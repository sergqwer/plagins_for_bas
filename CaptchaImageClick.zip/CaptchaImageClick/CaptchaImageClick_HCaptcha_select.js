var vzvalybc = GetInputConstructorValue("vzvalybc", loader);
                 if(vzvalybc["original"].length == 0)
                 {
                   Invalid("IS_INVISIBLE_CAPTCHA" + " is empty");
                   return;
                 }
var fcpwanit = GetInputConstructorValue("fcpwanit", loader);
                 if(fcpwanit["original"].length == 0)
                 {
                   Invalid("KEY" + " is empty");
                   return;
                 }
var dvdtykoq = GetInputConstructorValue("dvdtykoq", loader);
                 if(dvdtykoq["original"].length == 0)
                 {
                   Invalid("METHOD" + " is empty");
                   return;
                 }
var zrrqazij = GetInputConstructorValue("zrrqazij", loader);
                 if(zrrqazij["original"].length == 0)
                 {
                   Invalid("NUMBER_CAPTCHA" + " is empty");
                   return;
                 }
var lrdcoclk = GetInputConstructorValue("lrdcoclk", loader);
                 if(lrdcoclk["original"].length == 0)
                 {
                   Invalid("SELECTOR" + " is empty");
                   return;
                 }
var msnryoho = GetInputConstructorValue("msnryoho", loader);
                 if(msnryoho["original"].length == 0)
                 {
                   Invalid("SPEED_MOUSE" + " is empty");
                   return;
                 }
var vuwpevzj = GetInputConstructorValue("vuwpevzj", loader);
                 if(vuwpevzj["original"].length == 0)
                 {
                   Invalid("TRY_NUMBER" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#CaptchaImageClick_HCaptcha_code").html())({"vzvalybc": vzvalybc["updated"],"fcpwanit": fcpwanit["updated"],"dvdtykoq": dvdtykoq["updated"],"zrrqazij": zrrqazij["updated"],"lrdcoclk": lrdcoclk["updated"],"msnryoho": msnryoho["updated"],"vuwpevzj": vuwpevzj["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
