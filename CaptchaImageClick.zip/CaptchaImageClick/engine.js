function CaptchaImageClick_GeeTest()
   {
   
      
      
      VAR_GLOBAL_SELECTOR = _function_argument("SELECTOR")
	  
	  
	  
	  
	  VAR_GLOBAL_SELECTOR_BASE64 = _function_argument("SELECTOR_BASE64")
      

      
      
      VAR_KEY_MODULE = _function_argument("KEY")
      

      
      
      VAR_METHOD_MODULE = _function_argument("METHOD")
      

      
      
      VAR_SPEED_MOUSE = _function_argument("SPEED_MOUSE")
      

      
      
      VAR_TRY_MAX_CAPTCHA_PICTURE = _function_argument("TRY_MAX_CAPTCHA_PICTURE")
      

      
      
      /*Browser*/
      //cache_allow("*geetest.com/pictures*")!
      

      
      
      VAR_ERROR_FIND_MAIN_SELECTOR = "0"
      

      
      
      VAR_ERROR_LOAD = "0"
      

      
      
      VAR_ERROR_SOLVE = "0"
      

      
      
      VAR_ERROR_TASK = "0"
      

      
      
      VAR_CAPTCHA_MODULE_TYPE = "0"
      

      
      
      VAR_ERROR_CAP_MODULE = "0"
      

      
      
      VAR_GREEN_TICK = false
      

      
      
      VAR_GEETEST_TYPE_CAPTCHA = 0
      

      
      
      _call(function()
      {
      _on_fail(function(){
      VAR_LAST_ERROR = _result()
      VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
      VAR_WAS_ERROR = false
      _break(1,true)
      })
      CYCLES.Current().RemoveLabel("function")
      
         
         
         if (VAR_SPEED_MOUSE == "Slow")
         {
         VAR_SPEED = 100;
         VAR_GRAVITY = 6;
         VAR_DEVIATION = 2.5;
         }
         if (VAR_SPEED_MOUSE == "Normal")
         {
         VAR_SPEED = 200;
         VAR_GRAVITY = 12;
         VAR_DEVIATION = 5;
         }
         if (VAR_SPEED_MOUSE == "Fast")
         {
         VAR_SPEED = 300;
         VAR_GRAVITY = 18;
         VAR_DEVIATION = 7.5;
         }
         if (VAR_SPEED_MOUSE == "Very Fast")
         {
         VAR_SPEED = 400;
         VAR_GRAVITY = 24;
         VAR_DEVIATION = 10;
         }
         if (VAR_SPEED_MOUSE == "Extremal")
         {
         VAR_SPEED = 500;
         VAR_GRAVITY = 30;
         VAR_DEVIATION = 12.5;
         }
         

         
         
         page().script2("[[IS_MOBILE]] = navigator.maxTouchPoints;",JSON.stringify(_read_variables(["VAR_IS_MOBILE"])))!
         var _parse_result = JSON.parse(_result())
         _write_variables(JSON.parse(_parse_result.variables))
         if(!_parse_result.is_success)
         fail(_parse_result.error)
         

         
         
         _set_if_expression("W1tJU19NT0JJTEVdXSA9PSAwICYmIHJhbmQgKDEsMTApID4gNQ==");
         _if(VAR_IS_MOBILE == 0 && rand (1,10) > 5,function(){
         
            
            
            _do(function(){
            _set_action_info({ name: "While" });
            VAR_CYCLE_INDEX = _iterator() - 1
            BREAK_CONDITION = VAR_CYCLE_INDEX < 2 && VAR_IS_MOBILE == 0;
            if(!BREAK_CONDITION)_break();
            
               
               
               _get_browser_screen_settings()!
               ;(function(){
               var result = JSON.parse(_result())
               VAR_SCROLL_X = result["ScrollX"]
               VAR_SCROLL_Y = result["ScrollY"]
               VAR_CURSOR_X = result["CursorX"]
               VAR_CURSOR_Y = result["CursorY"]
               VAR_BROWSER_WIDTH = result["Width"]
               VAR_BROWSER_HEIGHT = result["Height"]
               })();
               

               
               
               var scroll_x=parseInt(VAR_CURSOR_Y);
               var scroll_y=parseInt(VAR_SCROLL_Y);
               var browser_h=parseInt(VAR_BROWSER_HEIGHT);
               //-------------------- Привели все в числа, считаем позицию ---------------------
               var absolut_y = VAR_CURSOR_Y + VAR_SCROLL_Y;
               var y_without_scroll = absolut_y - VAR_SCROLL_Y;
               var check_y_top = VAR_BROWSER_HEIGHT/12;
               var check_y_down = VAR_BROWSER_HEIGHT/100*92;
               var move_y_top = VAR_BROWSER_HEIGHT/10;
               var move_y_down = VAR_BROWSER_HEIGHT/100*80;
               // -------------------------- Округляем ----------------------------------
               VAR_CHECK_Y_TOP = check_y_top.toFixed();
               VAR_CHECK_Y_DOWN = check_y_down.toFixed();
               VAR_Y_WITHOUNT_SCROLL = y_without_scroll.toFixed();
               VAR_MOVE_Y_TOP = move_y_top.toFixed();
               VAR_MOVE_Y_DOWN = move_y_down.toFixed();
               // ----------------- Снова приводим к числу ------------------------
               VAR_CHECK_Y_TOP=parseInt(VAR_CHECK_Y_TOP);
               VAR_CHECK_Y_DOWN=parseInt(VAR_CHECK_Y_DOWN);
               VAR_Y_WITHOUNT_SCROLL=parseInt(VAR_Y_WITHOUNT_SCROLL);
               VAR_MOVE_Y_TOP=parseInt(VAR_MOVE_Y_TOP);
               VAR_MOVE_Y_DOWN=parseInt(VAR_MOVE_Y_DOWN);
               

               
               
               /*Browser*/
               move(rand(VAR_BROWSER_WIDTH/5,VAR_BROWSER_WIDTH/1.3),rand(VAR_MOVE_Y_TOP + VAR_SCROLL_Y,VAR_MOVE_Y_DOWN + VAR_SCROLL_Y),  {} )!
               

               
               
               _set_if_expression("cmFuZCAoMSwxMCkgPiA1");
               _if(rand (1,10) > 5,function(){
               
                  
                  
                  _break("function")
                  

               })!
               

            })!
            

         })!
         

         
         
         _do(function(){
         _set_action_info({ name: "For" });
         VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
         if(VAR_CYCLE_INDEX > parseInt(40))_break();
         
            
            
            /*Browser*/
            ;_SELECTOR=" \u003eCSS\u003e .geetest_canvas_slice";
            get_element_selector(_SELECTOR, false).nowait().exist()!
            VAR_IS_EXISTS = _result() == 1
            _if(VAR_IS_EXISTS, function(){
            get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
            VAR_IS_EXISTS = _result().indexOf("true")>=0
            })!
            

            
            
            _set_if_expression("W1tJU19FWElTVFNdXQ==");
            _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
            
               
               
               _break("function")
               

            })!
            

            
            
            /*Browser*/
            //;_SELECTOR=" \u003eCSS\u003e .geetest_window";
			;_SELECTOR=VAR_GLOBAL_SELECTOR_BASE64;
            get_element_selector(_SELECTOR, false).nowait().exist()!
            VAR_IS_EXISTS = _result() == 1
            _if(VAR_IS_EXISTS, function(){
            get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
            VAR_IS_EXISTS = _result().indexOf("true")>=0
            })!
            

            
            
            _set_if_expression("W1tJU19FWElTVFNdXQ==");
            _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
            
               
               
               _break("function")
               

            })!
            

            
            
            /*Browser*/
            ;_SELECTOR=VAR_GLOBAL_SELECTOR;
            get_element_selector(_SELECTOR, false).nowait().exist()!
            VAR_IS_EXISTS = _result() == 1
            _if(VAR_IS_EXISTS, function(){
            get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
            VAR_IS_EXISTS = _result().indexOf("true")>=0
            })!
            

            
            
            _cycle_params().if_else = typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined;
            _set_if_expression("W1tJU19FWElTVFNdXQ==");
            _if(_cycle_params().if_else,function(){
            
               
               
               /*Browser*/
               _SELECTOR = VAR_GLOBAL_SELECTOR;waiter_timeout_next(8000)
               wait_element_visible(_SELECTOR)!
               _call(_random_point, {})!
               _if(_result().length > 0, function(){
               move( {} )!
               get_element_selector(_SELECTOR, false).clarify(X,Y)!
               _call(_clarify, {} )!
               mouse(X,Y)!
               })!
               

               
               
               _break("function")
               

            })!
            

            
            
            _if(!_cycle_params().if_else,function(){
            
               
               
               sleep(rand(400,900))!
               

            })!
            delete _cycle_params().if_else;
            

            
            
            _set_if_expression("IVtbSVNfRVhJU1RTXV0=");
            _if(!VAR_IS_EXISTS,function(){
            
               
               
               _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gcmFuZCAoMjUsMzIp");
               _if(VAR_CYCLE_INDEX > rand (25,32),function(){
               
                  
                  
                  VAR_ERROR_FIND_MAIN_SELECTOR = "1"
                  

               })!
               

            })!
            

            
            
            sleep(rand(100,900))!
            

         })!
         

      },null)!
      

      
      
      _set_if_expression("W1tXQVNfRVJST1JdXQ==");
      _if(typeof(VAR_WAS_ERROR) !== "undefined" ? (VAR_WAS_ERROR) : undefined,function(){
      
         
         
         /*Browser*/
         cache_data_clear()!
         

         
         
         fail(VAR_LAST_ERROR)
         

      })!
      

      
      
      _set_if_expression("W1tFUlJPUl9GSU5EX01BSU5fU0VMRUNUT1JdXSA9PSAx");
      _if(VAR_ERROR_FIND_MAIN_SELECTOR == 1,function(){
      
         
         
         /*Browser*/
         cache_data_clear()!
         

         
         
         fail((_K==="en" ? "Could not wait for the main GeeTest selector to load main captcha window" : "Не удалось дождаться загрузки основного селектора, который должен открыть главное окно с капчей GeeTest"));
         

      })!
      

      
      
      VAR_TRY_CAPTCHA = "0"
      

      
      
      VAR_CAPTCHA_FAIL = "0"
      

      
      
      VAR_ERROR_KEY = "0"
      

      
      
      VAR_ERROR_BALANCE = "0"
      

      
      
      VAR_GET_ALL_COORDINATES = "0"
      

      
      
      VAR_FIRST_LOAD_CAPTCHA = true
      

      
      
      _set_goto_label("GeeTest Captcha Start here")!
      

      
      
      _do(function(){
      _set_action_info({ name: "For" });
      VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
      if(VAR_CYCLE_INDEX > parseInt(500))_break();
      
         
         
         VAR_CYCLE_INDEX = 0
         

         
         
         _set_if_expression("W1tFUlJPUl9LRVldXSA9PSAx");
         _if(VAR_ERROR_KEY == 1,function(){
         
            
            
            /*Browser*/
            cache_data_clear()!
            

            
            
            fail((_K==="en" ? "API secret key from captcha recognition service is wrong ERROR_WRONG_USER_KEY" : "Секретный ключ API от сервиса распознавания капчи неправильный ERROR_WRONG_USER_KEY"));
            

         })!
         

         
         
         _set_if_expression("W1tFUlJPUl9CQUxBTkNFXV0gPT0gMQ==");
         _if(VAR_ERROR_BALANCE == 1,function(){
         
            
            
            /*Browser*/
            cache_data_clear()!
            

            
            
            fail((_K==="en" ? "The balance on the captcha service has ended - ERROR_ZERO_BALANCE" : "Закончился баланс на сервисе распознавания капчи - ERROR_ZERO_BALANCE"));
            

         })!
         

         
         
         _set_if_expression("W1tDQVBUQ0hBX0ZBSUxdXSA9PSAx");
         _if(VAR_CAPTCHA_FAIL == 1,function(){
         
            
            
            /*Browser*/
            cache_data_clear()!
            

            
            
            fail((_K==="en" ? "Failed to complete the request to the captcha recognition server, error - CAPTCHA_FAIL" : "Не удалось выполнить запрос к серверу распознавания капчи, ошибка - CAPTCHA_FAIL"));
            

         })!
         

         
         
         _do(function(){
         _set_action_info({ name: "For" });
         VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
         if(VAR_CYCLE_INDEX > parseInt(120))_break();
         
            
            
            /*Browser*/
            ;_SELECTOR=" \u003eCSS\u003e .geetest_success_radar_tip_content";
            get_element_selector(_SELECTOR, false).nowait().exist()!
            VAR_IS_EXISTS = _result() == 1
            _if(VAR_IS_EXISTS, function(){
            get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
            VAR_IS_EXISTS = _result().indexOf("true")>=0
            })!
            

            
            
            _set_if_expression("W1tJU19FWElTVFNdXSA9PSB0cnVl");
            _if(VAR_IS_EXISTS == true,function(){
            
               
               
               /*Browser*/
               cache_data_clear()!
               

               
               
               VAR_GREEN_TICK = true
               

               
               
               _break("function")
               

            })!
            

            
            
            /*Browser*/
            ;_SELECTOR="\u003eCSS\u003e div[class*=\u0027geetest_slider geetest_fail\u0027]";
            get_element_selector(_SELECTOR, false).nowait().exist()!
            VAR_IS_EXISTS = _result() == 1
            _if(VAR_IS_EXISTS, function(){
            get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
            VAR_IS_EXISTS = _result().indexOf("true")>=0
            })!
            

            
            
            _set_if_expression("W1tJU19FWElTVFNdXQ==");
            _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
            
               
               
               VAR_ERROR_CAP_MODULE = 1
               

               
               
               _break("function")
               

            })!
            

            
            
            _set_if_expression("W1tFUlJPUl9DQVBfTU9EVUxFXV0gPT0gMQ==");
            _if(VAR_ERROR_CAP_MODULE == 1,function(){
            
               
               
               _break("function")
               

            })!
            

            
            
            /*Browser*/
            ;_SELECTOR=" \u003eCSS\u003e .geetest_canvas_slice";
            get_element_selector(_SELECTOR, false).nowait().exist()!
            VAR_IS_EXISTS = _result() == 1
            _if(VAR_IS_EXISTS, function(){
            get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
            VAR_IS_EXISTS = _result().indexOf("true")>=0
            })!
            

            
            
            _set_if_expression("W1tJU19FWElTVFNdXQ==");
            _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
            
               
               
               VAR_GEETEST_TYPE_CAPTCHA = "Canvas"
               

               
               
               _break("function")
               

            })!
            

            
            
            /*Browser*/
            //;_SELECTOR=" \u003eCSS\u003e .geetest_window";
			;_SELECTOR=VAR_GLOBAL_SELECTOR_BASE64;
            get_element_selector(_SELECTOR, false).nowait().exist()!
            VAR_IS_EXISTS = _result() == 1
            _if(VAR_IS_EXISTS, function(){
            get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
            VAR_IS_EXISTS = _result().indexOf("true")>=0
            })!
            

            
            
            _set_if_expression("W1tJU19FWElTVFNdXQ==");
            _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
            
               
               
               VAR_GEETEST_TYPE_CAPTCHA = "Normal_Image"
               

               
               
               _break("function")
               

            })!
            

            
            
            _set_if_expression("W1tJU19FWElTVFNdXSA9PSBmYWxzZSAmJiBbW0ZJUlNUX0xPQURfQ0FQVENIQV1dID09IGZhbHNl");
            _if(VAR_IS_EXISTS == false && VAR_FIRST_LOAD_CAPTCHA == false,function(){
            
               
               
               /*Browser*/
               cache_data_clear()!
               

               
               
               VAR_GREEN_TICK = true
               

               
               
               _break("function")
               

            })!
            

            
            
            _set_if_expression("W1tJU19FWElTVFNdXSA9PSBmYWxzZSAmJiBbW0ZJUlNUX0xPQURfQ0FQVENIQV1dID09IHRydWUgJiYgW1tDWUNMRV9JTkRFWF1dID4gNDU=");
            _if(VAR_IS_EXISTS == false && VAR_FIRST_LOAD_CAPTCHA == true && VAR_CYCLE_INDEX > 45,function(){
            
               
               
               /*Browser*/
               cache_data_clear()!
               

               
               
               fail((_K==="en" ? "Failed to solve the captcha. Unknown type of captcha window." : "Решить капчу не удалось. Неизвестный тип капчи."));
               

            })!
            

            
            
            sleep(rand(100,300))!
            

         })!
         

         
         
         VAR_CYCLE_INDEX = 0
         

         
         
         _set_if_expression("W1tHUkVFTl9USUNLXV0gPT0gdHJ1ZQ==");
         _if(VAR_GREEN_TICK == true,function(){
         
            
            
            /*Browser*/
            cache_data_clear()!
            

            
            
            _function_return("")
            

         })!
         

         
         
         VAR_TRY_CAPTCHA = parseInt(VAR_TRY_CAPTCHA) + parseInt(1)
         

         
         
         _set_if_expression("W1tUUllfQ0FQVENIQV1dID4gW1tUUllfTUFYX0NBUFRDSEFfUElDVFVSRV1d");
         _if(VAR_TRY_CAPTCHA > VAR_TRY_MAX_CAPTCHA_PICTURE,function(){
         
            
            
            fail((_K==="en" ? "Failed to solve the captcha. GeeTest attempts limit exceeded" : "Решить капчу не удалось. Превышен лимит попыток решить GeeTest капчу"));
            

         })!
         

         
         
         _call(function()
         {
         _on_fail(function(){
         VAR_LAST_ERROR = _result()
         VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
         VAR_WAS_ERROR = false
         _break(1,true)
         })
         CYCLES.Current().RemoveLabel("function")
         
            
            
            _set_if_expression("W1tFUlJPUl9DQVBfTU9EVUxFXV0gPT0gMQ==");
            _if(VAR_ERROR_CAP_MODULE == 1,function(){
            
               
               
               /*Browser*/
               ;_SELECTOR="\u003eCSS\u003e a[class*=\u0027geetest_refresh\u0027]";
               get_element_selector(_SELECTOR, false).nowait().exist()!
               VAR_IS_EXISTS = _result() == 1
               _if(VAR_IS_EXISTS, function(){
               get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
               VAR_IS_EXISTS = _result().indexOf("true")>=0
               })!
               

               
               
               _set_if_expression("W1tJU19FWElTVFNdXQ==");
               _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
               
                  
                  
                  /*Browser*/
                  _SELECTOR = "\u003eCSS\u003e a[class*=\u0027geetest_refresh\u0027]";
                  wait_element_visible(_SELECTOR)!
                  _call(_random_point, {})!
                  _if(_result().length > 0, function(){
                  move( {"speed": 100,"gravity": 6,"deviation": 2.5} )!
                  get_element_selector(_SELECTOR, false).clarify(X,Y)!
                  _call(_clarify, {"speed": 100,"gravity": 6,"deviation": 2.5} )!
                  mouse(X,Y)!
                  })!
                  

                  
                  
                  sleep(500)!
                  

               })!
               

            })!
            

         },null)!
         

         
         
         _call(function()
         {
         _on_fail(function(){
         VAR_LAST_ERROR = _result()
         VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
         VAR_WAS_ERROR = false
         _break(1,true)
         })
         CYCLES.Current().RemoveLabel("function")
         
            
            
            VAR_CYCLE_INDEX = "0"
            

            
            

            

            
            
            /*Browser*/
            //_SELECTOR = " \u003eCSS\u003e .geetest_window";
			;_SELECTOR=VAR_GLOBAL_SELECTOR_BASE64;
            wait_element(_SELECTOR)!
            get_element_selector(_SELECTOR, false).exist()!
            _if(_result() == "1", function(){
            get_element_selector(_SELECTOR, false).render_base64()!
            VAR_IMAGE_BASE_64 = _result()
            })!
            

         },null)!
         

         
         
         _set_if_expression("W1tXQVNfRVJST1JdXQ==");
         _if(typeof(VAR_WAS_ERROR) !== "undefined" ? (VAR_WAS_ERROR) : undefined,function(){
         
            
            
            _call(function()
            {
            _on_fail(function(){
            VAR_LAST_ERROR = _result()
            VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
            VAR_WAS_ERROR = false
            _break(1,true)
            })
            CYCLES.Current().RemoveLabel("function")
            
               
               
               /*Browser*/
               ;_SELECTOR="\u003eCSS\u003e a[class*=\u0027geetest_refresh\u0027]";
               get_element_selector(_SELECTOR, false).nowait().exist()!
               VAR_IS_EXISTS = _result() == 1
               _if(VAR_IS_EXISTS, function(){
               get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
               VAR_IS_EXISTS = _result().indexOf("true")>=0
               })!
               

               
               
               _set_if_expression("W1tJU19FWElTVFNdXQ==");
               _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
               
                  
                  
                  /*Browser*/
                  _SELECTOR = "\u003eCSS\u003e a[class*=\u0027geetest_refresh\u0027]";
                  wait_element_visible(_SELECTOR)!
                  _call(_random_point, {})!
                  _if(_result().length > 0, function(){
                  move( {"speed": 100,"gravity": 6,"deviation": 2.5} )!
                  get_element_selector(_SELECTOR, false).clarify(X,Y)!
                  _call(_clarify, {"speed": 100,"gravity": 6,"deviation": 2.5} )!
                  mouse(X,Y)!
                  })!
                  

               })!
               

               
               
               /*Browser*/
               ;_SELECTOR="\u003eCSS\u003e button[class*=\u0027geetest_refresh\u0027]";
               get_element_selector(_SELECTOR, false).nowait().exist()!
               VAR_IS_EXISTS = _result() == 1
               _if(VAR_IS_EXISTS, function(){
               get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
               VAR_IS_EXISTS = _result().indexOf("true")>=0
               })!
               

               
               
               _set_if_expression("W1tJU19FWElTVFNdXQ==");
               _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
               
                  
                  
                  /*Browser*/
                  _SELECTOR = "\u003eCSS\u003e button[class*=\u0027geetest_refresh\u0027]";
                  wait_element_visible(_SELECTOR)!
                  _call(_random_point, {})!
                  _if(_result().length > 0, function(){
                  move( {"speed": 100,"gravity": 6,"deviation": 2.5} )!
                  get_element_selector(_SELECTOR, false).clarify(X,Y)!
                  _call(_clarify, {"speed": 100,"gravity": 6,"deviation": 2.5} )!
                  mouse(X,Y)!
                  })!
                  

               })!
               

            },null)!
            

            
            
            _next("function")
            

         })!
         

         
         
         _call(function()
         {
         _on_fail(function(){
         VAR_LAST_ERROR = _result()
         VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
         VAR_WAS_ERROR = false
         _break(1,true)
         })
         CYCLES.Current().RemoveLabel("function")
         
            
            
            _set_if_expression("W1tJU19NT0JJTEVdXSA9PSAw");
            _if(VAR_IS_MOBILE == 0,function(){
            
               
               
               _get_browser_screen_settings()!
               ;(function(){
               var result = JSON.parse(_result())
               VAR_SCROLL_X = result["ScrollX"]
               VAR_SCROLL_Y = result["ScrollY"]
               VAR_CURSOR_X = result["CursorX"]
               VAR_CURSOR_Y = result["CursorY"]
               VAR_BROWSER_WIDTH = result["Width"]
               VAR_BROWSER_HEIGHT = result["Height"]
               })();
               

               
               
               _set_if_expression("W1tHRUVURVNUX1RZUEVfQ0FQVENIQV1dID09ICJDYW52YXMi");
               _if(VAR_GEETEST_TYPE_CAPTCHA == "Canvas",function(){
               
                  
                  
                  /*Browser*/
                  ;_SELECTOR="\u003eCSS\u003e div[class*=\u0027geetest_holder geetest_mobile\u0027]";
                  get_element_selector(_SELECTOR, false).nowait().exist()!
                  VAR_IS_EXISTS = _result() == 1
                  _if(VAR_IS_EXISTS, function(){
                  get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
                  VAR_IS_EXISTS = _result().indexOf("true")>=0
                  })!
                  

                  
                  
                  _set_if_expression("IVtbSVNfRVhJU1RTXV0=");
                  _if(!VAR_IS_EXISTS,function(){
                  
                     
                     
                     _next("function")
                     

                  })!
                  

                  
                  
                  _set_if_expression("W1tJU19FWElTVFNdXQ==");
                  _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
                  
                     
                     
                     /*Browser*/
                     _SELECTOR = "\u003eCSS\u003e div[class*=\u0027geetest_holder geetest_mobile\u0027]";
                     wait_element(_SELECTOR)!
                     get_element_selector(_SELECTOR, false).script("(function(){var rect = self.getBoundingClientRect();return (rect.left + positionx).toString() + '|' + (rect.top + positiony).toString() + '|' + (rect.right - rect.left).toString() + '|' + (rect.bottom - rect.top).toString()})();")!
                     if(_result().length > 0)
                     {
                     var split = _result().split("|")
                     VAR_X = parseInt(split[0])
                     VAR_Y = parseInt(split[1])
                     VAR_CAPTCHA_WIDTH = parseInt(split[2])
                     VAR_CAPTCHA_HEIGHT = parseInt(split[3])
                     }
                     

                     
                     
                     /*Browser*/
                     move(rand(VAR_X/100*115,(VAR_X+VAR_CAPTCHA_WIDTH)/100*93).toFixed(),rand(VAR_Y + VAR_SCROLL_Y/100*120,VAR_Y + VAR_SCROLL_Y + VAR_CAPTCHA_HEIGHT/100*90).toFixed(),  {} )!
                     

                  })!
                  

               })!
               

               
               
               _set_if_expression("W1tHRUVURVNUX1RZUEVfQ0FQVENIQV1dID09ICJOb3JtYWxfSW1hZ2Ui");
               _if(VAR_GEETEST_TYPE_CAPTCHA == "Normal_Image",function(){
               
                  
                  
                  /*Browser*/
                  ;_SELECTOR=" \u003eCSS\u003e .geetest_box";
                  get_element_selector(_SELECTOR, false).nowait().exist()!
                  VAR_IS_EXISTS = _result() == 1
                  _if(VAR_IS_EXISTS, function(){
                  get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
                  VAR_IS_EXISTS = _result().indexOf("true")>=0
                  })!
                  

                  
                  
                  _set_if_expression("IVtbSVNfRVhJU1RTXV0=");
                  _if(!VAR_IS_EXISTS,function(){
                  
                     
                     
                     _next("function")
                     

                  })!
                  

                  
                  
                  _set_if_expression("W1tJU19FWElTVFNdXQ==");
                  _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
                  
                     
                     
                     /*Browser*/
                     _SELECTOR = " \u003eCSS\u003e .geetest_box";
                     wait_element(_SELECTOR)!
                     get_element_selector(_SELECTOR, false).script("(function(){var rect = self.getBoundingClientRect();return (rect.left + positionx).toString() + '|' + (rect.top + positiony).toString() + '|' + (rect.right - rect.left).toString() + '|' + (rect.bottom - rect.top).toString()})();")!
                     if(_result().length > 0)
                     {
                     var split = _result().split("|")
                     VAR_X = parseInt(split[0])
                     VAR_Y = parseInt(split[1])
                     VAR_CAPTCHA_WIDTH = parseInt(split[2])
                     VAR_CAPTCHA_HEIGHT = parseInt(split[3])
                     }
                     

                     
                     
                     /*Browser*/
                     move(rand(VAR_X/100*115,(VAR_X+VAR_CAPTCHA_WIDTH)/100*93).toFixed(),rand(VAR_Y + VAR_SCROLL_Y/100*120,VAR_Y + VAR_SCROLL_Y + VAR_CAPTCHA_HEIGHT/100*90).toFixed(),  {} )!
                     

                  })!
                  

               })!
               

               
               
               _set_if_expression("W1tTQ1JPTExfWV1dICE9IDA=");
               _if(VAR_SCROLL_Y != 0,function(){
               
                  
                  
                  /*Browser*/
                  _scroll_to(0)!
                  

               })!
               

            })!
            

         },null)!
         

         
         
         VAR_FIRST_LOAD_CAPTCHA = false
         

         
         
         _call(function()
         {
         _on_fail(function(){
         VAR_LAST_ERROR = _result()
         VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
         VAR_WAS_ERROR = false
         _break(1,true)
         })
         CYCLES.Current().RemoveLabel("function")
         
            
            
            _do(function(){
            _set_action_info({ name: "For" });
            VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
            if(VAR_CYCLE_INDEX > parseInt(5))_break();
            
               
               
		  
					_cycle_params().if_else = VAR_METHOD_MODULE == "GoodXevilPay";
					//_set_if_expression("MSA9PSAy");
					_if(_cycle_params().if_else,function(){
					section_insert()

					solver_property("capmonster","serverurl","http://goodxevilpay.shop/")
					solver_property("capmonster","key",VAR_KEY_MODULE)
					solver_property("capmonster","method","geetest")
					//// Отправляем
					solver_property("capmonster", "body", VAR_IMAGE_BASE_64)
					solve_base64_no_fail("capmonster", "")!
					VAR_SAVED_CONTENT = _result();


					})!



					_if(!_cycle_params().if_else,function(){
					section_insert()

					solver_property("capmonster","serverurl","https://api.captcha.guru/")
					solver_property("capmonster","coordinatescaptcha","1")
					solver_property("capmonster","key",VAR_KEY_MODULE)
					solver_property("capmonster","click","geetest")
					solver_property("capmonster","method","post")
					//// Отправляем
					solve_base64_no_fail("capmonster", VAR_IMAGE_BASE_64)!
					VAR_SAVED_CONTENT = _result();


					})!
					//delete _cycle_params().if_else;
			   
               

               
               
               _set_if_expression("W1tTQVZFRF9DT05URU5UXV0uaW5kZXhPZigiRVJST1JfQ0FQVENIQV9VTlNPTFZBQkxFIikgPj0gMA==");
               _if(VAR_SAVED_CONTENT.indexOf("ERROR_CAPTCHA_UNSOLVABLE") >= 0,function(){
               
                  
                  
                  /*Browser*/
                  ;_SELECTOR="\u003eCSS\u003e a[class*=\u0027geetest_refresh\u0027]";
                  get_element_selector(_SELECTOR, false).nowait().exist()!
                  VAR_IS_EXISTS = _result() == 1
                  _if(VAR_IS_EXISTS, function(){
                  get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
                  VAR_IS_EXISTS = _result().indexOf("true")>=0
                  })!
                  

                  
                  
                  _set_if_expression("W1tJU19FWElTVFNdXQ==");
                  _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
                  
                     
                     
                     /*Browser*/
                     _SELECTOR = "\u003eCSS\u003e a[class*=\u0027geetest_refresh\u0027]";
                     wait_element_visible(_SELECTOR)!
                     _call(_random_point, {})!
                     _if(_result().length > 0, function(){
                     move( {"speed": 100,"gravity": 6,"deviation": 2.5} )!
                     get_element_selector(_SELECTOR, false).clarify(X,Y)!
                     _call(_clarify, {"speed": 100,"gravity": 6,"deviation": 2.5} )!
                     mouse(X,Y)!
                     })!
                     

                  })!
                  

                  
                  
                  /*Browser*/
                  ;_SELECTOR="\u003eCSS\u003e button[class*=\u0027geetest_refresh\u0027]";
                  get_element_selector(_SELECTOR, false).nowait().exist()!
                  VAR_IS_EXISTS = _result() == 1
                  _if(VAR_IS_EXISTS, function(){
                  get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
                  VAR_IS_EXISTS = _result().indexOf("true")>=0
                  })!
                  

                  
                  
                  _set_if_expression("W1tJU19FWElTVFNdXQ==");
                  _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
                  
                     
                     
                     /*Browser*/
                     _SELECTOR = "\u003eCSS\u003e button[class*=\u0027geetest_refresh\u0027]";
                     wait_element_visible(_SELECTOR)!
                     _call(_random_point, {})!
                     _if(_result().length > 0, function(){
                     move( {"speed": 100,"gravity": 6,"deviation": 2.5} )!
                     get_element_selector(_SELECTOR, false).clarify(X,Y)!
                     _call(_clarify, {"speed": 100,"gravity": 6,"deviation": 2.5} )!
                     mouse(X,Y)!
                     })!
                     

                  })!
                  

                  
                  
                  sleep(rand(1000,3000))!
                  

                  
                  
                  _break("function")
                  

               })!
               

               
               
               _set_if_expression("W1tTQVZFRF9DT05URU5UXV0uaW5kZXhPZigiRVJST1JfV1JPTkdfVVNFUl9LRVkiKSA+PSAw");
               _if(VAR_SAVED_CONTENT.indexOf("ERROR_WRONG_USER_KEY") >= 0,function(){
               
                  
                  
                  VAR_ERROR_KEY = "1"
                  

                  
                  
                  _break("function")
                  

               })!
               

               
               
               _set_if_expression("W1tTQVZFRF9DT05URU5UXV0uaW5kZXhPZigiRVJST1JfWkVST19CQUxBTkNFIikgPj0gMA==");
               _if(VAR_SAVED_CONTENT.indexOf("ERROR_ZERO_BALANCE") >= 0,function(){
               
                  
                  
                  VAR_ERROR_BALANCE = "1"
                  

                  
                  
                  _break("function")
                  

               })!
               

               
               
               _set_if_expression("W1tTQVZFRF9DT05URU5UXV0uaW5kZXhPZigiQ0FQVENIQV9GQUlMIikgPj0gMA==");
               _if(VAR_SAVED_CONTENT.indexOf("CAPTCHA_FAIL") >= 0,function(){
               
                  
                  
                  VAR_CAPTCHA_FAIL = "1"
                  

                  
                  
                  _break("function")
                  

               })!
               

               
               
               _cycle_params().if_else = VAR_SAVED_CONTENT.match(/[0-9]/);
               _set_if_expression("W1tTQVZFRF9DT05URU5UXV0ubWF0Y2goL1swLTldLyk=");
               _if(_cycle_params().if_else,function(){
               
                  
                  
                  var dd = VAR_SAVED_CONTENT;
                  var num_slide = dd.replace(/[;]+/g,",").replace(/[^0-9,]/g,"").split(",") /// Спарсили все цифры с ответа
                  VAR_X2 = parseInt(num_slide[0]); /// X2 координата куда двигать на картинке
                  VAR_Y2 = parseInt(num_slide[1]); /// Y2 координата куда двигать на картинке
                  VAR_W2 = parseInt(num_slide[2]); /// W2 координата куда двигать на картинке
				  //log(VAR_X2, VAR_Y2, VAR_W2);
                  

                  
                  
                  /*Browser*/
                  ;_SELECTOR=" \u003eCSS\u003e .geetest_slider_tip";
                  get_element_selector(_SELECTOR, false).nowait().exist()!
                  VAR_IS_EXISTS = _result() == 1
                  _if(VAR_IS_EXISTS, function(){
                  get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
                  VAR_IS_EXISTS = _result().indexOf("true")>=0
                  })!
                  

                  
                  
                  _set_if_expression("W1tJU19FWElTVFNdXQ==");
                  _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
                  
                     
                     
                     /*Browser*/
                     //_SELECTOR = " \u003eCSS\u003e .geetest_window";
					 ;_SELECTOR=VAR_GLOBAL_SELECTOR_BASE64;
                     wait_element(_SELECTOR)!
                     get_element_selector(_SELECTOR, false).script("(function(){var rect = self.getBoundingClientRect();return (rect.left + positionx).toString() + '|' + (rect.top + positiony).toString() + '|' + (rect.right - rect.left).toString() + '|' + (rect.bottom - rect.top).toString()})();")!
                     if(_result().length > 0)
                     {
                     var split = _result().split("|")
                     VAR_X_PICTRURE = parseInt(split[0])
                     VAR_Y_PICTRURE = parseInt(split[1])
                     VAR_WIDTH_PICTRURE = parseInt(split[2])
                     VAR_HEIGHT_PICTRURE = parseInt(split[3])
                     }
                     

                     
                     
                     /*Browser*/
                     _SELECTOR = " \u003eCSS\u003e .geetest_slider_tip";
                     wait_element(_SELECTOR)!
                     get_element_selector(_SELECTOR, false).script("(function(){var rect = self.getBoundingClientRect();return (rect.left + positionx).toString() + '|' + (rect.top + positiony).toString() + '|' + (rect.right - rect.left).toString() + '|' + (rect.bottom - rect.top).toString()})();")!
                     if(_result().length > 0)
                     {
                     var split = _result().split("|")
                     VAR_X_SLIDER = parseInt(split[0])
                     VAR_Y_SLIDER = parseInt(split[1])
                     VAR_WIDTH_SLIDER = parseInt(split[2])
                     VAR_HEIGHT_SLIDER = parseInt(split[3])
                     }
                     

                     
                     
                     VAR_Y_SLIDER = VAR_Y_SLIDER + VAR_HEIGHT_SLIDER/2; /// Координаты прогресс бага где нужно двигать ползунок
                     

                  })!
                  

                  
                  
                  /*Browser*/
                  ;_SELECTOR=" \u003eCSS\u003e .geetest_track";
                  get_element_selector(_SELECTOR, false).nowait().exist()!
                  VAR_IS_EXISTS2 = _result() == 1
                  _if(VAR_IS_EXISTS2, function(){
                  get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
                  VAR_IS_EXISTS2 = _result().indexOf("true")>=0
                  })!
                  

                  
                  
                  _set_if_expression("W1tJU19FWElTVFMyXV0=");
                  _if(typeof(VAR_IS_EXISTS2) !== "undefined" ? (VAR_IS_EXISTS2) : undefined,function(){
                  
                     
                     
                     /*Browser*/
                     //_SELECTOR = " \u003eCSS\u003e .geetest_window";
					 ;_SELECTOR=VAR_GLOBAL_SELECTOR_BASE64;
                     wait_element(_SELECTOR)!
                     get_element_selector(_SELECTOR, false).script("(function(){var rect = self.getBoundingClientRect();return (rect.left + positionx).toString() + '|' + (rect.top + positiony).toString() + '|' + (rect.right - rect.left).toString() + '|' + (rect.bottom - rect.top).toString()})();")!
                     if(_result().length > 0)
                     {
                     var split = _result().split("|")
                     VAR_X_PICTRURE = parseInt(split[0])
                     VAR_Y_PICTRURE = parseInt(split[1])
                     VAR_WIDTH_PICTRURE = parseInt(split[2])
                     VAR_HEIGHT_PICTRURE = parseInt(split[3])
                     }
                     

                     
                     
                     /*Browser*/
                     _SELECTOR = " \u003eCSS\u003e .geetest_track";
                     wait_element(_SELECTOR)!
                     get_element_selector(_SELECTOR, false).script("(function(){var rect = self.getBoundingClientRect();return (rect.left + positionx).toString() + '|' + (rect.top + positiony).toString() + '|' + (rect.right - rect.left).toString() + '|' + (rect.bottom - rect.top).toString()})();")!
                     if(_result().length > 0)
                     {
                     var split = _result().split("|")
                     VAR_X_SLIDER = parseInt(split[0])
                     VAR_Y_SLIDER = parseInt(split[1])
                     VAR_WIDTH_SLIDER = parseInt(split[2])
                     VAR_HEIGHT_SLIDER = parseInt(split[3])
                     }
                     

                     
                     
                     VAR_Y_SLIDER = VAR_Y_SLIDER + VAR_HEIGHT_SLIDER/2; /// Координаты прогресс бага где нужно двигать ползунок
                     

                  })!
                  

                  
                  
                  _set_if_expression("W1tJU19FWElTVFNdXSA9PSBmYWxzZSAmJiBbW0lTX0VYSVNUUzJdXSA9PSBmYWxzZQ==");
                  _if(VAR_IS_EXISTS == false && VAR_IS_EXISTS2 == false,function(){
                  
                     
                     
                     _break("function")
                     

                  })!
                  

                  
                  
                  _set_if_expression("W1tHRUVURVNUX1RZUEVfQ0FQVENIQV1dID09ICJDYW52YXMi");
                  _if(VAR_GEETEST_TYPE_CAPTCHA == "Canvas",function(){
                  
                     
                     
                     /*Browser*/
                     _SELECTOR = " \u003eCSS\u003e .geetest_slider_button";
                     wait_element_visible(_SELECTOR)!
                     _call(_random_point, {})!
                     _if(_result().length > 0, function(){
                     move( {} )!
                     get_element_selector(_SELECTOR, false).clarify(X,Y)!
                     _call(_clarify, {} )!
                     mouse_down(X,Y)!
                     })!
                     

                     
                     
                     _cycle_params().if_else = rand (1,10) >5;
                     _set_if_expression("cmFuZCAoMSwxMCkgPjU=");
                     _if(_cycle_params().if_else,function(){
                     
                        
                        
                        /*Browser*/
                        move(VAR_X_PICTRURE + VAR_X2 + VAR_W2/2,VAR_Y_PICTRURE + VAR_Y2,  {} )!
                        

                        
                        
                        /*Browser*/
                        move(VAR_X_PICTRURE + VAR_X2 + VAR_W2/2,VAR_Y_SLIDER,  {} )!
                        

                     })!
                     

                     
                     
                     _if(!_cycle_params().if_else,function(){
                     
                        
                        
                        /*Browser*/
                        move(VAR_X_SLIDER + VAR_WIDTH_SLIDER/2,VAR_Y_SLIDER,  {} )!
                        

                     })!
                     delete _cycle_params().if_else;
                     

                     
                     
                     sleep(rand(500,1000))!
                     

                     
                     
                     /*Browser*/
                     var move_settings =  {} ;
                     move_settings["do_mouse_up"] = "true"
                     move(VAR_X_PICTRURE + VAR_X2 + VAR_W2/2,VAR_Y_SLIDER, move_settings)!
                     

                  })!
                  

                  
                  
                  _set_if_expression("W1tHRUVURVNUX1RZUEVfQ0FQVENIQV1dID09ICJOb3JtYWxfSW1hZ2Ui");
                  _if(VAR_GEETEST_TYPE_CAPTCHA == "Normal_Image",function(){
                  
                     
                     
                     /*Browser*/
                     _SELECTOR = " \u003eCSS\u003e .geetest_btn";
                     wait_element_visible(_SELECTOR)!
                     _call(_random_point, {})!
                     _if(_result().length > 0, function(){
                     move( {} )!
                     get_element_selector(_SELECTOR, false).clarify(X,Y)!
                     _call(_clarify, {} )!
                     mouse_down(X,Y)!
                     })!
                     

                     
                     
                     _cycle_params().if_else = rand (1,10) >5;
                     _set_if_expression("cmFuZCAoMSwxMCkgPjU=");
                     _if(_cycle_params().if_else,function(){
                     
                        
                        
                        /*Browser*/
                        move(VAR_X_PICTRURE + VAR_X2 + VAR_W2/2,VAR_Y_SLIDER,  {} )!
                        

                        
                        
                        /*Browser*/
                        move(VAR_X_PICTRURE + VAR_X2 + VAR_W2/2,VAR_Y_SLIDER,  {} )!
                        

                     })!
                     

                     
                     
                     _if(!_cycle_params().if_else,function(){
                     
                        
                        
                        /*Browser*/
                        move(VAR_X_SLIDER + VAR_WIDTH_SLIDER/2,VAR_Y_SLIDER,  {} )!
                        

                     })!
                     delete _cycle_params().if_else;
                     

                     
                     
                     sleep(rand(400,1000))!
                     

                     
                     
                     /*Browser*/
                     var move_settings =  {} ;
                     move_settings["do_mouse_up"] = "true"
                     move(VAR_X_PICTRURE + VAR_X2 + VAR_W2/2,VAR_Y_SLIDER, move_settings)!
                     

                  })!
                  

                  
                  
                  VAR_ERROR_CAP_MODULE = "0"
                  

                  
                  
                  sleep(200)!
                  

                  
                  
                  /*Browser*/
                  ;_SELECTOR="\u003eCSS\u003e div[class*=\u0027geetest_slider geetest_fail\u0027]";
                  get_element_selector(_SELECTOR, false).nowait().exist()!
                  VAR_IS_EXISTS = _result() == 1
                  _if(VAR_IS_EXISTS, function(){
                  get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
                  VAR_IS_EXISTS = _result().indexOf("true")>=0
                  })!
                  

                  
                  
                  _set_if_expression("W1tJU19FWElTVFNdXQ==");
                  _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
                  
                     
                     
                     VAR_ERROR_CAP_MODULE = 1
                     

                  })!
                  

                  
                  
                  sleep(rand(100,200))!
                  

                  
                  
                  _break("function")
                  

               })!
               

               
               
               _if(!_cycle_params().if_else,function(){
               
                  
                  
                  sleep(rand(1000,2000))!
                  

                  
                  
                  _next("function")
                  

               })!
               delete _cycle_params().if_else;
               

            })!
            

            
            
            _next("function")
            

         },null)!
         

         
         
         _set_if_expression("W1tXQVNfRVJST1JdXQ==");
         _if(typeof(VAR_WAS_ERROR) !== "undefined" ? (VAR_WAS_ERROR) : undefined,function(){
         
            
            
            sleep(1000)!
            

            
            
            _next("function")
            

         })!
         

      })!
      

   }
   

function CaptchaImageClick_TikTok()
   {
   
      
      
      VAR_KEY_MODULE = _function_argument("KEY")
      

      
      
      VAR_METHOD_MODULE = _function_argument("METHOD")
      

      
      
      VAR_SPEED_MOUSE = _function_argument("SPEED_MOUSE")
      

      
      
      VAR_TRY_MAX_CAPTCHA_PICTURE = _function_argument("TRY_MAX_CAPTCHA_PICTURE")
      

      
      
      VAR_ERROR_LOAD = "0"
      

      
      
      VAR_ERROR_SOLVE = "0"
      

      
      
      VAR_ERROR_TASK = "0"
      

      
      
      VAR_CAPTCHA_MODULE_TYPE = "0"
      

      
      
      VAR_IMG1_MODULE = "0"
      

      
      
      VAR_IMG2_MODULE = "0"
      

      
      
      VAR_GREEN_TICK = false
      

      
      
      /*Browser*/
      cache_allow("*ibyteimg.com*")!
      

      
      
      /*Browser*/
      cache_allow("*captcha*")!
      

      
      
      _call(function()
      {
      _on_fail(function(){
      VAR_LAST_ERROR = _result()
      VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
      VAR_WAS_ERROR = false
      _break(1,true)
      })
      CYCLES.Current().RemoveLabel("function")
      
         
         
         if (VAR_SPEED_MOUSE == "Slow")
         {
         VAR_SPEED = 100;
         VAR_GRAVITY = 6;
         VAR_DEVIATION = 2.5;
         }
         if (VAR_SPEED_MOUSE == "Normal")
         {
         VAR_SPEED = 200;
         VAR_GRAVITY = 12;
         VAR_DEVIATION = 5;
         }
         if (VAR_SPEED_MOUSE == "Fast")
         {
         VAR_SPEED = 300;
         VAR_GRAVITY = 18;
         VAR_DEVIATION = 7.5;
         }
         if (VAR_SPEED_MOUSE == "Very Fast")
         {
         VAR_SPEED = 400;
         VAR_GRAVITY = 24;
         VAR_DEVIATION = 10;
         }
         if (VAR_SPEED_MOUSE == "Extremal")
         {
         VAR_SPEED = 500;
         VAR_GRAVITY = 30;
         VAR_DEVIATION = 12.5;
         }
         

         
         
         page().script2("[[IS_MOBILE]] = navigator.maxTouchPoints;",JSON.stringify(_read_variables(["VAR_IS_MOBILE"])))!
         var _parse_result = JSON.parse(_result())
         _write_variables(JSON.parse(_parse_result.variables))
         if(!_parse_result.is_success)
         fail(_parse_result.error)
         

         
         
         _set_if_expression("W1tJU19NT0JJTEVdXSA9PSAwICYmIHJhbmQgKDEsMTApID4gNQ==");
         _if(VAR_IS_MOBILE == 0 && rand (1,10) > 5,function(){
         
            
            
            _do(function(){
            _set_action_info({ name: "While" });
            VAR_CYCLE_INDEX = _iterator() - 1
            BREAK_CONDITION = VAR_CYCLE_INDEX < 2 && VAR_IS_MOBILE == 0;
            if(!BREAK_CONDITION)_break();
            
               
               
               _get_browser_screen_settings()!
               ;(function(){
               var result = JSON.parse(_result())
               VAR_SCROLL_X = result["ScrollX"]
               VAR_SCROLL_Y = result["ScrollY"]
               VAR_CURSOR_X = result["CursorX"]
               VAR_CURSOR_Y = result["CursorY"]
               VAR_BROWSER_WIDTH = result["Width"]
               VAR_BROWSER_HEIGHT = result["Height"]
               })();
               

               
               
               var scroll_x=parseInt(VAR_CURSOR_Y);
               var scroll_y=parseInt(VAR_SCROLL_Y);
               var browser_h=parseInt(VAR_BROWSER_HEIGHT);
               //-------------------- Привели все в числа, считаем позицию ---------------------
               var absolut_y = VAR_CURSOR_Y + VAR_SCROLL_Y;
               var y_without_scroll = absolut_y - VAR_SCROLL_Y;
               var check_y_top = VAR_BROWSER_HEIGHT/12;
               var check_y_down = VAR_BROWSER_HEIGHT/100*92;
               var move_y_top = VAR_BROWSER_HEIGHT/10;
               var move_y_down = VAR_BROWSER_HEIGHT/100*80;
               // -------------------------- Округляем ----------------------------------
               VAR_CHECK_Y_TOP = check_y_top.toFixed();
               VAR_CHECK_Y_DOWN = check_y_down.toFixed();
               VAR_Y_WITHOUNT_SCROLL = y_without_scroll.toFixed();
               VAR_MOVE_Y_TOP = move_y_top.toFixed();
               VAR_MOVE_Y_DOWN = move_y_down.toFixed();
               // ----------------- Снова приводим к числу ------------------------
               VAR_CHECK_Y_TOP=parseInt(VAR_CHECK_Y_TOP);
               VAR_CHECK_Y_DOWN=parseInt(VAR_CHECK_Y_DOWN);
               VAR_Y_WITHOUNT_SCROLL=parseInt(VAR_Y_WITHOUNT_SCROLL);
               VAR_MOVE_Y_TOP=parseInt(VAR_MOVE_Y_TOP);
               VAR_MOVE_Y_DOWN=parseInt(VAR_MOVE_Y_DOWN);
               

               
               
               /*Browser*/
               move(rand(VAR_BROWSER_WIDTH/5,VAR_BROWSER_WIDTH/1.3),rand(VAR_MOVE_Y_TOP + VAR_SCROLL_Y,VAR_MOVE_Y_DOWN + VAR_SCROLL_Y),  {} )!
               

               
               
               _set_if_expression("cmFuZCAoMSwxMCkgPiA1");
               _if(rand (1,10) > 5,function(){
               
                  
                  
                  _break("function")
                  

               })!
               

            })!
            

         })!
         

      },null)!
      

      
      
      VAR_TRY_CAPTCHA = "0"
      

      
      
      VAR_CAPTCHA_FAIL = "0"
      

      
      
      VAR_ERROR_KEY = "0"
      

      
      
      VAR_ERROR_BALANCE = "0"
      

      
      
      VAR_GET_ALL_COORDINATES = "0"
      

      
      
      VAR_FIRST_LOAD_CAPTCHA = true
      

      
      
      _set_goto_label("Tiktok Captcha Start here")!
      

      
      
      _do(function(){
      _set_action_info({ name: "For" });
      VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
      if(VAR_CYCLE_INDEX > parseInt(500))_break();
      
         
         
         VAR_CYCLE_INDEX = 0
         

         
         
         _set_if_expression("W1tFUlJPUl9LRVldXSA9PSAx");
         _if(VAR_ERROR_KEY == 1,function(){
         
            
            
            /*Browser*/
            cache_data_clear()!
            

            
            
            fail((_K==="en" ? "API secret key from captcha recognition service is wrong ERROR_WRONG_USER_KEY" : "Секретный ключ API от сервиса распознавания капчи неправильный ERROR_WRONG_USER_KEY"));
            

         })!
         

         
         
         _set_if_expression("W1tFUlJPUl9CQUxBTkNFXV0gPT0gMQ==");
         _if(VAR_ERROR_BALANCE == 1,function(){
         
            
            
            /*Browser*/
            cache_data_clear()!
            

            
            
            fail((_K==="en" ? "The balance on the captcha service has ended - ERROR_ZERO_BALANCE" : "Закончился баланс на сервисе распознавания капчи - ERROR_ZERO_BALANCE"));
            

         })!
         

         
         
         _set_if_expression("W1tDQVBUQ0hBX0ZBSUxdXSA9PSAx");
         _if(VAR_CAPTCHA_FAIL == 1,function(){
         
            
            
            /*Browser*/
            cache_data_clear()!
            

            
            
            fail((_K==="en" ? "Failed to complete the request to the captcha recognition server, error - CAPTCHA_FAIL" : "Не удалось выполнить запрос к серверу распознавания капчи, ошибка - CAPTCHA_FAIL"));
            

         })!
         

         
         
         _do(function(){
         _set_action_info({ name: "For" });
         VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
         if(VAR_CYCLE_INDEX > parseInt(120))_break();
         
            
            
            /*Browser*/
            ;_SELECTOR="\u003eCSS\u003e img.captcha_verify_img_slide.react-draggable";
            get_element_selector(_SELECTOR, false).nowait().exist()!
            VAR_IS_EXISTS = _result() == 1
            

            
            
            _set_if_expression("W1tJU19FWElTVFNdXQ==");
            _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
            
               
               
               VAR_CAPTCHA_MODULE_TYPE = "pazl"
               

               
               
               _break("function")
               

            })!
            

            
            
            /*Browser*/
            ;_SELECTOR=" \u003eCSS\u003e #verify-points";
            get_element_selector(_SELECTOR, false).nowait().exist()!
            VAR_IS_EXISTS = _result() == 1
            

            
            
            _set_if_expression("W1tJU19FWElTVFNdXQ==");
            _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
            
               
               
               VAR_CAPTCHA_MODULE_TYPE = "abc1"
               

               
               
               _break("function")
               

            })!
            

            
            
            /*Browser*/
            ;_SELECTOR=" \u003eXPATH\u003e //*[@id=\u0022captcha_container\u0022]//img[2][@draggable=\u0022false\u0022]";
            get_element_selector(_SELECTOR, false).nowait().exist()!
            VAR_IS_EXISTS = _result() == 1
            _if(VAR_IS_EXISTS, function(){
            get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
            VAR_IS_EXISTS = _result().indexOf("true")>=0
            })!
            

            
            
            _set_if_expression("W1tJU19FWElTVFNdXQ==");
            _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
            
               
               
               VAR_CAPTCHA_MODULE_TYPE = "koleso"
               

               
               
               _break("function")
               

            })!
            

            
            
            /*Browser*/
            ;_SELECTOR=" \u003eCSS\u003e #tiktok-verify-ele";
            get_element_selector(_SELECTOR, false).nowait().exist()!
            VAR_IS_EXISTS = _result() == 1
            _if(VAR_IS_EXISTS, function(){
            get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
            VAR_IS_EXISTS = _result().indexOf("true")>=0
            })!
            

            
            
            _set_if_expression("W1tJU19FWElTVFNdXQ==");
            _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
            
               
               
               VAR_CAPTCHA_MODULE_TYPE = "koleso"
               

               
               
               _break("function")
               

            })!
            

            
            
            _set_if_expression("W1tJU19FWElTVFNdXSA9PSBmYWxzZSAmJiBbW0ZJUlNUX0xPQURfQ0FQVENIQV1dID09IGZhbHNl");
            _if(VAR_IS_EXISTS == false && VAR_FIRST_LOAD_CAPTCHA == false,function(){
            
               
               
               /*Browser*/
               cache_data_clear()!
               

               
               
               VAR_GREEN_TICK = true
               

               
               
               _break("function")
               

            })!
            

            
            
            /*Browser*/
            ;_SELECTOR=" \u003eCSS\u003e .captcha_verify_message";
            get_element_selector(_SELECTOR, false).nowait().exist()!
            VAR_IS_EXISTS = _result() == 1
            _if(VAR_IS_EXISTS, function(){
            get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
            VAR_IS_EXISTS = _result().indexOf("true")>=0
            })!
            

            
            
            _set_if_expression("W1tJU19FWElTVFNdXSA9PSB0cnVl");
            _if(VAR_IS_EXISTS == true,function(){
            
               
               
               sleep(rand(100,500))!
               

               
               
               _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gODU=");
               _if(VAR_CYCLE_INDEX > 85,function(){
               
                  
                  
                  /*Browser*/
                  cache_data_clear()!
                  

                  
                  
                  fail((_K==="en" ? "Failed to solve the captcha. The captcha too many try check solve." : "Решить капчу не удалось. Много попыток проверить верификацию капчи."));
                  

               })!
               

               
               
               _next("function")
               

            })!
            

            
            
            /*Browser*/
            ;_SELECTOR=" \u003eCSS\u003e .captcha_verify_message-pass";
            get_element_selector(_SELECTOR, false).nowait().exist()!
            VAR_IS_EXISTS = _result() == 1
            _if(VAR_IS_EXISTS, function(){
            get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
            VAR_IS_EXISTS = _result().indexOf("true")>=0
            })!
            

            
            
            _set_if_expression("W1tJU19FWElTVFNdXSA9PSB0cnVl");
            _if(VAR_IS_EXISTS == true,function(){
            
               
               
               /*Browser*/
               cache_data_clear()!
               

               
               
               VAR_GREEN_TICK = true
               

               
               
               _break("function")
               

            })!
            

            
            
            _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gODU=");
            _if(VAR_CYCLE_INDEX > 85,function(){
            
               
               
               /*Browser*/
               cache_data_clear()!
               

               
               
               fail((_K==="en" ? "Failed to solve the captcha. The captcha window is closed or this captcha type is unknown." : "Решить капчу не удалось. Окно с капчей не было открыто, либо это неизвестный тип капчи."));
               

            })!
            

            
            
            sleep(rand(100,300))!
            

         })!
         

         
         
         VAR_CYCLE_INDEX = 0
         

         
         
         _set_if_expression("W1tHUkVFTl9USUNLXV0gPT0gdHJ1ZQ==");
         _if(VAR_GREEN_TICK == true,function(){
         
            
            
            /*Browser*/
            cache_data_clear()!
            

            
            
            _function_return("")
            

         })!
         

         
         
         VAR_TRY_CAPTCHA = parseInt(VAR_TRY_CAPTCHA) + parseInt(1)
         

         
         
         _set_if_expression("W1tUUllfQ0FQVENIQV1dID4gW1tUUllfTUFYX0NBUFRDSEFfUElDVFVSRV1d");
         _if(VAR_TRY_CAPTCHA > VAR_TRY_MAX_CAPTCHA_PICTURE,function(){
         
            
            
            fail((_K==="en" ? "Failed to solve the captcha. TikTok attempts limit exceeded" : "Решить капчу не удалось. Превышен лимит попыток решить TikTok капчу"));
            

         })!
         

         
         
         _call(function()
         {
         _on_fail(function(){
         VAR_LAST_ERROR = _result()
         VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
         VAR_WAS_ERROR = false
         _break(1,true)
         })
         CYCLES.Current().RemoveLabel("function")
         
            
            
            _set_if_expression("W1tJU19NT0JJTEVdXSA9PSAw");
            _if(VAR_IS_MOBILE == 0,function(){
            
               
               
               _get_browser_screen_settings()!
               ;(function(){
               var result = JSON.parse(_result())
               VAR_SCROLL_X = result["ScrollX"]
               VAR_SCROLL_Y = result["ScrollY"]
               VAR_CURSOR_X = result["CursorX"]
               VAR_CURSOR_Y = result["CursorY"]
               VAR_BROWSER_WIDTH = result["Width"]
               VAR_BROWSER_HEIGHT = result["Height"]
               })();
               

               
               
               _set_if_expression("W1tDQVBUQ0hBX01PRFVMRV9UWVBFXV0gPT0gImFiYzEi");
               _if(VAR_CAPTCHA_MODULE_TYPE == "abc1",function(){
               
                  
                  
                  /*Browser*/
                  ;_SELECTOR=" \u003eCSS\u003e #verify-points";
                  get_element_selector(_SELECTOR, false).nowait().exist()!
                  VAR_IS_EXISTS = _result() == 1
                  

                  
                  
                  _set_if_expression("IVtbSVNfRVhJU1RTXV0=");
                  _if(!VAR_IS_EXISTS,function(){
                  
                     
                     
                     _next("function")
                     

                  })!
                  

                  
                  
                  /*Browser*/
                  _SELECTOR = " \u003eCSS\u003e .captcha_verify_container";
                  wait_element_visible(_SELECTOR)!
                  _call(_random_point, {})!
                  _if(_result().length > 0, function(){
                  move( {} )!
                  get_element_selector(_SELECTOR, false).clarify(X,Y)!
                  _call(_clarify, {} )!
                  })!
                  

               })!
               

               
               
               _set_if_expression("W1tDQVBUQ0hBX01PRFVMRV9UWVBFXV0gPT0gImtvbGVzbyI=");
               _if(VAR_CAPTCHA_MODULE_TYPE == "koleso",function(){
               
                  
                  
                  /*Browser*/
                  ;_SELECTOR=" \u003eCSS\u003e .captcha_verify_container";
                  get_element_selector(_SELECTOR, false).nowait().exist()!
                  VAR_IS_EXISTS = _result() == 1
                  _if(VAR_IS_EXISTS, function(){
                  get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
                  VAR_IS_EXISTS = _result().indexOf("true")>=0
                  })!
                  

                  
                  
                  _set_if_expression("IVtbSVNfRVhJU1RTXV0=");
                  _if(!VAR_IS_EXISTS,function(){
                  
                     
                     
                     _next("function")
                     

                  })!
                  

                  
                  
                  _set_if_expression("W1tGSVJTVF9MT0FEX0NBUFRDSEFdXSA9PSB0cnVl");
                  _if(VAR_FIRST_LOAD_CAPTCHA == true,function(){
                  
                     
                     
                     /*Browser*/
                     _SELECTOR = " \u003eCSS\u003e .captcha_verify_container";
                     wait_element_visible(_SELECTOR)!
                     _call(_random_point, {})!
                     _if(_result().length > 0, function(){
                     move( {} )!
                     get_element_selector(_SELECTOR, false).clarify(X,Y)!
                     _call(_clarify, {} )!
                     })!
                     

                  })!
                  

               })!
               

               
               
               _set_if_expression("W1tDQVBUQ0hBX01PRFVMRV9UWVBFXV0gPT0gInBhemwi");
               _if(VAR_CAPTCHA_MODULE_TYPE == "pazl",function(){
               
                  
                  
                  /*Browser*/
                  ;_SELECTOR="\u003eCSS\u003e img.captcha_verify_img_slide.react-draggable";
                  get_element_selector(_SELECTOR, false).nowait().exist()!
                  VAR_IS_EXISTS = _result() == 1
                  _if(VAR_IS_EXISTS, function(){
                  get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
                  VAR_IS_EXISTS = _result().indexOf("true")>=0
                  })!
                  

                  
                  
                  _set_if_expression("IVtbSVNfRVhJU1RTXV0=");
                  _if(!VAR_IS_EXISTS,function(){
                  
                     
                     
                     _next("function")
                     

                  })!
                  

                  
                  
                  _set_if_expression("W1tGSVJTVF9MT0FEX0NBUFRDSEFdXSA9PSB0cnVl");
                  _if(VAR_FIRST_LOAD_CAPTCHA == true,function(){
                  
                     
                     
                     /*Browser*/
                     _SELECTOR = " \u003eCSS\u003e .captcha_verify_container";
                     wait_element_visible(_SELECTOR)!
                     _call(_random_point, {})!
                     _if(_result().length > 0, function(){
                     move( {} )!
                     get_element_selector(_SELECTOR, false).clarify(X,Y)!
                     _call(_clarify, {} )!
                     })!
                     

                  })!
                  

               })!
               

            })!
            

         },null)!
         

         
         
         _set_if_expression("W1tXQVNfRVJST1JdXQ==");
         _if(typeof(VAR_WAS_ERROR) !== "undefined" ? (VAR_WAS_ERROR) : undefined,function(){
         
            
            
            /*Browser*/
            cache_data_clear()!
            

            
            
            fail(VAR_LAST_ERROR)
            

         })!
         

         
         
         _call(function()
         {
         _on_fail(function(){
         VAR_LAST_ERROR = _result()
         VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
         VAR_WAS_ERROR = false
         _break(1,true)
         })
         CYCLES.Current().RemoveLabel("function")
         
            
            
            _set_if_expression("W1tDQVBUQ0hBX01PRFVMRV9UWVBFXV0gPT0gImFiYzEi");
            _if(VAR_CAPTCHA_MODULE_TYPE == "abc1",function(){
            
               
               
               VAR_CYCLE_INDEX = "0"
               

               
               
               _do(function(){
               _set_action_info({ name: "For" });
               VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
               if(VAR_CYCLE_INDEX > parseInt(100))_break();
               
                  
                  
                  /*Browser*/
                  ;_SELECTOR=" \u003eCSS\u003e #verify-points";
                  get_element_selector(_SELECTOR, false).nowait().exist()!
                  VAR_IS_EXISTS = _result() == 1
                  

                  
                  
                  _set_if_expression("IVtbSVNfRVhJU1RTXV0=");
                  _if(!VAR_IS_EXISTS,function(){
                  
                     
                     
                     sleep(1000)!
                     

                     
                     
                     _long_goto("Tiktok Captcha Start here", 5, [])!
                     

                  })!
                  

                  
                  
                  /*Browser*/
                  ;_SELECTOR=" \u003eCSS\u003e .captcha_verify_message";
                  get_element_selector(_SELECTOR, false).nowait().exist()!
                  VAR_IS_EXISTS = _result() == 1
                  _if(VAR_IS_EXISTS, function(){
                  get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
                  VAR_IS_EXISTS = _result().indexOf("true")>=0
                  })!
                  

                  
                  
                  _set_if_expression("W1tJU19FWElTVFNdXSA9PSB0cnVl");
                  _if(VAR_IS_EXISTS == true,function(){
                  
                     
                     
                     sleep(2000)!
                     

                     
                     
                     _long_goto("Tiktok Captcha Start here", 5, [])!
                     

                  })!
                  

                  
                  
                  cache_get_base64("*captcha*")!
                  var image_id = native("imageprocessing", "load", _result())
                  var image_size = native("imageprocessing", "getsize", image_id)
                  var image_w = parseInt(image_size.split(",")[0])
                  var image_h = parseInt(image_size.split(",")[1])
                  if (image_h == 0 && VAR_CYCLE_INDEX > rand (75,95)) fail((_K === "en" ? "Failed to wait for TikTok image from request cache" : "Не удалось дождаться картинку TikTok капчи из кэша запроса"))
                  if (image_h > 150) {
                  VAR_IMAGE_BASE_64 = _result()
                  _break()
                  }
                  sleep(200)!
                  

               })!
               

               
               
               VAR_SET_TASK = "geetest|abc1"
               

               
               
               _get_browser_screen_settings()!
               ;(function(){
               var result = JSON.parse(_result())
               VAR_SCROLL_X = result["ScrollX"]
               VAR_SCROLL_Y = result["ScrollY"]
               VAR_CURSOR_X = result["CursorX"]
               VAR_CURSOR_Y = result["CursorY"]
               VAR_BROWSER_WIDTH = result["Width"]
               VAR_BROWSER_HEIGHT = result["Height"]
               })();
               

               
               
               _set_if_expression("W1tHRVRfQUxMX0NPT1JESU5BVEVTXV0gPT0gMCB8fCBbW0lTX0NIQU5HRURfU0NST0xMX1ldXSAhPSBbW1NDUk9MTF9ZXV0=");
               _if(VAR_GET_ALL_COORDINATES == 0 || VAR_IS_CHANGED_SCROLL_Y != VAR_SCROLL_Y,function(){
               
                  
                  
                  VAR_IS_CHANGED_SCROLL_Y = VAR_SCROLL_Y
                  

                  
                  
                  VAR_ELEMENT_SELECTOR = " \u003eCSS\u003e #captcha-verify-image"
                  

                  
                  
                  _SELECTOR = VAR_ELEMENT_SELECTOR;
                  get_element_selector(_SELECTOR, false).script("(function(){var rect = self.getBoundingClientRect();return (rect.left + positionx).toString() + '|' + (rect.top + positiony).toString() + '|' + (rect.right - rect.left).toString() + '|' + (rect.bottom - rect.top).toString()})();")!
                  var split = _result().split("|");
                  var x = parseInt(split[0]), y = parseInt(split[1]), w = parseInt(split[2]), h = parseInt(split[3]);
                  /// Первый квадрат
                  VAR_SQUARE_BUTTON_X = parseInt(x)
                  VAR_SQUARE_BUTTON_Y = parseInt(y) + VAR_SCROLL_Y;
                  VAR_SQUARE_WIDTH = parseInt(w)
                  VAR_SQUARE_HEIGHT = parseInt(h)
                  

                  
                  
                  VAR_GET_ALL_COORDINATES = "1"
                  

               })!
               

               
               
               VAR_IMAGE_BASE_64 = native("imageprocessing", "load", VAR_IMAGE_BASE_64)
               

               
               
               native("imageprocessing", "resize", (VAR_IMAGE_BASE_64) + "," + (VAR_SQUARE_WIDTH) + "," + (VAR_SQUARE_HEIGHT))
               

               
               
               VAR_IMAGE_BASE_64 = native("imageprocessing", "getdata", VAR_IMAGE_BASE_64)
               

               
               
               native("imageprocessing", "delete", VAR_IMAGE_BASE_64)
               

            })!
            

            
            
            _set_if_expression("W1tDQVBUQ0hBX01PRFVMRV9UWVBFXV0gPT0gImtvbGVzbyI=");
            _if(VAR_CAPTCHA_MODULE_TYPE == "koleso",function(){
            
               
               
               VAR_CYCLE_INDEX = "0"
               

               
               
               _do(function(){
               _set_action_info({ name: "For" });
               VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
               if(VAR_CYCLE_INDEX > parseInt(100))_break();
               
                  
                  
                  /*Browser*/
                  ;_SELECTOR=" \u003eCSS\u003e .captcha_verify_container";
                  get_element_selector(_SELECTOR, false).nowait().exist()!
                  VAR_IS_EXISTS = _result() == 1
                  _if(VAR_IS_EXISTS, function(){
                  get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
                  VAR_IS_EXISTS = _result().indexOf("true")>=0
                  })!
                  

                  
                  
                  _set_if_expression("IVtbSVNfRVhJU1RTXV0=");
                  _if(!VAR_IS_EXISTS,function(){
                  
                     
                     
                     sleep(1000)!
                     

                     
                     
                     _long_goto("Tiktok Captcha Start here", 5, [])!
                     

                  })!
                  

                  
                  
                  /*Browser*/
                  ;_SELECTOR=" \u003eCSS\u003e .captcha_verify_message";
                  get_element_selector(_SELECTOR, false).nowait().exist()!
                  VAR_IS_EXISTS = _result() == 1
                  _if(VAR_IS_EXISTS, function(){
                  get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
                  VAR_IS_EXISTS = _result().indexOf("true")>=0
                  })!
                  

                  
                  
                  _set_if_expression("W1tJU19FWElTVFNdXSA9PSB0cnVl");
                  _if(VAR_IS_EXISTS == true,function(){
                  
                     
                     
                     sleep(2000)!
                     

                     
                     
                     _long_goto("Tiktok Captcha Start here", 5, [])!
                     

                  })!
                  

                  
                  
                  cache_get_base64("*ibyteimg.com*")!
                  var image_id = native("imageprocessing", "load", _result())
                  var image_size = native("imageprocessing", "getsize", image_id)
                  var image_w = parseInt(image_size.split(",")[0])
                  var image_h = parseInt(image_size.split(",")[1])
                  if (image_h == 0 && VAR_CYCLE_INDEX > rand (75,95)) fail((_K === "en" ? "Failed to wait for TikTok image from request cache" : "Не удалось дождаться картинку TikTok капчи из кэша запроса"))
                  if (image_h > 50) {
                  VAR_IMAGE_BASE_64 = _result()
                  _break()
                  }
                  sleep(200)!
                  

               })!
               

               
               
               VAR_SET_TASK = "koleso"
               

               
               
               /*Browser*/
               ;_SELECTOR=" \u003eCSS\u003e #tiktok-verify-ele";
               get_element_selector(_SELECTOR, false).nowait().exist()!
               VAR_IS_EXISTS = _result() == 1
               _if(VAR_IS_EXISTS, function(){
               get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
               VAR_IS_EXISTS = _result().indexOf("true")>=0
               })!
               

               
               
               _set_if_expression("W1tJU19FWElTVFNdXQ==");
               _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
               
                  
                  
                  _SELECTOR = " \u003eCSS\u003e .captcha_verify_container";
                  wait_element(_SELECTOR)!
                  get_element_selector(_SELECTOR, false).script2("var list1=[];\r\nvar imgs = document.querySelectorAll('#tiktok-verify-ele img')\r\nfor(var ke in imgs){\r\n//console.log(typeof imgs[ke])\r\n\tif(typeof imgs[ke] === 'object'){\r\n\t\tvar img = imgs[ke].getAttribute(\"src\")\r\n\t\tif(img !== undefined){\r\n\t\t\tlist1.push(btoa(img))\r\n\t\t}\r\n\t}\r\n}\r\n[[IMG1_MODULE]] = list1[0];\r\n[[IMG2_MODULE]] = list1[1];",JSON.stringify(_read_variables(["VAR_IMG1_MODULE","VAR_IMG2_MODULE"])))!
                  var _parse_result = JSON.parse(_result())
                  _write_variables(JSON.parse(_parse_result.variables))
                  if(!_parse_result.is_success)
                  fail(_parse_result.error)
                  

               })!
               

               
               
               /*Browser*/
               ;_SELECTOR=" \u003eCSS\u003e #captcha_container";
               get_element_selector(_SELECTOR, false).nowait().exist()!
               VAR_IS_EXISTS = _result() == 1
               _if(VAR_IS_EXISTS, function(){
               get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
               VAR_IS_EXISTS = _result().indexOf("true")>=0
               })!
               

               
               
               _set_if_expression("W1tJU19FWElTVFNdXQ==");
               _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
               
                  
                  
                  _SELECTOR = " \u003eCSS\u003e .captcha_verify_container";
                  wait_element(_SELECTOR)!
                  get_element_selector(_SELECTOR, false).script2("var list1=[];\r\nvar imgs = document.querySelectorAll('#captcha_container img')\r\nfor(var ke in imgs){\r\n//console.log(typeof imgs[ke])\r\n\tif(typeof imgs[ke] === 'object'){\r\n\t\tvar img = imgs[ke].getAttribute(\"src\")\r\n\t\tif(img !== undefined){\r\n\t\t\tlist1.push(btoa(img))\r\n\t\t}\r\n\t}\r\n}\r\n[[IMG1_MODULE]] = list1[0];\r\n[[IMG2_MODULE]] = list1[1];",JSON.stringify(_read_variables(["VAR_IMG1_MODULE","VAR_IMG2_MODULE"])))!
                  var _parse_result = JSON.parse(_result())
                  _write_variables(JSON.parse(_parse_result.variables))
                  if(!_parse_result.is_success)
                  fail(_parse_result.error)
                  

               })!
               

            })!
            

            
            
            _set_if_expression("W1tDQVBUQ0hBX01PRFVMRV9UWVBFXV0gPT0gInBhemwi");
            _if(VAR_CAPTCHA_MODULE_TYPE == "pazl",function(){
            
               
               
               VAR_CYCLE_INDEX = "0"
               

               
               
               _do(function(){
               _set_action_info({ name: "For" });
               VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
               if(VAR_CYCLE_INDEX > parseInt(100))_break();
               
                  
                  
                  /*Browser*/
                  ;_SELECTOR="\u003eCSS\u003e img.captcha_verify_img_slide.react-draggable";
                  get_element_selector(_SELECTOR, false).nowait().exist()!
                  VAR_IS_EXISTS = _result() == 1
                  _if(VAR_IS_EXISTS, function(){
                  get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
                  VAR_IS_EXISTS = _result().indexOf("true")>=0
                  })!
                  

                  
                  
                  _set_if_expression("IVtbSVNfRVhJU1RTXV0=");
                  _if(!VAR_IS_EXISTS,function(){
                  
                     
                     
                     sleep(1000)!
                     

                     
                     
                     _long_goto("Tiktok Captcha Start here", 5, [])!
                     

                  })!
                  

                  
                  
                  /*Browser*/
                  ;_SELECTOR=" \u003eCSS\u003e .captcha_verify_message";
                  get_element_selector(_SELECTOR, false).nowait().exist()!
                  VAR_IS_EXISTS = _result() == 1
                  _if(VAR_IS_EXISTS, function(){
                  get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
                  VAR_IS_EXISTS = _result().indexOf("true")>=0
                  })!
                  

                  
                  
                  _set_if_expression("W1tJU19FWElTVFNdXSA9PSB0cnVl");
                  _if(VAR_IS_EXISTS == true,function(){
                  
                     
                     
                     sleep(2000)!
                     

                     
                     
                     _long_goto("Tiktok Captcha Start here", 5, [])!
                     

                  })!
                  

                  
                  
                  cache_get_base64("*ibyteimg.com*")!
                  var image_id = native("imageprocessing", "load", _result())
                  var image_size = native("imageprocessing", "getsize", image_id)
                  var image_w = parseInt(image_size.split(",")[0])
                  var image_h = parseInt(image_size.split(",")[1])
                  if (image_h == 0 && VAR_CYCLE_INDEX > rand (75,95)) fail((_K === "en" ? "Failed to wait for TikTok image from request cache" : "Не удалось дождаться картинку TikTok капчи из кэша запроса"))
                  if (image_h > 50) {
                  VAR_IMAGE_BASE_64 = _result()
                  _break()
                  }
                  sleep(200)!
                  

               })!
               

               
               
               VAR_SET_TASK = "slider"
               

               
               
               _get_browser_screen_settings()!
               ;(function(){
               var result = JSON.parse(_result())
               VAR_SCROLL_X = result["ScrollX"]
               VAR_SCROLL_Y = result["ScrollY"]
               VAR_CURSOR_X = result["CursorX"]
               VAR_CURSOR_Y = result["CursorY"]
               VAR_BROWSER_WIDTH = result["Width"]
               VAR_BROWSER_HEIGHT = result["Height"]
               })();
               

               
               
               _set_if_expression("W1tTQ1JPTExfWV1dICE9IDA=");
               _if(VAR_SCROLL_Y != 0,function(){
               
                  
                  
                  /*Browser*/
                  _scroll_to(0)!
                  

               })!
               

               
               
               /*Browser*/
               _SELECTOR = " \u003eCSS\u003e #captcha-verify-image";
               wait_element(_SELECTOR)!
               get_element_selector(_SELECTOR, false).exist()!
               _if(_result() == "1", function(){
               get_element_selector(_SELECTOR, false).render_base64()!
               VAR_IMAGE_BASE_64 = _result()
               })!
               

            })!
            

            
            
            sleep(200)!
            

         },null)!
         

         
         
         _set_if_expression("W1tXQVNfRVJST1JdXQ==");
         _if(typeof(VAR_WAS_ERROR) !== "undefined" ? (VAR_WAS_ERROR) : undefined,function(){
         
            
            
            _call(function()
            {
            _on_fail(function(){
            VAR_LAST_ERROR = _result()
            VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
            VAR_WAS_ERROR = false
            _break(1,true)
            })
            CYCLES.Current().RemoveLabel("function")
            
               
               
               /*Browser*/
               ;_SELECTOR="\u003eCSS\u003e span[class*=\u0027captcha_refresh--text\u0027]";
               get_element_selector(_SELECTOR, false).nowait().exist()!
               VAR_IS_EXISTS = _result() == 1
               _if(VAR_IS_EXISTS, function(){
               get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
               VAR_IS_EXISTS = _result().indexOf("true")>=0
               })!
               

               
               
               _set_if_expression("W1tJU19FWElTVFNdXQ==");
               _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
               
                  
                  
                  /*Browser*/
                  _SELECTOR = "\u003eCSS\u003e span[class*=\u0027captcha_refresh--text\u0027]";
                  wait_element_visible(_SELECTOR)!
                  _call(_random_point, {})!
                  _if(_result().length > 0, function(){
                  move( {"speed": VAR_SPEED,"gravity": VAR_GRAVITY,"deviation": VAR_DEVIATION} )!
                  get_element_selector(_SELECTOR, false).clarify(X,Y)!
                  _call(_clarify, {"speed": VAR_SPEED,"gravity": VAR_GRAVITY,"deviation": VAR_DEVIATION} )!
                  mouse(X,Y)!
                  })!
                  

               })!
               

            },null)!
            

            
            
            _next("function")
            

         })!
         

         
         
         VAR_FIRST_LOAD_CAPTCHA = false
         

         
         
         _call(function()
         {
         _on_fail(function(){
         VAR_LAST_ERROR = _result()
         VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
         VAR_WAS_ERROR = false
         _break(1,true)
         })
         CYCLES.Current().RemoveLabel("function")
         
            
            
            _do(function(){
            _set_action_info({ name: "For" });
            VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
            if(VAR_CYCLE_INDEX > parseInt(4))_break();
            
               
               
               ///Чистим
               solver_properties_clear("capmonster")
               /// Формирумем основной запрос
               solver_property("capmonster","serverurl","https://api.captcha.guru/")
               solver_property("capmonster","coordinatescaptcha","1")
               solver_property("capmonster","key",VAR_KEY_MODULE)
               solver_property("capmonster","textinstructions",VAR_SET_TASK)
               solver_property("capmonster","click","geetest")
               solver_property("capmonster","method","post")
               if (VAR_CAPTCHA_MODULE_TYPE == "koleso")
               {
               solver_property("capmonster","body1",VAR_IMG1_MODULE)
               solver_property("capmonster","body2",VAR_IMG2_MODULE)
               }
               //// Отправляем
               solve_base64_no_fail("capmonster", VAR_IMAGE_BASE_64)!
               VAR_SAVED_CONTENT = _result();
               

               
               
               _set_if_expression("W1tTQVZFRF9DT05URU5UXV0uaW5kZXhPZigiRVJST1JfQ0FQVENIQV9VTlNPTFZBQkxFIikgPj0gMA==");
               _if(VAR_SAVED_CONTENT.indexOf("ERROR_CAPTCHA_UNSOLVABLE") >= 0,function(){
               
                  
                  
                  /*Browser*/
                  ;_SELECTOR="\u003eCSS\u003e span[class*=\u0027captcha_refresh--text\u0027]";
                  get_element_selector(_SELECTOR, false).nowait().exist()!
                  VAR_IS_EXISTS = _result() == 1
                  _if(VAR_IS_EXISTS, function(){
                  get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
                  VAR_IS_EXISTS = _result().indexOf("true")>=0
                  })!
                  

                  
                  
                  _set_if_expression("W1tJU19FWElTVFNdXQ==");
                  _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
                  
                     
                     
                     /*Browser*/
                     _SELECTOR = "\u003eCSS\u003e span[class*=\u0027captcha_refresh--text\u0027]";
                     wait_element_visible(_SELECTOR)!
                     _call(_random_point, {})!
                     _if(_result().length > 0, function(){
                     move( {"speed": VAR_SPEED,"gravity": VAR_GRAVITY,"deviation": VAR_DEVIATION} )!
                     get_element_selector(_SELECTOR, false).clarify(X,Y)!
                     _call(_clarify, {"speed": VAR_SPEED,"gravity": VAR_GRAVITY,"deviation": VAR_DEVIATION} )!
                     mouse(X,Y)!
                     })!
                     

                  })!
                  

                  
                  
                  sleep(rand(1000,3000))!
                  

                  
                  
                  _break("function")
                  

               })!
               

               
               
               _set_if_expression("W1tTQVZFRF9DT05URU5UXV0uaW5kZXhPZigiRVJST1JfV1JPTkdfVVNFUl9LRVkiKSA+PSAw");
               _if(VAR_SAVED_CONTENT.indexOf("ERROR_WRONG_USER_KEY") >= 0,function(){
               
                  
                  
                  VAR_ERROR_KEY = "1"
                  

                  
                  
                  _break("function")
                  

               })!
               

               
               
               _set_if_expression("W1tTQVZFRF9DT05URU5UXV0uaW5kZXhPZigiRVJST1JfWkVST19CQUxBTkNFIikgPj0gMA==");
               _if(VAR_SAVED_CONTENT.indexOf("ERROR_ZERO_BALANCE") >= 0,function(){
               
                  
                  
                  VAR_ERROR_BALANCE = "1"
                  

                  
                  
                  _break("function")
                  

               })!
               

               
               
               _set_if_expression("W1tTQVZFRF9DT05URU5UXV0uaW5kZXhPZigiQ0FQVENIQV9GQUlMIikgPj0gMA==");
               _if(VAR_SAVED_CONTENT.indexOf("CAPTCHA_FAIL") >= 0,function(){
               
                  
                  
                  VAR_CAPTCHA_FAIL = "1"
                  

                  
                  
                  _break("function")
                  

               })!
               

               
               
               _cycle_params().if_else = VAR_SAVED_CONTENT.match(/[0-9]/);
               _set_if_expression("W1tTQVZFRF9DT05URU5UXV0ubWF0Y2goL1swLTldLyk=");
               _if(_cycle_params().if_else,function(){
               
                  
                  
                  _set_if_expression("W1tDQVBUQ0hBX01PRFVMRV9UWVBFXV0gPT0gImtvbGVzbyI=");
                  _if(VAR_CAPTCHA_MODULE_TYPE == "koleso",function(){
                  
                     
                     
                     /*Browser*/
                     ;_SELECTOR=" \u003eCSS\u003e .secsdk-captcha-drag-icon";
                     get_element_selector(_SELECTOR, false).nowait().exist()!
                     VAR_IS_EXISTS = _result() == 1
                     

                     
                     
                     _cycle_params().if_else = typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined;
                     _set_if_expression("W1tJU19FWElTVFNdXQ==");
                     _if(_cycle_params().if_else,function(){
                     
                        
                        
                        /*Browser*/
                        _SELECTOR = " \u003eCSS\u003e .secsdk-captcha-drag-icon";
                        wait_element(_SELECTOR)!
                        get_element_selector(_SELECTOR, false).script("(function(){var rect = self.getBoundingClientRect();return (rect.left + positionx).toString() + '|' + (rect.top + positiony).toString() + '|' + (rect.right - rect.left).toString() + '|' + (rect.bottom - rect.top).toString()})();")!
                        if(_result().length > 0)
                        {
                        var split = _result().split("|")
                        VAR_X = parseInt(split[0])
                        VAR_Y = parseInt(split[1])
                        VAR_WIDTH = parseInt(split[2])
                        VAR_HEIGHT = parseInt(split[3])
                        }
                        

                     })!
                     

                     
                     
                     _if(!_cycle_params().if_else,function(){
                     
                        
                        
                        _break("function")
                        

                     })!
                     delete _cycle_params().if_else;
                     

                     
                     
                     var dd = VAR_SAVED_CONTENT;
                     var num_slide = dd.replace(/[^0-9,]/g,"").split(",")
                     VAR_X2 = parseInt(num_slide[1]);
                     VAR_XBUTON = (VAR_X + (VAR_HEIGHT/2))
                     VAR_YBUTON = (VAR_Y + (VAR_WIDTH/2))
                     

                     
                     
                     /*Browser*/
                     move(VAR_XBUTON,VAR_YBUTON,  {} )!
                     mouse_down(VAR_XBUTON,VAR_YBUTON)!
                     

                     
                     
                     /*Browser*/
                     var move_settings =  {} ;
                     move_settings["do_mouse_up"] = "true"
                     move(VAR_X+VAR_X2+20,VAR_Y, move_settings)!
                     

                  })!
                  

                  
                  
                  _set_if_expression("W1tDQVBUQ0hBX01PRFVMRV9UWVBFXV0gPT0gImFiYzEi");
                  _if(VAR_CAPTCHA_MODULE_TYPE == "abc1",function(){
                  
                     
                     
                     VAR_LISTS_COORDINATES = VAR_SAVED_CONTENT
                     VAR_LISTS_COORDINATES = VAR_LISTS_COORDINATES.split("coordinates:")[1];
                     VAR_LISTS_COORDINATES = VAR_LISTS_COORDINATES.split(";");
                     

                     
                     
                     ;(function (a) {var j, x, i;for (i = a.length; i; i--) {j = Math.floor(Math.random() * i);x = a[i - 1]; a[i - 1] = a[j];a[j] = x;}})(VAR_LISTS_COORDINATES)
                     

                     
                     
                     _do_with_params({"foreach_data":(VAR_LISTS_COORDINATES)},function(){
                     _set_action_info({ name: "Foreach" });
                     VAR_CYCLE_INDEX = _iterator() - 1
                     if(VAR_CYCLE_INDEX > _cycle_param("foreach_data").length - 1)_break();
                     VAR_FOREACH_DATA = _cycle_param("foreach_data")[VAR_CYCLE_INDEX]
                     
                        
                        
                        var csv_parse_result = csv_parse(VAR_FOREACH_DATA)
                        VAR_ANSWER_X = csv_parse_result[0]
                        if(typeof(VAR_ANSWER_X) == 'undefined' || !VAR_ANSWER_X)
                        {
                        VAR_ANSWER_X = ""
                        }
                        VAR_ANSWER_Y = csv_parse_result[1]
                        if(typeof(VAR_ANSWER_Y) == 'undefined' || !VAR_ANSWER_Y)
                        {
                        VAR_ANSWER_Y = ""
                        }
                        

                        
                        
                        VAR_ANSWER_X = VAR_ANSWER_X.replace(/[^0-9]/g, '');
                        VAR_ANSWER_Y = VAR_ANSWER_Y.replace(/[^0-9]/g, '');
                        VAR_ANSWER_X = parseInt(VAR_ANSWER_X)
                        VAR_ANSWER_Y = parseInt(VAR_ANSWER_Y)
                        

                        
                        
                        /*Browser*/
                        move(VAR_SQUARE_BUTTON_X + VAR_ANSWER_X,VAR_SQUARE_BUTTON_Y + VAR_ANSWER_Y,  {"speed": VAR_SPEED,"gravity": VAR_GRAVITY,"deviation": VAR_DEVIATION} )!
                        mouse(VAR_SQUARE_BUTTON_X + VAR_ANSWER_X,VAR_SQUARE_BUTTON_Y + VAR_ANSWER_Y)!
                        

                     })!
                     

                     
                     
                     /*Browser*/
                     _SELECTOR = " \u003eCSS\u003e .verify-captcha-submit-button";
                     wait_element_visible(_SELECTOR)!
                     _call(_random_point, {})!
                     _if(_result().length > 0, function(){
                     move( {} )!
                     get_element_selector(_SELECTOR, false).clarify(X,Y)!
                     _call(_clarify, {} )!
                     mouse(X,Y)!
                     })!
                     

                  })!
                  

                  
                  
                  _set_if_expression("W1tDQVBUQ0hBX01PRFVMRV9UWVBFXV0gPT0gInBhemwi");
                  _if(VAR_CAPTCHA_MODULE_TYPE == "pazl",function(){
                  
                     
                     
                     /*Browser*/
                     ;_SELECTOR=" \u003eCSS\u003e .secsdk-captcha-drag-icon";
                     get_element_selector(_SELECTOR, false).nowait().exist()!
                     VAR_IS_EXISTS = _result() == 1
                     

                     
                     
                     _cycle_params().if_else = typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined;
                     _set_if_expression("W1tJU19FWElTVFNdXQ==");
                     _if(_cycle_params().if_else,function(){
                     
                        
                        
                        /*Browser*/
                        _SELECTOR = " \u003eCSS\u003e .secsdk-captcha-drag-icon";
                        wait_element(_SELECTOR)!
                        get_element_selector(_SELECTOR, false).script("(function(){var rect = self.getBoundingClientRect();return (rect.left + positionx).toString() + '|' + (rect.top + positiony).toString() + '|' + (rect.right - rect.left).toString() + '|' + (rect.bottom - rect.top).toString()})();")!
                        if(_result().length > 0)
                        {
                        var split = _result().split("|")
                        VAR_X = parseInt(split[0])
                        VAR_Y = parseInt(split[1])
                        VAR_WIDTH = parseInt(split[2])
                        VAR_HEIGHT = parseInt(split[3])
                        }
                        

                     })!
                     

                     
                     
                     _if(!_cycle_params().if_else,function(){
                     
                        
                        
                        _break("function")
                        

                     })!
                     delete _cycle_params().if_else;
                     

                     
                     
                     var dd = VAR_SAVED_CONTENT;
                     var num_slide = dd.replace(/[;]+/g,",").replace(/[^0-9,]/g,"").split(",")
                     VAR_X2 = parseInt(num_slide[0]);
                     VAR_XBUTON = (VAR_X + (VAR_HEIGHT/2))
                     VAR_YBUTON = (VAR_Y + (VAR_WIDTH/2))
                     

                     
                     
                     /*Browser*/
                     move(VAR_XBUTON,VAR_YBUTON,  {"speed": 100,"gravity": 6,"deviation": 2.5} )!
                     mouse_down(VAR_XBUTON,VAR_YBUTON)!
                     

                     
                     
                     /*Browser*/
                     var move_settings =  {"speed": 100,"gravity": 6,"deviation": 2.5} ;
                     move_settings["do_mouse_up"] = "true"
                     move(VAR_X+VAR_X2+(VAR_WIDTH/4),VAR_Y, move_settings)!
                     

                  })!
                  

                  
                  
                  sleep(800)!
                  

                  
                  
                  _break("function")
                  

               })!
               

               
               
               _if(!_cycle_params().if_else,function(){
               
                  
                  
                  sleep(1000)!
                  

                  
                  
                  _next("function")
                  

               })!
               delete _cycle_params().if_else;
               

            })!
            

            
            
            _next("function")
            

         },null)!
         

         
         
         _set_if_expression("W1tXQVNfRVJST1JdXQ==");
         _if(typeof(VAR_WAS_ERROR) !== "undefined" ? (VAR_WAS_ERROR) : undefined,function(){
         
            
            
            sleep(1000)!
            

            
            
            _next("function")
            

         })!
         

      })!
      

   }
   

function CaptchaImageClick_FunCaptcha()
   {
   
      
      
      VAR_GLOBAL_SELECTOR = _function_argument("SELECTOR")
      

      
      
      VAR_SPEED_MOUSE = _function_argument("SPEED_MOUSE")
      

      
      
      VAR_KEY_MODULE = _function_argument("KEY")
      

      
      
      VAR_METHOD_MODULE = _function_argument("METHOD")
      

      
      
      VAR_TRY_MAX_CAPTCHA_PICTURE = _function_argument("TRY_MAX_CAPTCHA_PICTURE")
      

      
      
      VAR_NUMBER_CAPTCHA_MODULE = _function_argument("NUMBER_CAPTCHA")
      

      
      
      VAR_URL_MODULE = _function_argument("URL")
      

      
      
      VAR_ERROR_LOAD = "0"
      

      
      
      VAR_CACHE_ERROR = "0"
      

      
      
      VAR_ERROR_SOLVE = "0"
      

      
      
      VAR_ERROR_TASK = "0"
      

      
      
      VAR_ERROR_FIND_MAIN_SELECTOR = "0"
      

      
      
      VAR_XEVIL_NOT_SUPPORT_TASK = 0
      

      
      
      VAR_FUNCAPTCHA_PREFIX_SECOND_FRAME = ""
      

      
      
      VAR_RECAPTCHA_MODULE_ENABLED = 0
      

      
      
      VAR_HCAPTCHA_MODULE_ENABLED = 0
      

      
      
      VAR_FUNCATPCHA_MODULE_ENABLED = 0
      

      
      
      VAR_NAME_MODULE_AUTOSUBMIT = "NaN"
      

      
      
      //// Проверить установлены ли модули с автосабмитом.
      if (typeof NumbersParseRecaptcha2 === 'function') VAR_RECAPTCHA_MODULE_ENABLED = 1, VAR_NAME_MODULE_AUTOSUBMIT = "ReCaptcha 2 Autosubmit";
      if (typeof BASCaptchaSolver.helpers.HCaptchaHelper === 'function') VAR_HCAPTCHA_MODULE_ENABLED = 1, VAR_NAME_MODULE_AUTOSUBMIT = "hCaptcha Autosubmit";
      if (typeof BASCaptchaSolver.helpers.FunCaptchaHelper === 'function') VAR_FUNCAPTCHA_MODULE_ENABLED = 1, VAR_NAME_MODULE_AUTOSUBMIT = "FunCaptcha Autosubmit";
      

      
      
      _set_if_expression("W1tGVU5DQVRQQ0hBX01PRFVMRV9FTkFCTEVEXV0gPT0gMSB8fCBbW1JFQ0FQVENIQV9NT0RVTEVfRU5BQkxFRF1dID09IDEgfHwgW1tIQ0FQVENIQV9NT0RVTEVfRU5BQkxFRF1dID09IDE=");
      _if(VAR_FUNCATPCHA_MODULE_ENABLED == 1 || VAR_RECAPTCHA_MODULE_ENABLED == 1 || VAR_HCAPTCHA_MODULE_ENABLED == 1,function(){
      
         
         
         fail((_K==="en" ? "Solve the captcha failed, to continue solving captchas by clicks requires to disable module " +VAR_NAME_MODULE_AUTOSUBMIT + " and retry solving captcha by clicks" : "Решить капчу не удалось, для продолжения решения капчи кликами требуется отключить сторонний встроенный модуль в BAS: " +VAR_NAME_MODULE_AUTOSUBMIT + " и повторить попытку"));
         

      })!
      

      
      
      VAR_GREEN_TICK = false
      

      
      
      _call(function()
      {
      _on_fail(function(){
      VAR_LAST_ERROR = _result()
      VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
      VAR_WAS_ERROR = false
      _break(1,true)
      })
      CYCLES.Current().RemoveLabel("function")
      
         
         
         /*Browser*/
         waiter_timeout_next(45000)
         wait_load("*/rtig/image*")!
         

         
         
         sleep(rand(100,500))!
         

         
         
         /*Browser*/
         wait_load("*/fc/gfc*")!
         cache_get_string("*/fc/gfc*")!
         VAR_SAVED_CACHE = _result()
         

         
         
         _cycle_params().if_else = VAR_SAVED_CACHE != '';
         _set_if_expression("W1tTQVZFRF9DQUNIRV1dICE9ICcn");
         _if(_cycle_params().if_else,function(){
         
            
            
            var regexp_result = native("regexp", "first", JSON.stringify({text: VAR_SAVED_CACHE,regexp:"\u005c\u0022[0-9]\u005c.\u005cinstructions-[A-z0-9_-]*"}))
            if(regexp_result.length == 0)
            regexp_result = []
            else
            regexp_result = JSON.parse(regexp_result)
            VAR_ALL_MATCH = regexp_result.pop()
            if(typeof(VAR_ALL_MATCH) == 'undefined' || !VAR_ALL_MATCH)
            VAR_ALL_MATCH = ""
            VAR_SET_TASK = regexp_result[0]
            if(typeof(VAR_SET_TASK) == 'undefined' || !VAR_SET_TASK)
            VAR_SET_TASK = ""
            VAR_SET_TASK1 = regexp_result[1]
            if(typeof(VAR_SET_TASK1) == 'undefined' || !VAR_SET_TASK1)
            VAR_SET_TASK1 = ""
            VAR_SET_TASK2 = regexp_result[2]
            if(typeof(VAR_SET_TASK2) == 'undefined' || !VAR_SET_TASK2)
            VAR_SET_TASK2 = ""
            if(regexp_result.length == 0)
            {
            VAR_SET_TASK = VAR_ALL_MATCH
            }
            

            
            
            VAR_SHORT_TASK_FIRST = native("regexp", "replace", JSON.stringify({text: VAR_SET_TASK,regexp:"\u005c\u0022[0-9]\u005c.\u005cinstructions-",replace:""}))
            

            
            
            VAR_SHORT_TASK = native("regexp", "replace", JSON.stringify({text: VAR_SHORT_TASK_FIRST,regexp:"[_-]icon$",replace:""}))
            

            
            
            VAR_SET_TASK = native("regexp", "replace", JSON.stringify({text: VAR_SET_TASK,regexp:"\u0022",replace:""}))
			
			VAR_SET_TASK_XEVIL = VAR_SET_TASK.replace('"',"")
			VAR_SET_TASK_XEVIL = VAR_SAVED_CACHE.split(VAR_SET_TASK_XEVIL)[1].split('"')[2].replace(".", "")
            

            
            
            VAR_SAVED_CACHE = JSON.parse(VAR_SAVED_CACHE);
            VAR_CURRENT_TASK_NUMBERS = VAR_SAVED_CACHE.game_data.waves;
            

         })!
         

         
         
         _if(!_cycle_params().if_else,function(){
         
            
            
            VAR_CACHE_ERROR = "1"
            

         })!
         delete _cycle_params().if_else;
         

      },null)!
      

      
      
      _set_if_expression("W1tXQVNfRVJST1JdXQ==");
      _if(typeof(VAR_WAS_ERROR) !== "undefined" ? (VAR_WAS_ERROR) : undefined,function(){
      
         
         
         fail(VAR_LAST_ERROR)
         

      })!
      

      
      
      _call(function()
      {
      _on_fail(function(){
      VAR_LAST_ERROR = _result()
      VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
      VAR_WAS_ERROR = false
      _break(1,true)
      })
      CYCLES.Current().RemoveLabel("function")
      
         
         
         if (VAR_SPEED_MOUSE == "Slow")
         {
         VAR_SPEED = 100;
         VAR_GRAVITY = 6;
         VAR_DEVIATION = 2.5;
         }
         if (VAR_SPEED_MOUSE == "Normal")
         {
         VAR_SPEED = 200;
         VAR_GRAVITY = 12;
         VAR_DEVIATION = 5;
         }
         if (VAR_SPEED_MOUSE == "Fast")
         {
         VAR_SPEED = 300;
         VAR_GRAVITY = 18;
         VAR_DEVIATION = 7.5;
         }
         if (VAR_SPEED_MOUSE == "Very Fast")
         {
         VAR_SPEED = 400;
         VAR_GRAVITY = 24;
         VAR_DEVIATION = 10;
         }
         if (VAR_SPEED_MOUSE == "Extremal")
         {
         VAR_SPEED = 500;
         VAR_GRAVITY = 30;
         VAR_DEVIATION = 12.5;
         }
         

         
         
         page().script2("[[IS_MOBILE]] = navigator.maxTouchPoints;",JSON.stringify(_read_variables(["VAR_IS_MOBILE"])))!
         var _parse_result = JSON.parse(_result())
         _write_variables(JSON.parse(_parse_result.variables))
         if(!_parse_result.is_success)
         fail(_parse_result.error)
         

         
         
         _set_if_expression("W1tJU19NT0JJTEVdXSA9PSAwICYmIHJhbmQgKDEsMTApID4gNQ==");
         _if(VAR_IS_MOBILE == 0 && rand (1,10) > 5,function(){
         
            
            
            _do(function(){
            _set_action_info({ name: "While" });
            VAR_CYCLE_INDEX = _iterator() - 1
            BREAK_CONDITION = VAR_CYCLE_INDEX < 2 && VAR_IS_MOBILE == 0;
            if(!BREAK_CONDITION)_break();
            
               
               
               _get_browser_screen_settings()!
               ;(function(){
               var result = JSON.parse(_result())
               VAR_SCROLL_X = result["ScrollX"]
               VAR_SCROLL_Y = result["ScrollY"]
               VAR_CURSOR_X = result["CursorX"]
               VAR_CURSOR_Y = result["CursorY"]
               VAR_BROWSER_WIDTH = result["Width"]
               VAR_BROWSER_HEIGHT = result["Height"]
               })();
               

               
               
               var scroll_x=parseInt(VAR_CURSOR_Y);
               var scroll_y=parseInt(VAR_SCROLL_Y);
               var browser_h=parseInt(VAR_BROWSER_HEIGHT);
               //-------------------- Привели все в числа, считаем позицию ---------------------
               var absolut_y = VAR_CURSOR_Y + VAR_SCROLL_Y;
               var y_without_scroll = absolut_y - VAR_SCROLL_Y;
               var check_y_top = VAR_BROWSER_HEIGHT/12;
               var check_y_down = VAR_BROWSER_HEIGHT/100*92;
               var move_y_top = VAR_BROWSER_HEIGHT/10;
               var move_y_down = VAR_BROWSER_HEIGHT/100*80;
               // -------------------------- Округляем ----------------------------------
               VAR_CHECK_Y_TOP = check_y_top.toFixed();
               VAR_CHECK_Y_DOWN = check_y_down.toFixed();
               VAR_Y_WITHOUNT_SCROLL = y_without_scroll.toFixed();
               VAR_MOVE_Y_TOP = move_y_top.toFixed();
               VAR_MOVE_Y_DOWN = move_y_down.toFixed();
               // ----------------- Снова приводим к числу ------------------------
               VAR_CHECK_Y_TOP=parseInt(VAR_CHECK_Y_TOP);
               VAR_CHECK_Y_DOWN=parseInt(VAR_CHECK_Y_DOWN);
               VAR_Y_WITHOUNT_SCROLL=parseInt(VAR_Y_WITHOUNT_SCROLL);
               VAR_MOVE_Y_TOP=parseInt(VAR_MOVE_Y_TOP);
               VAR_MOVE_Y_DOWN=parseInt(VAR_MOVE_Y_DOWN);
               

               
               
               /*Browser*/
               move(rand(VAR_BROWSER_WIDTH/5,VAR_BROWSER_WIDTH/1.3),rand(VAR_MOVE_Y_TOP + VAR_SCROLL_Y,VAR_MOVE_Y_DOWN + VAR_SCROLL_Y),  {} )!
               

               
               
               _set_if_expression("cmFuZCAoMSwxMCkgPiA1");
               _if(rand (1,10) > 5,function(){
               
                  
                  
                  _break("function")
                  

               })!
               

            })!
            

         })!
         

         
         
         VAR_FUNCAPTCHA_PREFIX = VAR_GLOBAL_SELECTOR;
         VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME = VAR_FUNCAPTCHA_PREFIX;
         {
         var index = VAR_FUNCAPTCHA_PREFIX.toString().lastIndexOf(">FRAME>")
         if(index >= 0)
         VAR_FUNCAPTCHA_PREFIX = VAR_FUNCAPTCHA_PREFIX.substring(0,index)
         VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME = VAR_FUNCAPTCHA_PREFIX
         index = VAR_FUNCAPTCHA_PREFIX.toString().lastIndexOf(">FRAME>")
         if(index >= 0)
         VAR_FUNCAPTCHA_PREFIX = VAR_FUNCAPTCHA_PREFIX.substring(0,index + ">FRAME>".length)
         else
         VAR_FUNCAPTCHA_PREFIX = ""
         index = VAR_FUNCAPTCHA_PREFIX.toString().lastIndexOf(">FRAME>")
         if(index >= 0)
         VAR_FUNCAPTCHA_PREFIX = VAR_FUNCAPTCHA_PREFIX.substring(0,index + ">FRAME>".length)
         else
         VAR_FUNCAPTCHA_PREFIX = ""
         }
         

         
         
         _set_if_expression("W1tGVU5DQVBUQ0hBX1BSRUZJWF9TRUNPTkRfRlJBTUVdXSA9PSAiIg==");
         _if(VAR_FUNCAPTCHA_PREFIX_SECOND_FRAME == "",function(){
         
            
            
            _do(function(){
            _set_action_info({ name: "For" });
            VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
            if(VAR_CYCLE_INDEX > parseInt(40))_break();
            
               
               
               /*Browser*/
               ;_SELECTOR=VAR_GLOBAL_SELECTOR;
               get_element_selector(_SELECTOR, false).nowait().exist()!
               VAR_IS_EXISTS = _result() == 1
               _if(VAR_IS_EXISTS, function(){
               get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
               VAR_IS_EXISTS = _result().indexOf("true")>=0
               })!
               

               
               
               _cycle_params().if_else = typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined;
               _set_if_expression("W1tJU19FWElTVFNdXQ==");
               _if(_cycle_params().if_else,function(){
               
                  
                  
                  /*Browser*/
                  _SELECTOR = VAR_GLOBAL_SELECTOR;waiter_timeout_next(8000)
                  wait_element_visible(_SELECTOR)!
                  _call(_random_point, {})!
                  _if(_result().length > 0, function(){
                  move( {} )!
                  get_element_selector(_SELECTOR, false).clarify(X,Y)!
                  _call(_clarify, {} )!
                  mouse(X,Y)!
                  })!
                  

                  
                  
                  /*Browser*/
                  wait_load("*rtig/image*")!
                  

                  
                  
                  _break("function")
                  

               })!
               

               
               
               _if(!_cycle_params().if_else,function(){
               
                  
                  
                  sleep(rand(100,500))!
                  

               })!
               delete _cycle_params().if_else;
               

               
               
               _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gcmFuZCAoMjAsMjUp");
               _if(VAR_CYCLE_INDEX > rand (20,25),function(){
               
                  
                  
                  VAR_ERROR_FIND_MAIN_SELECTOR = "1"
                  

               })!
               

            })!
            

         })!
         

      },null)!
      

      
      
      _set_if_expression("W1tDQUNIRV9FUlJPUl1dID09IDE=");
      _if(VAR_CACHE_ERROR == 1,function(){
      
         
         
         fail((_K==="en" ? "Warning! Before load FunCaptcha you need allow cache by mask *rtig/image* and */fc/gfc*" : "Внимание! Перед решением FunCaptcha необходимо разрешить кэш по маске *rtig/image* и */fc/gfc*"));
         

      })!
      

      
      
      _set_if_expression("W1tDVVJSRU5UX1RBU0tfTlVNQkVSU11dID4gW1tUUllfTUFYX0NBUFRDSEFfUElDVFVSRV1d");
      _if(VAR_CURRENT_TASK_NUMBERS > VAR_TRY_MAX_CAPTCHA_PICTURE,function(){
      
         
         
         fail((_K==="en" ? "The capctha could not be resolved. The maximum number of jobs has been exceeded. Check the quality of the browser and proxy." : "Не удалось решить капчу. Превышен лимит на максимальное число заданий. Проверьте качество браузера и прокси."));
         

      })!
      

      
      
      _set_if_expression("W1tFUlJPUl9GSU5EX01BSU5fU0VMRUNUT1JdXSA9PSAx");
      _if(VAR_ERROR_FIND_MAIN_SELECTOR == 1,function(){
      
         
         
         /*Browser*/
         cache_data_clear()!
         

         
         
         fail((_K==="en" ? "Failed to wait for main captcha selector to load" : "Не удалось дождатся загрузки основного селектора капчи"));
         

      })!
      

      
      
      VAR_TRY_CAPTCHA = "0"
      

      
      
      VAR_BAS_CAPMONSTER_IMAGE_ID = "0"
      

      
      
      VAR_CAPTCHA_FAIL = "0"
      

      
      
      VAR_ERROR_KEY = "0"
      

      
      
      VAR_ERROR_BALANCE = "0"
      

      
      
      VAR_ERROR_LANG = "0"
      

      
      
      VAR_GET_ALL_COORDINATES = "0"
      

      
      
      VAR_FIRST_LOAD_CAPTCHA = true
      

      
      
      _do(function(){
      _set_action_info({ name: "For" });
      VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
      if(VAR_CYCLE_INDEX > parseInt(500))_break();
      
         
         
         VAR_CYCLE_INDEX = 0
         

         
         
         _set_if_expression("W1tFUlJPUl9LRVldXSA9PSAx");
         _if(VAR_ERROR_KEY == 1,function(){
         
            
            
            /*Browser*/
            cache_data_clear()!
            

            
            
            fail((_K==="en" ? "API secret key from captcha recognition service is wrong ERROR_WRONG_USER_KEY" : "Секретный ключ API от сервиса распознавания капчи неправильный ERROR_WRONG_USER_KEY"));
            

         })!
         

         
         
         _set_if_expression("W1tFUlJPUl9CQUxBTkNFXV0gPT0gMQ==");
         _if(VAR_ERROR_BALANCE == 1,function(){
         
            
            
            /*Browser*/
            cache_data_clear()!
            

            
            
            fail((_K==="en" ? "The balance on the captcha service has ended - ERROR_ZERO_BALANCE" : "Закончился баланс на сервисе распознавания капчи - ERROR_ZERO_BALANCE"));
            

         })!
         

         
         
         _set_if_expression("W1tFUlJPUl9UQVNLXV0gPiAx");
         _if(VAR_ERROR_TASK > 1,function(){
         
            
            
            /*Browser*/
            cache_data_clear()!
            

            
            
            fail((_K==="en" ? "This Funcaptcha task or picture type is not supported service " +VAR_METHOD_MODULE + ": " +VAR_SHORT_TASK : "Не удалось решить капчу, " +VAR_METHOD_MODULE + " не смог распознать это изображение с таким заданием: " +VAR_SHORT_TASK));
            

         })!
         

         
         
         _set_if_expression("W1tDQVBUQ0hBX0ZBSUxdXSA9PSAx");
         _if(VAR_CAPTCHA_FAIL == 1,function(){
         
            
            
            /*Browser*/
            cache_data_clear()!
            

            
            
            fail((_K==="en" ? "Failed to complete the request to the captcha recognition server, error - CAPTCHA_FAIL" : "Не удалось выполнить запрос к серверу распознавания капчи, ошибка - CAPTCHA_FAIL"));
            

         })!
         

         
         
         _do(function(){
         _set_action_info({ name: "For" });
         VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
         if(VAR_CYCLE_INDEX > parseInt(120))_break();
         
            
            
            /*Browser*/
            ;_SELECTOR=VAR_FUNCAPTCHA_PREFIX + "\u003eCSS\u003e #verifyButton";
            get_element_selector(_SELECTOR, false).nowait().exist()!
            VAR_IS_EXISTS = _result() == 1
            

            
            
            _set_if_expression("W1tJU19FWElTVFNdXQ==");
            _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
            
               
               
               /*Browser*/
               _SELECTOR = VAR_FUNCAPTCHA_PREFIX + "\u003eCSS\u003e #verifyButton";
               wait_element_visible(_SELECTOR)!
               _call(_random_point, {})!
               _if(_result().length > 0, function(){
               move( {} )!
               get_element_selector(_SELECTOR, false).clarify(X,Y)!
               _call(_clarify, {} )!
               mouse(X,Y)!
               })!
               

               
               
               sleep(rand(500,1000))!
               

               
               
               /*Browser*/
               wait_load("*rtig/image*")!
               

            })!
            

            
            
            /*Browser*/
            ;_SELECTOR=VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e #wrong_children_exclamation";
            get_element_selector(_SELECTOR, false).nowait().exist()!
            VAR_IS_EXISTS = _result() == 1
            _if(VAR_IS_EXISTS, function(){
            get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
            VAR_IS_EXISTS = _result().indexOf("true")>=0
            })!
            

            
            
            _set_if_expression("W1tJU19FWElTVFNdXSA9PSB0cnVl");
            _if(VAR_IS_EXISTS == true,function(){
            
               
               
               VAR_ERROR_SOLVE = "1"
               

               
               
               _break("function")
               

            })!
            

            
            
            /*Browser*/
            ;_SELECTOR=VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e #game_challengeItem";
            get_element_selector(_SELECTOR, false).nowait().exist()!
            VAR_IS_EXISTS = _result() == 1
            _if(VAR_IS_EXISTS, function(){
            get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
            VAR_IS_EXISTS = _result().indexOf("true")>=0
            })!
            

            
            
            _set_if_expression("W1tJU19FWElTVFNdXSA9PSB0cnVl");
            _if(VAR_IS_EXISTS == true,function(){
            
               
               
               _break("function")
               

            })!
            

            
            
            _set_if_expression("W1tJU19FWElTVFNdXSA9PSBmYWxzZSAmJiBbW0ZJUlNUX0xPQURfQ0FQVENIQV1dID09IGZhbHNl");
            _if(VAR_IS_EXISTS == false && VAR_FIRST_LOAD_CAPTCHA == false,function(){
            
               
               
               /*Browser*/
               cache_data_clear()!
               

               
               
               VAR_GREEN_TICK = true
               

               
               
               _break("function")
               

            })!
            

            
            
            _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gNDAgJiYgW1tGSVJTVF9MT0FEX0NBUFRDSEFdXSA9PSB0cnVl");
            _if(VAR_CYCLE_INDEX > 40 && VAR_FIRST_LOAD_CAPTCHA == true,function(){
            
               
               
               /*Browser*/
               cache_data_clear()!
               

               
               
               fail((_K==="en" ? "Failed to load captcha image window, internet connection too slow" : "Не удалось загрузить окно с картинками капчи, слишком медленное интернет соединение"));
               

            })!
            

            
            
            _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gNjAgJiYgW1tGSVJTVF9MT0FEX0NBUFRDSEFdXSA9PSBmYWxzZQ==");
            _if(VAR_CYCLE_INDEX > 60 && VAR_FIRST_LOAD_CAPTCHA == false,function(){
            
               
               
               /*Browser*/
               cache_data_clear()!
               

               
               
               fail((_K==="en" ? "Failed to solve the captcha. The captcha window is closed." : "Решить капчу не удалось. Окно с капчей не было открыто."));
               

            })!
            

            
            
            sleep(100)!
            

         })!
         

         
         
         VAR_CYCLE_INDEX = 0
         

         
         
         _set_if_expression("W1tHUkVFTl9USUNLXV0gPT0gdHJ1ZQ==");
         _if(VAR_GREEN_TICK == true,function(){
         
            
            
            /*Browser*/
            cache_data_clear()!
            

            
            
            _function_return("")
            

         })!
         

         
         
         _set_if_expression("W1tFUlJPUl9TT0xWRV1dID09IDE=");
         _if(VAR_ERROR_SOLVE == 1,function(){
         
            
            
            /*Browser*/
            cache_data_clear()!
            

            
            
            fail((_K==="en" ? "Сapcha solved incorrectly, error - ERROR_CAPTCHA_SOLVE" : "Капча решена неверно, ошибка  - ERROR_CAPTCHA_SOLVE"));
            

         })!
         

         
         
         VAR_TRY_CAPTCHA = parseInt(VAR_TRY_CAPTCHA) + parseInt(1)
         

         
         
         _set_if_expression("W1tUUllfQ0FQVENIQV1dID4gMjM=");
         _if(VAR_TRY_CAPTCHA > 23,function(){
         
            
            
            fail((_K==="en" ? "Failed to solve the captcha. FunCaptcha attempts limit exceeded" : "Решить капчу не удалось. Превышен лимит попыток решить FunCaptha"));
            

         })!
         

         
         
         _call(function()
         {
         _on_fail(function(){
         VAR_LAST_ERROR = _result()
         VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
         VAR_WAS_ERROR = false
         _break(1,true)
         })
         CYCLES.Current().RemoveLabel("function")
         
            
            
            _set_if_expression("W1tJU19NT0JJTEVdXSA9PSAwICYmIHJhbmQgKDEsMTApID4gNQ==");
            _if(VAR_IS_MOBILE == 0 && rand (1,10) > 5,function(){
            
               
               
               _get_browser_screen_settings()!
               ;(function(){
               var result = JSON.parse(_result())
               VAR_SCROLL_X = result["ScrollX"]
               VAR_SCROLL_Y = result["ScrollY"]
               VAR_CURSOR_X = result["CursorX"]
               VAR_CURSOR_Y = result["CursorY"]
               VAR_BROWSER_WIDTH = result["Width"]
               VAR_BROWSER_HEIGHT = result["Height"]
               })();
               

               
               
               /*Browser*/
               ;_SELECTOR=VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e #game_challengeItem";
               get_element_selector(_SELECTOR, false).nowait().exist()!
               VAR_IS_EXISTS = _result() == 1
               

               
               
               _set_if_expression("IVtbSVNfRVhJU1RTXV0=");
               _if(!VAR_IS_EXISTS,function(){
               
                  
                  
                  _next("function")
                  

               })!
               

               
               
               /*Browser*/
               _SELECTOR = VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e #game_challengeItem";
               wait_element(_SELECTOR)!
               get_element_selector(_SELECTOR, false).script("(function(){var rect = self.getBoundingClientRect();return (rect.left + positionx).toString() + '|' + (rect.top + positiony).toString() + '|' + (rect.right - rect.left).toString() + '|' + (rect.bottom - rect.top).toString()})();")!
               if(_result().length > 0)
               {
               var split = _result().split("|")
               VAR_X = parseInt(split[0])
               VAR_Y = parseInt(split[1])
               VAR_CAPTCHA_WIDTH = parseInt(split[2])
               VAR_CAPTCHA_HEIGHT = parseInt(split[3])
               }
               

               
               
               /*Browser*/
               move(rand(VAR_X/100*115,(VAR_X+VAR_CAPTCHA_WIDTH)/100*93).toFixed(),rand(VAR_Y + VAR_SCROLL_Y/100*120,VAR_Y + VAR_SCROLL_Y + VAR_CAPTCHA_HEIGHT/100*90).toFixed(),  {} )!
               

            })!
            

         },null)!
         

         
         
         _call(function()
         {
         _on_fail(function(){
         VAR_LAST_ERROR = _result()
         VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
         VAR_WAS_ERROR = false
         _break(1,true)
         })
         CYCLES.Current().RemoveLabel("function")
         
            
            
            _get_browser_screen_settings()!
            ;(function(){
            var result = JSON.parse(_result())
            VAR_SCROLL_X = result["ScrollX"]
            VAR_SCROLL_Y = result["ScrollY"]
            VAR_CURSOR_X = result["CursorX"]
            VAR_CURSOR_Y = result["CursorY"]
            VAR_BROWSER_WIDTH = result["Width"]
            VAR_BROWSER_HEIGHT = result["Height"]
            })();
            

            
            
            _set_if_expression("W1tHRVRfQUxMX0NPT1JESU5BVEVTXV0gPT0gMCB8fCBbW0lTX0NIQU5HRURfU0NST0xMX1ldXSAhPSBbW1NDUk9MTF9ZXV0=");
            _if(VAR_GET_ALL_COORDINATES == 0 || VAR_IS_CHANGED_SCROLL_Y != VAR_SCROLL_Y,function(){
            
               
               
               VAR_IS_CHANGED_SCROLL_Y = VAR_SCROLL_Y
               

               
               
               VAR_ELEMENT_SELECTOR = VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e #image1 \u003e a"
               

               
               
               _SELECTOR = VAR_ELEMENT_SELECTOR;
               get_element_selector(_SELECTOR, false).script("(function(){var rect = self.getBoundingClientRect();return (rect.left + positionx).toString() + '|' + (rect.top + positiony).toString() + '|' + (rect.right - rect.left).toString() + '|' + (rect.bottom - rect.top).toString()})();")!
               var split = _result().split("|");
               var x = parseInt(split[0]), y = parseInt(split[1]), w = parseInt(split[2]), h = parseInt(split[3]);
               /// Первый квадрат
               VAR_SQUARE_BUTTON_X = parseInt(x)
               VAR_SQUARE_BUTTON_Y = parseInt(y) + VAR_SCROLL_Y;
               VAR_SQUARE_WIDTH = parseInt(w)
               VAR_SQUARE_HEIGHT = parseInt(h)
               /// Первый квадрат для Xevil
               VAR_FIRST_PIC_X = parseInt(x) + parseInt(w)/2 ;
               VAR_FIRST_PIC_Y = parseInt(y)+ parseInt(h)/2;
               // Второй и т.д.
               VAR_SECOND_PIC_X = VAR_FIRST_PIC_X + w;
               VAR_SECOND_PIC_Y = VAR_FIRST_PIC_Y;
               VAR_THIRD_PIC_X = VAR_SECOND_PIC_X + w;
               VAR_THIRD_PIC_Y = VAR_FIRST_PIC_Y;
               VAR_FOUR_PIC_X = VAR_FIRST_PIC_X
               VAR_FOUR_PIC_Y = VAR_FIRST_PIC_Y + h;
               VAR_FIVE_PIC_X = VAR_SECOND_PIC_X
               VAR_FIVE_PIC_Y = VAR_SECOND_PIC_Y + h;
               VAR_SIX_PIC_X = VAR_THIRD_PIC_X;
               VAR_SIX_PIC_Y = VAR_THIRD_PIC_Y + h;
               

               
               
               VAR_GET_ALL_COORDINATES = "1"
               

            })!
            

         },null)!
         

         
         
         _set_if_expression("W1tXQVNfRVJST1JdXQ==");
         _if(typeof(VAR_WAS_ERROR) !== "undefined" ? (VAR_WAS_ERROR) : undefined,function(){
         
            
            
            /*Browser*/
            cache_data_clear()!
            

            
            
            fail(VAR_LAST_ERROR)
            

         })!
         

         
         
         _call(function()
         {
         _on_fail(function(){
         VAR_LAST_ERROR = _result()
         VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
         VAR_WAS_ERROR = false
         _break(1,true)
         })
         CYCLES.Current().RemoveLabel("function")
         
            
            
            /*Browser*/
            ;_SELECTOR=VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e #game_challengeItem";
            get_element_selector(_SELECTOR, false).nowait().exist()!
            VAR_IS_EXISTS = _result() == 1
            _if(VAR_IS_EXISTS, function(){
            get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
            VAR_IS_EXISTS = _result().indexOf("true")>=0
            })!
            

            
            
            _set_if_expression("W1tJU19FWElTVFNdXSA9PSBmYWxzZQ==");
            _if(VAR_IS_EXISTS == false,function(){
            
               
               
               _next("function")
               

            })!
            

            
            
            /*Browser*/
            _SELECTOR = VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e #game_challengeItem_image";waiter_timeout_next(20000)
            wait_element(_SELECTOR)!
            

            
            
            sleep(200)!
            

            
            
            /*Browser*/
            _SELECTOR = VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e #game_challengeItem_image";
            wait_element(_SELECTOR)!
            get_element_selector(_SELECTOR, false).attr("src")!
            VAR_SAVED_ATTRIBUTE = _result()
            

            
            
            _set_if_expression("W1tTQVZFRF9BVFRSSUJVVEVdXS5pbmRleE9mKCJkYXRhOmltYWdlL2dpZjtiYXNlNjQiKSA+PSAw");
            _if(VAR_SAVED_ATTRIBUTE.indexOf("data:image/gif;base64") >= 0,function(){
            
               
               
               var replace_string_funcap = "data:image/gif;base64,"
               VAR_IMAGE_BASE_64 = VAR_SAVED_ATTRIBUTE.replace(replace_string_funcap, "")
               

               
               
               VAR_LOADED_IMAGE_ID = native("imageprocessing", "load", VAR_IMAGE_BASE_64)
               

               
               
               var split = native("imageprocessing", "convert", (VAR_LOADED_IMAGE_ID) + "," + ("jpeg"))
               

               
               
               native("imageprocessing", "delete", VAR_LOADED_IMAGE_ID)
               

            })!
            

            
            
            _set_if_expression("W1tTQVZFRF9BVFRSSUJVVEVdXS5pbmRleE9mKCJkYXRhOmltYWdlL2pwZWc7YmFzZTY0IikgPj0gMA==");
            _if(VAR_SAVED_ATTRIBUTE.indexOf("data:image/jpeg;base64") >= 0,function(){
            
               
               
               var replace_string_funcap = "data:image/jpeg;base64,"
               VAR_IMAGE_BASE_64 = VAR_SAVED_ATTRIBUTE.replace(replace_string_funcap, "")
               

            })!
            

            
            
            VAR_THREAD_INDEX = thread_number()
            

            
            
            _set_if_expression("W1tUSFJFQURfSU5ERVhdXSA+IDk5OQ==");
            _if(VAR_THREAD_INDEX > 999,function(){
            
               
               
               native("filesystem", "writefile", JSON.stringify({path: "C:\u005cImages\u005c" + VAR_SET_TASK + "_" + VAR_THREAD_INDEX + ".jpeg",value: (VAR_IMAGE_BASE_64).toString(),base64:true,append:false}))
               

            })!
            

         },null)!
         

         
         
         _set_if_expression("W1tXQVNfRVJST1JdXQ==");
         _if(typeof(VAR_WAS_ERROR) !== "undefined" ? (VAR_WAS_ERROR) : undefined,function(){
         
            
            
            /*Browser*/
            cache_data_clear()!
            

            
            
            fail(VAR_LAST_ERROR)
            

         })!
         

         
         
         VAR_FIRST_LOAD_CAPTCHA = false
         

         
         
         _call(function()
         {
         _on_fail(function(){
         VAR_LAST_ERROR = _result()
         VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
         VAR_WAS_ERROR = false
         _break(1,true)
         })
         CYCLES.Current().RemoveLabel("function")
         
            
            
            _do(function(){
            _set_action_info({ name: "For" });
            VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
            if(VAR_CYCLE_INDEX > parseInt(3))_break();
            
               
               
               _set_if_expression("W1tNRVRIT0RfTU9EVUxFXV0gPT0gIkNhcHRjaGFHdXJ1Ig==");
               _if(VAR_METHOD_MODULE == "CaptchaGuru",function(){
               
                  
                  
                  ///Чистим
                  solver_properties_clear("capmonster")
                  /// Формирумем основной запрос
                  solver_property("capmonster","serverurl","https://api.captcha.guru/")
                  solver_property("capmonster","coordinatescaptcha","1")
                  solver_property("capmonster","key",VAR_KEY_MODULE)
                  solver_property("capmonster","textinstructions",VAR_SET_TASK)
                  solver_property("capmonster","click","funcap")
                  solver_property("capmonster","method","post")
                  //// Отправляем
                  solve_base64_no_fail("capmonster", VAR_IMAGE_BASE_64)!
                  VAR_SAVED_CONTENT = _result();
                  

               })!
               

               
               
               _set_if_expression("W1tNRVRIT0RfTU9EVUxFXV0gPT0gIlhldmlsIg==");
               _if(VAR_METHOD_MODULE == "Xevil",function(){
               
                  VAR_SHORT_TASK = "galaxy"
                  
                  if (VAR_SHORT_TASK == "square_icon_pair_similar") VAR_SHORT_TASK = "ident";
                  if (VAR_SHORT_TASK == "galaxy") VAR_SHORT_TASK = "spiral_galaxy";
                  //// Кубики
                  if (VAR_SHORT_TASK == "dice_pair") VAR_SHORT_TASK = "same_dice_pair";
                  if (VAR_SHORT_TASK == "dice_6_revised") VAR_SHORT_TASK = "dicesum6";
                  if (VAR_SHORT_TASK == "dice_7_revised") VAR_SHORT_TASK = "dicesum7";
                  if (VAR_SHORT_TASK == "dice_8_revised") VAR_SHORT_TASK = "dicesum8";
                  if (VAR_SHORT_TASK == "dice_14_revised") VAR_SHORT_TASK = "dicesum14";
                  /// Еще кубики
                  if (VAR_SHORT_TASK == "dice_slow_6_revised") VAR_SHORT_TASK = "dicesum6";
                  if (VAR_SHORT_TASK == "dice_slow_7_revised") VAR_SHORT_TASK = "dicesum7";
                  if (VAR_SHORT_TASK == "dice_slow_8_revised") VAR_SHORT_TASK = "dicesum8";
                  if (VAR_SHORT_TASK == "dice_slow_14_revised") VAR_SHORT_TASK = "dicesum14";
                  var all_xevil_support_task = ["newtask","ident","animal_look_standing","rotated","shadow_puppets","penguins","card","mouse_maze","dicesum6","dicesum7","dicesum8","dicesum14","same_dice_pair","card","spiral_galaxy","wrong_shadow","butterfly","parrot","dinosaur","pig","bee","monkey","snake","chicken","ladybug","bread","octopus","deer","cow","lobster","apple","seal","camel","bear","crab","cat","pig","pineapple","ant","parrot","owl","turtle","donut","rabbit","banana","snail","pizza","koala","duck","zebra","sheep","kangaroo","dog","ice_cream","starfish","dinosaur","elephant","shark","lion","grapes","giraffe","bat","frog","goat","mouse","dolphin","rhino"]
                  var tmp = all_xevil_support_task.length;
                  var support_task = 0;
                  while (--tmp) {
                  if (VAR_SHORT_TASK.toLowerCase().indexOf(all_xevil_support_task[tmp]) >= 0)
                  {
                  var support_task = 1
                  break;
                  }
                  }
                  VAR_XEVIL_NOT_SUPPORT_TASK = support_task;
                  

                  
                  
                  _set_if_expression("W1tYRVZJTF9OT1RfU1VQUE9SVF9UQVNLXV0gPT0gMA==");
                  _if(VAR_XEVIL_NOT_SUPPORT_TASK == 0,function(){
                  
                     
                     
                     VAR_ERROR_TASK = 2
                     

                     
                     
                     VAR_SAVED_CONTENT = "ERROR_CAPTCHA_UNSOLVABLE"
                     

                     
                     
                     _break("function")
                     

                  })!
                  

                  
                  
                  ///Чистим
                  solver_properties_clear("capmonster")
                  /// Формирумем основной запрос
                  solver_property("capmonster","serverurl",VAR_URL_MODULE)
                  solver_property("capmonster","key",VAR_KEY_MODULE)
                  solver_property("capmonster","imginstructions",VAR_SET_TASK_XEVIL)
                  solver_property("capmonster","method","post")
                  //// Отправляем
                  solve_base64_no_fail("capmonster", VAR_IMAGE_BASE_64)!
                  VAR_SAVED_CONTENT = _result();
                  

               })!
               

               
               
               _set_if_expression("W1tTQVZFRF9DT05URU5UXV0uaW5kZXhPZigiRVJST1JfQ0FQVENIQV9VTlNPTFZBQkxFIikgPj0gMA==");
               _if(VAR_SAVED_CONTENT.indexOf("ERROR_CAPTCHA_UNSOLVABLE") >= 0,function(){
               
                  
                  
                  VAR_ERROR_TASK = parseInt(VAR_ERROR_TASK) + parseInt(1)
                  

                  
                  
                  sleep(rand(2000,4000))!
                  

                  
                  
                  _break("function")
                  

               })!
               

               
               
               _set_if_expression("W1tTQVZFRF9DT05URU5UXV0uaW5kZXhPZigiRVJST1JfV1JPTkdfVVNFUl9LRVkiKSA+PSAw");
               _if(VAR_SAVED_CONTENT.indexOf("ERROR_WRONG_USER_KEY") >= 0,function(){
               
                  
                  
                  VAR_ERROR_KEY = "1"
                  

                  
                  
                  _break("function")
                  

               })!
               

               
               
               _set_if_expression("W1tTQVZFRF9DT05URU5UXV0uaW5kZXhPZigiRVJST1JfWkVST19CQUxBTkNFIikgPj0gMA==");
               _if(VAR_SAVED_CONTENT.indexOf("ERROR_ZERO_BALANCE") >= 0,function(){
               
                  
                  
                  VAR_ERROR_BALANCE = "1"
                  

                  
                  
                  _break("function")
                  

               })!
               

               
               
               _set_if_expression("W1tTQVZFRF9DT05URU5UXV0uaW5kZXhPZigiQ0FQVENIQV9GQUlMIikgPj0gMA==");
               _if(VAR_SAVED_CONTENT.indexOf("CAPTCHA_FAIL") >= 0,function(){
               
                  
                  
                  VAR_CAPTCHA_FAIL = "1"
                  

                  
                  
                  _break("function")
                  

               })!
               

               
               
               _cycle_params().if_else = VAR_SAVED_CONTENT.match(/[0-9]/);
               _set_if_expression("W1tTQVZFRF9DT05URU5UXV0ubWF0Y2goL1swLTldLyk=");
               _if(_cycle_params().if_else,function(){
               
                  
                  
                  _set_if_expression("W1tNRVRIT0RfTU9EVUxFXV0gPT0gIkNhcHRjaGFHdXJ1Ig==");
                  _if(VAR_METHOD_MODULE == "CaptchaGuru",function(){
                  
                     
                     
                     VAR_LISTS_COORDINATES = VAR_SAVED_CONTENT
                     VAR_LISTS_COORDINATES = VAR_LISTS_COORDINATES.split("coordinates:")[1];
                     VAR_LISTS_COORDINATES = VAR_LISTS_COORDINATES.split(";");
                     

                     
                     
                     ;(function (a) {var j, x, i;for (i = a.length; i; i--) {j = Math.floor(Math.random() * i);x = a[i - 1]; a[i - 1] = a[j];a[j] = x;}})(VAR_LISTS_COORDINATES)
                     

                     
                     
                     _do_with_params({"foreach_data":(VAR_LISTS_COORDINATES)},function(){
                     _set_action_info({ name: "Foreach" });
                     VAR_CYCLE_INDEX = _iterator() - 1
                     if(VAR_CYCLE_INDEX > _cycle_param("foreach_data").length - 1)_break();
                     VAR_FOREACH_DATA = _cycle_param("foreach_data")[VAR_CYCLE_INDEX]
                     
                        
                        
                        var csv_parse_result = csv_parse(VAR_FOREACH_DATA)
                        VAR_ANSWER_X = csv_parse_result[0]
                        if(typeof(VAR_ANSWER_X) == 'undefined' || !VAR_ANSWER_X)
                        {
                        VAR_ANSWER_X = ""
                        }
                        VAR_ANSWER_Y = csv_parse_result[1]
                        if(typeof(VAR_ANSWER_Y) == 'undefined' || !VAR_ANSWER_Y)
                        {
                        VAR_ANSWER_Y = ""
                        }
                        

                        
                        
                        VAR_ANSWER_X = VAR_ANSWER_X.replace(/[^0-9]/g, '');
                        VAR_ANSWER_Y = VAR_ANSWER_Y.replace(/[^0-9]/g, '');
                        VAR_ANSWER_X = parseInt(VAR_ANSWER_X)
                        VAR_ANSWER_Y = parseInt(VAR_ANSWER_Y)
                        

                        
                        
                        /*Browser*/
                        move(VAR_SQUARE_BUTTON_X + VAR_ANSWER_X + rand (-14,+14),VAR_SQUARE_BUTTON_Y + VAR_ANSWER_Y + rand (-14,+14),  {"speed": VAR_SPEED,"gravity": VAR_GRAVITY,"deviation": VAR_DEVIATION} )!
                        mouse(VAR_SQUARE_BUTTON_X + VAR_ANSWER_X + rand (-14,+14),VAR_SQUARE_BUTTON_Y + VAR_ANSWER_Y + rand (-14,+14))!
                        

                     })!
                     

                  })!
                  

                  
                  
                  _set_if_expression("W1tNRVRIT0RfTU9EVUxFXV0gPT0gIlhldmlsIg==");
                  _if(VAR_METHOD_MODULE == "Xevil",function(){
                  
                     
                     
                     VAR_LISTS_SQUARES = VAR_SAVED_CONTENT;
                     if (VAR_LISTS_SQUARES == 1)
                     {
                     VAR_PIC_X = VAR_FIRST_PIC_X
                     VAR_PIC_Y = VAR_FIRST_PIC_Y
                     }
                     if (VAR_LISTS_SQUARES == 2)
                     {
                     VAR_PIC_X = VAR_SECOND_PIC_X
                     VAR_PIC_Y = VAR_SECOND_PIC_Y
                     }
                     if (VAR_LISTS_SQUARES == 3)
                     {
                     VAR_PIC_X = VAR_THIRD_PIC_X
                     VAR_PIC_Y = VAR_THIRD_PIC_Y
                     }
                     if (VAR_LISTS_SQUARES == 4)
                     {
                     VAR_PIC_X = VAR_FOUR_PIC_X
                     VAR_PIC_Y = VAR_FOUR_PIC_Y
                     }
                     if (VAR_LISTS_SQUARES == 5)
                     {
                     VAR_PIC_X = VAR_FIVE_PIC_X
                     VAR_PIC_Y = VAR_FIVE_PIC_Y
                     }
                     if (VAR_LISTS_SQUARES == 6)
                     {
                     VAR_PIC_X = VAR_SIX_PIC_X
                     VAR_PIC_Y = VAR_SIX_PIC_Y
                     }
                     

                     
                     
                     /*Browser*/
                     move(VAR_PIC_X + rand (-14,+14),VAR_PIC_Y + rand (-14,+14),  {"speed": VAR_SPEED,"gravity": VAR_GRAVITY,"deviation": VAR_DEVIATION} )!
                     mouse(VAR_PIC_X + rand (-14,+14),VAR_PIC_Y + rand (-14,+14))!
                     

                  })!
                  

                  
                  
                  VAR_ERROR_TASK = 0
                  

                  
                  
                  VAR_CURRENT_TASK_NUMBERS = parseInt(VAR_CURRENT_TASK_NUMBERS) + parseInt(-1)
                  

                  
                  
                  sleep(200)!
                  

                  
                  
                  _set_if_expression("W1tDVVJSRU5UX1RBU0tfTlVNQkVSU11dICE9MA==");
                  _if(VAR_CURRENT_TASK_NUMBERS !=0,function(){
                  
                     
                     
                     /*Browser*/
                     _SELECTOR = VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e #game_challengeItem_image";waiter_timeout_next(20000)
                     wait_element(_SELECTOR)!
                     

                  })!
                  

                  
                  
                  _set_if_expression("W1tDVVJSRU5UX1RBU0tfTlVNQkVSU11dID09IDA=");
                  _if(VAR_CURRENT_TASK_NUMBERS == 0,function(){
                  
                     
                     
                     sleep(500)!
                     

                  })!
                  

                  
                  
                  _break("function")
                  

               })!
               

               
               
               _if(!_cycle_params().if_else,function(){
               
                  
                  
                  sleep(1000)!
                  

                  
                  
                  _next("function")
                  

               })!
               delete _cycle_params().if_else;
               

            })!
            

            
            
            _next("function")
            

         },null)!
         

         
         
         _set_if_expression("W1tXQVNfRVJST1JdXQ==");
         _if(typeof(VAR_WAS_ERROR) !== "undefined" ? (VAR_WAS_ERROR) : undefined,function(){
         
            
            
            sleep(1000)!
            

            
            
            _next("function")
            

         })!
         

      })!
      

   }
   

function CaptchaImageClick_HCaptcha()
   {
   
      
      
      VAR_GLOBAL_SELECTOR = _function_argument("SELECTOR")
      

      
      
      VAR_SPEED_MOUSE = _function_argument("SPEED_MOUSE")
      

      
      
      VAR_URL_MODULE = _function_argument("URL")
      

      
      
      VAR_KEY_MODULE = _function_argument("KEY")
      

      
      
      VAR_METHOD_MODULE = _function_argument("METHOD")
      

      
      
      VAR_TRY_NUMBER = _function_argument("TRY_NUMBER")
      

      
      
      VAR_NUMBER_CAPTCHA_MODULE = _function_argument("NUMBER_CAPTCHA")
      

      
      
      VAR_IS_INVISIBLE_CAPTCHA = _function_argument("IS_INVISIBLE_CAPTCHA")
      

      
      
      VAR_ERROR_LOAD = "0"
      

      
      
      VAR_ERROR_FIND_MAIN_SELECTOR = "0"
      

      
      
      VAR_HCAPTCHA_INVISIBLE = "0"
      

      
      
      VAR_NUMBER_CRUMB = "0"
      

      
      
      VAR_NOTIFY_ERROR_EXISTS = "0"
      

      
      
      VAR_HCAPTCHA_PREFIX_SECOND_FRAME = ""
      

      
      
      VAR_RECAPTCHA_MODULE_ENABLED = 0
      

      
      
      VAR_HCAPTCHA_MODULE_ENABLED = 0
      

      
      
      VAR_FUNCATPCHA_MODULE_ENABLED = 0
      

      
      
      VAR_NAME_MODULE_AUTOSUBMIT = "NaN"
      

      
      
      //// Проверить установлены ли модули с автосабмитом.
      if (typeof NumbersParseRecaptcha2 === 'function') VAR_RECAPTCHA_MODULE_ENABLED = 1, VAR_NAME_MODULE_AUTOSUBMIT = "ReCaptcha 2 Autosubmit";
      if (typeof BASCaptchaSolver.helpers.HCaptchaHelper === 'function') VAR_HCAPTCHA_MODULE_ENABLED = 1, VAR_NAME_MODULE_AUTOSUBMIT = "hCaptcha Autosubmit";
      if (typeof BASCaptchaSolver.helpers.FunCaptchaHelper === 'function') VAR_FUNCAPTCHA_MODULE_ENABLED = 1, VAR_NAME_MODULE_AUTOSUBMIT = "FunCaptcha Autosubmit";
      

      
      
      _set_if_expression("W1tGVU5DQVRQQ0hBX01PRFVMRV9FTkFCTEVEXV0gPT0gMSB8fCBbW1JFQ0FQVENIQV9NT0RVTEVfRU5BQkxFRF1dID09IDEgfHwgW1tIQ0FQVENIQV9NT0RVTEVfRU5BQkxFRF1dID09IDE=");
      _if(VAR_FUNCATPCHA_MODULE_ENABLED == 1 || VAR_RECAPTCHA_MODULE_ENABLED == 1 || VAR_HCAPTCHA_MODULE_ENABLED == 1,function(){
      
         
         
         fail((_K==="en" ? "Solve the captcha failed, to continue solving captchas by clicks requires to disable module " +VAR_NAME_MODULE_AUTOSUBMIT + " and retry solving captcha by clicks" : "Решить капчу не удалось, для продолжения решения капчи кликами требуется отключить сторонний встроенный модуль в BAS: " +VAR_NAME_MODULE_AUTOSUBMIT + " и повторить попытку"));
         

      })!
      

      
      
      VAR_GREEN_TICK = false
      

      
      
      /*Browser*/
      cache_allow("*hcaptcha.com/getcaptcha*")!
      

      
      
      /*Browser*/
      cache_allow("*imgs.hcaptcha.com/*")!
      

      
      
      _set_if_expression("W1tJU19JTlZJU0lCTEVfQ0FQVENIQV1d");
      _if(typeof(VAR_IS_INVISIBLE_CAPTCHA) !== "undefined" ? (VAR_IS_INVISIBLE_CAPTCHA) : undefined,function(){
      
         
         
         _call(function()
         {
         _on_fail(function(){
         VAR_LAST_ERROR = _result()
         VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
         VAR_WAS_ERROR = false
         _break(1,true)
         })
         CYCLES.Current().RemoveLabel("function")
         
            
            
            /*Browser*/
            waiter_timeout_next(45000)
            wait_load("*imgs.hcaptcha.com/*")!
            

            
            
            /*Browser*/
            wait_load("*hcaptcha.com/getcaptcha*")!
            

         },null)!
         

         
         
         _set_if_expression("W1tXQVNfRVJST1JdXQ==");
         _if(typeof(VAR_WAS_ERROR) !== "undefined" ? (VAR_WAS_ERROR) : undefined,function(){
         
            
            
            fail(VAR_LAST_ERROR)
            

         })!
         

      })!
      

      
      
      _call(function()
      {
      _on_fail(function(){
      VAR_LAST_ERROR = _result()
      VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
      VAR_WAS_ERROR = false
      _break(1,true)
      })
      CYCLES.Current().RemoveLabel("function")
      
         
         
         if (VAR_SPEED_MOUSE == "Slow")
         {
         VAR_SPEED = 100;
         VAR_GRAVITY = 6;
         VAR_DEVIATION = 2.5;
         }
         if (VAR_SPEED_MOUSE == "Normal")
         {
         VAR_SPEED = 200;
         VAR_GRAVITY = 12;
         VAR_DEVIATION = 5;
         }
         if (VAR_SPEED_MOUSE == "Fast")
         {
         VAR_SPEED = 300;
         VAR_GRAVITY = 18;
         VAR_DEVIATION = 7.5;
         }
         if (VAR_SPEED_MOUSE == "Very Fast")
         {
         VAR_SPEED = 400;
         VAR_GRAVITY = 24;
         VAR_DEVIATION = 10;
         }
         if (VAR_SPEED_MOUSE == "Extremal")
         {
         VAR_SPEED = 500;
         VAR_GRAVITY = 30;
         VAR_DEVIATION = 12.5;
         }
         

         
         
         page().script2("[[IS_MOBILE]] = navigator.maxTouchPoints;",JSON.stringify(_read_variables(["VAR_IS_MOBILE"])))!
         var _parse_result = JSON.parse(_result())
         _write_variables(JSON.parse(_parse_result.variables))
         if(!_parse_result.is_success)
         fail(_parse_result.error)
         

         
         
         _set_if_expression("W1tJU19NT0JJTEVdXSA9PSAwICYmIHJhbmQgKDEsMTApID4gMw==");
         _if(VAR_IS_MOBILE == 0 && rand (1,10) > 3,function(){
         
            
            
            _do(function(){
            _set_action_info({ name: "While" });
            VAR_CYCLE_INDEX = _iterator() - 1
            BREAK_CONDITION = VAR_CYCLE_INDEX < 2 && VAR_IS_MOBILE == 0;
            if(!BREAK_CONDITION)_break();
            
               
               
               _get_browser_screen_settings()!
               ;(function(){
               var result = JSON.parse(_result())
               VAR_SCROLL_X = result["ScrollX"]
               VAR_SCROLL_Y = result["ScrollY"]
               VAR_CURSOR_X = result["CursorX"]
               VAR_CURSOR_Y = result["CursorY"]
               VAR_BROWSER_WIDTH = result["Width"]
               VAR_BROWSER_HEIGHT = result["Height"]
               })();
               

               
               
               var scroll_x=parseInt(VAR_CURSOR_Y);
               var scroll_y=parseInt(VAR_SCROLL_Y);
               var browser_h=parseInt(VAR_BROWSER_HEIGHT);
               //-------------------- Привели все в числа, считаем позицию ---------------------
               var absolut_y = VAR_CURSOR_Y + VAR_SCROLL_Y;
               var y_without_scroll = absolut_y - VAR_SCROLL_Y;
               var check_y_top = VAR_BROWSER_HEIGHT/12;
               var check_y_down = VAR_BROWSER_HEIGHT/100*92;
               var move_y_top = VAR_BROWSER_HEIGHT/10;
               var move_y_down = VAR_BROWSER_HEIGHT/100*80;
               // -------------------------- Округляем ----------------------------------
               VAR_CHECK_Y_TOP = check_y_top.toFixed();
               VAR_CHECK_Y_DOWN = check_y_down.toFixed();
               VAR_Y_WITHOUNT_SCROLL = y_without_scroll.toFixed();
               VAR_MOVE_Y_TOP = move_y_top.toFixed();
               VAR_MOVE_Y_DOWN = move_y_down.toFixed();
               // ----------------- Снова приводим к числу ------------------------
               VAR_CHECK_Y_TOP=parseInt(VAR_CHECK_Y_TOP);
               VAR_CHECK_Y_DOWN=parseInt(VAR_CHECK_Y_DOWN);
               VAR_Y_WITHOUNT_SCROLL=parseInt(VAR_Y_WITHOUNT_SCROLL);
               VAR_MOVE_Y_TOP=parseInt(VAR_MOVE_Y_TOP);
               VAR_MOVE_Y_DOWN=parseInt(VAR_MOVE_Y_DOWN);
               

               
               
               /*Browser*/
               move(rand(VAR_BROWSER_WIDTH/5,VAR_BROWSER_WIDTH/1.3),rand(VAR_MOVE_Y_TOP + VAR_SCROLL_Y,VAR_MOVE_Y_DOWN + VAR_SCROLL_Y),  {} )!
               

               
               
               _set_if_expression("cmFuZCAoMSwxMCkgPiA1");
               _if(rand (1,10) > 5,function(){
               
                  
                  
                  _break("function")
                  

               })!
               

            })!
            

         })!
         

         
         
         VAR_HCAPTCHA_PREFIX = VAR_GLOBAL_SELECTOR;
         VAR_HCAPTCHA_PREFIX_FIRST_FRAME = VAR_HCAPTCHA_PREFIX;
         {
         var index = VAR_HCAPTCHA_PREFIX.toString().lastIndexOf(">FRAME>")
         if(index >= 0)
         VAR_HCAPTCHA_PREFIX = VAR_HCAPTCHA_PREFIX.substring(0,index)
         VAR_HCAPTCHA_PREFIX_FIRST_FRAME = VAR_HCAPTCHA_PREFIX
         index = VAR_HCAPTCHA_PREFIX.toString().lastIndexOf(">FRAME>")
         if(index >= 0)
         VAR_HCAPTCHA_PREFIX = VAR_HCAPTCHA_PREFIX.substring(0,index + ">FRAME>".length)
         else
         VAR_HCAPTCHA_PREFIX = ""
         }
         

         
         
         //////// Проверить открылось ли окно капчи (Invisible HCAPTCHA случай)
         _SELECTOR = VAR_HCAPTCHA_PREFIX_FIRST_FRAME;
         get_element_selector(_SELECTOR).script("(function(){var el = Array.prototype.slice.call(document.getElementsByTagName('iframe')).find(function(el){return(el.src.indexOf('/static/hcaptcha.html#frame=challenge')>=0 && getComputedStyle(el)['visibility'] == 'visible')});if(el){el=el['title']}else{el=''};return el;})()")!
         if(_result().length>0)
         {
         VAR_HCAPTCHA_PREFIX_SECOND_FRAME = VAR_HCAPTCHA_PREFIX + ">CSS>iframe[title=\"" + _result() + "\"]" + ">AT>" + VAR_NUMBER_CAPTCHA_MODULE + ">FRAME> >CSS> body";
         VAR_HCAPTCHA_PREFIX_SECOND_FRAME_ELEMENT = VAR_HCAPTCHA_PREFIX + ">CSS>iframe[title=\"" + _result() + "\"]" + ">AT>" + VAR_NUMBER_CAPTCHA_MODULE
         }
         

         
         
         _cycle_params().if_else = VAR_HCAPTCHA_PREFIX_SECOND_FRAME == "";
         _set_if_expression("W1tIQ0FQVENIQV9QUkVGSVhfU0VDT05EX0ZSQU1FXV0gPT0gIiI=");
         _if(_cycle_params().if_else,function(){
         
            
            
            _do(function(){
            _set_action_info({ name: "For" });
            VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
            if(VAR_CYCLE_INDEX > parseInt(40))_break();
            
               
               
               /*Browser*/
               ;_SELECTOR=VAR_GLOBAL_SELECTOR;
               get_element_selector(_SELECTOR, false).nowait().exist()!
               VAR_IS_EXISTS = _result() == 1
               _if(VAR_IS_EXISTS, function(){
               get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
               VAR_IS_EXISTS = _result().indexOf("true")>=0
               })!
               

               
               
               _cycle_params().if_else = typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined;
               _set_if_expression("W1tJU19FWElTVFNdXQ==");
               _if(_cycle_params().if_else,function(){
               
                  
                  
                  _cycle_params().if_else = VAR_GLOBAL_SELECTOR == ">CSS> iframe[src*='checkbox']>FRAME> >CSS> #checkbox";
                  _set_if_expression("W1tHTE9CQUxfU0VMRUNUT1JdXSA9PSAiPkNTUz4gaWZyYW1lW3NyYyo9J2NoZWNrYm94J10+RlJBTUU+ID5DU1M+ICNjaGVja2JveCI=");
                  _if(_cycle_params().if_else,function(){
                  
                     
                     
                     VAR_RANDOM_NUMBER_CLICK = Math.floor(Math.random() * (parseInt(12) - parseInt(1) + 1)) + parseInt(1)
                     

                     
                     
                     _set_if_expression("W1tSQU5ET01fTlVNQkVSX0NMSUNLXV0gPD0gNA==");
                     _if(VAR_RANDOM_NUMBER_CLICK <= 4,function(){
                     
                        
                        
                        /*Browser*/
                        _SELECTOR = VAR_GLOBAL_SELECTOR;waiter_timeout_next(8000)
                        wait_element_visible(_SELECTOR)!
                        _call(_random_point, {})!
                        _if(_result().length > 0, function(){
                        move( {} )!
                        get_element_selector(_SELECTOR, false).clarify(X,Y)!
                        _call(_clarify, {} )!
                        mouse(X,Y)!
                        })!
                        

                     })!
                     

                     
                     
                     _set_if_expression("W1tSQU5ET01fTlVNQkVSX0NMSUNLXV0gPiA0ICYmIFtbUkFORE9NX05VTUJFUl9DTElDS11dIDw9IDc=");
                     _if(VAR_RANDOM_NUMBER_CLICK > 4 && VAR_RANDOM_NUMBER_CLICK <= 7,function(){
                     
                        
                        
                        /*Browser*/
                        _SELECTOR = "\u003eCSS\u003e iframe[src*=\u0027checkbox\u0027]\u003eFRAME\u003e \u003eCSS\u003e div.label-container \u003e label-td";waiter_timeout_next(8000)
                        wait_element_visible(_SELECTOR)!
                        _call(_random_point, {})!
                        _if(_result().length > 0, function(){
                        move( {} )!
                        get_element_selector(_SELECTOR, false).clarify(X,Y)!
                        _call(_clarify, {} )!
                        mouse(X,Y)!
                        })!
                        

                     })!
                     

                     
                     
                     _set_if_expression("W1tSQU5ET01fTlVNQkVSX0NMSUNLXV0gPiA3");
                     _if(VAR_RANDOM_NUMBER_CLICK > 7,function(){
                     
                        
                        
                        /*Browser*/
                        _SELECTOR = "\u003eCSS\u003e iframe[src*=\u0027checkbox\u0027]\u003eFRAME\u003e \u003eCSS\u003e div.label-container";waiter_timeout_next(8000)
                        wait_element_visible(_SELECTOR)!
                        _call(_random_point, {})!
                        _if(_result().length > 0, function(){
                        move( {} )!
                        get_element_selector(_SELECTOR, false).clarify(X,Y)!
                        _call(_clarify, {} )!
                        mouse(X,Y)!
                        })!
                        

                     })!
                     

                  })!
                  

                  
                  
                  _if(!_cycle_params().if_else,function(){
                  
                     
                     
                     /*Browser*/
                     _SELECTOR = VAR_GLOBAL_SELECTOR;waiter_timeout_next(8000)
                     wait_element_visible(_SELECTOR)!
                     _call(_random_point, {})!
                     _if(_result().length > 0, function(){
                     move( {} )!
                     get_element_selector(_SELECTOR, false).clarify(X,Y)!
                     _call(_clarify, {} )!
                     mouse(X,Y)!
                     })!
                     

                  })!
                  delete _cycle_params().if_else;
                  

                  
                  
                  _break("function")
                  

               })!
               

               
               
               _if(!_cycle_params().if_else,function(){
               
                  
                  
                  sleep(rand(300,800))!
                  

               })!
               delete _cycle_params().if_else;
               

               
               
               _set_if_expression("IVtbSVNfRVhJU1RTXV0=");
               _if(!VAR_IS_EXISTS,function(){
               
                  
                  
                  _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gcmFuZCAoMjIsMjgp");
                  _if(VAR_CYCLE_INDEX > rand (22,28),function(){
                  
                     
                     
                     VAR_ERROR_FIND_MAIN_SELECTOR = "1"
                     

                  })!
                  

               })!
               

            })!
            

         })!
         

         
         
         _if(!_cycle_params().if_else,function(){
         
            
            
            VAR_HCAPTCHA_INVISIBLE = "1"
            

         })!
         delete _cycle_params().if_else;
         

      },null)!
      

      
      
      _set_if_expression("W1tXQVNfRVJST1JdXQ==");
      _if(typeof(VAR_WAS_ERROR) !== "undefined" ? (VAR_WAS_ERROR) : undefined,function(){
      
         
         
         /*Browser*/
         cache_data_clear()!
         

         
         
         fail(VAR_LAST_ERROR)
         

      })!
      

      
      
      _set_if_expression("W1tFUlJPUl9GSU5EX01BSU5fU0VMRUNUT1JdXSA9PSAx");
      _if(VAR_ERROR_FIND_MAIN_SELECTOR == 1,function(){
      
         
         
         /*Browser*/
         cache_data_clear()!
         

         
         
         fail((_K==="en" ? "Could not wait for the main hCaptcha selector to load with the 'I am human' button" : "Не удалось дождаться загрузки основного селектора hCaptcha c кнопкой 'Я человек'"));
         

      })!
      

      
      
      VAR_TRY_CAPTCHA = "0"
      

      
      
      VAR_BAS_CAPMONSTER_IMAGE_ID = "0"
      

      
      
      VAR_HCAPTCHA_CLOSED = "0"
      

      
      
      VAR_CAPTCHA_FAIL = "0"
      

      
      
      VAR_ERROR_LOAD = "0"
      

      
      
      VAR_ERROR_KEY = "0"
      

      
      
      VAR_ERROR_BALANCE = "0"
      

      
      
      VAR_ERROR_LANG = "0"
      

      
      
      VAR_GET_ALL_COORDINATES = "0"
      

      
      
      VAR_FIRST_LOAD_CAPTCHA = true
      

      
      
      _set_goto_label("hCaptcha start here location")!
      

      
      
      _do(function(){
      _set_action_info({ name: "For" });
      VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
      if(VAR_CYCLE_INDEX > parseInt(500))_break();
      
         
         
         VAR_CYCLE_INDEX = 0
         

         
         
         _set_if_expression("W1tFUlJPUl9LRVldXSA9PSAx");
         _if(VAR_ERROR_KEY == 1,function(){
         
            
            
            /*Browser*/
            cache_data_clear()!
            

            
            
            fail((_K==="en" ? "API secret key from captcha recognition service is wrong ERROR_WRONG_USER_KEY" : "Секретный ключ API от сервиса распознавания капчи неправильный ERROR_WRONG_USER_KEY"));
            

         })!
         

         
         
         _set_if_expression("W1tFUlJPUl9CQUxBTkNFXV0gPT0gMQ==");
         _if(VAR_ERROR_BALANCE == 1,function(){
         
            
            
            /*Browser*/
            cache_data_clear()!
            

            
            
            fail((_K==="en" ? "The balance on the captcha service has ended - ERROR_ZERO_BALANCE" : "Закончился баланс на сервисе распознавания капчи - ERROR_ZERO_BALANCE"));
            

         })!
         

         
         
         _set_if_expression("W1tDQVBUQ0hBX0ZBSUxdXSA9PSAx");
         _if(VAR_CAPTCHA_FAIL == 1,function(){
         
            
            
            /*Browser*/
            cache_data_clear()!
            

            
            
            fail((_K==="en" ? "Failed to complete the request to the captcha recognition server, error - CAPTCHA_FAIL" : "Не удалось выполнить запрос к серверу распознавания капчи, ошибка  - CAPTCHA_FAIL"));
            

         })!
         

         
         
         _do(function(){
         _set_action_info({ name: "For" });
         VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
         if(VAR_CYCLE_INDEX > parseInt(180))_break();
         
            
            
            /*Browser*/
            ;_SELECTOR=VAR_HCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e #checkbox[aria-checked=\u0027true\u0027]";
            get_element_selector(_SELECTOR, false).nowait().exist()!
            VAR_IS_EXISTS = _result() == 1
            _if(VAR_IS_EXISTS, function(){
            get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
            VAR_IS_EXISTS = _result().indexOf("true")>=0
            })!
            

            
            
            _set_if_expression("W1tJU19FWElTVFNdXSA9PSB0cnVl");
            _if(VAR_IS_EXISTS == true,function(){
            
               
               
               VAR_GREEN_TICK = true
               

               
               
               /*Browser*/
               cache_data_clear()!
               

               
               
               _break("function")
               

            })!
            

            
            
            _set_if_expression("W1tIQ0FQVENIQV9JTlZJU0lCTEVdXSA+IDAgJiYgW1tGSVJTVF9MT0FEX0NBUFRDSEFdXSA9PSBmYWxzZSAmJiBbW05VTUJFUl9DUlVNQl1dID09IDA=");
            _if(VAR_HCAPTCHA_INVISIBLE > 0 && VAR_FIRST_LOAD_CAPTCHA == false && VAR_NUMBER_CRUMB == 0,function(){
            
               
               
               /*Browser*/
               ;_SELECTOR=VAR_HCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eXPATH\u003e //div[@class=\u0022display-error\u0022][contains(@aria-hidden, \u0027false\u0027)]";
               get_element_selector(_SELECTOR, false).nowait().exist()!
               VAR_IS_EXISTS = _result() == 1
               _if(VAR_IS_EXISTS, function(){
               get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
               VAR_IS_EXISTS = _result().indexOf("true")>=0
               })!
               

               
               
               _set_if_expression("W1tJU19FWElTVFNdXQ==");
               _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
               
                  
                  
                  sleep(rand(500,1000))!
                  

                  
                  
                  _break("function")
                  

               })!
               

               
               
               /*Browser*/
               ;_SELECTOR=VAR_HCAPTCHA_PREFIX_SECOND_FRAME + "\u003eCSS\u003e .task-grid";
               get_element_selector(_SELECTOR, false).nowait().exist()!
               VAR_IS_EXISTS = _result() == 1
               _if(VAR_IS_EXISTS, function(){
               get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
               VAR_IS_EXISTS = _result().indexOf("true")>=0
               })!
               

               
               
               _set_if_expression("W1tJU19FWElTVFNdXSA9PSBmYWxzZQ==");
               _if(VAR_IS_EXISTS == false,function(){
               
                  
                  
                  VAR_GREEN_TICK = true
                  

                  
                  
                  /*Browser*/
                  cache_data_clear()!
                  

                  
                  
                  _break("function")
                  

               })!
               

            })!
            

            
            
            _set_if_expression("W1tIQ0FQVENIQV9JTlZJU0lCTEVdXSA9PSAwICYmIFtbRklSU1RfTE9BRF9DQVBUQ0hBXV0gPT0gdHJ1ZQ==");
            _if(VAR_HCAPTCHA_INVISIBLE == 0 && VAR_FIRST_LOAD_CAPTCHA == true,function(){
            
               
               
               /*Browser*/
               ;_SELECTOR=" \u003eXPATH\u003e //*[@id=\u0022challenge-running\u0022][contains(text(),\u0022Checking if the site connection is secure\u0022)] ";
               get_element_selector(_SELECTOR, false).nowait().exist()!
               VAR_IS_EXISTS = _result() == 1
               

               
               
               _set_if_expression("W1tJU19FWElTVFNdXQ==");
               _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
               
                  
                  
                  VAR_NUMBER_CAPTCHA_MODULE = "1"
                  

               })!
               

            })!
            

            
            
            //////// Проверить открылось ли окно капчи
            _SELECTOR = VAR_HCAPTCHA_PREFIX_FIRST_FRAME;
            get_element_selector(_SELECTOR).script("(function(){var el = Array.prototype.slice.call(document.getElementsByTagName('iframe')).find(function(el){return(el.src.indexOf('/static/hcaptcha.html#frame=challenge')>=0 && getComputedStyle(el)['visibility'] == 'visible')});if(el){el=el['title']}else{el=''};return el;})()")!
            if(_result().length>0)
            {
            VAR_HCAPTCHA_PREFIX_SECOND_FRAME = VAR_HCAPTCHA_PREFIX + ">CSS>iframe[title=\"" + _result() + "\"]" + ">AT>" + VAR_NUMBER_CAPTCHA_MODULE + ">FRAME> >CSS> body";
            VAR_HCAPTCHA_PREFIX_SECOND_FRAME_ELEMENT = VAR_HCAPTCHA_PREFIX + ">CSS>iframe[title=\"" + _result() + "\"]" + ">AT>" + VAR_NUMBER_CAPTCHA_MODULE
            _break()
            }
            

            
            
            _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gMTAwICYmIFtbRklSU1RfTE9BRF9DQVBUQ0hBXV0gPT0gdHJ1ZQ==");
            _if(VAR_CYCLE_INDEX > 100 && VAR_FIRST_LOAD_CAPTCHA == true,function(){
            
               
               
               /*Browser*/
               cache_data_clear()!
               

               
               
               fail((_K==="en" ? "Failed to load captcha image window, internet connection too slow" : "Не удалось загрузить окно с картинками капчи, слишком медленное интернет соединение"));
               

            })!
            

            
            
            _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gMjUgJiYgW1tGSVJTVF9MT0FEX0NBUFRDSEFdXSA9PSBmYWxzZQ==");
            _if(VAR_CYCLE_INDEX > 25 && VAR_FIRST_LOAD_CAPTCHA == false,function(){
            
               
               
               /*Browser*/
               cache_data_clear()!
               

               
               
               fail((_K==="en" ? "Failed to solve the captcha. The captcha window is closed." : "Решить капчу не удалось. Окно с капчей не было открыто."));
               

            })!
            

         })!
         

         
         
         _set_if_expression("W1tHUkVFTl9USUNLXV0gPT0gdHJ1ZQ==");
         _if(VAR_GREEN_TICK == true,function(){
         
            
            
            _function_return("")
            

         })!
         

         
         
         VAR_TRY_CAPTCHA = parseInt(VAR_TRY_CAPTCHA) + parseInt(1)
         

         
         
         _set_if_expression("W1tUUllfQ0FQVENIQV1dID49IFtbVFJZX05VTUJFUl1d");
         _if(VAR_TRY_CAPTCHA >= VAR_TRY_NUMBER,function(){
         
            
            
            /*Browser*/
            cache_data_clear()!
            

            
            
            fail((_K==="en" ? "Failed to solve the captcha. hCaptcha attempts limit exceeded" : "Решить капчу не удалось. Превышен лимит попыток решить hCaptcha"));
            

         })!
         

         
         
         _call(function()
         {
         _on_fail(function(){
         VAR_LAST_ERROR = _result()
         VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
         VAR_WAS_ERROR = false
         _break(1,true)
         })
         CYCLES.Current().RemoveLabel("function")
         
            
            
            _set_if_expression("W1tIQ0FQVENIQV9JTlZJU0lCTEVdXSA9PSAx");
            _if(VAR_HCAPTCHA_INVISIBLE == 1,function(){
            
               
               
               VAR_CYCLE_INDEX = 0
               

               
               
               _do(function(){
               _set_action_info({ name: "For" });
               VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
               if(VAR_CYCLE_INDEX > parseInt(60))_break();
               
                  
                  
                  /*Browser*/
                  ;_SELECTOR=VAR_HCAPTCHA_PREFIX_SECOND_FRAME + "\u003eCSS\u003e .task-grid";
                  get_element_selector(_SELECTOR, false).nowait().exist()!
                  VAR_IS_EXISTS = _result() == 1
                  _if(VAR_IS_EXISTS, function(){
                  get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
                  VAR_IS_EXISTS = _result().indexOf("true")>=0
                  })!
                  

                  
                  
                  _set_if_expression("W1tJU19FWElTVFNdXSA9PSB0cnVl");
                  _if(VAR_IS_EXISTS == true,function(){
                  
                     
                     
                     _break("function")
                     

                  })!
                  

                  
                  
                  _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gNTA=");
                  _if(VAR_CYCLE_INDEX > 50,function(){
                  
                     
                     
                     VAR_ERROR_LOAD = 1
                     

                  })!
                  

                  
                  
                  sleep(rand(200,600))!
                  

               })!
               

               
               
               _set_if_expression("W1tFUlJPUl9MT0FEXV0gPT0gMQ==");
               _if(VAR_ERROR_LOAD == 1,function(){
               
                  
                  
                  _next("function")
                  

               })!
               

            })!
            

            
            
            _set_if_expression("W1tIQ0FQVENIQV9JTlZJU0lCTEVdXSA9PSAwIHx8IFtbSENBUFRDSEFfSU5WSVNJQkxFXV0gPiAx");
            _if(VAR_HCAPTCHA_INVISIBLE == 0 || VAR_HCAPTCHA_INVISIBLE > 1,function(){
            
               
               
               get_element_selector(VAR_HCAPTCHA_PREFIX_SECOND_FRAME_ELEMENT).script("window.getComputedStyle(self)['visibility']")!
               if(_result() == "hidden"){
               VAR_HCAPTCHA_CLOSED = 1;
               }
               else{
               waiter_timeout_next(19000);
               wait_load("*imgs.hcaptcha.com/*")!
               }
               

               
               
               _set_if_expression("W1tIQ0FQVENIQV9DTE9TRURdXSA9PSAx");
               _if(VAR_HCAPTCHA_CLOSED == 1,function(){
               
                  
                  
                  sleep(100)!
                  

                  
                  
                  _next("function")
                  

               })!
               

               
               
               VAR_CYCLE_INDEX = 0
               

               
               
               _do(function(){
               _set_action_info({ name: "For" });
               VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
               if(VAR_CYCLE_INDEX > parseInt(60))_break();
               
                  
                  
                  /*Browser*/
                  ;_SELECTOR=VAR_HCAPTCHA_PREFIX_SECOND_FRAME_ELEMENT;
                  get_element_selector(_SELECTOR, false).nowait().exist()!
                  VAR_IS_EXISTS = _result() == 1
                  

                  
                  
                  _set_if_expression("IVtbSVNfRVhJU1RTXV0=");
                  _if(!VAR_IS_EXISTS,function(){
                  
                     
                     
                     _long_goto("hCaptcha start here location", 5, [])!
                     

                  })!
                  

                  
                  
                  cache_get_base64("*imgs.hcaptcha.com/*")!
                  var image_id = native("imageprocessing", "load", _result())
                  var image_size = native("imageprocessing", "getsize", image_id)
                  var image_w = parseInt(image_size.split(",")[0])
                  var image_h = parseInt(image_size.split(",")[1])
                  if (image_h == 0 && VAR_CYCLE_INDEX > rand (45,55)) fail((_K === "en" ? "Failed to wait for hCaptcha image from request cache" : "Не удалось дождаться картинку hCaptcha из кэша запроса"))
                  if (image_h > 50) {
                  VAR_IMAGE_BASE_64 = _result()
                  _break()
                  }
                  sleep(400)!
                  

               })!
               

            })!
            

         },null)!
         

         
         
         _set_if_expression("W1tXQVNfRVJST1JdXQ==");
         _if(typeof(VAR_WAS_ERROR) !== "undefined" ? (VAR_WAS_ERROR) : undefined,function(){
         
            
            
            _set_if_expression("W1tUUllfQ0FQVENIQV1dID49IFtbVFJZX05VTUJFUl1d");
            _if(VAR_TRY_CAPTCHA >= VAR_TRY_NUMBER,function(){
            
               
               
               _function_return("")
               

            })!
            

            
            
            _set_if_expression("W1tFUlJPUl9LRVldXSA9PSAx");
            _if(VAR_ERROR_KEY == 1,function(){
            
               
               
               /*Browser*/
               cache_data_clear()!
               

               
               
               fail((_K==="en" ? "API secret key from captcha recognition service is wrong ERROR_WRONG_USER_KEY" : "Секретный ключ API от сервиса распознавания капчи неправильный ERROR_WRONG_USER_KEY"));
               

            })!
            

            
            
            _set_if_expression("W1tFUlJPUl9CQUxBTkNFXV0gPT0gMQ==");
            _if(VAR_ERROR_BALANCE == 1,function(){
            
               
               
               /*Browser*/
               cache_data_clear()!
               

               
               
               fail((_K==="en" ? "The balance on the captcha service has ended - ERROR_ZERO_BALANCE" : "Закончился баланс на сервисе распознавания капчи - ERROR_ZERO_BALANCE"));
               

            })!
            

            
            
            _set_if_expression("W1tDQVBUQ0hBX0ZBSUxdXSA9PSAx");
            _if(VAR_CAPTCHA_FAIL == 1,function(){
            
               
               
               /*Browser*/
               cache_data_clear()!
               

               
               
               fail((_K==="en" ? "Failed to complete the request to the captcha recognition server, error - CAPTCHA_FAIL" : "Не удалось выполнить запрос к серверу распознавания капчи, ошибка  - CAPTCHA_FAIL"));
               

            })!
            

            
            
            /*Browser*/
            ;_SELECTOR=VAR_HCAPTCHA_PREFIX_SECOND_FRAME_ELEMENT;
            get_element_selector(_SELECTOR, false).nowait().exist()!
            VAR_IS_EXISTS = _result() == 1
            

            
            
            _set_if_expression("IVtbSVNfRVhJU1RTXV0=");
            _if(!VAR_IS_EXISTS,function(){
            
               
               
               _long_goto("hCaptcha start here location", 3, [])!
               

            })!
            

            
            
            cache_data_clear()!
            

            
            
            _call(function()
            {
            _on_fail(function(){
            VAR_LAST_ERROR = _result()
            VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
            VAR_WAS_ERROR = false
            _break(1,true)
            })
            CYCLES.Current().RemoveLabel("function")
            
               
               
               /*Browser*/
               ;_SELECTOR=VAR_HCAPTCHA_PREFIX_SECOND_FRAME + "\u003eCSS\u003e .refresh";
               get_element_selector(_SELECTOR, false).nowait().exist()!
               VAR_IS_EXISTS = _result() == 1
               _if(VAR_IS_EXISTS, function(){
               get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
               VAR_IS_EXISTS = _result().indexOf("true")>=0
               })!
               

               
               
               _cycle_params().if_else = VAR_GET_ALL_COORDINATES == 0;
               _set_if_expression("W1tHRVRfQUxMX0NPT1JESU5BVEVTXV0gPT0gMA==");
               _if(_cycle_params().if_else,function(){
               
                  
                  
                  _set_if_expression("W1tJU19FWElTVFNdXQ==");
                  _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
                  
                     
                     
                     /*Browser*/
                     _SELECTOR = VAR_HCAPTCHA_PREFIX_SECOND_FRAME + "\u003eCSS\u003e .refresh";
                     wait_element_visible(_SELECTOR)!
                     _call(_random_point, {})!
                     _if(_result().length > 0, function(){
                     move( {} )!
                     get_element_selector(_SELECTOR, false).clarify(X,Y)!
                     _call(_clarify, {} )!
                     mouse(X,Y)!
                     })!
                     

                  })!
                  

                  
                  
                  sleep(3000)!
                  

               })!
               

               
               
               _if(!_cycle_params().if_else,function(){
               
                  
                  
                  _set_if_expression("W1tSRUxPQURfQlVUVE9OX1ldXSA+IFtbQlJPV1NFUl9IRUlHSFRdXQ==");
                  _if(VAR_RELOAD_BUTTON_Y > VAR_BROWSER_HEIGHT,function(){
                  
                     
                     
                     /*Browser*/
                     _SELECTOR = VAR_HCAPTCHA_PREFIX_SECOND_FRAME + "\u003eXPATH\u003e //div[@class=\u0022challenge-interface\u0022]";
                     wait_element_visible(_SELECTOR)!
                     _call(_random_point, {})!
                     _if(_result().length > 0, function(){
                     move( {} )!
                     get_element_selector(_SELECTOR, false).clarify(X,Y)!
                     _call(_clarify, {} )!
                     })!
                     

                  })!
                  

                  
                  
                  _get_browser_screen_settings()!
                  ;(function(){
                  var result = JSON.parse(_result())
                  VAR_SCROLL_X = result["ScrollX"]
                  VAR_SCROLL_Y = result["ScrollY"]
                  VAR_CURSOR_X = result["CursorX"]
                  VAR_CURSOR_Y = result["CursorY"]
                  VAR_BROWSER_WIDTH = result["Width"]
                  VAR_BROWSER_HEIGHT = result["Height"]
                  })();
                  

                  
                  
                  _cycle_params().if_else = VAR_IS_CHANGED_SCROLL_Y != VAR_SCROLL_Y;
                  _set_if_expression("W1tJU19DSEFOR0VEX1NDUk9MTF9ZXV0gIT0gW1tTQ1JPTExfWV1d");
                  _if(_cycle_params().if_else,function(){
                  
                     
                     
                     VAR_ELEMENT_SELECTOR = VAR_HCAPTCHA_PREFIX_SECOND_FRAME + "\u003eCSS\u003e .refresh"
                     

                     
                     
                     _SELECTOR = VAR_ELEMENT_SELECTOR;
                     get_element_selector(_SELECTOR, false).script("(function(){var rect = self.getBoundingClientRect();return (rect.left + positionx).toString() + '|' + (rect.top + positiony).toString() + '|' + (rect.right - rect.left).toString() + '|' + (rect.bottom - rect.top).toString()})();")!
                     var split = _result().split("|");
                     var x = parseInt(split[0]), y = parseInt(split[1]), w = parseInt(split[2]), h = parseInt(split[3]);
                     _get_browser_screen_settings()!
                     var newresult = JSON.parse(_result());
                     var scroll_x = newresult["ScrollX"], scroll_y = newresult["ScrollY"]
                     var margin_top_bottom = 50; //percent
                     var margin_left_top = 50; // percent
                     div = 1;
                     var x_min = x + w/100*margin_left_top + parseInt(scroll_x), x_max = x+w/div-w/100*margin_left_top + parseInt(scroll_x);
                     var y_min = y + h/100*margin_top_bottom + parseInt(scroll_y), y_max = y+h - h/100*margin_top_bottom + parseInt(scroll_y);
                     x = rand(x_min, x_max);
                     y = rand(y_min, y_max);
                     x = x.toFixed();
                     y = y.toFixed();
                     /// Кнопка Reload
                     VAR_RELOAD_BUTTON_X = parseInt(x);
                     VAR_RELOAD_BUTTON_Y = parseInt(y);
                     

                  })!
                  

                  
                  
                  _set_if_expression("W1tJU19FWElTVFNdXQ==");
                  _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
                  
                     
                     
                     /*Browser*/
                     move(VAR_RELOAD_BUTTON_X + rand (-6,6),VAR_RELOAD_BUTTON_Y + rand (-6,6),  {"speed": VAR_SPEED,"gravity": VAR_GRAVITY,"deviation": VAR_DEVIATION} )!
                     mouse(VAR_RELOAD_BUTTON_X + rand (-6,6),VAR_RELOAD_BUTTON_Y + rand (-6,6))!
                     

                  })!
                  

                  
                  
                  sleep(3000)!
                  

               })!
               delete _cycle_params().if_else;
               

            },null)!
            

            
            
            VAR_NUMBER_CRUMB = "0"
            

            
            
            VAR_HCAPTCHA_INVISIBLE = parseInt(VAR_HCAPTCHA_INVISIBLE) + parseInt(1)
            

            
            
            sleep(1000)!
            

            
            
            _next("function")
            

         })!
         

         
         
         _call(function()
         {
         _on_fail(function(){
         VAR_LAST_ERROR = _result()
         VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
         VAR_WAS_ERROR = false
         _break(1,true)
         })
         CYCLES.Current().RemoveLabel("function")
         
            
            
            _get_browser_screen_settings()!
            ;(function(){
            var result = JSON.parse(_result())
            VAR_SCROLL_X = result["ScrollX"]
            VAR_SCROLL_Y = result["ScrollY"]
            VAR_CURSOR_X = result["CursorX"]
            VAR_CURSOR_Y = result["CursorY"]
            VAR_BROWSER_WIDTH = result["Width"]
            VAR_BROWSER_HEIGHT = result["Height"]
            })();
            

            
            
            _set_if_expression("W1tHRVRfQUxMX0NPT1JESU5BVEVTXV0gPT0gMCB8fCBbW0lTX0NIQU5HRURfU0NST0xMX1ldXSAhPSBbW1NDUk9MTF9ZXV0=");
            _if(VAR_GET_ALL_COORDINATES == 0 || VAR_IS_CHANGED_SCROLL_Y != VAR_SCROLL_Y,function(){
            
               
               
               VAR_IS_CHANGED_SCROLL_Y = VAR_SCROLL_Y
               

               
               
               VAR_ELEMENT_SELECTOR = VAR_HCAPTCHA_PREFIX_SECOND_FRAME + "\u003eCSS\u003e .task-grid"
               

               
               
               _SELECTOR = VAR_ELEMENT_SELECTOR;
               get_element_selector(_SELECTOR, false).script("(function(){var rect = self.getBoundingClientRect();return (rect.left + positionx).toString() + '|' + (rect.top + positiony).toString() + '|' + (rect.right - rect.left).toString() + '|' + (rect.bottom - rect.top).toString()})();")!
               var split = _result().split("|");
               var x = parseInt(split[0]), y = parseInt(split[1]), w = parseInt(split[2]), h = parseInt(split[3]);
               /// Первый квадрат
               VAR_SQUARE_BUTTON_X = parseInt(x)
               VAR_SQUARE_BUTTON_Y = parseInt(y) + VAR_SCROLL_Y;
               VAR_SQUARE_WIDTH = parseInt(w);
               VAR_SQUARE_HEIGHT = parseInt(h);
               

               
               
               VAR_ELEMENT_SELECTOR = VAR_HCAPTCHA_PREFIX_SECOND_FRAME + "\u003eCSS\u003e .refresh"
               

               
               
               _SELECTOR = VAR_ELEMENT_SELECTOR;
               get_element_selector(_SELECTOR, false).script("(function(){var rect = self.getBoundingClientRect();return (rect.left + positionx).toString() + '|' + (rect.top + positiony).toString() + '|' + (rect.right - rect.left).toString() + '|' + (rect.bottom - rect.top).toString()})();")!
               var split = _result().split("|");
               var x = parseInt(split[0]), y = parseInt(split[1]), w = parseInt(split[2]), h = parseInt(split[3]);
               _get_browser_screen_settings()!
               var newresult = JSON.parse(_result());
               var scroll_x = newresult["ScrollX"], scroll_y = newresult["ScrollY"]
               var margin_top_bottom = 50; //percent
               var margin_left_top = 50; // percent
               div = 1;
               var x_min = x + w/100*margin_left_top + parseInt(scroll_x), x_max = x+w/div-w/100*margin_left_top + parseInt(scroll_x);
               var y_min = y + h/100*margin_top_bottom + parseInt(scroll_y), y_max = y+h - h/100*margin_top_bottom + parseInt(scroll_y);
               x = rand(x_min, x_max);
               y = rand(y_min, y_max);
               x = x.toFixed();
               y = y.toFixed();
               /// Кнопка Reload
               VAR_RELOAD_BUTTON_X = parseInt(x);
               VAR_RELOAD_BUTTON_Y = parseInt(y);
               

               
               
               VAR_ELEMENT_SELECTOR = VAR_HCAPTCHA_PREFIX_SECOND_FRAME + "\u003eCSS\u003e .button-submit"
               

               
               
               _SELECTOR = VAR_ELEMENT_SELECTOR;
               get_element_selector(_SELECTOR, false).script("(function(){var rect = self.getBoundingClientRect();return (rect.left + positionx).toString() + '|' + (rect.top + positiony).toString() + '|' + (rect.right - rect.left).toString() + '|' + (rect.bottom - rect.top).toString()})();")!
               var split = _result().split("|");
               var x = parseInt(split[0]), y = parseInt(split[1]), w = parseInt(split[2]), h = parseInt(split[3]);
               _get_browser_screen_settings()!
               var newresult = JSON.parse(_result());
               var scroll_x = newresult["ScrollX"], scroll_y = newresult["ScrollY"]
               var margin_top_bottom = 50; //percent
               var margin_left_top = 50; // percent
               div = 1;
               var x_min = x + w/100*margin_left_top + parseInt(scroll_x), x_max = x+w/div-w/100*margin_left_top + parseInt(scroll_x);
               var y_min = y + h/100*margin_top_bottom + parseInt(scroll_y), y_max = y+h - h/100*margin_top_bottom + parseInt(scroll_y);
               x = rand(x_min, x_max);
               y = rand(y_min, y_max);
               x = x.toFixed();
               y = y.toFixed();
               /// Кнопка подтвердить
               VAR_SUBMIT_BUTTON_X = parseInt(x);
               VAR_SUBMIT_BUTTON_Y = parseInt(y);
               

               
               
               VAR_GET_ALL_COORDINATES = "1"
               

            })!
            

         },null)!
         

         
         
         _set_if_expression("W1tXQVNfRVJST1JdXQ==");
         _if(typeof(VAR_WAS_ERROR) !== "undefined" ? (VAR_WAS_ERROR) : undefined,function(){
         
            
            
            /*Browser*/
            cache_data_clear()!
            

            
            
            fail(VAR_LAST_ERROR)
            

         })!
         

         
         
         _call(function()
         {
         _on_fail(function(){
         VAR_LAST_ERROR = _result()
         VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
         VAR_WAS_ERROR = false
         _break(1,true)
         })
         CYCLES.Current().RemoveLabel("function")
         
            
            
            _set_if_expression("W1tOVU1CRVJfQ1JVTUJdXSA9PSAw");
            _if(VAR_NUMBER_CRUMB == 0,function(){
            
               
               
               /*Browser*/
               waiter_timeout_next(18000)
               wait_load("*hcaptcha.com/getcaptcha*")!
               

               
               
               /*Browser*/
               waiter_timeout_next(10000)
               wait_load("*hcaptcha.com/getcaptcha*")!
               cache_get_string("*hcaptcha.com/getcaptcha*")!
               VAR_CURRENT_CASHE_TASK = _result()
               

               
               
               _cycle_params().if_else = VAR_CURRENT_CASHE_TASK == "";
               _set_if_expression("W1tDVVJSRU5UX0NBU0hFX1RBU0tdXSA9PSAiIg==");
               _if(_cycle_params().if_else,function(){
               
                  
                  
                  VAR_NOTIFY_ERROR_EXISTS = "1"
                  

               })!
               

               
               
               _if(!_cycle_params().if_else,function(){
               
                  
                  
                  VAR_SET_TASK = JSON.parse(VAR_CURRENT_CASHE_TASK);
                  VAR_SET_TASK = VAR_SET_TASK.requester_question.en
                  

               })!
               delete _cycle_params().if_else;
               

            })!
            

            
            
            _set_if_expression("W1tSRUxPQURfQlVUVE9OX1ldXSA+IFtbQlJPV1NFUl9IRUlHSFRdXSAmJiBbW05VTUJFUl9DUlVNQl1dID09IDA=");
            _if(VAR_RELOAD_BUTTON_Y > VAR_BROWSER_HEIGHT && VAR_NUMBER_CRUMB == 0,function(){
            
               
               
               /*Browser*/
               _SELECTOR = VAR_HCAPTCHA_PREFIX_SECOND_FRAME + "\u003eXPATH\u003e //div[@class=\u0022challenge-interface\u0022]";
               wait_element_visible(_SELECTOR)!
               _call(_random_point, {})!
               _if(_result().length > 0, function(){
               move( {} )!
               get_element_selector(_SELECTOR, false).clarify(X,Y)!
               _call(_clarify, {} )!
               })!
               

               
               
               _get_browser_screen_settings()!
               ;(function(){
               var result = JSON.parse(_result())
               VAR_SCROLL_X = result["ScrollX"]
               VAR_SCROLL_Y = result["ScrollY"]
               VAR_CURSOR_X = result["CursorX"]
               VAR_CURSOR_Y = result["CursorY"]
               VAR_BROWSER_WIDTH = result["Width"]
               VAR_BROWSER_HEIGHT = result["Height"]
               })();
               

               
               
               VAR_ELEMENT_SELECTOR = VAR_HCAPTCHA_PREFIX_SECOND_FRAME + "\u003eCSS\u003e .task-grid"
               

               
               
               _SELECTOR = VAR_ELEMENT_SELECTOR;
               get_element_selector(_SELECTOR, false).script("(function(){var rect = self.getBoundingClientRect();return (rect.left + positionx).toString() + '|' + (rect.top + positiony).toString() + '|' + (rect.right - rect.left).toString() + '|' + (rect.bottom - rect.top).toString()})();")!
               var split = _result().split("|");
               var x = parseInt(split[0]), y = parseInt(split[1]), w = parseInt(split[2]), h = parseInt(split[3]);
               /// Первый квадрат
               VAR_SQUARE_BUTTON_X = parseInt(x)
               VAR_SQUARE_BUTTON_Y = parseInt(y) + VAR_SCROLL_Y;
               VAR_SQUARE_WIDTH = parseInt(w);
               VAR_SQUARE_HEIGHT = parseInt(h);
               

               
               
               VAR_ELEMENT_SELECTOR = VAR_HCAPTCHA_PREFIX_SECOND_FRAME + "\u003eCSS\u003e .refresh"
               

               
               
               _SELECTOR = VAR_ELEMENT_SELECTOR;
               get_element_selector(_SELECTOR, false).script("(function(){var rect = self.getBoundingClientRect();return (rect.left + positionx).toString() + '|' + (rect.top + positiony).toString() + '|' + (rect.right - rect.left).toString() + '|' + (rect.bottom - rect.top).toString()})();")!
               var split = _result().split("|");
               var x = parseInt(split[0]), y = parseInt(split[1]), w = parseInt(split[2]), h = parseInt(split[3]);
               _get_browser_screen_settings()!
               var newresult = JSON.parse(_result());
               var scroll_x = newresult["ScrollX"], scroll_y = newresult["ScrollY"]
               var margin_top_bottom = 50; //percent
               var margin_left_top = 50; // percent
               div = 1;
               var x_min = x + w/100*margin_left_top + parseInt(scroll_x), x_max = x+w/div-w/100*margin_left_top + parseInt(scroll_x);
               var y_min = y + h/100*margin_top_bottom + parseInt(scroll_y), y_max = y+h - h/100*margin_top_bottom + parseInt(scroll_y);
               x = rand(x_min, x_max);
               y = rand(y_min, y_max);
               x = x.toFixed();
               y = y.toFixed();
               /// Кнопка Reload
               VAR_RELOAD_BUTTON_X = parseInt(x);
               VAR_RELOAD_BUTTON_Y = parseInt(y);
               

               
               
               VAR_ELEMENT_SELECTOR = VAR_HCAPTCHA_PREFIX_SECOND_FRAME + "\u003eCSS\u003e .button-submit"
               

               
               
               _SELECTOR = VAR_ELEMENT_SELECTOR;
               get_element_selector(_SELECTOR, false).script("(function(){var rect = self.getBoundingClientRect();return (rect.left + positionx).toString() + '|' + (rect.top + positiony).toString() + '|' + (rect.right - rect.left).toString() + '|' + (rect.bottom - rect.top).toString()})();")!
               var split = _result().split("|");
               var x = parseInt(split[0]), y = parseInt(split[1]), w = parseInt(split[2]), h = parseInt(split[3]);
               _get_browser_screen_settings()!
               var newresult = JSON.parse(_result());
               var scroll_x = newresult["ScrollX"], scroll_y = newresult["ScrollY"]
               var margin_top_bottom = 50; //percent
               var margin_left_top = 50; // percent
               div = 1;
               var x_min = x + w/100*margin_left_top + parseInt(scroll_x), x_max = x+w/div-w/100*margin_left_top + parseInt(scroll_x);
               var y_min = y + h/100*margin_top_bottom + parseInt(scroll_y), y_max = y+h - h/100*margin_top_bottom + parseInt(scroll_y);
               x = rand(x_min, x_max);
               y = rand(y_min, y_max);
               x = x.toFixed();
               y = y.toFixed();
               /// Кнопка подтвердить
               VAR_SUBMIT_BUTTON_X = parseInt(x);
               VAR_SUBMIT_BUTTON_Y = parseInt(y);
               

               
               
               VAR_IS_CHANGED_SCROLL_Y = VAR_SCROLL_Y
               

            })!
            

            
            
            _set_if_expression("W1tJU19NT0JJTEVdXSA9PSAwICYmIHJhbmQgKDEsMTApID4gMw==");
            _if(VAR_IS_MOBILE == 0 && rand (1,10) > 3,function(){
            
               
               
               _get_browser_screen_settings()!
               ;(function(){
               var result = JSON.parse(_result())
               VAR_SCROLL_X = result["ScrollX"]
               VAR_SCROLL_Y = result["ScrollY"]
               VAR_CURSOR_X = result["CursorX"]
               VAR_CURSOR_Y = result["CursorY"]
               VAR_BROWSER_WIDTH = result["Width"]
               VAR_BROWSER_HEIGHT = result["Height"]
               })();
               

               
               
               /*Browser*/
               ;_SELECTOR=VAR_HCAPTCHA_PREFIX_SECOND_FRAME + "\u003eCSS\u003e .task-grid";
               get_element_selector(_SELECTOR, false).nowait().exist()!
               VAR_IS_EXISTS = _result() == 1
               _if(VAR_IS_EXISTS, function(){
               get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
               VAR_IS_EXISTS = _result().indexOf("true")>=0
               })!
               

               
               
               _set_if_expression("IVtbSVNfRVhJU1RTXV0=");
               _if(!VAR_IS_EXISTS,function(){
               
                  
                  
                  _next("function")
                  

               })!
               

               
               
               /*Browser*/
               _SELECTOR = VAR_HCAPTCHA_PREFIX_SECOND_FRAME + "\u003eCSS\u003e .task-grid";
               wait_element(_SELECTOR)!
               get_element_selector(_SELECTOR, false).script("(function(){var rect = self.getBoundingClientRect();return (rect.left + positionx).toString() + '|' + (rect.top + positiony).toString() + '|' + (rect.right - rect.left).toString() + '|' + (rect.bottom - rect.top).toString()})();")!
               if(_result().length > 0)
               {
               var split = _result().split("|")
               VAR_X = parseInt(split[0])
               VAR_Y = parseInt(split[1])
               VAR_CAPTCHA_WIDTH = parseInt(split[2])
               VAR_CAPTCHA_HEIGHT = parseInt(split[3])
               }
               

               
               
               /*Browser*/
               move(rand(VAR_X/100*105,(VAR_X+VAR_CAPTCHA_WIDTH)/100*93).toFixed(),rand(VAR_Y + VAR_SCROLL_Y/100*105,VAR_Y + VAR_SCROLL_Y + VAR_CAPTCHA_HEIGHT/100*90).toFixed(),  {} )!
               

            })!
            

            
            
            /*Browser*/
            render(VAR_SQUARE_BUTTON_X,VAR_SQUARE_BUTTON_Y,VAR_SQUARE_WIDTH,VAR_SQUARE_HEIGHT)!
            VAR_IMAGE_BASE_64 = _result()
            

            
            
            _set_if_expression("W1tJTUFHRV9CQVNFXzY0XV0gPT0gOTk5OTk5OTk5OQ==");
            _if(VAR_IMAGE_BASE_64 == 9999999999,function(){
            
               
               
               native("filesystem", "writefile", JSON.stringify({path: "C:/Images/Test.jpg",value: (VAR_IMAGE_BASE_64).toString(),base64:true,append:false}))
               

            })!
            

         },null)!
         

         
         
         _set_if_expression("W1tXQVNfRVJST1JdXQ==");
         _if(typeof(VAR_WAS_ERROR) !== "undefined" ? (VAR_WAS_ERROR) : undefined,function(){
         
            
            
            _set_if_expression("W1tMQVNUX0VSUk9SXV0uaW5kZXhPZigiaGNhcHRjaGEuY29tL2dldGNhcHRjaGEiKSA+PSAwICYmIFtbRklSU1RfTE9BRF9DQVBUQ0hBXV0gPT0gdHJ1ZQ==");
            _if(VAR_LAST_ERROR.indexOf("hcaptcha.com/getcaptcha") >= 0 && VAR_FIRST_LOAD_CAPTCHA == true,function(){
            
               
               
               fail((_K==="en" ? "Failed to get task from request cache - *hcaptcha.com/getcaptcha*. Try to allow the cache to mask and read module description" : "Не удалось получить задание из кэша запроса - *hcaptcha.com/getcaptcha*. Попробуйте разрешите кэш, как это указано в описании модуля."));
               

            })!
            

            
            
            /*Browser*/
            cache_data_clear()!
            

            
            
            fail(VAR_LAST_ERROR)
            

         })!
         

         
         
         _set_if_expression("W1tOT1RJRllfRVJST1JfRVhJU1RTXV0gPT0gMQ==");
         _if(VAR_NOTIFY_ERROR_EXISTS == 1,function(){
         
            
            
            fail((_K==="en" ? "Failed to get task from request cache - *hcaptcha.com/getcaptcha*. Try to enable the cache, as indicated in the module description" : "Не удалось получить задание из кэша запроса - *hcaptcha.com/getcaptcha*. Попробуйте разрешите кэш, как это указано в описании модуля."));
            

         })!
         

         
         
         VAR_FIRST_LOAD_CAPTCHA = false
         

         
         
         VAR_CYCLE_INDEX = 0
         

         
         
         _call(function()
         {
         _on_fail(function(){
         VAR_LAST_ERROR = _result()
         VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
         VAR_WAS_ERROR = false
         _break(1,true)
         })
         CYCLES.Current().RemoveLabel("function")
         
            
            
            _do(function(){
            _set_action_info({ name: "For" });
            VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
            if(VAR_CYCLE_INDEX > parseInt(30))_break();
            
               
               
               ///Чистим
               solver_properties_clear("capmonster")
               /// Формирумем основной запрос
               solver_property("capmonster","serverurl","https://api.captcha.guru/")
               solver_property("capmonster","coordinatescaptcha","1")
               solver_property("capmonster","key",VAR_KEY_MODULE)
               solver_property("capmonster","textinstructions",VAR_SET_TASK)
               solver_property("capmonster","click","hcap")
               solver_property("capmonster","method","post")
               //// Отправляем
               solve_base64_no_fail("capmonster", VAR_IMAGE_BASE_64)!
               VAR_SAVED_CONTENT = _result();
               

               
               
               _set_if_expression("W1tTQVZFRF9DT05URU5UXV0uaW5kZXhPZigiRVJST1JfQ0FQVENIQV9VTlNPTFZBQkxFIikgPj0gMA==");
               _if(VAR_SAVED_CONTENT.indexOf("ERROR_CAPTCHA_UNSOLVABLE") >= 0,function(){
               
                  
                  
                  cache_data_clear()!
                  

                  
                  
                  VAR_NUMBER_CRUMB = "0"
                  

                  
                  
                  VAR_HCAPTCHA_INVISIBLE = parseInt(VAR_HCAPTCHA_INVISIBLE) + parseInt(1)
                  

                  
                  
                  _set_if_expression("W1tSRUxPQURfQlVUVE9OX1ldXSA+IFtbQlJPV1NFUl9IRUlHSFRdXQ==");
                  _if(VAR_RELOAD_BUTTON_Y > VAR_BROWSER_HEIGHT,function(){
                  
                     
                     
                     /*Browser*/
                     _scroll_to(VAR_RELOAD_BUTTON_Y)!
                     

                  })!
                  

                  
                  
                  _get_browser_screen_settings()!
                  ;(function(){
                  var result = JSON.parse(_result())
                  VAR_SCROLL_X = result["ScrollX"]
                  VAR_SCROLL_Y = result["ScrollY"]
                  VAR_CURSOR_X = result["CursorX"]
                  VAR_CURSOR_Y = result["CursorY"]
                  VAR_BROWSER_WIDTH = result["Width"]
                  VAR_BROWSER_HEIGHT = result["Height"]
                  })();
                  

                  
                  
                  _cycle_params().if_else = VAR_IS_CHANGED_SCROLL_Y != VAR_SCROLL_Y;
                  _set_if_expression("W1tJU19DSEFOR0VEX1NDUk9MTF9ZXV0gIT0gW1tTQ1JPTExfWV1d");
                  _if(_cycle_params().if_else,function(){
                  
                     
                     
                     VAR_ELEMENT_SELECTOR = VAR_HCAPTCHA_PREFIX_SECOND_FRAME + "\u003eCSS\u003e .refresh"
                     

                     
                     
                     _SELECTOR = VAR_ELEMENT_SELECTOR;
                     get_element_selector(_SELECTOR, false).script("(function(){var rect = self.getBoundingClientRect();return (rect.left + positionx).toString() + '|' + (rect.top + positiony).toString() + '|' + (rect.right - rect.left).toString() + '|' + (rect.bottom - rect.top).toString()})();")!
                     var split = _result().split("|");
                     var x = parseInt(split[0]), y = parseInt(split[1]), w = parseInt(split[2]), h = parseInt(split[3]);
                     _get_browser_screen_settings()!
                     var result_hcaptcha = JSON.parse(_result());
                     var scroll_x = result_hcaptcha["ScrollX"], scroll_y = result_hcaptcha["ScrollY"]
                     var margin_top_bottom = 50; //percent
                     var margin_left_top = 50; // percent
                     div = 1;
                     var x_min = x + w/100*margin_left_top + parseInt(scroll_x), x_max = x+w/div-w/100*margin_left_top + parseInt(scroll_x);
                     var y_min = y + h/100*margin_top_bottom + parseInt(scroll_y), y_max = y+h - h/100*margin_top_bottom + parseInt(scroll_y);
                     x = rand(x_min, x_max);
                     y = rand(y_min, y_max);
                     x = x.toFixed();
                     y = y.toFixed();
                     /// Кнопка Reload
                     VAR_RELOAD_BUTTON_X = parseInt(x);
                     VAR_RELOAD_BUTTON_Y = parseInt(y);
                     

                  })!
                  

                  
                  
                  /*Browser*/
                  ;_SELECTOR=VAR_HCAPTCHA_PREFIX_SECOND_FRAME + "\u003eCSS\u003e .refresh";
                  get_element_selector(_SELECTOR, false).nowait().exist()!
                  VAR_IS_EXISTS = _result() == 1
                  _if(VAR_IS_EXISTS, function(){
                  get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
                  VAR_IS_EXISTS = _result().indexOf("true")>=0
                  })!
                  

                  
                  
                  _set_if_expression("W1tJU19FWElTVFNdXQ==");
                  _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
                  
                     
                     
                     /*Browser*/
                     move(VAR_RELOAD_BUTTON_X  + rand (-6,6),VAR_RELOAD_BUTTON_Y  + rand (-6,6),  {"speed": VAR_SPEED,"gravity": VAR_GRAVITY,"deviation": VAR_DEVIATION} )!
                     mouse(VAR_RELOAD_BUTTON_X  + rand (-6,6),VAR_RELOAD_BUTTON_Y  + rand (-6,6))!
                     

                  })!
                  

                  
                  
                  sleep(1000)!
                  

                  
                  
                  VAR_WAS_ERROR = false
                  

                  
                  
                  _break("function")
                  

               })!
               

               
               
               _set_if_expression("W1tTQVZFRF9DT05URU5UXV0uaW5kZXhPZigiRVJST1JfV1JPTkdfVVNFUl9LRVkiKSA+PSAw");
               _if(VAR_SAVED_CONTENT.indexOf("ERROR_WRONG_USER_KEY") >= 0,function(){
               
                  
                  
                  VAR_ERROR_KEY = "1"
                  

                  
                  
                  _break("function")
                  

               })!
               

               
               
               _set_if_expression("W1tTQVZFRF9DT05URU5UXV0uaW5kZXhPZigiRVJST1JfWkVST19CQUxBTkNFIikgPj0gMA==");
               _if(VAR_SAVED_CONTENT.indexOf("ERROR_ZERO_BALANCE") >= 0,function(){
               
                  
                  
                  VAR_ERROR_BALANCE = "1"
                  

                  
                  
                  _break("function")
                  

               })!
               

               
               
               _set_if_expression("W1tTQVZFRF9DT05URU5UXV0uaW5kZXhPZigiQ0FQVENIQV9GQUlMIikgPj0gMA==");
               _if(VAR_SAVED_CONTENT.indexOf("CAPTCHA_FAIL") >= 0,function(){
               
                  
                  
                  VAR_CAPTCHA_FAIL = "1"
                  

                  
                  
                  _break("function")
                  

               })!
               

               
               
               _cycle_params().if_else = VAR_SAVED_CONTENT.match(/[0-9]/);
               _set_if_expression("W1tTQVZFRF9DT05URU5UXV0ubWF0Y2goL1swLTldLyk=");
               _if(_cycle_params().if_else,function(){
               
                  
                  
                  VAR_LISTS_COORDINATES = VAR_SAVED_CONTENT
                  VAR_LISTS_COORDINATES = VAR_LISTS_COORDINATES.split("coordinates:")[1];
                  VAR_LISTS_COORDINATES = VAR_LISTS_COORDINATES.split(";");
                  

                  
                  
                  ;(function (a) {var j, x, i;for (i = a.length; i; i--) {j = Math.floor(Math.random() * i);x = a[i - 1]; a[i - 1] = a[j];a[j] = x;}})(VAR_LISTS_COORDINATES)
                  

                  
                  
                  VAR_FOREACH_DATA = 0
                  

                  
                  
                  _do_with_params({"foreach_data":(VAR_LISTS_COORDINATES)},function(){
                  _set_action_info({ name: "Foreach" });
                  VAR_CYCLE_INDEX = _iterator() - 1
                  if(VAR_CYCLE_INDEX > _cycle_param("foreach_data").length - 1)_break();
                  VAR_FOREACH_DATA = _cycle_param("foreach_data")[VAR_CYCLE_INDEX]
                  
                     
                     
                     var csv_parse_result = csv_parse(VAR_FOREACH_DATA)
                     VAR_ANSWER_X = csv_parse_result[0]
                     if(typeof(VAR_ANSWER_X) == 'undefined' || !VAR_ANSWER_X)
                     {
                     VAR_ANSWER_X = ""
                     }
                     VAR_ANSWER_Y = csv_parse_result[1]
                     if(typeof(VAR_ANSWER_Y) == 'undefined' || !VAR_ANSWER_Y)
                     {
                     VAR_ANSWER_Y = ""
                     }
                     

                     
                     
                     VAR_ANSWER_X = VAR_ANSWER_X.replace(/[^0-9]/g, '');
                     VAR_ANSWER_Y = VAR_ANSWER_Y.replace(/[^0-9]/g, '');
                     VAR_ANSWER_X = parseInt(VAR_ANSWER_X)
                     VAR_ANSWER_Y = parseInt(VAR_ANSWER_Y)
                     

                     
                     
                     /*Browser*/
                     move(VAR_SQUARE_BUTTON_X + VAR_ANSWER_X + rand (-12,+12),VAR_SQUARE_BUTTON_Y + VAR_ANSWER_Y + rand (-12,+12),  {"speed": VAR_SPEED,"gravity": VAR_GRAVITY,"deviation": VAR_DEVIATION} )!
                     mouse(VAR_SQUARE_BUTTON_X + VAR_ANSWER_X + rand (-12,+12),VAR_SQUARE_BUTTON_Y + VAR_ANSWER_Y + rand (-12,+12))!
                     

                     
                     
                     VAR_WAS_ERROR = false
                     

                  })!
                  

                  
                  
                  /*Browser*/
                  ;_SELECTOR=VAR_HCAPTCHA_PREFIX_SECOND_FRAME + "\u003eXPATH\u003e//div[@class=\u0022crumb-bg\u0022]";
                  get_element_selector(_SELECTOR, false).nowait().exist()!
                  VAR_IS_EXISTS = _result() == 1
                  _if(VAR_IS_EXISTS, function(){
                  get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
                  VAR_IS_EXISTS = _result().indexOf("true")>=0
                  })!
                  

                  
                  
                  _set_if_expression("IVtbSVNfRVhJU1RTXV0=");
                  _if(!VAR_IS_EXISTS,function(){
                  
                     
                     
                     VAR_NUMBER_CRUMB = "0"
                     

                     
                     
                     VAR_HCAPTCHA_INVISIBLE = parseInt(VAR_HCAPTCHA_INVISIBLE) + parseInt(1)
                     

                     
                     
                     cache_data_clear()!
                     

                  })!
                  

                  
                  
                  _set_if_expression("W1tJU19FWElTVFNdXQ==");
                  _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
                  
                     
                     
                     _set_if_expression("W1tOVU1CRVJfQ1JVTUJdXSA9PSAw");
                     _if(VAR_NUMBER_CRUMB == 0,function(){
                     
                        
                        
                        /*Browser*/
                        ;_SELECTOR=VAR_HCAPTCHA_PREFIX_SECOND_FRAME + "\u003eXPATH\u003e//div[@class=\u0022Crumb\u0022]";
                        get_element_selector(_SELECTOR, true).length()!
                        VAR_ELEMENT_LENGTH = _result()
                        

                        
                        
                        _set_if_expression("W1tFTEVNRU5UX0xFTkdUSF1dID4gMA==");
                        _if(VAR_ELEMENT_LENGTH > 0,function(){
                        
                           
                           
                           VAR_NUMBER_CRUMB = parseInt(VAR_NUMBER_CRUMB) + parseInt(1)
                           

                        })!
                        

                     })!
                     

                     
                     
                     _set_if_expression("W1tOVU1CRVJfQ1JVTUJdXSA9PSBbW0VMRU1FTlRfTEVOR1RIXV0=");
                     _if(VAR_NUMBER_CRUMB == VAR_ELEMENT_LENGTH,function(){
                     
                        
                        
                        VAR_NUMBER_CRUMB = "0"
                        

                        
                        
                        VAR_HCAPTCHA_INVISIBLE = parseInt(VAR_HCAPTCHA_INVISIBLE) + parseInt(1)
                        

                        
                        
                        cache_data_clear()!
                        

                     })!
                     

                  })!
                  

                  
                  
                  _set_if_expression("W1tTVUJNSVRfQlVUVE9OX1ldXSA+IFtbQlJPV1NFUl9IRUlHSFRdXQ==");
                  _if(VAR_SUBMIT_BUTTON_Y > VAR_BROWSER_HEIGHT,function(){
                  
                     
                     
                     /*Browser*/
                     _scroll_to(VAR_SUBMIT_BUTTON_Y)!
                     

                  })!
                  

                  
                  
                  _get_browser_screen_settings()!
                  ;(function(){
                  var result = JSON.parse(_result())
                  VAR_SCROLL_X = result["ScrollX"]
                  VAR_SCROLL_Y = result["ScrollY"]
                  VAR_CURSOR_X = result["CursorX"]
                  VAR_CURSOR_Y = result["CursorY"]
                  VAR_BROWSER_WIDTH = result["Width"]
                  VAR_BROWSER_HEIGHT = result["Height"]
                  })();
                  

                  
                  
                  _cycle_params().if_else = VAR_IS_CHANGED_SCROLL_Y != VAR_SCROLL_Y;
                  _set_if_expression("W1tJU19DSEFOR0VEX1NDUk9MTF9ZXV0gIT0gW1tTQ1JPTExfWV1d");
                  _if(_cycle_params().if_else,function(){
                  
                     
                     
                     VAR_ELEMENT_SELECTOR = VAR_HCAPTCHA_PREFIX_SECOND_FRAME + "\u003eCSS\u003e .button-submit"
                     

                     
                     
                     _SELECTOR = VAR_ELEMENT_SELECTOR;
                     get_element_selector(_SELECTOR, false).script("(function(){var rect = self.getBoundingClientRect();return (rect.left + positionx).toString() + '|' + (rect.top + positiony).toString() + '|' + (rect.right - rect.left).toString() + '|' + (rect.bottom - rect.top).toString()})();")!
                     var split = _result().split("|");
                     var x = parseInt(split[0]), y = parseInt(split[1]), w = parseInt(split[2]), h = parseInt(split[3]);
                     _get_browser_screen_settings()!
                     var newresult = JSON.parse(_result());
                     var scroll_x = newresult["ScrollX"], scroll_y = newresult["ScrollY"]
                     var margin_top_bottom = 50; //percent
                     var margin_left_top = 50; // percent
                     div = 1;
                     var x_min = x + w/100*margin_left_top + parseInt(scroll_x), x_max = x+w/div-w/100*margin_left_top + parseInt(scroll_x);
                     var y_min = y + h/100*margin_top_bottom + parseInt(scroll_y), y_max = y+h - h/100*margin_top_bottom + parseInt(scroll_y);
                     x = rand(x_min, x_max);
                     y = rand(y_min, y_max);
                     x = x.toFixed();
                     y = y.toFixed();
                     /// Кнопка подтвердить
                     VAR_SUBMIT_BUTTON_X = parseInt(x);
                     VAR_SUBMIT_BUTTON_Y = parseInt(y);
                     

                  })!
                  

                  
                  
                  /*Browser*/
                  move(VAR_SUBMIT_BUTTON_X + rand (-15,15),VAR_SUBMIT_BUTTON_Y + rand (-6,6),  {"speed": VAR_SPEED,"gravity": VAR_GRAVITY,"deviation": VAR_DEVIATION} )!
                  mouse(VAR_SUBMIT_BUTTON_X + rand (-15,15),VAR_SUBMIT_BUTTON_Y + rand (-6,6))!
                  

                  
                  
                  _set_if_expression("W1tOVU1CRVJfQ1JVTUJdXSA9PSAw");
                  _if(VAR_NUMBER_CRUMB == 0,function(){
                  
                     
                     
                     VAR_HCAPTCHA_INVISIBLE = parseInt(VAR_HCAPTCHA_INVISIBLE) + parseInt(1)
                     

                     
                     
                     sleep(rand(100,300))!
                     

                  })!
                  

                  
                  
                  _set_if_expression("W1tOVU1CRVJfQ1JVTUJdXSAhPSAw");
                  _if(VAR_NUMBER_CRUMB != 0,function(){
                  
                     
                     
                     VAR_NUMBER_CRUMB = parseInt(VAR_NUMBER_CRUMB) + parseInt(1)
                     

                     
                     
                     sleep(100)!
                     

                  })!
                  

                  
                  
                  _break("function")
                  

               })!
               

               
               
               _if(!_cycle_params().if_else,function(){
               
                  
                  
                  sleep(rand(600,950))!
                  

                  
                  
                  _next("function")
                  

               })!
               delete _cycle_params().if_else;
               

            })!
            

            
            
            _next("function")
            

         },null)!
         

         
         
         _set_if_expression("W1tXQVNfRVJST1JdXQ==");
         _if(typeof(VAR_WAS_ERROR) !== "undefined" ? (VAR_WAS_ERROR) : undefined,function(){
         
            
            
            sleep(1000)!
            

            
            
            _next("function")
            

         })!
         

      })!
      

   }
   

function CaptchaImageClick_ReCaptcha2()
   {
   
      
      
      VAR_GLOBAL_SELECTOR = _function_argument("SELECTOR")
      

      
      
      VAR_SPEED_MOUSE = _function_argument("SPEED_MOUSE")
      

      
      
      VAR_URL_MODULE = _function_argument("URL")
      

      
      
      VAR_KEY_MODULE = _function_argument("KEY")
      

      
      
      VAR_METHOD_MODULE = _function_argument("METHOD")
      

      
      
      VAR_TRY_NUMBER = _function_argument("TRY_NUMBER")
      

      
      
      VAR_NUMBER_CAPTCHA_MODULE = _function_argument("NUMBER_CAPTCHA")
      

      
      
      VAR_IS_INVISIBLE_CAPTCHA = _function_argument("IS_INVISIBLE_CAPTCHA")
      

      
      
      VAR_ERROR_LOAD = "0"
      

      
      
      VAR_ERROR_FIND_MAIN_SELECTOR = "0"
      

      
      
      VAR_RECAPTCHA_2_INVISIBLE = "0"
      

      
      
      VAR_RECAPTCHA_PREFIX_SECOND_FRAME = ""
      

      
      
      VAR_ERROR_KEY = "0"
      

      
      
      VAR_ERROR_BALANCE = "0"
      

      
      
      VAR_ERROR_LANG = "0"
      

      
      
      VAR_IS_CHANGED_SCROLL_Y = 0
      

      
      
      VAR_ERROR_PICK_IMAGE = 0
      

      
      
      VAR_RECAPTCHA_MODULE_ENABLED = 0
      

      
      
      VAR_HCAPTCHA_MODULE_ENABLED = 0
      

      
      
      VAR_FUNCATPCHA_MODULE_ENABLED = 0
      

      
      
      VAR_NAME_MODULE_AUTOSUBMIT = "NaN"
      

      
      
      VAR_GREEN_TICK = false
      

      
      
      /*Browser*/
      cache_allow("recaptcha/*/payload")!
      

      
      
      //// Проверить установлены ли модули с автосабмитом.
      if (typeof NumbersParseRecaptcha2 === 'function') VAR_RECAPTCHA_MODULE_ENABLED = 1, VAR_NAME_MODULE_AUTOSUBMIT = "ReCaptcha 2 Autosubmit";
      if (typeof BASCaptchaSolver.helpers.HCaptchaHelper === 'function') VAR_HCAPTCHA_MODULE_ENABLED = 1, VAR_NAME_MODULE_AUTOSUBMIT = "hCaptcha Autosubmit";
      if (typeof BASCaptchaSolver.helpers.FunCaptchaHelper === 'function') VAR_FUNCAPTCHA_MODULE_ENABLED = 1, VAR_NAME_MODULE_AUTOSUBMIT = "FunCaptcha Autosubmit";
      

      
      
      _set_if_expression("W1tGVU5DQVRQQ0hBX01PRFVMRV9FTkFCTEVEXV0gPT0gMSB8fCBbW1JFQ0FQVENIQV9NT0RVTEVfRU5BQkxFRF1dID09IDEgfHwgW1tIQ0FQVENIQV9NT0RVTEVfRU5BQkxFRF1dID09IDE=");
      _if(VAR_FUNCATPCHA_MODULE_ENABLED == 1 || VAR_RECAPTCHA_MODULE_ENABLED == 1 || VAR_HCAPTCHA_MODULE_ENABLED == 1,function(){
      
         
         
         fail((_K==="en" ? "Solve the captcha failed, to continue solving captchas by clicks requires to disable module " +VAR_NAME_MODULE_AUTOSUBMIT + " and retry solving captcha by clicks" : "Решить капчу не удалось, для продолжения решения капчи кликами требуется отключить сторонний встроенный модуль в BAS: " +VAR_NAME_MODULE_AUTOSUBMIT + " и повторить попытку"));
         

      })!
      

      
      
      _set_if_expression("W1tJU19JTlZJU0lCTEVfQ0FQVENIQV1d");
      _if(typeof(VAR_IS_INVISIBLE_CAPTCHA) !== "undefined" ? (VAR_IS_INVISIBLE_CAPTCHA) : undefined,function(){
      
         
         
         _call(function()
         {
         _on_fail(function(){
         VAR_LAST_ERROR = _result()
         VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
         VAR_WAS_ERROR = false
         _break(1,true)
         })
         CYCLES.Current().RemoveLabel("function")
         
            
            
            /*Browser*/
            waiter_timeout_next(45000)
            wait_load("recaptcha/*/payload")!
            

            
            
            sleep(1000)!
            

         },null)!
         

         
         
         _set_if_expression("W1tXQVNfRVJST1JdXQ==");
         _if(typeof(VAR_WAS_ERROR) !== "undefined" ? (VAR_WAS_ERROR) : undefined,function(){
         
            
            
            fail(VAR_LAST_ERROR)
            

         })!
         

      })!
      

      
      
      _call(function()
      {
      _on_fail(function(){
      VAR_LAST_ERROR = _result()
      VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
      VAR_WAS_ERROR = false
      _break(1,true)
      })
      CYCLES.Current().RemoveLabel("function")
      
         
         
         if (VAR_SPEED_MOUSE == "Slow")
         {
         VAR_SPEED = 100;
         VAR_GRAVITY = 6;
         VAR_DEVIATION = 2.5;
         }
         if (VAR_SPEED_MOUSE == "Normal")
         {
         VAR_SPEED = 200;
         VAR_GRAVITY = 12;
         VAR_DEVIATION = 5;
         }
         if (VAR_SPEED_MOUSE == "Fast")
         {
         VAR_SPEED = 300;
         VAR_GRAVITY = 18;
         VAR_DEVIATION = 7.5;
         }
         if (VAR_SPEED_MOUSE == "Very Fast")
         {
         VAR_SPEED = 400;
         VAR_GRAVITY = 24;
         VAR_DEVIATION = 10;
         }
         if (VAR_SPEED_MOUSE == "Extremal")
         {
         VAR_SPEED = 500;
         VAR_GRAVITY = 30;
         VAR_DEVIATION = 12.5;
         }
         

         
         
         page().script2("[[IS_MOBILE]] = navigator.maxTouchPoints;",JSON.stringify(_read_variables(["VAR_IS_MOBILE"])))!
         var _parse_result = JSON.parse(_result())
         _write_variables(JSON.parse(_parse_result.variables))
         if(!_parse_result.is_success)
         fail(_parse_result.error)
         

         
         
         _set_if_expression("W1tJU19NT0JJTEVdXSA9PSAwICYmIHJhbmQgKDEsMTApID4gNQ==");
         _if(VAR_IS_MOBILE == 0 && rand (1,10) > 5,function(){
         
            
            
            _do(function(){
            _set_action_info({ name: "While" });
            VAR_CYCLE_INDEX = _iterator() - 1
            BREAK_CONDITION = VAR_CYCLE_INDEX < 2 && VAR_IS_MOBILE == 0;
            if(!BREAK_CONDITION)_break();
            
               
               
               _get_browser_screen_settings()!
               ;(function(){
               var result = JSON.parse(_result())
               VAR_SCROLL_X = result["ScrollX"]
               VAR_SCROLL_Y = result["ScrollY"]
               VAR_CURSOR_X = result["CursorX"]
               VAR_CURSOR_Y = result["CursorY"]
               VAR_BROWSER_WIDTH = result["Width"]
               VAR_BROWSER_HEIGHT = result["Height"]
               })();
               

               
               
               var scroll_x=parseInt(VAR_CURSOR_Y);
               var scroll_y=parseInt(VAR_SCROLL_Y);
               var browser_h=parseInt(VAR_BROWSER_HEIGHT);
               //-------------------- Привели все в числа, считаем позицию ---------------------
               var absolut_y = VAR_CURSOR_Y + VAR_SCROLL_Y;
               var y_without_scroll = absolut_y - VAR_SCROLL_Y;
               var check_y_top = VAR_BROWSER_HEIGHT/12;
               var check_y_down = VAR_BROWSER_HEIGHT/100*92;
               var move_y_top = VAR_BROWSER_HEIGHT/10;
               var move_y_down = VAR_BROWSER_HEIGHT/100*80;
               // -------------------------- Округляем ----------------------------------
               VAR_CHECK_Y_TOP = check_y_top.toFixed();
               VAR_CHECK_Y_DOWN = check_y_down.toFixed();
               VAR_Y_WITHOUNT_SCROLL = y_without_scroll.toFixed();
               VAR_MOVE_Y_TOP = move_y_top.toFixed();
               VAR_MOVE_Y_DOWN = move_y_down.toFixed();
               // ----------------- Снова приводим к числу ------------------------
               VAR_CHECK_Y_TOP=parseInt(VAR_CHECK_Y_TOP);
               VAR_CHECK_Y_DOWN=parseInt(VAR_CHECK_Y_DOWN);
               VAR_Y_WITHOUNT_SCROLL=parseInt(VAR_Y_WITHOUNT_SCROLL);
               VAR_MOVE_Y_TOP=parseInt(VAR_MOVE_Y_TOP);
               VAR_MOVE_Y_DOWN=parseInt(VAR_MOVE_Y_DOWN);
               

               
               
               /*Browser*/
               move(rand(VAR_BROWSER_WIDTH/5,VAR_BROWSER_WIDTH/1.3),rand(VAR_MOVE_Y_TOP + VAR_SCROLL_Y,VAR_MOVE_Y_DOWN + VAR_SCROLL_Y),  {} )!
               

               
               
               _set_if_expression("cmFuZCAoMSwxMCkgPiA1");
               _if(rand (1,10) > 5,function(){
               
                  
                  
                  _break("function")
                  

               })!
               

            })!
            

         })!
         

         
         
         VAR_RECAPTCHA_PREFIX = VAR_GLOBAL_SELECTOR;
         VAR_RECAPTCHA_PREFIX_FIRST_FRAME = VAR_RECAPTCHA_PREFIX;
         {
         var index = VAR_RECAPTCHA_PREFIX.toString().lastIndexOf(">FRAME>")
         if(index >= 0)
         VAR_RECAPTCHA_PREFIX = VAR_RECAPTCHA_PREFIX.substring(0,index)
         VAR_RECAPTCHA_PREFIX_FIRST_FRAME = VAR_RECAPTCHA_PREFIX
         index = VAR_RECAPTCHA_PREFIX.toString().lastIndexOf(">FRAME>")
         if(index >= 0)
         VAR_RECAPTCHA_PREFIX = VAR_RECAPTCHA_PREFIX.substring(0,index + ">FRAME>".length)
         else
         VAR_RECAPTCHA_PREFIX = ""
         }
         

         
         
         //// Проверить бан айпи
         get_element_selector(VAR_RECAPTCHA_PREFIX_SECOND_FRAME).script("document.getElementsByClassName('rc-doscaptcha-body-text').length")!
         if(parseInt(_result()) > 0)
         fail((_K==="en" ? "IP address banned Repaptcha 2. Automated queries" : "IP адрес забанен ReСaptсha2 за автоматические запросы"));
         

         
         
         //////// Проверить открылось ли окно капчи (Невидимая рекаптча 2 случай)
         _SELECTOR = VAR_RECAPTCHA_PREFIX_FIRST_FRAME;
         get_element_selector(_SELECTOR).script("(function(){var el = Array.prototype.slice.call(document.getElementsByTagName('iframe')).find(function(el){return(el.src.indexOf('/bframe')>=0 && getComputedStyle(el)['visibility'] == 'visible')});if(el){el=el['name']}else{el=''};return el;})()")!
         if(_result().length>0)
         {
         VAR_RECAPTCHA_PREFIX_SECOND_FRAME = VAR_RECAPTCHA_PREFIX + ">CSS>iframe[name=\"" + _result() + "\"]" + ">AT>" + VAR_NUMBER_CAPTCHA_MODULE + ">FRAME> >CSS> body";
         VAR_RECAPTCHA_PREFIX_SECOND_FRAME_ELEMENT = VAR_RECAPTCHA_PREFIX + ">CSS>iframe[name=\"" + _result() + "\"]" + ">AT>" + VAR_NUMBER_CAPTCHA_MODULE
         }
         

         
         
         _cycle_params().if_else = VAR_RECAPTCHA_PREFIX_SECOND_FRAME == "";
         _set_if_expression("W1tSRUNBUFRDSEFfUFJFRklYX1NFQ09ORF9GUkFNRV1dID09ICIi");
         _if(_cycle_params().if_else,function(){
         
            
            
            _do(function(){
            _set_action_info({ name: "For" });
            VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
            if(VAR_CYCLE_INDEX > parseInt(40))_break();
            
               
               
               /*Browser*/
               ;_SELECTOR=VAR_GLOBAL_SELECTOR;
               get_element_selector(_SELECTOR, false).nowait().exist()!
               VAR_IS_EXISTS = _result() == 1
               _if(VAR_IS_EXISTS, function(){
               get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
               VAR_IS_EXISTS = _result().indexOf("true")>=0
               })!
               

               
               
               _cycle_params().if_else = typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined;
               _set_if_expression("W1tJU19FWElTVFNdXQ==");
               _if(_cycle_params().if_else,function(){
               
                  
                  
                  _cycle_params().if_else = VAR_GLOBAL_SELECTOR == ">CSS>iframe[src*='anchor']>FRAME> >CSS> #recaptcha-anchor-label";
                  _set_if_expression("W1tHTE9CQUxfU0VMRUNUT1JdXSA9PSAiPkNTUz5pZnJhbWVbc3JjKj0nYW5jaG9yJ10+RlJBTUU+ID5DU1M+ICNyZWNhcHRjaGEtYW5jaG9yLWxhYmVsIg==");
                  _if(_cycle_params().if_else,function(){
                  
                     
                     
                     VAR_RANDOM_NUMBER_CLICK = Math.floor(Math.random() * (parseInt(10) - parseInt(1) + 1)) + parseInt(1)
                     

                     
                     
                     _set_if_expression("W1tSQU5ET01fTlVNQkVSX0NMSUNLXV0gPD0gNA==");
                     _if(VAR_RANDOM_NUMBER_CLICK <= 4,function(){
                     
                        
                        
                        /*Browser*/
                        _SELECTOR = VAR_GLOBAL_SELECTOR;waiter_timeout_next(8000)
                        wait_element_visible(_SELECTOR)!
                        _call(_random_point, {})!
                        _if(_result().length > 0, function(){
                        move( {} )!
                        get_element_selector(_SELECTOR, false).clarify(X,Y)!
                        _call(_clarify, {} )!
                        mouse(X,Y)!
                        })!
                        

                     })!
                     

                     
                     
                     _set_if_expression("W1tSQU5ET01fTlVNQkVSX0NMSUNLXV0gPiA0ICYmIFtbUkFORE9NX05VTUJFUl9DTElDS11dIDw9IDc=");
                     _if(VAR_RANDOM_NUMBER_CLICK > 4 && VAR_RANDOM_NUMBER_CLICK <= 7,function(){
                     
                        
                        
                        /*Browser*/
                        _SELECTOR = "\u003eCSS\u003eiframe[src*=\u0027anchor\u0027]\u003eFRAME\u003e \u003eCSS\u003e div[class$=\u0022checkbox-border\u0022]";waiter_timeout_next(8000)
                        wait_element_visible(_SELECTOR)!
                        _call(_random_point, {})!
                        _if(_result().length > 0, function(){
                        move( {} )!
                        get_element_selector(_SELECTOR, false).clarify(X,Y)!
                        _call(_clarify, {} )!
                        mouse(X,Y)!
                        })!
                        

                     })!
                     

                     
                     
                     _set_if_expression("W1tSQU5ET01fTlVNQkVSX0NMSUNLXV0gPiA3");
                     _if(VAR_RANDOM_NUMBER_CLICK > 7,function(){
                     
                        
                        
                        /*Browser*/
                        _SELECTOR = "\u003eCSS\u003eiframe[src*=\u0027anchor\u0027]\u003eFRAME\u003e \u003eCSS\u003e div[class^=\u0022rc-anchor-content\u0022]";waiter_timeout_next(8000)
                        wait_element_visible(_SELECTOR)!
                        _call(_random_point, {})!
                        _if(_result().length > 0, function(){
                        move( {} )!
                        get_element_selector(_SELECTOR, false).clarify(X,Y)!
                        _call(_clarify, {} )!
                        mouse(X,Y)!
                        })!
                        

                     })!
                     

                  })!
                  

                  
                  
                  _if(!_cycle_params().if_else,function(){
                  
                     
                     
                     /*Browser*/
                     _SELECTOR = VAR_GLOBAL_SELECTOR;waiter_timeout_next(8000)
                     wait_element_visible(_SELECTOR)!
                     _call(_random_point, {})!
                     _if(_result().length > 0, function(){
                     move( {} )!
                     get_element_selector(_SELECTOR, false).clarify(X,Y)!
                     _call(_clarify, {} )!
                     mouse(X,Y)!
                     })!
                     

                  })!
                  delete _cycle_params().if_else;
                  

                  
                  
                  _break("function")
                  

               })!
               

               
               
               _if(!_cycle_params().if_else,function(){
               
                  
                  
                  sleep(rand(400,900))!
                  

               })!
               delete _cycle_params().if_else;
               

               
               
               _set_if_expression("IVtbSVNfRVhJU1RTXV0=");
               _if(!VAR_IS_EXISTS,function(){
               
                  
                  
                  _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gcmFuZCAoMjUsMzIp");
                  _if(VAR_CYCLE_INDEX > rand (25,32),function(){
                  
                     
                     
                     VAR_ERROR_FIND_MAIN_SELECTOR = "1"
                     

                  })!
                  

               })!
               

            })!
            

         })!
         

         
         
         _if(!_cycle_params().if_else,function(){
         
            
            
            VAR_RECAPTCHA_2_INVISIBLE = "1"
            

         })!
         delete _cycle_params().if_else;
         

      },null)!
      

      
      
      _set_if_expression("W1tXQVNfRVJST1JdXQ==");
      _if(typeof(VAR_WAS_ERROR) !== "undefined" ? (VAR_WAS_ERROR) : undefined,function(){
      
         
         
         /*Browser*/
         cache_data_clear()!
         

         
         
         fail(VAR_LAST_ERROR)
         

      })!
      

      
      
      _set_if_expression("W1tFUlJPUl9GSU5EX01BSU5fU0VMRUNUT1JdXSA9PSAx");
      _if(VAR_ERROR_FIND_MAIN_SELECTOR == 1,function(){
      
         
         
         /*Browser*/
         cache_data_clear()!
         

         
         
         fail((_K==="en" ? "Could not wait for the main ReCaptcha 2 selector to load with the 'I am not robot' button" : "Не удалось дождаться загрузки основного селектора ReCaptcha 2 c кнопкой 'Я не робот'"));
         

      })!
      

      
      
      VAR_TRY_CAPTCHA = "0"
      

      
      
      VAR_BAS_CAPMONSTER_IMAGE_ID = "0"
      

      
      
      VAR_RECAPTCHA_2_CLOSED = "0"
      

      
      
      VAR_CAPTCHA_FAIL = "0"
      

      
      
      VAR_ERROR_LOAD = "0"
      

      
      
      VAR_COORDINATES_ALDREADY_GET_4X4 = "0"
      

      
      
      VAR_COORDINATES_ALDREADY_GET_3X3 = "0"
      

      
      
      VAR_FIRST_LOAD_CAPTCHA = true
      

      
      
      _set_goto_label("Recaptcha2 start here location")!
      

      
      
      _do(function(){
      _set_action_info({ name: "For" });
      VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
      if(VAR_CYCLE_INDEX > parseInt(500))_break();
      
         
         
         VAR_CYCLE_INDEX = 0
         

         
         
         _set_if_expression("W1tFUlJPUl9MT0FEXV0gPT0gMQ==");
         _if(VAR_ERROR_LOAD == 1,function(){
         
            
            
            /*Browser*/
            cache_data_clear()!
            

            
            
            fail((_K==="en" ? "Error Load frame Recaptcha2" : "Не удалось дождатся открытия окна капчи"));
            

         })!
         

         
         
         _set_if_expression("W1tFUlJPUl9LRVldXSA9PSAx");
         _if(VAR_ERROR_KEY == 1,function(){
         
            
            
            /*Browser*/
            cache_data_clear()!
            

            
            
            fail((_K==="en" ? "API secret key from captcha recognition service is wrong ERROR_WRONG_USER_KEY" : "Секретный ключ API от сервиса распознавания капчи неподходит ERROR_WRONG_USER_KEY"));
            

         })!
         

         
         
         _set_if_expression("W1tFUlJPUl9CQUxBTkNFXV0gPT0gMQ==");
         _if(VAR_ERROR_BALANCE == 1,function(){
         
            
            
            /*Browser*/
            cache_data_clear()!
            

            
            
            fail((_K==="en" ? "The balance on the captcha service has ended - ERROR_ZERO_BALANCE" : "Закончился баланс на сервисе распознавания капчи - ERROR_ZERO_BALANCE"));
            

         })!
         

         
         
         _set_if_expression("W1tDQVBUQ0hBX0ZBSUxdXSA9PSAx");
         _if(VAR_CAPTCHA_FAIL == 1,function(){
         
            
            
            /*Browser*/
            cache_data_clear()!
            

            
            
            fail((_K==="en" ? "Failed to complete the request to the captcha recognition server, error - CAPTCHA_FAIL" : "Не удалось выполнить запрос к серверу распознавания капчи, ошибка  - CAPTCHA_FAIL"));
            

         })!
         

         
         
         _set_if_expression("W1tNRVRIT0RfTU9EVUxFXV0gPT0gIkNhcHRjaGFHdXJ1IiAmJiBbW0tFWV9NT0RVTEVdXSA9PSAiIg==");
         _if(VAR_METHOD_MODULE == "CaptchaGuru" && VAR_KEY_MODULE == "",function(){
         
            
            
            fail_user("fail((_K===\u0022en\u0022 ? \u0022For the Captcha.Guru service you must specify a secret API key!\u0022 : \u0022Для сервиса Captсha.Guru необходимо указать секретный API ключ!\u0022));",false)
            

         })!
         

         
         
         _do(function(){
         _set_action_info({ name: "For" });
         VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
         if(VAR_CYCLE_INDEX > parseInt(180))_break();
         
            
            
            /*Browser*/
            ;_SELECTOR=VAR_RECAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eXPATH\u003e //*[@id=\u0022recaptcha-anchor\u0022][@aria-checked=\u0022true\u0022]";
            get_element_selector(_SELECTOR, false).nowait().exist()!
            VAR_IS_EXISTS = _result() == 1
            _if(VAR_IS_EXISTS, function(){
            get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
            VAR_IS_EXISTS = _result().indexOf("true")>=0
            })!
            

            
            
            _set_if_expression("W1tJU19FWElTVFNdXSA9PSB0cnVl");
            _if(VAR_IS_EXISTS == true,function(){
            
               
               
               VAR_GREEN_TICK = true
               

               
               
               /*Browser*/
               cache_data_clear()!
               

               
               
               _break("function")
               

            })!
            

            
            
            _set_if_expression("W1tSRUNBUFRDSEFfMl9JTlZJU0lCTEVdXSA9PSAwICYmIFtbRklSU1RfTE9BRF9DQVBUQ0hBXV0gPT0gZmFsc2U=");
            _if(VAR_RECAPTCHA_2_INVISIBLE == 0 && VAR_FIRST_LOAD_CAPTCHA == false,function(){
            
               
               
               /*Browser*/
               ;_SELECTOR=VAR_RECAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eXPATH\u003e //*[@id=\u0022recaptcha-anchor\u0022]";
               get_element_selector(_SELECTOR, false).nowait().exist()!
               VAR_IS_EXISTS = _result() == 1
               

               
               
               _set_if_expression("W1tJU19FWElTVFNdXSA9PSBmYWxzZQ==");
               _if(VAR_IS_EXISTS == false,function(){
               
                  
                  
                  VAR_GREEN_TICK = true
                  

                  
                  
                  /*Browser*/
                  cache_data_clear()!
                  

                  
                  
                  _break("function")
                  

               })!
               

            })!
            

            
            
            _set_if_expression("W1tSRUNBUFRDSEFfMl9JTlZJU0lCTEVdXSA+IDAgJiYgW1tGSVJTVF9MT0FEX0NBUFRDSEFdXSA9PSBmYWxzZQ==");
            _if(VAR_RECAPTCHA_2_INVISIBLE > 0 && VAR_FIRST_LOAD_CAPTCHA == false,function(){
            
               
               
               /*Browser*/
               ;_SELECTOR=VAR_RECAPTCHA_PREFIX_SECOND_FRAME + "\u003eXPATH\u003e id(\u0022rc-imageselect-target\u0022)";
               get_element_selector(_SELECTOR, false).nowait().exist()!
               VAR_IS_EXISTS = _result() == 1
               _if(VAR_IS_EXISTS, function(){
               get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
               VAR_IS_EXISTS = _result().indexOf("true")>=0
               })!
               

               
               
               _set_if_expression("W1tJU19FWElTVFNdXSA9PSBmYWxzZQ==");
               _if(VAR_IS_EXISTS == false,function(){
               
                  
                  
                  VAR_GREEN_TICK = true
                  

                  
                  
                  /*Browser*/
                  cache_data_clear()!
                  

                  
                  
                  _break("function")
                  

               })!
               

            })!
            

            
            
            //////// Проверить открылось ли окно капчи
            _SELECTOR = VAR_RECAPTCHA_PREFIX_FIRST_FRAME;
            get_element_selector(_SELECTOR).script("(function(){var el = Array.prototype.slice.call(document.getElementsByTagName('iframe')).find(function(el){return(el.src.indexOf('/bframe')>=0 && getComputedStyle(el)['visibility'] == 'visible')});if(el){el=el['name']}else{el=''};return el;})()")!
            if(_result().length>0)
            {
            VAR_RECAPTCHA_PREFIX_SECOND_FRAME = VAR_RECAPTCHA_PREFIX + ">CSS>iframe[name=\"" + _result() + "\"]" + ">AT>" + VAR_NUMBER_CAPTCHA_MODULE + ">FRAME> >CSS> body";
            VAR_RECAPTCHA_PREFIX_SECOND_FRAME_ELEMENT = VAR_RECAPTCHA_PREFIX + ">CSS>iframe[name=\"" + _result() + "\"]" + ">AT>" + VAR_NUMBER_CAPTCHA_MODULE
            _break()
            }
            

            
            
            /*Browser*/
            ;_SELECTOR=VAR_RECAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eXPATH\u003e id(\u0022rc-anchor-container\u0022)/div[@class=\u0022rc-anchor-error-msg-container\u0022]";
            get_element_selector(_SELECTOR, false).nowait().exist()!
            VAR_IS_EXISTS = _result() == 1
            _if(VAR_IS_EXISTS, function(){
            get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
            VAR_IS_EXISTS = _result().indexOf("true")>=0
            })!
            

            
            
            _set_if_expression("W1tJU19FWElTVFNdXSAmJiBbW0ZJUlNUX0xPQURfQ0FQVENIQV1dID09IGZhbHNl");
            _if(VAR_IS_EXISTS && VAR_FIRST_LOAD_CAPTCHA == false,function(){
            
               
               
               /*Browser*/
               _SELECTOR = VAR_RECAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eXPATH\u003e id(\u0022rc-anchor-container\u0022)/div[@class=\u0022rc-anchor-error-msg-container\u0022]";
               wait_element(_SELECTOR)!
               get_element_selector(_SELECTOR, false).text()!
               VAR_SAVED_TEXT = _result()
               

               
               
               /*Browser*/
               cache_data_clear()!
               

               
               
               fail(VAR_SAVED_TEXT)
               

            })!
            

            
            
            _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gMTAwICYmIFtbRklSU1RfTE9BRF9DQVBUQ0hBXV0gPT0gdHJ1ZQ==");
            _if(VAR_CYCLE_INDEX > 100 && VAR_FIRST_LOAD_CAPTCHA == true,function(){
            
               
               
               /*Browser*/
               cache_data_clear()!
               

               
               
               fail((_K==="en" ? "Failed to load captcha image window, internet connection too slow" : "Не удалось загрузить окно с картинками капчи, слишком медленное интернет соединение"));
               

            })!
            

            
            
            _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gMTAgJiYgW1tGSVJTVF9MT0FEX0NBUFRDSEFdXSA9PSBmYWxzZQ==");
            _if(VAR_CYCLE_INDEX > 10 && VAR_FIRST_LOAD_CAPTCHA == false,function(){
            
               
               
               /*Browser*/
               cache_data_clear()!
               

               
               
               fail((_K==="en" ? "Failed to solve the captcha. The captcha window is closed." : "Решить капчу не удалось. Окно с капчей не было открыто."));
               

            })!
            

            
            
            _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gOA==");
            _if(VAR_CYCLE_INDEX > 8,function(){
            
               
               
               //// Проверить бан айпи
               get_element_selector(VAR_RECAPTCHA_PREFIX_SECOND_FRAME).script("document.getElementsByClassName('rc-doscaptcha-body-text').length")!
               if(parseInt(_result()) > 0)
               fail((_K==="en" ? "IP address banned Repaptcha 2. Automated queries" : "IP адрес забанен ReСaptсha2 за автоматические запросы"));
               

            })!
            

         })!
         

         
         
         _set_if_expression("W1tHUkVFTl9USUNLXV0gPT0gdHJ1ZQ==");
         _if(VAR_GREEN_TICK == true,function(){
         
            
            
            delete VAR_GLOBAL_SELECTOR;
            

            
            
            _function_return("")
            

         })!
         

         
         
         VAR_FIRST_LOAD_CAPTCHA = false
         

         
         
         VAR_TRY_CAPTCHA = parseInt(VAR_TRY_CAPTCHA) + parseInt(1)
         

         
         
         _set_if_expression("W1tUUllfQ0FQVENIQV1dID4gW1tUUllfTlVNQkVSXV0=");
         _if(VAR_TRY_CAPTCHA > VAR_TRY_NUMBER,function(){
         
            
            
            /*Browser*/
            cache_data_clear()!
            

            
            
            fail((_K==="en" ? "Failed to solve the captcha. ReCaptcha 2 attempts limit exceeded" : "Решить капчу не удалось. Превышен лимит попыток решить ReCaptcha 2"));
            

         })!
         

         
         
         _call(function()
         {
         _on_fail(function(){
         VAR_LAST_ERROR = _result()
         VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
         VAR_WAS_ERROR = false
         _break(1,true)
         })
         CYCLES.Current().RemoveLabel("function")
         
            
            
            /*Browser*/
            ;_SELECTOR=VAR_RECAPTCHA_PREFIX_SECOND_FRAME + "\u003eXPATH\u003e //div[@class=\u0022rc-imageselect-error-select-more\u0022]";
            get_element_selector(_SELECTOR, false).nowait().exist()!
            VAR_IS_EXISTS_1 = _result() == 1
            _if(VAR_IS_EXISTS_1, function(){
            get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
            VAR_IS_EXISTS_1 = _result().indexOf("true")>=0
            })!
            

            
            
            /*Browser*/
            ;_SELECTOR=VAR_RECAPTCHA_PREFIX_SECOND_FRAME + "\u003eXPATH\u003e //div[@class=\u0022rc-imageselect-error-dynamic-more\u0022]";
            get_element_selector(_SELECTOR, false).nowait().exist()!
            VAR_IS_EXISTS_2 = _result() == 1
            _if(VAR_IS_EXISTS_2, function(){
            get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
            VAR_IS_EXISTS_2 = _result().indexOf("true")>=0
            })!
            

            
            
            _set_if_expression("W1tJU19FWElTVFNfMV1dIHx8IFtbSVNfRVhJU1RTXzJdXQ==");
            _if(VAR_IS_EXISTS_1 || VAR_IS_EXISTS_2,function(){
            
               
               
               VAR_BAS_CAPMONSTER_IMAGE_ID = "0"
               

               
               
               _set_if_expression("W1tSRUNBUFRDSEFfMl9JTlZJU0lCTEVdXSA9PSAx");
               _if(VAR_RECAPTCHA_2_INVISIBLE == 1,function(){
               
                  
                  
                  VAR_RECAPTCHA_2_INVISIBLE = parseInt(VAR_RECAPTCHA_2_INVISIBLE) + parseInt(1)
                  

               })!
               

               
               
               cache_data_clear()!
               

               
               
               sleep(1000)!
               

               
               
               /*Browser*/
               _SELECTOR = VAR_RECAPTCHA_PREFIX_SECOND_FRAME + "\u003eXPATH\u003e id(\u0022recaptcha-reload-button\u0022)";
               wait_element_visible(_SELECTOR)!
               _call(_random_point, {})!
               _if(_result().length > 0, function(){
               move( {"speed": VAR_SPEED,"gravity": VAR_GRAVITY,"deviation": VAR_DEVIATION} )!
               get_element_selector(_SELECTOR, false).clarify(X,Y)!
               _call(_clarify, {"speed": VAR_SPEED,"gravity": VAR_GRAVITY,"deviation": VAR_DEVIATION} )!
               mouse(X,Y)!
               })!
               

               
               
               _set_if_expression("W1tSRUNBUFRDSEFfMl9JTlZJU0lCTEVdXSA9PSAx");
               _if(VAR_RECAPTCHA_2_INVISIBLE == 1,function(){
               
                  
                  
                  VAR_RECAPTCHA_2_INVISIBLE = parseInt(VAR_RECAPTCHA_2_INVISIBLE) + parseInt(1)
                  

               })!
               

               
               
               sleep(200)!
               

               
               
               _next("function")
               

            })!
            

         },null)!
         

         
         
         _set_if_expression("W1tXQVNfRVJST1JdXQ==");
         _if(typeof(VAR_WAS_ERROR) !== "undefined" ? (VAR_WAS_ERROR) : undefined,function(){
         
            
            
            /*Browser*/
            cache_data_clear()!
            

            
            
            fail(VAR_LAST_ERROR)
            

         })!
         

         
         
         //// Проверить бан айпи
         get_element_selector(VAR_RECAPTCHA_PREFIX_SECOND_FRAME).script("document.getElementsByClassName('rc-doscaptcha-body-text').length")!
         if(parseInt(_result()) > 0)
         fail((_K==="en" ? "IP address banned Repaptcha 2. Automated queries" : "IP адрес забанен ReСaptсha2 за автоматические запросы"));
         

         
         
         _call(function()
         {
         _on_fail(function(){
         VAR_LAST_ERROR = _result()
         VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
         VAR_WAS_ERROR = false
         _break(1,true)
         })
         CYCLES.Current().RemoveLabel("function")
         
            
            
            VAR_CYCLE_INDEX = 0
            

            
            
            _set_if_expression("W1tSRUNBUFRDSEFfMl9JTlZJU0lCTEVdXSA9PSAx");
            _if(VAR_RECAPTCHA_2_INVISIBLE == 1,function(){
            
               
               
               _do(function(){
               _set_action_info({ name: "For" });
               VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
               if(VAR_CYCLE_INDEX > parseInt(60))_break();
               
                  
                  
                  /*Browser*/
                  ;_SELECTOR=VAR_RECAPTCHA_PREFIX_SECOND_FRAME + "\u003eXPATH\u003e id(\u0022rc-imageselect-target\u0022)";
                  get_element_selector(_SELECTOR, false).nowait().exist()!
                  VAR_IS_EXISTS = _result() == 1
                  _if(VAR_IS_EXISTS, function(){
                  get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
                  VAR_IS_EXISTS = _result().indexOf("true")>=0
                  })!
                  

                  
                  
                  _set_if_expression("W1tJU19FWElTVFNdXSA9PSB0cnVl");
                  _if(VAR_IS_EXISTS == true,function(){
                  
                     
                     
                     _break("function")
                     

                  })!
                  

                  
                  
                  _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gNTA=");
                  _if(VAR_CYCLE_INDEX > 50,function(){
                  
                     
                     
                     VAR_ERROR_LOAD = "1"
                     

                  })!
                  

                  
                  
                  sleep(100)!
                  

               })!
               

               
               
               /*Browser*/
               _SELECTOR = VAR_RECAPTCHA_PREFIX_SECOND_FRAME + "\u003eXPATH\u003e id(\u0022rc-imageselect-target\u0022)";
               wait_element(_SELECTOR)!
               get_element_selector(_SELECTOR, false).exist()!
               _if(_result() == "1", function(){
               get_element_selector(_SELECTOR, false).render_base64()!
               VAR_IMAGE_BASE_64 = _result()
               })!
               

            })!
            

            
            
            _set_if_expression("W1tCQVNfQ0FQTU9OU1RFUl9JTUFHRV9JRF1dID09IDAgJiYgW1tSRUNBUFRDSEFfMl9JTlZJU0lCTEVdXSAhPSAx");
            _if(VAR_BAS_CAPMONSTER_IMAGE_ID == 0 && VAR_RECAPTCHA_2_INVISIBLE != 1,function(){
            
               
               
               get_element_selector(VAR_RECAPTCHA_PREFIX_SECOND_FRAME_ELEMENT).script("window.getComputedStyle(self)['visibility']")!
               if(_result() == "hidden"){
               VAR_RECAPTCHA_2_CLOSED = 1;
               }
               else{
               waiter_timeout_next(25000);
               wait_load("recaptcha/*/payload")!
               }
               

               
               
               _set_if_expression("W1tSRUNBUFRDSEFfMl9DTE9TRURdXSA9PSAx");
               _if(VAR_RECAPTCHA_2_CLOSED == 1,function(){
               
                  
                  
                  _next("function")
                  

               })!
               

               
               
               _do(function(){
               _set_action_info({ name: "For" });
               VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
               if(VAR_CYCLE_INDEX > parseInt(100))_break();
               
                  
                  
                  /*Browser*/
                  ;_SELECTOR=VAR_RECAPTCHA_PREFIX_SECOND_FRAME_ELEMENT;
                  get_element_selector(_SELECTOR, false).nowait().exist()!
                  VAR_IS_EXISTS = _result() == 1
                  

                  
                  
                  _set_if_expression("IVtbSVNfRVhJU1RTXV0=");
                  _if(!VAR_IS_EXISTS,function(){
                  
                     
                     
                     _long_goto("Recaptcha2 start here location", 5, [])!
                     

                  })!
                  

                  
                  
                  cache_get_base64("recaptcha/*/payload")!
                  var image_id = native("imageprocessing", "load", _result())
                  var image_size = native("imageprocessing", "getsize", image_id)
                  var image_w = parseInt(image_size.split(",")[0])
                  var image_h = parseInt(image_size.split(",")[1])
                  VAR_SQUARE_WIDHT = image_w;
                  VAR_SQUARE_HEIGHT = image_h;
                  if (image_h == 0 && VAR_CYCLE_INDEX > rand (35,48)) fail((_K === "en" ? "Failed to wait for ReCaptcha2 image from request cache" : "Не удалось дождаться картинку ReCaptcha2 из кэша запроса"))
                  if (image_h > 99) {
                  VAR_IMAGE_BASE_64 = _result()
                  _break()
                  }
                  sleep(400)!
                  

               })!
               

            })!
            

         },null)!
         

         
         
         _set_if_expression("W1tXQVNfRVJST1JdXQ==");
         _if(typeof(VAR_WAS_ERROR) !== "undefined" ? (VAR_WAS_ERROR) : undefined,function(){
         
            
            
            VAR_BAS_CAPMONSTER_IMAGE_ID = "0"
            

            
            
            _set_if_expression("W1tSRUNBUFRDSEFfMl9JTlZJU0lCTEVdXSA9PSAx");
            _if(VAR_RECAPTCHA_2_INVISIBLE == 1,function(){
            
               
               
               VAR_RECAPTCHA_2_INVISIBLE = parseInt(VAR_RECAPTCHA_2_INVISIBLE) + parseInt(1)
               

            })!
            

            
            
            _call(function()
            {
            _on_fail(function(){
            VAR_LAST_ERROR = _result()
            VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
            VAR_WAS_ERROR = false
            _break(1,true)
            })
            CYCLES.Current().RemoveLabel("function")
            
               
               
               /*Browser*/
               ;_SELECTOR=VAR_RECAPTCHA_PREFIX_SECOND_FRAME + "\u003eXPATH\u003e id(\u0022recaptcha-reload-button\u0022)";
               get_element_selector(_SELECTOR, false).nowait().exist()!
               VAR_IS_EXISTS = _result() == 1
               _if(VAR_IS_EXISTS, function(){
               get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
               VAR_IS_EXISTS = _result().indexOf("true")>=0
               })!
               

               
               
               _set_if_expression("W1tJU19FWElTVFNdXQ==");
               _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
               
                  
                  
                  /*Browser*/
                  _SELECTOR = VAR_RECAPTCHA_PREFIX_SECOND_FRAME + "\u003eXPATH\u003e id(\u0022recaptcha-reload-button\u0022)";
                  wait_element_visible(_SELECTOR)!
                  _call(_random_point, {})!
                  _if(_result().length > 0, function(){
                  move( {"speed": VAR_SPEED,"gravity": VAR_GRAVITY,"deviation": VAR_DEVIATION} )!
                  get_element_selector(_SELECTOR, false).clarify(X,Y)!
                  _call(_clarify, {"speed": VAR_SPEED,"gravity": VAR_GRAVITY,"deviation": VAR_DEVIATION} )!
                  mouse(X,Y)!
                  })!
                  

               })!
               

            },null)!
            

            
            
            _next("function")
            

         })!
         

         
         
         _set_if_expression("W1tCQVNfQ0FQTU9OU1RFUl9JTUFHRV9JRF1dID09IDA=");
         _if(VAR_BAS_CAPMONSTER_IMAGE_ID == 0,function(){
         
            
            
            get_element_selector(VAR_RECAPTCHA_PREFIX_SECOND_FRAME).script("document.getElementsByClassName('rc-imageselect-table-44').length")!
            VAR_IS44 = parseInt(_result()) > 0
            get_element_selector(VAR_RECAPTCHA_PREFIX_SECOND_FRAME).script("document.getElementsByClassName('rc-imageselect-table-33').length")!
            VAR_IS33 = parseInt(_result()) > 0
            if(!VAR_IS33 && !VAR_IS44)
            {
            fail((_K==="en" ? "Unknown captcha type" : "Неизвестный тип рекаптчи 2"));
            }
            get_element_selector(VAR_RECAPTCHA_PREFIX_SECOND_FRAME + " strong").text()!
            VAR_CURRENT_TASK = _result();
            function set_capmonster_tasks(task)
            {
            task = task.toLowerCase()
            cap_task = task;
            if(task.indexOf("bus") >= 0 || task.indexOf("автобус") >= 0) cap_task =("capmonster","TaskDef","/m/01bjv"); else
            if(task.indexOf("vehicle") >= 0 || task.indexOf("транспорт") >= 0 || task.indexOf("voertuigen") >= 0 || task.indexOf("fahrzeugen") >= 0) cap_task =("capmonster","TaskDef","/m/0k4j"); else
            if(task.indexOf("bridge") >= 0 || task.indexOf("мост") >= 0 || task.indexOf("bruggen") >= 0 || task.indexOf("brücken") >= 0) cap_task =("capmonster","TaskDef","/m/015kr"); else
            if(task.indexOf("mountain") >= 0 || task.indexOf("гор") >= 0 || task.indexOf("bergen") >= 0 || task.indexOf("bergen oder hügeln") >= 0) cap_task =("capmonster","TaskDef","/m/09d_r"); else
            if(task.indexOf("motorcycle") >= 0 || task.indexOf("мотоцикл") >= 0 || task.indexOf("motor") >= 0 || task.indexOf("motorrädern") >= 0 || task.indexOf("zweirädern") >= 0) cap_task =("capmonster","TaskDef","/m/04_sv"); else
            if(task.indexOf("taxi") >= 0 || task.indexOf("такси") >= 0 || task.indexOf("taxis") >= 0) cap_task =("capmonster","TaskDef","/m/0pg52"); else
            if(task.indexOf("crosswalk") >= 0 || task.indexOf("переход") >= 0 || task.indexOf("zebrapaden") >= 0 || task.indexOf("oversteekplaatsen") >= 0 || task.indexOf("fußgängerüberwegen") >= 0) cap_task =("capmonster","TaskDef","/m/014xcs"); else
            if(task.indexOf("crossing") >= 0 || task.indexOf("переход") >= 0 || task.indexOf("zebrapaden") >= 0 || task.indexOf("oversteekplaatsen") >= 0 || task.indexOf("fußgängerüberwegen") >= 0) cap_task =("capmonster","TaskDef","/m/014xcs"); else
            if(task.indexOf("bicycle") >= 0 || task.indexOf("велосипед") >= 0 || task.indexOf("fietsen") >= 0 || task.indexOf("fahrrädern") >= 0) cap_task =("capmonster","TaskDef","/m/0199g"); else
            if(task.indexOf("traffic") >= 0 || task.indexOf("светофор") >= 0 || task.indexOf("verkeerslichten") >= 0 || task.indexOf("ampeln") >= 0) cap_task =("capmonster","TaskDef","/m/015qff"); else
            if(task.indexOf("hydrant") >= 0 || task.indexOf("гидрант") >= 0 || task.indexOf("brandkra") >= 0 || task.indexOf("feuerhydranten") >= 0 || task.indexOf("hydranten") >= 0) cap_task =("capmonster","TaskDef","/m/01pns0"); else
            if(task.indexOf("boat") >= 0 || task.indexOf("лодк") >= 0 || task.indexOf("boten") >= 0 || task.indexOf("booten") >= 0) cap_task =("capmonster","TaskDef","/m/019jd"); else
            if(task.indexOf("chimney") >= 0 || task.indexOf("труб") >= 0 || task.indexOf("schoorstenen") >= 0) cap_task =("capmonster","TaskDef","/m/01jk_4"); else
            if(task.indexOf("stair") >= 0 || task.indexOf("лестниц") >= 0 || task.indexOf("trappen") >= 0 || task.indexOf("treppen") >= 0) cap_task =("capmonster","TaskDef","/m/01lynh"); else
            if(task.indexOf("palm") >= 0 || task.indexOf("пальм") >= 0 || task.indexOf("palmbomen") >= 0 || task.indexOf("palmen") >= 0) cap_task =("capmonster","TaskDef","/m/0cdl1"); else
            if(task.indexOf("tractor") >= 0 || task.indexOf("трактор") >= 0 || task.indexOf("tractors") >= 0 || task.indexOf("traktoren") >= 0) cap_task =("capmonster","TaskDef","/m/013xlm"); else
            if(task.indexOf("parking") >= 0 || task.indexOf("парковочные") >= 0 || task.indexOf("parkometern") >= 0) cap_task =("capmonster","TaskDef","/m/015qbp"); else
            if(task.indexOf("cars") >= 0 || task.indexOf("автомобил") >= 0 || task.indexOf("auto") >= 0 || task.indexOf("pkws") >= 0) cap_task =("capmonster","Task","cars")
            return cap_task;
            }
            VAR_SET_TASK = set_capmonster_tasks(VAR_CURRENT_TASK);
            if (VAR_METHOD_MODULE == "CaptchaGuru" || VAR_METHOD_MODULE == "RuCaptcha")
            {
            if (VAR_SET_TASK == "/m/01bjv") VAR_SET_TASK = "bus";
            if (VAR_SET_TASK == "/m/0k4j") VAR_SET_TASK = "vehicle";
            if (VAR_SET_TASK == "/m/015kr") VAR_SET_TASK = "bridge";
            if (VAR_SET_TASK == "/m/09d_r") VAR_SET_TASK = "mountain";
            if (VAR_SET_TASK == "/m/04_sv") VAR_SET_TASK = "motorcycle";
            if (VAR_SET_TASK == "/m/0pg52") VAR_SET_TASK = "taxi";
            if (VAR_SET_TASK == "/m/014xcs") VAR_SET_TASK = "crosswalk";
            if (VAR_SET_TASK == "/m/0199g") VAR_SET_TASK = "bicycle";
            if (VAR_SET_TASK == "/m/015qff") VAR_SET_TASK = "trafficlight";
            if (VAR_SET_TASK == "/m/01pns0") VAR_SET_TASK = "hydrant";
            if (VAR_SET_TASK == "/m/019jd") VAR_SET_TASK = "boat";
            if (VAR_SET_TASK == "/m/01jk_4") VAR_SET_TASK = "chimney";
            if (VAR_SET_TASK == "/m/01lynh") VAR_SET_TASK = "stairs";
            if (VAR_SET_TASK == "/m/0cdl1") VAR_SET_TASK = "palm";
            if (VAR_SET_TASK == "/m/013xlm") VAR_SET_TASK = "tractors";
            if (VAR_SET_TASK == "/m/015qbp") VAR_SET_TASK = "parkingmeters";
            if (VAR_SET_TASK == "cars") VAR_SET_TASK = "car";
            }
            

         })!
         

         
         
         _call(function()
         {
         _on_fail(function(){
         VAR_LAST_ERROR = _result()
         VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
         VAR_WAS_ERROR = false
         _break(1,true)
         })
         CYCLES.Current().RemoveLabel("function")
         
            
            
            _get_browser_screen_settings()!
            ;(function(){
            var result = JSON.parse(_result())
            VAR_SCROLL_X = result["ScrollX"]
            VAR_SCROLL_Y = result["ScrollY"]
            VAR_CURSOR_X = result["CursorX"]
            VAR_CURSOR_Y = result["CursorY"]
            VAR_BROWSER_WIDTH = result["Width"]
            VAR_BROWSER_HEIGHT = result["Height"]
            })();
            

            
            
            /*Browser*/
            ;_SELECTOR=VAR_RECAPTCHA_PREFIX_SECOND_FRAME + "\u003eXPATH\u003e//div[@class=\u0022rc-imageselect-incorrect-response\u0022]";
            get_element_selector(_SELECTOR, false).nowait().exist()!
            VAR_ERROR_EXISTS = _result() == 1
            _if(VAR_ERROR_EXISTS, function(){
            get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
            VAR_ERROR_EXISTS = _result().indexOf("true")>=0
            })!
            

            
            
            _set_if_expression("W1tCQVNfQ0FQTU9OU1RFUl9JTUFHRV9JRF1dID09IDAgJiYgW1tDT09SRElOQVRFU19BTERSRUFEWV9HRVRfNFg0XV0gPT0gMCAmJiBbW0lTNDRdXSA9PSB0cnVlIHx8IFtbSVNfQ0hBTkdFRF9TQ1JPTExfWV1dICE9IFtbU0NST0xMX1ldXSAmJiBbW0lTNDRdXSA9PSB0cnVl");
            _if(VAR_BAS_CAPMONSTER_IMAGE_ID == 0 && VAR_COORDINATES_ALDREADY_GET_4X4 == 0 && VAR_IS44 == true || VAR_IS_CHANGED_SCROLL_Y != VAR_SCROLL_Y && VAR_IS44 == true,function(){
            
               
               
               VAR_IS_CHANGED_SCROLL_Y = VAR_SCROLL_Y
               

               
               
               VAR_ELEMENT_SELECTOR = VAR_RECAPTCHA_PREFIX_SECOND_FRAME + "\u003eXPATH\u003e //*[@class=\u0022rc-imageselect-tile\u0022][@tabindex=\u00224\u0022]"
               

               
               
               _SELECTOR = VAR_ELEMENT_SELECTOR;
               get_element_selector(_SELECTOR, false).script("(function(){var rect = self.getBoundingClientRect();return (rect.left + positionx).toString() + '|' + (rect.top + positiony).toString() + '|' + (rect.right - rect.left).toString() + '|' + (rect.bottom - rect.top).toString()})();")!
               var split = _result().split("|");
               var x = parseInt(split[0]), y = parseInt(split[1]), w = parseInt(split[2]), h = parseInt(split[3]);
               _get_browser_screen_settings()!
               var result_recaptcha = JSON.parse(_result());
               var scroll_x = result_recaptcha["ScrollX"], scroll_y = result_recaptcha["ScrollY"]
               var margin_top_bottom = 50; //percent
               var margin_left_top = 50; // percent
               div = 1;
               var x_min = x + w/100*margin_left_top + parseInt(scroll_x), x_max = x+w/div-w/100*margin_left_top + parseInt(scroll_x);
               var y_min = y + h/100*margin_top_bottom + parseInt(scroll_y), y_max = y+h - h/100*margin_top_bottom + parseInt(scroll_y);
               x = rand(x_min, x_max);
               y = rand(y_min, y_max);
               x = x.toFixed();
               y = y.toFixed();
               if (VAR_IS33 == true)
               {
               /// Первый квадрат
               VAR_FIRST_PIC_X = parseInt(x);
               VAR_FIRST_PIC_Y = parseInt(y);
               // Второй и т.д.
               VAR_SECOND_PIC_X = VAR_FIRST_PIC_X + w;
               VAR_SECOND_PIC_Y = VAR_FIRST_PIC_Y;
               VAR_THIRD_PIC_X = VAR_SECOND_PIC_X + w;
               VAR_THIRD_PIC_Y = VAR_FIRST_PIC_Y;
               VAR_FOUR_PIC_X = VAR_FIRST_PIC_X
               VAR_FOUR_PIC_Y = VAR_FIRST_PIC_Y + h;
               VAR_FIVE_PIC_X = VAR_SECOND_PIC_X
               VAR_FIVE_PIC_Y = VAR_SECOND_PIC_Y + h;
               VAR_SIX_PIC_X = VAR_THIRD_PIC_X;
               VAR_SIX_PIC_Y = VAR_THIRD_PIC_Y + h;
               VAR_SEVEN_PIC_X = VAR_FOUR_PIC_X;
               VAR_SEVEN_PIC_Y = VAR_FOUR_PIC_Y + h;
               VAR_EIGHT_PIC_X = VAR_FIVE_PIC_X
               VAR_EIGHT_PIC_Y = VAR_FIVE_PIC_Y + h;
               VAR_NINE_PIC_X = VAR_SIX_PIC_X
               VAR_NINE_PIC_Y = VAR_SIX_PIC_Y + h;
               }
               if (VAR_IS44 == true)
               {
               /// Первый квадрат
               VAR_FIRST_PIC_X = parseInt(x);
               VAR_FIRST_PIC_Y = parseInt(y);
               // Второй и т.д.
               VAR_SECOND_PIC_X = VAR_FIRST_PIC_X + w;
               VAR_SECOND_PIC_Y = VAR_FIRST_PIC_Y;
               VAR_THIRD_PIC_X = VAR_SECOND_PIC_X + w;
               VAR_THIRD_PIC_Y = VAR_FIRST_PIC_Y;
               VAR_FOUR_PIC_X = VAR_THIRD_PIC_X + w;
               VAR_FOUR_PIC_Y = VAR_FIRST_PIC_Y
               VAR_FIVE_PIC_X = VAR_FIRST_PIC_X
               VAR_FIVE_PIC_Y = VAR_SECOND_PIC_Y + h;
               VAR_SIX_PIC_X = VAR_SECOND_PIC_X;
               VAR_SIX_PIC_Y = VAR_SECOND_PIC_Y + h;
               VAR_SEVEN_PIC_X = VAR_THIRD_PIC_X;
               VAR_SEVEN_PIC_Y = VAR_THIRD_PIC_Y + h;
               VAR_EIGHT_PIC_X = VAR_FOUR_PIC_X
               VAR_EIGHT_PIC_Y = VAR_FOUR_PIC_Y + h;
               VAR_NINE_PIC_X = VAR_FIVE_PIC_X
               VAR_NINE_PIC_Y = VAR_FIVE_PIC_Y + h;
               VAR_TEN_PIC_X = VAR_SIX_PIC_X
               VAR_TEN_PIC_Y = VAR_SIX_PIC_Y + h;
               VAR_ELEVEN_PIC_X = VAR_SEVEN_PIC_X
               VAR_ELEVEN_PIC_Y = VAR_SEVEN_PIC_Y + h;
               VAR_TWELVE_PIC_X = VAR_EIGHT_PIC_X
               VAR_TWELVE_PIC_Y = VAR_EIGHT_PIC_Y + h;
               VAR_THIRTEEN_PIC_X = VAR_NINE_PIC_X
               VAR_THIRTEEN_PIC_Y = VAR_NINE_PIC_Y + h;
               VAR_FOURTEEN_PIC_X = VAR_TEN_PIC_X
               VAR_FOURTEEN_PIC_Y = VAR_TEN_PIC_Y + h;
               VAR_FIVETEEN_PIC_X = VAR_ELEVEN_PIC_X
               VAR_FIVETEEN_PIC_Y = VAR_ELEVEN_PIC_Y + h;
               VAR_SIXTEEN_PIC_X = VAR_TWELVE_PIC_X
               VAR_SIXTEEN_PIC_Y = VAR_TWELVE_PIC_Y + h;
               }
               

               
               
               VAR_COORDINATES_ALDREADY_GET_4X4 = "1"
               

               
               
               VAR_COORDINATES_ALDREADY_GET_3X3 = "0"
               

            })!
            

            
            
            _set_if_expression("W1tCQVNfQ0FQTU9OU1RFUl9JTUFHRV9JRF1dID09IDAgJiYgW1tDT09SRElOQVRFU19BTERSRUFEWV9HRVRfM1gzXV0gPT0gMCAmJiBbW0lTMzNdXSA9PSB0cnVlIHx8IFtbSVNfQ0hBTkdFRF9TQ1JPTExfWV1dICE9IFtbU0NST0xMX1ldXSAmJiBbW0lTMzNdXSA9PSB0cnVl");
            _if(VAR_BAS_CAPMONSTER_IMAGE_ID == 0 && VAR_COORDINATES_ALDREADY_GET_3X3 == 0 && VAR_IS33 == true || VAR_IS_CHANGED_SCROLL_Y != VAR_SCROLL_Y && VAR_IS33 == true,function(){
            
               
               
               VAR_IS_CHANGED_SCROLL_Y = VAR_SCROLL_Y
               

               
               
               VAR_ELEMENT_SELECTOR = VAR_RECAPTCHA_PREFIX_SECOND_FRAME + "\u003eXPATH\u003e //*[@class=\u0022rc-imageselect-tile\u0022][@tabindex=\u00224\u0022]"
               

               
               
               _SELECTOR = VAR_ELEMENT_SELECTOR;
               get_element_selector(_SELECTOR, false).script("(function(){var rect = self.getBoundingClientRect();return (rect.left + positionx).toString() + '|' + (rect.top + positiony).toString() + '|' + (rect.right - rect.left).toString() + '|' + (rect.bottom - rect.top).toString()})();")!
               var split = _result().split("|");
               var x = parseInt(split[0]), y = parseInt(split[1]), w = parseInt(split[2]), h = parseInt(split[3]);
               _get_browser_screen_settings()!
               var result_recaptcha = JSON.parse(_result());
               var scroll_x = result_recaptcha["ScrollX"], scroll_y = result_recaptcha["ScrollY"]
               var margin_top_bottom = 50; //percent
               var margin_left_top = 50; // percent
               div = 1;
               var x_min = x + w/100*margin_left_top + parseInt(scroll_x), x_max = x+w/div-w/100*margin_left_top + parseInt(scroll_x);
               var y_min = y + h/100*margin_top_bottom + parseInt(scroll_y), y_max = y+h - h/100*margin_top_bottom + parseInt(scroll_y);
               x = rand(x_min, x_max);
               y = rand(y_min, y_max);
               x = x.toFixed();
               y = y.toFixed();
               if (VAR_IS33 == true)
               {
               /// Первый квадрат
               VAR_FIRST_PIC_X = parseInt(x);
               VAR_FIRST_PIC_Y = parseInt(y);
               // Второй и т.д.
               VAR_SECOND_PIC_X = VAR_FIRST_PIC_X + w;
               VAR_SECOND_PIC_Y = VAR_FIRST_PIC_Y;
               VAR_THIRD_PIC_X = VAR_SECOND_PIC_X + w;
               VAR_THIRD_PIC_Y = VAR_FIRST_PIC_Y;
               VAR_FOUR_PIC_X = VAR_FIRST_PIC_X
               VAR_FOUR_PIC_Y = VAR_FIRST_PIC_Y + h;
               VAR_FIVE_PIC_X = VAR_SECOND_PIC_X
               VAR_FIVE_PIC_Y = VAR_SECOND_PIC_Y + h;
               VAR_SIX_PIC_X = VAR_THIRD_PIC_X;
               VAR_SIX_PIC_Y = VAR_THIRD_PIC_Y + h;
               VAR_SEVEN_PIC_X = VAR_FOUR_PIC_X;
               VAR_SEVEN_PIC_Y = VAR_FOUR_PIC_Y + h;
               VAR_EIGHT_PIC_X = VAR_FIVE_PIC_X
               VAR_EIGHT_PIC_Y = VAR_FIVE_PIC_Y + h;
               VAR_NINE_PIC_X = VAR_SIX_PIC_X
               VAR_NINE_PIC_Y = VAR_SIX_PIC_Y + h;
               }
               if (VAR_IS44 == true)
               {
               /// Первый квадрат
               VAR_FIRST_PIC_X = parseInt(x);
               VAR_FIRST_PIC_Y = parseInt(y);
               // Второй и т.д.
               VAR_SECOND_PIC_X = VAR_FIRST_PIC_X + w;
               VAR_SECOND_PIC_Y = VAR_FIRST_PIC_Y;
               VAR_THIRD_PIC_X = VAR_SECOND_PIC_X + w;
               VAR_THIRD_PIC_Y = VAR_FIRST_PIC_Y;
               VAR_FOUR_PIC_X = VAR_THIRD_PIC_X + w;
               VAR_FOUR_PIC_Y = VAR_FIRST_PIC_Y
               VAR_FIVE_PIC_X = VAR_FIRST_PIC_X
               VAR_FIVE_PIC_Y = VAR_SECOND_PIC_Y + h;
               VAR_SIX_PIC_X = VAR_SECOND_PIC_X;
               VAR_SIX_PIC_Y = VAR_SECOND_PIC_Y + h;
               VAR_SEVEN_PIC_X = VAR_THIRD_PIC_X;
               VAR_SEVEN_PIC_Y = VAR_THIRD_PIC_Y + h;
               VAR_EIGHT_PIC_X = VAR_FOUR_PIC_X
               VAR_EIGHT_PIC_Y = VAR_FOUR_PIC_Y + h;
               VAR_NINE_PIC_X = VAR_FIVE_PIC_X
               VAR_NINE_PIC_Y = VAR_FIVE_PIC_Y + h;
               VAR_TEN_PIC_X = VAR_SIX_PIC_X
               VAR_TEN_PIC_Y = VAR_SIX_PIC_Y + h;
               VAR_ELEVEN_PIC_X = VAR_SEVEN_PIC_X
               VAR_ELEVEN_PIC_Y = VAR_SEVEN_PIC_Y + h;
               VAR_TWELVE_PIC_X = VAR_EIGHT_PIC_X
               VAR_TWELVE_PIC_Y = VAR_EIGHT_PIC_Y + h;
               VAR_THIRTEEN_PIC_X = VAR_NINE_PIC_X
               VAR_THIRTEEN_PIC_Y = VAR_NINE_PIC_Y + h;
               VAR_FOURTEEN_PIC_X = VAR_TEN_PIC_X
               VAR_FOURTEEN_PIC_Y = VAR_TEN_PIC_Y + h;
               VAR_FIVETEEN_PIC_X = VAR_ELEVEN_PIC_X
               VAR_FIVETEEN_PIC_Y = VAR_ELEVEN_PIC_Y + h;
               VAR_SIXTEEN_PIC_X = VAR_TWELVE_PIC_X
               VAR_SIXTEEN_PIC_Y = VAR_TWELVE_PIC_Y + h;
               }
               

               
               
               VAR_COORDINATES_ALDREADY_GET_4X4 = "0"
               

               
               
               VAR_COORDINATES_ALDREADY_GET_3X3 = "1"
               

            })!
            

         },null)!
         

         
         
         _set_if_expression("W1tXQVNfRVJST1JdXQ==");
         _if(typeof(VAR_WAS_ERROR) !== "undefined" ? (VAR_WAS_ERROR) : undefined,function(){
         
            
            
            /*Browser*/
            cache_data_clear()!
            

            
            
            fail(VAR_LAST_ERROR)
            

         })!
         

         
         
         _call(function()
         {
         _on_fail(function(){
         VAR_LAST_ERROR = _result()
         VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
         VAR_WAS_ERROR = false
         _break(1,true)
         })
         CYCLES.Current().RemoveLabel("function")
         
            
            
            _set_if_expression("W1tJU19NT0JJTEVdXSA9PSAwICYmIHJhbmQgKDEsMTApID4gMyAmJiBbW0JBU19DQVBNT05TVEVSX0lNQUdFX0lEXV0gPT0gMA==");
            _if(VAR_IS_MOBILE == 0 && rand (1,10) > 3 && VAR_BAS_CAPMONSTER_IMAGE_ID == 0,function(){
            
               
               
               _get_browser_screen_settings()!
               ;(function(){
               var result = JSON.parse(_result())
               VAR_SCROLL_X = result["ScrollX"]
               VAR_SCROLL_Y = result["ScrollY"]
               VAR_CURSOR_X = result["CursorX"]
               VAR_CURSOR_Y = result["CursorY"]
               VAR_BROWSER_WIDTH = result["Width"]
               VAR_BROWSER_HEIGHT = result["Height"]
               })();
               

               
               
               /*Browser*/
               ;_SELECTOR=VAR_RECAPTCHA_PREFIX_SECOND_FRAME + "\u003eXPATH\u003e id(\u0022rc-imageselect-target\u0022)";
               get_element_selector(_SELECTOR, false).nowait().exist()!
               VAR_IS_EXISTS = _result() == 1
               _if(VAR_IS_EXISTS, function(){
               get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
               VAR_IS_EXISTS = _result().indexOf("true")>=0
               })!
               

               
               
               _set_if_expression("IVtbSVNfRVhJU1RTXV0=");
               _if(!VAR_IS_EXISTS,function(){
               
                  
                  
                  _next("function")
                  

               })!
               

               
               
               /*Browser*/
               _SELECTOR = VAR_RECAPTCHA_PREFIX_SECOND_FRAME + "\u003eXPATH\u003e id(\u0022rc-imageselect-target\u0022)";
               wait_element(_SELECTOR)!
               get_element_selector(_SELECTOR, false).script("(function(){var rect = self.getBoundingClientRect();return (rect.left + positionx).toString() + '|' + (rect.top + positiony).toString() + '|' + (rect.right - rect.left).toString() + '|' + (rect.bottom - rect.top).toString()})();")!
               if(_result().length > 0)
               {
               var split = _result().split("|")
               VAR_X = parseInt(split[0])
               VAR_Y = parseInt(split[1])
               VAR_CAPTCHA_WIDTH = parseInt(split[2])
               VAR_CAPTCHA_HEIGHT = parseInt(split[3])
               }
               

               
               
               /*Browser*/
               move(rand(VAR_X/100*105,(VAR_X+VAR_CAPTCHA_WIDTH)/100*93).toFixed(),rand(VAR_Y + VAR_SCROLL_Y/100*105,VAR_Y + VAR_SCROLL_Y + VAR_CAPTCHA_HEIGHT/100*90).toFixed(),  {} )!
               

            })!
            

         },null)!
         

         
         
         _set_if_expression("W1tXQVNfRVJST1JdXQ==");
         _if(typeof(VAR_WAS_ERROR) !== "undefined" ? (VAR_WAS_ERROR) : undefined,function(){
         
            
            
            /*Browser*/
            cache_data_clear()!
            

            
            
            fail(VAR_LAST_ERROR)
            

         })!
         

         
         
         _call(function()
         {
         _on_fail(function(){
         VAR_LAST_ERROR = _result()
         VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
         VAR_WAS_ERROR = false
         _break(1,true)
         })
         CYCLES.Current().RemoveLabel("function")
         
            
            
            VAR_CYCLE_INDEX = 0
            

            
            
            _do(function(){
            _set_action_info({ name: "For" });
            VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
            if(VAR_CYCLE_INDEX > parseInt(30))_break();
            
               
               
               _set_if_expression("W1tNRVRIT0RfTU9EVUxFXV0gPT0gIkNhcHRjaGFHdXJ1Ig==");
               _if(VAR_METHOD_MODULE == "CaptchaGuru",function(){
               
                  
                  
                  ///Чистим
                  solver_properties_clear("capmonster")
                  /// Формирумем основной запрос
                  solver_property("capmonster","serverurl","https://api.captcha.guru/")
                  solver_property("capmonster","key",VAR_KEY_MODULE)
                  solver_property("capmonster","textinstructions",VAR_SET_TASK)
                  solver_property("capmonster","click","recap2")
                  solver_property("capmonster","method","post")
                  //// Отправляем
                  solve_base64_no_fail("capmonster", VAR_IMAGE_BASE_64)!
                  VAR_SAVED_CONTENT = _result();
                  

               })!
               

               
               
               _set_if_expression("W1tNRVRIT0RfTU9EVUxFXV0gPT0gIkNhcE1vbnN0ZXJJbWFnZSI=");
               _if(VAR_METHOD_MODULE == "CapMonsterImage",function(){
               
                  
                  
                  ///Чистим
                  solver_properties_clear("capmonster")
                  /// Формирумем основной запрос
                  solver_property("capmonster","serverurl",VAR_URL_MODULE)
                  solver_property("capmonster","bas_disable_image_convert","1")
                  solver_property("capmonster","CapMonsterModule","ZennoLab.ReCaptcha2")
                  solver_property("capmonster","IsNotDynamic",VAR_IS44)
                  /// Дополняем
                  if (VAR_KEY_MODULE != '') solver_property("capmonster","key",VAR_KEY_MODULE)
                  if (VAR_SET_TASK != "cars") solver_property("capmonster","TaskDef",VAR_SET_TASK)
                  if (VAR_SET_TASK == "cars") solver_property("capmonster","Task",VAR_SET_TASK)
                  //// Отправляем
                  solve_base64_no_fail("capmonster", VAR_IMAGE_BASE_64)!
                  VAR_SAVED_CONTENT = _result();
                  

               })!
               

               
               
               _set_if_expression("W1tTQVZFRF9DT05URU5UXV0uaW5kZXhPZigiRVJST1JfQ0FQVENIQV9VTlNPTFZBQkxFIikgPj0gMA==");
               _if(VAR_SAVED_CONTENT.indexOf("ERROR_CAPTCHA_UNSOLVABLE") >= 0,function(){
               
                  
                  
                  VAR_BAS_CAPMONSTER_IMAGE_ID = "0"
                  

                  
                  
                  _set_if_expression("W1tSRUNBUFRDSEFfMl9JTlZJU0lCTEVdXSA9PSAx");
                  _if(VAR_RECAPTCHA_2_INVISIBLE == 1,function(){
                  
                     
                     
                     VAR_RECAPTCHA_2_INVISIBLE = parseInt(VAR_RECAPTCHA_2_INVISIBLE) + parseInt(1)
                     

                  })!
                  

                  
                  
                  cache_data_clear()!
                  

                  
                  
                  /*Browser*/
                  _SELECTOR = VAR_RECAPTCHA_PREFIX_SECOND_FRAME + "\u003eCSS\u003e #recaptcha-verify-button";
                  wait_element_visible(_SELECTOR)!
                  _call(_random_point, {})!
                  _if(_result().length > 0, function(){
                  move( {"speed": VAR_SPEED,"gravity": VAR_GRAVITY,"deviation": VAR_DEVIATION} )!
                  get_element_selector(_SELECTOR, false).clarify(X,Y)!
                  _call(_clarify, {"speed": VAR_SPEED,"gravity": VAR_GRAVITY,"deviation": VAR_DEVIATION} )!
                  mouse(X,Y)!
                  })!
                  

                  
                  
                  sleep(100)!
                  

                  
                  
                  _break("function")
                  

               })!
               

               
               
               _set_if_expression("W1tTQVZFRF9DT05URU5UXV0uaW5kZXhPZigiRVJST1JfV1JPTkdfVVNFUl9LRVkiKSA+PSAw");
               _if(VAR_SAVED_CONTENT.indexOf("ERROR_WRONG_USER_KEY") >= 0,function(){
               
                  
                  
                  VAR_ERROR_KEY = "1"
                  

                  
                  
                  _break("function")
                  

               })!
               

               
               
               _set_if_expression("W1tTQVZFRF9DT05URU5UXV0uaW5kZXhPZigiRVJST1JfWkVST19CQUxBTkNFIikgPj0gMA==");
               _if(VAR_SAVED_CONTENT.indexOf("ERROR_ZERO_BALANCE") >= 0,function(){
               
                  
                  
                  VAR_ERROR_BALANCE = "1"
                  

                  
                  
                  _break("function")
                  

               })!
               

               
               
               _set_if_expression("W1tTQVZFRF9DT05URU5UXV0uaW5kZXhPZigiQ0FQVENIQV9GQUlMIikgPj0gMA==");
               _if(VAR_SAVED_CONTENT.indexOf("CAPTCHA_FAIL") >= 0,function(){
               
                  
                  
                  VAR_CAPTCHA_FAIL = "1"
                  

                  
                  
                  _break("function")
                  

               })!
               

               
               
               _cycle_params().if_else = VAR_SAVED_CONTENT.match(/[0-9]/) || VAR_SAVED_CONTENT == "sorry" || VAR_SAVED_CONTENT == "notpic";
               _set_if_expression("W1tTQVZFRF9DT05URU5UXV0ubWF0Y2goL1swLTldLykgfHwgW1tTQVZFRF9DT05URU5UXV0gPT0gInNvcnJ5IiB8fCBbW1NBVkVEX0NPTlRFTlRdXSA9PSAibm90cGljIg==");
               _if(_cycle_params().if_else,function(){
               
                  
                  
                  VAR_LISTS_SQUARE = VAR_SAVED_CONTENT
                  

                  
                  
                  _set_if_expression("W1tMSVNUU19TUVVBUkVdXSA9PSAic29ycnkiIHx8IFtbTElTVFNfU1FVQVJFXV0gPT0gIm5vdHBpYyI=");
                  _if(VAR_LISTS_SQUARE == "sorry" || VAR_LISTS_SQUARE == "notpic",function(){
                  
                     
                     
                     VAR_BAS_CAPMONSTER_IMAGE_ID = "0"
                     

                     
                     
                     _set_if_expression("W1tSRUNBUFRDSEFfMl9JTlZJU0lCTEVdXSA9PSAx");
                     _if(VAR_RECAPTCHA_2_INVISIBLE == 1,function(){
                     
                        
                        
                        VAR_RECAPTCHA_2_INVISIBLE = parseInt(VAR_RECAPTCHA_2_INVISIBLE) + parseInt(1)
                        

                     })!
                     

                     
                     
                     cache_data_clear()!
                     

                     
                     
                     /*Browser*/
                     _SELECTOR = VAR_RECAPTCHA_PREFIX_SECOND_FRAME + "\u003eCSS\u003e #recaptcha-verify-button";
                     wait_element_visible(_SELECTOR)!
                     _call(_random_point, {})!
                     _if(_result().length > 0, function(){
                     move( {"speed": VAR_SPEED,"gravity": VAR_GRAVITY,"deviation": VAR_DEVIATION} )!
                     get_element_selector(_SELECTOR, false).clarify(X,Y)!
                     _call(_clarify, {"speed": VAR_SPEED,"gravity": VAR_GRAVITY,"deviation": VAR_DEVIATION} )!
                     mouse(X,Y)!
                     })!
                     

                     
                     
                     sleep(100)!
                     

                     
                     
                     _break("function")
                     

                  })!
                  

                  
                  
                  VAR_LISTS_SQUARE = native("regexp", "scan", JSON.stringify({text: VAR_LISTS_SQUARE,regexp:"[0-9]+"}))
                  if(VAR_LISTS_SQUARE.length == 0)
                  VAR_LISTS_SQUARE = []
                  else
                  VAR_LISTS_SQUARE = JSON.parse(VAR_LISTS_SQUARE)
                  

                  
                  
                  ;(function (a) {var j, x, i;for (i = a.length; i; i--) {j = Math.floor(Math.random() * i);x = a[i - 1]; a[i - 1] = a[j];a[j] = x;}})(VAR_LISTS_SQUARE)
                  

                  
                  
                  VAR_FOREACH_DATA = 0
                  

                  
                  
                  _do_with_params({"foreach_data":(VAR_LISTS_SQUARE)},function(){
                  _set_action_info({ name: "Foreach" });
                  VAR_CYCLE_INDEX = _iterator() - 1
                  if(VAR_CYCLE_INDEX > _cycle_param("foreach_data").length - 1)_break();
                  VAR_FOREACH_DATA = _cycle_param("foreach_data")[VAR_CYCLE_INDEX]
                  
                     
                     
                     VAR_FOREACH_DATA = Number(VAR_FOREACH_DATA)+3;
                     if (VAR_FOREACH_DATA == 4)
                     {
                     VAR_PIC_X = VAR_FIRST_PIC_X
                     VAR_PIC_Y = VAR_FIRST_PIC_Y
                     }
                     if (VAR_FOREACH_DATA == 5)
                     {
                     VAR_PIC_X = VAR_SECOND_PIC_X
                     VAR_PIC_Y = VAR_SECOND_PIC_Y
                     }
                     if (VAR_FOREACH_DATA == 6)
                     {
                     VAR_PIC_X = VAR_THIRD_PIC_X
                     VAR_PIC_Y = VAR_THIRD_PIC_Y
                     }
                     if (VAR_FOREACH_DATA == 7)
                     {
                     VAR_PIC_X = VAR_FOUR_PIC_X
                     VAR_PIC_Y = VAR_FOUR_PIC_Y
                     }
                     if (VAR_FOREACH_DATA == 8)
                     {
                     VAR_PIC_X = VAR_FIVE_PIC_X
                     VAR_PIC_Y = VAR_FIVE_PIC_Y
                     }
                     if (VAR_FOREACH_DATA == 9)
                     {
                     VAR_PIC_X = VAR_SIX_PIC_X
                     VAR_PIC_Y = VAR_SIX_PIC_Y
                     }
                     if (VAR_FOREACH_DATA == 10)
                     {
                     VAR_PIC_X = VAR_SEVEN_PIC_X
                     VAR_PIC_Y = VAR_SEVEN_PIC_Y
                     }
                     if (VAR_FOREACH_DATA == 11)
                     {
                     VAR_PIC_X = VAR_EIGHT_PIC_X
                     VAR_PIC_Y = VAR_EIGHT_PIC_Y
                     }
                     if (VAR_FOREACH_DATA == 12)
                     {
                     VAR_PIC_X = VAR_NINE_PIC_X
                     VAR_PIC_Y = VAR_NINE_PIC_Y
                     }
                     if (VAR_FOREACH_DATA == 13)
                     {
                     VAR_PIC_X = VAR_TEN_PIC_X
                     VAR_PIC_Y = VAR_TEN_PIC_Y
                     }
                     if (VAR_FOREACH_DATA == 14)
                     {
                     VAR_PIC_X = VAR_ELEVEN_PIC_X
                     VAR_PIC_Y = VAR_ELEVEN_PIC_Y
                     }
                     if (VAR_FOREACH_DATA == 15)
                     {
                     VAR_PIC_X = VAR_TWELVE_PIC_X
                     VAR_PIC_Y = VAR_TWELVE_PIC_Y
                     }
                     if (VAR_FOREACH_DATA == 16)
                     {
                     VAR_PIC_X = VAR_THIRTEEN_PIC_X
                     VAR_PIC_Y = VAR_THIRTEEN_PIC_Y
                     }
                     if (VAR_FOREACH_DATA == 17)
                     {
                     VAR_PIC_X = VAR_FOURTEEN_PIC_X
                     VAR_PIC_Y = VAR_FOURTEEN_PIC_Y
                     }
                     if (VAR_FOREACH_DATA == 18)
                     {
                     VAR_PIC_X = VAR_FIVETEEN_PIC_X
                     VAR_PIC_Y = VAR_FIVETEEN_PIC_Y
                     }
                     if (VAR_FOREACH_DATA == 19)
                     {
                     VAR_PIC_X = VAR_SIXTEEN_PIC_X
                     VAR_PIC_Y = VAR_SIXTEEN_PIC_Y
                     }
                     

                     
                     
                     _set_if_expression("cmFuZCAoMSwxMCkgPiA1ICYmIFtbSVM0NF1dID09IHRydWU=");
                     _if(rand (1,10) > 5 && VAR_IS44 == true,function(){
                     
                        
                        
                        sleep(100)!
                        

                     })!
                     

                     
                     
                     _set_if_expression("W1tJUzMzXV0gPT0gdHJ1ZQ==");
                     _if(VAR_IS33 == true,function(){
                     
                        
                        
                        /*Browser*/
                        cache_data_clear()!
                        

                     })!
                     

                     
                     
                     _set_if_expression("W1tFUlJPUl9FWElTVFNdXSA9PSBmYWxzZQ==");
                     _if(VAR_ERROR_EXISTS == false,function(){
                     
                        
                        
                        _set_if_expression("W1tJUzMzXV0gPT0gdHJ1ZQ==");
                        _if(VAR_IS33 == true,function(){
                        
                           
                           
                           /*Browser*/
                           move(VAR_PIC_X + rand (-16,+16),VAR_PIC_Y + rand (-16,+16),  {"speed": VAR_SPEED,"gravity": VAR_GRAVITY,"deviation": VAR_DEVIATION} )!
                           mouse(VAR_PIC_X + rand (-16,+16),VAR_PIC_Y + rand (-16,+16))!
                           

                        })!
                        

                        
                        
                        _set_if_expression("W1tJUzQ0XV0gPT0gdHJ1ZQ==");
                        _if(VAR_IS44 == true,function(){
                        
                           
                           
                           /*Browser*/
                           move(VAR_PIC_X + rand (-10,+10),VAR_PIC_Y + rand (-10,+10),  {"speed": VAR_SPEED,"gravity": VAR_GRAVITY,"deviation": VAR_DEVIATION} )!
                           mouse(VAR_PIC_X + rand (-10,+10),VAR_PIC_Y + rand (-10,+10))!
                           

                        })!
                        

                     })!
                     

                     
                     
                     _set_if_expression("W1tFUlJPUl9FWElTVFNdXSA9PSB0cnVl");
                     _if(VAR_ERROR_EXISTS == true,function(){
                     
                        
                        
                        /*Browser*/
                        move(VAR_PIC_X + rand (-7,+7),VAR_PIC_Y + rand (-7,+7),  {"speed": VAR_SPEED,"gravity": VAR_GRAVITY,"deviation": VAR_DEVIATION} )!
                        mouse(VAR_PIC_X + rand (-7,+7),VAR_PIC_Y + rand (-7,+7))!
                        

                     })!
                     

                     
                     
                     _set_if_expression("W1tJUzMzXV0gPT0gdHJ1ZQ==");
                     _if(VAR_IS33 == true,function(){
                     
                        
                        
                        /*Browser*/
                        ;_SELECTOR=VAR_RECAPTCHA_PREFIX_SECOND_FRAME + "\u003eXPATH\u003e//*[@class=\u0022rc-imageselect-tile rc-imageselect-tileselected\u0022]";
                        get_element_selector(_SELECTOR, false).nowait().exist()!
                        VAR_IS_EXISTS = _result() == 1
                        _if(VAR_IS_EXISTS, function(){
                        get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
                        VAR_IS_EXISTS = _result().indexOf("true")>=0
                        })!
                        

                        
                        
                        _set_if_expression("W1tJU19FWElTVFNdXSA9PSBmYWxzZQ==");
                        _if(VAR_IS_EXISTS == false,function(){
                        
                           
                           
                           if (VAR_FOREACH_DATA == 4)
                           {
                           VAR_X_IMAGE = 0;
                           VAR_Y_IMAGE = 0;
                           }
                           if (VAR_FOREACH_DATA == 5)
                           {
                           VAR_X_IMAGE = 100;
                           VAR_Y_IMAGE = 0;
                           }
                           if (VAR_FOREACH_DATA == 6)
                           {
                           VAR_X_IMAGE = 200;
                           VAR_Y_IMAGE = 0;
                           }
                           if (VAR_FOREACH_DATA == 7)
                           {
                           VAR_X_IMAGE = 0;
                           VAR_Y_IMAGE = 100;
                           }
                           if (VAR_FOREACH_DATA == 8)
                           {
                           VAR_X_IMAGE = 100;
                           VAR_Y_IMAGE = 100;
                           }
                           if (VAR_FOREACH_DATA == 9)
                           {
                           VAR_X_IMAGE = 200;
                           VAR_Y_IMAGE = 100;
                           }
                           if (VAR_FOREACH_DATA == 10)
                           {
                           VAR_X_IMAGE = 0;
                           VAR_Y_IMAGE = 200;
                           }
                           if (VAR_FOREACH_DATA == 11)
                           {
                           VAR_X_IMAGE = 100;
                           VAR_Y_IMAGE = 200;
                           }
                           if (VAR_FOREACH_DATA == 12)
                           {
                           VAR_X_IMAGE = 200;
                           VAR_Y_IMAGE = 200;
                           }
                           

                           
                           
                           waiter_timeout_next(9000);
                           wait_load("recaptcha/*/payload")!
                           

                           
                           
                           _do(function(){
                           _set_action_info({ name: "For" });
                           VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
                           if(VAR_CYCLE_INDEX > parseInt(60))_break();
                           
                              
                              
                              cache_get_base64("recaptcha/*/payload")!
                              var image_id = native("imageprocessing", "load", _result())
                              var image_size = native("imageprocessing", "getsize", image_id)
                              var image_h = parseInt(image_size.split(",")[1])
                              if (image_h == 0 && VAR_CYCLE_INDEX > 30) _break()
                              //// Ждём в кэше маленькую картинку
                              if (image_h > 75) {
                              VAR_SAVED_CROP_IMAGE = _result()
                              _break()
                              }
                              get_element_selector(VAR_RECAPTCHA_PREFIX_SECOND_FRAME_ELEMENT).script("window.getComputedStyle(self)['visibility']")!
                              if(_result() == "hidden")
                              {
                              VAR_RECAPTCHA_2_CLOSED = 1;
                              _break()
                              }
                              sleep(400)!
                              

                           })!
                           

                           
                           
                           _set_if_expression("W1tSRUNBUFRDSEFfMl9DTE9TRURdXSA9PSAx");
                           _if(VAR_RECAPTCHA_2_CLOSED == 1,function(){
                           
                              
                              
                              _break("function")
                              

                           })!
                           

                           
                           
                           VAR_IMAGE_BASE_64 = native("imageprocessing", "load", VAR_IMAGE_BASE_64)
                           

                           
                           
                           VAR_LOADED_CROP = native("imageprocessing", "load", VAR_SAVED_CROP_IMAGE)
                           

                           
                           
                           _set_if_expression("W1tSRUNBUFRDSEFfMl9JTlZJU0lCTEVdXSA9PSAx");
                           _if(VAR_RECAPTCHA_2_INVISIBLE == 1,function(){
                           
                              
                              
                              native("imageprocessing", "resize", (VAR_IMAGE_BASE_64) + "," + (300) + "," + (300))
                              

                              
                              
                              VAR_RECAPTCHA_2_INVISIBLE = parseInt(VAR_RECAPTCHA_2_INVISIBLE) + parseInt(1)
                              

                           })!
                           

                           
                           
                           native("imageprocessing", "insert", (VAR_IMAGE_BASE_64) + "," + (VAR_LOADED_CROP) + ","  + (VAR_X_IMAGE) + "," + (VAR_Y_IMAGE))
                           

                           
                           
                           VAR_IMAGE_BASE_64 = native("imageprocessing", "getdata", VAR_IMAGE_BASE_64)
                           

                           
                           
                           native("imageprocessing", "delete", VAR_IMAGE_BASE_64)
                           

                           
                           
                           native("imageprocessing", "delete", VAR_LOADED_CROP)
                           

                           
                           
                           _set_if_expression("W1tSRUNBUFRDSEFfMl9JTlZJU0lCTEVdXSAgPT0gOTk5OTk5OQ==");
                           _if(VAR_RECAPTCHA_2_INVISIBLE  == 9999999,function(){
                           
                              
                              
                              VAR_THREAD_INDEX = thread_number()
                              

                              
                              
                              native("filesystem", "writefile", JSON.stringify({path: "C:\u005cImages\u005cRecaptcha2" + VAR_THREAD_INDEX + ".png",value: (VAR_IMAGE_BASE_64).toString(),base64:true,append:false}))
                              

                              
                              
                              native("filesystem", "writefile", JSON.stringify({path: "C:\u005cImages\u005cRecaptcha2_Crop" + VAR_THREAD_INDEX + ".png",value: (VAR_SAVED_CROP_IMAGE).toString(),base64:true,append:false}))
                              

                           })!
                           

                           
                           
                           VAR_BAS_CAPMONSTER_IMAGE_ID = "1"
                           

                           
                           
                           sleep(100)!
                           

                        })!
                        

                     })!
                     

                  })!
                  

                  
                  
                  _set_if_expression("W1tSRUNBUFRDSEFfMl9DTE9TRURdXSA9PSAx");
                  _if(VAR_RECAPTCHA_2_CLOSED == 1,function(){
                  
                     
                     
                     _break("function")
                     

                  })!
                  

                  
                  
                  _set_if_expression("W1tJUzMzXV0gPT0gdHJ1ZQ==");
                  _if(VAR_IS33 == true,function(){
                  
                     
                     
                     /*Browser*/
                     ;_SELECTOR=VAR_RECAPTCHA_PREFIX_SECOND_FRAME + "\u003eXPATH\u003e//*[@class=\u0022rc-imageselect-tile rc-imageselect-tileselected\u0022]";
                     get_element_selector(_SELECTOR, false).nowait().exist()!
                     VAR_IS_EXISTS = _result() == 1
                     _if(VAR_IS_EXISTS, function(){
                     get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
                     VAR_IS_EXISTS = _result().indexOf("true")>=0
                     })!
                     

                     
                     
                     _set_if_expression("W1tJU19FWElTVFNdXQ==");
                     _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
                     
                        
                        
                        cache_data_clear()!
                        

                        
                        
                        /*Browser*/
                        _SELECTOR = VAR_RECAPTCHA_PREFIX_SECOND_FRAME + "\u003eXPATH\u003e id(\u0022recaptcha-verify-button\u0022)";
                        wait_element_visible(_SELECTOR)!
                        _call(_random_point, {})!
                        _if(_result().length > 0, function(){
                        move( {"speed": VAR_SPEED,"gravity": VAR_GRAVITY,"deviation": VAR_DEVIATION} )!
                        get_element_selector(_SELECTOR, false).clarify(X,Y)!
                        _call(_clarify, {"speed": VAR_SPEED,"gravity": VAR_GRAVITY,"deviation": VAR_DEVIATION} )!
                        mouse(X,Y)!
                        })!
                        

                        
                        
                        sleep(100)!
                        

                     })!
                     

                     
                     
                     /*Browser*/
                     ;_SELECTOR=VAR_RECAPTCHA_PREFIX_SECOND_FRAME + "\u003eXPATH\u003e //div[@class=\u0022rc-imageselect-error-select-more\u0022]";
                     get_element_selector(_SELECTOR, false).nowait().exist()!
                     VAR_IS_EXISTS_1 = _result() == 1
                     _if(VAR_IS_EXISTS_1, function(){
                     get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
                     VAR_IS_EXISTS_1 = _result().indexOf("true")>=0
                     })!
                     

                     
                     
                     /*Browser*/
                     ;_SELECTOR=VAR_RECAPTCHA_PREFIX_SECOND_FRAME + "\u003eXPATH\u003e //div[@class=\u0022rc-imageselect-error-dynamic-more\u0022]";
                     get_element_selector(_SELECTOR, false).nowait().exist()!
                     VAR_IS_EXISTS_2 = _result() == 1
                     _if(VAR_IS_EXISTS_2, function(){
                     get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
                     VAR_IS_EXISTS_2 = _result().indexOf("true")>=0
                     })!
                     

                     
                     
                     _set_if_expression("W1tJU19FWElTVFNfMV1dIHx8IFtbSVNfRVhJU1RTXzJdXQ==");
                     _if(VAR_IS_EXISTS_1 || VAR_IS_EXISTS_2,function(){
                     
                        
                        
                        VAR_BAS_CAPMONSTER_IMAGE_ID = "0"
                        

                        
                        
                        _set_if_expression("W1tSRUNBUFRDSEFfMl9JTlZJU0lCTEVdXSA9PSAx");
                        _if(VAR_RECAPTCHA_2_INVISIBLE == 1,function(){
                        
                           
                           
                           VAR_RECAPTCHA_2_INVISIBLE = parseInt(VAR_RECAPTCHA_2_INVISIBLE) + parseInt(1)
                           

                        })!
                        

                        
                        
                        cache_data_clear()!
                        

                        
                        
                        /*Browser*/
                        _SELECTOR = VAR_RECAPTCHA_PREFIX_SECOND_FRAME + "\u003eXPATH\u003e id(\u0022recaptcha-reload-button\u0022)";
                        wait_element_visible(_SELECTOR)!
                        _call(_random_point, {})!
                        _if(_result().length > 0, function(){
                        move( {"speed": VAR_SPEED,"gravity": VAR_GRAVITY,"deviation": VAR_DEVIATION} )!
                        get_element_selector(_SELECTOR, false).clarify(X,Y)!
                        _call(_clarify, {"speed": VAR_SPEED,"gravity": VAR_GRAVITY,"deviation": VAR_DEVIATION} )!
                        mouse(X,Y)!
                        })!
                        

                     })!
                     

                  })!
                  

                  
                  
                  _set_if_expression("W1tJUzQ0XV0gPT0gdHJ1ZQ==");
                  _if(VAR_IS44 == true,function(){
                  
                     
                     
                     cache_data_clear()!
                     

                     
                     
                     /*Browser*/
                     _SELECTOR = VAR_RECAPTCHA_PREFIX_SECOND_FRAME + "\u003eXPATH\u003e id(\u0022recaptcha-verify-button\u0022)";
                     wait_element_visible(_SELECTOR)!
                     _call(_random_point, {})!
                     _if(_result().length > 0, function(){
                     move( {"speed": VAR_SPEED,"gravity": VAR_GRAVITY,"deviation": VAR_DEVIATION} )!
                     get_element_selector(_SELECTOR, false).clarify(X,Y)!
                     _call(_clarify, {"speed": VAR_SPEED,"gravity": VAR_GRAVITY,"deviation": VAR_DEVIATION} )!
                     mouse(X,Y)!
                     })!
                     

                     
                     
                     sleep(100)!
                     

                  })!
                  

                  
                  
                  _set_if_expression("W1tSRUNBUFRDSEFfMl9JTlZJU0lCTEVdXSA9PSAx");
                  _if(VAR_RECAPTCHA_2_INVISIBLE == 1,function(){
                  
                     
                     
                     VAR_RECAPTCHA_2_INVISIBLE = parseInt(VAR_RECAPTCHA_2_INVISIBLE) + parseInt(1)
                     

                  })!
                  

                  
                  
                  sleep(rand(200,500))!
                  

                  
                  
                  _break("function")
                  

               })!
               

               
               
               _if(!_cycle_params().if_else,function(){
               
                  
                  
                  sleep(1000)!
                  

                  
                  
                  _next("function")
                  

               })!
               delete _cycle_params().if_else;
               

            })!
            

            
            
            _next("function")
            

         },null)!
         

         
         
         _set_if_expression("W1tXQVNfRVJST1JdXQ==");
         _if(typeof(VAR_WAS_ERROR) !== "undefined" ? (VAR_WAS_ERROR) : undefined,function(){
         
            
            
            sleep(1000)!
            

            
            
            VAR_BAS_CAPMONSTER_IMAGE_ID = "0"
            

            
            
            _set_if_expression("W1tSRUNBUFRDSEFfMl9JTlZJU0lCTEVdXSA9PSAx");
            _if(VAR_RECAPTCHA_2_INVISIBLE == 1,function(){
            
               
               
               VAR_RECAPTCHA_2_INVISIBLE = parseInt(VAR_RECAPTCHA_2_INVISIBLE) + parseInt(1)
               

            })!
            

            
            
            _set_if_expression("W1tMQVNUX0VSUk9SXV0uaW5kZXhPZigicGF5bG9hZCIpID49IDAg");
            _if(VAR_LAST_ERROR.indexOf("payload") >= 0 ,function(){
            
               
               
               _call(function()
               {
               _on_fail(function(){
               VAR_LAST_ERROR = _result()
               VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
               VAR_WAS_ERROR = false
               _break(1,true)
               })
               CYCLES.Current().RemoveLabel("function")
               
                  
                  
                  /*Browser*/
                  ;_SELECTOR=VAR_RECAPTCHA_PREFIX_SECOND_FRAME + "\u003eXPATH\u003e id(\u0022recaptcha-reload-button\u0022)";
                  get_element_selector(_SELECTOR, false).nowait().exist()!
                  VAR_IS_EXISTS = _result() == 1
                  _if(VAR_IS_EXISTS, function(){
                  get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
                  VAR_IS_EXISTS = _result().indexOf("true")>=0
                  })!
                  

                  
                  
                  _set_if_expression("W1tJU19FWElTVFNdXQ==");
                  _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
                  
                     
                     
                     /*Browser*/
                     _SELECTOR = VAR_RECAPTCHA_PREFIX_SECOND_FRAME + "\u003eXPATH\u003e id(\u0022recaptcha-reload-button\u0022)";
                     wait_element_visible(_SELECTOR)!
                     _call(_random_point, {})!
                     _if(_result().length > 0, function(){
                     move( {"speed": VAR_SPEED,"gravity": VAR_GRAVITY,"deviation": VAR_DEVIATION} )!
                     get_element_selector(_SELECTOR, false).clarify(X,Y)!
                     _call(_clarify, {"speed": VAR_SPEED,"gravity": VAR_GRAVITY,"deviation": VAR_DEVIATION} )!
                     mouse(X,Y)!
                     })!
                     

                  })!
                  

               },null)!
               

            })!
            

            
            
            _next("function")
            

         })!
         

      })!
      

   }
   

