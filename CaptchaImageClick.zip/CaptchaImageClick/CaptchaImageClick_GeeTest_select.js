var xsjngzty = GetInputConstructorValue("xsjngzty", loader);
                 if(xsjngzty["original"].length == 0)
                 {
                   Invalid("KEY" + " is empty");
                   return;
                 }
var zrsiisyg = GetInputConstructorValue("zrsiisyg", loader);
                 if(zrsiisyg["original"].length == 0)
                 {
                   Invalid("METHOD" + " is empty");
                   return;
                 }
var zetrilkf = GetInputConstructorValue("zetrilkf", loader);
                 if(zetrilkf["original"].length == 0)
                 {
                   Invalid("SELECTOR" + " is empty");
                   return;
                 }
var zetrbase64 = GetInputConstructorValue("zetrbase64", loader);
                 if(zetrbase64["original"].length == 0)
                 {
                   Invalid("SELECTOR" + " is empty");
                   return;
                 }
var ambhfnyz = GetInputConstructorValue("ambhfnyz", loader);
                 if(ambhfnyz["original"].length == 0)
                 {
                   Invalid("TRY_MAX_CAPTCHA_PICTURE" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#CaptchaImageClick_GeeTest_code").html())({"xsjngzty": xsjngzty["updated"],"zrsiisyg": zrsiisyg["updated"],"zetrilkf": zetrilkf["updated"],"zetrbase64": zetrbase64["updated"],"ambhfnyz": ambhfnyz["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
