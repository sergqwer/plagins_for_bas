_call_function(CaptchaImageClick_GeeTest,{ "KEY": (<%= xsjngzty %>),"METHOD": (<%= zrsiisyg %>),"SELECTOR": (<%= zetrilkf %>),"TRY_MAX_CAPTCHA_PICTURE": (<%= ambhfnyz %>) })!
