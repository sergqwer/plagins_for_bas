var vcufqelc = GetInputConstructorValue("vcufqelc", loader);
                 if(vcufqelc["original"].length == 0)
                 {
                   Invalid("KEY" + " is empty");
                   return;
                 }
var xasslgdv = GetInputConstructorValue("xasslgdv", loader);
                 if(xasslgdv["original"].length == 0)
                 {
                   Invalid("METHOD" + " is empty");
                   return;
                 }
var eslyxftj = GetInputConstructorValue("eslyxftj", loader);
                 if(eslyxftj["original"].length == 0)
                 {
                   Invalid("NUMBER_CAPTCHA" + " is empty");
                   return;
                 }
var padxyhdm = GetInputConstructorValue("padxyhdm", loader);
                 if(padxyhdm["original"].length == 0)
                 {
                   Invalid("SELECTOR" + " is empty");
                   return;
                 }
var njxltqyc = GetInputConstructorValue("njxltqyc", loader);
                 if(njxltqyc["original"].length == 0)
                 {
                   Invalid("SPEED_MOUSE" + " is empty");
                   return;
                 }
var bjviytym = GetInputConstructorValue("bjviytym", loader);
                 if(bjviytym["original"].length == 0)
                 {
                   Invalid("TRY_MAX_CAPTCHA_PICTURE" + " is empty");
                   return;
                 }
var acpuurdq = GetInputConstructorValue("acpuurdq", loader);
                 if(acpuurdq["original"].length == 0)
                 {
                   Invalid("URL" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#CaptchaImageClick_FunCaptcha_code").html())({"vcufqelc": vcufqelc["updated"],"xasslgdv": xasslgdv["updated"],"eslyxftj": eslyxftj["updated"],"padxyhdm": padxyhdm["updated"],"njxltqyc": njxltqyc["updated"],"bjviytym": bjviytym["updated"],"acpuurdq": acpuurdq["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
