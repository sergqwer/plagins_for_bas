function For_All_Puzzle_GeeTest_Solver()
   {
   
      
      
      VAR_ARROW_ID = _function_argument("arrow_id")
      

      
      
      VAR_BUTTON_ID = _function_argument("button_id")
      

      
      
      VAR_COEF = _function_argument("coef")
      

      
      
      VAR_IMAGE_ID = _function_argument("image id")
      

      
      
      VAR_RELOAD_ID = _function_argument("reload_id")
      

      
      
      VAR_PIXEL_KOEF = _function_argument("pixel_koef")
      

      
      
      VAR_AVTOUPDATE = _function_argument("avtoupdate")
      

      
      
      VAR_KEY = _function_argument("key")
      

      
      
      VAR_SPEED = _function_argument("speed")
      

      
      
      VAR_TYPE_SWIPE = _function_argument("type_swipe")
      

      
      
      _call(function()
      {
      _on_fail(function(){
      VAR_LAST_ERROR = _result()
      VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
      VAR_WAS_ERROR = false
      _break(1,true)
      })
      CYCLES.Current().RemoveLabel("function")
      
         
         
         /*Browser*/
         waiter_timeout_next(5000)
         wait_async_load()!
         

      },null)!
      

      
      
      /*Browser*/
      ;_SELECTOR=VAR_IMAGE_ID;
      get_element_selector(_SELECTOR, false).nowait().exist()!
      VAR_IS_EXISTS = _result() == 1
      _if(VAR_IS_EXISTS, function(){
      get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
      VAR_IS_EXISTS = _result().indexOf("true")>=0
      })!
      

      
      
      _do(function(){
      _set_action_info({ name: "While" });
      VAR_CYCLE_INDEX = _iterator() - 1
      BREAK_CONDITION = VAR_IS_EXISTS == false;
      if(!BREAK_CONDITION)_break();
      
         
         
         _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gNQ==");
         _if(VAR_CYCLE_INDEX > 5,function(){
         
            
            
            fail_user("Капча не найдена, перезагрузите страницу",false)
            

         })!
         

         
         
         /*Browser*/
         ;_SELECTOR=VAR_BUTTON_ID;
         get_element_selector(_SELECTOR, false).nowait().exist()!
         VAR_IS_EXISTS = _result() == 1
         _if(VAR_IS_EXISTS, function(){
         get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
         VAR_IS_EXISTS = _result().indexOf("true")>=0
         })!
         

         
         
         _cycle_params().if_else = VAR_IS_EXISTS == false;
         _set_if_expression("W1tJU19FWElTVFNdXSA9PSBmYWxzZQ==");
         _if(_cycle_params().if_else,function(){
         
            
            
            fail_user("Капча не найдена, перезагрузите страницу",false)
            

         })!
         

         
         
         _if(!_cycle_params().if_else,function(){
         
            
            
            /*Browser*/
            _SELECTOR = VAR_BUTTON_ID;
            wait_element_visible(_SELECTOR)!
            _call(_random_point, {})!
            _if(_result().length > 0, function(){
            move( {} )!
            get_element_selector(_SELECTOR, false).clarify(X,Y)!
            _call(_clarify, {} )!
            mouse(X,Y)!
            })!
            

            
            
            _call(function()
            {
            _on_fail(function(){
            VAR_LAST_ERROR = _result()
            VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
            VAR_WAS_ERROR = false
            _break(1,true)
            })
            CYCLES.Current().RemoveLabel("function")
            
               
               
               /*Browser*/
               IDDLE_EMULATION_END = Date.now() + 1000 * (4)
               IDDLE_EMULATION_DISTRIBUTION = [2,3,3,3,4,4]
               _get_browser_screen_settings()!
               IDDLE_EMULATION_RESULT = JSON.parse(_result())
               IDDLE_CURSOR_POSITION_X = IDDLE_EMULATION_RESULT["CursorX"]
               IDDLE_CURSOR_POSITION_Y = IDDLE_EMULATION_RESULT["CursorY"]
               IDDLE_CURSOR_POSITION_WIDTH = IDDLE_EMULATION_RESULT["Width"]
               IDDLE_CURSOR_POSITION_HEIGHT = IDDLE_EMULATION_RESULT["Height"]
               IDDLE_CURSOR_POSITION_WAS_SCROLL = false
               _do(function(){
               if(Date.now() >= IDDLE_EMULATION_END)
               _break()
               IDDLE_EMULATION_CURRENT_ITEM = IDDLE_EMULATION_DISTRIBUTION[Math.floor(Math.random()*IDDLE_EMULATION_DISTRIBUTION.length)]
               if(_iterator() == 1 && IDDLE_EMULATION_DISTRIBUTION.indexOf(2)>=0)
               IDDLE_EMULATION_CURRENT_ITEM = 2
               _if(IDDLE_EMULATION_CURRENT_ITEM == 1, function(){
               //scroll
               IDDLE_EMULATION_CURRENT_DIRECTION = (rand(1,2) == 2) ? "<MOUSESCROLLUP>" : "<MOUSESCROLLDOWN>"
               if(!IDDLE_CURSOR_POSITION_WAS_SCROLL)
               IDDLE_EMULATION_CURRENT_DIRECTION = "<MOUSESCROLLDOWN>"
               IDDLE_CURSOR_POSITION_WAS_SCROLL = true
               IDDLE_EMULATION_CURRENT_NUMBER = rand(1,5)
               _do(function(){
               if(_iterator() >= IDDLE_EMULATION_CURRENT_NUMBER)
               _break()
               _type(IDDLE_EMULATION_CURRENT_DIRECTION,1000)!
               sleep(rand(300,1000))!
               })!
               })!
               _if(IDDLE_EMULATION_CURRENT_ITEM == 2, function(){
               //long move
               page().script("document.documentElement.scrollLeft")!
               IDDLE_CURSOR_POSITION_SCROLL_X = parseInt(_result())
               page().script("document.documentElement.scrollTop")!
               IDDLE_CURSOR_POSITION_SCROLL_Y = parseInt(_result())
               IDDLE_CURSOR_POSITION_X = rand(1,IDDLE_CURSOR_POSITION_WIDTH)
               IDDLE_CURSOR_POSITION_Y = rand(1,IDDLE_CURSOR_POSITION_HEIGHT)
               move(IDDLE_CURSOR_POSITION_SCROLL_X + IDDLE_CURSOR_POSITION_X,IDDLE_CURSOR_POSITION_SCROLL_Y + IDDLE_CURSOR_POSITION_Y)!
               })!
               _if(IDDLE_EMULATION_CURRENT_ITEM == 3, function(){
               //short move
               if(IDDLE_CURSOR_POSITION_X < 0 || IDDLE_CURSOR_POSITION_Y < 0)
               _break()
               page().script("document.documentElement.scrollLeft")!
               IDDLE_CURSOR_POSITION_SCROLL_X = parseInt(_result())
               page().script("document.documentElement.scrollTop")!
               IDDLE_CURSOR_POSITION_SCROLL_Y = parseInt(_result())
               IDDLE_EMULATION_CURRENT_NUMBER = rand(1,4)
               _do(function(){
               if(_iterator() >= IDDLE_EMULATION_CURRENT_NUMBER)
               _break()
               IDDLE_CURSOR_POSITION_X += rand(-50,50)
               IDDLE_CURSOR_POSITION_Y += rand(-50,50)
               if(IDDLE_CURSOR_POSITION_X > IDDLE_CURSOR_POSITION_WIDTH)
               IDDLE_CURSOR_POSITION_X = IDDLE_CURSOR_POSITION_WIDTH
               if(IDDLE_CURSOR_POSITION_Y > IDDLE_CURSOR_POSITION_HEIGHT)
               IDDLE_CURSOR_POSITION_Y = IDDLE_CURSOR_POSITION_HEIGHT
               if(IDDLE_CURSOR_POSITION_X < 0)
               IDDLE_CURSOR_POSITION_X = 0
               if(IDDLE_CURSOR_POSITION_Y < 0)
               IDDLE_CURSOR_POSITION_Y = 0
               move(IDDLE_CURSOR_POSITION_SCROLL_X + IDDLE_CURSOR_POSITION_X,IDDLE_CURSOR_POSITION_SCROLL_Y + IDDLE_CURSOR_POSITION_Y)!
               _if(rand(1,10) > 3,function(){
               sleep(rand(10,300))!
               })!
               })!
               })!
               _if(IDDLE_EMULATION_CURRENT_ITEM == 4, function(){
               //sleep
               sleep(rand(500,5000))!
               })!
               })!
               

            },null)!
            

         })!
         delete _cycle_params().if_else;
         

         
         
         /*Browser*/
         ;_SELECTOR=VAR_IMAGE_ID;
         get_element_selector(_SELECTOR, false).nowait().exist()!
         VAR_IS_EXISTS = _result() == 1
         _if(VAR_IS_EXISTS, function(){
         get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
         VAR_IS_EXISTS = _result().indexOf("true")>=0
         })!
         

      })!
      

      
      
      /*Browser*/
      ;_SELECTOR=VAR_IMAGE_ID;
      get_element_selector(_SELECTOR, false).nowait().exist()!
      VAR_IS_EXISTS = _result() == 1
      _if(VAR_IS_EXISTS, function(){
      get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
      VAR_IS_EXISTS = _result().indexOf("true")>=0
      })!
      

      
      
      _do(function(){
      _set_action_info({ name: "While" });
      VAR_CYCLE_INDEX = _iterator() - 1
      BREAK_CONDITION = VAR_IS_EXISTS;
      if(!BREAK_CONDITION)_break();
      
         
         
         _set_if_expression("W1tDWUNMRV9JTkRFWF1dID49IDk=");
         _if(VAR_CYCLE_INDEX >= 9,function(){
         
            
            
            fail_user("Капча не решена за 10 попыток",false)
            

         })!
         

         
         
         /*Browser*/
         _SELECTOR = VAR_IMAGE_ID;
         wait_element(_SELECTOR)!
         get_element_selector(_SELECTOR, false).exist()!
         _if(_result() == "1", function(){
         get_element_selector(_SELECTOR, false).render_base64()!
         VAR_SCREENSHOT_BASE64 = _result()
         })!
         

         
         
         VAR_STRING_LENGTH = _string_length(VAR_SCREENSHOT_BASE64);
         

         
         
         _set_if_expression("W1tTVFJJTkdfTEVOR1RIXV0gPCAxMDAw");
         _if(VAR_STRING_LENGTH < 1000,function(){
         
            
            
            fail_user("Слишком маленькая картинка, вы явно задали не тот идентификатор изображения",false)
            

         })!
         

         
         
         _do(function(){
         _set_action_info({ name: "For" });
         VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
         if(VAR_CYCLE_INDEX > parseInt(3))_break();
         
            
            
            _set_if_expression("W1tDWUNMRV9JTkRFWF1dID49IDM=");
            _if(VAR_CYCLE_INDEX >= 3,function(){
            
               
               
               fail_user(VAR_LAST_ERROR,false)
               

            })!
            

            
            
            _call(function()
            {
            _on_fail(function(){
            VAR_LAST_ERROR = _result()
            VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
            VAR_WAS_ERROR = false
            _break(1,true)
            })
            CYCLES.Current().RemoveLabel("function")
            
               
               
               _switch_http_client_main()
               http_client_post("http://goodxevilpay.shop/in.php", ["method","geetest","key",VAR_KEY,"body",VAR_SCREENSHOT_BASE64], {"content-type":("multipart"), "encoding":("UTF-8"), "method":("POST"),headers:("")})!
               

               
               
               _switch_http_client_main()
               VAR_SAVED_CONTENT = http_client_encoded_content("utf-8")
               

               
               
               _break("function")
               

            },null)!
            

         })!
         

         
         
         VAR_STRING_CONTAINS = _string_contains(VAR_SAVED_CONTENT,"|");
         

         
         
         _set_if_expression("W1tTVFJJTkdfQ09OVEFJTlNdXSA9PSBmYWxzZQ==");
         _if(VAR_STRING_CONTAINS == false,function(){
         
            
            
            fail_user(VAR_SAVED_CONTENT,false)
            

         })!
         

         
         
         sleep(1000)!
         

         
         
         VAR_ID = VAR_SAVED_CONTENT.split("|")[1]
         

         
         
         _do(function(){
         _set_action_info({ name: "For" });
         VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
         if(VAR_CYCLE_INDEX > parseInt(3))_break();
         
            
            
            _set_if_expression("W1tDWUNMRV9JTkRFWF1dID49IDM=");
            _if(VAR_CYCLE_INDEX >= 3,function(){
            
               
               
               fail_user(VAR_LAST_ERROR,false)
               

            })!
            

            
            
            _call(function()
            {
            _on_fail(function(){
            VAR_LAST_ERROR = _result()
            VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
            VAR_WAS_ERROR = false
            _break(1,true)
            })
            CYCLES.Current().RemoveLabel("function")
            
               
               
               _switch_http_client_main()
               http_client_get2("http://goodxevilpay.shop/res.php?key=" + VAR_KEY + "\u0026id=" + VAR_ID,{method:("GET"),headers:("")})!
               

               
               
               _switch_http_client_main()
               VAR_SAVED_CONTENT = http_client_encoded_content("utf-8")
               

               
               
               _do(function(){
               _set_action_info({ name: "While" });
               VAR_CYCLE_INDEX = _iterator() - 1
               BREAK_CONDITION = VAR_SAVED_CONTENT == "CAPCHA_NOT_READY";
               if(!BREAK_CONDITION)_break();
               
                  
                  
                  sleep(1000)!
                  

                  
                  
                  _switch_http_client_main()
                  http_client_get2("http://goodxevilpay.shop/res.php?key=" + VAR_KEY + "\u0026id=" + VAR_ID,{method:("GET"),headers:("")})!
                  

                  
                  
                  _switch_http_client_main()
                  VAR_SAVED_CONTENT = http_client_encoded_content("utf-8")
                  

               })!
               

               
               
               _break("function")
               

            },null)!
            

         })!
         

         
         
         VAR_STRING_CONTAINS = _string_contains(VAR_SAVED_CONTENT,"|");
         

         
         
         _set_if_expression("W1tTVFJJTkdfQ09OVEFJTlNdXSA9PSBmYWxzZQ==");
         _if(VAR_STRING_CONTAINS == false,function(){
         
            
            
            fail_user(VAR_SAVED_CONTENT,false)
            

         })!
         

         
         
         VAR_SCAN_RESULT_LIST = native("regexp", "scan", JSON.stringify({text: VAR_SAVED_CONTENT,regexp:"\u005cd+"}))
         if(VAR_SCAN_RESULT_LIST.length == 0)
         VAR_SCAN_RESULT_LIST = []
         else
         VAR_SCAN_RESULT_LIST = JSON.parse(VAR_SCAN_RESULT_LIST)
         

         
         
         VAR_LIST_LENGTH = (VAR_SCAN_RESULT_LIST).length
         

         
         
         _set_if_expression("W1tMSVNUX0xFTkdUSF1dICE9IDM=");
         _if(VAR_LIST_LENGTH != 3,function(){
         
            
            
            fail_user("Не понятный ответ от сервера: " + VAR_SAVED_CONTENT,false)
            

         })!
         

         
         
         VAR_X_XEVIL = (_to_number(VAR_SCAN_RESULT_LIST[0],"",".",",") * VAR_COEF) + VAR_PIXEL_KOEF;
         VAR_Y_XEVIL = _to_number(VAR_SCAN_RESULT_LIST[1],"",".",",");
         VAR_W_XEVIL = _to_number(VAR_SCAN_RESULT_LIST[2],"",".",",");
         

         
         
         /*Browser*/
         _SELECTOR = VAR_ARROW_ID;
         wait_element(_SELECTOR)!
         get_element_selector(_SELECTOR, false).script("(function(){var rect = self.getBoundingClientRect();return (rect.left + positionx).toString() + '|' + (rect.top + positiony).toString() + '|' + (rect.right - rect.left).toString() + '|' + (rect.bottom - rect.top).toString()})();")!
         if(_result().length > 0)
         {
         var split = _result().split("|")
         VAR_X = parseInt(split[0])
         VAR_Y = parseInt(split[1])
         VAR_WIDTH = parseInt(split[2])
         VAR_HEIGHT = parseInt(split[3])
         }
         

         
         
         /*Browser*/
         move(VAR_X + (VAR_WIDTH/2),VAR_Y + (VAR_HEIGHT/2),  {"speed": 100*VAR_SPEED,"gravity": 6,"deviation": 2.5} )!
         mouse_down(VAR_X + (VAR_WIDTH/2),VAR_Y + (VAR_HEIGHT/2))!
         

         
         
         _set_if_expression("W1tUWVBFX1NXSVBFXV0gPT0gMQ==");
         _if(VAR_TYPE_SWIPE == 1,function(){
         
            
            
            VAR_RANDOM_SPEED = Math.floor(Math.random() * (parseInt(200) - parseInt(100) + 1)) + parseInt(100)
            

            
            
            VAR_RANDOM_PR = Math.floor(Math.random() * (parseInt(9) - parseInt(5) + 1)) + parseInt(5)
            

            
            
            /*Browser*/
            move(VAR_X+ (VAR_X_XEVIL/1.2),VAR_Y,  {"speed": VAR_RANDOM_SPEED*VAR_SPEED,"gravity": VAR_RANDOM_PR,"deviation": 4} )!
            

            
            
            VAR_RANDOM_SPEED = Math.floor(Math.random() * (parseInt(60) - parseInt(10) + 1)) + parseInt(10)
            

            
            
            VAR_RANDOM_PR = Math.floor(Math.random() * (parseInt(10) - parseInt(7) + 1)) + parseInt(7)
            

            
            
            /*Browser*/
            move(VAR_X+VAR_X_XEVIL + VAR_W_XEVIL/2,VAR_Y,  {"speed": VAR_RANDOM_SPEED*VAR_SPEED,"gravity": VAR_RANDOM_PR,"deviation": 0} )!
            

            
            
            VAR_RANDOM_Y = Math.floor(Math.random() * (parseInt(15) - parseInt(-15) + 1)) + parseInt(-15)
            

            
            
            /*Browser*/
            var move_settings =  {"speed": 50*VAR_SPEED,"gravity": 9,"deviation": 0} ;
            move_settings["do_mouse_up"] = "true"
            move(VAR_X+VAR_X_XEVIL + VAR_W_XEVIL/2,VAR_Y + VAR_RANDOM_Y, move_settings)!
            

         })!
         

         
         
         _set_if_expression("W1tUWVBFX1NXSVBFXV0gPT0gMg==");
         _if(VAR_TYPE_SWIPE == 2,function(){
         
            
            
            VAR_RANDOM_SPEED = Math.floor(Math.random() * (parseInt(40) - parseInt(20) + 1)) + parseInt(20)
            

            
            
            VAR_RANDOM_PR = Math.floor(Math.random() * (parseInt(4) - parseInt(3) + 1)) + parseInt(3)
            

            
            
            VAR_RANDOM_RT = Math.floor(Math.random() * (parseInt(2) - parseInt(1) + 1)) + parseInt(1)
            

            
            
            VAR_RANDOM_Y = Math.floor(Math.random() * (parseInt(5) - parseInt(-5) + 1)) + parseInt(-5)
            

            
            
            /*Browser*/
            var move_settings =  {"speed": VAR_RANDOM_SPEED*VAR_SPEED,"gravity": VAR_RANDOM_PR,"deviation": VAR_RANDOM_RT} ;
            move_settings["do_mouse_up"] = "true"
            move(VAR_X+VAR_X_XEVIL + VAR_W_XEVIL/2,VAR_Y + VAR_RANDOM_Y, move_settings)!
            

         })!
         

         
         
         _set_if_expression("W1tUWVBFX1NXSVBFXV0gPT0gMw==");
         _if(VAR_TYPE_SWIPE == 3,function(){
         
            
            
            VAR_RANDOM_SPEED = Math.floor(Math.random() * (parseInt(200) - parseInt(150) + 1)) + parseInt(150)
            

            
            
            VAR_RANDOM_PR = Math.floor(Math.random() * (parseInt(4) - parseInt(3) + 1)) + parseInt(3)
            

            
            
            VAR_RANDOM_RT = Math.floor(Math.random() * (parseInt(3) - parseInt(2) + 1)) + parseInt(2)
            

            
            
            VAR_RANDOM_Y = Math.floor(Math.random() * (parseInt(5) - parseInt(-5) + 1)) + parseInt(-5)
            

            
            
            /*Browser*/
            var move_settings =  {"speed": VAR_RANDOM_SPEED*VAR_SPEED,"gravity": VAR_RANDOM_PR,"deviation": VAR_RANDOM_RT} ;
            move_settings["do_mouse_up"] = "true"
            move(VAR_X+VAR_X_XEVIL + VAR_W_XEVIL/2,VAR_Y + VAR_RANDOM_Y, move_settings)!
            

         })!
         

         
         
         _set_if_expression("W1tUWVBFX1NXSVBFXV0gPT0gNA==");
         _if(VAR_TYPE_SWIPE == 4,function(){
         
            
            
            VAR_RANDOM_SPEED = Math.floor(Math.random() * (parseInt(200) - parseInt(150) + 1)) + parseInt(150)
            

            
            
            VAR_RANDOM_PR = Math.floor(Math.random() * (parseInt(9) - parseInt(7) + 1)) + parseInt(7)
            

            
            
            VAR_RANDOM_RT = Math.floor(Math.random() * (parseInt(1) - parseInt(0) + 1)) + parseInt(0)
            

            
            
            VAR_RANDOM_Y = Math.floor(Math.random() * (parseInt(5) - parseInt(-5) + 1)) + parseInt(-5)
            

            
            
            /*Browser*/
            var move_settings =  {"speed": VAR_RANDOM_SPEED*VAR_SPEED,"gravity": VAR_RANDOM_PR,"deviation": VAR_RANDOM_RT} ;
            move_settings["do_mouse_up"] = "true"
            move(VAR_X+VAR_X_XEVIL + VAR_W_XEVIL/2,VAR_Y + VAR_RANDOM_Y, move_settings)!
            

         })!
         

         
         
         _call(function()
         {
         _on_fail(function(){
         VAR_LAST_ERROR = _result()
         VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
         VAR_WAS_ERROR = false
         _break(1,true)
         })
         CYCLES.Current().RemoveLabel("function")
         
            
            
            /*Browser*/
            waiter_timeout_next(5000)
            wait_async_load()!
            

         },null)!
         

         
         
         /*Browser*/
         ;_SELECTOR=VAR_IMAGE_ID;
         get_element_selector(_SELECTOR, false).nowait().exist()!
         VAR_IS_EXISTS = _result() == 1
         _if(VAR_IS_EXISTS, function(){
         get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
         VAR_IS_EXISTS = _result().indexOf("true")>=0
         })!
         

         
         
         _set_if_expression("W1tBVlRPVVBEQVRFXV0gPT0gImZhbHNlIg==");
         _if(VAR_AVTOUPDATE == "false",function(){
         
            
            
            _set_if_expression("W1tJU19FWElTVFNdXQ==");
            _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
            
               
               
               /*Browser*/
               _SELECTOR = VAR_RELOAD_ID;
               wait_element_visible(_SELECTOR)!
               _call(_random_point, {})!
               _if(_result().length > 0, function(){
               move( {} )!
               get_element_selector(_SELECTOR, false).clarify(X,Y)!
               _call(_clarify, {} )!
               mouse(X,Y)!
               })!
               

               
               
               _call(function()
               {
               _on_fail(function(){
               VAR_LAST_ERROR = _result()
               VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
               VAR_WAS_ERROR = false
               _break(1,true)
               })
               CYCLES.Current().RemoveLabel("function")
               
                  
                  
                  /*Browser*/
                  waiter_timeout_next(15000)
                  wait_async_load()!
                  

               },null)!
               

            })!
            

         })!
         

      })!
      

   }
   

