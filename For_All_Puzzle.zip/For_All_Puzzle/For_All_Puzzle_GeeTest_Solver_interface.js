<div class="container-fluid">
<%= _.template($('#input_constructor').html())({id:"hbsrswnj", description:"arrow_id", default_selector: "string", disable_int:true, value_string: " >CSS> .geetest_slider_button", help: {description: "Идентификатор кнопки, которую надо провести"} }) %>
<%= _.template($('#input_constructor').html())({id:"rypdkhcy", description:"avtoupdate", default_selector: "string", disable_int:true, value_string: "true", help: {description: "true - капча обновляется сама после неуспешного решения\nfalse - надо нажать на кнопку, чтобы обновить задание"} }) %>
<%= _.template($('#input_constructor').html())({id:"uquqsrfu", description:"button_id", default_selector: "string", disable_int:true, value_string: " >CSS> .geetest_radar_tip", help: {description: "Идентификатор кнопки, на которую надо нажать, чтобы появилась капча"} }) %>
<%= _.template($('#input_constructor').html())({id:"xkcldowz", description:"coef", default_selector: "expression", disable_int:true, disable_string:true, value_string: "1", help: {description: "На некоторых сайтах пазл движется быстрее чем ползунок, укажите коефициент от 0.6 до 1.4 (При решении капчи бот всегда промахивается на разное расстояние в зависимости от отдаления пазла)"} }) %>
<%= _.template($('#input_constructor').html())({id:"pnecoeif", description:"image id", default_selector: "string", disable_int:true, value_string: " >CSS> .geetest_canvas_slice", help: {description: "Идентификатор изображения капчи"} }) %>
<%= _.template($('#input_constructor').html())({id:"fwunnzae", description:"key", default_selector: "string", disable_int:true, value_string: "", help: {description: "Ключ сервиса решения капчи"} }) %>
<%= _.template($('#input_constructor').html())({id:"ngubkggl", description:"pixel_koef", default_selector: "int", disable_string:true, value_number: 0, min_number:-999999, max_number:999999, help: {description: "Иногда ползунок находится правее или левее пазла, введите єто расстояние в пикселях (При решении капчи бот всегда промахивается на одинаковое расстояние)"} }) %>
<%= _.template($('#input_constructor').html())({id:"skgdogyq", description:"reload_id", default_selector: "string", disable_int:true, value_string: " >CSS> .geetest_refresh_1", help: {description: "Идентификатор кнопки, которая обновляет картинку"} }) %>
</div>
<div class="tooltipinternal">
<div class="tr tooltip-paragraph-first-fold">Решает большенство каптч с пазлом</div>
</div>
<%= _.template($('#back').html())({action:"executeandadd", visible:true}) %>
