var hbsrswnj = GetInputConstructorValue("hbsrswnj", loader);
                 if(hbsrswnj["original"].length == 0)
                 {
                   Invalid("arrow_id" + " is empty");
                   return;
                 }
var rypdkhcy = GetInputConstructorValue("rypdkhcy", loader);
                 if(rypdkhcy["original"].length == 0)
                 {
                   Invalid("avtoupdate" + " is empty");
                   return;
                 }
var uquqsrfu = GetInputConstructorValue("uquqsrfu", loader);
                 if(uquqsrfu["original"].length == 0)
                 {
                   Invalid("button_id" + " is empty");
                   return;
                 }
var xkcldowz = GetInputConstructorValue("xkcldowz", loader);
                 if(xkcldowz["original"].length == 0)
                 {
                   Invalid("coef" + " is empty");
                   return;
                 }
var pnecoeif = GetInputConstructorValue("pnecoeif", loader);
                 if(pnecoeif["original"].length == 0)
                 {
                   Invalid("image id" + " is empty");
                   return;
                 }
var fwunnzae = GetInputConstructorValue("fwunnzae", loader);
                 if(fwunnzae["original"].length == 0)
                 {
                   Invalid("key" + " is empty");
                   return;
                 }
var ngubkggl = GetInputConstructorValue("ngubkggl", loader);
                 if(ngubkggl["original"].length == 0)
                 {
                   Invalid("pixel_koef" + " is empty");
                   return;
                 }
var skgdogyq = GetInputConstructorValue("skgdogyq", loader);
                 if(skgdogyq["original"].length == 0)
                 {
                   Invalid("reload_id" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#For_All_Puzzle_GeeTest_Solver_code").html())({"hbsrswnj": hbsrswnj["updated"],"rypdkhcy": rypdkhcy["updated"],"uquqsrfu": uquqsrfu["updated"],"xkcldowz": xkcldowz["updated"],"pnecoeif": pnecoeif["updated"],"fwunnzae": fwunnzae["updated"],"ngubkggl": ngubkggl["updated"],"skgdogyq": skgdogyq["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
