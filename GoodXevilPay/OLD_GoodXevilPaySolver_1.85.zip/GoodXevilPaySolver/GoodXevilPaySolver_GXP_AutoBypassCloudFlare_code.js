_call_function(GoodXevilPaySolver_GXP_AutoBypassCloudFlare,{ "custom_button": (<%= rufoqpss %>),"max_time": (<%= tcntwkmt %>),"whait_element": (<%= kkwgrlqd %>) })!
