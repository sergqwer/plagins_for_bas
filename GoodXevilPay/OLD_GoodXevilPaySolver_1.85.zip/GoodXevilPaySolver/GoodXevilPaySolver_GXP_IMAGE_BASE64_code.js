_call_function(GoodXevilPaySolver_GXP_IMAGE_BASE64,{ "APIKEY": (<%= zmvusasv %>),"IMAGE_BASE64": (<%= flutbnps %>) })!
<%= variable %> = _result_function()
