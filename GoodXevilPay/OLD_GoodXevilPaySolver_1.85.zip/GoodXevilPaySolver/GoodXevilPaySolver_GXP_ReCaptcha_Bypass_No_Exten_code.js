_call_function(GoodXevilPaySolver_GXP_ReCaptcha_Bypass_No_Exten,{ "apikey": (<%= ahahwpun %>),"enterprise": (<%= wxyndumc %>),"index": (<%= nrnesbzw %>),"invisible": (<%= kuaxryul %>),"recaptchaframe": (<%= prpavxef %>) })!
<%= variable %> = _result_function()
