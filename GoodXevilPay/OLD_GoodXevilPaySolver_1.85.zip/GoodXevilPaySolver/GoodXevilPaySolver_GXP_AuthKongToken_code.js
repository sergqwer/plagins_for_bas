_call_function(GoodXevilPaySolver_GXP_AuthKongToken,{ "APIKEY": (<%= mvjezlff %>),"site_url": (<%= afssnuso %>),"sitekey": (<%= xtonehfb %>) })!
<%= variable %> = _result_function()
