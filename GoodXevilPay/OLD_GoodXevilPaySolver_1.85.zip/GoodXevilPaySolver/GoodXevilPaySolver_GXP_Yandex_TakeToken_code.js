_call_function(GoodXevilPaySolver_GXP_Yandex_TakeToken,{ "apikey": (<%= rdydlpzk %>),"pageurl": (<%= jqrdrzqb %>),"sitekey": (<%= vgvrdpvx %>) })!
<%= variable %> = _result_function()
