var zbswlqgb = GetInputConstructorValue("zbswlqgb", loader);
                 if(zbswlqgb["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var luoetyww = GetInputConstructorValue("luoetyww", loader);
                 if(luoetyww["original"].length == 0)
                 {
                   Invalid("site_url" + " is empty");
                   return;
                 }
var robtagsi = GetInputConstructorValue("robtagsi", loader);
                 if(robtagsi["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_TurnstileToken_code").html())({"zbswlqgb": zbswlqgb["updated"],"luoetyww": luoetyww["updated"],"robtagsi": robtagsi["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
