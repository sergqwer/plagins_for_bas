var rufoqpss = GetInputConstructorValue("rufoqpss", loader);
                 if(rufoqpss["original"].length == 0)
                 {
                   Invalid("custom_button" + " is empty");
                   return;
                 }
var tcntwkmt = GetInputConstructorValue("tcntwkmt", loader);
                 if(tcntwkmt["original"].length == 0)
                 {
                   Invalid("max_time" + " is empty");
                   return;
                 }
var kkwgrlqd = GetInputConstructorValue("kkwgrlqd", loader);
                 if(kkwgrlqd["original"].length == 0)
                 {
                   Invalid("whait_element" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_AutoBypassCloudFlare_code").html())({"rufoqpss": rufoqpss["updated"],"tcntwkmt": tcntwkmt["updated"],"kkwgrlqd": kkwgrlqd["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
