_call_function(GoodXevilPaySolver_GXP_HcaptchaTakeToken,{ "APIKEY": (<%= iobwxpqr %>),"site_url": (<%= gdhmmfib %>),"sitekey": (<%= kfbulxvb %>) })!
<%= variable %> = _result_function()
