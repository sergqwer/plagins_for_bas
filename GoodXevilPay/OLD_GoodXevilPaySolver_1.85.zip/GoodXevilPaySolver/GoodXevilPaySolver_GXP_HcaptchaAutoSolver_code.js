_call_function(GoodXevilPaySolver_GXP_HcaptchaAutoSolver,{ "apikey": (<%= kxviydcs %>) })!
<%= variable %> = _result_function()
