var afzrhjnf = GetInputConstructorValue("afzrhjnf", loader);
                 if(afzrhjnf["original"].length == 0)
                 {
                   Invalid("arrow_id" + " is empty");
                   return;
                 }
var msmxbbil = GetInputConstructorValue("msmxbbil", loader);
                 if(msmxbbil["original"].length == 0)
                 {
                   Invalid("avtoupdate" + " is empty");
                   return;
                 }
var fcwtxflj = GetInputConstructorValue("fcwtxflj", loader);
                 if(fcwtxflj["original"].length == 0)
                 {
                   Invalid("button_id" + " is empty");
                   return;
                 }
var bbhpmtsz = GetInputConstructorValue("bbhpmtsz", loader);
                 if(bbhpmtsz["original"].length == 0)
                 {
                   Invalid("coef" + " is empty");
                   return;
                 }
var pqyrxgif = GetInputConstructorValue("pqyrxgif", loader);
                 if(pqyrxgif["original"].length == 0)
                 {
                   Invalid("image id" + " is empty");
                   return;
                 }
var uvymrcfw = GetInputConstructorValue("uvymrcfw", loader);
                 if(uvymrcfw["original"].length == 0)
                 {
                   Invalid("key" + " is empty");
                   return;
                 }
var tqpdunik = GetInputConstructorValue("tqpdunik", loader);
                 if(tqpdunik["original"].length == 0)
                 {
                   Invalid("pixel_koef" + " is empty");
                   return;
                 }
var yvoeobvo = GetInputConstructorValue("yvoeobvo", loader);
                 if(yvoeobvo["original"].length == 0)
                 {
                   Invalid("reload_id" + " is empty");
                   return;
                 }
var ofxvodpo = GetInputConstructorValue("ofxvodpo", loader);
                 if(ofxvodpo["original"].length == 0)
                 {
                   Invalid("speed" + " is empty");
                   return;
                 }
var wfmgayku = GetInputConstructorValue("wfmgayku", loader);
                 if(wfmgayku["original"].length == 0)
                 {
                   Invalid("type_slide" + " is empty");
                   return;
                 }
var jnehagcv = GetInputConstructorValue("jnehagcv", loader);
                 if(jnehagcv["original"].length == 0)
                 {
                   Invalid("type_swipe" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SliderSolver_code").html())({"afzrhjnf": afzrhjnf["updated"],"msmxbbil": msmxbbil["updated"],"fcwtxflj": fcwtxflj["updated"],"bbhpmtsz": bbhpmtsz["updated"],"pqyrxgif": pqyrxgif["updated"],"uvymrcfw": uvymrcfw["updated"],"tqpdunik": tqpdunik["updated"],"yvoeobvo": yvoeobvo["updated"],"ofxvodpo": ofxvodpo["updated"],"wfmgayku": wfmgayku["updated"],"jnehagcv": jnehagcv["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
