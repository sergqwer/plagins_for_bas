_call_function(GoodXevilPaySolver_GXP_Antibot,{ "apikey": (<%= liembyan %>),"mouse": (<%= zrainovh %>) })!
