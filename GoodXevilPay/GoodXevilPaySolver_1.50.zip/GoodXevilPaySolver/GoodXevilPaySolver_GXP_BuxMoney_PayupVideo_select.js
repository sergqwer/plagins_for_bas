var qdoitfzw = GetInputConstructorValue("qdoitfzw", loader);
                 if(qdoitfzw["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var cijkpstr = GetInputConstructorValue("cijkpstr", loader);
                 if(cijkpstr["original"].length == 0)
                 {
                   Invalid("timer" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_BuxMoney_PayupVideo_code").html())({"qdoitfzw": qdoitfzw["updated"],"cijkpstr": cijkpstr["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
