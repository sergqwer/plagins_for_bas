var vjblwfmb = GetInputConstructorValue("vjblwfmb", loader);
                 if(vjblwfmb["original"].length == 0)
                 {
                   Invalid("custom_button" + " is empty");
                   return;
                 }
var yarpmvro = GetInputConstructorValue("yarpmvro", loader);
                 if(yarpmvro["original"].length == 0)
                 {
                   Invalid("max_time" + " is empty");
                   return;
                 }
var etvbzdok = GetInputConstructorValue("etvbzdok", loader);
                 if(etvbzdok["original"].length == 0)
                 {
                   Invalid("whait_element" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_AutoBypassCloudFlare_code").html())({"vjblwfmb": vjblwfmb["updated"],"yarpmvro": yarpmvro["updated"],"etvbzdok": etvbzdok["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
