_call_function(GoodXevilPaySolver_GXP_ReCaptchav2TakeToken,{ "APIKEY": (<%= aohdhybq %>),"site_url": (<%= ytsdecmy %>),"sitekey": (<%= twcyyjsn %>) })!
<%= variable %> = _result_function()
