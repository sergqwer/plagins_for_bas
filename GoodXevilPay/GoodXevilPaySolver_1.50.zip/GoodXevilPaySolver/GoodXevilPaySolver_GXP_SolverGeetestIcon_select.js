var lobodcge = GetInputConstructorValue("lobodcge", loader);
                 if(lobodcge["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var saawbiir = GetInputConstructorValue("saawbiir", loader);
                 if(saawbiir["original"].length == 0)
                 {
                   Invalid("button_capthca" + " is empty");
                   return;
                 }
var uysqhhcs = GetInputConstructorValue("uysqhhcs", loader);
                 if(uysqhhcs["original"].length == 0)
                 {
                   Invalid("captcha_submit" + " is empty");
                   return;
                 }
var wppyfhhf = GetInputConstructorValue("wppyfhhf", loader);
                 if(wppyfhhf["original"].length == 0)
                 {
                   Invalid("foto_captcha" + " is empty");
                   return;
                 }
var anugtavx = GetInputConstructorValue("anugtavx", loader);
                 if(anugtavx["original"].length == 0)
                 {
                   Invalid("pixel_coef" + " is empty");
                   return;
                 }
var jitrpwdx = GetInputConstructorValue("jitrpwdx", loader);
                 if(jitrpwdx["original"].length == 0)
                 {
                   Invalid("reload_captcha" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SolverGeetestIcon_code").html())({"lobodcge": lobodcge["updated"],"saawbiir": saawbiir["updated"],"uysqhhcs": uysqhhcs["updated"],"wppyfhhf": wppyfhhf["updated"],"anugtavx": anugtavx["updated"],"jitrpwdx": jitrpwdx["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
