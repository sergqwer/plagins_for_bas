var aohdhybq = GetInputConstructorValue("aohdhybq", loader);
                 if(aohdhybq["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var ytsdecmy = GetInputConstructorValue("ytsdecmy", loader);
                 if(ytsdecmy["original"].length == 0)
                 {
                   Invalid("site_url" + " is empty");
                   return;
                 }
var twcyyjsn = GetInputConstructorValue("twcyyjsn", loader);
                 if(twcyyjsn["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_ReCaptchav2TakeToken_code").html())({"aohdhybq": aohdhybq["updated"],"ytsdecmy": ytsdecmy["updated"],"twcyyjsn": twcyyjsn["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
