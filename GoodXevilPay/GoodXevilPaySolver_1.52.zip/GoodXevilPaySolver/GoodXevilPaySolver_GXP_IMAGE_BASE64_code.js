_call_function(GoodXevilPaySolver_GXP_IMAGE_BASE64,{ "APIKEY": (<%= ldoryiyh %>),"IMAGE_BASE64": (<%= fqnpbpix %>) })!
<%= variable %> = _result_function()
