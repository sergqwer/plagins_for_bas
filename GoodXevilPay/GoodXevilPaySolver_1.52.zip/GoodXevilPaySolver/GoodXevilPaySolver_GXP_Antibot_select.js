var ozhofqwk = GetInputConstructorValue("ozhofqwk", loader);
                 if(ozhofqwk["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var fdlydcgb = GetInputConstructorValue("fdlydcgb", loader);
                 if(fdlydcgb["original"].length == 0)
                 {
                   Invalid("mouse" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_Antibot_code").html())({"ozhofqwk": ozhofqwk["updated"],"fdlydcgb": fdlydcgb["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
