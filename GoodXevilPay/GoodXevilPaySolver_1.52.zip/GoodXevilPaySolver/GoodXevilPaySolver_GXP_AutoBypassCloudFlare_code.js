_call_function(GoodXevilPaySolver_GXP_AutoBypassCloudFlare,{ "custom_button": (<%= yksoljbs %>),"max_time": (<%= qvlutrsb %>),"whait_element": (<%= hatxupws %>) })!
