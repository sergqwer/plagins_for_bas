_call_function(GoodXevilPaySolver_GXP_HcaptchaTakeToken,{ "APIKEY": (<%= jihsshoo %>),"site_url": (<%= mkpuqzew %>),"sitekey": (<%= vqplivfw %>) })!
<%= variable %> = _result_function()
