_call_function(GoodXevilPaySolver_GXP_ReCaptchav2TakeToken,{ "APIKEY": (<%= mxclgybk %>),"site_url": (<%= glsejteo %>),"sitekey": (<%= xrrvcrua %>) })!
<%= variable %> = _result_function()
