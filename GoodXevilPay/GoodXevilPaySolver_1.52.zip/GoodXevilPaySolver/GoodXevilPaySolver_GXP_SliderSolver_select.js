var okqfxwxo = GetInputConstructorValue("okqfxwxo", loader);
                 if(okqfxwxo["original"].length == 0)
                 {
                   Invalid("arrow_id" + " is empty");
                   return;
                 }
var updsgiiz = GetInputConstructorValue("updsgiiz", loader);
                 if(updsgiiz["original"].length == 0)
                 {
                   Invalid("avtoupdate" + " is empty");
                   return;
                 }
var wbcnkugm = GetInputConstructorValue("wbcnkugm", loader);
                 if(wbcnkugm["original"].length == 0)
                 {
                   Invalid("button_id" + " is empty");
                   return;
                 }
var fueupsck = GetInputConstructorValue("fueupsck", loader);
                 if(fueupsck["original"].length == 0)
                 {
                   Invalid("coef" + " is empty");
                   return;
                 }
var hlimmagm = GetInputConstructorValue("hlimmagm", loader);
                 if(hlimmagm["original"].length == 0)
                 {
                   Invalid("image id" + " is empty");
                   return;
                 }
var elqhffmv = GetInputConstructorValue("elqhffmv", loader);
                 if(elqhffmv["original"].length == 0)
                 {
                   Invalid("key" + " is empty");
                   return;
                 }
var svvodnzb = GetInputConstructorValue("svvodnzb", loader);
                 if(svvodnzb["original"].length == 0)
                 {
                   Invalid("pixel_koef" + " is empty");
                   return;
                 }
var ugnoybab = GetInputConstructorValue("ugnoybab", loader);
                 if(ugnoybab["original"].length == 0)
                 {
                   Invalid("reload_id" + " is empty");
                   return;
                 }
var pdrxyeej = GetInputConstructorValue("pdrxyeej", loader);
                 if(pdrxyeej["original"].length == 0)
                 {
                   Invalid("speed" + " is empty");
                   return;
                 }
var thiecfuh = GetInputConstructorValue("thiecfuh", loader);
                 if(thiecfuh["original"].length == 0)
                 {
                   Invalid("type_slide" + " is empty");
                   return;
                 }
var aozizkye = GetInputConstructorValue("aozizkye", loader);
                 if(aozizkye["original"].length == 0)
                 {
                   Invalid("type_swipe" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SliderSolver_code").html())({"okqfxwxo": okqfxwxo["updated"],"updsgiiz": updsgiiz["updated"],"wbcnkugm": wbcnkugm["updated"],"fueupsck": fueupsck["updated"],"hlimmagm": hlimmagm["updated"],"elqhffmv": elqhffmv["updated"],"svvodnzb": svvodnzb["updated"],"ugnoybab": ugnoybab["updated"],"pdrxyeej": pdrxyeej["updated"],"thiecfuh": thiecfuh["updated"],"aozizkye": aozizkye["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
