var yksoljbs = GetInputConstructorValue("yksoljbs", loader);
                 if(yksoljbs["original"].length == 0)
                 {
                   Invalid("custom_button" + " is empty");
                   return;
                 }
var qvlutrsb = GetInputConstructorValue("qvlutrsb", loader);
                 if(qvlutrsb["original"].length == 0)
                 {
                   Invalid("max_time" + " is empty");
                   return;
                 }
var hatxupws = GetInputConstructorValue("hatxupws", loader);
                 if(hatxupws["original"].length == 0)
                 {
                   Invalid("whait_element" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_AutoBypassCloudFlare_code").html())({"yksoljbs": yksoljbs["updated"],"qvlutrsb": qvlutrsb["updated"],"hatxupws": hatxupws["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
