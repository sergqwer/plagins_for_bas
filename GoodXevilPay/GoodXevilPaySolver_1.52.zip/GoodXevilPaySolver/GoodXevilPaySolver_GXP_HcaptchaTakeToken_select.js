var jihsshoo = GetInputConstructorValue("jihsshoo", loader);
                 if(jihsshoo["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var mkpuqzew = GetInputConstructorValue("mkpuqzew", loader);
                 if(mkpuqzew["original"].length == 0)
                 {
                   Invalid("site_url" + " is empty");
                   return;
                 }
var vqplivfw = GetInputConstructorValue("vqplivfw", loader);
                 if(vqplivfw["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_HcaptchaTakeToken_code").html())({"jihsshoo": jihsshoo["updated"],"mkpuqzew": mkpuqzew["updated"],"vqplivfw": vqplivfw["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
