var rrrnwuxl = GetInputConstructorValue("rrrnwuxl", loader);
                 if(rrrnwuxl["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var aedfeyqs = GetInputConstructorValue("aedfeyqs", loader);
                 if(aedfeyqs["original"].length == 0)
                 {
                   Invalid("timer" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_BuxMoney_PayupVideo_code").html())({"rrrnwuxl": rrrnwuxl["updated"],"aedfeyqs": aedfeyqs["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
