_call_function(GoodXevilPaySolver_ReCaptchav2TakeToken,{ "APIKEY": (<%= iwkkznnv %>),"site_url": (<%= vgsnkznv %>),"sitekey": (<%= pxpjvgjg %>) })!
<%= variable %> = _result_function()
