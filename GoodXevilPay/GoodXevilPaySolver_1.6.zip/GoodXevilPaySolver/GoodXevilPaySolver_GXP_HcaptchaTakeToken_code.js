_call_function(GoodXevilPaySolver_GXP_HcaptchaTakeToken,{ "APIKEY": (<%= ntaneyfe %>),"site_url": (<%= lkslvfxu %>),"sitekey": (<%= sprubvmi %>) })!
<%= variable %> = _result_function()
