var wehxvfpx = GetInputConstructorValue("wehxvfpx", loader);
                 if(wehxvfpx["original"].length == 0)
                 {
                   Invalid("arrow_id" + " is empty");
                   return;
                 }
var jnwwruat = GetInputConstructorValue("jnwwruat", loader);
                 if(jnwwruat["original"].length == 0)
                 {
                   Invalid("avtoupdate" + " is empty");
                   return;
                 }
var lcipcuim = GetInputConstructorValue("lcipcuim", loader);
                 if(lcipcuim["original"].length == 0)
                 {
                   Invalid("button_id" + " is empty");
                   return;
                 }
var luyphaew = GetInputConstructorValue("luyphaew", loader);
                 if(luyphaew["original"].length == 0)
                 {
                   Invalid("coef" + " is empty");
                   return;
                 }
var ugiqbref = GetInputConstructorValue("ugiqbref", loader);
                 if(ugiqbref["original"].length == 0)
                 {
                   Invalid("image id" + " is empty");
                   return;
                 }
var htcxpbrs = GetInputConstructorValue("htcxpbrs", loader);
                 if(htcxpbrs["original"].length == 0)
                 {
                   Invalid("key" + " is empty");
                   return;
                 }
var gnvnkqqk = GetInputConstructorValue("gnvnkqqk", loader);
                 if(gnvnkqqk["original"].length == 0)
                 {
                   Invalid("pixel_koef" + " is empty");
                   return;
                 }
var caqicckx = GetInputConstructorValue("caqicckx", loader);
                 if(caqicckx["original"].length == 0)
                 {
                   Invalid("reload_id" + " is empty");
                   return;
                 }
var yrdyfhij = GetInputConstructorValue("yrdyfhij", loader);
                 if(yrdyfhij["original"].length == 0)
                 {
                   Invalid("speed" + " is empty");
                   return;
                 }
var muzntcpv = GetInputConstructorValue("muzntcpv", loader);
                 if(muzntcpv["original"].length == 0)
                 {
                   Invalid("type_slide" + " is empty");
                   return;
                 }
var gzbiuuya = GetInputConstructorValue("gzbiuuya", loader);
                 if(gzbiuuya["original"].length == 0)
                 {
                   Invalid("type_swipe" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SliderSolver_code").html())({"wehxvfpx": wehxvfpx["updated"],"jnwwruat": jnwwruat["updated"],"lcipcuim": lcipcuim["updated"],"luyphaew": luyphaew["updated"],"ugiqbref": ugiqbref["updated"],"htcxpbrs": htcxpbrs["updated"],"gnvnkqqk": gnvnkqqk["updated"],"caqicckx": caqicckx["updated"],"yrdyfhij": yrdyfhij["updated"],"muzntcpv": muzntcpv["updated"],"gzbiuuya": gzbiuuya["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
