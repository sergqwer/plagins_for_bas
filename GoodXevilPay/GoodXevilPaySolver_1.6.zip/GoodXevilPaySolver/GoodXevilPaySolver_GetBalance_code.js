_call_function(GoodXevilPaySolver_GetBalance,{ "APIKEY": (<%= regmxvrn %>) })!
<%= variable %> = _result_function()
