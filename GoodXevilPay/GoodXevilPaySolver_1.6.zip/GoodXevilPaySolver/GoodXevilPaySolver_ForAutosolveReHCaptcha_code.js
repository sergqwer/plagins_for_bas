_call_function(GoodXevilPaySolver_ForAutosolveReHCaptcha,{ "AutoSettings": (<%= oovsqadg %>) })!
