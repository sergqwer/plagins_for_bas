var zfnkifxf = GetInputConstructorValue("zfnkifxf", loader);
                 if(zfnkifxf["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var bzbrniwa = GetInputConstructorValue("bzbrniwa", loader);
                 if(bzbrniwa["original"].length == 0)
                 {
                   Invalid("timer" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_BuxMoney_PayupVideo_code").html())({"zfnkifxf": zfnkifxf["updated"],"bzbrniwa": bzbrniwa["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
