var qudeasej = GetInputConstructorValue("qudeasej", loader);
                 if(qudeasej["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var jrasmwxd = GetInputConstructorValue("jrasmwxd", loader);
                 if(jrasmwxd["original"].length == 0)
                 {
                   Invalid("site_url" + " is empty");
                   return;
                 }
var wmwvgdjx = GetInputConstructorValue("wmwvgdjx", loader);
                 if(wmwvgdjx["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_HcaptchaTakeToken_code").html())({"qudeasej": qudeasej["updated"],"jrasmwxd": jrasmwxd["updated"],"wmwvgdjx": wmwvgdjx["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
