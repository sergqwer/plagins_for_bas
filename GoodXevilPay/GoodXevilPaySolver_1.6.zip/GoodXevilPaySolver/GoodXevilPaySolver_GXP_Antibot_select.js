var fcnyahhk = GetInputConstructorValue("fcnyahhk", loader);
                 if(fcnyahhk["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var ttohhpyx = GetInputConstructorValue("ttohhpyx", loader);
                 if(ttohhpyx["original"].length == 0)
                 {
                   Invalid("mouse" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_Antibot_code").html())({"fcnyahhk": fcnyahhk["updated"],"ttohhpyx": ttohhpyx["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
