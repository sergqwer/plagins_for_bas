_call_function(GoodXevilPaySolver_GXP_ReCaptchav2TakeToken,{ "APIKEY": (<%= npnqglhq %>),"site_url": (<%= eozyjjxc %>),"sitekey": (<%= zmkmtprv %>) })!
<%= variable %> = _result_function()
