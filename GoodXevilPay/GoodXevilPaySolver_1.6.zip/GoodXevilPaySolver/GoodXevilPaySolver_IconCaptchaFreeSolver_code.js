_call_function(GoodXevilPaySolver_IconCaptchaFreeSolver,{  })!
