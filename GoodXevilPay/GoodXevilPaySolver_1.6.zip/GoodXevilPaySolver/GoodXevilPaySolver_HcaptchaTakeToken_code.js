_call_function(GoodXevilPaySolver_HcaptchaTakeToken,{ "APIKEY": (<%= qudeasej %>),"site_url": (<%= jrasmwxd %>),"sitekey": (<%= wmwvgdjx %>) })!
<%= variable %> = _result_function()
