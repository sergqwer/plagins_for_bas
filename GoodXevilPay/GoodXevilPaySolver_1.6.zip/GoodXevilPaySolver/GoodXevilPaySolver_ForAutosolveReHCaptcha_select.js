var oovsqadg = GetInputConstructorValue("oovsqadg", loader);
                 if(oovsqadg["original"].length == 0)
                 {
                   Invalid("AutoSettings" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_ForAutosolveReHCaptcha_code").html())({"oovsqadg": oovsqadg["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
