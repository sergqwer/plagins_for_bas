_call_function(OLD_GoodXevilPaySolver_GXP_IMAGE_BASE64,{ "APIKEY": (<%= ziskehte %>),"IMAGE_BASE64": (<%= gabbozqu %>) })!
<%= variable %> = _result_function()
