var kaenrrpg = GetInputConstructorValue("kaenrrpg", loader);
                 if(kaenrrpg["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var dsxaunox = GetInputConstructorValue("dsxaunox", loader);
                 if(dsxaunox["original"].length == 0)
                 {
                   Invalid("captcha_submit" + " is empty");
                   return;
                 }
var zoljycjx = GetInputConstructorValue("zoljycjx", loader);
                 if(zoljycjx["original"].length == 0)
                 {
                   Invalid("foto_captcha" + " is empty");
                   return;
                 }
var sucbsyor = GetInputConstructorValue("sucbsyor", loader);
                 if(sucbsyor["original"].length == 0)
                 {
                   Invalid("pixel_coef" + " is empty");
                   return;
                 }
var uunkflxh = GetInputConstructorValue("uunkflxh", loader);
                 if(uunkflxh["original"].length == 0)
                 {
                   Invalid("reload_captcha" + " is empty");
                   return;
                 }
var dxlfkxba = GetInputConstructorValue("dxlfkxba", loader);
                 if(dxlfkxba["original"].length == 0)
                 {
                   Invalid("type_data" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#OLD_GoodXevilPaySolver_GXP_SolverGeetestIcon_code").html())({"kaenrrpg": kaenrrpg["updated"],"dsxaunox": dsxaunox["updated"],"zoljycjx": zoljycjx["updated"],"sucbsyor": sucbsyor["updated"],"uunkflxh": uunkflxh["updated"],"dxlfkxba": dxlfkxba["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
