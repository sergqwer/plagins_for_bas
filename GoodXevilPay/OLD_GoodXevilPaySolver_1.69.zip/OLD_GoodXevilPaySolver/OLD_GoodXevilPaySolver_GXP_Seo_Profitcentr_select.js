var pbkfgacq = GetInputConstructorValue("pbkfgacq", loader);
                 if(pbkfgacq["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#OLD_GoodXevilPaySolver_GXP_Seo_Profitcentr_code").html())({"pbkfgacq": pbkfgacq["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
