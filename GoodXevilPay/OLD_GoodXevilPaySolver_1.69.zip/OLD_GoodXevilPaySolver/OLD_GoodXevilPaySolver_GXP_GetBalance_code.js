_call_function(OLD_GoodXevilPaySolver_GXP_GetBalance,{ "APIKEY": (<%= gjdbdncr %>) })!
<%= variable %> = _result_function()
