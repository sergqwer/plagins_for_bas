var mpqersap = GetInputConstructorValue("mpqersap", loader);
                 if(mpqersap["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var okjctaeo = GetInputConstructorValue("okjctaeo", loader);
                 if(okjctaeo["original"].length == 0)
                 {
                   Invalid("cut_url" + " is empty");
                   return;
                 }
var zyfcdbun = GetInputConstructorValue("zyfcdbun", loader);
                 if(zyfcdbun["original"].length == 0)
                 {
                   Invalid("enterprise" + " is empty");
                   return;
                 }
var snehpltt = GetInputConstructorValue("snehpltt", loader);
                 if(snehpltt["original"].length == 0)
                 {
                   Invalid("index" + " is empty");
                   return;
                 }
var hjjghzfh = GetInputConstructorValue("hjjghzfh", loader);
                 if(hjjghzfh["original"].length == 0)
                 {
                   Invalid("invisible" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#OLD_GoodXevilPaySolver_GXP_ReCaptcha_Bypass_No_Exten_code").html())({"mpqersap": mpqersap["updated"],"okjctaeo": okjctaeo["updated"],"zyfcdbun": zyfcdbun["updated"],"snehpltt": snehpltt["updated"],"hjjghzfh": hjjghzfh["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
