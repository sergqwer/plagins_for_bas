<div class="container-fluid">
<%= _.template($('#input_constructor').html())({id:"qilticqy", description:"apikey", default_selector: "string", disable_int:true, value_string: "", help: {description: "apikey с сервиса https://t.me/Xevil_check_bot\n\napikey from https://t.me/Xevil_check_bot"} }) %>
</div>
<div class="tooltipinternal">
<div class="tr tooltip-paragraph-first-fold">Автоматически решает Recaptcha на странице, для работы требуется функция For Autosolve ReHCaptcha</div>
<div class="tr tooltip-paragraph-last-fold">Automatically solves Recaptcha on the page, For Autosolve ReHCaptcha is required to work</div>
</div>
<%= _.template($('#back').html())({action:"executeandadd", visible:true}) %>
