var owtgpetf = GetInputConstructorValue("owtgpetf", loader);
                 if(owtgpetf["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var yswlhwft = GetInputConstructorValue("yswlhwft", loader);
                 if(yswlhwft["original"].length == 0)
                 {
                   Invalid("site_url" + " is empty");
                   return;
                 }
var pqdsdyms = GetInputConstructorValue("pqdsdyms", loader);
                 if(pqdsdyms["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#OLD_GoodXevilPaySolver_GXP_HcaptchaTakeToken_code").html())({"owtgpetf": owtgpetf["updated"],"yswlhwft": yswlhwft["updated"],"pqdsdyms": pqdsdyms["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
