_call_function(OLD_GoodXevilPaySolver_GXP_AutoBypassCloudFlare,{ "custom_button": (<%= vbujytkw %>),"max_time": (<%= hyhainty %>),"whait_element": (<%= qgpmjiyh %>) })!
