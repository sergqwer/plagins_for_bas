var wcbskyfr = GetInputConstructorValue("wcbskyfr", loader);
                 if(wcbskyfr["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var veijtznq = GetInputConstructorValue("veijtznq", loader);
                 if(veijtznq["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var pblynlwh = GetInputConstructorValue("pblynlwh", loader);
                 if(pblynlwh["original"].length == 0)
                 {
                   Invalid("siteurl" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#OLD_GoodXevilPaySolver_GXP_BasiliskCaptcha_code").html())({"wcbskyfr": wcbskyfr["updated"],"veijtznq": veijtznq["updated"],"pblynlwh": pblynlwh["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
