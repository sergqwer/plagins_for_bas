_call_function(OLD_GoodXevilPaySolver_GXP_HcaptchaTakeToken,{ "APIKEY": (<%= owtgpetf %>),"site_url": (<%= yswlhwft %>),"sitekey": (<%= pqdsdyms %>) })!
<%= variable %> = _result_function()
