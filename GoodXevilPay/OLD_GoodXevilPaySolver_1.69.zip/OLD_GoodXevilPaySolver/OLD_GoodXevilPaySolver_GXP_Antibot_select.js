var uyosxyyr = GetInputConstructorValue("uyosxyyr", loader);
                 if(uyosxyyr["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var gpfwrgbd = GetInputConstructorValue("gpfwrgbd", loader);
                 if(gpfwrgbd["original"].length == 0)
                 {
                   Invalid("mouse" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#OLD_GoodXevilPaySolver_GXP_Antibot_code").html())({"uyosxyyr": uyosxyyr["updated"],"gpfwrgbd": gpfwrgbd["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
