var wszqqaka = GetInputConstructorValue("wszqqaka", loader);
                 if(wszqqaka["original"].length == 0)
                 {
                   Invalid("hCaptcha_USE" + " is empty");
                   return;
                 }
var cgkhdnjo = GetInputConstructorValue("cgkhdnjo", loader);
                 if(cgkhdnjo["original"].length == 0)
                 {
                   Invalid("ReCaptcha_USE" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#OLD_GoodXevilPaySolver_GXP_ForAutosolveReHCaptcha_code").html())({"wszqqaka": wszqqaka["updated"],"cgkhdnjo": cgkhdnjo["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
