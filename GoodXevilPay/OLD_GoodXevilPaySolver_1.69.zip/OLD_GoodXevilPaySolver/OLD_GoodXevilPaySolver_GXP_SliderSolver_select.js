var rltpgcir = GetInputConstructorValue("rltpgcir", loader);
                 if(rltpgcir["original"].length == 0)
                 {
                   Invalid("arrow_id" + " is empty");
                   return;
                 }
var efgfqlil = GetInputConstructorValue("efgfqlil", loader);
                 if(efgfqlil["original"].length == 0)
                 {
                   Invalid("Attempts" + " is empty");
                   return;
                 }
var favtnkgk = GetInputConstructorValue("favtnkgk", loader);
                 if(favtnkgk["original"].length == 0)
                 {
                   Invalid("avtoupdate" + " is empty");
                   return;
                 }
var ftuagicm = GetInputConstructorValue("ftuagicm", loader);
                 if(ftuagicm["original"].length == 0)
                 {
                   Invalid("button_id" + " is empty");
                   return;
                 }
var ssdbvdio = GetInputConstructorValue("ssdbvdio", loader);
                 if(ssdbvdio["original"].length == 0)
                 {
                   Invalid("coef" + " is empty");
                   return;
                 }
var mlkeocta = GetInputConstructorValue("mlkeocta", loader);
                 if(mlkeocta["original"].length == 0)
                 {
                   Invalid("image id" + " is empty");
                   return;
                 }
var aqqlaktw = GetInputConstructorValue("aqqlaktw", loader);
                 if(aqqlaktw["original"].length == 0)
                 {
                   Invalid("key" + " is empty");
                   return;
                 }
var hezzrhvg = GetInputConstructorValue("hezzrhvg", loader);
                 if(hezzrhvg["original"].length == 0)
                 {
                   Invalid("pixel_koef" + " is empty");
                   return;
                 }
var dfuzoxtq = GetInputConstructorValue("dfuzoxtq", loader);
                 if(dfuzoxtq["original"].length == 0)
                 {
                   Invalid("reload_id" + " is empty");
                   return;
                 }
var hjikzals = GetInputConstructorValue("hjikzals", loader);
                 if(hjikzals["original"].length == 0)
                 {
                   Invalid("slider_type" + " is empty");
                   return;
                 }
var yimllhtw = GetInputConstructorValue("yimllhtw", loader);
                 if(yimllhtw["original"].length == 0)
                 {
                   Invalid("speed" + " is empty");
                   return;
                 }
var jkufwzyn = GetInputConstructorValue("jkufwzyn", loader);
                 if(jkufwzyn["original"].length == 0)
                 {
                   Invalid("type_slide" + " is empty");
                   return;
                 }
var arhiiezo = GetInputConstructorValue("arhiiezo", loader);
                 if(arhiiezo["original"].length == 0)
                 {
                   Invalid("type_swipe" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#OLD_GoodXevilPaySolver_GXP_SliderSolver_code").html())({"rltpgcir": rltpgcir["updated"],"efgfqlil": efgfqlil["updated"],"favtnkgk": favtnkgk["updated"],"ftuagicm": ftuagicm["updated"],"ssdbvdio": ssdbvdio["updated"],"mlkeocta": mlkeocta["updated"],"aqqlaktw": aqqlaktw["updated"],"hezzrhvg": hezzrhvg["updated"],"dfuzoxtq": dfuzoxtq["updated"],"hjikzals": hjikzals["updated"],"yimllhtw": yimllhtw["updated"],"jkufwzyn": jkufwzyn["updated"],"arhiiezo": arhiiezo["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
