_call_function(OLD_GoodXevilPaySolver_GXP_BasiliskCaptcha,{ "apikey": (<%= wcbskyfr %>),"sitekey": (<%= veijtznq %>),"siteurl": (<%= pblynlwh %>) })!
