_call_function(OLD_GoodXevilPaySolver_GXP_ReCaptchav2TakeToken,{ "APIKEY": (<%= uusfmbdj %>),"site_url": (<%= hdoknmwu %>),"sitekey": (<%= kvvuyozd %>) })!
<%= variable %> = _result_function()
