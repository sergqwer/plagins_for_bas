_call_function(GoodXevilPaySolver_GXP_IMAGE_BASE64,{ "APIKEY": (<%= wgzxdwzo %>),"IMAGE_BASE64": (<%= hjeuwpfe %>) })!
<%= variable %> = _result_function()
