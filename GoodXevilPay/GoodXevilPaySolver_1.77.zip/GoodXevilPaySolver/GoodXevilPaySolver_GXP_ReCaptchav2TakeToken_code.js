_call_function(GoodXevilPaySolver_GXP_ReCaptchav2TakeToken,{ "APIKEY": (<%= ldzgrlte %>),"site_url": (<%= coxermsu %>),"sitekey": (<%= zquoeplh %>) })!
<%= variable %> = _result_function()
