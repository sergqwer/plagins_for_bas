var wlyrjklk = GetInputConstructorValue("wlyrjklk", loader);
                 if(wlyrjklk["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var ovbfrrvn = GetInputConstructorValue("ovbfrrvn", loader);
                 if(ovbfrrvn["original"].length == 0)
                 {
                   Invalid("site_url" + " is empty");
                   return;
                 }
var bqsjkohr = GetInputConstructorValue("bqsjkohr", loader);
                 if(bqsjkohr["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_AuthKongToken_code").html())({"wlyrjklk": wlyrjklk["updated"],"ovbfrrvn": ovbfrrvn["updated"],"bqsjkohr": bqsjkohr["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
