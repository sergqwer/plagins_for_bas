<div class="container-fluid">
<%= _.template($('#input_constructor').html())({id:"vooffxta", description:"apikey", default_selector: "string", disable_int:true, value_string: "", help: {description: "apikey с сервиса https://t.me/Xevil_check_bot\n\napikey from https://t.me/Xevil_check_bot"} }) %>
<%= _.template($('#variable_constructor').html())({id:"Save", description:"Result", default_variable: "RESULT", help: {description: "Ответ от сервиса решения капчи\n\nResponse from the captcha solution service"}}) %>
</div>
<div class="tooltipinternal">
<div class="tr tooltip-paragraph-first-fold">Решает капчу с сайта https://namars.com, для решения обязательно надо вызвать функцию Namars CacheAllow</div>
<div class="tr tooltip-paragraph-last-fold">Solves captcha from https://namars.com, to solve it you must call Namars CacheAllow function.</div>
</div>
<%= _.template($('#back').html())({action:"executeandadd", visible:true}) %>
