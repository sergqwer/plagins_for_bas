_call_function(GoodXevilPaySolver_GXP_Solve_Funcaptcha,{ "APIKey": (<%= nyhvhglm %>),"CaptchaNumber": (<%= ajdpowme %>),"CaptchaSelector": (<%= fqlzflht %>),"MaxLimitTask": (<%= ntkmbvuy %>) })!
