var uwwnzhdn = GetInputConstructorValue("uwwnzhdn", loader);
                 if(uwwnzhdn["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var fqnmigcl = GetInputConstructorValue("fqnmigcl", loader);
                 if(fqnmigcl["original"].length == 0)
                 {
                   Invalid("CaptchaSelector" + " is empty");
                   return;
                 }
var zitsqlgd = GetInputConstructorValue("zitsqlgd", loader);
                 if(zitsqlgd["original"].length == 0)
                 {
                   Invalid("InvisibleCaptcha" + " is empty");
                   return;
                 }
var qkfdhtii = GetInputConstructorValue("qkfdhtii", loader);
                 if(qkfdhtii["original"].length == 0)
                 {
                   Invalid("TrySolve" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_hCaptcha_Click_code").html())({"uwwnzhdn": uwwnzhdn["updated"],"fqnmigcl": fqnmigcl["updated"],"zitsqlgd": zitsqlgd["updated"],"qkfdhtii": qkfdhtii["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
