var nyhvhglm = GetInputConstructorValue("nyhvhglm", loader);
                 if(nyhvhglm["original"].length == 0)
                 {
                   Invalid("APIKey" + " is empty");
                   return;
                 }
var ajdpowme = GetInputConstructorValue("ajdpowme", loader);
                 if(ajdpowme["original"].length == 0)
                 {
                   Invalid("CaptchaNumber" + " is empty");
                   return;
                 }
var fqlzflht = GetInputConstructorValue("fqlzflht", loader);
                 if(fqlzflht["original"].length == 0)
                 {
                   Invalid("CaptchaSelector" + " is empty");
                   return;
                 }
var ntkmbvuy = GetInputConstructorValue("ntkmbvuy", loader);
                 if(ntkmbvuy["original"].length == 0)
                 {
                   Invalid("MaxLimitTask" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_Solve_Funcaptcha_code").html())({"nyhvhglm": nyhvhglm["updated"],"ajdpowme": ajdpowme["updated"],"fqlzflht": fqlzflht["updated"],"ntkmbvuy": ntkmbvuy["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
