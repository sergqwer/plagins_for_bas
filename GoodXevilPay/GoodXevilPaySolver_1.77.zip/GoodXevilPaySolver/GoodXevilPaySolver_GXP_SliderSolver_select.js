var hntopbjo = GetInputConstructorValue("hntopbjo", loader);
                 if(hntopbjo["original"].length == 0)
                 {
                   Invalid("arrow_id" + " is empty");
                   return;
                 }
var vzdntdxz = GetInputConstructorValue("vzdntdxz", loader);
                 if(vzdntdxz["original"].length == 0)
                 {
                   Invalid("Attempts" + " is empty");
                   return;
                 }
var ujmnxamh = GetInputConstructorValue("ujmnxamh", loader);
                 if(ujmnxamh["original"].length == 0)
                 {
                   Invalid("avtoupdate" + " is empty");
                   return;
                 }
var pttpeuux = GetInputConstructorValue("pttpeuux", loader);
                 if(pttpeuux["original"].length == 0)
                 {
                   Invalid("button_id" + " is empty");
                   return;
                 }
var friydhhj = GetInputConstructorValue("friydhhj", loader);
                 if(friydhhj["original"].length == 0)
                 {
                   Invalid("coef" + " is empty");
                   return;
                 }
var lqqjqtui = GetInputConstructorValue("lqqjqtui", loader);
                 if(lqqjqtui["original"].length == 0)
                 {
                   Invalid("image id" + " is empty");
                   return;
                 }
var dzhyfkci = GetInputConstructorValue("dzhyfkci", loader);
                 if(dzhyfkci["original"].length == 0)
                 {
                   Invalid("key" + " is empty");
                   return;
                 }
var vgzxrjtl = GetInputConstructorValue("vgzxrjtl", loader);
                 if(vgzxrjtl["original"].length == 0)
                 {
                   Invalid("pixel_koef" + " is empty");
                   return;
                 }
var ncefzrot = GetInputConstructorValue("ncefzrot", loader);
                 if(ncefzrot["original"].length == 0)
                 {
                   Invalid("reload_id" + " is empty");
                   return;
                 }
var amkasjxh = GetInputConstructorValue("amkasjxh", loader);
                 if(amkasjxh["original"].length == 0)
                 {
                   Invalid("slider_type" + " is empty");
                   return;
                 }
var swtentsc = GetInputConstructorValue("swtentsc", loader);
                 if(swtentsc["original"].length == 0)
                 {
                   Invalid("speed" + " is empty");
                   return;
                 }
var uxcvhppf = GetInputConstructorValue("uxcvhppf", loader);
                 if(uxcvhppf["original"].length == 0)
                 {
                   Invalid("type_slide" + " is empty");
                   return;
                 }
var qtxsldym = GetInputConstructorValue("qtxsldym", loader);
                 if(qtxsldym["original"].length == 0)
                 {
                   Invalid("type_swipe" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SliderSolver_code").html())({"hntopbjo": hntopbjo["updated"],"vzdntdxz": vzdntdxz["updated"],"ujmnxamh": ujmnxamh["updated"],"pttpeuux": pttpeuux["updated"],"friydhhj": friydhhj["updated"],"lqqjqtui": lqqjqtui["updated"],"dzhyfkci": dzhyfkci["updated"],"vgzxrjtl": vgzxrjtl["updated"],"ncefzrot": ncefzrot["updated"],"amkasjxh": amkasjxh["updated"],"swtentsc": swtentsc["updated"],"uxcvhppf": uxcvhppf["updated"],"qtxsldym": qtxsldym["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
