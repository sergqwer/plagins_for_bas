var nnfuvlfd = GetInputConstructorValue("nnfuvlfd", loader);
                 if(nnfuvlfd["original"].length == 0)
                 {
                   Invalid("custom_button" + " is empty");
                   return;
                 }
var aeejtfhj = GetInputConstructorValue("aeejtfhj", loader);
                 if(aeejtfhj["original"].length == 0)
                 {
                   Invalid("max_time" + " is empty");
                   return;
                 }
var vyxdjujw = GetInputConstructorValue("vyxdjujw", loader);
                 if(vyxdjujw["original"].length == 0)
                 {
                   Invalid("whait_element" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_AutoBypassCloudFlare_code").html())({"nnfuvlfd": nnfuvlfd["updated"],"aeejtfhj": aeejtfhj["updated"],"vyxdjujw": vyxdjujw["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
