_call_function(GoodXevilPaySolver_GXP_HcaptchaTakeToken,{ "APIKEY": (<%= iadilsyj %>),"site_url": (<%= lmvbcdbl %>),"sitekey": (<%= cdifmftt %>) })!
<%= variable %> = _result_function()
