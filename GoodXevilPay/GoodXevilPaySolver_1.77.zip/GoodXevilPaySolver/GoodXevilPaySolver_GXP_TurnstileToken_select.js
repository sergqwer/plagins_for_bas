var ndemaqcj = GetInputConstructorValue("ndemaqcj", loader);
                 if(ndemaqcj["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var qcixivre = GetInputConstructorValue("qcixivre", loader);
                 if(qcixivre["original"].length == 0)
                 {
                   Invalid("site_url" + " is empty");
                   return;
                 }
var sbnhzmes = GetInputConstructorValue("sbnhzmes", loader);
                 if(sbnhzmes["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_TurnstileToken_code").html())({"ndemaqcj": ndemaqcj["updated"],"qcixivre": qcixivre["updated"],"sbnhzmes": sbnhzmes["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
