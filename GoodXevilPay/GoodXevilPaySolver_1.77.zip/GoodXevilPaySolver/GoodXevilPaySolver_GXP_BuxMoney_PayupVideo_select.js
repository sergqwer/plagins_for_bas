var aeqdqdpi = GetInputConstructorValue("aeqdqdpi", loader);
                 if(aeqdqdpi["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var muytzpjc = GetInputConstructorValue("muytzpjc", loader);
                 if(muytzpjc["original"].length == 0)
                 {
                   Invalid("timer" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_BuxMoney_PayupVideo_code").html())({"aeqdqdpi": aeqdqdpi["updated"],"muytzpjc": muytzpjc["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
