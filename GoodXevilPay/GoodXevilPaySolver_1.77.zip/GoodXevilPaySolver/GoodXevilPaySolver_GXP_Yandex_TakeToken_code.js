_call_function(GoodXevilPaySolver_GXP_Yandex_TakeToken,{ "apikey": (<%= aynwmqkp %>),"pageurl": (<%= qkrhaowi %>),"sitekey": (<%= yyglfybj %>) })!
<%= variable %> = _result_function()
