var vuxxlyrl = GetInputConstructorValue("vuxxlyrl", loader);
                 if(vuxxlyrl["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var nzdxbskm = GetInputConstructorValue("nzdxbskm", loader);
                 if(nzdxbskm["original"].length == 0)
                 {
                   Invalid("arab_fix" + " is empty");
                   return;
                 }
var ulzwmpet = GetInputConstructorValue("ulzwmpet", loader);
                 if(ulzwmpet["original"].length == 0)
                 {
                   Invalid("captcha_submit" + " is empty");
                   return;
                 }
var agupjsvk = GetInputConstructorValue("agupjsvk", loader);
                 if(agupjsvk["original"].length == 0)
                 {
                   Invalid("foto_captcha" + " is empty");
                   return;
                 }
var iluxboki = GetInputConstructorValue("iluxboki", loader);
                 if(iluxboki["original"].length == 0)
                 {
                   Invalid("pixel_coef" + " is empty");
                   return;
                 }
var wzpwaeze = GetInputConstructorValue("wzpwaeze", loader);
                 if(wzpwaeze["original"].length == 0)
                 {
                   Invalid("reload_captcha" + " is empty");
                   return;
                 }
var zjqsumkr = GetInputConstructorValue("zjqsumkr", loader);
                 if(zjqsumkr["original"].length == 0)
                 {
                   Invalid("type_data" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SolverGeetestIcon_code").html())({"vuxxlyrl": vuxxlyrl["updated"],"nzdxbskm": nzdxbskm["updated"],"ulzwmpet": ulzwmpet["updated"],"agupjsvk": agupjsvk["updated"],"iluxboki": iluxboki["updated"],"wzpwaeze": wzpwaeze["updated"],"zjqsumkr": zjqsumkr["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
