_call_function(GoodXevilPaySolver_GXP_ReCaptcha_click,{ "apikey": (<%= sojzwlty %>),"CaptchaSelector": (<%= gjqcoody %>),"InvisibleCaptcha": (<%= eknevffl %>),"TrySolve": (<%= kryqddqp %>) })!
