var sojzwlty = GetInputConstructorValue("sojzwlty", loader);
                 if(sojzwlty["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var gjqcoody = GetInputConstructorValue("gjqcoody", loader);
                 if(gjqcoody["original"].length == 0)
                 {
                   Invalid("CaptchaSelector" + " is empty");
                   return;
                 }
var eknevffl = GetInputConstructorValue("eknevffl", loader);
                 if(eknevffl["original"].length == 0)
                 {
                   Invalid("InvisibleCaptcha" + " is empty");
                   return;
                 }
var kryqddqp = GetInputConstructorValue("kryqddqp", loader);
                 if(kryqddqp["original"].length == 0)
                 {
                   Invalid("TrySolve" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_ReCaptcha_click_code").html())({"sojzwlty": sojzwlty["updated"],"gjqcoody": gjqcoody["updated"],"eknevffl": eknevffl["updated"],"kryqddqp": kryqddqp["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
