var jbuhdykb = GetInputConstructorValue("jbuhdykb", loader);
                 if(jbuhdykb["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var xlsrjlrh = GetInputConstructorValue("xlsrjlrh", loader);
                 if(xlsrjlrh["original"].length == 0)
                 {
                   Invalid("enterprise" + " is empty");
                   return;
                 }
var cgwrwlty = GetInputConstructorValue("cgwrwlty", loader);
                 if(cgwrwlty["original"].length == 0)
                 {
                   Invalid("index" + " is empty");
                   return;
                 }
var hiifxolr = GetInputConstructorValue("hiifxolr", loader);
                 if(hiifxolr["original"].length == 0)
                 {
                   Invalid("invisible" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_ReCaptcha_Bypass_No_Exten_code").html())({"jbuhdykb": jbuhdykb["updated"],"xlsrjlrh": xlsrjlrh["updated"],"cgwrwlty": cgwrwlty["updated"],"hiifxolr": hiifxolr["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
