var nedvrdci = GetInputConstructorValue("nedvrdci", loader);
                 if(nedvrdci["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var prbqyuki = GetInputConstructorValue("prbqyuki", loader);
                 if(prbqyuki["original"].length == 0)
                 {
                   Invalid("images_button" + " is empty");
                   return;
                 }
var ygyuyoxe = GetInputConstructorValue("ygyuyoxe", loader);
                 if(ygyuyoxe["original"].length == 0)
                 {
                   Invalid("reload_button" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_GeeTestImages_code").html())({"nedvrdci": nedvrdci["updated"],"prbqyuki": prbqyuki["updated"],"ygyuyoxe": ygyuyoxe["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
