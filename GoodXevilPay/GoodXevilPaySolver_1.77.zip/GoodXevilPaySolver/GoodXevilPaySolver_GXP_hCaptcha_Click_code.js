_call_function(GoodXevilPaySolver_GXP_hCaptcha_Click,{ "apikey": (<%= uwwnzhdn %>),"CaptchaSelector": (<%= fqnmigcl %>),"InvisibleCaptcha": (<%= zitsqlgd %>),"TrySolve": (<%= qkfdhtii %>) })!
