var pgloourf = GetInputConstructorValue("pgloourf", loader);
                 if(pgloourf["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var xemmforf = GetInputConstructorValue("xemmforf", loader);
                 if(xemmforf["original"].length == 0)
                 {
                   Invalid("mouse" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_Antibot_code").html())({"pgloourf": pgloourf["updated"],"xemmforf": xemmforf["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
