<div class="container-fluid">
<%= _.template($('#input_constructor').html())({id:"wlyrjklk", description:"APIKEY", default_selector: "string", disable_int:true, value_string: "", help: {description: "apikey с сервиса https://t.me/Xevil_check_bot\n\napikey from https://t.me/Xevil_check_bot"} }) %>
<%= _.template($('#input_constructor').html())({id:"ovbfrrvn", description:"site_url", default_selector: "string", disable_int:true, value_string: "https://onlyfaucet.com/", help: {description: "Полный URL страницы где находится AuthKong\n\nFull URL of the page where the AuthKong is located"} }) %>
<%= _.template($('#input_constructor').html())({id:"bqsjkohr", description:"sitekey", default_selector: "string", disable_int:true, value_string: "08f2c2d465d09d4dfd64eeb53f8b579f135b15abf170407747312a066f88b2a1", help: {description: "Значение параметра data-sitekey AuthKong\n\nAuthKong data-sitekey parameter value"} }) %>
<%= _.template($('#variable_constructor').html())({id:"Save", description:"Result", default_variable: "AUTHKONG_RESULT", help: {description: ""}}) %>
</div>
<div class="tooltipinternal">
<div class="tr tooltip-paragraph-first-fold">Эта функция получает токен AuthKong через сервис решения капчи https://t.me/Xevil_check_bot This feature receives a AuthKong token via the captcha solution service https://t.me/Xevil_check_bot</div>
</div>
<%= _.template($('#back').html())({action:"executeandadd", visible:true}) %>
