_call_function(GoodXevilPaySolver_GXP_IconsFinder,{ "APIKEY": (<%= zxcloosx %>),"iconselement": (<%= aapitbmz %>) })!
