_call_function(GoodXevilPaySolver_GXP_AutoBypassCloudFlare,{ "custom_button": (<%= nnfuvlfd %>),"max_time": (<%= aeejtfhj %>),"whait_element": (<%= vyxdjujw %>) })!
