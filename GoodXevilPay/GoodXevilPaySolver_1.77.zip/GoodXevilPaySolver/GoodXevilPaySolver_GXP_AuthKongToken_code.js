_call_function(GoodXevilPaySolver_GXP_AuthKongToken,{ "APIKEY": (<%= wlyrjklk %>),"site_url": (<%= ovbfrrvn %>),"sitekey": (<%= bqsjkohr %>) })!
<%= variable %> = _result_function()
