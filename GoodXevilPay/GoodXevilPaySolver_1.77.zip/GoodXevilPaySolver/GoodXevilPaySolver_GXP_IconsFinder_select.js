var zxcloosx = GetInputConstructorValue("zxcloosx", loader);
                 if(zxcloosx["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var aapitbmz = GetInputConstructorValue("aapitbmz", loader);
                 if(aapitbmz["original"].length == 0)
                 {
                   Invalid("iconselement" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_IconsFinder_code").html())({"zxcloosx": zxcloosx["updated"],"aapitbmz": aapitbmz["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
