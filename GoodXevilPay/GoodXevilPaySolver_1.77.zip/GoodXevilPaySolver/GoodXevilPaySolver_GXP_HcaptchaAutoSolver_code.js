_call_function(GoodXevilPaySolver_GXP_HcaptchaAutoSolver,{ "apikey": (<%= clsoskcr %>) })!
<%= variable %> = _result_function()
