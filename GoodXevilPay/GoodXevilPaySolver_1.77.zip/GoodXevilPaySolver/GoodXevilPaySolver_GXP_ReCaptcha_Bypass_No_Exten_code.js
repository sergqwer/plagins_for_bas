_call_function(GoodXevilPaySolver_GXP_ReCaptcha_Bypass_No_Exten,{ "apikey": (<%= jbuhdykb %>),"enterprise": (<%= xlsrjlrh %>),"index": (<%= cgwrwlty %>),"invisible": (<%= hiifxolr %>) })!
<%= variable %> = _result_function()
