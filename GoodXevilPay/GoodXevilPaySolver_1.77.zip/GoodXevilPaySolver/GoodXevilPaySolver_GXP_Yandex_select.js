var jvifpmlm = GetInputConstructorValue("jvifpmlm", loader);
                 if(jvifpmlm["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var ublncjje = GetInputConstructorValue("ublncjje", loader);
                 if(ublncjje["original"].length == 0)
                 {
                   Invalid("CaptchaSelector" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_Yandex_code").html())({"jvifpmlm": jvifpmlm["updated"],"ublncjje": ublncjje["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
