var zuuknqhf = GetInputConstructorValue("zuuknqhf", loader);
                 if(zuuknqhf["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var szbahorz = GetInputConstructorValue("szbahorz", loader);
                 if(szbahorz["original"].length == 0)
                 {
                   Invalid("captcha_submit" + " is empty");
                   return;
                 }
var sbsohzhx = GetInputConstructorValue("sbsohzhx", loader);
                 if(sbsohzhx["original"].length == 0)
                 {
                   Invalid("foto_captcha" + " is empty");
                   return;
                 }
var pywkrhnb = GetInputConstructorValue("pywkrhnb", loader);
                 if(pywkrhnb["original"].length == 0)
                 {
                   Invalid("pixel_coef" + " is empty");
                   return;
                 }
var fczymwdg = GetInputConstructorValue("fczymwdg", loader);
                 if(fczymwdg["original"].length == 0)
                 {
                   Invalid("reload_captcha" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SolverGeetestIcon_code").html())({"zuuknqhf": zuuknqhf["updated"],"szbahorz": szbahorz["updated"],"sbsohzhx": sbsohzhx["updated"],"pywkrhnb": pywkrhnb["updated"],"fczymwdg": fczymwdg["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
