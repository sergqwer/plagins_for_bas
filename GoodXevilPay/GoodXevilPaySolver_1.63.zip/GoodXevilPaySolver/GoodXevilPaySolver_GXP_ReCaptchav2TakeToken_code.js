_call_function(GoodXevilPaySolver_GXP_ReCaptchav2TakeToken,{ "APIKEY": (<%= vvkwytee %>),"site_url": (<%= cnaxwxlv %>),"sitekey": (<%= wcbzdsbq %>) })!
<%= variable %> = _result_function()
