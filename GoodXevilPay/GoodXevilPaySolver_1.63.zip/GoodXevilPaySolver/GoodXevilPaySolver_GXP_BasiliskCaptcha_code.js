_call_function(GoodXevilPaySolver_GXP_BasiliskCaptcha,{ "apikey": (<%= gqualkhp %>),"sitekey": (<%= wiilupqd %>),"siteurl": (<%= vevjhksk %>) })!
