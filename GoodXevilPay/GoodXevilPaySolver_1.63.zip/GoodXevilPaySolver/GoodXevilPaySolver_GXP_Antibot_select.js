var wvmngvfb = GetInputConstructorValue("wvmngvfb", loader);
                 if(wvmngvfb["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var cyxgtful = GetInputConstructorValue("cyxgtful", loader);
                 if(cyxgtful["original"].length == 0)
                 {
                   Invalid("mouse" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_Antibot_code").html())({"wvmngvfb": wvmngvfb["updated"],"cyxgtful": cyxgtful["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
