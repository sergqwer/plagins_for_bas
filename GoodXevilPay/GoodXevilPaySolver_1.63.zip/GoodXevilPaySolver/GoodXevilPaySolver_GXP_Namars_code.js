_call_function(GoodXevilPaySolver_GXP_Namars,{ "apikey": (<%= fmoqewca %>) })!
<%= variable %> = _result_function()
