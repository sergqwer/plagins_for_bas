var dfyczjnn = GetInputConstructorValue("dfyczjnn", loader);
                 if(dfyczjnn["original"].length == 0)
                 {
                   Invalid("arrow_id" + " is empty");
                   return;
                 }
var ugogdxzr = GetInputConstructorValue("ugogdxzr", loader);
                 if(ugogdxzr["original"].length == 0)
                 {
                   Invalid("avtoupdate" + " is empty");
                   return;
                 }
var qxctpswp = GetInputConstructorValue("qxctpswp", loader);
                 if(qxctpswp["original"].length == 0)
                 {
                   Invalid("button_id" + " is empty");
                   return;
                 }
var zrrwxuhz = GetInputConstructorValue("zrrwxuhz", loader);
                 if(zrrwxuhz["original"].length == 0)
                 {
                   Invalid("coef" + " is empty");
                   return;
                 }
var xyhjmxbt = GetInputConstructorValue("xyhjmxbt", loader);
                 if(xyhjmxbt["original"].length == 0)
                 {
                   Invalid("image id" + " is empty");
                   return;
                 }
var ndnvlrmq = GetInputConstructorValue("ndnvlrmq", loader);
                 if(ndnvlrmq["original"].length == 0)
                 {
                   Invalid("key" + " is empty");
                   return;
                 }
var rouokrqd = GetInputConstructorValue("rouokrqd", loader);
                 if(rouokrqd["original"].length == 0)
                 {
                   Invalid("pixel_koef" + " is empty");
                   return;
                 }
var ouibpxhl = GetInputConstructorValue("ouibpxhl", loader);
                 if(ouibpxhl["original"].length == 0)
                 {
                   Invalid("reload_id" + " is empty");
                   return;
                 }
var uaapkslb = GetInputConstructorValue("uaapkslb", loader);
                 if(uaapkslb["original"].length == 0)
                 {
                   Invalid("speed" + " is empty");
                   return;
                 }
var wnrhbthq = GetInputConstructorValue("wnrhbthq", loader);
                 if(wnrhbthq["original"].length == 0)
                 {
                   Invalid("type_slide" + " is empty");
                   return;
                 }
var blysjirb = GetInputConstructorValue("blysjirb", loader);
                 if(blysjirb["original"].length == 0)
                 {
                   Invalid("type_swipe" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SliderSolver_code").html())({"dfyczjnn": dfyczjnn["updated"],"ugogdxzr": ugogdxzr["updated"],"qxctpswp": qxctpswp["updated"],"zrrwxuhz": zrrwxuhz["updated"],"xyhjmxbt": xyhjmxbt["updated"],"ndnvlrmq": ndnvlrmq["updated"],"rouokrqd": rouokrqd["updated"],"ouibpxhl": ouibpxhl["updated"],"uaapkslb": uaapkslb["updated"],"wnrhbthq": wnrhbthq["updated"],"blysjirb": blysjirb["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
