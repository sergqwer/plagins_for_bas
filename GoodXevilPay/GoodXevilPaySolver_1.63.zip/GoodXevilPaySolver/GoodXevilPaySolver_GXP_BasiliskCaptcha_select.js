var gqualkhp = GetInputConstructorValue("gqualkhp", loader);
                 if(gqualkhp["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var wiilupqd = GetInputConstructorValue("wiilupqd", loader);
                 if(wiilupqd["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var vevjhksk = GetInputConstructorValue("vevjhksk", loader);
                 if(vevjhksk["original"].length == 0)
                 {
                   Invalid("siteurl" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_BasiliskCaptcha_code").html())({"gqualkhp": gqualkhp["updated"],"wiilupqd": wiilupqd["updated"],"vevjhksk": vevjhksk["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
