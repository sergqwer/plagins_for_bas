var qrbsbeym = GetInputConstructorValue("qrbsbeym", loader);
                 if(qrbsbeym["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var sgnahoiq = GetInputConstructorValue("sgnahoiq", loader);
                 if(sgnahoiq["original"].length == 0)
                 {
                   Invalid("timer" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_BuxMoney_PayupVideo_code").html())({"qrbsbeym": qrbsbeym["updated"],"sgnahoiq": sgnahoiq["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
