var wgkvchdi = GetInputConstructorValue("wgkvchdi", loader);
                 if(wgkvchdi["original"].length == 0)
                 {
                   Invalid("custom_button" + " is empty");
                   return;
                 }
var gtdgfjza = GetInputConstructorValue("gtdgfjza", loader);
                 if(gtdgfjza["original"].length == 0)
                 {
                   Invalid("max_time" + " is empty");
                   return;
                 }
var zmzddyqi = GetInputConstructorValue("zmzddyqi", loader);
                 if(zmzddyqi["original"].length == 0)
                 {
                   Invalid("whait_element" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_AutoBypassCloudFlare_code").html())({"wgkvchdi": wgkvchdi["updated"],"gtdgfjza": gtdgfjza["updated"],"zmzddyqi": zmzddyqi["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
