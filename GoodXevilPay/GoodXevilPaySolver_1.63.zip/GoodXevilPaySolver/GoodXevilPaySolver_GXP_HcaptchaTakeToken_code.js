_call_function(GoodXevilPaySolver_GXP_HcaptchaTakeToken,{ "APIKEY": (<%= yibmzwpd %>),"site_url": (<%= whdlfvhb %>),"sitekey": (<%= esaikwrd %>) })!
<%= variable %> = _result_function()
