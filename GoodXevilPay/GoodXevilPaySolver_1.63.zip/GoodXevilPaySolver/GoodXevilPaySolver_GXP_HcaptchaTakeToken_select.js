var yibmzwpd = GetInputConstructorValue("yibmzwpd", loader);
                 if(yibmzwpd["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var whdlfvhb = GetInputConstructorValue("whdlfvhb", loader);
                 if(whdlfvhb["original"].length == 0)
                 {
                   Invalid("site_url" + " is empty");
                   return;
                 }
var esaikwrd = GetInputConstructorValue("esaikwrd", loader);
                 if(esaikwrd["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_HcaptchaTakeToken_code").html())({"yibmzwpd": yibmzwpd["updated"],"whdlfvhb": whdlfvhb["updated"],"esaikwrd": esaikwrd["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
