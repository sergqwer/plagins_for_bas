_call_function(GoodXevilPaySolver_GXP_AutoBypassCloudFlare,{ "custom_button": (<%= wgkvchdi %>),"max_time": (<%= gtdgfjza %>),"whait_element": (<%= zmzddyqi %>) })!
