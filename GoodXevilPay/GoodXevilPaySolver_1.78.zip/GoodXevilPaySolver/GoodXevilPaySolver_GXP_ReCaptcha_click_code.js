_call_function(GoodXevilPaySolver_GXP_ReCaptcha_click,{ "apikey": (<%= xicakktf %>),"CaptchaSelector": (<%= ghdffsmd %>),"InvisibleCaptcha": (<%= iscvlzua %>),"TrySolve": (<%= liangrvj %>) })!
