var shwuzqxp = GetInputConstructorValue("shwuzqxp", loader);
                 if(shwuzqxp["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var tqdihfiv = GetInputConstructorValue("tqdihfiv", loader);
                 if(tqdihfiv["original"].length == 0)
                 {
                   Invalid("site_url" + " is empty");
                   return;
                 }
var jizndjwg = GetInputConstructorValue("jizndjwg", loader);
                 if(jizndjwg["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_AuthKongToken_code").html())({"shwuzqxp": shwuzqxp["updated"],"tqdihfiv": tqdihfiv["updated"],"jizndjwg": jizndjwg["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
