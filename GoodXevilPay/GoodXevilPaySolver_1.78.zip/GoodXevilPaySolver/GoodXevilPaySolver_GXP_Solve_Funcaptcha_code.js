_call_function(GoodXevilPaySolver_GXP_Solve_Funcaptcha,{ "APIKey": (<%= gbkorcpt %>),"CaptchaNumber": (<%= bpgluykd %>),"CaptchaSelector": (<%= asxcbdgv %>),"MaxLimitTask": (<%= zhobyzlr %>) })!
