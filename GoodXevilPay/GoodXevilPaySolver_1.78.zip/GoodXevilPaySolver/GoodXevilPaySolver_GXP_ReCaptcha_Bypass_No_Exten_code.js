_call_function(GoodXevilPaySolver_GXP_ReCaptcha_Bypass_No_Exten,{ "apikey": (<%= sivlieko %>),"enterprise": (<%= orkdslvn %>),"index": (<%= nwkuibzy %>),"invisible": (<%= jtndartf %>),"recaptchaframe": (<%= dlrkihkk %>) })!
<%= variable %> = _result_function()
