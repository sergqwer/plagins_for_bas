var rbxyfrxj = GetInputConstructorValue("rbxyfrxj", loader);
                 if(rbxyfrxj["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var kvcyylgd = GetInputConstructorValue("kvcyylgd", loader);
                 if(kvcyylgd["original"].length == 0)
                 {
                   Invalid("mouse" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_Antibot_code").html())({"rbxyfrxj": rbxyfrxj["updated"],"kvcyylgd": kvcyylgd["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
