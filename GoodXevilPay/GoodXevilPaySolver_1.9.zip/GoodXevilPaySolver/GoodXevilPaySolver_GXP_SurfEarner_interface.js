<div class="container-fluid">
<%= _.template($('#input_constructor').html())({id:"linvwmbj", description:"apikey", default_selector: "string", disable_expression:true, disable_int:true, value_string: "", help: {description: "apikey с бота в телеграмме https://t.me/Xevil_check_bot"} }) %>
</div>
<div class="tooltipinternal">
<div class="tr tooltip-paragraph-first-fold">Автоматически решает капчу на сайте https://surfearner.com/, для работы требуется функция GXP_SurfEarner_AllowCache</div>
</div>
<%= _.template($('#back').html())({action:"executeandadd", visible:true}) %>
