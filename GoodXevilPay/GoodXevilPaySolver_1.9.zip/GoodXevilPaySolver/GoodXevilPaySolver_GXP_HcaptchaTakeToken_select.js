var ymfiundh = GetInputConstructorValue("ymfiundh", loader);
                 if(ymfiundh["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var ncdvggac = GetInputConstructorValue("ncdvggac", loader);
                 if(ncdvggac["original"].length == 0)
                 {
                   Invalid("site_url" + " is empty");
                   return;
                 }
var ykizzsob = GetInputConstructorValue("ykizzsob", loader);
                 if(ykizzsob["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_HcaptchaTakeToken_code").html())({"ymfiundh": ymfiundh["updated"],"ncdvggac": ncdvggac["updated"],"ykizzsob": ykizzsob["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
