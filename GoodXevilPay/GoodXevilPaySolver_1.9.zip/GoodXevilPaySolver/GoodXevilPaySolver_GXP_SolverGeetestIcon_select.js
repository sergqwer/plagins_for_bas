var qxlzrfbl = GetInputConstructorValue("qxlzrfbl", loader);
                 if(qxlzrfbl["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var gfazbquc = GetInputConstructorValue("gfazbquc", loader);
                 if(gfazbquc["original"].length == 0)
                 {
                   Invalid("button_capthca" + " is empty");
                   return;
                 }
var fyqnfcuo = GetInputConstructorValue("fyqnfcuo", loader);
                 if(fyqnfcuo["original"].length == 0)
                 {
                   Invalid("captcha_submit" + " is empty");
                   return;
                 }
var dxhwtpzw = GetInputConstructorValue("dxhwtpzw", loader);
                 if(dxhwtpzw["original"].length == 0)
                 {
                   Invalid("foto_captcha" + " is empty");
                   return;
                 }
var llxsbneu = GetInputConstructorValue("llxsbneu", loader);
                 if(llxsbneu["original"].length == 0)
                 {
                   Invalid("reload_captcha" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SolverGeetestIcon_code").html())({"qxlzrfbl": qxlzrfbl["updated"],"gfazbquc": gfazbquc["updated"],"fyqnfcuo": fyqnfcuo["updated"],"dxhwtpzw": dxhwtpzw["updated"],"llxsbneu": llxsbneu["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
