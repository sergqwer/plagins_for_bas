_call_function(GoodXevilPaySolver_GXP_GetBalance,{ "APIKEY": (<%= nvegzegm %>) })!
<%= variable %> = _result_function()
