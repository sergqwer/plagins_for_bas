var gzwctbnt = GetInputConstructorValue("gzwctbnt", loader);
                 if(gzwctbnt["original"].length == 0)
                 {
                   Invalid("AutoSettings" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_ForAutosolveReHCaptcha_code").html())({"gzwctbnt": gzwctbnt["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
