_call_function(GoodXevilPaySolver_GXP_HcaptchaTakeToken,{ "APIKEY": (<%= ymfiundh %>),"site_url": (<%= ncdvggac %>),"sitekey": (<%= ykizzsob %>) })!
<%= variable %> = _result_function()
