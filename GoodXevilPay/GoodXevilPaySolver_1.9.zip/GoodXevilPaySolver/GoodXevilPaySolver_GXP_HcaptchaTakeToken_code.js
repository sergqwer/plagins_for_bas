_call_function(GoodXevilPaySolver_GXP_HcaptchaTakeToken,{ "APIKEY": (<%= zlmwguaq %>),"site_url": (<%= uuckcqdb %>),"sitekey": (<%= nafgtfwb %>) })!
<%= variable %> = _result_function()
