var snbkymxb = GetInputConstructorValue("snbkymxb", loader);
                 if(snbkymxb["original"].length == 0)
                 {
                   Invalid("arrow_id" + " is empty");
                   return;
                 }
var zmsxvatb = GetInputConstructorValue("zmsxvatb", loader);
                 if(zmsxvatb["original"].length == 0)
                 {
                   Invalid("avtoupdate" + " is empty");
                   return;
                 }
var okndlkgr = GetInputConstructorValue("okndlkgr", loader);
                 if(okndlkgr["original"].length == 0)
                 {
                   Invalid("button_id" + " is empty");
                   return;
                 }
var bbcbmozn = GetInputConstructorValue("bbcbmozn", loader);
                 if(bbcbmozn["original"].length == 0)
                 {
                   Invalid("coef" + " is empty");
                   return;
                 }
var btiyvbvq = GetInputConstructorValue("btiyvbvq", loader);
                 if(btiyvbvq["original"].length == 0)
                 {
                   Invalid("image id" + " is empty");
                   return;
                 }
var elpuqhvp = GetInputConstructorValue("elpuqhvp", loader);
                 if(elpuqhvp["original"].length == 0)
                 {
                   Invalid("key" + " is empty");
                   return;
                 }
var zwmttnan = GetInputConstructorValue("zwmttnan", loader);
                 if(zwmttnan["original"].length == 0)
                 {
                   Invalid("pixel_koef" + " is empty");
                   return;
                 }
var txcsglhu = GetInputConstructorValue("txcsglhu", loader);
                 if(txcsglhu["original"].length == 0)
                 {
                   Invalid("reload_id" + " is empty");
                   return;
                 }
var saauipre = GetInputConstructorValue("saauipre", loader);
                 if(saauipre["original"].length == 0)
                 {
                   Invalid("speed" + " is empty");
                   return;
                 }
var mxxcopqg = GetInputConstructorValue("mxxcopqg", loader);
                 if(mxxcopqg["original"].length == 0)
                 {
                   Invalid("type_slide" + " is empty");
                   return;
                 }
var jvmyyzhu = GetInputConstructorValue("jvmyyzhu", loader);
                 if(jvmyyzhu["original"].length == 0)
                 {
                   Invalid("type_swipe" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SliderSolver_code").html())({"snbkymxb": snbkymxb["updated"],"zmsxvatb": zmsxvatb["updated"],"okndlkgr": okndlkgr["updated"],"bbcbmozn": bbcbmozn["updated"],"btiyvbvq": btiyvbvq["updated"],"elpuqhvp": elpuqhvp["updated"],"zwmttnan": zwmttnan["updated"],"txcsglhu": txcsglhu["updated"],"saauipre": saauipre["updated"],"mxxcopqg": mxxcopqg["updated"],"jvmyyzhu": jvmyyzhu["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
