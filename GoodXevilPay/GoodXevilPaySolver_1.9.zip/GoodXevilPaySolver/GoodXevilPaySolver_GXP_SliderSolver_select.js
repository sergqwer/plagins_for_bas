var wqqbkmtc = GetInputConstructorValue("wqqbkmtc", loader);
                 if(wqqbkmtc["original"].length == 0)
                 {
                   Invalid("arrow_id" + " is empty");
                   return;
                 }
var imsanhow = GetInputConstructorValue("imsanhow", loader);
                 if(imsanhow["original"].length == 0)
                 {
                   Invalid("avtoupdate" + " is empty");
                   return;
                 }
var qmrmfmyw = GetInputConstructorValue("qmrmfmyw", loader);
                 if(qmrmfmyw["original"].length == 0)
                 {
                   Invalid("button_id" + " is empty");
                   return;
                 }
var dhbkqntq = GetInputConstructorValue("dhbkqntq", loader);
                 if(dhbkqntq["original"].length == 0)
                 {
                   Invalid("coef" + " is empty");
                   return;
                 }
var mkyayrfg = GetInputConstructorValue("mkyayrfg", loader);
                 if(mkyayrfg["original"].length == 0)
                 {
                   Invalid("image id" + " is empty");
                   return;
                 }
var kyalrxct = GetInputConstructorValue("kyalrxct", loader);
                 if(kyalrxct["original"].length == 0)
                 {
                   Invalid("key" + " is empty");
                   return;
                 }
var cvdbhwmh = GetInputConstructorValue("cvdbhwmh", loader);
                 if(cvdbhwmh["original"].length == 0)
                 {
                   Invalid("pixel_koef" + " is empty");
                   return;
                 }
var cxuqebvk = GetInputConstructorValue("cxuqebvk", loader);
                 if(cxuqebvk["original"].length == 0)
                 {
                   Invalid("reload_id" + " is empty");
                   return;
                 }
var sddrjtsi = GetInputConstructorValue("sddrjtsi", loader);
                 if(sddrjtsi["original"].length == 0)
                 {
                   Invalid("speed" + " is empty");
                   return;
                 }
var rlfkpvaj = GetInputConstructorValue("rlfkpvaj", loader);
                 if(rlfkpvaj["original"].length == 0)
                 {
                   Invalid("type_slide" + " is empty");
                   return;
                 }
var rfzqmhfq = GetInputConstructorValue("rfzqmhfq", loader);
                 if(rfzqmhfq["original"].length == 0)
                 {
                   Invalid("type_swipe" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SliderSolver_code").html())({"wqqbkmtc": wqqbkmtc["updated"],"imsanhow": imsanhow["updated"],"qmrmfmyw": qmrmfmyw["updated"],"dhbkqntq": dhbkqntq["updated"],"mkyayrfg": mkyayrfg["updated"],"kyalrxct": kyalrxct["updated"],"cvdbhwmh": cvdbhwmh["updated"],"cxuqebvk": cxuqebvk["updated"],"sddrjtsi": sddrjtsi["updated"],"rlfkpvaj": rlfkpvaj["updated"],"rfzqmhfq": rfzqmhfq["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
