_call_function(GoodXevilPaySolver_GXP_IMAGE_BASE64,{ "APIKEY": (<%= xtyzbmdk %>),"IMAGE_BASE64": (<%= afjobsbu %>) })!
<%= variable %> = _result_function()
