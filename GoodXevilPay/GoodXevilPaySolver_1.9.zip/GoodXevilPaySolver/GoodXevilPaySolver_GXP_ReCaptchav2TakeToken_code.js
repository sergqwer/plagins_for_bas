_call_function(GoodXevilPaySolver_GXP_ReCaptchav2TakeToken,{ "APIKEY": (<%= zjqgpnfn %>),"site_url": (<%= jpjbokzm %>),"sitekey": (<%= qcasdyct %>) })!
<%= variable %> = _result_function()
