_call_function(GoodXevilPaySolver_GXP_ReCaptchav2TakeToken,{ "APIKEY": (<%= udhhvxuh %>),"site_url": (<%= wxpcdaei %>),"sitekey": (<%= tymmsalo %>) })!
<%= variable %> = _result_function()
