var tbrdjkxi = GetInputConstructorValue("tbrdjkxi", loader);
                 if(tbrdjkxi["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var tyjadlrl = GetInputConstructorValue("tyjadlrl", loader);
                 if(tyjadlrl["original"].length == 0)
                 {
                   Invalid("timer" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_BuxMoney_PayupVideo_code").html())({"tbrdjkxi": tbrdjkxi["updated"],"tyjadlrl": tyjadlrl["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
