var aciyvajz = GetInputConstructorValue("aciyvajz", loader);
                 if(aciyvajz["original"].length == 0)
                 {
                   Invalid("token" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_AutoConfirmCallback_ReCaptcha_code").html())({"aciyvajz": aciyvajz["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
