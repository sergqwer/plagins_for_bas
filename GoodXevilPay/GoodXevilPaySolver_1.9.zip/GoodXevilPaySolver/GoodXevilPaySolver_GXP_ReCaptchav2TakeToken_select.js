var zjqgpnfn = GetInputConstructorValue("zjqgpnfn", loader);
                 if(zjqgpnfn["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var jpjbokzm = GetInputConstructorValue("jpjbokzm", loader);
                 if(jpjbokzm["original"].length == 0)
                 {
                   Invalid("site_url" + " is empty");
                   return;
                 }
var qcasdyct = GetInputConstructorValue("qcasdyct", loader);
                 if(qcasdyct["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_ReCaptchav2TakeToken_code").html())({"zjqgpnfn": zjqgpnfn["updated"],"jpjbokzm": jpjbokzm["updated"],"qcasdyct": qcasdyct["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
