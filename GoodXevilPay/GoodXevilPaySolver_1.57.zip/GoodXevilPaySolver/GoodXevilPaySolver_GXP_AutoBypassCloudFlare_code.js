_call_function(GoodXevilPaySolver_GXP_AutoBypassCloudFlare,{ "custom_button": (<%= uoxohzwu %>),"max_time": (<%= eepfeaas %>),"whait_element": (<%= lugxndhn %>) })!
