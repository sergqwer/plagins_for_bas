_call_function(GoodXevilPaySolver_GXP_IMAGE_BASE64,{ "APIKEY": (<%= etazfrcp %>),"IMAGE_BASE64": (<%= ehkxdjvh %>) })!
<%= variable %> = _result_function()
