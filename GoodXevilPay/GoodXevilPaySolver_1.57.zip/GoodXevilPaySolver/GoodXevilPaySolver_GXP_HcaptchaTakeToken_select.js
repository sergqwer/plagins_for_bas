var kxfvgvok = GetInputConstructorValue("kxfvgvok", loader);
                 if(kxfvgvok["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var wvwxwtbg = GetInputConstructorValue("wvwxwtbg", loader);
                 if(wvwxwtbg["original"].length == 0)
                 {
                   Invalid("site_url" + " is empty");
                   return;
                 }
var lbhhlvux = GetInputConstructorValue("lbhhlvux", loader);
                 if(lbhhlvux["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_HcaptchaTakeToken_code").html())({"kxfvgvok": kxfvgvok["updated"],"wvwxwtbg": wvwxwtbg["updated"],"lbhhlvux": lbhhlvux["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
