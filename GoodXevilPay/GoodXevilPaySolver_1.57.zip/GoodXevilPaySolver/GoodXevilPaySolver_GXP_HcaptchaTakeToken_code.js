_call_function(GoodXevilPaySolver_GXP_HcaptchaTakeToken,{ "APIKEY": (<%= kxfvgvok %>),"site_url": (<%= wvwxwtbg %>),"sitekey": (<%= lbhhlvux %>) })!
<%= variable %> = _result_function()
