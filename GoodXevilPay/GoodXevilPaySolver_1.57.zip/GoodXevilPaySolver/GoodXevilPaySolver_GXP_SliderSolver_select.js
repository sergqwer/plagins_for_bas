var vibrzvax = GetInputConstructorValue("vibrzvax", loader);
                 if(vibrzvax["original"].length == 0)
                 {
                   Invalid("arrow_id" + " is empty");
                   return;
                 }
var xrujfvla = GetInputConstructorValue("xrujfvla", loader);
                 if(xrujfvla["original"].length == 0)
                 {
                   Invalid("avtoupdate" + " is empty");
                   return;
                 }
var rvnvtnko = GetInputConstructorValue("rvnvtnko", loader);
                 if(rvnvtnko["original"].length == 0)
                 {
                   Invalid("button_id" + " is empty");
                   return;
                 }
var horyznly = GetInputConstructorValue("horyznly", loader);
                 if(horyznly["original"].length == 0)
                 {
                   Invalid("coef" + " is empty");
                   return;
                 }
var mcrfryfe = GetInputConstructorValue("mcrfryfe", loader);
                 if(mcrfryfe["original"].length == 0)
                 {
                   Invalid("image id" + " is empty");
                   return;
                 }
var ytbiaiea = GetInputConstructorValue("ytbiaiea", loader);
                 if(ytbiaiea["original"].length == 0)
                 {
                   Invalid("key" + " is empty");
                   return;
                 }
var botacnuz = GetInputConstructorValue("botacnuz", loader);
                 if(botacnuz["original"].length == 0)
                 {
                   Invalid("pixel_koef" + " is empty");
                   return;
                 }
var ktpjaeql = GetInputConstructorValue("ktpjaeql", loader);
                 if(ktpjaeql["original"].length == 0)
                 {
                   Invalid("reload_id" + " is empty");
                   return;
                 }
var jxwjuhfw = GetInputConstructorValue("jxwjuhfw", loader);
                 if(jxwjuhfw["original"].length == 0)
                 {
                   Invalid("speed" + " is empty");
                   return;
                 }
var ygrkojtu = GetInputConstructorValue("ygrkojtu", loader);
                 if(ygrkojtu["original"].length == 0)
                 {
                   Invalid("type_slide" + " is empty");
                   return;
                 }
var yrwalily = GetInputConstructorValue("yrwalily", loader);
                 if(yrwalily["original"].length == 0)
                 {
                   Invalid("type_swipe" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SliderSolver_code").html())({"vibrzvax": vibrzvax["updated"],"xrujfvla": xrujfvla["updated"],"rvnvtnko": rvnvtnko["updated"],"horyznly": horyznly["updated"],"mcrfryfe": mcrfryfe["updated"],"ytbiaiea": ytbiaiea["updated"],"botacnuz": botacnuz["updated"],"ktpjaeql": ktpjaeql["updated"],"jxwjuhfw": jxwjuhfw["updated"],"ygrkojtu": ygrkojtu["updated"],"yrwalily": yrwalily["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
