var xdgltqec = GetInputConstructorValue("xdgltqec", loader);
                 if(xdgltqec["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var rpmpanfj = GetInputConstructorValue("rpmpanfj", loader);
                 if(rpmpanfj["original"].length == 0)
                 {
                   Invalid("captcha_submit" + " is empty");
                   return;
                 }
var nfrnjywf = GetInputConstructorValue("nfrnjywf", loader);
                 if(nfrnjywf["original"].length == 0)
                 {
                   Invalid("foto_captcha" + " is empty");
                   return;
                 }
var lcggrtut = GetInputConstructorValue("lcggrtut", loader);
                 if(lcggrtut["original"].length == 0)
                 {
                   Invalid("pixel_coef" + " is empty");
                   return;
                 }
var qgksjogs = GetInputConstructorValue("qgksjogs", loader);
                 if(qgksjogs["original"].length == 0)
                 {
                   Invalid("reload_captcha" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SolverGeetestIcon_code").html())({"xdgltqec": xdgltqec["updated"],"rpmpanfj": rpmpanfj["updated"],"nfrnjywf": nfrnjywf["updated"],"lcggrtut": lcggrtut["updated"],"qgksjogs": qgksjogs["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
