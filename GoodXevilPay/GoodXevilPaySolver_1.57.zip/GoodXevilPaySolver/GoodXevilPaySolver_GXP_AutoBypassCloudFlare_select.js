var uoxohzwu = GetInputConstructorValue("uoxohzwu", loader);
                 if(uoxohzwu["original"].length == 0)
                 {
                   Invalid("custom_button" + " is empty");
                   return;
                 }
var eepfeaas = GetInputConstructorValue("eepfeaas", loader);
                 if(eepfeaas["original"].length == 0)
                 {
                   Invalid("max_time" + " is empty");
                   return;
                 }
var lugxndhn = GetInputConstructorValue("lugxndhn", loader);
                 if(lugxndhn["original"].length == 0)
                 {
                   Invalid("whait_element" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_AutoBypassCloudFlare_code").html())({"uoxohzwu": uoxohzwu["updated"],"eepfeaas": eepfeaas["updated"],"lugxndhn": lugxndhn["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
