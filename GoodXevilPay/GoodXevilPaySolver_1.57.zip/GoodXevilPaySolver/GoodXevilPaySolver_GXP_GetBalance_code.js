_call_function(GoodXevilPaySolver_GXP_GetBalance,{ "APIKEY": (<%= qcxngdng %>) })!
<%= variable %> = _result_function()
