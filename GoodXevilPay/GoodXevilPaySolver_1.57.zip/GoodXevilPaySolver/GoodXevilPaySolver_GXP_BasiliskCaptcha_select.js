var ayyitpty = GetInputConstructorValue("ayyitpty", loader);
                 if(ayyitpty["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var tztfwwjh = GetInputConstructorValue("tztfwwjh", loader);
                 if(tztfwwjh["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var bczxnmux = GetInputConstructorValue("bczxnmux", loader);
                 if(bczxnmux["original"].length == 0)
                 {
                   Invalid("siteurl" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_BasiliskCaptcha_code").html())({"ayyitpty": ayyitpty["updated"],"tztfwwjh": tztfwwjh["updated"],"bczxnmux": bczxnmux["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
