_call_function(GoodXevilPaySolver_GXP_Antibot,{ "apikey": (<%= ghkwilfd %>),"mouse": (<%= dagsotgw %>) })!
