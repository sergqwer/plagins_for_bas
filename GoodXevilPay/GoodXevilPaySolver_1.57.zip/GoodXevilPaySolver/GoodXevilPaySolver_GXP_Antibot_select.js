var ghkwilfd = GetInputConstructorValue("ghkwilfd", loader);
                 if(ghkwilfd["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var dagsotgw = GetInputConstructorValue("dagsotgw", loader);
                 if(dagsotgw["original"].length == 0)
                 {
                   Invalid("mouse" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_Antibot_code").html())({"ghkwilfd": ghkwilfd["updated"],"dagsotgw": dagsotgw["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
