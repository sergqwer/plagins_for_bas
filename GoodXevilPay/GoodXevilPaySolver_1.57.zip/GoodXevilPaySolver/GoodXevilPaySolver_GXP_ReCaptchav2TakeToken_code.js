_call_function(GoodXevilPaySolver_GXP_ReCaptchav2TakeToken,{ "APIKEY": (<%= wubgetre %>),"site_url": (<%= hydceftd %>),"sitekey": (<%= qajxsarj %>) })!
<%= variable %> = _result_function()
