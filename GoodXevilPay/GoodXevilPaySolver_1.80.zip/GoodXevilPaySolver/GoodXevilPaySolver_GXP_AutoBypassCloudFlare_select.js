var uuznljaw = GetInputConstructorValue("uuznljaw", loader);
                 if(uuznljaw["original"].length == 0)
                 {
                   Invalid("custom_button" + " is empty");
                   return;
                 }
var bgyfdfpg = GetInputConstructorValue("bgyfdfpg", loader);
                 if(bgyfdfpg["original"].length == 0)
                 {
                   Invalid("max_time" + " is empty");
                   return;
                 }
var btyhcnyv = GetInputConstructorValue("btyhcnyv", loader);
                 if(btyhcnyv["original"].length == 0)
                 {
                   Invalid("whait_element" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_AutoBypassCloudFlare_code").html())({"uuznljaw": uuznljaw["updated"],"bgyfdfpg": bgyfdfpg["updated"],"btyhcnyv": btyhcnyv["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
