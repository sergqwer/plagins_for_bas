_call_function(GoodXevilPaySolver_GXP_AutoBypassCloudFlare,{ "custom_button": (<%= uuznljaw %>),"max_time": (<%= bgyfdfpg %>),"whait_element": (<%= btyhcnyv %>) })!
