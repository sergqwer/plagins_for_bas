var pcwfxguq = GetInputConstructorValue("pcwfxguq", loader);
                 if(pcwfxguq["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_teaserfast_code").html())({"pcwfxguq": pcwfxguq["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
