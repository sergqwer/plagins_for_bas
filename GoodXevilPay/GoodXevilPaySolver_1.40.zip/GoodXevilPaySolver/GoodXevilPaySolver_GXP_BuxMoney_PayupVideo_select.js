var mcetybdu = GetInputConstructorValue("mcetybdu", loader);
                 if(mcetybdu["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var imgszxrd = GetInputConstructorValue("imgszxrd", loader);
                 if(imgszxrd["original"].length == 0)
                 {
                   Invalid("timer" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_BuxMoney_PayupVideo_code").html())({"mcetybdu": mcetybdu["updated"],"imgszxrd": imgszxrd["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
