_call_function(GoodXevilPaySolver_GXP_ReCaptchav2TakeToken,{ "APIKEY": (<%= ewphmynd %>),"site_url": (<%= bjgydqwb %>),"sitekey": (<%= vvkzddnh %>) })!
<%= variable %> = _result_function()
