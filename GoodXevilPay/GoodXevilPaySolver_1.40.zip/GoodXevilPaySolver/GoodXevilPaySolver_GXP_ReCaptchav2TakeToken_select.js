var ewphmynd = GetInputConstructorValue("ewphmynd", loader);
                 if(ewphmynd["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var bjgydqwb = GetInputConstructorValue("bjgydqwb", loader);
                 if(bjgydqwb["original"].length == 0)
                 {
                   Invalid("site_url" + " is empty");
                   return;
                 }
var vvkzddnh = GetInputConstructorValue("vvkzddnh", loader);
                 if(vvkzddnh["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_ReCaptchav2TakeToken_code").html())({"ewphmynd": ewphmynd["updated"],"bjgydqwb": bjgydqwb["updated"],"vvkzddnh": vvkzddnh["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
