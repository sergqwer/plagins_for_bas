var qzrrhkbk = GetInputConstructorValue("qzrrhkbk", loader);
                 if(qzrrhkbk["original"].length == 0)
                 {
                   Invalid("arrow_id" + " is empty");
                   return;
                 }
var ecccatzr = GetInputConstructorValue("ecccatzr", loader);
                 if(ecccatzr["original"].length == 0)
                 {
                   Invalid("avtoupdate" + " is empty");
                   return;
                 }
var lqyzewgn = GetInputConstructorValue("lqyzewgn", loader);
                 if(lqyzewgn["original"].length == 0)
                 {
                   Invalid("button_id" + " is empty");
                   return;
                 }
var nvotmeuz = GetInputConstructorValue("nvotmeuz", loader);
                 if(nvotmeuz["original"].length == 0)
                 {
                   Invalid("coef" + " is empty");
                   return;
                 }
var tkwfhjkk = GetInputConstructorValue("tkwfhjkk", loader);
                 if(tkwfhjkk["original"].length == 0)
                 {
                   Invalid("image id" + " is empty");
                   return;
                 }
var oxnkwagb = GetInputConstructorValue("oxnkwagb", loader);
                 if(oxnkwagb["original"].length == 0)
                 {
                   Invalid("key" + " is empty");
                   return;
                 }
var awvqiyvq = GetInputConstructorValue("awvqiyvq", loader);
                 if(awvqiyvq["original"].length == 0)
                 {
                   Invalid("pixel_koef" + " is empty");
                   return;
                 }
var rntarlih = GetInputConstructorValue("rntarlih", loader);
                 if(rntarlih["original"].length == 0)
                 {
                   Invalid("reload_id" + " is empty");
                   return;
                 }
var zbgrqcmi = GetInputConstructorValue("zbgrqcmi", loader);
                 if(zbgrqcmi["original"].length == 0)
                 {
                   Invalid("speed" + " is empty");
                   return;
                 }
var ymbrowia = GetInputConstructorValue("ymbrowia", loader);
                 if(ymbrowia["original"].length == 0)
                 {
                   Invalid("type_slide" + " is empty");
                   return;
                 }
var nvqpcmxf = GetInputConstructorValue("nvqpcmxf", loader);
                 if(nvqpcmxf["original"].length == 0)
                 {
                   Invalid("type_swipe" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SliderSolver_code").html())({"qzrrhkbk": qzrrhkbk["updated"],"ecccatzr": ecccatzr["updated"],"lqyzewgn": lqyzewgn["updated"],"nvotmeuz": nvotmeuz["updated"],"tkwfhjkk": tkwfhjkk["updated"],"oxnkwagb": oxnkwagb["updated"],"awvqiyvq": awvqiyvq["updated"],"rntarlih": rntarlih["updated"],"zbgrqcmi": zbgrqcmi["updated"],"ymbrowia": ymbrowia["updated"],"nvqpcmxf": nvqpcmxf["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
