_call_function(GoodXevilPaySolver_GXP_HcaptchaTakeToken,{ "APIKEY": (<%= rwbwkgzl %>),"site_url": (<%= owcauwee %>),"sitekey": (<%= oxzmgbuf %>) })!
<%= variable %> = _result_function()
