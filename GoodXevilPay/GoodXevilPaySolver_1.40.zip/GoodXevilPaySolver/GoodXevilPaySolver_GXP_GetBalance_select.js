var fezzgisi = GetInputConstructorValue("fezzgisi", loader);
                 if(fezzgisi["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_GetBalance_code").html())({"fezzgisi": fezzgisi["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
