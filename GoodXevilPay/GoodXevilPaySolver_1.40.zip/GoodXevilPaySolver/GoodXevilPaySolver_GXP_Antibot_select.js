var kfljcxdy = GetInputConstructorValue("kfljcxdy", loader);
                 if(kfljcxdy["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var bwzfjbjg = GetInputConstructorValue("bwzfjbjg", loader);
                 if(bwzfjbjg["original"].length == 0)
                 {
                   Invalid("mouse" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_Antibot_code").html())({"kfljcxdy": kfljcxdy["updated"],"bwzfjbjg": bwzfjbjg["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
