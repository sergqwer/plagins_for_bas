var jwhdjgru = GetInputConstructorValue("jwhdjgru", loader);
                 if(jwhdjgru["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var voiuujag = GetInputConstructorValue("voiuujag", loader);
                 if(voiuujag["original"].length == 0)
                 {
                   Invalid("site_url" + " is empty");
                   return;
                 }
var xngamghg = GetInputConstructorValue("xngamghg", loader);
                 if(xngamghg["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_HcaptchaTakeToken_code").html())({"jwhdjgru": jwhdjgru["updated"],"voiuujag": voiuujag["updated"],"xngamghg": xngamghg["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
