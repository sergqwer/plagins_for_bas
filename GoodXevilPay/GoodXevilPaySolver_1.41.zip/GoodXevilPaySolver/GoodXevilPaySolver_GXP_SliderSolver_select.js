var qgbayykx = GetInputConstructorValue("qgbayykx", loader);
                 if(qgbayykx["original"].length == 0)
                 {
                   Invalid("arrow_id" + " is empty");
                   return;
                 }
var hzbxjxhx = GetInputConstructorValue("hzbxjxhx", loader);
                 if(hzbxjxhx["original"].length == 0)
                 {
                   Invalid("avtoupdate" + " is empty");
                   return;
                 }
var nwdsawso = GetInputConstructorValue("nwdsawso", loader);
                 if(nwdsawso["original"].length == 0)
                 {
                   Invalid("button_id" + " is empty");
                   return;
                 }
var rmtyiwxq = GetInputConstructorValue("rmtyiwxq", loader);
                 if(rmtyiwxq["original"].length == 0)
                 {
                   Invalid("coef" + " is empty");
                   return;
                 }
var cckdkwhm = GetInputConstructorValue("cckdkwhm", loader);
                 if(cckdkwhm["original"].length == 0)
                 {
                   Invalid("image id" + " is empty");
                   return;
                 }
var cckwuukm = GetInputConstructorValue("cckwuukm", loader);
                 if(cckwuukm["original"].length == 0)
                 {
                   Invalid("key" + " is empty");
                   return;
                 }
var qqzfwcgt = GetInputConstructorValue("qqzfwcgt", loader);
                 if(qqzfwcgt["original"].length == 0)
                 {
                   Invalid("pixel_koef" + " is empty");
                   return;
                 }
var twhjeyoe = GetInputConstructorValue("twhjeyoe", loader);
                 if(twhjeyoe["original"].length == 0)
                 {
                   Invalid("reload_id" + " is empty");
                   return;
                 }
var vimxsjfy = GetInputConstructorValue("vimxsjfy", loader);
                 if(vimxsjfy["original"].length == 0)
                 {
                   Invalid("speed" + " is empty");
                   return;
                 }
var ncyujyym = GetInputConstructorValue("ncyujyym", loader);
                 if(ncyujyym["original"].length == 0)
                 {
                   Invalid("type_slide" + " is empty");
                   return;
                 }
var fssupqcg = GetInputConstructorValue("fssupqcg", loader);
                 if(fssupqcg["original"].length == 0)
                 {
                   Invalid("type_swipe" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SliderSolver_code").html())({"qgbayykx": qgbayykx["updated"],"hzbxjxhx": hzbxjxhx["updated"],"nwdsawso": nwdsawso["updated"],"rmtyiwxq": rmtyiwxq["updated"],"cckdkwhm": cckdkwhm["updated"],"cckwuukm": cckwuukm["updated"],"qqzfwcgt": qqzfwcgt["updated"],"twhjeyoe": twhjeyoe["updated"],"vimxsjfy": vimxsjfy["updated"],"ncyujyym": ncyujyym["updated"],"fssupqcg": fssupqcg["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
