_call_function(GoodXevilPaySolver_GXP_IMAGE_BASE64,{ "APIKEY": (<%= pjymtaej %>),"IMAGE_BASE64": (<%= ogiifsvl %>) })!
<%= variable %> = _result_function()
