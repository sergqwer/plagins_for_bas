var harebaoz = GetInputConstructorValue("harebaoz", loader);
                 if(harebaoz["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var ncjqjecz = GetInputConstructorValue("ncjqjecz", loader);
                 if(ncjqjecz["original"].length == 0)
                 {
                   Invalid("button_capthca" + " is empty");
                   return;
                 }
var bwhobfdz = GetInputConstructorValue("bwhobfdz", loader);
                 if(bwhobfdz["original"].length == 0)
                 {
                   Invalid("captcha_submit" + " is empty");
                   return;
                 }
var pgxqkeqh = GetInputConstructorValue("pgxqkeqh", loader);
                 if(pgxqkeqh["original"].length == 0)
                 {
                   Invalid("foto_captcha" + " is empty");
                   return;
                 }
var ieapeurc = GetInputConstructorValue("ieapeurc", loader);
                 if(ieapeurc["original"].length == 0)
                 {
                   Invalid("reload_captcha" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SolverGeetestIcon_code").html())({"harebaoz": harebaoz["updated"],"ncjqjecz": ncjqjecz["updated"],"bwhobfdz": bwhobfdz["updated"],"pgxqkeqh": pgxqkeqh["updated"],"ieapeurc": ieapeurc["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
