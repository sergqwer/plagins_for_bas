_call_function(GoodXevilPaySolver_GXP_HcaptchaTakeToken,{ "APIKEY": (<%= jwhdjgru %>),"site_url": (<%= voiuujag %>),"sitekey": (<%= xngamghg %>) })!
<%= variable %> = _result_function()
