var jwqajzno = GetInputConstructorValue("jwqajzno", loader);
                 if(jwqajzno["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var zzhykuvu = GetInputConstructorValue("zzhykuvu", loader);
                 if(zzhykuvu["original"].length == 0)
                 {
                   Invalid("mouse" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_Antibot_code").html())({"jwqajzno": jwqajzno["updated"],"zzhykuvu": zzhykuvu["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
