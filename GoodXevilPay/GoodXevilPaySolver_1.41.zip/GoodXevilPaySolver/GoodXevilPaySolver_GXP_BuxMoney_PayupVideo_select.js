var wecydbvd = GetInputConstructorValue("wecydbvd", loader);
                 if(wecydbvd["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var csfzcggb = GetInputConstructorValue("csfzcggb", loader);
                 if(csfzcggb["original"].length == 0)
                 {
                   Invalid("timer" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_BuxMoney_PayupVideo_code").html())({"wecydbvd": wecydbvd["updated"],"csfzcggb": csfzcggb["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
