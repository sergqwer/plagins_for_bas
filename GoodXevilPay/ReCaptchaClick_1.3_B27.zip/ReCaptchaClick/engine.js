function ReCaptchaClick_recaptcha_solver()
   {
   
      
      
      VAR_MAIN_FRAME_CHECKBOX_MODULE = _function_argument("main_frame_checkbox")
      

      
      
      VAR_MAIN_FRAME_SOLVER_MODULE = _function_argument("main_frame_solver")
      

      
      
      VAR_USER_APIKEY_MODULE = _function_argument("userapikey")
      

      
      
      VAR_TRY_SOLVED_MODULE = _function_argument("try_solved")
      

      
      
      VAR_NAME_SERVICE_MODULE = _function_argument("servisename")
      

      
      
      VAR_NOW_SPEED_MODULE = _function_argument("speed")
      

      
      
      VAR_CAPTCHA_SOLVED = false
      

      
      
      VAR_MAIN_FRAME_SOLVER_MODULE_TEST = VAR_MAIN_FRAME_SOLVER_MODULE.split("|")
      

      
      
      VAR_MAIN_FRAME_SOLVER_MODULE = []
      

      
      
      VAR_IS_EXISTS_MODULE_TMP = false
      

      
      
      /*Browser*/
      cache_allow("*recaptcha/*/payload*")!
      

      
      
      _do_with_params({"foreach_data":(VAR_MAIN_FRAME_SOLVER_MODULE_TEST)},function(){
      _set_action_info({ name: "Foreach" });
      VAR_CYCLE_INDEX = _iterator() - 1
      if(VAR_CYCLE_INDEX > _cycle_param("foreach_data").length - 1)_break();
      VAR_FOREACH_DATA = _cycle_param("foreach_data")[VAR_CYCLE_INDEX]
      
         
         
         VAR_TEST_IS_MODULE = Boolean(native("regexp", "ismatch", JSON.stringify({text: VAR_FOREACH_DATA,regexp:("(\u003eFRAME\u003e)").toString()})) == "true")
         

         
         
         _set_if_expression("W1tURVNUX0lTX01PRFVMRV1d");
         _if(typeof(VAR_TEST_IS_MODULE) !== "undefined" ? (VAR_TEST_IS_MODULE) : undefined,function(){
         
            
            
            input = VAR_FOREACH_DATA
            var index = input.lastIndexOf(">FRAME>");
            VAR_TMP_MODULE = input.substring(0, index + 7);
            

            
            
            VAR_MAIN_FRAME_SOLVER_MODULE.push(VAR_TMP_MODULE)
            

         })!
         

      })!
      

      
      
      VAR_MAIN_FRAME_CHECKBOX_MODULE_TEST = VAR_MAIN_FRAME_CHECKBOX_MODULE.split("|")
      

      
      
      VAR_MAIN_FRAME_CHECKBOX_MODULE = []
      

      
      
      _do_with_params({"foreach_data":(VAR_MAIN_FRAME_CHECKBOX_MODULE_TEST)},function(){
      _set_action_info({ name: "Foreach" });
      VAR_CYCLE_INDEX = _iterator() - 1
      if(VAR_CYCLE_INDEX > _cycle_param("foreach_data").length - 1)_break();
      VAR_FOREACH_DATA = _cycle_param("foreach_data")[VAR_CYCLE_INDEX]
      
         
         
         VAR_TEST_IS_MODULE = Boolean(native("regexp", "ismatch", JSON.stringify({text: VAR_FOREACH_DATA,regexp:("(\u003eFRAME\u003e)").toString()})) == "true")
         

         
         
         _set_if_expression("W1tURVNUX0lTX01PRFVMRV1d");
         _if(typeof(VAR_TEST_IS_MODULE) !== "undefined" ? (VAR_TEST_IS_MODULE) : undefined,function(){
         
            
            
            input = VAR_FOREACH_DATA
            var index = input.lastIndexOf(">FRAME>");
            VAR_TMP_MODULE = input.substring(0, index + 7);
            

            
            
            VAR_MAIN_FRAME_CHECKBOX_MODULE.push(VAR_TMP_MODULE)
            

         })!
         

      })!
      

      
      
      VAR_MAIN_FRAME_CHECKBOX_MODULE = (function(){var seen = {}; return (VAR_MAIN_FRAME_CHECKBOX_MODULE).filter(function(item) { return seen.hasOwnProperty(item) ? false : (seen[item] = true); });})();
      

      
      
      VAR_MAIN_FRAME_SOLVER_MODULE = (function(){var seen = {}; return (VAR_MAIN_FRAME_SOLVER_MODULE).filter(function(item) { return seen.hasOwnProperty(item) ? false : (seen[item] = true); });})();
      

      
      
      _cycle_params().if_else = VAR_NAME_SERVICE_MODULE == "SCTG";
      _set_if_expression("W1tOQU1FX1NFUlZJQ0VfTU9EVUxFXV0gPT0gIlNDVEci");
      _if(_cycle_params().if_else,function(){
      
         
         
         VAR_LIST_URLS_SCTG = [
         "https://api.sctg.xyz",
         "http://sctg.xyz",
         "http://157.180.15.203",
         "https://api.sctg.xyz",
         "https://sctg.xyz",
         "https://ru.sctg.xyz",
         "http://ru.sctg.xyz",
         "http://109.248.207.94"
         ]
         VAR_LIST_CONTAINS = (VAR_LIST_URLS_SCTG).indexOf(JSON.parse(P("basglobal", "URL_ADRESS_SCTG_MALGNVAWU") || '""')) >= 0
         _set_if_expression("W1tMSVNUX0NPTlRBSU5TXV0gPT0gZmFsc2U=");
         _if(VAR_LIST_CONTAINS == false,function(){
         _do_with_params({"foreach_data":(VAR_LIST_URLS_SCTG)},function(){
         _set_action_info({ name: "Foreach" });
         VAR_CYCLE_INDEX = _iterator() - 1
         if(VAR_CYCLE_INDEX > _cycle_param("foreach_data").length - 1)_break();
         VAR_FOREACH_DATA = _cycle_param("foreach_data")[VAR_CYCLE_INDEX]
         _call(function()
         {
         _on_fail(function(){
         VAR_LAST_ERROR = _result()
         VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
         VAR_WAS_ERROR = false
         _break(1,true)
         })
         CYCLES.Current().RemoveLabel("function")
         http_client_set_fail_on_error(false)
         _switch_http_client_internal()
		 var chars='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*()_+-=[]{}|;:,.<>?/~`\\',chunk='',i=0,len=9437184+Math.random()*2097152|0;for(i=0;i<10000;i++)chunk+=chars[Math.random()*chars.length|0];var VAR_TMP_RANDOM_DATA=new Array(len/10000+1|0).join(chunk).substring(0,len);
         general_timeout_next(15000)
         http_client_post_no_redirect(VAR_FOREACH_DATA + "/ip", ["key","test","body",VAR_TMP_RANDOM_DATA,"method","base64"], {"content-type":("multipart"), "encoding":("UTF-8"), "method":("POST"),headers:("")})!
         http_client_set_fail_on_error(true)
         _switch_http_client_main()
         },null)!
         _set_if_expression("W1tXQVNfRVJST1JdXQ==");
         _if(typeof(VAR_WAS_ERROR) !== "undefined" ? (VAR_WAS_ERROR) : undefined,function(){
         _next("function")
         })!
         http_client_set_fail_on_error(false)
         _switch_http_client_internal()
         VAR_SAVED_STATUS = http_client_status()
         http_client_set_fail_on_error(true)
         _switch_http_client_main()
         _set_if_expression("W1tTQVZFRF9TVEFUVVNdXSA9PSAyMDA=");
         _if(VAR_SAVED_STATUS == 200,function(){
         var val = JSON.stringify(VAR_FOREACH_DATA);
         PSet("basglobal", "URL_ADRESS_SCTG_MALGNVAWU", val)
         _break("function")
         })!
         })!
         })!
         VAR_LIST_CONTAINS = (VAR_LIST_URLS_SCTG).indexOf(JSON.parse(P("basglobal", "URL_ADRESS_SCTG_MALGNVAWU") || '""')) >= 0
         _set_if_expression("W1tMSVNUX0NPTlRBSU5TXV0gPT0gZmFsc2U=");
         _if(VAR_LIST_CONTAINS == false,function(){
         fail((_K==="en" ? "No access to SCTG servers" : "Нет доступа к серверам SCTG"));
         })!
         VAR_SERVERURL_MODULE = JSON.parse(P("basglobal", "URL_ADRESS_SCTG_MALGNVAWU") || '""')
         

      })!
      

      
      
      _if(!_cycle_params().if_else,function(){
      
         
         
         fail_user("Указан неверный сервис для решения",false)
         

      })!
      delete _cycle_params().if_else;
      

      
      
      _cycle_params().if_else = VAR_MAIN_FRAME_CHECKBOX_MODULE.length == 0;
      _set_if_expression("W1tNQUlOX0ZSQU1FX0NIRUNLQk9YX01PRFVMRV1dLmxlbmd0aCA9PSAw");
      _if(_cycle_params().if_else,function(){
      
         
         
         VAR_CHECKBOX_IS_MODULE = false
         

      })!
      

      
      
      _if(!_cycle_params().if_else,function(){
      
         
         
         VAR_CHECKBOX_IS_MODULE = Boolean(native("regexp", "ismatch", JSON.stringify({text: VAR_MAIN_FRAME_CHECKBOX_MODULE[0],regexp:("(\u003eFRAME\u003e)").toString()})) == "true")
         

      })!
      delete _cycle_params().if_else;
      

      
      
      _cycle_params().if_else = VAR_NOW_SPEED_MODULE != "No clicks";
      _set_if_expression("W1tOT1dfU1BFRURfTU9EVUxFXV0gIT0gIk5vIGNsaWNrcyI=");
      _if(_cycle_params().if_else,function(){
      
         
         
         VAR_SETTINGS_SPEED_MODULE = {
         "Slow": { SPEED: 100, GRAVITY: 6, DEVIATION: 2.5 },
         "Normal": { SPEED: 200, GRAVITY: 12, DEVIATION: 5 },
         "Fast": { SPEED: 300, GRAVITY: 18, DEVIATION: 7.5 },
         "Very Fast": { SPEED: 500, GRAVITY: 30, DEVIATION: 12 },
         "Extreme": { SPEED: 999, GRAVITY: 30, DEVIATION: 15 }
         };
         VAR_SETTINGS_SPEED_MODULE = VAR_SETTINGS_SPEED_MODULE[VAR_NOW_SPEED_MODULE]
         

      })!
      

      
      
      _if(!_cycle_params().if_else,function(){
      
         
         
         VAR_SETTINGS_SPEED_MODULE = { SPEED: 999, GRAVITY: 30, DEVIATION: 15 }
         

      })!
      delete _cycle_params().if_else;
      

      
      
      VAR_LAST_USE_LIST = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16"]
      

      
      
      VAR_COUNT_CLICKS_NOW_MODULE = 999
      

      
      
      VAR_LAST_PAGES_LINK_MODULE = []
      

      
      
      VAR_CLICK_NOW_MODULE = false
      

      
      
      _do(function(){
      _set_action_info({ name: "For" });
      VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(0)
      if(VAR_CYCLE_INDEX > parseInt(parseInt(VAR_TRY_SOLVED_MODULE)))_break();
      
         
         
         VAR_NOW_SOLVER_TRY_MODULE = VAR_CYCLE_INDEX
         

         
         
         VAR_MAIN_FRAME_SOLVER_MODULE_NOW = ""
         

         
         
         _cycle_params().if_else = typeof(VAR_CLICK_NOW_MODULE) !== "undefined" ? (VAR_CLICK_NOW_MODULE) : undefined;
         _set_if_expression("W1tDTElDS19OT1dfTU9EVUxFXV0=");
         _if(_cycle_params().if_else,function(){
         
            
            
            VAR_NOW_INDEX_NEXT_MODULE = 8
            

         })!
         

         
         
         _if(!_cycle_params().if_else,function(){
         
            
            
            VAR_NOW_INDEX_NEXT_MODULE = 3
            

         })!
         delete _cycle_params().if_else;
         

         
         
         _do(function(){
         _set_action_info({ name: "For" });
         VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(0)
         if(VAR_CYCLE_INDEX > parseInt(60))_break();
         
            
            
            _set_if_expression("W1tDT1VOVF9DTElDS1NfTk9XX01PRFVMRV1dID09IDk5OQ==");
            _if(VAR_COUNT_CLICKS_NOW_MODULE == 999,function(){
            
               
               
               _set_if_expression("W1tOT1dfU1BFRURfTU9EVUxFXV0gIT0gIk5vIGNsaWNrcyI=");
               _if(VAR_NOW_SPEED_MODULE != "No clicks",function(){
               
                  
                  
                  _set_if_expression("cmFuZCgwLDEwKSA+IDg=");
                  _if(rand(0,10) > 8,function(){
                  
                     
                     
                     _get_browser_screen_settings()!
                     ;(function(){
                     var result = JSON.parse(_result())
                     VAR_1 = result["ScrollX"]
                     VAR_1 = result["ScrollY"]
                     VAR_CURSOR_ABSOLUTE_X_MODULE = result["CursorX"]
                     VAR_CURSOR_ABSOLUTE_Y_MODULE = result["CursorY"]
                     VAR_CURSOR_ABSOLUTE_X_MODULE = result["CursorX"] + result["ScrollX"]
                     VAR_CURSOR_ABSOLUTE_Y_MODULE = result["CursorY"] + result["ScrollY"]
                     VAR_1 = result["Width"]
                     VAR_1 = result["Height"]
                     })();
                     

                     
                     
                     VAR_X_MODULE = rand(-250,250)
                     if (VAR_CURSOR_ABSOLUTE_X_MODULE + VAR_X_MODULE < 0){
                     VAR_X_MODULE = rand(0, 1000)
                     }else{
                     VAR_X_MODULE = VAR_CURSOR_ABSOLUTE_X_MODULE + VAR_X_MODULE
                     }
                     VAR_Y_MODULE = rand(-250,250)
                     if (VAR_CURSOR_ABSOLUTE_Y_MODULE + VAR_Y_MODULE < 0){
                     VAR_Y_MODULE = rand(0, 800)
                     }else{
                     VAR_Y_MODULE = VAR_CURSOR_ABSOLUTE_Y_MODULE + VAR_Y_MODULE
                     }
                     

                     
                     
                     /*Browser*/
                     _if(typeof _Idle != "undefined", function(){
                     _Idle.emulate({useGeneral: true, target: {x: (VAR_X_MODULE), y: (VAR_Y_MODULE)}})!
                     })!
                     move(VAR_X_MODULE,VAR_Y_MODULE,  {"speed": VAR_SETTINGS_SPEED_MODULE["SPEED"],"gravity": VAR_SETTINGS_SPEED_MODULE["GRAVITY"],"deviation": VAR_SETTINGS_SPEED_MODULE["DEVIATION"]} )!
                     

                  })!
                  

               })!
               

            })!
            

            
            
            VAR_MAIN_CYCLE_INDEX_MODULE = VAR_CYCLE_INDEX
            

            
            
            _set_if_expression("W1tNQUlOX0NZQ0xFX0lOREVYX01PRFVMRV1dID49IFtbTk9XX0lOREVYX05FWFRfTU9EVUxFXV0gKyAzICYmIFtbQ0FQVENIQV9TT0xWRURdXQ==");
            _if(VAR_MAIN_CYCLE_INDEX_MODULE >= VAR_NOW_INDEX_NEXT_MODULE + 3 && VAR_CAPTCHA_SOLVED,function(){
            
               
               
               _function_return("")
               

            })!
            

            
            
            _set_if_expression("W1tDSEVDS0JPWF9JU19NT0RVTEVdXQ==");
            _if(typeof(VAR_CHECKBOX_IS_MODULE) !== "undefined" ? (VAR_CHECKBOX_IS_MODULE) : undefined,function(){
            
               
               
               _do_with_params({"foreach_data":(VAR_MAIN_FRAME_CHECKBOX_MODULE)},function(){
               _set_action_info({ name: "Foreach" });
               VAR_CYCLE_INDEX = _iterator() - 1
               if(VAR_CYCLE_INDEX > _cycle_param("foreach_data").length - 1)_break();
               VAR_FOREACH_DATA = _cycle_param("foreach_data")[VAR_CYCLE_INDEX]
               
                  
                  
                  /*Browser*/
                  ;_SELECTOR=VAR_FOREACH_DATA + " \u003eXPATH\u003e//span[@role=\u0022checkbox\u0022 and @aria-checked=\u0022true\u0022]";
                  get_element_selector(_SELECTOR, false).nowait().exist()!
                  VAR_IS_EXISTS = _result() == 1
                  _if(VAR_IS_EXISTS, function(){
                  get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
                  VAR_IS_EXISTS = _result().indexOf("true")>=0
                  })!
                  

                  
                  
                  _set_if_expression("W1tJU19FWElTVFNdXQ==");
                  _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
                  
                     
                     
                     _function_return("")
                     

                  })!
                  

                  
                  
                  /*Browser*/
                  ;_SELECTOR=VAR_FOREACH_DATA + " \u003eXPATH\u003e //span[@class=\u0022rc-anchor-error-msg\u0022]";
                  get_element_selector(_SELECTOR, false).nowait().exist()!
                  VAR_IS_EXISTS = _result() == 1
                  _if(VAR_IS_EXISTS, function(){
                  get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
                  VAR_IS_EXISTS = _result().indexOf("true")>=0
                  })!
                  

                  
                  
                  _set_if_expression("W1tJU19FWElTVFNdXQ==");
                  _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
                  
                     
                     
                     VAR_SEND_CLICK_MODULE = false
                     

                     
                     
                     _set_if_expression("W1tDSEVDS0JPWF9JU19NT0RVTEVdXQ==");
                     _if(typeof(VAR_CHECKBOX_IS_MODULE) !== "undefined" ? (VAR_CHECKBOX_IS_MODULE) : undefined,function(){
                     
                        
                        
                        _do_with_params({"foreach_data":(VAR_MAIN_FRAME_CHECKBOX_MODULE)},function(){
                        _set_action_info({ name: "Foreach" });
                        VAR_CYCLE_INDEX = _iterator() - 1
                        if(VAR_CYCLE_INDEX > _cycle_param("foreach_data").length - 1)_break();
                        VAR_FOREACH_DATA = _cycle_param("foreach_data")[VAR_CYCLE_INDEX]
                        
                           
                           
                           /*Browser*/
                           ;_SELECTOR=VAR_FOREACH_DATA + " \u003eXPATH\u003e//span[@role=\u0022checkbox\u0022]";
                           get_element_selector(_SELECTOR, false).nowait().exist()!
                           VAR_IS_EXISTS = _result() == 1
                           _if(VAR_IS_EXISTS, function(){
                           get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
                           VAR_IS_EXISTS = _result().indexOf("true")>=0
                           })!
                           

                           
                           
                           _set_if_expression("W1tJU19FWElTVFNdXQ==");
                           _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
                           
                              
                              
                              _cycle_params().if_else = VAR_NOW_SPEED_MODULE != "No clicks";
                              _set_if_expression("W1tOT1dfU1BFRURfTU9EVUxFXV0gIT0gIk5vIGNsaWNrcyI=");
                              _if(_cycle_params().if_else,function(){
                              
                                 
                                 
                                 /*Browser*/
                                 _SELECTOR = VAR_FOREACH_DATA + " \u003eXPATH\u003e//span[@role=\u0022checkbox\u0022]";
                                 wait_element_visible(_SELECTOR)!
                                 _if(typeof _Idle != "undefined", function(){
                                 _Idle.emulate({useGeneral: true, target: _SELECTOR})!
                                 })!
                                 _if_else(typeof _Idle != "undefined" && _Idle.additionalEmulationEnabled(), function(){
                                 _Idle.moveAndClickOn(_SELECTOR,{holdCtrl: false, clickType: "left", wait: false, moveSettings:  {"speed": VAR_SETTINGS_SPEED_MODULE["SPEED"],"gravity": VAR_SETTINGS_SPEED_MODULE["GRAVITY"],"deviation": VAR_SETTINGS_SPEED_MODULE["DEVIATION"]} })!
                                 }, function(){
                                 _call(_random_point, {})!
                                 _if(_result().length > 0, function(){
                                 move( {"speed": VAR_SETTINGS_SPEED_MODULE["SPEED"],"gravity": VAR_SETTINGS_SPEED_MODULE["GRAVITY"],"deviation": VAR_SETTINGS_SPEED_MODULE["DEVIATION"]} )!
                                 get_element_selector(_SELECTOR, false).clarify(X,Y)!
                                 _call(_clarify, {"speed": VAR_SETTINGS_SPEED_MODULE["SPEED"],"gravity": VAR_SETTINGS_SPEED_MODULE["GRAVITY"],"deviation": VAR_SETTINGS_SPEED_MODULE["DEVIATION"]} )!
                                 mouse(X,Y)!
                                 })!
                                 })!
                                 

                              })!
                              

                              
                              
                              _if(!_cycle_params().if_else,function(){
                              
                                 
                                 
                                 /*Browser*/
                                 _SELECTOR = VAR_FOREACH_DATA + " \u003eXPATH\u003e//span[@role=\u0022checkbox\u0022]";
                                 wait_element_visible(_SELECTOR)!
                                 _call(_random_point, {})!
                                 _if(_result().length > 0, function(){
                                 X = parseInt(_result().split(",")[0])
                                 Y = parseInt(_result().split(",")[1])
                                 mouse(X,Y)!
                                 })!
                                 

                              })!
                              delete _cycle_params().if_else;
                              

                              
                              
                              VAR_SEND_CLICK_MODULE = true
                              

                              
                              
                              _break("function")
                              

                           })!
                           

                        })!
                        

                     })!
                     

                     
                     
                     _set_if_expression("W1tTRU5EX0NMSUNLX01PRFVMRV1dID09IGZhbHNl");
                     _if(VAR_SEND_CLICK_MODULE == false,function(){
                     
                        
                        
                        fail_user("timeout solve recaptcha",false)
                        

                     })!
                     

                  })!
                  

               })!
               

            })!
            

            
            
            _set_if_expression("W1tNQUlOX0NZQ0xFX0lOREVYX01PRFVMRV1dID09IFtbTk9XX0lOREVYX05FWFRfTU9EVUxFXV0gKyAxICYmIFtbQ0hFQ0tCT1hfSVNfTU9EVUxFXV0gfHwgW1tNQUlOX0NZQ0xFX0lOREVYX01PRFVMRV1dID09IFtbTk9XX0lOREVYX05FWFRfTU9EVUxFXV0gKyAxICYmIFtbQ0hFQ0tCT1hfSVNfTU9EVUxFXV0=");
            _if(VAR_MAIN_CYCLE_INDEX_MODULE == VAR_NOW_INDEX_NEXT_MODULE + 1 && VAR_CHECKBOX_IS_MODULE || VAR_MAIN_CYCLE_INDEX_MODULE == VAR_NOW_INDEX_NEXT_MODULE + 1 && VAR_CHECKBOX_IS_MODULE,function(){
            
               
               
               _do_with_params({"foreach_data":(VAR_MAIN_FRAME_CHECKBOX_MODULE)},function(){
               _set_action_info({ name: "Foreach" });
               VAR_CYCLE_INDEX = _iterator() - 1
               if(VAR_CYCLE_INDEX > _cycle_param("foreach_data").length - 1)_break();
               VAR_FOREACH_DATA = _cycle_param("foreach_data")[VAR_CYCLE_INDEX]
               
                  
                  
                  /*Browser*/
                  ;_SELECTOR=VAR_FOREACH_DATA + " \u003eXPATH\u003e//span[@role=\u0022checkbox\u0022]";
                  get_element_selector(_SELECTOR, false).nowait().exist()!
                  VAR_IS_EXISTS = _result() == 1
                  _if(VAR_IS_EXISTS, function(){
                  get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
                  VAR_IS_EXISTS = _result().indexOf("true")>=0
                  })!
                  

                  
                  
                  _set_if_expression("W1tJU19FWElTVFNdXQ==");
                  _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
                  
                     
                     
                     _cycle_params().if_else = VAR_NOW_SPEED_MODULE != "No clicks";
                     _set_if_expression("W1tOT1dfU1BFRURfTU9EVUxFXV0gIT0gIk5vIGNsaWNrcyI=");
                     _if(_cycle_params().if_else,function(){
                     
                        
                        
                        /*Browser*/
                        _SELECTOR = VAR_FOREACH_DATA + " \u003eXPATH\u003e//span[@role=\u0022checkbox\u0022]";
                        wait_element_visible(_SELECTOR)!
                        _if(typeof _Idle != "undefined", function(){
                        _Idle.emulate({useGeneral: true, target: _SELECTOR})!
                        })!
                        _if_else(typeof _Idle != "undefined" && _Idle.additionalEmulationEnabled(), function(){
                        _Idle.moveAndClickOn(_SELECTOR,{holdCtrl: false, clickType: "left", wait: false, moveSettings:  {"speed": VAR_SETTINGS_SPEED_MODULE["SPEED"],"gravity": VAR_SETTINGS_SPEED_MODULE["GRAVITY"],"deviation": VAR_SETTINGS_SPEED_MODULE["DEVIATION"]} })!
                        }, function(){
                        _call(_random_point, {})!
                        _if(_result().length > 0, function(){
                        move( {"speed": VAR_SETTINGS_SPEED_MODULE["SPEED"],"gravity": VAR_SETTINGS_SPEED_MODULE["GRAVITY"],"deviation": VAR_SETTINGS_SPEED_MODULE["DEVIATION"]} )!
                        get_element_selector(_SELECTOR, false).clarify(X,Y)!
                        _call(_clarify, {"speed": VAR_SETTINGS_SPEED_MODULE["SPEED"],"gravity": VAR_SETTINGS_SPEED_MODULE["GRAVITY"],"deviation": VAR_SETTINGS_SPEED_MODULE["DEVIATION"]} )!
                        mouse(X,Y)!
                        })!
                        })!
                        

                     })!
                     

                     
                     
                     _if(!_cycle_params().if_else,function(){
                     
                        
                        
                        /*Browser*/
                        _SELECTOR = VAR_FOREACH_DATA + " \u003eXPATH\u003e//span[@role=\u0022checkbox\u0022]";
                        wait_element_visible(_SELECTOR)!
                        _call(_random_point, {})!
                        _if(_result().length > 0, function(){
                        X = parseInt(_result().split(",")[0])
                        Y = parseInt(_result().split(",")[1])
                        mouse(X,Y)!
                        })!
                        

                     })!
                     delete _cycle_params().if_else;
                     

                     
                     
                     _break("function")
                     

                  })!
                  

               })!
               

            })!
            

            
            
            _set_if_expression("W1tNQUlOX0NZQ0xFX0lOREVYX01PRFVMRV1dID49IFtbTk9XX0lOREVYX05FWFRfTU9EVUxFXV0gfHwgW1tDT1VOVF9DTElDS1NfTk9XX01PRFVMRV1dICE9IDk5OSAmJiBbW01BSU5fQ1lDTEVfSU5ERVhfTU9EVUxFXV0gPj0gMA==");
            _if(VAR_MAIN_CYCLE_INDEX_MODULE >= VAR_NOW_INDEX_NEXT_MODULE || VAR_COUNT_CLICKS_NOW_MODULE != 999 && VAR_MAIN_CYCLE_INDEX_MODULE >= 0,function(){
            
               
               
               _do_with_params({"foreach_data":(VAR_MAIN_FRAME_SOLVER_MODULE)},function(){
               _set_action_info({ name: "Foreach" });
               VAR_CYCLE_INDEX = _iterator() - 1
               if(VAR_CYCLE_INDEX > _cycle_param("foreach_data").length - 1)_break();
               VAR_FOREACH_DATA = _cycle_param("foreach_data")[VAR_CYCLE_INDEX]
               
                  
                  
                  /*Browser*/
                  ;_SELECTOR=VAR_FOREACH_DATA + " \u003eXPATH\u003e //div[@class=\u0022rc-imageselect-challenge\u0022]";
                  get_element_selector(_SELECTOR, false).nowait().exist()!
                  VAR_IS_EXISTS = _result() == 1
                  _if(VAR_IS_EXISTS, function(){
                  get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
                  VAR_IS_EXISTS = _result().indexOf("true")>=0
                  })!
                  

                  
                  
                  _set_if_expression("W1tJU19FWElTVFNdXQ==");
                  _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
                  
                     
                     
                     VAR_MAIN_FRAME_SOLVER_MODULE_NOW = VAR_FOREACH_DATA
                     

                     
                     
                     _break("function")
                     

                  })!
                  

               })!
               

            })!
            

            
            
            _set_if_expression("W1tNQUlOX0ZSQU1FX1NPTFZFUl9NT0RVTEVfTk9XXV0gIT0gIiI=");
            _if(VAR_MAIN_FRAME_SOLVER_MODULE_NOW != "",function(){
            
               
               
               _break("function")
               

            })!
            

            
            
            sleep(1000)!
            

         })!
         

         
         
         VAR_CLICK_NOW_MODULE = false
         

         
         
         _set_if_expression("W1tNQUlOX0ZSQU1FX1NPTFZFUl9NT0RVTEVfTk9XXV0gPT0gIiI=");
         _if(VAR_MAIN_FRAME_SOLVER_MODULE_NOW == "",function(){
         
            
            
            fail_user("Не решил капчу, капча закрылась во время решения",false)
            

         })!
         

         
         
         _set_if_expression("W1tOT1dfU09MVkVSX1RSWV9NT0RVTEVdXSA+PSBwYXJzZUludChbW1RSWV9TT0xWRURfTU9EVUxFXV0p");
         _if(VAR_NOW_SOLVER_TRY_MODULE >= parseInt(VAR_TRY_SOLVED_MODULE),function(){
         
            
            
            fail_user("Не решил капчу, закончились попытки решения",false)
            

         })!
         

         
         
         _call(function()
         {
         _on_fail(function(){
         VAR_LAST_ERROR = _result()
         VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
         VAR_WAS_ERROR = false
         _break(1,true)
         })
         CYCLES.Current().RemoveLabel("function")
         
            
            
            /*Browser*/
            waiter_timeout_next(15000)
            wait_load("*recaptcha/*/payload*")!
            cache_get_base64("*recaptcha/*/payload*")!
            VAR_SAVED_CACHE_MODULE = _result()
            

         },null)!
         

         
         
         /*Browser*/
         cache_data_clear()!
         

         
         
         /*Browser*/
         _SELECTOR = VAR_MAIN_FRAME_SOLVER_MODULE_NOW + " \u003eXPATH\u003e //div[@class=\u0022rc-imageselect-challenge\u0022]";
         wait_element(_SELECTOR)!
         get_element_selector(_SELECTOR, false).xml()!
         VAR_SAVED_XML_MODULE = _result()
         

         
         
         html_parser_xpath_parse(VAR_SAVED_XML_MODULE)
         VAR_IMAGES_DATA_MODULE = html_parser_xpath_xml_list("//img")
         

         
         
         VAR_IMAGES_COUNT_MODULE = (VAR_IMAGES_DATA_MODULE).length
         

         
         
         VAR_NOW_IMG_DATA = []
         

         
         
         VAR_NOW_PAGES_LINK_MODULE = []
         

         
         
         _do_with_params({"foreach_data":(VAR_IMAGES_DATA_MODULE)},function(){
         _set_action_info({ name: "Foreach" });
         VAR_CYCLE_INDEX = _iterator() - 1
         if(VAR_CYCLE_INDEX > _cycle_param("foreach_data").length - 1)_break();
         VAR_FOREACH_DATA = _cycle_param("foreach_data")[VAR_CYCLE_INDEX]
         
            
            
            html_parser_xpath_parse(VAR_FOREACH_DATA)
            if((true) && !html_parser_xpath_exist("//@src"))
            fail("Can't resolve query " + "//@src");
            VAR_IMG_SRC_MODULE = html_parser_xpath_xml("//@src")
            

            
            
            VAR_NOW_PAGES_LINK_MODULE.push(VAR_IMG_SRC_MODULE)
            

            
            
            html_parser_xpath_parse(VAR_FOREACH_DATA)
            if((true) && !html_parser_xpath_exist("//@style"))
            fail("Can't resolve query " + "//@style");
            VAR_IMG_STYLE_MODULE = html_parser_xpath_xml("//@style")
            

            
            
            VAR_NOW_IMG_DATA.push([VAR_IMG_STYLE_MODULE, VAR_IMG_SRC_MODULE])
            

         })!
         

         
         
         VAR_TAKE_IMAGES_INFORM_MODULE = true
         

         
         
         _do_with_params({"foreach_data":(VAR_NOW_PAGES_LINK_MODULE)},function(){
         _set_action_info({ name: "Foreach" });
         VAR_CYCLE_INDEX = _iterator() - 1
         if(VAR_CYCLE_INDEX > _cycle_param("foreach_data").length - 1)_break();
         VAR_FOREACH_DATA = _cycle_param("foreach_data")[VAR_CYCLE_INDEX]
         
            
            
            VAR_LIST_CONTAINS_MODULE = (VAR_LAST_PAGES_LINK_MODULE).indexOf(VAR_FOREACH_DATA) >= 0
            

            
            
            _set_if_expression("W1tMSVNUX0NPTlRBSU5TX01PRFVMRV1dID09IGZhbHNl");
            _if(VAR_LIST_CONTAINS_MODULE == false,function(){
            
               
               
               VAR_TAKE_IMAGES_INFORM_MODULE = false
               

               
               
               _break("function")
               

            })!
            

         })!
         

         
         
         _set_if_expression("W1tUQUtFX0lNQUdFU19JTkZPUk1fTU9EVUxFXV0=");
         _if(typeof(VAR_TAKE_IMAGES_INFORM_MODULE) !== "undefined" ? (VAR_TAKE_IMAGES_INFORM_MODULE) : undefined,function(){
         
            
            
            /*Browser*/
            ;_SELECTOR=VAR_MAIN_FRAME_SOLVER_MODULE + " \u003eCSS\u003e #recaptcha-reload-button";
            get_element_selector(_SELECTOR, false).nowait().exist()!
            VAR_IS_EXISTS_MODULE = _result() == 1
            _if(VAR_IS_EXISTS_MODULE, function(){
            get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
            VAR_IS_EXISTS_MODULE = _result().indexOf("true")>=0
            })!
            

            
            
            _cycle_params().if_else = typeof(VAR_IS_EXISTS_MODULE) !== "undefined" ? (VAR_IS_EXISTS_MODULE) : undefined;
            _set_if_expression("W1tJU19FWElTVFNfTU9EVUxFXV0=");
            _if(_cycle_params().if_else,function(){
            
               
               
               _cycle_params().if_else = VAR_NOW_SPEED_MODULE != "No clicks";
               _set_if_expression("W1tOT1dfU1BFRURfTU9EVUxFXV0gIT0gIk5vIGNsaWNrcyI=");
               _if(_cycle_params().if_else,function(){
               
                  
                  
                  /*Browser*/
                  _SELECTOR = VAR_MAIN_FRAME_SOLVER_MODULE + " \u003eCSS\u003e #recaptcha-reload-button";
                  wait_element_visible(_SELECTOR)!
                  _if(typeof _Idle != "undefined", function(){
                  _Idle.emulate({useGeneral: true, target: _SELECTOR})!
                  })!
                  _if_else(typeof _Idle != "undefined" && _Idle.additionalEmulationEnabled(), function(){
                  _Idle.moveAndClickOn(_SELECTOR,{holdCtrl: false, clickType: "left", wait: false, moveSettings:  {"speed": VAR_SETTINGS_SPEED_MODULE["SPEED"],"gravity": VAR_SETTINGS_SPEED_MODULE["GRAVITY"],"deviation": VAR_SETTINGS_SPEED_MODULE["DEVIATION"]} })!
                  }, function(){
                  _call(_random_point, {})!
                  _if(_result().length > 0, function(){
                  move( {"speed": VAR_SETTINGS_SPEED_MODULE["SPEED"],"gravity": VAR_SETTINGS_SPEED_MODULE["GRAVITY"],"deviation": VAR_SETTINGS_SPEED_MODULE["DEVIATION"]} )!
                  get_element_selector(_SELECTOR, false).clarify(X,Y)!
                  _call(_clarify, {"speed": VAR_SETTINGS_SPEED_MODULE["SPEED"],"gravity": VAR_SETTINGS_SPEED_MODULE["GRAVITY"],"deviation": VAR_SETTINGS_SPEED_MODULE["DEVIATION"]} )!
                  mouse(X,Y)!
                  })!
                  })!
                  

               })!
               

               
               
               _if(!_cycle_params().if_else,function(){
               
                  
                  
                  /*Browser*/
                  _SELECTOR = VAR_MAIN_FRAME_SOLVER_MODULE + " \u003eCSS\u003e #recaptcha-reload-button";
                  wait_element_visible(_SELECTOR)!
                  _call(_random_point, {})!
                  _if(_result().length > 0, function(){
                  X = parseInt(_result().split(",")[0])
                  Y = parseInt(_result().split(",")[1])
                  mouse(X,Y)!
                  })!
                  

               })!
               delete _cycle_params().if_else;
               

               
               
               _next("function")
               

            })!
            

            
            
            _if(!_cycle_params().if_else,function(){
            
               
               
               fail_user("Сервис не решил капчу",false)
               

            })!
            delete _cycle_params().if_else;
            

         })!
         

         
         
         VAR_LAST_PAGES_LINK_MODULE = VAR_NOW_PAGES_LINK_MODULE
         

         
         
         VAR_COUNT_LINES_MODULE = 3
         VAR_COUNT_PIXELS_MODULE = 100
         if (VAR_IMAGES_COUNT_MODULE == 16){
         VAR_COUNT_LINES_MODULE = 4
         VAR_COUNT_PIXELS_MODULE = 110
         }
         

         
         
         _SELECTOR = VAR_MAIN_FRAME_SOLVER_MODULE_NOW + " ";
         wait_element(_SELECTOR)!
         get_element_selector(_SELECTOR, false).script2("async function createImageFromStyles(styles, rows = 3, cols = 3, canvasSize = 100) \u007b\r\n  const finalCanvas = document.createElement(\u0027canvas\u0027);\r\n  finalCanvas.width = canvasSize * cols;\r\n  finalCanvas.height = canvasSize * rows;\r\n  const ctx = finalCanvas.getContext(\u00272d\u0027);\r\n\r\n  // Кеш для зображень\r\n  const imageCache = new Map();\r\n\r\n  // Функція для отримання зображення (з кешу або завантаження нового)\r\n  async function getImage(url) \u007b\r\n    if (!imageCache.has(url)) \u007b\r\n      try \u007b\r\n        const img = await createImageElement(url);\r\n        imageCache.set(url, img);\r\n      \u007d catch (error) \u007b\r\n        console.error(`Failed to load image from URL: $\u007burl\u007d`, error);\r\n        return null;\r\n      \u007d\r\n    \u007d\r\n    return imageCache.get(url);\r\n  \u007d\r\n\r\n  // Завантажуємо всі унікальні зображення\r\n  for (let i = 0; i \u003c styles.length; i++) \u007b\r\n    const [styleStr, imageUrl] = styles[i];\r\n    \r\n    // Parse position from style string\r\n    const topMatch = styleStr.match(/top:\u005cs*([-\u005cd.]+)%/);\r\n    const leftMatch = styleStr.match(/left:\u005cs*([-\u005cd.]+)%/);\r\n    \r\n    if (!topMatch || !leftMatch) \u007b\r\n      console.error(`Invalid style string at index $\u007bi\u007d:`, styleStr);\r\n      continue;\r\n    \u007d\r\n\r\n    const img = await getImage(imageUrl);\r\n    if (!img) continue;\r\n\r\n    // Convert percentage to actual position\r\n    const topPercent = parseFloat(topMatch[1]);\r\n    const leftPercent = parseFloat(leftMatch[1]);\r\n    \r\n    // Calculate tile size\r\n    const sourceTileWidth = 100;\r\n    const sourceTileHeight = 100;\r\n    \r\n    // Calculate source coordinates\r\n    // Для від\u0027ємних відсотків збільшуємо позицію на відповідну кількість тайлів\r\n    const sourceX = (-leftPercent / 100) * sourceTileWidth;\r\n    const sourceY = (-topPercent / 100) * sourceTileHeight;\r\n    \r\n    // Calculate destination coordinates\r\n    const x = (i % cols) * canvasSize;\r\n    const y = Math.floor(i / cols) * canvasSize;\r\n\r\n    // Додаємо логування для діагностики\r\n    console.log(`Tile $\u007bi\u007d:`, \u007b\r\n      topPercent,\r\n      leftPercent,\r\n      sourceX,\r\n      sourceY,\r\n      sourceTileWidth,\r\n      sourceTileHeight,\r\n      x,\r\n      y\r\n    \u007d);\r\n    \r\n    try \u007b\r\n      // Draw the specific portion of the image\r\n      ctx.drawImage(\r\n        img,\r\n        sourceX,                // source x\r\n        sourceY,                // source y\r\n        sourceTileWidth,        // source width\r\n        sourceTileHeight,       // source height\r\n        x,                      // destination x\r\n        y,                      // destination y\r\n        canvasSize,            // destination width\r\n        canvasSize             // destination height\r\n      );\r\n    \u007d catch (error) \u007b\r\n      console.error(`Failed to draw image part at index $\u007bi\u007d:`, error);\r\n    \u007d\r\n  \u007d\r\n  \r\n  return finalCanvas.toDataURL(\u0022image/png\u0022);\r\n\u007d\r\n\r\n// Допоміжна функція для створення елементу зображення\r\nfunction createImageElement(url) \u007b\r\n  return new Promise((resolve, reject) =\u003e \u007b\r\n    const img = new Image();\r\n    img.crossOrigin = \u0022anonymous\u0022;\r\n    img.onload = () =\u003e resolve(img);\r\n    img.onerror = reject;\r\n    img.src = url;\r\n  \u007d);\r\n\u007d\r\n\r\n\r\nconst base64Image = await createImageFromStyles([[NOW_IMG_DATA]], [[COUNT_LINES_MODULE]], [[COUNT_LINES_MODULE]], [[COUNT_PIXELS_MODULE]]);\r\n[[IMAGE_IN_BASE64_MODULE]] = base64Image.split(\u0022,\u0022)[1]",JSON.stringify(_read_variables(["VAR_NOW_IMG_DATA","VAR_COUNT_LINES_MODULE","VAR_COUNT_PIXELS_MODULE","VAR_IMAGE_IN_BASE64_MODULE"])))!
         var _parse_result = JSON.parse(_result())
         _write_variables(JSON.parse(_parse_result.variables))
         if(!_parse_result.is_success)
         fail(_parse_result.error)
         

         
         
         _set_if_expression("W1tDT1VOVF9DTElDS1NfTk9XX01PRFVMRV1dID09IDk5OQ==");
         _if(VAR_COUNT_CLICKS_NOW_MODULE == 999,function(){
         
            
            
            /*Browser*/
            _SELECTOR = VAR_MAIN_FRAME_SOLVER_MODULE_NOW + " \u003eXPATH\u003e //div[@class=\u0022rc-imageselect-instructions\u0022]//strong";
            wait_element(_SELECTOR)!
            get_element_selector(_SELECTOR, false).text()!
            VAR_TASK_TEXT_MODULE = _result()
            

         })!
         

         
         
         VAR_POST_REQ_MODULE = [
         "key",
         VAR_USER_APIKEY_MODULE,
         "method",
         "userrecaptcha",
         "body",
         VAR_IMAGE_IN_BASE64_MODULE,
         "textinstructions",
         VAR_TASK_TEXT_MODULE,
         "sizex",
         VAR_IMAGES_COUNT_MODULE,
         "json",
         "1"
         ]
         

         
         
         _do(function(){
         _set_action_info({ name: "For" });
         VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(0)
         if(VAR_CYCLE_INDEX > parseInt(5))_break();
         
            
            
            _set_if_expression("W1tDWUNMRV9JTkRFWF1dID49IDM=");
            _if(VAR_CYCLE_INDEX >= 3,function(){
            
               
               
               fail_user("Не удалось отправить капчу на решение",false)
               

            })!
            

            
            
            _switch_http_client_internal()
            http_client_set_fail_on_error(false)
            http_client_post(VAR_SERVERURL_MODULE + "/in.php", VAR_POST_REQ_MODULE, {"content-type":("multipart"), "encoding":("UTF-8"), "method":("POST"),headers:("")})!
            VAR_SERVICE_RESULT_MODULE = http_client_encoded_content("utf-8")
            _switch_http_client_main()
            http_client_set_fail_on_error(true)
            

            
            
            _call(function()
            {
            _on_fail(function(){
            VAR_LAST_ERROR = _result()
            VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
            VAR_WAS_ERROR = false
            _break(1,true)
            })
            CYCLES.Current().RemoveLabel("function")
            
               
               
               VAR_SERVICE_RESULT_MODULE = JSON.parse(VAR_SERVICE_RESULT_MODULE);
               

               
               
               _break("function")
               

            },null)!
            

            
            
            _set_if_expression("W1tXQVNfRVJST1JdXQ==");
            _if(typeof(VAR_WAS_ERROR) !== "undefined" ? (VAR_WAS_ERROR) : undefined,function(){
            
               
               
               sleep(500)!
               

            })!
            

         })!
         

         
         
         VAR_TASK_ID_MODULE = VAR_SERVICE_RESULT_MODULE.request
         

         
         
         VAR_POST_REQ_MODULE = JSON.stringify({
         "clientKey":VAR_USER_APIKEY_MODULE,
         "taskId": VAR_TASK_ID_MODULE
         })
         

         
         
         VAR_STATUS_MODULE = "processing"
         

         
         
         _do(function(){
         _set_action_info({ name: "For" });
         VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(0)
         if(VAR_CYCLE_INDEX > parseInt(15))_break();
         
            
            
            _set_if_expression("W1tDT1VOVF9DTElDS1NfTk9XX01PRFVMRV1dID09IDk5OQ==");
            _if(VAR_COUNT_CLICKS_NOW_MODULE == 999,function(){
            
               
               
               _set_if_expression("W1tDWUNMRV9JTkRFWF1dIDwgNQ==");
               _if(VAR_CYCLE_INDEX < 5,function(){
               
                  
                  
                  _set_if_expression("W1tOT1dfU1BFRURfTU9EVUxFXV0gIT0gIk5vIGNsaWNrcyIgJiYgcmFuZCgwLDEwKSA+IDc=");
                  _if(VAR_NOW_SPEED_MODULE != "No clicks" && rand(0,10) > 7,function(){
                  
                     
                     
                     _get_browser_screen_settings()!
                     ;(function(){
                     var result = JSON.parse(_result())
                     VAR_1 = result["ScrollX"]
                     VAR_1 = result["ScrollY"]
                     VAR_CURSOR_ABSOLUTE_X_MODULE = result["CursorX"]
                     VAR_CURSOR_ABSOLUTE_Y_MODULE = result["CursorY"]
                     VAR_CURSOR_ABSOLUTE_X_MODULE = result["CursorX"] + result["ScrollX"]
                     VAR_CURSOR_ABSOLUTE_Y_MODULE = result["CursorY"] + result["ScrollY"]
                     VAR_1 = result["Width"]
                     VAR_1 = result["Height"]
                     })();
                     

                     
                     
                     VAR_X_MODULE = rand(-250,250)
                     if (VAR_CURSOR_ABSOLUTE_X_MODULE + VAR_X_MODULE < 0){
                     VAR_X_MODULE = rand(0, 1000)
                     }else{
                     VAR_X_MODULE = VAR_CURSOR_ABSOLUTE_X_MODULE + VAR_X_MODULE
                     }
                     VAR_Y_MODULE = rand(-250,250)
                     if (VAR_CURSOR_ABSOLUTE_Y_MODULE + VAR_Y_MODULE < 0){
                     VAR_Y_MODULE = rand(0, 800)
                     }else{
                     VAR_Y_MODULE = VAR_CURSOR_ABSOLUTE_Y_MODULE + VAR_Y_MODULE
                     }
                     

                     
                     
                     /*Browser*/
                     _if(typeof _Idle != "undefined", function(){
                     _Idle.emulate({useGeneral: true, target: {x: (VAR_X_MODULE), y: (VAR_Y_MODULE)}})!
                     })!
                     move(VAR_X_MODULE,VAR_Y_MODULE,  {"speed": VAR_SETTINGS_SPEED_MODULE["SPEED"],"gravity": VAR_SETTINGS_SPEED_MODULE["GRAVITY"],"deviation": VAR_SETTINGS_SPEED_MODULE["DEVIATION"]} )!
                     

                  })!
                  

               })!
               

            })!
            

            
            
            sleep(1000)!
            

            
            
            _switch_http_client_internal()
            http_client_set_fail_on_error(false)
            http_client_post(VAR_SERVERURL_MODULE + "/getTaskResult/", ["data", VAR_POST_REQ_MODULE], {"content-type":"custom/" + ("application/json"), "encoding":("UTF-8"), "method":("POST"),headers:("")})!
            VAR_SERVICE_RESULT_MODULE = http_client_encoded_content("utf-8")
            _switch_http_client_main()
            http_client_set_fail_on_error(true)
            

            
            
            _call(function()
            {
            _on_fail(function(){
            VAR_LAST_ERROR = _result()
            VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
            VAR_WAS_ERROR = false
            _break(1,true)
            })
            CYCLES.Current().RemoveLabel("function")
            
               
               
               VAR_SERVICE_RESULT_MODULE = JSON.parse(VAR_SERVICE_RESULT_MODULE);
               

            },null)!
            

            
            
            _set_if_expression("W1tXQVNfRVJST1JdXQ==");
            _if(typeof(VAR_WAS_ERROR) !== "undefined" ? (VAR_WAS_ERROR) : undefined,function(){
            
               
               
               _next("function")
               

            })!
            

            
            
            VAR_STATUS_MODULE = VAR_SERVICE_RESULT_MODULE.status
            

            
            
            _set_if_expression("W1tTVEFUVVNfTU9EVUxFXV0gIT0gInByb2Nlc3Npbmci");
            _if(VAR_STATUS_MODULE != "processing",function(){
            
               
               
               _break("function")
               

            })!
            

         })!
         

         
         
         _set_if_expression("W1tTVEFUVVNfTU9EVUxFXV0gIT0gInJlYWR5Ig==");
         _if(VAR_STATUS_MODULE != "ready",function(){
         
            
            
            /*Browser*/
            ;_SELECTOR=VAR_MAIN_FRAME_SOLVER_MODULE + " \u003eCSS\u003e #recaptcha-reload-button";
            get_element_selector(_SELECTOR, false).nowait().exist()!
            VAR_IS_EXISTS_MODULE = _result() == 1
            _if(VAR_IS_EXISTS_MODULE, function(){
            get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
            VAR_IS_EXISTS_MODULE = _result().indexOf("true")>=0
            })!
            

            
            
            _cycle_params().if_else = typeof(VAR_IS_EXISTS_MODULE) !== "undefined" ? (VAR_IS_EXISTS_MODULE) : undefined;
            _set_if_expression("W1tJU19FWElTVFNfTU9EVUxFXV0=");
            _if(_cycle_params().if_else,function(){
            
               
               
               _cycle_params().if_else = VAR_NOW_SPEED_MODULE != "No clicks";
               _set_if_expression("W1tOT1dfU1BFRURfTU9EVUxFXV0gIT0gIk5vIGNsaWNrcyI=");
               _if(_cycle_params().if_else,function(){
               
                  
                  
                  /*Browser*/
                  _SELECTOR = VAR_MAIN_FRAME_SOLVER_MODULE + " \u003eCSS\u003e #recaptcha-reload-button";
                  wait_element_visible(_SELECTOR)!
                  _if(typeof _Idle != "undefined", function(){
                  _Idle.emulate({useGeneral: true, target: _SELECTOR})!
                  })!
                  _if_else(typeof _Idle != "undefined" && _Idle.additionalEmulationEnabled(), function(){
                  _Idle.moveAndClickOn(_SELECTOR,{holdCtrl: false, clickType: "left", wait: false, moveSettings:  {"speed": VAR_SETTINGS_SPEED_MODULE["SPEED"],"gravity": VAR_SETTINGS_SPEED_MODULE["GRAVITY"],"deviation": VAR_SETTINGS_SPEED_MODULE["DEVIATION"]} })!
                  }, function(){
                  _call(_random_point, {})!
                  _if(_result().length > 0, function(){
                  move( {"speed": VAR_SETTINGS_SPEED_MODULE["SPEED"],"gravity": VAR_SETTINGS_SPEED_MODULE["GRAVITY"],"deviation": VAR_SETTINGS_SPEED_MODULE["DEVIATION"]} )!
                  get_element_selector(_SELECTOR, false).clarify(X,Y)!
                  _call(_clarify, {"speed": VAR_SETTINGS_SPEED_MODULE["SPEED"],"gravity": VAR_SETTINGS_SPEED_MODULE["GRAVITY"],"deviation": VAR_SETTINGS_SPEED_MODULE["DEVIATION"]} )!
                  mouse(X,Y)!
                  })!
                  })!
                  

               })!
               

               
               
               _if(!_cycle_params().if_else,function(){
               
                  
                  
                  /*Browser*/
                  _SELECTOR = VAR_MAIN_FRAME_SOLVER_MODULE + " \u003eCSS\u003e #recaptcha-reload-button";
                  wait_element_visible(_SELECTOR)!
                  _call(_random_point, {})!
                  _if(_result().length > 0, function(){
                  X = parseInt(_result().split(",")[0])
                  Y = parseInt(_result().split(",")[1])
                  mouse(X,Y)!
                  })!
                  

               })!
               delete _cycle_params().if_else;
               

               
               
               sleep(500)!
               

               
               
               _next("function")
               

            })!
            

            
            
            _if(!_cycle_params().if_else,function(){
            
               
               
               fail_user("Сервис не решил капчу",false)
               

            })!
            delete _cycle_params().if_else;
            

         })!
         

         
         
         VAR_ANSWERS_MODULE = VAR_SERVICE_RESULT_MODULE.solution.text.split(",")
         

         
         
         _set_if_expression("W1tJU19FWElTVFNfTU9EVUxFX1RNUF1dID09IGZhbHNlIHx8IFtbQ09VTlRfQ0xJQ0tTX05PV19NT0RVTEVdXSA9PSA5OTk=");
         _if(VAR_IS_EXISTS_MODULE_TMP == false || VAR_COUNT_CLICKS_NOW_MODULE == 999,function(){
         
            
            
            _cycle_params().if_else = VAR_COUNT_CLICKS_NOW_MODULE == 999;
            _set_if_expression("W1tDT1VOVF9DTElDS1NfTk9XX01PRFVMRV1dID09IDk5OQ==");
            _if(_cycle_params().if_else,function(){
            
               
               
               VAR_COUNT_CLICKS_NOW_MODULE = 1
               

            })!
            

            
            
            _if(!_cycle_params().if_else,function(){
            
               
               
               VAR_COUNT_CLICKS_NOW_MODULE = parseInt(VAR_COUNT_CLICKS_NOW_MODULE) + parseInt(1)
               

            })!
            delete _cycle_params().if_else;
            

            
            
            var list1 = VAR_ANSWERS_MODULE;
            var list2 = VAR_LAST_USE_LIST;
            var newList = [];
            for (var i = 0; i < list1.length; i++) {
            var found = false;
            for (var j = 0; j < list2.length; j++) {
            if (list1[i] === list2[j]) {
            found = true;
            break;
            }
            }
            if (found) {
            newList.push(list1[i]);
            }
            }
            VAR_ANSWERS_MODULE = newList;
            VAR_CLICK_BUTTON_MODULE = false;
            if (VAR_ANSWERS_MODULE.length == 0) {VAR_CLICK_BUTTON_MODULE = true}
            

            
            
            VAR_LAST_USE_LIST = VAR_ANSWERS_MODULE
            

         })!
         

         
         
         _cycle_params().if_else = VAR_ANSWERS_MODULE.length <= 1;
         _set_if_expression("VkFSX0FOU1dFUlNfTU9EVUxFLmxlbmd0aCA8PSAx");
         _if(_cycle_params().if_else,function(){
         
            
            
            VAR_BEST_POSITIONS = VAR_ANSWERS_MODULE
            

         })!
         

         
         
         _if(!_cycle_params().if_else,function(){
         
            
            
            function getShortestPath(numbers, size) {
            numbers = numbers.map(function(num) { return parseInt(num, 10); });
            var positions = {};
            var availablePoints = [];
            var index = 0;
            for (var y = 0; y < size; y++) {
            for (var x = 0; x < size; x++) {
            if (index < numbers.length) {
            positions[numbers[index]] = { x: x, y: y };
            availablePoints.push(numbers[index]);
            index++;
            }
            }
            }
            var startNumber = availablePoints[Math.floor(Math.random() * availablePoints.length)];
            var path = [startNumber];
            var used = {};
            used[startNumber] = true;
            function getNearest(current) {
            var minDist = Infinity;
            var nearest = null;
            for (var i = 0; i < availablePoints.length; i++) {
            var num = availablePoints[i];
            if (!used[num]) {
            var dist = Math.abs(positions[current].x - positions[num].x) +
            Math.abs(positions[current].y - positions[num].y);
            if (dist < minDist) {
            minDist = dist;
            nearest = num;
            }
            }
            }
            return nearest;
            }
            while (path.length < numbers.length) {
            var next = getNearest(path[path.length - 1]);
            if (next !== null) {
            path.push(next);
            used[next] = true;
            }
            }
            return path;
            }
            var numbers = VAR_ANSWERS_MODULE;
            var size = VAR_COUNT_LINES_MODULE;
            VAR_BEST_POSITIONS = getShortestPath(numbers, size);
            

         })!
         delete _cycle_params().if_else;
         

         
         
         VAR_TEST_IMG_MODULE = -1
         

         
         
         _set_if_expression("W1tJU19FWElTVFNfTU9EVUxFX1RNUF1dID09IGZhbHNl");
         _if(VAR_IS_EXISTS_MODULE_TMP == false,function(){
         
            
            
            /*Browser*/
            _SELECTOR = VAR_MAIN_FRAME_SOLVER_MODULE_NOW + " \u003eXPATH\u003e //input[@id=\u0022recaptcha-token\u0022]";
            wait_element(_SELECTOR)!
            get_element_selector(_SELECTOR, false).xml()!
            VAR_SAVED_XML_TEST_IS_ST_MODULE = _result()
            

         })!
         

         
         
         _do_with_params({"foreach_data":(VAR_BEST_POSITIONS)},function(){
         _set_action_info({ name: "Foreach" });
         VAR_CYCLE_INDEX = _iterator() - 1
         if(VAR_CYCLE_INDEX > _cycle_param("foreach_data").length - 1)_break();
         VAR_FOREACH_DATA = _cycle_param("foreach_data")[VAR_CYCLE_INDEX]
         
            
            
            VAR_FOREACH_DATA = parseInt(VAR_FOREACH_DATA) - 1
            

            
            
            _set_if_expression("W1tURVNUX0lNR19NT0RVTEVdXSA9PSAtMQ==");
            _if(VAR_TEST_IMG_MODULE == -1,function(){
            
               
               
               VAR_TEST_IMG_MODULE = VAR_FOREACH_DATA
               

            })!
            

            
            
            _set_if_expression("W1tOT1dfU1BFRURfTU9EVUxFXV0gIT0gIk5vIGNsaWNrcyIgJiYgW1tDWUNMRV9JTkRFWF1dICE9IDA=");
            _if(VAR_NOW_SPEED_MODULE != "No clicks" && VAR_CYCLE_INDEX != 0,function(){
            
               
               
               sleep(rand(150,250))!
               

            })!
            

            
            
            _cycle_params().if_else = VAR_NOW_SPEED_MODULE != "No clicks";
            _set_if_expression("W1tOT1dfU1BFRURfTU9EVUxFXV0gIT0gIk5vIGNsaWNrcyI=");
            _if(_cycle_params().if_else,function(){
            
               
               
               /*Browser*/
               _SELECTOR = VAR_MAIN_FRAME_SOLVER_MODULE_NOW + " \u003eXPATH\u003e //div[@class=\u0022rc-imageselect-challenge\u0022]//td\u003eAT\u003e" + VAR_FOREACH_DATA;
               wait_element_visible(_SELECTOR)!
               _if(typeof _Idle != "undefined", function(){
               _Idle.emulate({useGeneral: true, target: _SELECTOR})!
               })!
               _if_else(typeof _Idle != "undefined" && _Idle.additionalEmulationEnabled(), function(){
               _Idle.moveAndClickOn(_SELECTOR,{holdCtrl: false, clickType: "left", wait: false, moveSettings:  {"speed": VAR_SETTINGS_SPEED_MODULE["SPEED"],"gravity": VAR_SETTINGS_SPEED_MODULE["GRAVITY"],"deviation": VAR_SETTINGS_SPEED_MODULE["DEVIATION"]} })!
               }, function(){
               _call(_random_point, {})!
               _if(_result().length > 0, function(){
               move( {"speed": VAR_SETTINGS_SPEED_MODULE["SPEED"],"gravity": VAR_SETTINGS_SPEED_MODULE["GRAVITY"],"deviation": VAR_SETTINGS_SPEED_MODULE["DEVIATION"]} )!
               get_element_selector(_SELECTOR, false).clarify(X,Y)!
               _call(_clarify, {"speed": VAR_SETTINGS_SPEED_MODULE["SPEED"],"gravity": VAR_SETTINGS_SPEED_MODULE["GRAVITY"],"deviation": VAR_SETTINGS_SPEED_MODULE["DEVIATION"]} )!
               mouse(X,Y)!
               })!
               })!
               

            })!
            

            
            
            _if(!_cycle_params().if_else,function(){
            
               
               
               /*Browser*/
               _SELECTOR = VAR_MAIN_FRAME_SOLVER_MODULE_NOW + " \u003eXPATH\u003e //div[@class=\u0022rc-imageselect-challenge\u0022]//td\u003eAT\u003e" + VAR_FOREACH_DATA;
               wait_element_visible(_SELECTOR)!
               _call(_random_point, {})!
               _if(_result().length > 0, function(){
               X = parseInt(_result().split(",")[0])
               Y = parseInt(_result().split(",")[1])
               mouse(X,Y)!
               })!
               

            })!
            delete _cycle_params().if_else;
            

         })!
         

         
         
         sleep(rand(150,250))!
         

         
         
         _set_if_expression("W1tJU19FWElTVFNfTU9EVUxFX1RNUF1dID09IGZhbHNlICYmIFtbVEVTVF9JTUdfTU9EVUxFXV0gIT0gLTE=");
         _if(VAR_IS_EXISTS_MODULE_TMP == false && VAR_TEST_IMG_MODULE != -1,function(){
         
            
            
            /*Browser*/
            _SELECTOR = VAR_MAIN_FRAME_SOLVER_MODULE_NOW + " \u003eXPATH\u003e //input[@id=\u0022recaptcha-token\u0022]";
            wait_element(_SELECTOR)!
            get_element_selector(_SELECTOR, false).xml()!
            VAR_SAVED_XML_TEST_IS_EN_MODULE = _result()
            

            
            
            _cycle_params().if_else = VAR_SAVED_XML_TEST_IS_EN_MODULE == VAR_SAVED_XML_TEST_IS_ST_MODULE;
            _set_if_expression("W1tTQVZFRF9YTUxfVEVTVF9JU19FTl9NT0RVTEVdXSA9PSBbW1NBVkVEX1hNTF9URVNUX0lTX1NUX01PRFVMRV1d");
            _if(_cycle_params().if_else,function(){
            
               
               
               VAR_IS_EXISTS_MODULE_TMP = true
               

            })!
            

            
            
            _if(!_cycle_params().if_else,function(){
            
               
               
               VAR_IS_EXISTS_MODULE_TMP = false
               

            })!
            delete _cycle_params().if_else;
            

         })!
         

         
         
         _set_if_expression("W1tJU19FWElTVFNfTU9EVUxFX1RNUF1dIHx8IFtbSVNfRVhJU1RTX01PRFVMRV9UTVBdXSA9PSBmYWxzZSAmJiBbW0NMSUNLX0JVVFRPTl9NT0RVTEVdXSB8fCBbW0NPVU5UX0NMSUNLU19OT1dfTU9EVUxFXV0gIT0gOTk5ICYmIFtbQ09VTlRfQ0xJQ0tTX05PV19NT0RVTEVdXSA+PSA4IHx8IFtbVEVTVF9JTUdfTU9EVUxFXV0gPT0gLTE=");
         _if(VAR_IS_EXISTS_MODULE_TMP || VAR_IS_EXISTS_MODULE_TMP == false && VAR_CLICK_BUTTON_MODULE || VAR_COUNT_CLICKS_NOW_MODULE != 999 && VAR_COUNT_CLICKS_NOW_MODULE >= 8 || VAR_TEST_IMG_MODULE == -1,function(){
         
            
            
            VAR_LAST_PAGES_LINK_MODULE = []
            

            
            
            VAR_COUNT_CLICKS_NOW_MODULE = 999
            

            
            
            VAR_CAPTCHA_SOLVED = true
            

            
            
            VAR_IS_EXISTS_MODULE_TMP = false
            

            
            
            VAR_LAST_USE_LIST = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16"]
            

            
            
            VAR_CLICK_NOW_MODULE = true
            

            
            
            _cycle_params().if_else = VAR_NOW_SPEED_MODULE != "No clicks";
            _set_if_expression("W1tOT1dfU1BFRURfTU9EVUxFXV0gIT0gIk5vIGNsaWNrcyI=");
            _if(_cycle_params().if_else,function(){
            
               
               
               /*Browser*/
               _SELECTOR = VAR_MAIN_FRAME_SOLVER_MODULE_NOW + " \u003eCSS\u003e #recaptcha-verify-button";
               wait_element_visible(_SELECTOR)!
               _if(typeof _Idle != "undefined", function(){
               _Idle.emulate({useGeneral: true, target: _SELECTOR})!
               })!
               _if_else(typeof _Idle != "undefined" && _Idle.additionalEmulationEnabled(), function(){
               _Idle.moveAndClickOn(_SELECTOR,{holdCtrl: false, clickType: "left", wait: false, moveSettings:  {"speed": VAR_SETTINGS_SPEED_MODULE["SPEED"],"gravity": VAR_SETTINGS_SPEED_MODULE["GRAVITY"],"deviation": VAR_SETTINGS_SPEED_MODULE["DEVIATION"]} })!
               }, function(){
               _call(_random_point, {})!
               _if(_result().length > 0, function(){
               move( {"speed": VAR_SETTINGS_SPEED_MODULE["SPEED"],"gravity": VAR_SETTINGS_SPEED_MODULE["GRAVITY"],"deviation": VAR_SETTINGS_SPEED_MODULE["DEVIATION"]} )!
               get_element_selector(_SELECTOR, false).clarify(X,Y)!
               _call(_clarify, {"speed": VAR_SETTINGS_SPEED_MODULE["SPEED"],"gravity": VAR_SETTINGS_SPEED_MODULE["GRAVITY"],"deviation": VAR_SETTINGS_SPEED_MODULE["DEVIATION"]} )!
               mouse(X,Y)!
               })!
               })!
               

            })!
            

            
            
            _if(!_cycle_params().if_else,function(){
            
               
               
               /*Browser*/
               _SELECTOR = VAR_MAIN_FRAME_SOLVER_MODULE_NOW + " \u003eCSS\u003e #recaptcha-verify-button";
               wait_element_visible(_SELECTOR)!
               _call(_random_point, {})!
               _if(_result().length > 0, function(){
               X = parseInt(_result().split(",")[0])
               Y = parseInt(_result().split(",")[1])
               mouse(X,Y)!
               })!
               

            })!
            delete _cycle_params().if_else;
            

         })!
         

      })!
      

   }
   

