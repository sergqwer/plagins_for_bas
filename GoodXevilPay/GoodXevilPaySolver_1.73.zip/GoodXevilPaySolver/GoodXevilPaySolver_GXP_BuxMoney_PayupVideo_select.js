var wrperzhc = GetInputConstructorValue("wrperzhc", loader);
                 if(wrperzhc["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var rskksyak = GetInputConstructorValue("rskksyak", loader);
                 if(rskksyak["original"].length == 0)
                 {
                   Invalid("timer" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_BuxMoney_PayupVideo_code").html())({"wrperzhc": wrperzhc["updated"],"rskksyak": rskksyak["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
