var betmkxeh = GetInputConstructorValue("betmkxeh", loader);
                 if(betmkxeh["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var wzlzgkkf = GetInputConstructorValue("wzlzgkkf", loader);
                 if(wzlzgkkf["original"].length == 0)
                 {
                   Invalid("arab_fix" + " is empty");
                   return;
                 }
var btmhslzi = GetInputConstructorValue("btmhslzi", loader);
                 if(btmhslzi["original"].length == 0)
                 {
                   Invalid("captcha_submit" + " is empty");
                   return;
                 }
var qcrmqtdc = GetInputConstructorValue("qcrmqtdc", loader);
                 if(qcrmqtdc["original"].length == 0)
                 {
                   Invalid("foto_captcha" + " is empty");
                   return;
                 }
var cnwmlqjy = GetInputConstructorValue("cnwmlqjy", loader);
                 if(cnwmlqjy["original"].length == 0)
                 {
                   Invalid("pixel_coef" + " is empty");
                   return;
                 }
var pzeltooi = GetInputConstructorValue("pzeltooi", loader);
                 if(pzeltooi["original"].length == 0)
                 {
                   Invalid("reload_captcha" + " is empty");
                   return;
                 }
var rvgrmtjr = GetInputConstructorValue("rvgrmtjr", loader);
                 if(rvgrmtjr["original"].length == 0)
                 {
                   Invalid("type_data" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SolverGeetestIcon_code").html())({"betmkxeh": betmkxeh["updated"],"wzlzgkkf": wzlzgkkf["updated"],"btmhslzi": btmhslzi["updated"],"qcrmqtdc": qcrmqtdc["updated"],"cnwmlqjy": cnwmlqjy["updated"],"pzeltooi": pzeltooi["updated"],"rvgrmtjr": rvgrmtjr["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
