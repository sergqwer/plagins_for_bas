var uawkrvwx = GetInputConstructorValue("uawkrvwx", loader);
                 if(uawkrvwx["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var wqajjsfr = GetInputConstructorValue("wqajjsfr", loader);
                 if(wqajjsfr["original"].length == 0)
                 {
                   Invalid("site_url" + " is empty");
                   return;
                 }
var sqorwawn = GetInputConstructorValue("sqorwawn", loader);
                 if(sqorwawn["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_TurnstileToken_code").html())({"uawkrvwx": uawkrvwx["updated"],"wqajjsfr": wqajjsfr["updated"],"sqorwawn": sqorwawn["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
