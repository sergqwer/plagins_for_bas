var usezmosp = GetInputConstructorValue("usezmosp", loader);
                 if(usezmosp["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var fijqjbmz = GetInputConstructorValue("fijqjbmz", loader);
                 if(fijqjbmz["original"].length == 0)
                 {
                   Invalid("CaptchaSelector" + " is empty");
                   return;
                 }
var wwkivtqo = GetInputConstructorValue("wwkivtqo", loader);
                 if(wwkivtqo["original"].length == 0)
                 {
                   Invalid("InvisibleCaptcha" + " is empty");
                   return;
                 }
var rwbsutto = GetInputConstructorValue("rwbsutto", loader);
                 if(rwbsutto["original"].length == 0)
                 {
                   Invalid("TrySolve" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_hCaptcha_Click_code").html())({"usezmosp": usezmosp["updated"],"fijqjbmz": fijqjbmz["updated"],"wwkivtqo": wwkivtqo["updated"],"rwbsutto": rwbsutto["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
