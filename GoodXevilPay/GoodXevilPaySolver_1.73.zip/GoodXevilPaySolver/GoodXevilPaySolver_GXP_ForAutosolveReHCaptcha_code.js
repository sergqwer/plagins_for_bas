_call_function(GoodXevilPaySolver_GXP_ForAutosolveReHCaptcha,{ "hCaptcha_USE": (<%= yazknheg %>),"ReCaptcha_USE": (<%= mwbpicgc %>) })!
