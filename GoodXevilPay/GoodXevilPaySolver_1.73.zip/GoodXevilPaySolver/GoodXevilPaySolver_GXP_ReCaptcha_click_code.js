_call_function(GoodXevilPaySolver_GXP_ReCaptcha_click,{ "apikey": (<%= uodyssdz %>),"CaptchaSelector": (<%= sopvdrlu %>),"InvisibleCaptcha": (<%= ifslhvik %>),"TrySolve": (<%= mnztkgpn %>) })!
