var xofyzmar = GetInputConstructorValue("xofyzmar", loader);
                 if(xofyzmar["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var ectrjfti = GetInputConstructorValue("ectrjfti", loader);
                 if(ectrjfti["original"].length == 0)
                 {
                   Invalid("cut_url" + " is empty");
                   return;
                 }
var ahdmpnfh = GetInputConstructorValue("ahdmpnfh", loader);
                 if(ahdmpnfh["original"].length == 0)
                 {
                   Invalid("enterprise" + " is empty");
                   return;
                 }
var lcwltnfs = GetInputConstructorValue("lcwltnfs", loader);
                 if(lcwltnfs["original"].length == 0)
                 {
                   Invalid("index" + " is empty");
                   return;
                 }
var hygcujnt = GetInputConstructorValue("hygcujnt", loader);
                 if(hygcujnt["original"].length == 0)
                 {
                   Invalid("invisible" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_ReCaptcha_Bypass_No_Exten_code").html())({"xofyzmar": xofyzmar["updated"],"ectrjfti": ectrjfti["updated"],"ahdmpnfh": ahdmpnfh["updated"],"lcwltnfs": lcwltnfs["updated"],"hygcujnt": hygcujnt["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
