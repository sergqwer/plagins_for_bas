<div class="container-fluid">
<%= _.template($('#input_constructor').html())({id:"dbkpybfe", description:"APIKEY", default_selector: "string", disable_expression:true, disable_int:true, value_string: "", help: {description: "apikey с сервиса https://t.me/Xevil_check_bot\n\napikey from https://t.me/Xevil_check_bot"} }) %>
<%= _.template($('#input_constructor').html())({id:"ivsypzcs", description:"IMAGE_BASE64", default_selector: "string", disable_int:true, value_string: "", help: {description: "Изображение в формате base64\n\nImage in base64 format"} }) %>
<%= _.template($('#variable_constructor').html())({id:"Save", description:"Result", default_variable: "RESULT", help: {description: "Ответ от сервиса решения капчи\nResponse from the captcha solution service"}}) %>
</div>
<div class="tooltipinternal">
<div class="tr tooltip-paragraph-first-fold">Решает изображения в формате base64</div>
<div class="tr tooltip-paragraph-last-fold">Resolves images in base64 format</div>
</div>
<%= _.template($('#back').html())({action:"executeandadd", visible:true}) %>
