_call_function(GoodXevilPaySolver_GXP_HcaptchaTakeToken,{ "APIKEY": (<%= qxfqzxwi %>),"site_url": (<%= mhxxiniw %>),"sitekey": (<%= mpmfybzy %>) })!
<%= variable %> = _result_function()
