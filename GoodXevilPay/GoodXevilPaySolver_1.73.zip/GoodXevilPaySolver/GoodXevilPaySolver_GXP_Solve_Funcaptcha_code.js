_call_function(GoodXevilPaySolver_GXP_Solve_Funcaptcha,{ "APIKey": (<%= txfzkftu %>),"CaptchaNumber": (<%= wsibfswb %>),"CaptchaSelector": (<%= jrnniqfl %>),"MaxLimitTask": (<%= zydhfnnz %>) })!
