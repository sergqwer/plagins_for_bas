_call_function(GoodXevilPaySolver_GXP_AutoBypassCloudFlare,{ "custom_button": (<%= gxacqltz %>),"max_time": (<%= hucqwdok %>),"whait_element": (<%= rbalvozk %>) })!
