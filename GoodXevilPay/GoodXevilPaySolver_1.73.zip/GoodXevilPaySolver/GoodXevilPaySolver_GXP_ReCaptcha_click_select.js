var uodyssdz = GetInputConstructorValue("uodyssdz", loader);
                 if(uodyssdz["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var sopvdrlu = GetInputConstructorValue("sopvdrlu", loader);
                 if(sopvdrlu["original"].length == 0)
                 {
                   Invalid("CaptchaSelector" + " is empty");
                   return;
                 }
var ifslhvik = GetInputConstructorValue("ifslhvik", loader);
                 if(ifslhvik["original"].length == 0)
                 {
                   Invalid("InvisibleCaptcha" + " is empty");
                   return;
                 }
var mnztkgpn = GetInputConstructorValue("mnztkgpn", loader);
                 if(mnztkgpn["original"].length == 0)
                 {
                   Invalid("TrySolve" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_ReCaptcha_click_code").html())({"uodyssdz": uodyssdz["updated"],"sopvdrlu": sopvdrlu["updated"],"ifslhvik": ifslhvik["updated"],"mnztkgpn": mnztkgpn["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
