<div class="container-fluid">
<%= _.template($('#input_constructor').html())({id:"yazknheg", description:"hCaptcha_USE", default_selector: "int", disable_string:true, value_number: 1, min_number:-999999, max_number:999999, help: {description: "Добавить в модуль решения hCaptcha?\n1 - Использовать\n0 - Не использовать\n\nAdd to the hCaptcha solution module?\n1 - Use\n0 - Do not use"} }) %>
<%= _.template($('#input_constructor').html())({id:"mwbpicgc", description:"ReCaptcha_USE", default_selector: "int", disable_string:true, value_number: 1, min_number:-999999, max_number:999999, help: {description: "Добавить в модуль решения ReCaptcha?\n1 - Использовать\n0 - Не использовать\n\nAdd to the ReCaptcha solution module?\n1 - Use\n0 - Do not use"} }) %>
</div>
<div class="tooltipinternal">
<div class="tr tooltip-paragraph-first-fold">Для работы надо после установки этого кубика установить действие "Настройки браузера" с меню "Браузер", и в пункте "Расширения" дописать строку</div>
<div class="tr tooltip-paragraph-fold">[[PROJECT_DIRECTORY]]/CaptchaAutoSolver</div>
<div class="tr tooltip-paragraph-fold">Используется для автоматического решения hCaptcha/reCaptcha</div>
<div class="tr tooltip-paragraph-fold">Эта функция установит расширение, которое будет подгружать js нужный для автоматического определения sitekey и callback</div>
<div class="tr tooltip-paragraph-fold">To work, after installing this cube you need to set the "Browser Settings" action from the "Browser" menu, and in the "Extensions" item add the line</div>
<div class="tr tooltip-paragraph-fold">[[PROJECT_DIRECTORY]]/CaptchaAutoSolver</div>
<div class="tr tooltip-paragraph-fold">Used to automatically solve hCaptcha/reCaptcha</div>
<div class="tr tooltip-paragraph-last-fold">This function will install an extension that will load the js needed for automatic sitekey and callback detection</div>
</div>
<%= _.template($('#back').html())({action:"executeandadd", visible:true}) %>
