_call_function(GoodXevilPaySolver_GXP_ReCaptchav2TakeToken,{ "APIKEY": (<%= rsabtbbz %>),"site_url": (<%= uqtaonfy %>),"sitekey": (<%= rkzienjb %>) })!
<%= variable %> = _result_function()
