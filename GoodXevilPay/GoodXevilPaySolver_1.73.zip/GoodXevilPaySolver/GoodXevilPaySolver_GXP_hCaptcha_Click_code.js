_call_function(GoodXevilPaySolver_GXP_hCaptcha_Click,{ "apikey": (<%= usezmosp %>),"CaptchaSelector": (<%= fijqjbmz %>),"InvisibleCaptcha": (<%= wwkivtqo %>),"TrySolve": (<%= rwbsutto %>) })!
