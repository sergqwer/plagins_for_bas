var wfczsnws = GetInputConstructorValue("wfczsnws", loader);
                 if(wfczsnws["original"].length == 0)
                 {
                   Invalid("arrow_id" + " is empty");
                   return;
                 }
var etmojfyj = GetInputConstructorValue("etmojfyj", loader);
                 if(etmojfyj["original"].length == 0)
                 {
                   Invalid("Attempts" + " is empty");
                   return;
                 }
var vwbrivbh = GetInputConstructorValue("vwbrivbh", loader);
                 if(vwbrivbh["original"].length == 0)
                 {
                   Invalid("avtoupdate" + " is empty");
                   return;
                 }
var kyyzvieg = GetInputConstructorValue("kyyzvieg", loader);
                 if(kyyzvieg["original"].length == 0)
                 {
                   Invalid("button_id" + " is empty");
                   return;
                 }
var cbqhqbto = GetInputConstructorValue("cbqhqbto", loader);
                 if(cbqhqbto["original"].length == 0)
                 {
                   Invalid("coef" + " is empty");
                   return;
                 }
var fusabpud = GetInputConstructorValue("fusabpud", loader);
                 if(fusabpud["original"].length == 0)
                 {
                   Invalid("image id" + " is empty");
                   return;
                 }
var tnosbnyg = GetInputConstructorValue("tnosbnyg", loader);
                 if(tnosbnyg["original"].length == 0)
                 {
                   Invalid("key" + " is empty");
                   return;
                 }
var xcrpflsp = GetInputConstructorValue("xcrpflsp", loader);
                 if(xcrpflsp["original"].length == 0)
                 {
                   Invalid("pixel_koef" + " is empty");
                   return;
                 }
var dxqhtvxc = GetInputConstructorValue("dxqhtvxc", loader);
                 if(dxqhtvxc["original"].length == 0)
                 {
                   Invalid("reload_id" + " is empty");
                   return;
                 }
var nfnhjzom = GetInputConstructorValue("nfnhjzom", loader);
                 if(nfnhjzom["original"].length == 0)
                 {
                   Invalid("slider_type" + " is empty");
                   return;
                 }
var nmtultpy = GetInputConstructorValue("nmtultpy", loader);
                 if(nmtultpy["original"].length == 0)
                 {
                   Invalid("speed" + " is empty");
                   return;
                 }
var wglztqpk = GetInputConstructorValue("wglztqpk", loader);
                 if(wglztqpk["original"].length == 0)
                 {
                   Invalid("type_slide" + " is empty");
                   return;
                 }
var gldwewcs = GetInputConstructorValue("gldwewcs", loader);
                 if(gldwewcs["original"].length == 0)
                 {
                   Invalid("type_swipe" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SliderSolver_code").html())({"wfczsnws": wfczsnws["updated"],"etmojfyj": etmojfyj["updated"],"vwbrivbh": vwbrivbh["updated"],"kyyzvieg": kyyzvieg["updated"],"cbqhqbto": cbqhqbto["updated"],"fusabpud": fusabpud["updated"],"tnosbnyg": tnosbnyg["updated"],"xcrpflsp": xcrpflsp["updated"],"dxqhtvxc": dxqhtvxc["updated"],"nfnhjzom": nfnhjzom["updated"],"nmtultpy": nmtultpy["updated"],"wglztqpk": wglztqpk["updated"],"gldwewcs": gldwewcs["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
