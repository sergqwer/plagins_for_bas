var gxacqltz = GetInputConstructorValue("gxacqltz", loader);
                 if(gxacqltz["original"].length == 0)
                 {
                   Invalid("custom_button" + " is empty");
                   return;
                 }
var hucqwdok = GetInputConstructorValue("hucqwdok", loader);
                 if(hucqwdok["original"].length == 0)
                 {
                   Invalid("max_time" + " is empty");
                   return;
                 }
var rbalvozk = GetInputConstructorValue("rbalvozk", loader);
                 if(rbalvozk["original"].length == 0)
                 {
                   Invalid("whait_element" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_AutoBypassCloudFlare_code").html())({"gxacqltz": gxacqltz["updated"],"hucqwdok": hucqwdok["updated"],"rbalvozk": rbalvozk["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
