var lxjthjcl = GetInputConstructorValue("lxjthjcl", loader);
                 if(lxjthjcl["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var rzcnutsd = GetInputConstructorValue("rzcnutsd", loader);
                 if(rzcnutsd["original"].length == 0)
                 {
                   Invalid("CaptchaSelector" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_Yandex_code").html())({"lxjthjcl": lxjthjcl["updated"],"rzcnutsd": rzcnutsd["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
