var txfzkftu = GetInputConstructorValue("txfzkftu", loader);
                 if(txfzkftu["original"].length == 0)
                 {
                   Invalid("APIKey" + " is empty");
                   return;
                 }
var wsibfswb = GetInputConstructorValue("wsibfswb", loader);
                 if(wsibfswb["original"].length == 0)
                 {
                   Invalid("CaptchaNumber" + " is empty");
                   return;
                 }
var jrnniqfl = GetInputConstructorValue("jrnniqfl", loader);
                 if(jrnniqfl["original"].length == 0)
                 {
                   Invalid("CaptchaSelector" + " is empty");
                   return;
                 }
var zydhfnnz = GetInputConstructorValue("zydhfnnz", loader);
                 if(zydhfnnz["original"].length == 0)
                 {
                   Invalid("MaxLimitTask" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_Solve_Funcaptcha_code").html())({"txfzkftu": txfzkftu["updated"],"wsibfswb": wsibfswb["updated"],"jrnniqfl": jrnniqfl["updated"],"zydhfnnz": zydhfnnz["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
