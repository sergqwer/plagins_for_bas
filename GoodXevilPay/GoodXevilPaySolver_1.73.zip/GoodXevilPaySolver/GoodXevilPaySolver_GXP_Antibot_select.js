var hnpnbesd = GetInputConstructorValue("hnpnbesd", loader);
                 if(hnpnbesd["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var bmgsjrgl = GetInputConstructorValue("bmgsjrgl", loader);
                 if(bmgsjrgl["original"].length == 0)
                 {
                   Invalid("mouse" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_Antibot_code").html())({"hnpnbesd": hnpnbesd["updated"],"bmgsjrgl": bmgsjrgl["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
