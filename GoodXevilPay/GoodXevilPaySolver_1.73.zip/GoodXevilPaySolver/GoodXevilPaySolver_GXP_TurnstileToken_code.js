_call_function(GoodXevilPaySolver_GXP_TurnstileToken,{ "APIKEY": (<%= uawkrvwx %>),"site_url": (<%= wqajjsfr %>),"sitekey": (<%= sqorwawn %>) })!
