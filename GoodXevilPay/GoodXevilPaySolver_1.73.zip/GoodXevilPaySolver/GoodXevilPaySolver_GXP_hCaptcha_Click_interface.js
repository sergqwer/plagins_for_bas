<div class="container-fluid">
<%= _.template($('#input_constructor').html())({id:"usezmosp", description:"apikey", default_selector: "string", disable_int:true, value_string: "", help: {description: "apikey с сервиса https://t.me/Xevil_check_bot\n\napikey from https://t.me/Xevil_check_bot"} }) %>
<%= _.template($('#input_constructor').html())({id:"fijqjbmz", description:"CaptchaSelector", default_selector: "string", disable_int:true, value_string: ">CSS> iframe[src*='checkbox']>FRAME> >CSS> #checkbox", help: {description: "Селектор hCaptcha\n\nThe hCaptcha selector"} }) %>
<%= _.template($('#input_constructor').html())({id:"wwkivtqo", description:"InvisibleCaptcha", default_selector: "expression", disable_int:true, disable_string:true, value_string: "false", help: {description: "Это невидимая капча? false - нет true - да Если капча невидимая, для ее решения надо разрешить кеш\n\nIs it an invisible captcha? false - no true - yes If the captcha is invisible, you must enable cache to solve it."} }) %>
<%= _.template($('#input_constructor').html())({id:"rwbsutto", description:"TrySolve", default_selector: "int", disable_string:true, value_number: 20, min_number:-999999, max_number:999999, help: {description: "Количество попыток решения капчи\n\nNumber of attempts to solve captcha"} }) %>
</div>
<div class="tooltipinternal">
<div class="tr tooltip-paragraph-first-fold">Решает кликами hCaptcha через сервис https://t.me/Xevil_check_bot, оплачивается каждое изображение</div>
<div class="tr tooltip-paragraph-last-fold">Resolves by hCaptcha clicks through the service https://t.me/Xevil_check_bot, paid per image</div>
</div>
<%= _.template($('#back').html())({action:"executeandadd", visible:true}) %>
