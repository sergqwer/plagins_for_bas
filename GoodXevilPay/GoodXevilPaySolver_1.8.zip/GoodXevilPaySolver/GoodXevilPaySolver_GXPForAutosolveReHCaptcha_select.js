var hevvflhh = GetInputConstructorValue("hevvflhh", loader);
                 if(hevvflhh["original"].length == 0)
                 {
                   Invalid("AutoSettings" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXPForAutosolveReHCaptcha_code").html())({"hevvflhh": hevvflhh["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
