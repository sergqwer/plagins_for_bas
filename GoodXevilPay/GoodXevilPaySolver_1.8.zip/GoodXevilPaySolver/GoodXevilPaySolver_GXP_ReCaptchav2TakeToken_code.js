_call_function(GoodXevilPaySolver_GXP_ReCaptchav2TakeToken,{ "APIKEY": (<%= ebgavadv %>),"site_url": (<%= rssgbgve %>),"sitekey": (<%= iyiabbzq %>) })!
<%= variable %> = _result_function()
