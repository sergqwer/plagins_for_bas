_call_function(GoodXevilPaySolver_GXPReCaptchav2TakeToken,{ "APIKEY": (<%= ghkgmhkw %>),"site_url": (<%= menycdez %>),"sitekey": (<%= pcketvxw %>) })!
<%= variable %> = _result_function()
