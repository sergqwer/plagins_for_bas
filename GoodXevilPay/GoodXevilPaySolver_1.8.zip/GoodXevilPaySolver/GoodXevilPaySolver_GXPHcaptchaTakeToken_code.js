_call_function(GoodXevilPaySolver_GXPHcaptchaTakeToken,{ "APIKEY": (<%= brnquadi %>),"site_url": (<%= rubdchts %>),"sitekey": (<%= voalpehm %>) })!
<%= variable %> = _result_function()
