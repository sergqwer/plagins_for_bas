var qywkbqjl = GetInputConstructorValue("qywkbqjl", loader);
                 if(qywkbqjl["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var cwywsvhi = GetInputConstructorValue("cwywsvhi", loader);
                 if(cwywsvhi["original"].length == 0)
                 {
                   Invalid("IMAGE_BASE64" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_IMAGE_BASE64_code").html())({"qywkbqjl": qywkbqjl["updated"],"cwywsvhi": cwywsvhi["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
