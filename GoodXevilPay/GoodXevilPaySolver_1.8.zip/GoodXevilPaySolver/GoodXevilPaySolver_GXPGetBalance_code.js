_call_function(GoodXevilPaySolver_GXPGetBalance,{ "APIKEY": (<%= qczskgpj %>) })!
<%= variable %> = _result_function()
