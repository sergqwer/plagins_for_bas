var ludzcdtt = GetInputConstructorValue("ludzcdtt", loader);
                 if(ludzcdtt["original"].length == 0)
                 {
                   Invalid("arrow_id" + " is empty");
                   return;
                 }
var zblqbktu = GetInputConstructorValue("zblqbktu", loader);
                 if(zblqbktu["original"].length == 0)
                 {
                   Invalid("avtoupdate" + " is empty");
                   return;
                 }
var fiitqdic = GetInputConstructorValue("fiitqdic", loader);
                 if(fiitqdic["original"].length == 0)
                 {
                   Invalid("button_id" + " is empty");
                   return;
                 }
var lblbpwuo = GetInputConstructorValue("lblbpwuo", loader);
                 if(lblbpwuo["original"].length == 0)
                 {
                   Invalid("coef" + " is empty");
                   return;
                 }
var luozwkqx = GetInputConstructorValue("luozwkqx", loader);
                 if(luozwkqx["original"].length == 0)
                 {
                   Invalid("image id" + " is empty");
                   return;
                 }
var rvhnnajs = GetInputConstructorValue("rvhnnajs", loader);
                 if(rvhnnajs["original"].length == 0)
                 {
                   Invalid("key" + " is empty");
                   return;
                 }
var cxdodpkf = GetInputConstructorValue("cxdodpkf", loader);
                 if(cxdodpkf["original"].length == 0)
                 {
                   Invalid("pixel_koef" + " is empty");
                   return;
                 }
var uqqodqcb = GetInputConstructorValue("uqqodqcb", loader);
                 if(uqqodqcb["original"].length == 0)
                 {
                   Invalid("reload_id" + " is empty");
                   return;
                 }
var dwaokqzh = GetInputConstructorValue("dwaokqzh", loader);
                 if(dwaokqzh["original"].length == 0)
                 {
                   Invalid("speed" + " is empty");
                   return;
                 }
var gixhqzzn = GetInputConstructorValue("gixhqzzn", loader);
                 if(gixhqzzn["original"].length == 0)
                 {
                   Invalid("type_slide" + " is empty");
                   return;
                 }
var bxpahgnf = GetInputConstructorValue("bxpahgnf", loader);
                 if(bxpahgnf["original"].length == 0)
                 {
                   Invalid("type_swipe" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SliderSolver_code").html())({"ludzcdtt": ludzcdtt["updated"],"zblqbktu": zblqbktu["updated"],"fiitqdic": fiitqdic["updated"],"lblbpwuo": lblbpwuo["updated"],"luozwkqx": luozwkqx["updated"],"rvhnnajs": rvhnnajs["updated"],"cxdodpkf": cxdodpkf["updated"],"uqqodqcb": uqqodqcb["updated"],"dwaokqzh": dwaokqzh["updated"],"gixhqzzn": gixhqzzn["updated"],"bxpahgnf": bxpahgnf["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
