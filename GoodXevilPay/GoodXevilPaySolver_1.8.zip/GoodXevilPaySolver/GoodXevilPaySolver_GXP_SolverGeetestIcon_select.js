var vyeelbys = GetInputConstructorValue("vyeelbys", loader);
                 if(vyeelbys["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var cunnuzzp = GetInputConstructorValue("cunnuzzp", loader);
                 if(cunnuzzp["original"].length == 0)
                 {
                   Invalid("button_capthca" + " is empty");
                   return;
                 }
var dbznqlir = GetInputConstructorValue("dbznqlir", loader);
                 if(dbznqlir["original"].length == 0)
                 {
                   Invalid("captcha_submit" + " is empty");
                   return;
                 }
var zuccgadi = GetInputConstructorValue("zuccgadi", loader);
                 if(zuccgadi["original"].length == 0)
                 {
                   Invalid("foto_captcha" + " is empty");
                   return;
                 }
var wupupnzc = GetInputConstructorValue("wupupnzc", loader);
                 if(wupupnzc["original"].length == 0)
                 {
                   Invalid("reload_captcha" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SolverGeetestIcon_code").html())({"vyeelbys": vyeelbys["updated"],"cunnuzzp": cunnuzzp["updated"],"dbznqlir": dbznqlir["updated"],"zuccgadi": zuccgadi["updated"],"wupupnzc": wupupnzc["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
