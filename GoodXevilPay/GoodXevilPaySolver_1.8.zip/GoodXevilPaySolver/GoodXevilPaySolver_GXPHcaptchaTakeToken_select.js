var brnquadi = GetInputConstructorValue("brnquadi", loader);
                 if(brnquadi["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var rubdchts = GetInputConstructorValue("rubdchts", loader);
                 if(rubdchts["original"].length == 0)
                 {
                   Invalid("site_url" + " is empty");
                   return;
                 }
var voalpehm = GetInputConstructorValue("voalpehm", loader);
                 if(voalpehm["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXPHcaptchaTakeToken_code").html())({"brnquadi": brnquadi["updated"],"rubdchts": rubdchts["updated"],"voalpehm": voalpehm["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
