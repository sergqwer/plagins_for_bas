var ghkgmhkw = GetInputConstructorValue("ghkgmhkw", loader);
                 if(ghkgmhkw["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var menycdez = GetInputConstructorValue("menycdez", loader);
                 if(menycdez["original"].length == 0)
                 {
                   Invalid("site_url" + " is empty");
                   return;
                 }
var pcketvxw = GetInputConstructorValue("pcketvxw", loader);
                 if(pcketvxw["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXPReCaptchav2TakeToken_code").html())({"ghkgmhkw": ghkgmhkw["updated"],"menycdez": menycdez["updated"],"pcketvxw": pcketvxw["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
