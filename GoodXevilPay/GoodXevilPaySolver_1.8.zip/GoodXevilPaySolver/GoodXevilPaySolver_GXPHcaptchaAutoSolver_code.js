_call_function(GoodXevilPaySolver_GXPHcaptchaAutoSolver,{ "apikey": (<%= hphhmasg %>) })!
