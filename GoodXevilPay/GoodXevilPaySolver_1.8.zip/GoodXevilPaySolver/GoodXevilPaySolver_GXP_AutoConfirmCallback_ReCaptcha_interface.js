<div class="container-fluid">
<%= _.template($('#input_constructor').html())({id:"teilngmy", description:"token", default_selector: "string", disable_int:true, value_string: "", help: {description: "Токен recaptcha полученый, например, через CaptchaCustom"} }) %>
</div>
<div class="tooltipinternal">
<div class="tr tooltip-paragraph-first-fold">Данная функция автоматически применит ваш токен recaptcha, для работы требуется функция GXP_ForAutosolveReHCaptcha</div>
</div>
<%= _.template($('#back').html())({action:"executeandadd", visible:true}) %>
