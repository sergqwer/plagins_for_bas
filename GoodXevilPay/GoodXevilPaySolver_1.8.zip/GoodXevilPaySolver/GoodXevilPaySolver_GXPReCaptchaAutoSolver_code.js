_call_function(GoodXevilPaySolver_GXPReCaptchaAutoSolver,{ "apikey": (<%= jzufffgo %>) })!
