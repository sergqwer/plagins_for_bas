var exkeosgy = GetInputConstructorValue("exkeosgy", loader);
                 if(exkeosgy["original"].length == 0)
                 {
                   Invalid("token" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_AutoConfirmCallback_Hcaptcha_code").html())({"exkeosgy": exkeosgy["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
