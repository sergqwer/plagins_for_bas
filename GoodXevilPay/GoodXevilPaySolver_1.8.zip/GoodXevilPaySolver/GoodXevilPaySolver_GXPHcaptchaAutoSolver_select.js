var hphhmasg = GetInputConstructorValue("hphhmasg", loader);
                 if(hphhmasg["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXPHcaptchaAutoSolver_code").html())({"hphhmasg": hphhmasg["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
