_call_function(GoodXevilPaySolver_GXP_HcaptchaTakeToken,{ "APIKEY": (<%= lvrkdflt %>),"site_url": (<%= jpmjtmml %>),"sitekey": (<%= mgisssyv %>) })!
<%= variable %> = _result_function()
