_call_function(GoodXevilPaySolver_GXP_Antibot,{ "apikey": (<%= dkksxgfy %>),"mouse": (<%= oantgywj %>) })!
