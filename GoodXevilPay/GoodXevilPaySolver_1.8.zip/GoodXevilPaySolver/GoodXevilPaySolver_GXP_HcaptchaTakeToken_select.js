var lvrkdflt = GetInputConstructorValue("lvrkdflt", loader);
                 if(lvrkdflt["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var jpmjtmml = GetInputConstructorValue("jpmjtmml", loader);
                 if(jpmjtmml["original"].length == 0)
                 {
                   Invalid("site_url" + " is empty");
                   return;
                 }
var mgisssyv = GetInputConstructorValue("mgisssyv", loader);
                 if(mgisssyv["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_HcaptchaTakeToken_code").html())({"lvrkdflt": lvrkdflt["updated"],"jpmjtmml": jpmjtmml["updated"],"mgisssyv": mgisssyv["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
