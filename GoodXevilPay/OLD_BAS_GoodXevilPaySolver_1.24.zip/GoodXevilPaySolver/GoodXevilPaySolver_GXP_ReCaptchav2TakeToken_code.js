_call_function(GoodXevilPaySolver_GXP_ReCaptchav2TakeToken,{ "APIKEY": (<%= wihzudea %>),"site_url": (<%= qbyvtgie %>),"sitekey": (<%= msoggfpa %>) })!
<%= variable %> = _result_function()
