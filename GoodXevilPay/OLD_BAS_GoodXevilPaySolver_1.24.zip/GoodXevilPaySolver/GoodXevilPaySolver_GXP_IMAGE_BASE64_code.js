_call_function(GoodXevilPaySolver_GXP_IMAGE_BASE64,{ "APIKEY": (<%= kdgpgzay %>),"IMAGE_BASE64": (<%= jrjbkjgu %>) })!
<%= variable %> = _result_function()
