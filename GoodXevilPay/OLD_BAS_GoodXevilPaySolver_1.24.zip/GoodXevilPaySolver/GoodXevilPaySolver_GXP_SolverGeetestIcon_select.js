var oqlonidn = GetInputConstructorValue("oqlonidn", loader);
                 if(oqlonidn["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var wgrbijnw = GetInputConstructorValue("wgrbijnw", loader);
                 if(wgrbijnw["original"].length == 0)
                 {
                   Invalid("button_capthca" + " is empty");
                   return;
                 }
var pkcfutwf = GetInputConstructorValue("pkcfutwf", loader);
                 if(pkcfutwf["original"].length == 0)
                 {
                   Invalid("captcha_submit" + " is empty");
                   return;
                 }
var wbydshbo = GetInputConstructorValue("wbydshbo", loader);
                 if(wbydshbo["original"].length == 0)
                 {
                   Invalid("foto_captcha" + " is empty");
                   return;
                 }
var ystxdnrn = GetInputConstructorValue("ystxdnrn", loader);
                 if(ystxdnrn["original"].length == 0)
                 {
                   Invalid("reload_captcha" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SolverGeetestIcon_code").html())({"oqlonidn": oqlonidn["updated"],"wgrbijnw": wgrbijnw["updated"],"pkcfutwf": pkcfutwf["updated"],"wbydshbo": wbydshbo["updated"],"ystxdnrn": ystxdnrn["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
