_call_function(GoodXevilPaySolver_GXP_HcaptchaTakeToken,{ "APIKEY": (<%= kgoxlkdd %>),"site_url": (<%= nscazdtn %>),"sitekey": (<%= rypmvhul %>) })!
<%= variable %> = _result_function()
