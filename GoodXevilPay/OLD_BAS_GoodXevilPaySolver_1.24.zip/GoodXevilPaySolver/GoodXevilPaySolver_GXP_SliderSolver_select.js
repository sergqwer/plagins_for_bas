var shhrinfc = GetInputConstructorValue("shhrinfc", loader);
                 if(shhrinfc["original"].length == 0)
                 {
                   Invalid("arrow_id" + " is empty");
                   return;
                 }
var roksgegl = GetInputConstructorValue("roksgegl", loader);
                 if(roksgegl["original"].length == 0)
                 {
                   Invalid("avtoupdate" + " is empty");
                   return;
                 }
var lrtkgcoy = GetInputConstructorValue("lrtkgcoy", loader);
                 if(lrtkgcoy["original"].length == 0)
                 {
                   Invalid("button_id" + " is empty");
                   return;
                 }
var qqtfnzcu = GetInputConstructorValue("qqtfnzcu", loader);
                 if(qqtfnzcu["original"].length == 0)
                 {
                   Invalid("coef" + " is empty");
                   return;
                 }
var xesfmmru = GetInputConstructorValue("xesfmmru", loader);
                 if(xesfmmru["original"].length == 0)
                 {
                   Invalid("image id" + " is empty");
                   return;
                 }
var hkvgsxfs = GetInputConstructorValue("hkvgsxfs", loader);
                 if(hkvgsxfs["original"].length == 0)
                 {
                   Invalid("key" + " is empty");
                   return;
                 }
var omtneivj = GetInputConstructorValue("omtneivj", loader);
                 if(omtneivj["original"].length == 0)
                 {
                   Invalid("pixel_koef" + " is empty");
                   return;
                 }
var zjypxfbw = GetInputConstructorValue("zjypxfbw", loader);
                 if(zjypxfbw["original"].length == 0)
                 {
                   Invalid("reload_id" + " is empty");
                   return;
                 }
var kqqrunfl = GetInputConstructorValue("kqqrunfl", loader);
                 if(kqqrunfl["original"].length == 0)
                 {
                   Invalid("speed" + " is empty");
                   return;
                 }
var txzufrlx = GetInputConstructorValue("txzufrlx", loader);
                 if(txzufrlx["original"].length == 0)
                 {
                   Invalid("type_slide" + " is empty");
                   return;
                 }
var rquxswsc = GetInputConstructorValue("rquxswsc", loader);
                 if(rquxswsc["original"].length == 0)
                 {
                   Invalid("type_swipe" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SliderSolver_code").html())({"shhrinfc": shhrinfc["updated"],"roksgegl": roksgegl["updated"],"lrtkgcoy": lrtkgcoy["updated"],"qqtfnzcu": qqtfnzcu["updated"],"xesfmmru": xesfmmru["updated"],"hkvgsxfs": hkvgsxfs["updated"],"omtneivj": omtneivj["updated"],"zjypxfbw": zjypxfbw["updated"],"kqqrunfl": kqqrunfl["updated"],"txzufrlx": txzufrlx["updated"],"rquxswsc": rquxswsc["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
