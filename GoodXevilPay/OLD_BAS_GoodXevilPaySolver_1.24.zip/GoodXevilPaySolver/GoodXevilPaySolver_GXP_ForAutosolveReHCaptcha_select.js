var alznukbf = GetInputConstructorValue("alznukbf", loader);
                 if(alznukbf["original"].length == 0)
                 {
                   Invalid("AutoSettings" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_ForAutosolveReHCaptcha_code").html())({"alznukbf": alznukbf["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
