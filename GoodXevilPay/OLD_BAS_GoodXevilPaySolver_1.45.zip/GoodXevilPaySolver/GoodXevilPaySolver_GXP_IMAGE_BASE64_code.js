_call_function(GoodXevilPaySolver_GXP_IMAGE_BASE64,{ "APIKEY": (<%= ucedsxri %>),"IMAGE_BASE64": (<%= jzqaygbw %>) })!
<%= variable %> = _result_function()
