var pldrkxtw = GetInputConstructorValue("pldrkxtw", loader);
                 if(pldrkxtw["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var hizefooc = GetInputConstructorValue("hizefooc", loader);
                 if(hizefooc["original"].length == 0)
                 {
                   Invalid("mouse" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_Antibot_code").html())({"pldrkxtw": pldrkxtw["updated"],"hizefooc": hizefooc["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
