_call_function(GoodXevilPaySolver_GXP_ReCaptchav2TakeToken,{ "APIKEY": (<%= rsfhnpwo %>),"site_url": (<%= paoxypma %>),"sitekey": (<%= bshxppzw %>) })!
<%= variable %> = _result_function()
