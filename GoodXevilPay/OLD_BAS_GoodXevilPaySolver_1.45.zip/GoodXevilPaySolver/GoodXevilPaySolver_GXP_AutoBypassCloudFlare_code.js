_call_function(GoodXevilPaySolver_GXP_AutoBypassCloudFlare,{ "custom_button": (<%= ereurfbv %>),"max_time": (<%= ueuhsnws %>),"whait_element": (<%= saidziqx %>) })!
