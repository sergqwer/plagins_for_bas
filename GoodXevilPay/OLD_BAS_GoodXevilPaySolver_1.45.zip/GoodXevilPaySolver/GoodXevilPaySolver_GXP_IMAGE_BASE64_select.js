var ucedsxri = GetInputConstructorValue("ucedsxri", loader);
                 if(ucedsxri["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var jzqaygbw = GetInputConstructorValue("jzqaygbw", loader);
                 if(jzqaygbw["original"].length == 0)
                 {
                   Invalid("IMAGE_BASE64" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_IMAGE_BASE64_code").html())({"ucedsxri": ucedsxri["updated"],"jzqaygbw": jzqaygbw["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
