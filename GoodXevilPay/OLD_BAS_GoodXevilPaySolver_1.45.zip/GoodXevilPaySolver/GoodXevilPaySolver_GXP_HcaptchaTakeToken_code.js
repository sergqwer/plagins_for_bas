_call_function(GoodXevilPaySolver_GXP_HcaptchaTakeToken,{ "APIKEY": (<%= rmkaawgr %>),"site_url": (<%= hdaqovgu %>),"sitekey": (<%= khysffup %>) })!
<%= variable %> = _result_function()
