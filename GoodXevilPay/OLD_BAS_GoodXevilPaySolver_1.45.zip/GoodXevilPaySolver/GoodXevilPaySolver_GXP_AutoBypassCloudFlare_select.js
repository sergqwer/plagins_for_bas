var ereurfbv = GetInputConstructorValue("ereurfbv", loader);
                 if(ereurfbv["original"].length == 0)
                 {
                   Invalid("custom_button" + " is empty");
                   return;
                 }
var ueuhsnws = GetInputConstructorValue("ueuhsnws", loader);
                 if(ueuhsnws["original"].length == 0)
                 {
                   Invalid("max_time" + " is empty");
                   return;
                 }
var saidziqx = GetInputConstructorValue("saidziqx", loader);
                 if(saidziqx["original"].length == 0)
                 {
                   Invalid("whait_element" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_AutoBypassCloudFlare_code").html())({"ereurfbv": ereurfbv["updated"],"ueuhsnws": ueuhsnws["updated"],"saidziqx": saidziqx["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
