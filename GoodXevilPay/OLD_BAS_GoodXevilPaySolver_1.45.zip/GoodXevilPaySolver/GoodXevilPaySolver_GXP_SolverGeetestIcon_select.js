var lrbsxfko = GetInputConstructorValue("lrbsxfko", loader);
                 if(lrbsxfko["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var hxgwugna = GetInputConstructorValue("hxgwugna", loader);
                 if(hxgwugna["original"].length == 0)
                 {
                   Invalid("button_capthca" + " is empty");
                   return;
                 }
var fxaqkgvx = GetInputConstructorValue("fxaqkgvx", loader);
                 if(fxaqkgvx["original"].length == 0)
                 {
                   Invalid("captcha_submit" + " is empty");
                   return;
                 }
var owqkoumj = GetInputConstructorValue("owqkoumj", loader);
                 if(owqkoumj["original"].length == 0)
                 {
                   Invalid("foto_captcha" + " is empty");
                   return;
                 }
var yeribruf = GetInputConstructorValue("yeribruf", loader);
                 if(yeribruf["original"].length == 0)
                 {
                   Invalid("reload_captcha" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SolverGeetestIcon_code").html())({"lrbsxfko": lrbsxfko["updated"],"hxgwugna": hxgwugna["updated"],"fxaqkgvx": fxaqkgvx["updated"],"owqkoumj": owqkoumj["updated"],"yeribruf": yeribruf["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
