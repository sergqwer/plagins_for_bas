var kxgbnzov = GetInputConstructorValue("kxgbnzov", loader);
                 if(kxgbnzov["original"].length == 0)
                 {
                   Invalid("arrow_id" + " is empty");
                   return;
                 }
var nqunmymd = GetInputConstructorValue("nqunmymd", loader);
                 if(nqunmymd["original"].length == 0)
                 {
                   Invalid("avtoupdate" + " is empty");
                   return;
                 }
var qrideetl = GetInputConstructorValue("qrideetl", loader);
                 if(qrideetl["original"].length == 0)
                 {
                   Invalid("button_id" + " is empty");
                   return;
                 }
var qntftymq = GetInputConstructorValue("qntftymq", loader);
                 if(qntftymq["original"].length == 0)
                 {
                   Invalid("coef" + " is empty");
                   return;
                 }
var uqgtvmoi = GetInputConstructorValue("uqgtvmoi", loader);
                 if(uqgtvmoi["original"].length == 0)
                 {
                   Invalid("image id" + " is empty");
                   return;
                 }
var jedtbmtm = GetInputConstructorValue("jedtbmtm", loader);
                 if(jedtbmtm["original"].length == 0)
                 {
                   Invalid("key" + " is empty");
                   return;
                 }
var kcdswlsy = GetInputConstructorValue("kcdswlsy", loader);
                 if(kcdswlsy["original"].length == 0)
                 {
                   Invalid("pixel_koef" + " is empty");
                   return;
                 }
var jwyewdlt = GetInputConstructorValue("jwyewdlt", loader);
                 if(jwyewdlt["original"].length == 0)
                 {
                   Invalid("reload_id" + " is empty");
                   return;
                 }
var nqjdrcuq = GetInputConstructorValue("nqjdrcuq", loader);
                 if(nqjdrcuq["original"].length == 0)
                 {
                   Invalid("speed" + " is empty");
                   return;
                 }
var erfthmmh = GetInputConstructorValue("erfthmmh", loader);
                 if(erfthmmh["original"].length == 0)
                 {
                   Invalid("type_slide" + " is empty");
                   return;
                 }
var fyqyvlpx = GetInputConstructorValue("fyqyvlpx", loader);
                 if(fyqyvlpx["original"].length == 0)
                 {
                   Invalid("type_swipe" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SliderSolver_code").html())({"kxgbnzov": kxgbnzov["updated"],"nqunmymd": nqunmymd["updated"],"qrideetl": qrideetl["updated"],"qntftymq": qntftymq["updated"],"uqgtvmoi": uqgtvmoi["updated"],"jedtbmtm": jedtbmtm["updated"],"kcdswlsy": kcdswlsy["updated"],"jwyewdlt": jwyewdlt["updated"],"nqjdrcuq": nqjdrcuq["updated"],"erfthmmh": erfthmmh["updated"],"fyqyvlpx": fyqyvlpx["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
