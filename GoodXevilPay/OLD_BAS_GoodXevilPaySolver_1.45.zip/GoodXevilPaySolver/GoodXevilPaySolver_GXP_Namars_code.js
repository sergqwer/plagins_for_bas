_call_function(GoodXevilPaySolver_GXP_Namars,{ "apikey": (<%= swiipgxa %>) })!
<%= variable %> = _result_function()
