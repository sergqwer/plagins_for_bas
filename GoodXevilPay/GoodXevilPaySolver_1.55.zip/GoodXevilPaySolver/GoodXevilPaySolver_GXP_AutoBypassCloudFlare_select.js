var jqbthevp = GetInputConstructorValue("jqbthevp", loader);
                 if(jqbthevp["original"].length == 0)
                 {
                   Invalid("custom_button" + " is empty");
                   return;
                 }
var zprhvchb = GetInputConstructorValue("zprhvchb", loader);
                 if(zprhvchb["original"].length == 0)
                 {
                   Invalid("max_time" + " is empty");
                   return;
                 }
var dwvezzzi = GetInputConstructorValue("dwvezzzi", loader);
                 if(dwvezzzi["original"].length == 0)
                 {
                   Invalid("whait_element" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_AutoBypassCloudFlare_code").html())({"jqbthevp": jqbthevp["updated"],"zprhvchb": zprhvchb["updated"],"dwvezzzi": dwvezzzi["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
