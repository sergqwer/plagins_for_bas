var ejbgnjci = GetInputConstructorValue("ejbgnjci", loader);
                 if(ejbgnjci["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var pbwshapc = GetInputConstructorValue("pbwshapc", loader);
                 if(pbwshapc["original"].length == 0)
                 {
                   Invalid("captcha_submit" + " is empty");
                   return;
                 }
var kzqetxvl = GetInputConstructorValue("kzqetxvl", loader);
                 if(kzqetxvl["original"].length == 0)
                 {
                   Invalid("foto_captcha" + " is empty");
                   return;
                 }
var hnkcutux = GetInputConstructorValue("hnkcutux", loader);
                 if(hnkcutux["original"].length == 0)
                 {
                   Invalid("pixel_coef" + " is empty");
                   return;
                 }
var cqxpxmck = GetInputConstructorValue("cqxpxmck", loader);
                 if(cqxpxmck["original"].length == 0)
                 {
                   Invalid("reload_captcha" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SolverGeetestIcon_code").html())({"ejbgnjci": ejbgnjci["updated"],"pbwshapc": pbwshapc["updated"],"kzqetxvl": kzqetxvl["updated"],"hnkcutux": hnkcutux["updated"],"cqxpxmck": cqxpxmck["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
