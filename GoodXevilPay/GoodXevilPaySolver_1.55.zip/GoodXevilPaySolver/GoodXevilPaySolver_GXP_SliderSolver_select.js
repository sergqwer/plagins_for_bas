var gwogudfy = GetInputConstructorValue("gwogudfy", loader);
                 if(gwogudfy["original"].length == 0)
                 {
                   Invalid("arrow_id" + " is empty");
                   return;
                 }
var ocqnyuwy = GetInputConstructorValue("ocqnyuwy", loader);
                 if(ocqnyuwy["original"].length == 0)
                 {
                   Invalid("avtoupdate" + " is empty");
                   return;
                 }
var uzaspftp = GetInputConstructorValue("uzaspftp", loader);
                 if(uzaspftp["original"].length == 0)
                 {
                   Invalid("button_id" + " is empty");
                   return;
                 }
var yxubuopq = GetInputConstructorValue("yxubuopq", loader);
                 if(yxubuopq["original"].length == 0)
                 {
                   Invalid("coef" + " is empty");
                   return;
                 }
var jqisjuyo = GetInputConstructorValue("jqisjuyo", loader);
                 if(jqisjuyo["original"].length == 0)
                 {
                   Invalid("image id" + " is empty");
                   return;
                 }
var qhgvyhdz = GetInputConstructorValue("qhgvyhdz", loader);
                 if(qhgvyhdz["original"].length == 0)
                 {
                   Invalid("key" + " is empty");
                   return;
                 }
var nbqysqld = GetInputConstructorValue("nbqysqld", loader);
                 if(nbqysqld["original"].length == 0)
                 {
                   Invalid("pixel_koef" + " is empty");
                   return;
                 }
var zyhjiwru = GetInputConstructorValue("zyhjiwru", loader);
                 if(zyhjiwru["original"].length == 0)
                 {
                   Invalid("reload_id" + " is empty");
                   return;
                 }
var vmpncspm = GetInputConstructorValue("vmpncspm", loader);
                 if(vmpncspm["original"].length == 0)
                 {
                   Invalid("speed" + " is empty");
                   return;
                 }
var ejjlwgpo = GetInputConstructorValue("ejjlwgpo", loader);
                 if(ejjlwgpo["original"].length == 0)
                 {
                   Invalid("type_slide" + " is empty");
                   return;
                 }
var fokxrtgu = GetInputConstructorValue("fokxrtgu", loader);
                 if(fokxrtgu["original"].length == 0)
                 {
                   Invalid("type_swipe" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SliderSolver_code").html())({"gwogudfy": gwogudfy["updated"],"ocqnyuwy": ocqnyuwy["updated"],"uzaspftp": uzaspftp["updated"],"yxubuopq": yxubuopq["updated"],"jqisjuyo": jqisjuyo["updated"],"qhgvyhdz": qhgvyhdz["updated"],"nbqysqld": nbqysqld["updated"],"zyhjiwru": zyhjiwru["updated"],"vmpncspm": vmpncspm["updated"],"ejjlwgpo": ejjlwgpo["updated"],"fokxrtgu": fokxrtgu["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
