_call_function(GoodXevilPaySolver_GXP_AutoBypassCloudFlare,{ "custom_button": (<%= jqbthevp %>),"max_time": (<%= zprhvchb %>),"whait_element": (<%= dwvezzzi %>) })!
