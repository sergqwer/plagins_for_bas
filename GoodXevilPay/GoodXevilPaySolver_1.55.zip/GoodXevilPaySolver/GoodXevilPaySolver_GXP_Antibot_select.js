var gskkltwz = GetInputConstructorValue("gskkltwz", loader);
                 if(gskkltwz["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var mdsmsdnr = GetInputConstructorValue("mdsmsdnr", loader);
                 if(mdsmsdnr["original"].length == 0)
                 {
                   Invalid("mouse" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_Antibot_code").html())({"gskkltwz": gskkltwz["updated"],"mdsmsdnr": mdsmsdnr["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
