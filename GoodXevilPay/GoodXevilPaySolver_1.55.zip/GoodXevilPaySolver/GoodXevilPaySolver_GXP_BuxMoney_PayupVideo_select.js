var cwgjsphn = GetInputConstructorValue("cwgjsphn", loader);
                 if(cwgjsphn["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var hgzwomss = GetInputConstructorValue("hgzwomss", loader);
                 if(hgzwomss["original"].length == 0)
                 {
                   Invalid("timer" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_BuxMoney_PayupVideo_code").html())({"cwgjsphn": cwgjsphn["updated"],"hgzwomss": hgzwomss["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
