_call_function(GoodXevilPaySolver_GXP_HcaptchaTakeToken,{ "APIKEY": (<%= yyeycolf %>),"site_url": (<%= wwsybynl %>),"sitekey": (<%= nchlotof %>) })!
<%= variable %> = _result_function()
