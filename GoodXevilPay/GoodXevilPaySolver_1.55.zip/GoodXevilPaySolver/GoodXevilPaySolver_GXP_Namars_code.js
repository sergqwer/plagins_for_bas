_call_function(GoodXevilPaySolver_GXP_Namars,{ "apikey": (<%= ahbavlav %>) })!
<%= variable %> = _result_function()
