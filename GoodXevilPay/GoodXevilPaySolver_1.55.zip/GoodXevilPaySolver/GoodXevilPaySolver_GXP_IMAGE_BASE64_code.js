_call_function(GoodXevilPaySolver_GXP_IMAGE_BASE64,{ "APIKEY": (<%= anoyawdh %>),"IMAGE_BASE64": (<%= dnodrwuc %>) })!
<%= variable %> = _result_function()
