var mmlmlwln = GetInputConstructorValue("mmlmlwln", loader);
                 if(mmlmlwln["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var wctbbhhc = GetInputConstructorValue("wctbbhhc", loader);
                 if(wctbbhhc["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var bnvdlrip = GetInputConstructorValue("bnvdlrip", loader);
                 if(bnvdlrip["original"].length == 0)
                 {
                   Invalid("siteurl" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_BasiliskCaptcha_code").html())({"mmlmlwln": mmlmlwln["updated"],"wctbbhhc": wctbbhhc["updated"],"bnvdlrip": bnvdlrip["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
