_call_function(GoodXevilPaySolver_GXP_ReCaptchav2TakeToken,{ "APIKEY": (<%= dsgrsovk %>),"site_url": (<%= agecdzul %>),"sitekey": (<%= ztrcowdv %>) })!
<%= variable %> = _result_function()
