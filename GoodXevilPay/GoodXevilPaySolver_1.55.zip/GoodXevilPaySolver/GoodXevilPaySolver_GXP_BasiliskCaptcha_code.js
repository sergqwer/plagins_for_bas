_call_function(GoodXevilPaySolver_GXP_BasiliskCaptcha,{ "apikey": (<%= mmlmlwln %>),"sitekey": (<%= wctbbhhc %>),"siteurl": (<%= bnvdlrip %>) })!
