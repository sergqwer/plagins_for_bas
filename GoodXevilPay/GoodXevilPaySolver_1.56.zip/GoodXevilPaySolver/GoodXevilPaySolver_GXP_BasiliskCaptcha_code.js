_call_function(GoodXevilPaySolver_GXP_BasiliskCaptcha,{ "apikey": (<%= jpxnhugd %>),"sitekey": (<%= qjtnqqsj %>),"siteurl": (<%= pilksbii %>) })!
