var omwvtlir = GetInputConstructorValue("omwvtlir", loader);
                 if(omwvtlir["original"].length == 0)
                 {
                   Invalid("custom_button" + " is empty");
                   return;
                 }
var sqsqjgrg = GetInputConstructorValue("sqsqjgrg", loader);
                 if(sqsqjgrg["original"].length == 0)
                 {
                   Invalid("max_time" + " is empty");
                   return;
                 }
var hxjnveru = GetInputConstructorValue("hxjnveru", loader);
                 if(hxjnveru["original"].length == 0)
                 {
                   Invalid("whait_element" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_AutoBypassCloudFlare_code").html())({"omwvtlir": omwvtlir["updated"],"sqsqjgrg": sqsqjgrg["updated"],"hxjnveru": hxjnveru["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
