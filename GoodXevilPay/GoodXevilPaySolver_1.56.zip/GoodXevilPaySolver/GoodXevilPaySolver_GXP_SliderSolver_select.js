var gexqjojk = GetInputConstructorValue("gexqjojk", loader);
                 if(gexqjojk["original"].length == 0)
                 {
                   Invalid("arrow_id" + " is empty");
                   return;
                 }
var zjyeejkk = GetInputConstructorValue("zjyeejkk", loader);
                 if(zjyeejkk["original"].length == 0)
                 {
                   Invalid("avtoupdate" + " is empty");
                   return;
                 }
var czwhiuno = GetInputConstructorValue("czwhiuno", loader);
                 if(czwhiuno["original"].length == 0)
                 {
                   Invalid("button_id" + " is empty");
                   return;
                 }
var ntgduqwu = GetInputConstructorValue("ntgduqwu", loader);
                 if(ntgduqwu["original"].length == 0)
                 {
                   Invalid("coef" + " is empty");
                   return;
                 }
var vikvecxg = GetInputConstructorValue("vikvecxg", loader);
                 if(vikvecxg["original"].length == 0)
                 {
                   Invalid("image id" + " is empty");
                   return;
                 }
var isfykjsk = GetInputConstructorValue("isfykjsk", loader);
                 if(isfykjsk["original"].length == 0)
                 {
                   Invalid("key" + " is empty");
                   return;
                 }
var pfpqtwpv = GetInputConstructorValue("pfpqtwpv", loader);
                 if(pfpqtwpv["original"].length == 0)
                 {
                   Invalid("pixel_koef" + " is empty");
                   return;
                 }
var smddvwtc = GetInputConstructorValue("smddvwtc", loader);
                 if(smddvwtc["original"].length == 0)
                 {
                   Invalid("reload_id" + " is empty");
                   return;
                 }
var dnjlghnx = GetInputConstructorValue("dnjlghnx", loader);
                 if(dnjlghnx["original"].length == 0)
                 {
                   Invalid("speed" + " is empty");
                   return;
                 }
var qzhdrnzj = GetInputConstructorValue("qzhdrnzj", loader);
                 if(qzhdrnzj["original"].length == 0)
                 {
                   Invalid("type_slide" + " is empty");
                   return;
                 }
var znucpmfa = GetInputConstructorValue("znucpmfa", loader);
                 if(znucpmfa["original"].length == 0)
                 {
                   Invalid("type_swipe" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SliderSolver_code").html())({"gexqjojk": gexqjojk["updated"],"zjyeejkk": zjyeejkk["updated"],"czwhiuno": czwhiuno["updated"],"ntgduqwu": ntgduqwu["updated"],"vikvecxg": vikvecxg["updated"],"isfykjsk": isfykjsk["updated"],"pfpqtwpv": pfpqtwpv["updated"],"smddvwtc": smddvwtc["updated"],"dnjlghnx": dnjlghnx["updated"],"qzhdrnzj": qzhdrnzj["updated"],"znucpmfa": znucpmfa["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
