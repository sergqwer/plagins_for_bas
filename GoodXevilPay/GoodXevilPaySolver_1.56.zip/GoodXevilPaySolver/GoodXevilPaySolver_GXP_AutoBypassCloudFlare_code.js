_call_function(GoodXevilPaySolver_GXP_AutoBypassCloudFlare,{ "custom_button": (<%= omwvtlir %>),"max_time": (<%= sqsqjgrg %>),"whait_element": (<%= hxjnveru %>) })!
