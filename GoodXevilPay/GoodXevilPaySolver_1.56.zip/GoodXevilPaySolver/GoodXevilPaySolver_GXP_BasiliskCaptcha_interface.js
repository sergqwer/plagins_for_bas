<div class="container-fluid">
<%= _.template($('#input_constructor').html())({id:"jpxnhugd", description:"apikey", default_selector: "string", disable_int:true, value_string: "", help: {description: "apikey с сервиса https://t.me/Xevil_check_bot\n\napikey from https://t.me/Xevil_check_bot"} }) %>
<%= _.template($('#input_constructor').html())({id:"qjtnqqsj", description:"sitekey", default_selector: "string", disable_int:true, value_string: "a3760bfe5cf4254b2759c19fb2601667", help: {description: "Значения поля data-sitekey в коде страницы, стандартное значение указано для faucetpay.io\n\nThe values of the data-sitekey field in the page code, the default value is given for faucetpay.io"} }) %>
<%= _.template($('#input_constructor').html())({id:"pilksbii", description:"siteurl", default_selector: "string", disable_int:true, value_string: "https://faucetpay.io/account/login", help: {description: "Страница на которой решается капча\n\nThe page where the captcha is solved"} }) %>
</div>
<div class="tooltipinternal">
<div class="tr tooltip-paragraph-first-fold">Автоматически решает капчу на сайте faucetpay.io</div>
<div class="tr tooltip-paragraph-last-fold">Automatically solves captcha on the faucetpay.io website</div>
</div>
<%= _.template($('#back').html())({action:"executeandadd", visible:true}) %>
