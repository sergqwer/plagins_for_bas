var lgknpwha = GetInputConstructorValue("lgknpwha", loader);
                 if(lgknpwha["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var pcqwjerg = GetInputConstructorValue("pcqwjerg", loader);
                 if(pcqwjerg["original"].length == 0)
                 {
                   Invalid("captcha_submit" + " is empty");
                   return;
                 }
var lyxeoroh = GetInputConstructorValue("lyxeoroh", loader);
                 if(lyxeoroh["original"].length == 0)
                 {
                   Invalid("foto_captcha" + " is empty");
                   return;
                 }
var jafrkktk = GetInputConstructorValue("jafrkktk", loader);
                 if(jafrkktk["original"].length == 0)
                 {
                   Invalid("pixel_coef" + " is empty");
                   return;
                 }
var atfviiil = GetInputConstructorValue("atfviiil", loader);
                 if(atfviiil["original"].length == 0)
                 {
                   Invalid("reload_captcha" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SolverGeetestIcon_code").html())({"lgknpwha": lgknpwha["updated"],"pcqwjerg": pcqwjerg["updated"],"lyxeoroh": lyxeoroh["updated"],"jafrkktk": jafrkktk["updated"],"atfviiil": atfviiil["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
