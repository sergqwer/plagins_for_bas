_call_function(GoodXevilPaySolver_GXP_ReCaptchav2TakeToken,{ "APIKEY": (<%= nmpxclqm %>),"site_url": (<%= nzfnxobt %>),"sitekey": (<%= jlhvhcwk %>) })!
<%= variable %> = _result_function()
