var jpxnhugd = GetInputConstructorValue("jpxnhugd", loader);
                 if(jpxnhugd["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var qjtnqqsj = GetInputConstructorValue("qjtnqqsj", loader);
                 if(qjtnqqsj["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var pilksbii = GetInputConstructorValue("pilksbii", loader);
                 if(pilksbii["original"].length == 0)
                 {
                   Invalid("siteurl" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_BasiliskCaptcha_code").html())({"jpxnhugd": jpxnhugd["updated"],"qjtnqqsj": qjtnqqsj["updated"],"pilksbii": pilksbii["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
