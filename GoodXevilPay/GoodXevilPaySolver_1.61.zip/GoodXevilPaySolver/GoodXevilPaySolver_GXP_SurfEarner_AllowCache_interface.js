<div class="container-fluid">
</div>
<div class="tooltipinternal">
<div class="tr tooltip-paragraph-first-fold">Надо для правильной работы SurfEarner</div>
<div class="tr tooltip-paragraph-fold">Запускать надо до загрузки страницы с капчей</div>
<div class="tr tooltip-paragraph-fold">It is necessary for SurfEarner to work properly</div>
<div class="tr tooltip-paragraph-last-fold">It should be run before the page with captcha is loaded</div>
</div>
<%= _.template($('#back').html())({action:"executeandadd", visible:true}) %>
