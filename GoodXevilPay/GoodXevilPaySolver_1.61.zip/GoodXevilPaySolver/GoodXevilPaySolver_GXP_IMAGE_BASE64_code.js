_call_function(GoodXevilPaySolver_GXP_IMAGE_BASE64,{ "APIKEY": (<%= eqoqvarj %>),"IMAGE_BASE64": (<%= nzyjiuzs %>) })!
<%= variable %> = _result_function()
