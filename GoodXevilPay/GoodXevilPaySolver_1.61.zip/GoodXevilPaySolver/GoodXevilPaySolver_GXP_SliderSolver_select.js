var ouhaskcy = GetInputConstructorValue("ouhaskcy", loader);
                 if(ouhaskcy["original"].length == 0)
                 {
                   Invalid("arrow_id" + " is empty");
                   return;
                 }
var klvwcwrq = GetInputConstructorValue("klvwcwrq", loader);
                 if(klvwcwrq["original"].length == 0)
                 {
                   Invalid("avtoupdate" + " is empty");
                   return;
                 }
var xzhamiyk = GetInputConstructorValue("xzhamiyk", loader);
                 if(xzhamiyk["original"].length == 0)
                 {
                   Invalid("button_id" + " is empty");
                   return;
                 }
var mfiadbii = GetInputConstructorValue("mfiadbii", loader);
                 if(mfiadbii["original"].length == 0)
                 {
                   Invalid("coef" + " is empty");
                   return;
                 }
var tnriclij = GetInputConstructorValue("tnriclij", loader);
                 if(tnriclij["original"].length == 0)
                 {
                   Invalid("image id" + " is empty");
                   return;
                 }
var rwvfocef = GetInputConstructorValue("rwvfocef", loader);
                 if(rwvfocef["original"].length == 0)
                 {
                   Invalid("key" + " is empty");
                   return;
                 }
var itdrkywt = GetInputConstructorValue("itdrkywt", loader);
                 if(itdrkywt["original"].length == 0)
                 {
                   Invalid("pixel_koef" + " is empty");
                   return;
                 }
var pafhnkor = GetInputConstructorValue("pafhnkor", loader);
                 if(pafhnkor["original"].length == 0)
                 {
                   Invalid("reload_id" + " is empty");
                   return;
                 }
var mwolfpke = GetInputConstructorValue("mwolfpke", loader);
                 if(mwolfpke["original"].length == 0)
                 {
                   Invalid("speed" + " is empty");
                   return;
                 }
var wzhtshzn = GetInputConstructorValue("wzhtshzn", loader);
                 if(wzhtshzn["original"].length == 0)
                 {
                   Invalid("type_slide" + " is empty");
                   return;
                 }
var ogzpxelc = GetInputConstructorValue("ogzpxelc", loader);
                 if(ogzpxelc["original"].length == 0)
                 {
                   Invalid("type_swipe" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SliderSolver_code").html())({"ouhaskcy": ouhaskcy["updated"],"klvwcwrq": klvwcwrq["updated"],"xzhamiyk": xzhamiyk["updated"],"mfiadbii": mfiadbii["updated"],"tnriclij": tnriclij["updated"],"rwvfocef": rwvfocef["updated"],"itdrkywt": itdrkywt["updated"],"pafhnkor": pafhnkor["updated"],"mwolfpke": mwolfpke["updated"],"wzhtshzn": wzhtshzn["updated"],"ogzpxelc": ogzpxelc["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
