var uuyzqytf = GetInputConstructorValue("uuyzqytf", loader);
                 if(uuyzqytf["original"].length == 0)
                 {
                   Invalid("custom_button" + " is empty");
                   return;
                 }
var pyjqynmi = GetInputConstructorValue("pyjqynmi", loader);
                 if(pyjqynmi["original"].length == 0)
                 {
                   Invalid("max_time" + " is empty");
                   return;
                 }
var mbgdrmks = GetInputConstructorValue("mbgdrmks", loader);
                 if(mbgdrmks["original"].length == 0)
                 {
                   Invalid("whait_element" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_AutoBypassCloudFlare_code").html())({"uuyzqytf": uuyzqytf["updated"],"pyjqynmi": pyjqynmi["updated"],"mbgdrmks": mbgdrmks["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
