_call_function(GoodXevilPaySolver_GXP_ReCaptchav2TakeToken,{ "APIKEY": (<%= rkbnbtdy %>),"site_url": (<%= aceqfmzd %>),"sitekey": (<%= uqeoffvu %>) })!
<%= variable %> = _result_function()
