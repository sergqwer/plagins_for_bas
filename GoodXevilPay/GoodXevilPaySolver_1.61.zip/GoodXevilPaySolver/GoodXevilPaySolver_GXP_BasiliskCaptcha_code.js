_call_function(GoodXevilPaySolver_GXP_BasiliskCaptcha,{ "apikey": (<%= yewzssfk %>),"sitekey": (<%= pkmyhujz %>),"siteurl": (<%= gowowcrj %>) })!
