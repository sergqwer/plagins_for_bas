var npabyskc = GetInputConstructorValue("npabyskc", loader);
                 if(npabyskc["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var lktipeco = GetInputConstructorValue("lktipeco", loader);
                 if(lktipeco["original"].length == 0)
                 {
                   Invalid("site_url" + " is empty");
                   return;
                 }
var kfgzmfxl = GetInputConstructorValue("kfgzmfxl", loader);
                 if(kfgzmfxl["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_HcaptchaTakeToken_code").html())({"npabyskc": npabyskc["updated"],"lktipeco": lktipeco["updated"],"kfgzmfxl": kfgzmfxl["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
