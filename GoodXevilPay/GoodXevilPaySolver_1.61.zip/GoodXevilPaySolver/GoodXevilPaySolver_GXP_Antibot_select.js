var tjpfbmis = GetInputConstructorValue("tjpfbmis", loader);
                 if(tjpfbmis["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var wdmcpqds = GetInputConstructorValue("wdmcpqds", loader);
                 if(wdmcpqds["original"].length == 0)
                 {
                   Invalid("mouse" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_Antibot_code").html())({"tjpfbmis": tjpfbmis["updated"],"wdmcpqds": wdmcpqds["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
