var jzugsfhq = GetInputConstructorValue("jzugsfhq", loader);
                 if(jzugsfhq["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var yyimigck = GetInputConstructorValue("yyimigck", loader);
                 if(yyimigck["original"].length == 0)
                 {
                   Invalid("captcha_submit" + " is empty");
                   return;
                 }
var npbczjyg = GetInputConstructorValue("npbczjyg", loader);
                 if(npbczjyg["original"].length == 0)
                 {
                   Invalid("foto_captcha" + " is empty");
                   return;
                 }
var ofoosatn = GetInputConstructorValue("ofoosatn", loader);
                 if(ofoosatn["original"].length == 0)
                 {
                   Invalid("pixel_coef" + " is empty");
                   return;
                 }
var mhxhvies = GetInputConstructorValue("mhxhvies", loader);
                 if(mhxhvies["original"].length == 0)
                 {
                   Invalid("reload_captcha" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SolverGeetestIcon_code").html())({"jzugsfhq": jzugsfhq["updated"],"yyimigck": yyimigck["updated"],"npbczjyg": npbczjyg["updated"],"ofoosatn": ofoosatn["updated"],"mhxhvies": mhxhvies["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
