var dgdrexkk = GetInputConstructorValue("dgdrexkk", loader);
                 if(dgdrexkk["original"].length == 0)
                 {
                   Invalid("hCaptcha_USE" + " is empty");
                   return;
                 }
var mudjpycl = GetInputConstructorValue("mudjpycl", loader);
                 if(mudjpycl["original"].length == 0)
                 {
                   Invalid("ReCaptcha_USE" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_ForAutosolveReHCaptcha_code").html())({"dgdrexkk": dgdrexkk["updated"],"mudjpycl": mudjpycl["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
