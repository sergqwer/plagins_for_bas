_call_function(GoodXevilPaySolver_GXP_Solve_Funcaptcha,{ "APIKey": (<%= wrkujeci %>),"CaptchaNumber": (<%= bvgcmevs %>),"CaptchaSelector": (<%= bhjaictp %>),"MaxLimitTask": (<%= glqnkxia %>) })!
