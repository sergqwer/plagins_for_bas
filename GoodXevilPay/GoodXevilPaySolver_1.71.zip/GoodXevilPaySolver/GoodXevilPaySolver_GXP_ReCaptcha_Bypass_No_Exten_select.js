var fhzqhtvs = GetInputConstructorValue("fhzqhtvs", loader);
                 if(fhzqhtvs["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var eslsebbm = GetInputConstructorValue("eslsebbm", loader);
                 if(eslsebbm["original"].length == 0)
                 {
                   Invalid("cut_url" + " is empty");
                   return;
                 }
var gyzcrrsm = GetInputConstructorValue("gyzcrrsm", loader);
                 if(gyzcrrsm["original"].length == 0)
                 {
                   Invalid("enterprise" + " is empty");
                   return;
                 }
var zadsufue = GetInputConstructorValue("zadsufue", loader);
                 if(zadsufue["original"].length == 0)
                 {
                   Invalid("index" + " is empty");
                   return;
                 }
var yuzkwlio = GetInputConstructorValue("yuzkwlio", loader);
                 if(yuzkwlio["original"].length == 0)
                 {
                   Invalid("invisible" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_ReCaptcha_Bypass_No_Exten_code").html())({"fhzqhtvs": fhzqhtvs["updated"],"eslsebbm": eslsebbm["updated"],"gyzcrrsm": gyzcrrsm["updated"],"zadsufue": zadsufue["updated"],"yuzkwlio": yuzkwlio["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
