var wrkujeci = GetInputConstructorValue("wrkujeci", loader);
                 if(wrkujeci["original"].length == 0)
                 {
                   Invalid("APIKey" + " is empty");
                   return;
                 }
var bvgcmevs = GetInputConstructorValue("bvgcmevs", loader);
                 if(bvgcmevs["original"].length == 0)
                 {
                   Invalid("CaptchaNumber" + " is empty");
                   return;
                 }
var bhjaictp = GetInputConstructorValue("bhjaictp", loader);
                 if(bhjaictp["original"].length == 0)
                 {
                   Invalid("CaptchaSelector" + " is empty");
                   return;
                 }
var glqnkxia = GetInputConstructorValue("glqnkxia", loader);
                 if(glqnkxia["original"].length == 0)
                 {
                   Invalid("MaxLimitTask" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_Solve_Funcaptcha_code").html())({"wrkujeci": wrkujeci["updated"],"bvgcmevs": bvgcmevs["updated"],"bhjaictp": bhjaictp["updated"],"glqnkxia": glqnkxia["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
