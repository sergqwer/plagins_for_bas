var tiryrohd = GetInputConstructorValue("tiryrohd", loader);
                 if(tiryrohd["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var pocydpnm = GetInputConstructorValue("pocydpnm", loader);
                 if(pocydpnm["original"].length == 0)
                 {
                   Invalid("arab_fix" + " is empty");
                   return;
                 }
var xzytzcpz = GetInputConstructorValue("xzytzcpz", loader);
                 if(xzytzcpz["original"].length == 0)
                 {
                   Invalid("captcha_submit" + " is empty");
                   return;
                 }
var ljwzltls = GetInputConstructorValue("ljwzltls", loader);
                 if(ljwzltls["original"].length == 0)
                 {
                   Invalid("foto_captcha" + " is empty");
                   return;
                 }
var hjlgunfu = GetInputConstructorValue("hjlgunfu", loader);
                 if(hjlgunfu["original"].length == 0)
                 {
                   Invalid("pixel_coef" + " is empty");
                   return;
                 }
var pttvztwe = GetInputConstructorValue("pttvztwe", loader);
                 if(pttvztwe["original"].length == 0)
                 {
                   Invalid("reload_captcha" + " is empty");
                   return;
                 }
var twvsfjcv = GetInputConstructorValue("twvsfjcv", loader);
                 if(twvsfjcv["original"].length == 0)
                 {
                   Invalid("type_data" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SolverGeetestIcon_code").html())({"tiryrohd": tiryrohd["updated"],"pocydpnm": pocydpnm["updated"],"xzytzcpz": xzytzcpz["updated"],"ljwzltls": ljwzltls["updated"],"hjlgunfu": hjlgunfu["updated"],"pttvztwe": pttvztwe["updated"],"twvsfjcv": twvsfjcv["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
