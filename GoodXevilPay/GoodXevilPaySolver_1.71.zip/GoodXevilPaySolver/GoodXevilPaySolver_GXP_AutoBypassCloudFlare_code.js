_call_function(GoodXevilPaySolver_GXP_AutoBypassCloudFlare,{ "custom_button": (<%= pxtroelw %>),"max_time": (<%= hxoyoulb %>),"whait_element": (<%= ofxkjsxx %>) })!
