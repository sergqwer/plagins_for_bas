var pxtroelw = GetInputConstructorValue("pxtroelw", loader);
                 if(pxtroelw["original"].length == 0)
                 {
                   Invalid("custom_button" + " is empty");
                   return;
                 }
var hxoyoulb = GetInputConstructorValue("hxoyoulb", loader);
                 if(hxoyoulb["original"].length == 0)
                 {
                   Invalid("max_time" + " is empty");
                   return;
                 }
var ofxkjsxx = GetInputConstructorValue("ofxkjsxx", loader);
                 if(ofxkjsxx["original"].length == 0)
                 {
                   Invalid("whait_element" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_AutoBypassCloudFlare_code").html())({"pxtroelw": pxtroelw["updated"],"hxoyoulb": hxoyoulb["updated"],"ofxkjsxx": ofxkjsxx["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
