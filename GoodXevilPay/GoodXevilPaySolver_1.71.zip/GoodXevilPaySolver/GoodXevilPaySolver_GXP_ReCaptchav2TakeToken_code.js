_call_function(GoodXevilPaySolver_GXP_ReCaptchav2TakeToken,{ "APIKEY": (<%= esrutpat %>),"site_url": (<%= epcahcrn %>),"sitekey": (<%= zkhkjjql %>) })!
<%= variable %> = _result_function()
