_call_function(GoodXevilPaySolver_GXP_Namars,{ "apikey": (<%= ekdiyqba %>) })!
<%= variable %> = _result_function()
