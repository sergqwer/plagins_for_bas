var kvxwjblh = GetInputConstructorValue("kvxwjblh", loader);
                 if(kvxwjblh["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var xhedhava = GetInputConstructorValue("xhedhava", loader);
                 if(xhedhava["original"].length == 0)
                 {
                   Invalid("CaptchaSelector" + " is empty");
                   return;
                 }
var tfzsdrhk = GetInputConstructorValue("tfzsdrhk", loader);
                 if(tfzsdrhk["original"].length == 0)
                 {
                   Invalid("InvisibleCaptcha" + " is empty");
                   return;
                 }
var xtugtxgr = GetInputConstructorValue("xtugtxgr", loader);
                 if(xtugtxgr["original"].length == 0)
                 {
                   Invalid("TrySolve" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_hCaptcha_Click_code").html())({"kvxwjblh": kvxwjblh["updated"],"xhedhava": xhedhava["updated"],"tfzsdrhk": tfzsdrhk["updated"],"xtugtxgr": xtugtxgr["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
