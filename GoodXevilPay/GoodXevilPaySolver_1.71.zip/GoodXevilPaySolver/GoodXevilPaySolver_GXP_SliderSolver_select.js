var tnrqddsy = GetInputConstructorValue("tnrqddsy", loader);
                 if(tnrqddsy["original"].length == 0)
                 {
                   Invalid("arrow_id" + " is empty");
                   return;
                 }
var dnipupqo = GetInputConstructorValue("dnipupqo", loader);
                 if(dnipupqo["original"].length == 0)
                 {
                   Invalid("Attempts" + " is empty");
                   return;
                 }
var xojhejtv = GetInputConstructorValue("xojhejtv", loader);
                 if(xojhejtv["original"].length == 0)
                 {
                   Invalid("avtoupdate" + " is empty");
                   return;
                 }
var ulievxfz = GetInputConstructorValue("ulievxfz", loader);
                 if(ulievxfz["original"].length == 0)
                 {
                   Invalid("button_id" + " is empty");
                   return;
                 }
var ynoxoocv = GetInputConstructorValue("ynoxoocv", loader);
                 if(ynoxoocv["original"].length == 0)
                 {
                   Invalid("coef" + " is empty");
                   return;
                 }
var iadpgybz = GetInputConstructorValue("iadpgybz", loader);
                 if(iadpgybz["original"].length == 0)
                 {
                   Invalid("image id" + " is empty");
                   return;
                 }
var gftlzlxi = GetInputConstructorValue("gftlzlxi", loader);
                 if(gftlzlxi["original"].length == 0)
                 {
                   Invalid("key" + " is empty");
                   return;
                 }
var vxkvwiez = GetInputConstructorValue("vxkvwiez", loader);
                 if(vxkvwiez["original"].length == 0)
                 {
                   Invalid("pixel_koef" + " is empty");
                   return;
                 }
var iubjfdgn = GetInputConstructorValue("iubjfdgn", loader);
                 if(iubjfdgn["original"].length == 0)
                 {
                   Invalid("reload_id" + " is empty");
                   return;
                 }
var pnclafby = GetInputConstructorValue("pnclafby", loader);
                 if(pnclafby["original"].length == 0)
                 {
                   Invalid("slider_type" + " is empty");
                   return;
                 }
var fuwwiktu = GetInputConstructorValue("fuwwiktu", loader);
                 if(fuwwiktu["original"].length == 0)
                 {
                   Invalid("speed" + " is empty");
                   return;
                 }
var brqorchb = GetInputConstructorValue("brqorchb", loader);
                 if(brqorchb["original"].length == 0)
                 {
                   Invalid("type_slide" + " is empty");
                   return;
                 }
var skuwqxda = GetInputConstructorValue("skuwqxda", loader);
                 if(skuwqxda["original"].length == 0)
                 {
                   Invalid("type_swipe" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SliderSolver_code").html())({"tnrqddsy": tnrqddsy["updated"],"dnipupqo": dnipupqo["updated"],"xojhejtv": xojhejtv["updated"],"ulievxfz": ulievxfz["updated"],"ynoxoocv": ynoxoocv["updated"],"iadpgybz": iadpgybz["updated"],"gftlzlxi": gftlzlxi["updated"],"vxkvwiez": vxkvwiez["updated"],"iubjfdgn": iubjfdgn["updated"],"pnclafby": pnclafby["updated"],"fuwwiktu": fuwwiktu["updated"],"brqorchb": brqorchb["updated"],"skuwqxda": skuwqxda["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
