var bfnlkfjs = GetInputConstructorValue("bfnlkfjs", loader);
                 if(bfnlkfjs["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var luautgnq = GetInputConstructorValue("luautgnq", loader);
                 if(luautgnq["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var knxadtqh = GetInputConstructorValue("knxadtqh", loader);
                 if(knxadtqh["original"].length == 0)
                 {
                   Invalid("siteurl" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_BasiliskCaptcha_code").html())({"bfnlkfjs": bfnlkfjs["updated"],"luautgnq": luautgnq["updated"],"knxadtqh": knxadtqh["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
