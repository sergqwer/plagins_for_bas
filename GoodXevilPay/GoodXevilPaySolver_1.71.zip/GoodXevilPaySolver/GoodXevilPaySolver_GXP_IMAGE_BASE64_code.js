_call_function(GoodXevilPaySolver_GXP_IMAGE_BASE64,{ "APIKEY": (<%= biirrbtr %>),"IMAGE_BASE64": (<%= iordcsdk %>) })!
<%= variable %> = _result_function()
