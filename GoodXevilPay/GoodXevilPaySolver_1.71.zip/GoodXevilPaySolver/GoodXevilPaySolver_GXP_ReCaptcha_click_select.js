var dnhsbdvq = GetInputConstructorValue("dnhsbdvq", loader);
                 if(dnhsbdvq["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var auvceivu = GetInputConstructorValue("auvceivu", loader);
                 if(auvceivu["original"].length == 0)
                 {
                   Invalid("CaptchaSelector" + " is empty");
                   return;
                 }
var btiwguey = GetInputConstructorValue("btiwguey", loader);
                 if(btiwguey["original"].length == 0)
                 {
                   Invalid("InvisibleCaptcha" + " is empty");
                   return;
                 }
var jhtznepp = GetInputConstructorValue("jhtznepp", loader);
                 if(jhtznepp["original"].length == 0)
                 {
                   Invalid("TrySolve" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_ReCaptcha_click_code").html())({"dnhsbdvq": dnhsbdvq["updated"],"auvceivu": auvceivu["updated"],"btiwguey": btiwguey["updated"],"jhtznepp": jhtznepp["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
