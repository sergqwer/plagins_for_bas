_call_function(GoodXevilPaySolver_GXP_hCaptcha_Click,{ "apikey": (<%= kvxwjblh %>),"CaptchaSelector": (<%= xhedhava %>),"InvisibleCaptcha": (<%= tfzsdrhk %>),"TrySolve": (<%= xtugtxgr %>) })!
