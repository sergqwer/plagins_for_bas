_call_function(GoodXevilPaySolver_GXP_ReCaptcha_click,{ "apikey": (<%= dnhsbdvq %>),"CaptchaSelector": (<%= auvceivu %>),"InvisibleCaptcha": (<%= btiwguey %>),"TrySolve": (<%= jhtznepp %>) })!
