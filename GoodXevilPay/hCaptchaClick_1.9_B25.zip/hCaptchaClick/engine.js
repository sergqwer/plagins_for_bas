function hCaptchaClick_hcaptcha_solver()
   {
   
      
      
      VAR_MAIN_FRAME_CHECKBOX_MODULE = _function_argument("main_frame_checkbox")
      

      
      
      VAR_MAIN_FRAME_SOLVER_MODULE = _function_argument("main_frame_solver")
      

      
      
      VAR_USER_APIKEY_MODULE = _function_argument("userapikey")
      

      
      
      VAR_TRY_SOLVED_MODULE = _function_argument("try_solved")
      

      
      
      VAR_NAME_SERVICE_MODULE = _function_argument("servisename")
      

      
      
      VAR_NOW_SPEED_MODULE = _function_argument("speed")
      

      
      
      VAR_CAPTCHA_SOLVED = false
      

      
      
      VAR_MAIN_FRAME_SOLVER_MODULE_TEST = VAR_MAIN_FRAME_SOLVER_MODULE.split("|")
      

      
      
      VAR_MAIN_FRAME_SOLVER_MODULE = []
      

      
      
      /*Browser*/
      cache_allow("*hcaptcha.*getcaptcha*")!
      

      
      
      /*Browser*/
      cache_allow("*hcaptcha.*/checkcaptcha*")!
      

      
      
      /*Browser*/
      cache_allow("*img*hcaptcha.*/*")!
      

      
      
      _do_with_params({"foreach_data":(VAR_MAIN_FRAME_SOLVER_MODULE_TEST)},function(){
      _set_action_info({ name: "Foreach" });
      VAR_CYCLE_INDEX = _iterator() - 1
      if(VAR_CYCLE_INDEX > _cycle_param("foreach_data").length - 1)_break();
      VAR_FOREACH_DATA = _cycle_param("foreach_data")[VAR_CYCLE_INDEX]
      
         
         
         VAR_TEST_IS_MODULE = Boolean(native("regexp", "ismatch", JSON.stringify({text: VAR_FOREACH_DATA,regexp:"(\u003eFRAME\u003e)"})) == "true")
         

         
         
         _set_if_expression("W1tURVNUX0lTX01PRFVMRV1d");
         _if(typeof(VAR_TEST_IS_MODULE) !== "undefined" ? (VAR_TEST_IS_MODULE) : undefined,function(){
         
            
            
            input = VAR_FOREACH_DATA
            var index = input.lastIndexOf(">FRAME>");
            VAR_TMP_MODULE = input.substring(0, index + 7);
            

            
            
            VAR_MAIN_FRAME_SOLVER_MODULE.push(VAR_TMP_MODULE)
            

         })!
         

      })!
      

      
      
      VAR_MAIN_FRAME_CHECKBOX_MODULE_TEST = VAR_MAIN_FRAME_CHECKBOX_MODULE.split("|")
      

      
      
      VAR_MAIN_FRAME_CHECKBOX_MODULE = []
      

      
      
      _do_with_params({"foreach_data":(VAR_MAIN_FRAME_CHECKBOX_MODULE_TEST)},function(){
      _set_action_info({ name: "Foreach" });
      VAR_CYCLE_INDEX = _iterator() - 1
      if(VAR_CYCLE_INDEX > _cycle_param("foreach_data").length - 1)_break();
      VAR_FOREACH_DATA = _cycle_param("foreach_data")[VAR_CYCLE_INDEX]
      
         
         
         VAR_TEST_IS_MODULE = Boolean(native("regexp", "ismatch", JSON.stringify({text: VAR_FOREACH_DATA,regexp:"(\u003eFRAME\u003e)"})) == "true")
         

         
         
         _set_if_expression("W1tURVNUX0lTX01PRFVMRV1d");
         _if(typeof(VAR_TEST_IS_MODULE) !== "undefined" ? (VAR_TEST_IS_MODULE) : undefined,function(){
         
            
            
            input = VAR_FOREACH_DATA
            var index = input.lastIndexOf(">FRAME>");
            VAR_TMP_MODULE = input.substring(0, index + 7);
            

            
            
            VAR_MAIN_FRAME_CHECKBOX_MODULE.push(VAR_TMP_MODULE)
            

         })!
         

      })!
      

      
      
      VAR_MAIN_FRAME_CHECKBOX_MODULE = (function(){var seen = {}; return (VAR_MAIN_FRAME_CHECKBOX_MODULE).filter(function(item) { return seen.hasOwnProperty(item) ? false : (seen[item] = true); });})();
      

      
      
      VAR_MAIN_FRAME_SOLVER_MODULE = (function(){var seen = {}; return (VAR_MAIN_FRAME_SOLVER_MODULE).filter(function(item) { return seen.hasOwnProperty(item) ? false : (seen[item] = true); });})();
      

      
      
      _cycle_params().if_else = VAR_NAME_SERVICE_MODULE == "SCTG";
      _set_if_expression("W1tOQU1FX1NFUlZJQ0VfTU9EVUxFXV0gPT0gIlNDVEci");
      _if(_cycle_params().if_else,function(){
      
         
         
         VAR_LIST_URLS_SCTG = [
         "http://api.sctg.xyz",
         "http://sctg.xyz",
         "http://157.180.15.203",
         "https://api.sctg.xyz",
         "https://sctg.xyz",
         "https://ru.sctg.xyz",
         "http://ru.sctg.xyz",
         "http://109.248.207.94"
         ]
         VAR_LIST_CONTAINS = (VAR_LIST_URLS_SCTG).indexOf(JSON.parse(P("basglobal", "URL_ADRESS_SCTG_MALGNVAWU") || '""')) >= 0
         _set_if_expression("W1tMSVNUX0NPTlRBSU5TXV0gPT0gZmFsc2U=");
         _if(VAR_LIST_CONTAINS == false,function(){
         _do_with_params({"foreach_data":(VAR_LIST_URLS_SCTG)},function(){
         _set_action_info({ name: "Foreach" });
         VAR_CYCLE_INDEX = _iterator() - 1
         if(VAR_CYCLE_INDEX > _cycle_param("foreach_data").length - 1)_break();
         VAR_FOREACH_DATA = _cycle_param("foreach_data")[VAR_CYCLE_INDEX]
         _call(function()
         {
         _on_fail(function(){
         VAR_LAST_ERROR = _result()
         VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
         VAR_WAS_ERROR = false
         _break(1,true)
         })
         CYCLES.Current().RemoveLabel("function")
         http_client_set_fail_on_error(false)
         _switch_http_client_internal()
         general_timeout_next(10000)
         http_client_get_no_redirect2(VAR_FOREACH_DATA + "/ip",{method:("GET"),headers:("")})!
         http_client_set_fail_on_error(true)
         _switch_http_client_main()
         },null)!
         _set_if_expression("W1tXQVNfRVJST1JdXQ==");
         _if(typeof(VAR_WAS_ERROR) !== "undefined" ? (VAR_WAS_ERROR) : undefined,function(){
         _next("function")
         })!
         http_client_set_fail_on_error(false)
         _switch_http_client_internal()
         VAR_SAVED_STATUS = http_client_status()
         http_client_set_fail_on_error(true)
         _switch_http_client_main()
         _set_if_expression("W1tTQVZFRF9TVEFUVVNdXSA9PSAyMDA=");
         _if(VAR_SAVED_STATUS == 200,function(){
         var val = JSON.stringify(VAR_FOREACH_DATA);
         PSet("basglobal", "URL_ADRESS_SCTG_MALGNVAWU", val)
         _break("function")
         })!
         })!
         })!
         VAR_LIST_CONTAINS = (VAR_LIST_URLS_SCTG).indexOf(JSON.parse(P("basglobal", "URL_ADRESS_SCTG_MALGNVAWU") || '""')) >= 0
         _set_if_expression("W1tMSVNUX0NPTlRBSU5TXV0gPT0gZmFsc2U=");
         _if(VAR_LIST_CONTAINS == false,function(){
         fail((_K==="en" ? "No access to SCTG servers" : "Нет доступа к серверам SCTG"));
         })!
         VAR_SERVERURL_MODULE = JSON.parse(P("basglobal", "URL_ADRESS_SCTG_MALGNVAWU") || '""')
         

      })!
      

      
      
      _if(!_cycle_params().if_else,function(){
      
         
         
         VAR_SERVERURL_MODULE = "http://api.multibot.in"
         

      })!
      delete _cycle_params().if_else;
      

      
      
      _cycle_params().if_else = VAR_MAIN_FRAME_CHECKBOX_MODULE.length == 0;
      _set_if_expression("W1tNQUlOX0ZSQU1FX0NIRUNLQk9YX01PRFVMRV1dLmxlbmd0aCA9PSAw");
      _if(_cycle_params().if_else,function(){
      
         
         
         VAR_CHECKBOX_IS_MODULE = false
         

      })!
      

      
      
      _if(!_cycle_params().if_else,function(){
      
         
         
         VAR_CHECKBOX_IS_MODULE = Boolean(native("regexp", "ismatch", JSON.stringify({text: VAR_MAIN_FRAME_CHECKBOX_MODULE[0],regexp:"(\u003eFRAME\u003e)"})) == "true")
         

      })!
      delete _cycle_params().if_else;
      

      
      
      _cycle_params().if_else = VAR_NOW_SPEED_MODULE != "No clicks";
      _set_if_expression("W1tOT1dfU1BFRURfTU9EVUxFXV0gIT0gIk5vIGNsaWNrcyI=");
      _if(_cycle_params().if_else,function(){
      
         
         
         VAR_SETTINGS_SPEED_MODULE = {
         "Slow": { SPEED: 100, GRAVITY: 6, DEVIATION: 2.5 },
         "Normal": { SPEED: 200, GRAVITY: 12, DEVIATION: 5 },
         "Fast": { SPEED: 300, GRAVITY: 18, DEVIATION: 7.5 },
         "Very Fast": { SPEED: 500, GRAVITY: 30, DEVIATION: 12 },
         "Extreme": { SPEED: 999, GRAVITY: 30, DEVIATION: 15 }
         };
         VAR_SETTINGS_SPEED_MODULE = VAR_SETTINGS_SPEED_MODULE[VAR_NOW_SPEED_MODULE]
         

      })!
      

      
      
      _if(!_cycle_params().if_else,function(){
      
         
         
         VAR_SETTINGS_SPEED_MODULE = { SPEED: 999, GRAVITY: 30, DEVIATION: 15 }
         

      })!
      delete _cycle_params().if_else;
      

      
      
      VAR_TASK_TYPE_MODULE = ""
      

      
      
      _do(function(){
      _set_action_info({ name: "For" });
      VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(0)
      if(VAR_CYCLE_INDEX > parseInt(parseInt(VAR_TRY_SOLVED_MODULE)))_break();
      
         
         
         VAR_NOW_SOLVER_TRY_MODULE = VAR_CYCLE_INDEX
         

         
         
         _set_if_expression("W1tDWUNMRV9JTkRFWF1dICE9IDA=");
         _if(VAR_CYCLE_INDEX != 0,function(){
         
            
            
            sleep(1500)!
            

         })!
         

         
         
         VAR_MAIN_FRAME_SOLVER_MODULE_NOW = ""
         

         
         
         _do(function(){
         _set_action_info({ name: "For" });
         VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(0)
         if(VAR_CYCLE_INDEX > parseInt(60))_break();
         
            
            
            _set_if_expression("W1tOT1dfU1BFRURfTU9EVUxFXV0gIT0gIk5vIGNsaWNrcyIgJiYgcmFuZCgwLDEwKSA+IDg=");
            _if(VAR_NOW_SPEED_MODULE != "No clicks" && rand(0,10) > 8,function(){
            
               
               
               _get_browser_screen_settings()!
               ;(function(){
               var result = JSON.parse(_result())
               VAR_1 = result["ScrollX"]
               VAR_1 = result["ScrollY"]
               VAR_CURSOR_ABSOLUTE_X_MODULE = result["CursorX"]
               VAR_CURSOR_ABSOLUTE_Y_MODULE = result["CursorY"]
               VAR_1 = result["Width"]
               VAR_1 = result["Height"]
               })();
               

               
               
               VAR_X_MODULE = rand(-250,250)
               if (VAR_CURSOR_ABSOLUTE_X_MODULE + VAR_X_MODULE < 0){
               VAR_X_MODULE = rand(0, 1000)
               }else{
               VAR_X_MODULE = VAR_CURSOR_ABSOLUTE_X_MODULE + VAR_X_MODULE
               }
               VAR_Y_MODULE = rand(-250,250)
               if (VAR_CURSOR_ABSOLUTE_Y_MODULE + VAR_Y_MODULE < 0){
               VAR_Y_MODULE = rand(0, 800)
               }else{
               VAR_Y_MODULE = VAR_CURSOR_ABSOLUTE_Y_MODULE + VAR_Y_MODULE
               }
               

               
               
               /*Browser*/
               move(VAR_X_MODULE,VAR_Y_MODULE,  {"speed": VAR_SETTINGS_SPEED_MODULE["SPEED"],"gravity": VAR_SETTINGS_SPEED_MODULE["GRAVITY"],"deviation": VAR_SETTINGS_SPEED_MODULE["DEVIATION"]} )!
               

            })!
            

            
            
            VAR_MAIN_CYCLE_INDEX_MODULE = VAR_CYCLE_INDEX
            

            
            
            _set_if_expression("W1tNQUlOX0NZQ0xFX0lOREVYX01PRFVMRV1dID49IDggJiYgW1tDQVBUQ0hBX1NPTFZFRF1d");
            _if(VAR_MAIN_CYCLE_INDEX_MODULE >= 8 && VAR_CAPTCHA_SOLVED,function(){
            
               
               
               _function_return("")
               

            })!
            

            
            
            _set_if_expression("W1tDSEVDS0JPWF9JU19NT0RVTEVdXQ==");
            _if(typeof(VAR_CHECKBOX_IS_MODULE) !== "undefined" ? (VAR_CHECKBOX_IS_MODULE) : undefined,function(){
            
               
               
               _do_with_params({"foreach_data":(VAR_MAIN_FRAME_CHECKBOX_MODULE)},function(){
               _set_action_info({ name: "Foreach" });
               VAR_CYCLE_INDEX = _iterator() - 1
               if(VAR_CYCLE_INDEX > _cycle_param("foreach_data").length - 1)_break();
               VAR_FOREACH_DATA = _cycle_param("foreach_data")[VAR_CYCLE_INDEX]
               
                  
                  
                  /*Browser*/
                  ;_SELECTOR=VAR_FOREACH_DATA + " \u003eXPATH\u003e//img[@src=\u0022data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAYAAACqaXHeAAAABmJLR0QA/wD/AP+gvaeTAAAC00lEQVR4nO2aTU8TQRyHn39bIdXEm3jwLQhefPkAJorYLYslIF64ohwM8eQH0A/gzYSLIRooxBORKJr4Ultq4smz8YgQb3ow4YAmUHY8IEpgd7vQ3e0smee4+5/uPL+daXdmCwaDwWAwGAwGg8FgMBgM+wBr0u7JFe17QWrTUXcmbqxJuwdhTpDejsHO7Ne5hbJf/b4KYFMeJAuAcKleCPsmgB3ymwiX2m901BZfLHx0a5eKpXcR4ykPgPqdEvnk1Vai7Fgc1JMXkevlm+88p0CiA2hUHhIcQBjykNAAwpKHBAYQpjwkLICw5SFBAUQhDwkJICp5SEAAUcqD5gFELQ8aBxCHPGgaQFzyoGEAccpDwNXgxZmhLCr6sPJTvXk/eRSDYcpDgAAGxgcOZleW31hF+1GUIViTdo9S6qXfna+MlN6HfV3fAApjhdZfrauzInIFkdGoQoh72G/FM4ChmaGW1cPOM+Dav4MRhNBMefAJ4OfK8hjQv+OEyKhV7H0YRgjNmPPb8QxgndQDYMn1pHC30ZHQrDm/Hc8APoy8XVK1dDew6FrQwHTIFe0uRJ43a9hvpW7nc0/6TklmvQq0uxYoNV65VbqDoIJcMFe0uwR5DRxy+bBY5SHgg1B+On9SOZkqqNOuBQFD0E0edvEkuBFCeh7ocC2oE4KO8rCL9wLl4fK3tKOuAguuBT7fCbrKwx7WAvaEfcJJybyCTteCbSNBZ3nY42Ko+2nheKbmVOuFkJuyL+ssDw2sBnNT/cdErVWBMx4ls6D6/B5y4vidr0dDT3PWY+soBzLzwNngrfS485s09HK0crvynbVaDvgSrIVe8hDShsjfkVABznlX6ScPIe4I2dN2W82RisD5nWf1lIeQt8Tsabtt3aEMcuH/UX3lIeQ/SJSGSz9anLQF6vPGEb3lIaJN0cJE4ciaOK9IcV9n+WiJYRPVYDAYDAaDoRH+ALzfixyrasnFAAAAAElFTkSuQmCC\u0022]";
                  get_element_selector(_SELECTOR, false).nowait().exist()!
                  VAR_IS_EXISTS = _result() == 1
                  _if(VAR_IS_EXISTS, function(){
                  get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
                  VAR_IS_EXISTS = _result().indexOf("true")>=0
                  })!
                  

                  
                  
                  _set_if_expression("W1tJU19FWElTVFNdXQ==");
                  _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
                  
                     
                     
                     _function_return("")
                     

                  })!
                  

                  
                  
                  /*Browser*/
                  ;_SELECTOR=VAR_FOREACH_DATA + " \u003eXPATH\u003e //div[@id=\u0022status\u0022 and @style=\u0022display: block; color: rgb(191, 23, 34); font-size: 10px; top: 5px; left: 5px; position: absolute;\u0022]";
                  get_element_selector(_SELECTOR, false).nowait().exist()!
                  VAR_IS_EXISTS = _result() == 1
                  _if(VAR_IS_EXISTS, function(){
                  get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
                  VAR_IS_EXISTS = _result().indexOf("true")>=0
                  })!
                  

                  
                  
                  _set_if_expression("W1tJU19FWElTVFNdXQ==");
                  _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
                  
                     
                     
                     fail_user("ip banned",false)
                     

                  })!
                  

               })!
               

            })!
            

            
            
            _set_if_expression("W1tNQUlOX0NZQ0xFX0lOREVYX01PRFVMRV1dID09IDcgJiYgW1tDSEVDS0JPWF9JU19NT0RVTEVdXSB8fCBbW01BSU5fQ1lDTEVfSU5ERVhfTU9EVUxFXV0gPT0gMTEgJiYgW1tDSEVDS0JPWF9JU19NT0RVTEVdXQ==");
            _if(VAR_MAIN_CYCLE_INDEX_MODULE == 7 && VAR_CHECKBOX_IS_MODULE || VAR_MAIN_CYCLE_INDEX_MODULE == 11 && VAR_CHECKBOX_IS_MODULE,function(){
            
               
               
               _do_with_params({"foreach_data":(VAR_MAIN_FRAME_CHECKBOX_MODULE)},function(){
               _set_action_info({ name: "Foreach" });
               VAR_CYCLE_INDEX = _iterator() - 1
               if(VAR_CYCLE_INDEX > _cycle_param("foreach_data").length - 1)_break();
               VAR_FOREACH_DATA = _cycle_param("foreach_data")[VAR_CYCLE_INDEX]
               
                  
                  
                  /*Browser*/
                  ;_SELECTOR=VAR_FOREACH_DATA + " \u003eCSS\u003e #checkbox";
                  get_element_selector(_SELECTOR, false).nowait().exist()!
                  VAR_IS_EXISTS = _result() == 1
                  _if(VAR_IS_EXISTS, function(){
                  get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
                  VAR_IS_EXISTS = _result().indexOf("true")>=0
                  })!
                  

                  
                  
                  _set_if_expression("W1tJU19FWElTVFNdXQ==");
                  _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
                  
                     
                     
                     _cycle_params().if_else = VAR_NOW_SPEED_MODULE != "No clicks";
                     _set_if_expression("W1tOT1dfU1BFRURfTU9EVUxFXV0gIT0gIk5vIGNsaWNrcyI=");
                     _if(_cycle_params().if_else,function(){
                     
                        
                        
                        /*Browser*/
                        _SELECTOR = VAR_FOREACH_DATA + " \u003eCSS\u003e #checkbox";
                        wait_element_visible(_SELECTOR)!
                        _call(_random_point, {})!
                        _if(_result().length > 0, function(){
                        move( {"speed": VAR_SETTINGS_SPEED_MODULE["SPEED"],"gravity": VAR_SETTINGS_SPEED_MODULE["GRAVITY"],"deviation": VAR_SETTINGS_SPEED_MODULE["DEVIATION"]} )!
                        get_element_selector(_SELECTOR, false).clarify(X,Y)!
                        _call(_clarify, {"speed": VAR_SETTINGS_SPEED_MODULE["SPEED"],"gravity": VAR_SETTINGS_SPEED_MODULE["GRAVITY"],"deviation": VAR_SETTINGS_SPEED_MODULE["DEVIATION"]} )!
                        mouse(X,Y)!
                        })!
                        

                     })!
                     

                     
                     
                     _if(!_cycle_params().if_else,function(){
                     
                        
                        
                        /*Browser*/
                        _SELECTOR = VAR_FOREACH_DATA + " \u003eCSS\u003e #checkbox";
                        wait_element_visible(_SELECTOR)!
                        _call(_random_point, {})!
                        _if(_result().length > 0, function(){
                        X = parseInt(_result().split(",")[0])
                        Y = parseInt(_result().split(",")[1])
                        mouse(X,Y)!
                        })!
                        

                     })!
                     delete _cycle_params().if_else;
                     

                     
                     
                     _break("function")
                     

                  })!
                  

               })!
               

               
               
               _call(function()
               {
               _on_fail(function(){
               VAR_LAST_ERROR = _result()
               VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
               VAR_WAS_ERROR = false
               _break(1,true)
               })
               CYCLES.Current().RemoveLabel("function")
               
                  
                  
                  /*Browser*/
                  waiter_timeout_next(15000)
                  wait_load("*hcaptcha.*getcaptcha*")!
                  cache_get_base64("*hcaptcha.*getcaptcha*")!
                  VAR_SAVED_CACHE_MODULE = _result()
                  

               },null)!
               

            })!
            

            
            
            _do_with_params({"foreach_data":(VAR_MAIN_FRAME_SOLVER_MODULE)},function(){
            _set_action_info({ name: "Foreach" });
            VAR_CYCLE_INDEX = _iterator() - 1
            if(VAR_CYCLE_INDEX > _cycle_param("foreach_data").length - 1)_break();
            VAR_FOREACH_DATA = _cycle_param("foreach_data")[VAR_CYCLE_INDEX]
            
               
               
               /*Browser*/
               ;_SELECTOR=VAR_FOREACH_DATA + " \u003eXPATH\u003e //div[@class=\u0022task-grid\u0022]/div\u003eAT\u003e8";
               get_element_selector(_SELECTOR, false).nowait().exist()!
               VAR_IS_EXISTS = _result() == 1
               _if(VAR_IS_EXISTS, function(){
               get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
               VAR_IS_EXISTS = _result().indexOf("true")>=0
               })!
               

               
               
               _set_if_expression("W1tJU19FWElTVFNdXQ==");
               _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
               
                  
                  
                  _set_if_expression("W1tUQVNLX1RZUEVfTU9EVUxFXV0gIT0gIkdyaWQiIHx8IFtbTUFJTl9DWUNMRV9JTkRFWF9NT0RVTEVdXSA+PSA2");
                  _if(VAR_TASK_TYPE_MODULE != "Grid" || VAR_MAIN_CYCLE_INDEX_MODULE >= 6,function(){
                  
                     
                     
                     VAR_MAIN_FRAME_SOLVER_MODULE_NOW = VAR_FOREACH_DATA
                     

                     
                     
                     VAR_TASK_TYPE_MODULE = "Grid"
                     

                     
                     
                     _break("function")
                     

                  })!
                  

               })!
               

               
               
               /*Browser*/
               ;_SELECTOR=VAR_FOREACH_DATA + "  \u003eXPATH\u003e //div[@class=\u0022challenge-prompt\u0022]/*[@class=\u0022prompt-text\u0022]";
               get_element_selector(_SELECTOR, false).nowait().exist()!
               VAR_IS_EXISTS = _result() == 1
               _if(VAR_IS_EXISTS, function(){
               get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
               VAR_IS_EXISTS = _result().indexOf("true")>=0
               })!
               

               
               
               _set_if_expression("W1tJU19FWElTVFNdXQ==");
               _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
               
                  
                  
                  _set_if_expression("W1tUQVNLX1RZUEVfTU9EVUxFXV0gIT0gIkNhbnZhcyIgfHwgW1tNQUlOX0NZQ0xFX0lOREVYX01PRFVMRV1dID49IDY=");
                  _if(VAR_TASK_TYPE_MODULE != "Canvas" || VAR_MAIN_CYCLE_INDEX_MODULE >= 6,function(){
                  
                     
                     
                     VAR_MAIN_FRAME_SOLVER_MODULE_NOW = VAR_FOREACH_DATA
                     

                     
                     
                     VAR_TASK_TYPE_MODULE = "Canvas"
                     

                     
                     
                     _break("function")
                     

                  })!
                  

               })!
               

            })!
            

            
            
            _set_if_expression("W1tNQUlOX0ZSQU1FX1NPTFZFUl9NT0RVTEVfTk9XXV0gIT0gIiI=");
            _if(VAR_MAIN_FRAME_SOLVER_MODULE_NOW != "",function(){
            
               
               
               _break("function")
               

            })!
            

            
            
            sleep(1000)!
            

         })!
         

         
         
         _set_if_expression("W1tOT1dfU09MVkVSX1RSWV9NT0RVTEVdXSA+PSBwYXJzZUludChbW1RSWV9TT0xWRURfTU9EVUxFXV0p");
         _if(VAR_NOW_SOLVER_TRY_MODULE >= parseInt(VAR_TRY_SOLVED_MODULE),function(){
         
            
            
            fail_user("Не решил капчу, закончились попытки решения",false)
            

         })!
         

         
         
         _call(function()
         {
         _on_fail(function(){
         VAR_LAST_ERROR = _result()
         VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
         VAR_WAS_ERROR = false
         _break(1,true)
         })
         CYCLES.Current().RemoveLabel("function")
         
            
            
            /*Browser*/
            waiter_timeout_next(15000)
            wait_load("*img*hcaptcha.*/*")!
            cache_get_base64("*img*hcaptcha.*/*")!
            VAR_SAVED_CACHE_MODULE = _result()
            

         },null)!
         

         
         
         /*Browser*/
         ;_SELECTOR=VAR_MAIN_FRAME_SOLVER_MODULE_NOW + " \u003eXPATH\u003e //div[@class=\u0022language-selector\u0022]/div[@id=\u0022display-language\u0022]/div";
         get_element_selector(_SELECTOR, false).nowait().exist()!
         VAR_IS_EXISTS = _result() == 1
         _if(VAR_IS_EXISTS, function(){
         get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
         VAR_IS_EXISTS = _result().indexOf("true")>=0
         })!
         

         
         
         _set_if_expression("W1tJU19FWElTVFNdXQ==");
         _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
         
            
            
            /*Browser*/
            _SELECTOR = VAR_MAIN_FRAME_SOLVER_MODULE_NOW + " \u003eXPATH\u003e //div[@class=\u0022language-selector\u0022]/div[@id=\u0022display-language\u0022]/div";
            wait_element(_SELECTOR)!
            get_element_selector(_SELECTOR, false).text()!
            VAR_SAVED_TEXT_MODULE = _result()
            

            
            
            _set_if_expression("W1tTQVZFRF9URVhUX01PRFVMRV1dLmluZGV4T2YoJ0VuZ2xpc2gnKSA9PSAtMSAmJiBbW1NBVkVEX1RFWFRfTU9EVUxFXV0uaW5kZXhPZignRU4nKSA9PSAtMSAmJiBbW1NBVkVEX1RFWFRfTU9EVUxFXV0uaW5kZXhPZignRW4nKSA9PSAtMQ==");
            _if(VAR_SAVED_TEXT_MODULE.indexOf('English') == -1 && VAR_SAVED_TEXT_MODULE.indexOf('EN') == -1 && VAR_SAVED_TEXT_MODULE.indexOf('En') == -1,function(){
            
               
               
               _SELECTOR = VAR_MAIN_FRAME_SOLVER_MODULE_NOW;
               wait_element(_SELECTOR)!
               get_element_selector(_SELECTOR, false).script2("const select = document.getElementById('language-list');\r\nif (select) {\r\n  select.value = 'en'; // English\r\n  select.dispatchEvent(new Event('change', { bubbles: true }));\r\n}",JSON.stringify(_read_variables([])))!
               var _parse_result = JSON.parse(_result())
               _write_variables(JSON.parse(_parse_result.variables))
               if(!_parse_result.is_success)
               fail(_parse_result.error)
               

               
               
               _SELECTOR = VAR_MAIN_FRAME_SOLVER_MODULE_NOW;
               wait_element(_SELECTOR)!
               get_element_selector(_SELECTOR, false).script2("document.querySelector(\".language-selector .option:nth-child(23)\")?.click();",JSON.stringify(_read_variables([])))!
               var _parse_result = JSON.parse(_result())
               _write_variables(JSON.parse(_parse_result.variables))
               if(!_parse_result.is_success)
               fail(_parse_result.error)
               

               
               
               sleep(250)!
               

            })!
            

         })!
         

         
         
         _set_if_expression("W1tUQVNLX1RZUEVfTU9EVUxFXV0gPT0gIkdyaWQi");
         _if(VAR_TASK_TYPE_MODULE == "Grid",function(){
         
            
            
            /*Browser*/
            ;_SELECTOR=VAR_MAIN_FRAME_SOLVER_MODULE_NOW + "  \u003eXPATH\u003e //div[@class=\u0022challenge-example\u0022]/div[@class=\u0022image\u0022]/div[@class=\u0022image\u0022]";
            get_element_selector(_SELECTOR, false).nowait().exist()!
            VAR_IS_EXISTS = _result() == 1
            _if(VAR_IS_EXISTS, function(){
            get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
            VAR_IS_EXISTS = _result().indexOf("true")>=0
            })!
            

            
            
            _cycle_params().if_else = typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined;
            _set_if_expression("W1tJU19FWElTVFNdXQ==");
            _if(_cycle_params().if_else,function(){
            
               
               
               /*Browser*/
               _SELECTOR = VAR_MAIN_FRAME_SOLVER_MODULE_NOW + "  \u003eXPATH\u003e //div[@class=\u0022challenge-example\u0022]/div[@class=\u0022image\u0022]/div[@class=\u0022image\u0022]";
               wait_element(_SELECTOR)!
               get_element_selector(_SELECTOR, false).xml()!
               VAR_SAVED_XML_MODULE = _result()
               

            })!
            

            
            
            _if(!_cycle_params().if_else,function(){
            
               
               
               VAR_SAVED_XML_MODULE = ""
               

            })!
            delete _cycle_params().if_else;
            

            
            
            VAR_TASK_IMG_URL_MODULE = native("regexp", "scan", JSON.stringify({text: VAR_SAVED_XML_MODULE,regexp:"url\u005c(\u0026quot;([^\u005c(\u005c);]+?)\u0026quot;\u005c)"}))
            if(VAR_TASK_IMG_URL_MODULE.length == 0)
            VAR_TASK_IMG_URL_MODULE = []
            else
            VAR_TASK_IMG_URL_MODULE = JSON.parse(VAR_TASK_IMG_URL_MODULE)
            

            
            
            /*Browser*/
            _SELECTOR = VAR_MAIN_FRAME_SOLVER_MODULE_NOW + "  \u003eXPATH\u003e //div[@class=\u0022challenge-prompt\u0022]//*[@class=\u0022prompt-text\u0022]/*";
            wait_element(_SELECTOR)!
            get_element_selector(_SELECTOR, false).text()!
            VAR_PROMT_TEXT_MODULE = _result()
            

            
            
            /*Browser*/
            _SELECTOR = VAR_MAIN_FRAME_SOLVER_MODULE_NOW + "  \u003eXPATH\u003e //div[@class=\u0022task-grid\u0022]";
            wait_element(_SELECTOR)!
            get_element_selector(_SELECTOR, false).xml()!
            VAR_SAVED_XML_MODULE = _result()
            

            
            
            html_parser_xpath_parse(VAR_SAVED_XML_MODULE)
            VAR_XPATH_XML_LIST_MODULE = html_parser_xpath_xml_list("//div[@class=\u0022task-grid\u0022]/*[@class=\u0022task\u0022]//div[@class=\u0022image\u0022]/@style")
            

            
            
            _SELECTOR = VAR_MAIN_FRAME_SOLVER_MODULE_NOW + " ";
            wait_element(_SELECTOR)!
            get_element_selector(_SELECTOR, false).script2("async function createImageFromStyles(styles, rows = 3, cols = 3) {\r\n  const canvasSize = 128;  // Кожне зображення 120x120 згідно з прикладом\r\n  const finalCanvas = document.createElement('canvas');\r\n  finalCanvas.width = canvasSize * cols;\r\n  finalCanvas.height = canvasSize * rows;\r\n  const ctx = finalCanvas.getContext('2d');\r\n\r\n  for (let i = 0; i < styles.length; i++) {\r\n    const backgroundImage = extractUrlFromStyle(styles[i]);\r\n    if (backgroundImage) {\r\n      const img = await createImageElement(backgroundImage);\r\n      const x = (i % cols) * canvasSize;\r\n      const y = Math.floor(i / cols) * canvasSize;\r\n      ctx.drawImage(img, 0, 0, img.width, img.height, x, y, canvasSize, canvasSize);\r\n    }\r\n  }\r\n\r\n  return finalCanvas.toDataURL(\"image/png\");\r\n\r\n  // Витягує URL з CSS background\r\n  function extractUrlFromStyle(style) {\r\n    const match = style.match(/url\\([\"']?(.+?)[\"']?\\)/);\r\n    return match ? match[1] : null;\r\n  }\r\n\r\n  // Створює Image-елемент без повторного завантаження, якщо зображення вже є в браузері\r\n  function createImageElement(url) {\r\n    return new Promise((resolve, reject) => {\r\n      const img = new Image();\r\n      img.crossOrigin = \"anonymous\";  // Дозволяє малювати CORS-зображення\r\n      img.onload = () => resolve(img);\r\n      img.onerror = reject;\r\n      img.src = url;\r\n    });\r\n  }\r\n}\r\n\r\n\r\n\r\nconst base64Image = await createImageFromStyles([[XPATH_XML_LIST_MODULE]]);\r\n[[IMAGE_IN_BASE64_MODULE]] = base64Image.split(\",\")[1]",JSON.stringify(_read_variables(["VAR_XPATH_XML_LIST_MODULE","VAR_IMAGE_IN_BASE64_MODULE"])))!
            var _parse_result = JSON.parse(_result())
            _write_variables(JSON.parse(_parse_result.variables))
            if(!_parse_result.is_success)
            fail(_parse_result.error)
            

            
            
            VAR_POST_REQ_MODULE = JSON.stringify({
            "clientKey": VAR_USER_APIKEY_MODULE,
            "type":"hCaptchaBase64",
            "task": {
            "request_type": VAR_TASK_TYPE_MODULE,
            "question": VAR_PROMT_TEXT_MODULE,
            "body": VAR_IMAGE_IN_BASE64_MODULE,
            "examples": VAR_TASK_IMG_URL_MODULE
            }
            })
            

            
            
            _do(function(){
            _set_action_info({ name: "For" });
            VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(0)
            if(VAR_CYCLE_INDEX > parseInt(5))_break();
            
               
               
               _set_if_expression("W1tDWUNMRV9JTkRFWF1dID49IDM=");
               _if(VAR_CYCLE_INDEX >= 3,function(){
               
                  
                  
                  fail_user("Ошибка при отправке запроса на сервис решения",false)
                  

               })!
               

               
               
               _switch_http_client_internal()
               http_client_set_fail_on_error(false)
               http_client_post(VAR_SERVERURL_MODULE + "/createTask/", ["data", VAR_POST_REQ_MODULE], {"content-type":"custom/" + ("application/json"), "encoding":("UTF-8"), "method":("POST"),headers:("")})!
               VAR_SERVICE_RESULT_MODULE = http_client_encoded_content("utf-8")
               _switch_http_client_main()
               http_client_set_fail_on_error(true)
               

               
               
               _call(function()
               {
               _on_fail(function(){
               VAR_LAST_ERROR = _result()
               VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
               VAR_WAS_ERROR = false
               _break(1,true)
               })
               CYCLES.Current().RemoveLabel("function")
               
                  
                  
                  VAR_SERVICE_RESULT_MODULE = JSON.parse(VAR_SERVICE_RESULT_MODULE);
                  

               },null)!
               

               
               
               _set_if_expression("W1tXQVNfRVJST1JdXQ==");
               _if(typeof(VAR_WAS_ERROR) !== "undefined" ? (VAR_WAS_ERROR) : undefined,function(){
               
                  
                  
                  sleep(500)!
                  

                  
                  
                  _next("function")
                  

               })!
               

               
               
               _break("function")
               

            })!
            

            
            
            VAR_TASK_ID_MODULE = VAR_SERVICE_RESULT_MODULE.taskId
            

            
            
            VAR_POST_REQ_MODULE = JSON.stringify({
            "clientKey":VAR_USER_APIKEY_MODULE,
            "taskId": VAR_TASK_ID_MODULE
            })
            

            
            
            VAR_STATUS_MODULE = "processing"
            

            
            
            _do(function(){
            _set_action_info({ name: "For" });
            VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(0)
            if(VAR_CYCLE_INDEX > parseInt(30))_break();
            
               
               
               _set_if_expression("W1tDWUNMRV9JTkRFWF1dIDwgNQ==");
               _if(VAR_CYCLE_INDEX < 5,function(){
               
                  
                  
                  _set_if_expression("W1tOT1dfU1BFRURfTU9EVUxFXV0gIT0gIk5vIGNsaWNrcyIgJiYgcmFuZCgwLDEwKSA+IDc=");
                  _if(VAR_NOW_SPEED_MODULE != "No clicks" && rand(0,10) > 7,function(){
                  
                     
                     
                     _get_browser_screen_settings()!
                     ;(function(){
                     var result = JSON.parse(_result())
                     VAR_1 = result["ScrollX"]
                     VAR_1 = result["ScrollY"]
                     VAR_CURSOR_ABSOLUTE_X_MODULE = result["CursorX"]
                     VAR_CURSOR_ABSOLUTE_Y_MODULE = result["CursorY"]
                     VAR_1 = result["Width"]
                     VAR_1 = result["Height"]
                     })();
                     

                     
                     
                     VAR_X_MODULE = rand(-250,250)
                     if (VAR_CURSOR_ABSOLUTE_X_MODULE + VAR_X_MODULE < 0){
                     VAR_X_MODULE = rand(0, 1000)
                     }else{
                     VAR_X_MODULE = VAR_CURSOR_ABSOLUTE_X_MODULE + VAR_X_MODULE
                     }
                     VAR_Y_MODULE = rand(-250,250)
                     if (VAR_CURSOR_ABSOLUTE_Y_MODULE + VAR_Y_MODULE < 0){
                     VAR_Y_MODULE = rand(0, 800)
                     }else{
                     VAR_Y_MODULE = VAR_CURSOR_ABSOLUTE_Y_MODULE + VAR_Y_MODULE
                     }
                     

                     
                     
                     /*Browser*/
                     move(VAR_X_MODULE,VAR_Y_MODULE,  {"speed": VAR_SETTINGS_SPEED_MODULE["SPEED"],"gravity": VAR_SETTINGS_SPEED_MODULE["GRAVITY"],"deviation": VAR_SETTINGS_SPEED_MODULE["DEVIATION"]} )!
                     

                  })!
                  

               })!
               

               
               
               sleep(1000)!
               

               
               
               _switch_http_client_internal()
               http_client_set_fail_on_error(false)
               http_client_post(VAR_SERVERURL_MODULE + "/getTaskResult/", ["data", VAR_POST_REQ_MODULE], {"content-type":"custom/" + ("application/json"), "encoding":("UTF-8"), "method":("POST"),headers:("")})!
               VAR_SERVICE_RESULT_MODULE = http_client_encoded_content("utf-8")
               _switch_http_client_main()
               http_client_set_fail_on_error(true)
               

               
               
               _call(function()
               {
               _on_fail(function(){
               VAR_LAST_ERROR = _result()
               VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
               VAR_WAS_ERROR = false
               _break(1,true)
               })
               CYCLES.Current().RemoveLabel("function")
               
                  
                  
                  VAR_SERVICE_RESULT_MODULE = JSON.parse(VAR_SERVICE_RESULT_MODULE);
                  

               },null)!
               

               
               
               _set_if_expression("W1tXQVNfRVJST1JdXQ==");
               _if(typeof(VAR_WAS_ERROR) !== "undefined" ? (VAR_WAS_ERROR) : undefined,function(){
               
                  
                  
                  _next("function")
                  

               })!
               

               
               
               VAR_STATUS_MODULE = VAR_SERVICE_RESULT_MODULE.status
               

               
               
               _set_if_expression("W1tTVEFUVVNfTU9EVUxFXV0gIT0gInByb2Nlc3Npbmci");
               _if(VAR_STATUS_MODULE != "processing",function(){
               
                  
                  
                  _break("function")
                  

               })!
               

            })!
            

            
            
            _set_if_expression("W1tTVEFUVVNfTU9EVUxFXV0gIT0gInJlYWR5Ig==");
            _if(VAR_STATUS_MODULE != "ready",function(){
            
               
               
               /*Browser*/
               ;_SELECTOR=VAR_MAIN_FRAME_SOLVER_MODULE + " \u003eCSS\u003e .refresh-off";
               get_element_selector(_SELECTOR, false).nowait().exist()!
               VAR_IS_EXISTS_MODULE = _result() == 1
               _if(VAR_IS_EXISTS_MODULE, function(){
               get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
               VAR_IS_EXISTS_MODULE = _result().indexOf("true")>=0
               })!
               

               
               
               _cycle_params().if_else = typeof(VAR_IS_EXISTS_MODULE) !== "undefined" ? (VAR_IS_EXISTS_MODULE) : undefined;
               _set_if_expression("W1tJU19FWElTVFNfTU9EVUxFXV0=");
               _if(_cycle_params().if_else,function(){
               
                  
                  
                  /*Browser*/
                  _SELECTOR = VAR_MAIN_FRAME_SOLVER_MODULE + " \u003eCSS\u003e .refresh-off";
                  wait_element_visible(_SELECTOR)!
                  _call(_random_point, {})!
                  _if(_result().length > 0, function(){
                  move( {} )!
                  get_element_selector(_SELECTOR, false).clarify(X,Y)!
                  _call(_clarify, {} )!
                  mouse(X,Y)!
                  })!
                  

                  
                  
                  _next("function")
                  

               })!
               

               
               
               _if(!_cycle_params().if_else,function(){
               
                  
                  
                  fail_user("Сервис не решил капчу",false)
                  

               })!
               delete _cycle_params().if_else;
               

            })!
            

            
            
            VAR_ANSWERS_MODULE = VAR_SERVICE_RESULT_MODULE.answers
            

            
            
            _do_with_params({"foreach_data":(VAR_ANSWERS_MODULE)},function(){
            _set_action_info({ name: "Foreach" });
            VAR_CYCLE_INDEX = _iterator() - 1
            if(VAR_CYCLE_INDEX > _cycle_param("foreach_data").length - 1)_break();
            VAR_FOREACH_DATA = _cycle_param("foreach_data")[VAR_CYCLE_INDEX]
            
               
               
               _set_if_expression("W1tDWUNMRV9JTkRFWF1dICE9IDA=");
               _if(VAR_CYCLE_INDEX != 0,function(){
               
                  
                  
                  sleep(rand(250,400))!
                  

               })!
               

               
               
               _cycle_params().if_else = VAR_NOW_SPEED_MODULE != "No clicks";
               _set_if_expression("W1tOT1dfU1BFRURfTU9EVUxFXV0gIT0gIk5vIGNsaWNrcyI=");
               _if(_cycle_params().if_else,function(){
               
                  
                  
                  /*Browser*/
                  _SELECTOR = VAR_MAIN_FRAME_SOLVER_MODULE_NOW + "  \u003eXPATH\u003e //div[@class=\u0022task-grid\u0022]/*[@class=\u0022task\u0022]\u003eAT\u003e" + VAR_FOREACH_DATA;
                  wait_element_visible(_SELECTOR)!
                  _call(_random_point, {})!
                  _if(_result().length > 0, function(){
                  move( {"speed": VAR_SETTINGS_SPEED_MODULE["SPEED"],"gravity": VAR_SETTINGS_SPEED_MODULE["GRAVITY"],"deviation": VAR_SETTINGS_SPEED_MODULE["DEVIATION"]} )!
                  get_element_selector(_SELECTOR, false).clarify(X,Y)!
                  _call(_clarify, {"speed": VAR_SETTINGS_SPEED_MODULE["SPEED"],"gravity": VAR_SETTINGS_SPEED_MODULE["GRAVITY"],"deviation": VAR_SETTINGS_SPEED_MODULE["DEVIATION"]} )!
                  mouse(X,Y)!
                  })!
                  

               })!
               

               
               
               _if(!_cycle_params().if_else,function(){
               
                  
                  
                  /*Browser*/
                  _SELECTOR = VAR_MAIN_FRAME_SOLVER_MODULE_NOW + "  \u003eXPATH\u003e //div[@class=\u0022task-grid\u0022]/*[@class=\u0022task\u0022]\u003eAT\u003e" + VAR_FOREACH_DATA;
                  wait_element_visible(_SELECTOR)!
                  _call(_random_point, {})!
                  _if(_result().length > 0, function(){
                  X = parseInt(_result().split(",")[0])
                  Y = parseInt(_result().split(",")[1])
                  mouse(X,Y)!
                  })!
                  

               })!
               delete _cycle_params().if_else;
               

            })!
            

            
            
            VAR_CAPTCHA_SOLVED = true
            

            
            
            _cycle_params().if_else = VAR_NOW_SPEED_MODULE != "No clicks";
            _set_if_expression("W1tOT1dfU1BFRURfTU9EVUxFXV0gIT0gIk5vIGNsaWNrcyI=");
            _if(_cycle_params().if_else,function(){
            
               
               
               /*Browser*/
               _SELECTOR = VAR_MAIN_FRAME_SOLVER_MODULE_NOW + " \u003eCSS\u003e .button-submit";
               wait_element_visible(_SELECTOR)!
               _call(_random_point, {})!
               _if(_result().length > 0, function(){
               move( {"speed": VAR_SETTINGS_SPEED_MODULE["SPEED"],"gravity": VAR_SETTINGS_SPEED_MODULE["GRAVITY"],"deviation": VAR_SETTINGS_SPEED_MODULE["DEVIATION"]} )!
               get_element_selector(_SELECTOR, false).clarify(X,Y)!
               _call(_clarify, {"speed": VAR_SETTINGS_SPEED_MODULE["SPEED"],"gravity": VAR_SETTINGS_SPEED_MODULE["GRAVITY"],"deviation": VAR_SETTINGS_SPEED_MODULE["DEVIATION"]} )!
               mouse(X,Y)!
               })!
               

            })!
            

            
            
            _if(!_cycle_params().if_else,function(){
            
               
               
               /*Browser*/
               _SELECTOR = VAR_MAIN_FRAME_SOLVER_MODULE_NOW + " \u003eCSS\u003e .button-submit";
               wait_element_visible(_SELECTOR)!
               _call(_random_point, {})!
               _if(_result().length > 0, function(){
               X = parseInt(_result().split(",")[0])
               Y = parseInt(_result().split(",")[1])
               mouse(X,Y)!
               })!
               

            })!
            delete _cycle_params().if_else;
            

         })!
         

         
         
         _set_if_expression("W1tUQVNLX1RZUEVfTU9EVUxFXV0gPT0gIkNhbnZhcyI=");
         _if(VAR_TASK_TYPE_MODULE == "Canvas",function(){
         
            
            
            _SELECTOR = VAR_MAIN_FRAME_SOLVER_MODULE_NOW;
            wait_element(_SELECTOR)!
            get_element_selector(_SELECTOR, false).script2("try {\r\n    const canvas = document.querySelector('canvas');\r\n    const base64Image = canvas.toDataURL('image/png');\r\n    [[IMAGE_IN_BASE64_MODULE]] = base64Image.split(\",\")[1]\r\n    [[CANVAS_WIDTH_MODULE]] = canvas.width\r\n    [[CANVAS_HEIGHT_MODULE]] = canvas.height\r\n} catch (e) {\r\n    const base64Image = \"ERR\";\r\n    [[IMAGE_IN_BASE64_MODULE]] = base64Image\r\n}\r\n\r\n\r\n",JSON.stringify(_read_variables(["VAR_IMAGE_IN_BASE64_MODULE","VAR_CANVAS_WIDTH_MODULE","VAR_CANVAS_HEIGHT_MODULE"])))!
            var _parse_result = JSON.parse(_result())
            _write_variables(JSON.parse(_parse_result.variables))
            if(!_parse_result.is_success)
            fail(_parse_result.error)
            

            
            
            _set_if_expression("W1tJTUFHRV9JTl9CQVNFNjRfTU9EVUxFXV0gPT0gIkVSUiI=");
            _if(VAR_IMAGE_IN_BASE64_MODULE == "ERR",function(){
            
               
               
               VAR_TASK_TYPE_MODULE = "Drag"
               

               
               
               /*Browser*/
               _SELECTOR = VAR_MAIN_FRAME_SOLVER_MODULE_NOW + "  \u003eCSS\u003e canvas";
               wait_element(_SELECTOR)!
               get_element_selector(_SELECTOR, false).exist()!
               _if(_result() == "1", function(){
               get_element_selector(_SELECTOR, false).render_base64()!
               VAR_IMAGE_IN_BASE64_MODULE = _result()
               })!
               

               
               
               /*Browser*/
               _SELECTOR = VAR_MAIN_FRAME_SOLVER_MODULE_NOW + " \u003eCSS\u003e canvas";
               wait_element(_SELECTOR)!
               get_element_selector(_SELECTOR, false).script("(function(){var rect = self.getBoundingClientRect();return (rect.left + positionx).toString() + '|' + (rect.top + positiony).toString() + '|' + (rect.right - rect.left).toString() + '|' + (rect.bottom - rect.top).toString()})();")!
               if(_result().length > 0)
               {
               var split = _result().split("|")
               VAR_1 = parseInt(split[0])
               VAR_1 = parseInt(split[1])
               VAR_CANVAS_WIDTH_MODULE = parseInt(split[2])
               VAR_CANVAS_HEIGHT_MODULE = parseInt(split[3])
               }
               

            })!
            

            
            
            /*Browser*/
            ;_SELECTOR=VAR_MAIN_FRAME_SOLVER_MODULE_NOW + " \u003eXPATH\u003e //div[@class=\u0022bounding-box-example\u0022]";
            get_element_selector(_SELECTOR, false).nowait().exist()!
            VAR_IS_EXISTS = _result() == 1
            _if(VAR_IS_EXISTS, function(){
            get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
            VAR_IS_EXISTS = _result().indexOf("true")>=0
            })!
            

            
            
            _cycle_params().if_else = typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined;
            _set_if_expression("W1tJU19FWElTVFNdXQ==");
            _if(_cycle_params().if_else,function(){
            
               
               
               /*Browser*/
               _SELECTOR = VAR_MAIN_FRAME_SOLVER_MODULE_NOW + " \u003eXPATH\u003e //div[@class=\u0022bounding-box-example\u0022]";
               wait_element(_SELECTOR)!
               get_element_selector(_SELECTOR, false).xml()!
               VAR_SAVED_XML_MODULE = _result()
               

               
               
               VAR_TASK_IMG_URL_MODULE = native("regexp", "scan", JSON.stringify({text: VAR_SAVED_XML_MODULE,regexp:"url\u005c(\u0026quot;([^\u005c(\u005c);]+?)\u0026quot;\u005c)"}))
               if(VAR_TASK_IMG_URL_MODULE.length == 0)
               VAR_TASK_IMG_URL_MODULE = []
               else
               VAR_TASK_IMG_URL_MODULE = JSON.parse(VAR_TASK_IMG_URL_MODULE)
               

            })!
            

            
            
            _if(!_cycle_params().if_else,function(){
            
               
               
               VAR_TASK_IMG_URL_MODULE = []
               

            })!
            delete _cycle_params().if_else;
            

            
            
            /*Browser*/
            _SELECTOR = VAR_MAIN_FRAME_SOLVER_MODULE_NOW + " \u003eXPATH\u003e //div[@class=\u0022challenge-prompt\u0022]/*[@class=\u0022prompt-text\u0022]";
            wait_element(_SELECTOR)!
            get_element_selector(_SELECTOR, false).text()!
            VAR_PROMT_TEXT_MODULE = _result()
            

            
            
            VAR_POST_REQ_MODULE = JSON.stringify({
            "clientKey": VAR_USER_APIKEY_MODULE,
            "type":"hCaptchaBase64",
            "task": {
            "request_type": VAR_TASK_TYPE_MODULE,
            "question": VAR_PROMT_TEXT_MODULE,
            "body": VAR_IMAGE_IN_BASE64_MODULE,
            "examples": VAR_TASK_IMG_URL_MODULE
            }
            })
            

            
            
            _do(function(){
            _set_action_info({ name: "For" });
            VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(0)
            if(VAR_CYCLE_INDEX > parseInt(5))_break();
            
               
               
               _set_if_expression("W1tDWUNMRV9JTkRFWF1dID49IDM=");
               _if(VAR_CYCLE_INDEX >= 3,function(){
               
                  
                  
                  fail_user("Ошибка при отправке запроса на сервис решения",false)
                  

               })!
               

               
               
               _switch_http_client_internal()
               http_client_set_fail_on_error(false)
               http_client_post(VAR_SERVERURL_MODULE + "/createTask/", ["data", VAR_POST_REQ_MODULE], {"content-type":"custom/" + ("application/json"), "encoding":("UTF-8"), "method":("POST"),headers:("")})!
               VAR_SERVICE_RESULT_MODULE = http_client_encoded_content("utf-8")
               _switch_http_client_main()
               http_client_set_fail_on_error(true)
               

               
               
               _call(function()
               {
               _on_fail(function(){
               VAR_LAST_ERROR = _result()
               VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
               VAR_WAS_ERROR = false
               _break(1,true)
               })
               CYCLES.Current().RemoveLabel("function")
               
                  
                  
                  VAR_SERVICE_RESULT_MODULE = JSON.parse(VAR_SERVICE_RESULT_MODULE);
                  

               },null)!
               

               
               
               _set_if_expression("W1tXQVNfRVJST1JdXQ==");
               _if(typeof(VAR_WAS_ERROR) !== "undefined" ? (VAR_WAS_ERROR) : undefined,function(){
               
                  
                  
                  sleep(500)!
                  

                  
                  
                  _next("function")
                  

               })!
               

               
               
               _break("function")
               

            })!
            

            
            
            VAR_TASK_ID_MODULE = VAR_SERVICE_RESULT_MODULE.taskId
            

            
            
            VAR_POST_REQ_MODULE = JSON.stringify({
            "clientKey":VAR_USER_APIKEY_MODULE,
            "taskId": VAR_TASK_ID_MODULE
            })
            

            
            
            VAR_STATUS_MODULE = "processing"
            

            
            
            _do(function(){
            _set_action_info({ name: "For" });
            VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(0)
            if(VAR_CYCLE_INDEX > parseInt(30))_break();
            
               
               
               _set_if_expression("W1tDWUNMRV9JTkRFWF1dIDwgNQ==");
               _if(VAR_CYCLE_INDEX < 5,function(){
               
                  
                  
                  _set_if_expression("W1tOT1dfU1BFRURfTU9EVUxFXV0gIT0gIk5vIGNsaWNrcyIgJiYgcmFuZCgwLDEwKSA+IDc=");
                  _if(VAR_NOW_SPEED_MODULE != "No clicks" && rand(0,10) > 7,function(){
                  
                     
                     
                     _get_browser_screen_settings()!
                     ;(function(){
                     var result = JSON.parse(_result())
                     VAR_1 = result["ScrollX"]
                     VAR_1 = result["ScrollY"]
                     VAR_CURSOR_ABSOLUTE_X_MODULE = result["CursorX"]
                     VAR_CURSOR_ABSOLUTE_Y_MODULE = result["CursorY"]
                     VAR_1 = result["Width"]
                     VAR_1 = result["Height"]
                     })();
                     

                     
                     
                     VAR_X_MODULE = rand(-250,250)
                     if (VAR_CURSOR_ABSOLUTE_X_MODULE + VAR_X_MODULE < 0){
                     VAR_X_MODULE = rand(0, 1000)
                     }else{
                     VAR_X_MODULE = VAR_CURSOR_ABSOLUTE_X_MODULE + VAR_X_MODULE
                     }
                     VAR_Y_MODULE = rand(-250,250)
                     if (VAR_CURSOR_ABSOLUTE_Y_MODULE + VAR_Y_MODULE < 0){
                     VAR_Y_MODULE = rand(0, 800)
                     }else{
                     VAR_Y_MODULE = VAR_CURSOR_ABSOLUTE_Y_MODULE + VAR_Y_MODULE
                     }
                     

                     
                     
                     /*Browser*/
                     move(VAR_X_MODULE,VAR_Y_MODULE,  {"speed": VAR_SETTINGS_SPEED_MODULE["SPEED"],"gravity": VAR_SETTINGS_SPEED_MODULE["GRAVITY"],"deviation": VAR_SETTINGS_SPEED_MODULE["DEVIATION"]} )!
                     

                  })!
                  

               })!
               

               
               
               sleep(1000)!
               

               
               
               _switch_http_client_internal()
               http_client_set_fail_on_error(false)
               http_client_post(VAR_SERVERURL_MODULE + "/getTaskResult/", ["data", VAR_POST_REQ_MODULE], {"content-type":"custom/" + ("application/json"), "encoding":("UTF-8"), "method":("POST"),headers:("")})!
               VAR_SERVICE_RESULT_MODULE = http_client_encoded_content("utf-8")
               _switch_http_client_main()
               http_client_set_fail_on_error(true)
               

               
               
               _call(function()
               {
               _on_fail(function(){
               VAR_LAST_ERROR = _result()
               VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
               VAR_WAS_ERROR = false
               _break(1,true)
               })
               CYCLES.Current().RemoveLabel("function")
               
                  
                  
                  VAR_SERVICE_RESULT_MODULE = JSON.parse(VAR_SERVICE_RESULT_MODULE);
                  

               },null)!
               

               
               
               _set_if_expression("W1tXQVNfRVJST1JdXQ==");
               _if(typeof(VAR_WAS_ERROR) !== "undefined" ? (VAR_WAS_ERROR) : undefined,function(){
               
                  
                  
                  _next("function")
                  

               })!
               

               
               
               VAR_STATUS_MODULE = VAR_SERVICE_RESULT_MODULE.status
               

               
               
               _set_if_expression("W1tTVEFUVVNfTU9EVUxFXV0gIT0gInByb2Nlc3Npbmci");
               _if(VAR_STATUS_MODULE != "processing",function(){
               
                  
                  
                  _break("function")
                  

               })!
               

            })!
            

            
            
            _set_if_expression("W1tTVEFUVVNfTU9EVUxFXV0gIT0gInJlYWR5Ig==");
            _if(VAR_STATUS_MODULE != "ready",function(){
            
               
               
               /*Browser*/
               ;_SELECTOR=VAR_MAIN_FRAME_SOLVER_MODULE + " \u003eCSS\u003e .refresh-off";
               get_element_selector(_SELECTOR, false).nowait().exist()!
               VAR_IS_EXISTS_MODULE = _result() == 1
               _if(VAR_IS_EXISTS_MODULE, function(){
               get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
               VAR_IS_EXISTS_MODULE = _result().indexOf("true")>=0
               })!
               

               
               
               _cycle_params().if_else = typeof(VAR_IS_EXISTS_MODULE) !== "undefined" ? (VAR_IS_EXISTS_MODULE) : undefined;
               _set_if_expression("W1tJU19FWElTVFNfTU9EVUxFXV0=");
               _if(_cycle_params().if_else,function(){
               
                  
                  
                  /*Browser*/
                  _SELECTOR = VAR_MAIN_FRAME_SOLVER_MODULE + " \u003eCSS\u003e .refresh-off";
                  wait_element_visible(_SELECTOR)!
                  _call(_random_point, {})!
                  _if(_result().length > 0, function(){
                  move( {} )!
                  get_element_selector(_SELECTOR, false).clarify(X,Y)!
                  _call(_clarify, {} )!
                  mouse(X,Y)!
                  })!
                  

                  
                  
                  _next("function")
                  

               })!
               

               
               
               _if(!_cycle_params().if_else,function(){
               
                  
                  
                  fail_user("Сервис не решил капчу",false)
                  

               })!
               delete _cycle_params().if_else;
               

            })!
            

            
            
            VAR_ANSWERS_MODULE = VAR_SERVICE_RESULT_MODULE.answers
            

            
            
            /*Browser*/
            _SELECTOR = VAR_MAIN_FRAME_SOLVER_MODULE_NOW + " \u003eCSS\u003e canvas";
            wait_element(_SELECTOR)!
            get_element_selector(_SELECTOR, false).script("(function(){var rect = self.getBoundingClientRect();return (rect.left + positionx).toString() + '|' + (rect.top + positiony).toString() + '|' + (rect.right - rect.left).toString() + '|' + (rect.bottom - rect.top).toString()})();")!
            if(_result().length > 0)
            {
            var split = _result().split("|")
            VAR_ABSOLUTE_X = parseInt(split[0])
            VAR_ABSOLUTE_Y = parseInt(split[1])
            VAR_WIDTH = parseInt(split[2])
            VAR_HEIGHT = parseInt(split[3])
            }
            

            
            
            _set_if_expression("W1tUQVNLX1RZUEVfTU9EVUxFXV0gPT0gIkRyYWci");
            _if(VAR_TASK_TYPE_MODULE == "Drag",function(){
            
               
               
               function chunkArray(arr, size) {
               var result = [];
               for (var i = 0; i < arr.length; i += size) {
               result.push(arr.slice(i, i + size));
               }
               return result;
               }
               const list = VAR_ANSWERS_MODULE;
               VAR_ANSWERS_MODULE = chunkArray(list, 2)
               

            })!
            

            
            
            _do_with_params({"foreach_data":(VAR_ANSWERS_MODULE)},function(){
            _set_action_info({ name: "Foreach" });
            VAR_CYCLE_INDEX = _iterator() - 1
            if(VAR_CYCLE_INDEX > _cycle_param("foreach_data").length - 1)_break();
            VAR_FOREACH_DATA = _cycle_param("foreach_data")[VAR_CYCLE_INDEX]
            
               
               
               _set_if_expression("W1tDWUNMRV9JTkRFWF1dICE9IDA=");
               _if(VAR_CYCLE_INDEX != 0,function(){
               
                  
                  
                  sleep(rand(250,400))!
                  

               })!
               

               
               
               _cycle_params().if_else = VAR_TASK_TYPE_MODULE == "Drag";
               _set_if_expression("W1tUQVNLX1RZUEVfTU9EVUxFXV0gPT0gIkRyYWci");
               _if(_cycle_params().if_else,function(){
               
                  
                  
                  _set_if_expression("W1tDWUNMRV9JTkRFWF1dICE9IDA=");
                  _if(VAR_CYCLE_INDEX != 0,function(){
                  
                     
                     
                     sleep(rand(500,1000))!
                     

                  })!
                  

                  
                  
                  /*Browser*/
                  move(parseInt(VAR_ABSOLUTE_X) + parseInt( VAR_FOREACH_DATA[0][0] * ( VAR_WIDTH / parseInt(VAR_CANVAS_WIDTH_MODULE) ) ) + rand(-4,4),parseInt(VAR_ABSOLUTE_Y)  + parseInt( VAR_FOREACH_DATA[0][1] * ( VAR_HEIGHT / parseInt(VAR_CANVAS_HEIGHT_MODULE) ) ) + rand(-4,4),  {"speed": VAR_SETTINGS_SPEED_MODULE["SPEED"],"gravity": VAR_SETTINGS_SPEED_MODULE["GRAVITY"],"deviation": VAR_SETTINGS_SPEED_MODULE["DEVIATION"]} )!
                  mouse_down(parseInt(VAR_ABSOLUTE_X) + parseInt( VAR_FOREACH_DATA[0][0] * ( VAR_WIDTH / parseInt(VAR_CANVAS_WIDTH_MODULE) ) ) + rand(-4,4),parseInt(VAR_ABSOLUTE_Y)  + parseInt( VAR_FOREACH_DATA[0][1] * ( VAR_HEIGHT / parseInt(VAR_CANVAS_HEIGHT_MODULE) ) ) + rand(-4,4))!
                  

                  
                  
                  sleep(rand(150,250))!
                  

                  
                  
                  /*Browser*/
                  move(parseInt(VAR_ABSOLUTE_X) + parseInt( VAR_FOREACH_DATA[1][0] * ( VAR_WIDTH / parseInt(VAR_CANVAS_WIDTH_MODULE) ) ) + rand(-25,25),parseInt(VAR_ABSOLUTE_Y)  + parseInt( VAR_FOREACH_DATA[1][1] * ( VAR_HEIGHT / parseInt(VAR_CANVAS_HEIGHT_MODULE) ) ) + rand(-25,25),  {"speed": VAR_SETTINGS_SPEED_MODULE["SPEED"],"gravity": VAR_SETTINGS_SPEED_MODULE["GRAVITY"],"deviation": VAR_SETTINGS_SPEED_MODULE["DEVIATION"]} )!
                  

                  
                  
                  sleep(rand(150,250))!
                  

                  
                  
                  /*Browser*/
                  var move_settings =  {"speed": VAR_SETTINGS_SPEED_MODULE["SPEED"],"gravity": VAR_SETTINGS_SPEED_MODULE["GRAVITY"],"deviation": VAR_SETTINGS_SPEED_MODULE["DEVIATION"]} ;
                  move_settings["do_mouse_up"] = "true"
                  move(parseInt(VAR_ABSOLUTE_X) + parseInt( VAR_FOREACH_DATA[1][0] * ( VAR_WIDTH / parseInt(VAR_CANVAS_WIDTH_MODULE) ) ) + rand(-4,4),parseInt(VAR_ABSOLUTE_Y)  + parseInt( VAR_FOREACH_DATA[1][1] * ( VAR_HEIGHT / parseInt(VAR_CANVAS_HEIGHT_MODULE) ) ) + rand(-4,4), move_settings)!
                  

                  
                  
                  sleep(rand(400,500))!
                  

                  
                  
                  /*Browser*/
                  mouse(parseInt(VAR_ABSOLUTE_X) + parseInt( VAR_FOREACH_DATA[1][0] * ( VAR_WIDTH / parseInt(VAR_CANVAS_WIDTH_MODULE) ) ) + rand(-4,4),parseInt(VAR_ABSOLUTE_Y)  + parseInt( VAR_FOREACH_DATA[1][1] * ( VAR_HEIGHT / parseInt(VAR_CANVAS_HEIGHT_MODULE) ) ) + rand(-4,4))!
                  

               })!
               

               
               
               _if(!_cycle_params().if_else,function(){
               
                  
                  
                  _cycle_params().if_else = VAR_NOW_SPEED_MODULE != "No clicks";
                  _set_if_expression("W1tOT1dfU1BFRURfTU9EVUxFXV0gIT0gIk5vIGNsaWNrcyI=");
                  _if(_cycle_params().if_else,function(){
                  
                     
                     
                     /*Browser*/
                     move(parseInt(VAR_ABSOLUTE_X) + parseInt( VAR_FOREACH_DATA[0] * ( VAR_WIDTH / parseInt(VAR_CANVAS_WIDTH_MODULE) ) ),parseInt(VAR_ABSOLUTE_Y)  + parseInt( VAR_FOREACH_DATA[1] * ( VAR_HEIGHT / parseInt(VAR_CANVAS_HEIGHT_MODULE) ) ),  {"speed": VAR_SETTINGS_SPEED_MODULE["SPEED"],"gravity": VAR_SETTINGS_SPEED_MODULE["GRAVITY"],"deviation": VAR_SETTINGS_SPEED_MODULE["DEVIATION"]} )!
                     mouse(parseInt(VAR_ABSOLUTE_X) + parseInt( VAR_FOREACH_DATA[0] * ( VAR_WIDTH / parseInt(VAR_CANVAS_WIDTH_MODULE) ) ),parseInt(VAR_ABSOLUTE_Y)  + parseInt( VAR_FOREACH_DATA[1] * ( VAR_HEIGHT / parseInt(VAR_CANVAS_HEIGHT_MODULE) ) ))!
                     

                  })!
                  

                  
                  
                  _if(!_cycle_params().if_else,function(){
                  
                     
                     
                     /*Browser*/
                     mouse(parseInt(VAR_ABSOLUTE_X) + parseInt( VAR_FOREACH_DATA[0] * ( VAR_WIDTH / parseInt(VAR_CANVAS_WIDTH_MODULE) ) ),parseInt(VAR_ABSOLUTE_Y)  + parseInt( VAR_FOREACH_DATA[1] * ( VAR_HEIGHT / parseInt(VAR_CANVAS_HEIGHT_MODULE) ) ))!
                     

                  })!
                  delete _cycle_params().if_else;
                  

               })!
               delete _cycle_params().if_else;
               

            })!
            

            
            
            VAR_CAPTCHA_SOLVED = true
            

            
            
            _cycle_params().if_else = VAR_NOW_SPEED_MODULE != "No clicks";
            _set_if_expression("W1tOT1dfU1BFRURfTU9EVUxFXV0gIT0gIk5vIGNsaWNrcyI=");
            _if(_cycle_params().if_else,function(){
            
               
               
               _set_if_expression("cmFuZCgwLDEwKSA+IDc=");
               _if(rand(0,10) > 7,function(){
               
                  
                  
                  _get_browser_screen_settings()!
                  ;(function(){
                  var result = JSON.parse(_result())
                  VAR_1 = result["ScrollX"]
                  VAR_1 = result["ScrollY"]
                  VAR_CURSOR_ABSOLUTE_X_MODULE = result["CursorX"]
                  VAR_CURSOR_ABSOLUTE_Y_MODULE = result["CursorY"]
                  VAR_1 = result["Width"]
                  VAR_1 = result["Height"]
                  })();
                  

                  
                  
                  VAR_X_MODULE = rand(-250,250)
                  if (VAR_CURSOR_ABSOLUTE_X_MODULE + VAR_X_MODULE < 0){
                  VAR_X_MODULE = rand(0, 1000)
                  }else{
                  VAR_X_MODULE = VAR_CURSOR_ABSOLUTE_X_MODULE + VAR_X_MODULE
                  }
                  VAR_Y_MODULE = rand(-250,250)
                  if (VAR_CURSOR_ABSOLUTE_Y_MODULE + VAR_Y_MODULE < 0){
                  VAR_Y_MODULE = rand(0, 800)
                  }else{
                  VAR_Y_MODULE = VAR_CURSOR_ABSOLUTE_Y_MODULE + VAR_Y_MODULE
                  }
                  

                  
                  
                  /*Browser*/
                  move(VAR_X_MODULE,VAR_Y_MODULE,  {"speed": VAR_SETTINGS_SPEED_MODULE["SPEED"],"gravity": VAR_SETTINGS_SPEED_MODULE["GRAVITY"],"deviation": VAR_SETTINGS_SPEED_MODULE["DEVIATION"]} )!
                  

               })!
               

               
               
               /*Browser*/
               _SELECTOR = VAR_MAIN_FRAME_SOLVER_MODULE_NOW + " \u003eCSS\u003e .button-submit";
               wait_element_visible(_SELECTOR)!
               _call(_random_point, {})!
               _if(_result().length > 0, function(){
               move( {"speed": VAR_SETTINGS_SPEED_MODULE["SPEED"],"gravity": VAR_SETTINGS_SPEED_MODULE["GRAVITY"],"deviation": VAR_SETTINGS_SPEED_MODULE["DEVIATION"]} )!
               get_element_selector(_SELECTOR, false).clarify(X,Y)!
               _call(_clarify, {"speed": VAR_SETTINGS_SPEED_MODULE["SPEED"],"gravity": VAR_SETTINGS_SPEED_MODULE["GRAVITY"],"deviation": VAR_SETTINGS_SPEED_MODULE["DEVIATION"]} )!
               mouse(X,Y)!
               })!
               

               
               
               _set_if_expression("cmFuZCgwLDEwKSA+IDQ=");
               _if(rand(0,10) > 4,function(){
               
                  
                  
                  _get_browser_screen_settings()!
                  ;(function(){
                  var result = JSON.parse(_result())
                  VAR_1 = result["ScrollX"]
                  VAR_1 = result["ScrollY"]
                  VAR_CURSOR_ABSOLUTE_X_MODULE = result["CursorX"]
                  VAR_CURSOR_ABSOLUTE_Y_MODULE = result["CursorY"]
                  VAR_1 = result["Width"]
                  VAR_1 = result["Height"]
                  })();
                  

                  
                  
                  VAR_X_MODULE = rand(-250,250)
                  if (VAR_CURSOR_ABSOLUTE_X_MODULE + VAR_X_MODULE < 0){
                  VAR_X_MODULE = rand(0, 1000)
                  }else{
                  VAR_X_MODULE = VAR_CURSOR_ABSOLUTE_X_MODULE + VAR_X_MODULE
                  }
                  VAR_Y_MODULE = rand(-250,250)
                  if (VAR_CURSOR_ABSOLUTE_Y_MODULE + VAR_Y_MODULE < 0){
                  VAR_Y_MODULE = rand(0, 800)
                  }else{
                  VAR_Y_MODULE = VAR_CURSOR_ABSOLUTE_Y_MODULE + VAR_Y_MODULE
                  }
                  

                  
                  
                  /*Browser*/
                  move(VAR_X_MODULE,VAR_Y_MODULE,  {"speed": VAR_SETTINGS_SPEED_MODULE["SPEED"],"gravity": VAR_SETTINGS_SPEED_MODULE["GRAVITY"],"deviation": VAR_SETTINGS_SPEED_MODULE["DEVIATION"]} )!
                  

               })!
               

            })!
            

            
            
            _if(!_cycle_params().if_else,function(){
            
               
               
               /*Browser*/
               _SELECTOR = VAR_MAIN_FRAME_SOLVER_MODULE_NOW + " \u003eCSS\u003e .button-submit";
               wait_element_visible(_SELECTOR)!
               _call(_random_point, {})!
               _if(_result().length > 0, function(){
               X = parseInt(_result().split(",")[0])
               Y = parseInt(_result().split(",")[1])
               mouse(X,Y)!
               })!
               

            })!
            delete _cycle_params().if_else;
            

         })!
         

      })!
      

   }
   

