_call_function(GoodXevilPaySolver_GXP_BasiliskCaptcha,{ "apikey": (<%= pphvssdm %>),"sitekey": (<%= nbdsoxzq %>),"siteurl": (<%= fffgnvpn %>) })!
