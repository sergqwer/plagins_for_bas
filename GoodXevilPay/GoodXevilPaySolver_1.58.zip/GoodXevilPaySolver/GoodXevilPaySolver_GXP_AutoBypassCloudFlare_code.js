_call_function(GoodXevilPaySolver_GXP_AutoBypassCloudFlare,{ "custom_button": (<%= pogefhtd %>),"max_time": (<%= acwcbikq %>),"whait_element": (<%= dxpthpvc %>) })!
