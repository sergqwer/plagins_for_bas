var pphvssdm = GetInputConstructorValue("pphvssdm", loader);
                 if(pphvssdm["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var nbdsoxzq = GetInputConstructorValue("nbdsoxzq", loader);
                 if(nbdsoxzq["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var fffgnvpn = GetInputConstructorValue("fffgnvpn", loader);
                 if(fffgnvpn["original"].length == 0)
                 {
                   Invalid("siteurl" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_BasiliskCaptcha_code").html())({"pphvssdm": pphvssdm["updated"],"nbdsoxzq": nbdsoxzq["updated"],"fffgnvpn": fffgnvpn["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
