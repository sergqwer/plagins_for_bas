<div class="container-fluid">
</div>
<div class="tooltipinternal">
<div class="tr tooltip-paragraph-first-fold">Решает Rs капчу стандартными сервисами BAS не используя сторонние сервисы</div>
<div class="tr tooltip-paragraph-last-fold">Solves Rs captcha with standard BAS services without using third-party services</div>
</div>
<%= _.template($('#back').html())({action:"executeandadd", visible:true}) %>
