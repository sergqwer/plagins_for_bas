_call_function(GoodXevilPaySolver_GXP_Antibot,{ "apikey": (<%= rwcceanr %>),"mouse": (<%= uxadbabl %>) })!
