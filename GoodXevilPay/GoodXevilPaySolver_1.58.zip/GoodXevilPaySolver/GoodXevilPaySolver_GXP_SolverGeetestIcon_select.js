var btkxzlcf = GetInputConstructorValue("btkxzlcf", loader);
                 if(btkxzlcf["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var wxdaeuwe = GetInputConstructorValue("wxdaeuwe", loader);
                 if(wxdaeuwe["original"].length == 0)
                 {
                   Invalid("captcha_submit" + " is empty");
                   return;
                 }
var qojdwvuv = GetInputConstructorValue("qojdwvuv", loader);
                 if(qojdwvuv["original"].length == 0)
                 {
                   Invalid("foto_captcha" + " is empty");
                   return;
                 }
var xthocdqe = GetInputConstructorValue("xthocdqe", loader);
                 if(xthocdqe["original"].length == 0)
                 {
                   Invalid("pixel_coef" + " is empty");
                   return;
                 }
var dgbkvsxf = GetInputConstructorValue("dgbkvsxf", loader);
                 if(dgbkvsxf["original"].length == 0)
                 {
                   Invalid("reload_captcha" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SolverGeetestIcon_code").html())({"btkxzlcf": btkxzlcf["updated"],"wxdaeuwe": wxdaeuwe["updated"],"qojdwvuv": qojdwvuv["updated"],"xthocdqe": xthocdqe["updated"],"dgbkvsxf": dgbkvsxf["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
