var pogefhtd = GetInputConstructorValue("pogefhtd", loader);
                 if(pogefhtd["original"].length == 0)
                 {
                   Invalid("custom_button" + " is empty");
                   return;
                 }
var acwcbikq = GetInputConstructorValue("acwcbikq", loader);
                 if(acwcbikq["original"].length == 0)
                 {
                   Invalid("max_time" + " is empty");
                   return;
                 }
var dxpthpvc = GetInputConstructorValue("dxpthpvc", loader);
                 if(dxpthpvc["original"].length == 0)
                 {
                   Invalid("whait_element" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_AutoBypassCloudFlare_code").html())({"pogefhtd": pogefhtd["updated"],"acwcbikq": acwcbikq["updated"],"dxpthpvc": dxpthpvc["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
