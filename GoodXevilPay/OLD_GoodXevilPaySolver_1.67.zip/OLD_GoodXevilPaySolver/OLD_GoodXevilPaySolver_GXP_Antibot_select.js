var fraqaevy = GetInputConstructorValue("fraqaevy", loader);
                 if(fraqaevy["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var mmposjzb = GetInputConstructorValue("mmposjzb", loader);
                 if(mmposjzb["original"].length == 0)
                 {
                   Invalid("mouse" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#OLD_GoodXevilPaySolver_GXP_Antibot_code").html())({"fraqaevy": fraqaevy["updated"],"mmposjzb": mmposjzb["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
