_call_function(OLD_GoodXevilPaySolver_GXP_ProtonMail,{ "APIKEY": (<%= jyrvdimr %>) })!
