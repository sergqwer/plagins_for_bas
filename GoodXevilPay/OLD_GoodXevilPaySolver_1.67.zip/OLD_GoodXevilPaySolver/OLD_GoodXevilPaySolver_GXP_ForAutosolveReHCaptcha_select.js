var ifrlesir = GetInputConstructorValue("ifrlesir", loader);
                 if(ifrlesir["original"].length == 0)
                 {
                   Invalid("hCaptcha_USE" + " is empty");
                   return;
                 }
var etjlklzn = GetInputConstructorValue("etjlklzn", loader);
                 if(etjlklzn["original"].length == 0)
                 {
                   Invalid("ReCaptcha_USE" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#OLD_GoodXevilPaySolver_GXP_ForAutosolveReHCaptcha_code").html())({"ifrlesir": ifrlesir["updated"],"etjlklzn": etjlklzn["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
