_call_function(OLD_GoodXevilPaySolver_GXP_GetBalance,{ "APIKEY": (<%= uperebvq %>) })!
<%= variable %> = _result_function()
