_call_function(OLD_GoodXevilPaySolver_GXP_ReCaptcha_Bypass_No_Exten,{ "apikey": (<%= bjkxrkrt %>),"enterprise": (<%= dnzkamyd %>),"index": (<%= ewwyxsld %>),"invisible": (<%= thpmynna %>) })!
