var smcvmwah = GetInputConstructorValue("smcvmwah", loader);
                 if(smcvmwah["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var jebewjyz = GetInputConstructorValue("jebewjyz", loader);
                 if(jebewjyz["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var xngbgbsl = GetInputConstructorValue("xngbgbsl", loader);
                 if(xngbgbsl["original"].length == 0)
                 {
                   Invalid("siteurl" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#OLD_GoodXevilPaySolver_GXP_BasiliskCaptcha_code").html())({"smcvmwah": smcvmwah["updated"],"jebewjyz": jebewjyz["updated"],"xngbgbsl": xngbgbsl["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
