var shgwhvit = GetInputConstructorValue("shgwhvit", loader);
                 if(shgwhvit["original"].length == 0)
                 {
                   Invalid("arrow_id" + " is empty");
                   return;
                 }
var erfvkujf = GetInputConstructorValue("erfvkujf", loader);
                 if(erfvkujf["original"].length == 0)
                 {
                   Invalid("Attempts" + " is empty");
                   return;
                 }
var pryczzsv = GetInputConstructorValue("pryczzsv", loader);
                 if(pryczzsv["original"].length == 0)
                 {
                   Invalid("avtoupdate" + " is empty");
                   return;
                 }
var fvtxigpn = GetInputConstructorValue("fvtxigpn", loader);
                 if(fvtxigpn["original"].length == 0)
                 {
                   Invalid("button_id" + " is empty");
                   return;
                 }
var zwxpkwmd = GetInputConstructorValue("zwxpkwmd", loader);
                 if(zwxpkwmd["original"].length == 0)
                 {
                   Invalid("coef" + " is empty");
                   return;
                 }
var qdeusaiu = GetInputConstructorValue("qdeusaiu", loader);
                 if(qdeusaiu["original"].length == 0)
                 {
                   Invalid("image id" + " is empty");
                   return;
                 }
var cykjnzbi = GetInputConstructorValue("cykjnzbi", loader);
                 if(cykjnzbi["original"].length == 0)
                 {
                   Invalid("key" + " is empty");
                   return;
                 }
var vuhpxhia = GetInputConstructorValue("vuhpxhia", loader);
                 if(vuhpxhia["original"].length == 0)
                 {
                   Invalid("pixel_koef" + " is empty");
                   return;
                 }
var aofmphxv = GetInputConstructorValue("aofmphxv", loader);
                 if(aofmphxv["original"].length == 0)
                 {
                   Invalid("reload_id" + " is empty");
                   return;
                 }
var lzrqrfqj = GetInputConstructorValue("lzrqrfqj", loader);
                 if(lzrqrfqj["original"].length == 0)
                 {
                   Invalid("slider_type" + " is empty");
                   return;
                 }
var huvxdvlh = GetInputConstructorValue("huvxdvlh", loader);
                 if(huvxdvlh["original"].length == 0)
                 {
                   Invalid("speed" + " is empty");
                   return;
                 }
var sawjeyee = GetInputConstructorValue("sawjeyee", loader);
                 if(sawjeyee["original"].length == 0)
                 {
                   Invalid("type_slide" + " is empty");
                   return;
                 }
var jcrhjdol = GetInputConstructorValue("jcrhjdol", loader);
                 if(jcrhjdol["original"].length == 0)
                 {
                   Invalid("type_swipe" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#OLD_GoodXevilPaySolver_GXP_SliderSolver_code").html())({"shgwhvit": shgwhvit["updated"],"erfvkujf": erfvkujf["updated"],"pryczzsv": pryczzsv["updated"],"fvtxigpn": fvtxigpn["updated"],"zwxpkwmd": zwxpkwmd["updated"],"qdeusaiu": qdeusaiu["updated"],"cykjnzbi": cykjnzbi["updated"],"vuhpxhia": vuhpxhia["updated"],"aofmphxv": aofmphxv["updated"],"lzrqrfqj": lzrqrfqj["updated"],"huvxdvlh": huvxdvlh["updated"],"sawjeyee": sawjeyee["updated"],"jcrhjdol": jcrhjdol["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
