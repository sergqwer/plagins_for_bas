_call_function(OLD_GoodXevilPaySolver_GXP_HcaptchaTakeToken,{ "APIKEY": (<%= bxatlngl %>),"site_url": (<%= ypljrihq %>),"sitekey": (<%= xejvrvkg %>) })!
<%= variable %> = _result_function()
