_call_function(OLD_GoodXevilPaySolver_GXP_AutoBypassCloudFlare,{ "custom_button": (<%= gdpxvvmi %>),"max_time": (<%= mecpfcty %>),"whait_element": (<%= iqcwqikv %>) })!
