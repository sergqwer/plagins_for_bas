_call_function(OLD_GoodXevilPaySolver_GXP_ForAutosolveReHCaptcha,{ "hCaptcha_USE": (<%= ifrlesir %>),"ReCaptcha_USE": (<%= etjlklzn %>) })!
