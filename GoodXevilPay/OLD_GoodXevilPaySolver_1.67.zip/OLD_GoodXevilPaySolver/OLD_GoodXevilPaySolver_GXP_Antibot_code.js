_call_function(OLD_GoodXevilPaySolver_GXP_Antibot,{ "apikey": (<%= fraqaevy %>),"mouse": (<%= mmposjzb %>) })!
