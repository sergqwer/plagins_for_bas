_call_function(OLD_GoodXevilPaySolver_GXP_IMAGE_BASE64,{ "APIKEY": (<%= fqixlodq %>),"IMAGE_BASE64": (<%= vdsibpwh %>) })!
<%= variable %> = _result_function()
