var swajhpbm = GetInputConstructorValue("swajhpbm", loader);
                 if(swajhpbm["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var htirqaqi = GetInputConstructorValue("htirqaqi", loader);
                 if(htirqaqi["original"].length == 0)
                 {
                   Invalid("captcha_submit" + " is empty");
                   return;
                 }
var gsqxnuwh = GetInputConstructorValue("gsqxnuwh", loader);
                 if(gsqxnuwh["original"].length == 0)
                 {
                   Invalid("foto_captcha" + " is empty");
                   return;
                 }
var eltxqldx = GetInputConstructorValue("eltxqldx", loader);
                 if(eltxqldx["original"].length == 0)
                 {
                   Invalid("pixel_coef" + " is empty");
                   return;
                 }
var mgvugddm = GetInputConstructorValue("mgvugddm", loader);
                 if(mgvugddm["original"].length == 0)
                 {
                   Invalid("reload_captcha" + " is empty");
                   return;
                 }
var ywuxhvav = GetInputConstructorValue("ywuxhvav", loader);
                 if(ywuxhvav["original"].length == 0)
                 {
                   Invalid("type_data" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#OLD_GoodXevilPaySolver_GXP_SolverGeetestIcon_code").html())({"swajhpbm": swajhpbm["updated"],"htirqaqi": htirqaqi["updated"],"gsqxnuwh": gsqxnuwh["updated"],"eltxqldx": eltxqldx["updated"],"mgvugddm": mgvugddm["updated"],"ywuxhvav": ywuxhvav["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
