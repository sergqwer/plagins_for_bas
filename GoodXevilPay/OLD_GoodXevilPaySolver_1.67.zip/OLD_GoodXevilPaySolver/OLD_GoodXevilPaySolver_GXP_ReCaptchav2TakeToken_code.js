_call_function(OLD_GoodXevilPaySolver_GXP_ReCaptchav2TakeToken,{ "APIKEY": (<%= lcskhhxz %>),"site_url": (<%= qmthzonq %>),"sitekey": (<%= owazrxuw %>) })!
<%= variable %> = _result_function()
