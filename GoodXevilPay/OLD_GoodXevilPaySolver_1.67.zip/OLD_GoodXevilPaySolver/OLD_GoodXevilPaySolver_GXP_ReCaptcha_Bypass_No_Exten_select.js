var bjkxrkrt = GetInputConstructorValue("bjkxrkrt", loader);
                 if(bjkxrkrt["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var dnzkamyd = GetInputConstructorValue("dnzkamyd", loader);
                 if(dnzkamyd["original"].length == 0)
                 {
                   Invalid("enterprise" + " is empty");
                   return;
                 }
var ewwyxsld = GetInputConstructorValue("ewwyxsld", loader);
                 if(ewwyxsld["original"].length == 0)
                 {
                   Invalid("index" + " is empty");
                   return;
                 }
var thpmynna = GetInputConstructorValue("thpmynna", loader);
                 if(thpmynna["original"].length == 0)
                 {
                   Invalid("invisible" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#OLD_GoodXevilPaySolver_GXP_ReCaptcha_Bypass_No_Exten_code").html())({"bjkxrkrt": bjkxrkrt["updated"],"dnzkamyd": dnzkamyd["updated"],"ewwyxsld": ewwyxsld["updated"],"thpmynna": thpmynna["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
