_call_function(OLD_GoodXevilPaySolver_GXP_BasiliskCaptcha,{ "apikey": (<%= smcvmwah %>),"sitekey": (<%= jebewjyz %>),"siteurl": (<%= xngbgbsl %>) })!
