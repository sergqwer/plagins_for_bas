_call_function(GoodXevilPaySolver_GXP_ReCaptchav2TakeToken,{ "APIKEY": (<%= aopdgywb %>),"site_url": (<%= gavqazmd %>),"sitekey": (<%= ekazojcu %>) })!
<%= variable %> = _result_function()
