var rdydlpzk = GetInputConstructorValue("rdydlpzk", loader);
                 if(rdydlpzk["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var jqrdrzqb = GetInputConstructorValue("jqrdrzqb", loader);
                 if(jqrdrzqb["original"].length == 0)
                 {
                   Invalid("pageurl" + " is empty");
                   return;
                 }
var vgvrdpvx = GetInputConstructorValue("vgvrdpvx", loader);
                 if(vgvrdpvx["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_Yandex_TakeToken_code").html())({"rdydlpzk": rdydlpzk["updated"],"jqrdrzqb": jqrdrzqb["updated"],"vgvrdpvx": vgvrdpvx["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
