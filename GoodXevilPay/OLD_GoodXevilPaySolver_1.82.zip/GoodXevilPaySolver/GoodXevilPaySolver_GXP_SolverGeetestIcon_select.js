var tslbfodm = GetInputConstructorValue("tslbfodm", loader);
                 if(tslbfodm["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var hhktoexd = GetInputConstructorValue("hhktoexd", loader);
                 if(hhktoexd["original"].length == 0)
                 {
                   Invalid("arab_fix" + " is empty");
                   return;
                 }
var drredlum = GetInputConstructorValue("drredlum", loader);
                 if(drredlum["original"].length == 0)
                 {
                   Invalid("captcha_submit" + " is empty");
                   return;
                 }
var ljlgjand = GetInputConstructorValue("ljlgjand", loader);
                 if(ljlgjand["original"].length == 0)
                 {
                   Invalid("foto_captcha" + " is empty");
                   return;
                 }
var kfgrmije = GetInputConstructorValue("kfgrmije", loader);
                 if(kfgrmije["original"].length == 0)
                 {
                   Invalid("pixel_coef" + " is empty");
                   return;
                 }
var hgnyiylm = GetInputConstructorValue("hgnyiylm", loader);
                 if(hgnyiylm["original"].length == 0)
                 {
                   Invalid("reload_captcha" + " is empty");
                   return;
                 }
var qfacfpoq = GetInputConstructorValue("qfacfpoq", loader);
                 if(qfacfpoq["original"].length == 0)
                 {
                   Invalid("type_data" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SolverGeetestIcon_code").html())({"tslbfodm": tslbfodm["updated"],"hhktoexd": hhktoexd["updated"],"drredlum": drredlum["updated"],"ljlgjand": ljlgjand["updated"],"kfgrmije": kfgrmije["updated"],"hgnyiylm": hgnyiylm["updated"],"qfacfpoq": qfacfpoq["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
