_call_function(GoodXevilPaySolver_GXP_TurnstileToken,{ "APIKEY": (<%= zbswlqgb %>),"site_url": (<%= luoetyww %>),"sitekey": (<%= robtagsi %>) })!
<%= variable %> = _result_function()
