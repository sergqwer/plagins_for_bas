var ahahwpun = GetInputConstructorValue("ahahwpun", loader);
                 if(ahahwpun["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var wxyndumc = GetInputConstructorValue("wxyndumc", loader);
                 if(wxyndumc["original"].length == 0)
                 {
                   Invalid("enterprise" + " is empty");
                   return;
                 }
var nrnesbzw = GetInputConstructorValue("nrnesbzw", loader);
                 if(nrnesbzw["original"].length == 0)
                 {
                   Invalid("index" + " is empty");
                   return;
                 }
var kuaxryul = GetInputConstructorValue("kuaxryul", loader);
                 if(kuaxryul["original"].length == 0)
                 {
                   Invalid("invisible" + " is empty");
                   return;
                 }
var prpavxef = GetInputConstructorValue("prpavxef", loader);
                 if(prpavxef["original"].length == 0)
                 {
                   Invalid("recaptchaframe" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_ReCaptcha_Bypass_No_Exten_code").html())({"ahahwpun": ahahwpun["updated"],"wxyndumc": wxyndumc["updated"],"nrnesbzw": nrnesbzw["updated"],"kuaxryul": kuaxryul["updated"],"prpavxef": prpavxef["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
