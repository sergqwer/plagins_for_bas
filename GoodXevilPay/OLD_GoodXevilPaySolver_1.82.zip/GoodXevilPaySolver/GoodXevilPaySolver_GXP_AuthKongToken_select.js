var mvjezlff = GetInputConstructorValue("mvjezlff", loader);
                 if(mvjezlff["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var afssnuso = GetInputConstructorValue("afssnuso", loader);
                 if(afssnuso["original"].length == 0)
                 {
                   Invalid("site_url" + " is empty");
                   return;
                 }
var xtonehfb = GetInputConstructorValue("xtonehfb", loader);
                 if(xtonehfb["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_AuthKongToken_code").html())({"mvjezlff": mvjezlff["updated"],"afssnuso": afssnuso["updated"],"xtonehfb": xtonehfb["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
