var itercdxh = GetInputConstructorValue("itercdxh", loader);
                 if(itercdxh["original"].length == 0)
                 {
                   Invalid("main_frame_checkbox" + " is empty");
                   return;
                 }
var mklbkoit = GetInputConstructorValue("mklbkoit", loader);
                 if(mklbkoit["original"].length == 0)
                 {
                   Invalid("main_frame_solver" + " is empty");
                   return;
                 }
var zzhrcfkp = GetInputConstructorValue("zzhrcfkp", loader);
                 if(zzhrcfkp["original"].length == 0)
                 {
                   Invalid("servisename" + " is empty");
                   return;
                 }
var apiqtfwz = GetInputConstructorValue("apiqtfwz", loader);
                 if(apiqtfwz["original"].length == 0)
                 {
                   Invalid("speed" + " is empty");
                   return;
                 }
var dzrndvkj = GetInputConstructorValue("dzrndvkj", loader);
                 if(dzrndvkj["original"].length == 0)
                 {
                   Invalid("try_solved" + " is empty");
                   return;
                 }
var hdeaqlzg = GetInputConstructorValue("hdeaqlzg", loader);
                 if(hdeaqlzg["original"].length == 0)
                 {
                   Invalid("userapikey" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#ReCaptchaClick_recaptcha_solver_code").html())({"itercdxh": itercdxh["updated"],"mklbkoit": mklbkoit["updated"],"zzhrcfkp": zzhrcfkp["updated"],"apiqtfwz": apiqtfwz["updated"],"dzrndvkj": dzrndvkj["updated"],"hdeaqlzg": hdeaqlzg["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
