_call_function(GoodXevilPaySolver_GXP_HcaptchaTakeToken,{ "APIKEY": (<%= fwopohtn %>),"site_url": (<%= lkxasgba %>),"sitekey": (<%= zalooeeq %>) })!
<%= variable %> = _result_function()
