var jrwlrdtm = GetInputConstructorValue("jrwlrdtm", loader);
                 if(jrwlrdtm["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var ksjbdsgn = GetInputConstructorValue("ksjbdsgn", loader);
                 if(ksjbdsgn["original"].length == 0)
                 {
                   Invalid("mouse" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_Antibot_code").html())({"jrwlrdtm": jrwlrdtm["updated"],"ksjbdsgn": ksjbdsgn["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
