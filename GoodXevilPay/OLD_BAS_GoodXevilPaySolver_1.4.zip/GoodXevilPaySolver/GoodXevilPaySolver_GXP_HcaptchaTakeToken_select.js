var fwopohtn = GetInputConstructorValue("fwopohtn", loader);
                 if(fwopohtn["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var lkxasgba = GetInputConstructorValue("lkxasgba", loader);
                 if(lkxasgba["original"].length == 0)
                 {
                   Invalid("site_url" + " is empty");
                   return;
                 }
var zalooeeq = GetInputConstructorValue("zalooeeq", loader);
                 if(zalooeeq["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_HcaptchaTakeToken_code").html())({"fwopohtn": fwopohtn["updated"],"lkxasgba": lkxasgba["updated"],"zalooeeq": zalooeeq["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
