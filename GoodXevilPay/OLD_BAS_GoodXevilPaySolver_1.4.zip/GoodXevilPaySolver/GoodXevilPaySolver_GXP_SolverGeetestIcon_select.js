var uqeshypb = GetInputConstructorValue("uqeshypb", loader);
                 if(uqeshypb["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var byhdbtzx = GetInputConstructorValue("byhdbtzx", loader);
                 if(byhdbtzx["original"].length == 0)
                 {
                   Invalid("button_capthca" + " is empty");
                   return;
                 }
var huzxhwzg = GetInputConstructorValue("huzxhwzg", loader);
                 if(huzxhwzg["original"].length == 0)
                 {
                   Invalid("captcha_submit" + " is empty");
                   return;
                 }
var rpzyxwqj = GetInputConstructorValue("rpzyxwqj", loader);
                 if(rpzyxwqj["original"].length == 0)
                 {
                   Invalid("foto_captcha" + " is empty");
                   return;
                 }
var osvqywwg = GetInputConstructorValue("osvqywwg", loader);
                 if(osvqywwg["original"].length == 0)
                 {
                   Invalid("reload_captcha" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SolverGeetestIcon_code").html())({"uqeshypb": uqeshypb["updated"],"byhdbtzx": byhdbtzx["updated"],"huzxhwzg": huzxhwzg["updated"],"rpzyxwqj": rpzyxwqj["updated"],"osvqywwg": osvqywwg["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
