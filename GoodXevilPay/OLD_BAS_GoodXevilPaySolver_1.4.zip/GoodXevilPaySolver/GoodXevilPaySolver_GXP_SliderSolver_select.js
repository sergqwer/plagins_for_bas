var qypglkrf = GetInputConstructorValue("qypglkrf", loader);
                 if(qypglkrf["original"].length == 0)
                 {
                   Invalid("arrow_id" + " is empty");
                   return;
                 }
var sqrecjfn = GetInputConstructorValue("sqrecjfn", loader);
                 if(sqrecjfn["original"].length == 0)
                 {
                   Invalid("avtoupdate" + " is empty");
                   return;
                 }
var qifyzykv = GetInputConstructorValue("qifyzykv", loader);
                 if(qifyzykv["original"].length == 0)
                 {
                   Invalid("button_id" + " is empty");
                   return;
                 }
var nhusklpw = GetInputConstructorValue("nhusklpw", loader);
                 if(nhusklpw["original"].length == 0)
                 {
                   Invalid("coef" + " is empty");
                   return;
                 }
var zrqgdvam = GetInputConstructorValue("zrqgdvam", loader);
                 if(zrqgdvam["original"].length == 0)
                 {
                   Invalid("image id" + " is empty");
                   return;
                 }
var hcfeetuo = GetInputConstructorValue("hcfeetuo", loader);
                 if(hcfeetuo["original"].length == 0)
                 {
                   Invalid("key" + " is empty");
                   return;
                 }
var njfdnpqq = GetInputConstructorValue("njfdnpqq", loader);
                 if(njfdnpqq["original"].length == 0)
                 {
                   Invalid("pixel_koef" + " is empty");
                   return;
                 }
var epsbiapb = GetInputConstructorValue("epsbiapb", loader);
                 if(epsbiapb["original"].length == 0)
                 {
                   Invalid("reload_id" + " is empty");
                   return;
                 }
var nagusaqy = GetInputConstructorValue("nagusaqy", loader);
                 if(nagusaqy["original"].length == 0)
                 {
                   Invalid("speed" + " is empty");
                   return;
                 }
var nzalcjwo = GetInputConstructorValue("nzalcjwo", loader);
                 if(nzalcjwo["original"].length == 0)
                 {
                   Invalid("type_slide" + " is empty");
                   return;
                 }
var crjrbcos = GetInputConstructorValue("crjrbcos", loader);
                 if(crjrbcos["original"].length == 0)
                 {
                   Invalid("type_swipe" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SliderSolver_code").html())({"qypglkrf": qypglkrf["updated"],"sqrecjfn": sqrecjfn["updated"],"qifyzykv": qifyzykv["updated"],"nhusklpw": nhusklpw["updated"],"zrqgdvam": zrqgdvam["updated"],"hcfeetuo": hcfeetuo["updated"],"njfdnpqq": njfdnpqq["updated"],"epsbiapb": epsbiapb["updated"],"nagusaqy": nagusaqy["updated"],"nzalcjwo": nzalcjwo["updated"],"crjrbcos": crjrbcos["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
