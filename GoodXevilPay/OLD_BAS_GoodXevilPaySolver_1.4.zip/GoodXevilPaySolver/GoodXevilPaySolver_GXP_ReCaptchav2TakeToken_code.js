_call_function(GoodXevilPaySolver_GXP_ReCaptchav2TakeToken,{ "APIKEY": (<%= lwfxdilx %>),"site_url": (<%= utivedgq %>),"sitekey": (<%= fddgxzcd %>) })!
<%= variable %> = _result_function()
