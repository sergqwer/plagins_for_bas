var jpzlytxf = GetInputConstructorValue("jpzlytxf", loader);
                 if(jpzlytxf["original"].length == 0)
                 {
                   Invalid("token" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_AutoConfirmCallback_ReCaptcha_code").html())({"jpzlytxf": jpzlytxf["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
