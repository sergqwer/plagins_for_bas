_call_function(GoodXevilPaySolver_GXP_HcaptchaTakeToken,{ "APIKEY": (<%= bffdhizy %>),"site_url": (<%= laogsvko %>),"sitekey": (<%= ckvvmsjd %>) })!
<%= variable %> = _result_function()
