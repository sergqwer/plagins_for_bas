_call_function(GoodXevilPaySolver_GXP_ReCaptchav2TakeToken,{ "APIKEY": (<%= uposfpag %>),"site_url": (<%= vmnbgvos %>),"sitekey": (<%= yckzkwoa %>) })!
<%= variable %> = _result_function()
