var fqfukpdc = GetInputConstructorValue("fqfukpdc", loader);
                 if(fqfukpdc["original"].length == 0)
                 {
                   Invalid("arrow_id" + " is empty");
                   return;
                 }
var hvefownv = GetInputConstructorValue("hvefownv", loader);
                 if(hvefownv["original"].length == 0)
                 {
                   Invalid("avtoupdate" + " is empty");
                   return;
                 }
var jgfqntkf = GetInputConstructorValue("jgfqntkf", loader);
                 if(jgfqntkf["original"].length == 0)
                 {
                   Invalid("button_id" + " is empty");
                   return;
                 }
var xmaxsmxt = GetInputConstructorValue("xmaxsmxt", loader);
                 if(xmaxsmxt["original"].length == 0)
                 {
                   Invalid("coef" + " is empty");
                   return;
                 }
var oloukbmj = GetInputConstructorValue("oloukbmj", loader);
                 if(oloukbmj["original"].length == 0)
                 {
                   Invalid("image id" + " is empty");
                   return;
                 }
var xwthjawm = GetInputConstructorValue("xwthjawm", loader);
                 if(xwthjawm["original"].length == 0)
                 {
                   Invalid("key" + " is empty");
                   return;
                 }
var zxiaznpu = GetInputConstructorValue("zxiaznpu", loader);
                 if(zxiaznpu["original"].length == 0)
                 {
                   Invalid("pixel_koef" + " is empty");
                   return;
                 }
var kqotdkjw = GetInputConstructorValue("kqotdkjw", loader);
                 if(kqotdkjw["original"].length == 0)
                 {
                   Invalid("reload_id" + " is empty");
                   return;
                 }
var scmplect = GetInputConstructorValue("scmplect", loader);
                 if(scmplect["original"].length == 0)
                 {
                   Invalid("speed" + " is empty");
                   return;
                 }
var ejpwsokj = GetInputConstructorValue("ejpwsokj", loader);
                 if(ejpwsokj["original"].length == 0)
                 {
                   Invalid("type_slide" + " is empty");
                   return;
                 }
var ylkqysyj = GetInputConstructorValue("ylkqysyj", loader);
                 if(ylkqysyj["original"].length == 0)
                 {
                   Invalid("type_swipe" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SliderSolver_code").html())({"fqfukpdc": fqfukpdc["updated"],"hvefownv": hvefownv["updated"],"jgfqntkf": jgfqntkf["updated"],"xmaxsmxt": xmaxsmxt["updated"],"oloukbmj": oloukbmj["updated"],"xwthjawm": xwthjawm["updated"],"zxiaznpu": zxiaznpu["updated"],"kqotdkjw": kqotdkjw["updated"],"scmplect": scmplect["updated"],"ejpwsokj": ejpwsokj["updated"],"ylkqysyj": ylkqysyj["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
