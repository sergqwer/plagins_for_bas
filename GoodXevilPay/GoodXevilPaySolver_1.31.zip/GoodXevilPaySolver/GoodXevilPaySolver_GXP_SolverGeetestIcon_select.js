var jfzoowmu = GetInputConstructorValue("jfzoowmu", loader);
                 if(jfzoowmu["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var yfyggvyh = GetInputConstructorValue("yfyggvyh", loader);
                 if(yfyggvyh["original"].length == 0)
                 {
                   Invalid("button_capthca" + " is empty");
                   return;
                 }
var eypxouuf = GetInputConstructorValue("eypxouuf", loader);
                 if(eypxouuf["original"].length == 0)
                 {
                   Invalid("captcha_submit" + " is empty");
                   return;
                 }
var vcvjosnb = GetInputConstructorValue("vcvjosnb", loader);
                 if(vcvjosnb["original"].length == 0)
                 {
                   Invalid("foto_captcha" + " is empty");
                   return;
                 }
var thrqjsiq = GetInputConstructorValue("thrqjsiq", loader);
                 if(thrqjsiq["original"].length == 0)
                 {
                   Invalid("reload_captcha" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SolverGeetestIcon_code").html())({"jfzoowmu": jfzoowmu["updated"],"yfyggvyh": yfyggvyh["updated"],"eypxouuf": eypxouuf["updated"],"vcvjosnb": vcvjosnb["updated"],"thrqjsiq": thrqjsiq["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
