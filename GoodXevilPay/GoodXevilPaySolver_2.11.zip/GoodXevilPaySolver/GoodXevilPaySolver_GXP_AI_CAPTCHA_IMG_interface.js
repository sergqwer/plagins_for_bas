<div class="container-fluid">
<%= _.template($('#input_constructor').html())({id:"ilcfpeuq", description:"ApiKey", default_selector: "string", disable_int:true, value_string: "", help: {description: "<div>apikey с сервиса https://t.me/Xevil_check_bot</div><div>apikey from https://t.me/Xevil_check_bot</div>"} }) %>
<%= _.template($('#input_constructor').html())({id:"pmngrprv", description:"Promt", default_selector: "string", disable_expression:true, disable_int:true, value_string: "Прочитай текст на изображении", help: {description: "<div>Как можно точнее опишите, что надо сделать</div><div>Describe as precisely as possible what needs to be done</div>"} }) %>
<%= _.template($('#input_constructor').html())({id:"gmcmdcgm", description:"Image in BASE64", default_selector: "string", disable_expression:true, disable_int:true, value_string: "false", help: {description: "<div>Изображение в BASE64</div><div>Image in BASE64</div>"} }) %>
<%= _.template($('#input_constructor').html())({id:"dsymrlya", description:"REGEXTM", default_selector: "string", disable_expression:true, disable_int:true, value_string: ".+", help: {description: "<div>A regular to filter out unnecessary characters</div><div>Can be empty</div><div>Numbers only: [0-9]+</div><div>English letters only: [A-Za-z]+</div><div>rus letters only: [А-Яа-я]+</div><div>Character list: [0123456abcdef]+"} }) %>
<%= _.template($('#variable_constructor').html())({id:"Save", description:"Result", default_variable: "RESULT_AI", help: {description: ""}}) %>
</div>
<div class="tooltipinternal">
<div class="tr tooltip-paragraph-first-fold">Здесь используется LLM с сайта chatgptchatapp.com, что умеет читать текст с картинок, распознавать обекты, и много чего еще, самое главное задать правильный промт</div>
<div class="tr tooltip-paragraph-first-fold">Here we use LLM from chatgptchatapp.com, which can read text from pictures, recognize objects, and much more, the most important thing is to set the right promt</div>
</div>
<%= _.template($('#back').html())({action:"executeandadd", visible:true}) %>
