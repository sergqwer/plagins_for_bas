var khtktxwi = GetInputConstructorValue("khtktxwi", loader);
                 if(khtktxwi["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var tuugrqxy = GetInputConstructorValue("tuugrqxy", loader);
                 if(tuugrqxy["original"].length == 0)
                 {
                   Invalid("CaptchaSelector" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_Yandex_code").html())({"khtktxwi": khtktxwi["updated"],"tuugrqxy": tuugrqxy["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
