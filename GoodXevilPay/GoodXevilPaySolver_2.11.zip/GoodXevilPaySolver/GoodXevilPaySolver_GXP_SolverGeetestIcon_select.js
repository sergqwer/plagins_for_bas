var tfdyvhku = GetInputConstructorValue("tfdyvhku", loader);
                 if(tfdyvhku["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var pagzduvs = GetInputConstructorValue("pagzduvs", loader);
                 if(pagzduvs["original"].length == 0)
                 {
                   Invalid("arab_fix" + " is empty");
                   return;
                 }
var xhydiykf = GetInputConstructorValue("xhydiykf", loader);
                 if(xhydiykf["original"].length == 0)
                 {
                   Invalid("captcha_submit" + " is empty");
                   return;
                 }
var rcfmpiix = GetInputConstructorValue("rcfmpiix", loader);
                 if(rcfmpiix["original"].length == 0)
                 {
                   Invalid("foto_captcha" + " is empty");
                   return;
                 }
var mpziqazk = GetInputConstructorValue("mpziqazk", loader);
                 if(mpziqazk["original"].length == 0)
                 {
                   Invalid("pixel_coef" + " is empty");
                   return;
                 }
var ujmqnmoh = GetInputConstructorValue("ujmqnmoh", loader);
                 if(ujmqnmoh["original"].length == 0)
                 {
                   Invalid("reload_captcha" + " is empty");
                   return;
                 }
var gptcgrdm = GetInputConstructorValue("gptcgrdm", loader);
                 if(gptcgrdm["original"].length == 0)
                 {
                   Invalid("type_data" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SolverGeetestIcon_code").html())({"tfdyvhku": tfdyvhku["updated"],"pagzduvs": pagzduvs["updated"],"xhydiykf": xhydiykf["updated"],"rcfmpiix": rcfmpiix["updated"],"mpziqazk": mpziqazk["updated"],"ujmqnmoh": ujmqnmoh["updated"],"gptcgrdm": gptcgrdm["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
