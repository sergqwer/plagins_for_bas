var vjpaihwh = GetInputConstructorValue("vjpaihwh", loader);
                 if(vjpaihwh["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var lrludjev = GetInputConstructorValue("lrludjev", loader);
                 if(lrludjev["original"].length == 0)
                 {
                   Invalid("timer" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_BuxMoney_PayupVideo_code").html())({"vjpaihwh": vjpaihwh["updated"],"lrludjev": lrludjev["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
