var szqbzqss = GetInputConstructorValue("szqbzqss", loader);
                 if(szqbzqss["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var cxvxquku = GetInputConstructorValue("cxvxquku", loader);
                 if(cxvxquku["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var hppacqdc = GetInputConstructorValue("hppacqdc", loader);
                 if(hppacqdc["original"].length == 0)
                 {
                   Invalid("siteurl" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#OLD_GoodXevilPaySolver_GXP_BasiliskCaptcha_code").html())({"szqbzqss": szqbzqss["updated"],"cxvxquku": cxvxquku["updated"],"hppacqdc": hppacqdc["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
