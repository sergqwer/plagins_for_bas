var yywfrkpb = GetInputConstructorValue("yywfrkpb", loader);
                 if(yywfrkpb["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var vxjzqxvq = GetInputConstructorValue("vxjzqxvq", loader);
                 if(vxjzqxvq["original"].length == 0)
                 {
                   Invalid("index" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#OLD_GoodXevilPaySolver_GXP_ReCaptcha_Bypass_No_Exten_code").html())({"yywfrkpb": yywfrkpb["updated"],"vxjzqxvq": vxjzqxvq["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
