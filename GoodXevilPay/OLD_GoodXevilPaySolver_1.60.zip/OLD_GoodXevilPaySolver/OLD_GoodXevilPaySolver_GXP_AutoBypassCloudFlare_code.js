_call_function(OLD_GoodXevilPaySolver_GXP_AutoBypassCloudFlare,{ "custom_button": (<%= hjszpmox %>),"max_time": (<%= uuxhpysa %>),"whait_element": (<%= dgbmseso %>) })!
