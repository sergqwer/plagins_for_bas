var kcjycnha = GetInputConstructorValue("kcjycnha", loader);
                 if(kcjycnha["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var lrpkuyvw = GetInputConstructorValue("lrpkuyvw", loader);
                 if(lrpkuyvw["original"].length == 0)
                 {
                   Invalid("mouse" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#OLD_GoodXevilPaySolver_GXP_Antibot_code").html())({"kcjycnha": kcjycnha["updated"],"lrpkuyvw": lrpkuyvw["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
