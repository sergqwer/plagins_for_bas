_call_function(OLD_GoodXevilPaySolver_GXP_ReCaptcha_Bypass_No_Exten,{ "apikey": (<%= yywfrkpb %>),"index": (<%= vxjzqxvq %>) })!
