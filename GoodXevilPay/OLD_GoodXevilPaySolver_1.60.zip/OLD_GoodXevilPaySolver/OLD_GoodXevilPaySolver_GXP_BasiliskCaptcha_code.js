_call_function(OLD_GoodXevilPaySolver_GXP_BasiliskCaptcha,{ "apikey": (<%= szqbzqss %>),"sitekey": (<%= cxvxquku %>),"siteurl": (<%= hppacqdc %>) })!
