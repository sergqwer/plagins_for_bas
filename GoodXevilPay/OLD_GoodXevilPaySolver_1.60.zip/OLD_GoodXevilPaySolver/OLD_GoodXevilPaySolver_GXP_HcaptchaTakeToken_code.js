_call_function(OLD_GoodXevilPaySolver_GXP_HcaptchaTakeToken,{ "APIKEY": (<%= jlgvmuor %>),"site_url": (<%= riamvtsi %>),"sitekey": (<%= cnoiwpul %>) })!
<%= variable %> = _result_function()
