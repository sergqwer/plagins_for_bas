_call_function(OLD_GoodXevilPaySolver_GXP_GetBalance,{ "APIKEY": (<%= ynhcgxxg %>) })!
<%= variable %> = _result_function()
