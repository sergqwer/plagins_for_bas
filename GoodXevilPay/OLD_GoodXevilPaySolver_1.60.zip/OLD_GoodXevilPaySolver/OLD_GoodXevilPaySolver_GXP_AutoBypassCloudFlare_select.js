var hjszpmox = GetInputConstructorValue("hjszpmox", loader);
                 if(hjszpmox["original"].length == 0)
                 {
                   Invalid("custom_button" + " is empty");
                   return;
                 }
var uuxhpysa = GetInputConstructorValue("uuxhpysa", loader);
                 if(uuxhpysa["original"].length == 0)
                 {
                   Invalid("max_time" + " is empty");
                   return;
                 }
var dgbmseso = GetInputConstructorValue("dgbmseso", loader);
                 if(dgbmseso["original"].length == 0)
                 {
                   Invalid("whait_element" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#OLD_GoodXevilPaySolver_GXP_AutoBypassCloudFlare_code").html())({"hjszpmox": hjszpmox["updated"],"uuxhpysa": uuxhpysa["updated"],"dgbmseso": dgbmseso["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
