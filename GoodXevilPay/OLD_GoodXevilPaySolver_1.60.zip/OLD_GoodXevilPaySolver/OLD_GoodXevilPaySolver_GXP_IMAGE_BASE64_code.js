_call_function(OLD_GoodXevilPaySolver_GXP_IMAGE_BASE64,{ "APIKEY": (<%= rxkjgbmx %>),"IMAGE_BASE64": (<%= rjrsynps %>) })!
<%= variable %> = _result_function()
