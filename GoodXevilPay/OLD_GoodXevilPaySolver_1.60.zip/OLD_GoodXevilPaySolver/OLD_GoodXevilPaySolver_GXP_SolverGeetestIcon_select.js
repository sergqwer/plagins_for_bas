var bmfdaujm = GetInputConstructorValue("bmfdaujm", loader);
                 if(bmfdaujm["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var qwlrghbt = GetInputConstructorValue("qwlrghbt", loader);
                 if(qwlrghbt["original"].length == 0)
                 {
                   Invalid("captcha_submit" + " is empty");
                   return;
                 }
var trajzhsb = GetInputConstructorValue("trajzhsb", loader);
                 if(trajzhsb["original"].length == 0)
                 {
                   Invalid("foto_captcha" + " is empty");
                   return;
                 }
var jliytbgl = GetInputConstructorValue("jliytbgl", loader);
                 if(jliytbgl["original"].length == 0)
                 {
                   Invalid("pixel_coef" + " is empty");
                   return;
                 }
var faidrtnc = GetInputConstructorValue("faidrtnc", loader);
                 if(faidrtnc["original"].length == 0)
                 {
                   Invalid("reload_captcha" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#OLD_GoodXevilPaySolver_GXP_SolverGeetestIcon_code").html())({"bmfdaujm": bmfdaujm["updated"],"qwlrghbt": qwlrghbt["updated"],"trajzhsb": trajzhsb["updated"],"jliytbgl": jliytbgl["updated"],"faidrtnc": faidrtnc["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
