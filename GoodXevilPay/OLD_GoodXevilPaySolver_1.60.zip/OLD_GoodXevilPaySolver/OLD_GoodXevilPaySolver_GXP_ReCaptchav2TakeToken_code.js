_call_function(OLD_GoodXevilPaySolver_GXP_ReCaptchav2TakeToken,{ "APIKEY": (<%= pnjfdnal %>),"site_url": (<%= sryneysi %>),"sitekey": (<%= nonemnjr %>) })!
<%= variable %> = _result_function()
