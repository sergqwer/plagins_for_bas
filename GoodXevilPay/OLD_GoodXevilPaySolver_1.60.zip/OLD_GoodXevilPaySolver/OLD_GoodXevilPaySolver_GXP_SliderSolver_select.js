var vrxidhyz = GetInputConstructorValue("vrxidhyz", loader);
                 if(vrxidhyz["original"].length == 0)
                 {
                   Invalid("arrow_id" + " is empty");
                   return;
                 }
var qajcudyr = GetInputConstructorValue("qajcudyr", loader);
                 if(qajcudyr["original"].length == 0)
                 {
                   Invalid("avtoupdate" + " is empty");
                   return;
                 }
var fhzvpnhs = GetInputConstructorValue("fhzvpnhs", loader);
                 if(fhzvpnhs["original"].length == 0)
                 {
                   Invalid("button_id" + " is empty");
                   return;
                 }
var dzncgzlw = GetInputConstructorValue("dzncgzlw", loader);
                 if(dzncgzlw["original"].length == 0)
                 {
                   Invalid("coef" + " is empty");
                   return;
                 }
var rmnaodcz = GetInputConstructorValue("rmnaodcz", loader);
                 if(rmnaodcz["original"].length == 0)
                 {
                   Invalid("image id" + " is empty");
                   return;
                 }
var orxdfkfi = GetInputConstructorValue("orxdfkfi", loader);
                 if(orxdfkfi["original"].length == 0)
                 {
                   Invalid("key" + " is empty");
                   return;
                 }
var kebodjrb = GetInputConstructorValue("kebodjrb", loader);
                 if(kebodjrb["original"].length == 0)
                 {
                   Invalid("pixel_koef" + " is empty");
                   return;
                 }
var mdkdbira = GetInputConstructorValue("mdkdbira", loader);
                 if(mdkdbira["original"].length == 0)
                 {
                   Invalid("reload_id" + " is empty");
                   return;
                 }
var jlkgtoiq = GetInputConstructorValue("jlkgtoiq", loader);
                 if(jlkgtoiq["original"].length == 0)
                 {
                   Invalid("speed" + " is empty");
                   return;
                 }
var lliedper = GetInputConstructorValue("lliedper", loader);
                 if(lliedper["original"].length == 0)
                 {
                   Invalid("type_slide" + " is empty");
                   return;
                 }
var uhkofryz = GetInputConstructorValue("uhkofryz", loader);
                 if(uhkofryz["original"].length == 0)
                 {
                   Invalid("type_swipe" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#OLD_GoodXevilPaySolver_GXP_SliderSolver_code").html())({"vrxidhyz": vrxidhyz["updated"],"qajcudyr": qajcudyr["updated"],"fhzvpnhs": fhzvpnhs["updated"],"dzncgzlw": dzncgzlw["updated"],"rmnaodcz": rmnaodcz["updated"],"orxdfkfi": orxdfkfi["updated"],"kebodjrb": kebodjrb["updated"],"mdkdbira": mdkdbira["updated"],"jlkgtoiq": jlkgtoiq["updated"],"lliedper": lliedper["updated"],"uhkofryz": uhkofryz["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
