<div class="container-fluid">
</div>
<div class="tooltipinternal">
<div class="tr tooltip-paragraph-first-fold">Надо для решения капчи на PTC, вызвать при входе в аккаунт</div>
<div class="tr tooltip-paragraph-last-fold">Need to solve captcha on PTC, call when logging into account</div>
</div>
<%= _.template($('#back').html())({action:"executeandadd", visible:true}) %>
