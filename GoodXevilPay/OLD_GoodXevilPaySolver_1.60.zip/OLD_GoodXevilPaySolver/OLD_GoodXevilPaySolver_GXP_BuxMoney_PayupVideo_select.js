var uimaytue = GetInputConstructorValue("uimaytue", loader);
                 if(uimaytue["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var rbrsierw = GetInputConstructorValue("rbrsierw", loader);
                 if(rbrsierw["original"].length == 0)
                 {
                   Invalid("timer" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#OLD_GoodXevilPaySolver_GXP_BuxMoney_PayupVideo_code").html())({"uimaytue": uimaytue["updated"],"rbrsierw": rbrsierw["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
