var kqzmxhos = GetInputConstructorValue("kqzmxhos", loader);
                 if(kqzmxhos["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var squagkzh = GetInputConstructorValue("squagkzh", loader);
                 if(squagkzh["original"].length == 0)
                 {
                   Invalid("site_url" + " is empty");
                   return;
                 }
var scklgsez = GetInputConstructorValue("scklgsez", loader);
                 if(scklgsez["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_ReCaptchav2TakeToken_code").html())({"kqzmxhos": kqzmxhos["updated"],"squagkzh": squagkzh["updated"],"scklgsez": scklgsez["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
