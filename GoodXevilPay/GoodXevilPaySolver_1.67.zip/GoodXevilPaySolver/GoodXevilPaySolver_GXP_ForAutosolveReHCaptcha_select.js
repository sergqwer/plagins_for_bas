var gefjtyox = GetInputConstructorValue("gefjtyox", loader);
                 if(gefjtyox["original"].length == 0)
                 {
                   Invalid("hCaptcha_USE" + " is empty");
                   return;
                 }
var tkyvdcde = GetInputConstructorValue("tkyvdcde", loader);
                 if(tkyvdcde["original"].length == 0)
                 {
                   Invalid("ReCaptcha_USE" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_ForAutosolveReHCaptcha_code").html())({"gefjtyox": gefjtyox["updated"],"tkyvdcde": tkyvdcde["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
