<div class="container-fluid">
<%= _.template($('#input_constructor').html())({id:"jsdtqsdq", description:"token", default_selector: "string", disable_int:true, value_string: "", help: {description: "Токен recaptcha полученый, например, через CaptchaCustom\n\nRecaptcha token obtained, for example, via CaptchaCustom"} }) %>
</div>
<div class="tooltipinternal">
<div class="tr tooltip-paragraph-first-fold">Данная функция автоматически применит ваш токен recaptcha, для работы требуется функция For Autosolve ReHCaptcha</div>
<div class="tr tooltip-paragraph-last-fold">This function will automatically apply your recaptcha token, For Autosolve ReHCaptcha is required to work</div>
</div>
<%= _.template($('#back').html())({action:"executeandadd", visible:true}) %>
