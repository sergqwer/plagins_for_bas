_call_function(GoodXevilPaySolver_GXP_AutoBypassCloudFlare,{ "custom_button": (<%= lxnwhlon %>),"max_time": (<%= yvzctdxt %>),"whait_element": (<%= hrzujtph %>) })!
