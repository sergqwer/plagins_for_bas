var ptrifpbn = GetInputConstructorValue("ptrifpbn", loader);
                 if(ptrifpbn["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var gussdodt = GetInputConstructorValue("gussdodt", loader);
                 if(gussdodt["original"].length == 0)
                 {
                   Invalid("captcha_submit" + " is empty");
                   return;
                 }
var xnfrcdvp = GetInputConstructorValue("xnfrcdvp", loader);
                 if(xnfrcdvp["original"].length == 0)
                 {
                   Invalid("foto_captcha" + " is empty");
                   return;
                 }
var dnairekc = GetInputConstructorValue("dnairekc", loader);
                 if(dnairekc["original"].length == 0)
                 {
                   Invalid("pixel_coef" + " is empty");
                   return;
                 }
var sowbupsp = GetInputConstructorValue("sowbupsp", loader);
                 if(sowbupsp["original"].length == 0)
                 {
                   Invalid("reload_captcha" + " is empty");
                   return;
                 }
var vkmxtstz = GetInputConstructorValue("vkmxtstz", loader);
                 if(vkmxtstz["original"].length == 0)
                 {
                   Invalid("type_data" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SolverGeetestIcon_code").html())({"ptrifpbn": ptrifpbn["updated"],"gussdodt": gussdodt["updated"],"xnfrcdvp": xnfrcdvp["updated"],"dnairekc": dnairekc["updated"],"sowbupsp": sowbupsp["updated"],"vkmxtstz": vkmxtstz["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
