var lxnwhlon = GetInputConstructorValue("lxnwhlon", loader);
                 if(lxnwhlon["original"].length == 0)
                 {
                   Invalid("custom_button" + " is empty");
                   return;
                 }
var yvzctdxt = GetInputConstructorValue("yvzctdxt", loader);
                 if(yvzctdxt["original"].length == 0)
                 {
                   Invalid("max_time" + " is empty");
                   return;
                 }
var hrzujtph = GetInputConstructorValue("hrzujtph", loader);
                 if(hrzujtph["original"].length == 0)
                 {
                   Invalid("whait_element" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_AutoBypassCloudFlare_code").html())({"lxnwhlon": lxnwhlon["updated"],"yvzctdxt": yvzctdxt["updated"],"hrzujtph": hrzujtph["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
