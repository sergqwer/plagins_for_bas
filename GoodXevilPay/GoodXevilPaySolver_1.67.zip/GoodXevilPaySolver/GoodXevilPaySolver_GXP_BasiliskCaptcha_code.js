_call_function(GoodXevilPaySolver_GXP_BasiliskCaptcha,{ "apikey": (<%= phkgcpdw %>),"sitekey": (<%= qmjmxvig %>),"siteurl": (<%= uigbnawp %>) })!
