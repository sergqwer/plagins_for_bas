<div class="container-fluid">
<%= _.template($('#input_constructor').html())({id:"zlrefqrg", description:"apikey", default_selector: "string", disable_int:true, value_string: "", help: {description: "apikey с сервиса https://t.me/Xevil_check_bot\n\napikey from https://t.me/Xevil_check_bot"} }) %>
<%= _.template($('#input_constructor').html())({id:"mmsddzgj", description:"enterprise", default_selector: "int", disable_string:true, value_number: 0, min_number:-999999, max_number:999999, help: {description: "0 - not enterprise\n1 - enterprise"} }) %>
<%= _.template($('#input_constructor').html())({id:"lvqsskud", description:"index", default_selector: "int", disable_string:true, value_number: 0, min_number:-999999, max_number:999999, help: {description: "Индекс капчи на странице"} }) %>
<%= _.template($('#input_constructor').html())({id:"roephlhw", description:"invisible", default_selector: "int", disable_string:true, value_number: 0, min_number:-999999, max_number:999999, help: {description: "0 - not invisible\n1 - invisible"} }) %>
</div>
<div class="tooltipinternal">
<div class="tr tooltip-paragraph-first-fold">Автоматически решает ReCaptcha на странице без использования расширения, и сторонних js в коде страницы</div>
<div class="tr tooltip-paragraph-last-fold">Automatically solves ReCaptcha on the page without using extension, and third-party js in the page code</div>
</div>
<%= _.template($('#back').html())({action:"executeandadd", visible:true}) %>
