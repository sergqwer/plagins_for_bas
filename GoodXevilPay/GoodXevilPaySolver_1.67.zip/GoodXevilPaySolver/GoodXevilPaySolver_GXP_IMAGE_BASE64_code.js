_call_function(GoodXevilPaySolver_GXP_IMAGE_BASE64,{ "APIKEY": (<%= ipytbzsj %>),"IMAGE_BASE64": (<%= kgizcqnd %>) })!
<%= variable %> = _result_function()
