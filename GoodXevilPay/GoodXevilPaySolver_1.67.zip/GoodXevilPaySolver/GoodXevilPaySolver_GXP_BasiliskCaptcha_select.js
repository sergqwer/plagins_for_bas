var phkgcpdw = GetInputConstructorValue("phkgcpdw", loader);
                 if(phkgcpdw["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var qmjmxvig = GetInputConstructorValue("qmjmxvig", loader);
                 if(qmjmxvig["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var uigbnawp = GetInputConstructorValue("uigbnawp", loader);
                 if(uigbnawp["original"].length == 0)
                 {
                   Invalid("siteurl" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_BasiliskCaptcha_code").html())({"phkgcpdw": phkgcpdw["updated"],"qmjmxvig": qmjmxvig["updated"],"uigbnawp": uigbnawp["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
