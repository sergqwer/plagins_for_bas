var thdubezx = GetInputConstructorValue("thdubezx", loader);
                 if(thdubezx["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var dszqpkjd = GetInputConstructorValue("dszqpkjd", loader);
                 if(dszqpkjd["original"].length == 0)
                 {
                   Invalid("timer" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_BuxMoney_PayupVideo_code").html())({"thdubezx": thdubezx["updated"],"dszqpkjd": dszqpkjd["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
