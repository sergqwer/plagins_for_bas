var zlrefqrg = GetInputConstructorValue("zlrefqrg", loader);
                 if(zlrefqrg["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var mmsddzgj = GetInputConstructorValue("mmsddzgj", loader);
                 if(mmsddzgj["original"].length == 0)
                 {
                   Invalid("enterprise" + " is empty");
                   return;
                 }
var lvqsskud = GetInputConstructorValue("lvqsskud", loader);
                 if(lvqsskud["original"].length == 0)
                 {
                   Invalid("index" + " is empty");
                   return;
                 }
var roephlhw = GetInputConstructorValue("roephlhw", loader);
                 if(roephlhw["original"].length == 0)
                 {
                   Invalid("invisible" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_ReCaptcha_Bypass_No_Exten_code").html())({"zlrefqrg": zlrefqrg["updated"],"mmsddzgj": mmsddzgj["updated"],"lvqsskud": lvqsskud["updated"],"roephlhw": roephlhw["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
