_call_function(GoodXevilPaySolver_GXP_HcaptchaTakeToken,{ "APIKEY": (<%= bpssyjvz %>),"site_url": (<%= vnijoljg %>),"sitekey": (<%= vhvtnudv %>) })!
<%= variable %> = _result_function()
