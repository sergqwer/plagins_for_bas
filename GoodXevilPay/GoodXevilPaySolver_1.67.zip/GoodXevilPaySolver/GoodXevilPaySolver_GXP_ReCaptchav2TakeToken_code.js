_call_function(GoodXevilPaySolver_GXP_ReCaptchav2TakeToken,{ "APIKEY": (<%= kqzmxhos %>),"site_url": (<%= squagkzh %>),"sitekey": (<%= scklgsez %>) })!
<%= variable %> = _result_function()
