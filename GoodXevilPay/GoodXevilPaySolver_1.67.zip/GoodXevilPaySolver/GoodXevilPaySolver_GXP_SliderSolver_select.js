var dztzqftq = GetInputConstructorValue("dztzqftq", loader);
                 if(dztzqftq["original"].length == 0)
                 {
                   Invalid("arrow_id" + " is empty");
                   return;
                 }
var utnhwzfx = GetInputConstructorValue("utnhwzfx", loader);
                 if(utnhwzfx["original"].length == 0)
                 {
                   Invalid("Attempts" + " is empty");
                   return;
                 }
var hclfsram = GetInputConstructorValue("hclfsram", loader);
                 if(hclfsram["original"].length == 0)
                 {
                   Invalid("avtoupdate" + " is empty");
                   return;
                 }
var qbjzejwq = GetInputConstructorValue("qbjzejwq", loader);
                 if(qbjzejwq["original"].length == 0)
                 {
                   Invalid("button_id" + " is empty");
                   return;
                 }
var loicseqh = GetInputConstructorValue("loicseqh", loader);
                 if(loicseqh["original"].length == 0)
                 {
                   Invalid("coef" + " is empty");
                   return;
                 }
var ifuozidj = GetInputConstructorValue("ifuozidj", loader);
                 if(ifuozidj["original"].length == 0)
                 {
                   Invalid("image id" + " is empty");
                   return;
                 }
var ucrtrwnf = GetInputConstructorValue("ucrtrwnf", loader);
                 if(ucrtrwnf["original"].length == 0)
                 {
                   Invalid("key" + " is empty");
                   return;
                 }
var epaiscgk = GetInputConstructorValue("epaiscgk", loader);
                 if(epaiscgk["original"].length == 0)
                 {
                   Invalid("pixel_koef" + " is empty");
                   return;
                 }
var lhjrsuak = GetInputConstructorValue("lhjrsuak", loader);
                 if(lhjrsuak["original"].length == 0)
                 {
                   Invalid("reload_id" + " is empty");
                   return;
                 }
var emaxvvhw = GetInputConstructorValue("emaxvvhw", loader);
                 if(emaxvvhw["original"].length == 0)
                 {
                   Invalid("slider_type" + " is empty");
                   return;
                 }
var odcilyyp = GetInputConstructorValue("odcilyyp", loader);
                 if(odcilyyp["original"].length == 0)
                 {
                   Invalid("speed" + " is empty");
                   return;
                 }
var shqdskjf = GetInputConstructorValue("shqdskjf", loader);
                 if(shqdskjf["original"].length == 0)
                 {
                   Invalid("type_slide" + " is empty");
                   return;
                 }
var mkezxeol = GetInputConstructorValue("mkezxeol", loader);
                 if(mkezxeol["original"].length == 0)
                 {
                   Invalid("type_swipe" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SliderSolver_code").html())({"dztzqftq": dztzqftq["updated"],"utnhwzfx": utnhwzfx["updated"],"hclfsram": hclfsram["updated"],"qbjzejwq": qbjzejwq["updated"],"loicseqh": loicseqh["updated"],"ifuozidj": ifuozidj["updated"],"ucrtrwnf": ucrtrwnf["updated"],"epaiscgk": epaiscgk["updated"],"lhjrsuak": lhjrsuak["updated"],"emaxvvhw": emaxvvhw["updated"],"odcilyyp": odcilyyp["updated"],"shqdskjf": shqdskjf["updated"],"mkezxeol": mkezxeol["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
