_call_function(GoodXevilPaySolver_GXP_BuxMoney_PayupVideo,{ "apikey": (<%= alemygtc %>),"timer": (<%= dkjlqhbc %>) })!
