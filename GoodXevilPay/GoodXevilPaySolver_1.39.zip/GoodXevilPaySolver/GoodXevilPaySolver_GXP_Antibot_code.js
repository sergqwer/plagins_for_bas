_call_function(GoodXevilPaySolver_GXP_Antibot,{ "apikey": (<%= ktrrwdxs %>),"mouse": (<%= llbdddjz %>) })!
