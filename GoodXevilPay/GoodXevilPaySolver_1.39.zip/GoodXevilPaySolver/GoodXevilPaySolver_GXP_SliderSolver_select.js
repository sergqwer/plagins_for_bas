var llgikwph = GetInputConstructorValue("llgikwph", loader);
                 if(llgikwph["original"].length == 0)
                 {
                   Invalid("arrow_id" + " is empty");
                   return;
                 }
var chzgmlsf = GetInputConstructorValue("chzgmlsf", loader);
                 if(chzgmlsf["original"].length == 0)
                 {
                   Invalid("avtoupdate" + " is empty");
                   return;
                 }
var iukntfcr = GetInputConstructorValue("iukntfcr", loader);
                 if(iukntfcr["original"].length == 0)
                 {
                   Invalid("button_id" + " is empty");
                   return;
                 }
var rlnktktr = GetInputConstructorValue("rlnktktr", loader);
                 if(rlnktktr["original"].length == 0)
                 {
                   Invalid("coef" + " is empty");
                   return;
                 }
var ahneqcnw = GetInputConstructorValue("ahneqcnw", loader);
                 if(ahneqcnw["original"].length == 0)
                 {
                   Invalid("image id" + " is empty");
                   return;
                 }
var iweefehr = GetInputConstructorValue("iweefehr", loader);
                 if(iweefehr["original"].length == 0)
                 {
                   Invalid("key" + " is empty");
                   return;
                 }
var haflluze = GetInputConstructorValue("haflluze", loader);
                 if(haflluze["original"].length == 0)
                 {
                   Invalid("pixel_koef" + " is empty");
                   return;
                 }
var tgdcvxgh = GetInputConstructorValue("tgdcvxgh", loader);
                 if(tgdcvxgh["original"].length == 0)
                 {
                   Invalid("reload_id" + " is empty");
                   return;
                 }
var aaymetkp = GetInputConstructorValue("aaymetkp", loader);
                 if(aaymetkp["original"].length == 0)
                 {
                   Invalid("speed" + " is empty");
                   return;
                 }
var emwyehpo = GetInputConstructorValue("emwyehpo", loader);
                 if(emwyehpo["original"].length == 0)
                 {
                   Invalid("type_slide" + " is empty");
                   return;
                 }
var ewxhcagr = GetInputConstructorValue("ewxhcagr", loader);
                 if(ewxhcagr["original"].length == 0)
                 {
                   Invalid("type_swipe" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SliderSolver_code").html())({"llgikwph": llgikwph["updated"],"chzgmlsf": chzgmlsf["updated"],"iukntfcr": iukntfcr["updated"],"rlnktktr": rlnktktr["updated"],"ahneqcnw": ahneqcnw["updated"],"iweefehr": iweefehr["updated"],"haflluze": haflluze["updated"],"tgdcvxgh": tgdcvxgh["updated"],"aaymetkp": aaymetkp["updated"],"emwyehpo": emwyehpo["updated"],"ewxhcagr": ewxhcagr["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
