_call_function(GoodXevilPaySolver_GXP_Namars,{ "apikey": (<%= yxfwliqd %>) })!
<%= variable %> = _result_function()
