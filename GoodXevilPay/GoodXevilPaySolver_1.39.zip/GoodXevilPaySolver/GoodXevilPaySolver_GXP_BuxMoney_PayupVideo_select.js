var alemygtc = GetInputConstructorValue("alemygtc", loader);
                 if(alemygtc["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var dkjlqhbc = GetInputConstructorValue("dkjlqhbc", loader);
                 if(dkjlqhbc["original"].length == 0)
                 {
                   Invalid("timer" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_BuxMoney_PayupVideo_code").html())({"alemygtc": alemygtc["updated"],"dkjlqhbc": dkjlqhbc["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
