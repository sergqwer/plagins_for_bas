_call_function(GoodXevilPaySolver_GXP_ReCaptchav2TakeToken,{ "APIKEY": (<%= vexcswfh %>),"site_url": (<%= tlbsuajg %>),"sitekey": (<%= stfgpjzd %>) })!
<%= variable %> = _result_function()
