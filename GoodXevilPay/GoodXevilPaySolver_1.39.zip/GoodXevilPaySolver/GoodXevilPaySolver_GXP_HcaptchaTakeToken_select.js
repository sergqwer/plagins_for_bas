var czvlqowx = GetInputConstructorValue("czvlqowx", loader);
                 if(czvlqowx["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var allmpnal = GetInputConstructorValue("allmpnal", loader);
                 if(allmpnal["original"].length == 0)
                 {
                   Invalid("site_url" + " is empty");
                   return;
                 }
var aprepukx = GetInputConstructorValue("aprepukx", loader);
                 if(aprepukx["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_HcaptchaTakeToken_code").html())({"czvlqowx": czvlqowx["updated"],"allmpnal": allmpnal["updated"],"aprepukx": aprepukx["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
