_call_function(GoodXevilPaySolver_GXP_IMAGE_BASE64,{ "APIKEY": (<%= ituvdwqf %>),"IMAGE_BASE64": (<%= jkdfeysb %>) })!
<%= variable %> = _result_function()
