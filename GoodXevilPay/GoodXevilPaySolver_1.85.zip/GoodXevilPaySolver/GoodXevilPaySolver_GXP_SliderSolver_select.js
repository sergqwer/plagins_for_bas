var javbxlgp = GetInputConstructorValue("javbxlgp", loader);
                 if(javbxlgp["original"].length == 0)
                 {
                   Invalid("arrow_id" + " is empty");
                   return;
                 }
var llpuzvcr = GetInputConstructorValue("llpuzvcr", loader);
                 if(llpuzvcr["original"].length == 0)
                 {
                   Invalid("Attempts" + " is empty");
                   return;
                 }
var iaxkfoyk = GetInputConstructorValue("iaxkfoyk", loader);
                 if(iaxkfoyk["original"].length == 0)
                 {
                   Invalid("avtoupdate" + " is empty");
                   return;
                 }
var uwawzfxs = GetInputConstructorValue("uwawzfxs", loader);
                 if(uwawzfxs["original"].length == 0)
                 {
                   Invalid("button_id" + " is empty");
                   return;
                 }
var uuvswlue = GetInputConstructorValue("uuvswlue", loader);
                 if(uuvswlue["original"].length == 0)
                 {
                   Invalid("coef" + " is empty");
                   return;
                 }
var wmppuity = GetInputConstructorValue("wmppuity", loader);
                 if(wmppuity["original"].length == 0)
                 {
                   Invalid("image id" + " is empty");
                   return;
                 }
var jflpkghc = GetInputConstructorValue("jflpkghc", loader);
                 if(jflpkghc["original"].length == 0)
                 {
                   Invalid("key" + " is empty");
                   return;
                 }
var vjbnskmf = GetInputConstructorValue("vjbnskmf", loader);
                 if(vjbnskmf["original"].length == 0)
                 {
                   Invalid("pixel_koef" + " is empty");
                   return;
                 }
var suqiaoky = GetInputConstructorValue("suqiaoky", loader);
                 if(suqiaoky["original"].length == 0)
                 {
                   Invalid("reload_id" + " is empty");
                   return;
                 }
var zfwfknwo = GetInputConstructorValue("zfwfknwo", loader);
                 if(zfwfknwo["original"].length == 0)
                 {
                   Invalid("slider_type" + " is empty");
                   return;
                 }
var iujyhlkz = GetInputConstructorValue("iujyhlkz", loader);
                 if(iujyhlkz["original"].length == 0)
                 {
                   Invalid("speed" + " is empty");
                   return;
                 }
var qsloacod = GetInputConstructorValue("qsloacod", loader);
                 if(qsloacod["original"].length == 0)
                 {
                   Invalid("type_slide" + " is empty");
                   return;
                 }
var lwydebca = GetInputConstructorValue("lwydebca", loader);
                 if(lwydebca["original"].length == 0)
                 {
                   Invalid("type_swipe" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SliderSolver_code").html())({"javbxlgp": javbxlgp["updated"],"llpuzvcr": llpuzvcr["updated"],"iaxkfoyk": iaxkfoyk["updated"],"uwawzfxs": uwawzfxs["updated"],"uuvswlue": uuvswlue["updated"],"wmppuity": wmppuity["updated"],"jflpkghc": jflpkghc["updated"],"vjbnskmf": vjbnskmf["updated"],"suqiaoky": suqiaoky["updated"],"zfwfknwo": zfwfknwo["updated"],"iujyhlkz": iujyhlkz["updated"],"qsloacod": qsloacod["updated"],"lwydebca": lwydebca["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
