var umptlygl = GetInputConstructorValue("umptlygl", loader);
                 if(umptlygl["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var woryznkr = GetInputConstructorValue("woryznkr", loader);
                 if(woryznkr["original"].length == 0)
                 {
                   Invalid("iconselement" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_IconsFinder_code").html())({"umptlygl": umptlygl["updated"],"woryznkr": woryznkr["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
