var htomwjva = GetInputConstructorValue("htomwjva", loader);
                 if(htomwjva["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var hapupaww = GetInputConstructorValue("hapupaww", loader);
                 if(hapupaww["original"].length == 0)
                 {
                   Invalid("site_url" + " is empty");
                   return;
                 }
var yyhjynmc = GetInputConstructorValue("yyhjynmc", loader);
                 if(yyhjynmc["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_TurnstileToken_code").html())({"htomwjva": htomwjva["updated"],"hapupaww": hapupaww["updated"],"yyhjynmc": yyhjynmc["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
