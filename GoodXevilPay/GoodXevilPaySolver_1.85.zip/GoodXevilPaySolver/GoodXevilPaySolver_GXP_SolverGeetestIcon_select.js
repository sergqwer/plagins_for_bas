var zhgqkitr = GetInputConstructorValue("zhgqkitr", loader);
                 if(zhgqkitr["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var pgxhuerg = GetInputConstructorValue("pgxhuerg", loader);
                 if(pgxhuerg["original"].length == 0)
                 {
                   Invalid("arab_fix" + " is empty");
                   return;
                 }
var nsziqnpi = GetInputConstructorValue("nsziqnpi", loader);
                 if(nsziqnpi["original"].length == 0)
                 {
                   Invalid("captcha_submit" + " is empty");
                   return;
                 }
var mepvbrqc = GetInputConstructorValue("mepvbrqc", loader);
                 if(mepvbrqc["original"].length == 0)
                 {
                   Invalid("foto_captcha" + " is empty");
                   return;
                 }
var xzjzedhh = GetInputConstructorValue("xzjzedhh", loader);
                 if(xzjzedhh["original"].length == 0)
                 {
                   Invalid("pixel_coef" + " is empty");
                   return;
                 }
var vjylefqt = GetInputConstructorValue("vjylefqt", loader);
                 if(vjylefqt["original"].length == 0)
                 {
                   Invalid("reload_captcha" + " is empty");
                   return;
                 }
var mmxvwhaa = GetInputConstructorValue("mmxvwhaa", loader);
                 if(mmxvwhaa["original"].length == 0)
                 {
                   Invalid("type_data" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SolverGeetestIcon_code").html())({"zhgqkitr": zhgqkitr["updated"],"pgxhuerg": pgxhuerg["updated"],"nsziqnpi": nsziqnpi["updated"],"mepvbrqc": mepvbrqc["updated"],"xzjzedhh": xzjzedhh["updated"],"vjylefqt": vjylefqt["updated"],"mmxvwhaa": mmxvwhaa["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
