_call_function(GoodXevilPaySolver_GXP_TurnstileToken,{ "APIKEY": (<%= htomwjva %>),"site_url": (<%= hapupaww %>),"sitekey": (<%= yyhjynmc %>) })!
<%= variable %> = _result_function()
