_call_function(GoodXevilPaySolver_GXP_Yandex,{ "apikey": (<%= nliplsjr %>),"CaptchaSelector": (<%= zoshbbcq %>) })!
