var ixqyblzo = GetInputConstructorValue("ixqyblzo", loader);
                 if(ixqyblzo["original"].length == 0)
                 {
                   Invalid("custom_button" + " is empty");
                   return;
                 }
var ghyvzgvi = GetInputConstructorValue("ghyvzgvi", loader);
                 if(ghyvzgvi["original"].length == 0)
                 {
                   Invalid("max_time" + " is empty");
                   return;
                 }
var bqrptwuz = GetInputConstructorValue("bqrptwuz", loader);
                 if(bqrptwuz["original"].length == 0)
                 {
                   Invalid("whait_element" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_AutoBypassCloudFlare_code").html())({"ixqyblzo": ixqyblzo["updated"],"ghyvzgvi": ghyvzgvi["updated"],"bqrptwuz": bqrptwuz["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
