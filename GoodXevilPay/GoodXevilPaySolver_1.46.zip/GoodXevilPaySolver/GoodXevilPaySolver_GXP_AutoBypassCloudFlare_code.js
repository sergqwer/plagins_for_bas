_call_function(GoodXevilPaySolver_GXP_AutoBypassCloudFlare,{ "custom_button": (<%= ixqyblzo %>),"max_time": (<%= ghyvzgvi %>),"whait_element": (<%= bqrptwuz %>) })!
