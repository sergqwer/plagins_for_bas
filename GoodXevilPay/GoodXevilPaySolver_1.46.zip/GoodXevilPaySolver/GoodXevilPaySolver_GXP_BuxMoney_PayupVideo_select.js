var tzqbsqxx = GetInputConstructorValue("tzqbsqxx", loader);
                 if(tzqbsqxx["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var fbjzymst = GetInputConstructorValue("fbjzymst", loader);
                 if(fbjzymst["original"].length == 0)
                 {
                   Invalid("timer" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_BuxMoney_PayupVideo_code").html())({"tzqbsqxx": tzqbsqxx["updated"],"fbjzymst": fbjzymst["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
