var sbsmsnyq = GetInputConstructorValue("sbsmsnyq", loader);
                 if(sbsmsnyq["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var kgbxmmrs = GetInputConstructorValue("kgbxmmrs", loader);
                 if(kgbxmmrs["original"].length == 0)
                 {
                   Invalid("button_capthca" + " is empty");
                   return;
                 }
var mmhqmfuo = GetInputConstructorValue("mmhqmfuo", loader);
                 if(mmhqmfuo["original"].length == 0)
                 {
                   Invalid("captcha_submit" + " is empty");
                   return;
                 }
var jzdozuzc = GetInputConstructorValue("jzdozuzc", loader);
                 if(jzdozuzc["original"].length == 0)
                 {
                   Invalid("foto_captcha" + " is empty");
                   return;
                 }
var hpjrfyze = GetInputConstructorValue("hpjrfyze", loader);
                 if(hpjrfyze["original"].length == 0)
                 {
                   Invalid("reload_captcha" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SolverGeetestIcon_code").html())({"sbsmsnyq": sbsmsnyq["updated"],"kgbxmmrs": kgbxmmrs["updated"],"mmhqmfuo": mmhqmfuo["updated"],"jzdozuzc": jzdozuzc["updated"],"hpjrfyze": hpjrfyze["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
