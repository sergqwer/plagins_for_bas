_call_function(GoodXevilPaySolver_GXP_HcaptchaTakeToken,{ "APIKEY": (<%= ewhvgwpk %>),"site_url": (<%= spczxkvw %>),"sitekey": (<%= oczkwbom %>) })!
<%= variable %> = _result_function()
