<div class="container-fluid">
<%= _.template($('#input_constructor').html())({id:"ialzjcvg", description:"apikey", default_selector: "string", disable_int:true, value_string: "", help: {description: "apikey с сервиса \nhttps://t.me/Xevil_check_bot"} }) %>
</div>
<div class="tooltipinternal">
</div>
<%= _.template($('#back').html())({action:"executeandadd", visible:true}) %>
