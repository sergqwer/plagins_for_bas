_call_function(GoodXevilPaySolver_GXP_IMAGE_BASE64,{ "APIKEY": (<%= mgyuhwgq %>),"IMAGE_BASE64": (<%= sazqyyut %>) })!
<%= variable %> = _result_function()
