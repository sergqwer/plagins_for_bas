_call_function(GoodXevilPaySolver_GXP_ReCaptchav2TakeToken,{ "APIKEY": (<%= ziyetrbt %>),"site_url": (<%= vqvyfytg %>),"sitekey": (<%= cttqfdxx %>) })!
<%= variable %> = _result_function()
