var jpemmdqq = GetInputConstructorValue("jpemmdqq", loader);
                 if(jpemmdqq["original"].length == 0)
                 {
                   Invalid("arrow_id" + " is empty");
                   return;
                 }
var iwcwwmpw = GetInputConstructorValue("iwcwwmpw", loader);
                 if(iwcwwmpw["original"].length == 0)
                 {
                   Invalid("avtoupdate" + " is empty");
                   return;
                 }
var eakethfd = GetInputConstructorValue("eakethfd", loader);
                 if(eakethfd["original"].length == 0)
                 {
                   Invalid("button_id" + " is empty");
                   return;
                 }
var hidhfyik = GetInputConstructorValue("hidhfyik", loader);
                 if(hidhfyik["original"].length == 0)
                 {
                   Invalid("coef" + " is empty");
                   return;
                 }
var mtwbpqtg = GetInputConstructorValue("mtwbpqtg", loader);
                 if(mtwbpqtg["original"].length == 0)
                 {
                   Invalid("image id" + " is empty");
                   return;
                 }
var iobvjqsl = GetInputConstructorValue("iobvjqsl", loader);
                 if(iobvjqsl["original"].length == 0)
                 {
                   Invalid("key" + " is empty");
                   return;
                 }
var utkocrah = GetInputConstructorValue("utkocrah", loader);
                 if(utkocrah["original"].length == 0)
                 {
                   Invalid("pixel_koef" + " is empty");
                   return;
                 }
var ezhovwra = GetInputConstructorValue("ezhovwra", loader);
                 if(ezhovwra["original"].length == 0)
                 {
                   Invalid("reload_id" + " is empty");
                   return;
                 }
var ijcotass = GetInputConstructorValue("ijcotass", loader);
                 if(ijcotass["original"].length == 0)
                 {
                   Invalid("speed" + " is empty");
                   return;
                 }
var rcsnwwes = GetInputConstructorValue("rcsnwwes", loader);
                 if(rcsnwwes["original"].length == 0)
                 {
                   Invalid("type_slide" + " is empty");
                   return;
                 }
var ivgooivc = GetInputConstructorValue("ivgooivc", loader);
                 if(ivgooivc["original"].length == 0)
                 {
                   Invalid("type_swipe" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SliderSolver_code").html())({"jpemmdqq": jpemmdqq["updated"],"iwcwwmpw": iwcwwmpw["updated"],"eakethfd": eakethfd["updated"],"hidhfyik": hidhfyik["updated"],"mtwbpqtg": mtwbpqtg["updated"],"iobvjqsl": iobvjqsl["updated"],"utkocrah": utkocrah["updated"],"ezhovwra": ezhovwra["updated"],"ijcotass": ijcotass["updated"],"rcsnwwes": rcsnwwes["updated"],"ivgooivc": ivgooivc["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
