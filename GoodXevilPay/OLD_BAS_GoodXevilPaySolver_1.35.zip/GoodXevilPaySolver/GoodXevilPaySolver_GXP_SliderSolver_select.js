var oytkfoag = GetInputConstructorValue("oytkfoag", loader);
                 if(oytkfoag["original"].length == 0)
                 {
                   Invalid("arrow_id" + " is empty");
                   return;
                 }
var fttozylt = GetInputConstructorValue("fttozylt", loader);
                 if(fttozylt["original"].length == 0)
                 {
                   Invalid("avtoupdate" + " is empty");
                   return;
                 }
var kgaejhhj = GetInputConstructorValue("kgaejhhj", loader);
                 if(kgaejhhj["original"].length == 0)
                 {
                   Invalid("button_id" + " is empty");
                   return;
                 }
var cwjksjdt = GetInputConstructorValue("cwjksjdt", loader);
                 if(cwjksjdt["original"].length == 0)
                 {
                   Invalid("coef" + " is empty");
                   return;
                 }
var bbnyrnxs = GetInputConstructorValue("bbnyrnxs", loader);
                 if(bbnyrnxs["original"].length == 0)
                 {
                   Invalid("image id" + " is empty");
                   return;
                 }
var npqqzsav = GetInputConstructorValue("npqqzsav", loader);
                 if(npqqzsav["original"].length == 0)
                 {
                   Invalid("key" + " is empty");
                   return;
                 }
var dajpepje = GetInputConstructorValue("dajpepje", loader);
                 if(dajpepje["original"].length == 0)
                 {
                   Invalid("pixel_koef" + " is empty");
                   return;
                 }
var xxidoesw = GetInputConstructorValue("xxidoesw", loader);
                 if(xxidoesw["original"].length == 0)
                 {
                   Invalid("reload_id" + " is empty");
                   return;
                 }
var jxfjbeim = GetInputConstructorValue("jxfjbeim", loader);
                 if(jxfjbeim["original"].length == 0)
                 {
                   Invalid("speed" + " is empty");
                   return;
                 }
var qppybjiu = GetInputConstructorValue("qppybjiu", loader);
                 if(qppybjiu["original"].length == 0)
                 {
                   Invalid("type_slide" + " is empty");
                   return;
                 }
var mgaamthx = GetInputConstructorValue("mgaamthx", loader);
                 if(mgaamthx["original"].length == 0)
                 {
                   Invalid("type_swipe" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SliderSolver_code").html())({"oytkfoag": oytkfoag["updated"],"fttozylt": fttozylt["updated"],"kgaejhhj": kgaejhhj["updated"],"cwjksjdt": cwjksjdt["updated"],"bbnyrnxs": bbnyrnxs["updated"],"npqqzsav": npqqzsav["updated"],"dajpepje": dajpepje["updated"],"xxidoesw": xxidoesw["updated"],"jxfjbeim": jxfjbeim["updated"],"qppybjiu": qppybjiu["updated"],"mgaamthx": mgaamthx["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
