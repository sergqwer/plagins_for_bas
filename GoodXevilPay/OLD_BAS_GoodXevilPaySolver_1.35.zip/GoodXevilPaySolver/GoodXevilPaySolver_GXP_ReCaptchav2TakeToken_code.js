_call_function(GoodXevilPaySolver_GXP_ReCaptchav2TakeToken,{ "APIKEY": (<%= uxgvjhpb %>),"site_url": (<%= ynlgoceq %>),"sitekey": (<%= oxdfdsgl %>) })!
<%= variable %> = _result_function()
