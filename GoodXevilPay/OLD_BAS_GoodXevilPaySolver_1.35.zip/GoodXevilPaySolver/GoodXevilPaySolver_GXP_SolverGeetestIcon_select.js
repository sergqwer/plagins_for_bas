var iezjeekf = GetInputConstructorValue("iezjeekf", loader);
                 if(iezjeekf["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var lwqdbnsj = GetInputConstructorValue("lwqdbnsj", loader);
                 if(lwqdbnsj["original"].length == 0)
                 {
                   Invalid("button_capthca" + " is empty");
                   return;
                 }
var grotlrmj = GetInputConstructorValue("grotlrmj", loader);
                 if(grotlrmj["original"].length == 0)
                 {
                   Invalid("captcha_submit" + " is empty");
                   return;
                 }
var qwsqvxuj = GetInputConstructorValue("qwsqvxuj", loader);
                 if(qwsqvxuj["original"].length == 0)
                 {
                   Invalid("foto_captcha" + " is empty");
                   return;
                 }
var evxqrosm = GetInputConstructorValue("evxqrosm", loader);
                 if(evxqrosm["original"].length == 0)
                 {
                   Invalid("reload_captcha" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SolverGeetestIcon_code").html())({"iezjeekf": iezjeekf["updated"],"lwqdbnsj": lwqdbnsj["updated"],"grotlrmj": grotlrmj["updated"],"qwsqvxuj": qwsqvxuj["updated"],"evxqrosm": evxqrosm["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
