_call_function(GoodXevilPaySolver_GXP_IMAGE_BASE64,{ "APIKEY": (<%= blxprrab %>),"IMAGE_BASE64": (<%= jzptsxdt %>) })!
<%= variable %> = _result_function()
