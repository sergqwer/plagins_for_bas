var jgtoinjy = GetInputConstructorValue("jgtoinjy", loader);
                 if(jgtoinjy["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var cupvuarg = GetInputConstructorValue("cupvuarg", loader);
                 if(cupvuarg["original"].length == 0)
                 {
                   Invalid("CaptchaSelector" + " is empty");
                   return;
                 }
var nlwfgpyv = GetInputConstructorValue("nlwfgpyv", loader);
                 if(nlwfgpyv["original"].length == 0)
                 {
                   Invalid("InvisibleCaptcha" + " is empty");
                   return;
                 }
var nnfijryj = GetInputConstructorValue("nnfijryj", loader);
                 if(nnfijryj["original"].length == 0)
                 {
                   Invalid("TrySolve" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_hCaptcha_Click_code").html())({"jgtoinjy": jgtoinjy["updated"],"cupvuarg": cupvuarg["updated"],"nlwfgpyv": nlwfgpyv["updated"],"nnfijryj": nnfijryj["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
