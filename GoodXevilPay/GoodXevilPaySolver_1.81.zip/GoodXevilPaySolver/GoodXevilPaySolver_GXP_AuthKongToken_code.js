_call_function(GoodXevilPaySolver_GXP_AuthKongToken,{ "APIKEY": (<%= shwuzqxp %>),"site_url": (<%= tqdihfiv %>),"sitekey": (<%= jizndjwg %>) })!
<%= variable %> = _result_function()
