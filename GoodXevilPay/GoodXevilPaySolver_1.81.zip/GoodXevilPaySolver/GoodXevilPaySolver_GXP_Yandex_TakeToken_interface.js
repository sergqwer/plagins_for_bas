<div class="container-fluid">
<%= _.template($('#input_constructor').html())({id:"nbpbsicm", description:"apikey", default_selector: "string", disable_int:true, value_string: "", help: {description: "apikey с сервиса https://t.me/Xevil_check_bot\n\napikey from https://t.me/Xevil_check_bot"} }) %>
<%= _.template($('#input_constructor').html())({id:"iwynuyld", description:"pageurl", default_selector: "string", disable_int:true, value_string: "https://gencfg.ru/captcha-demo-7", help: {description: "Полный URL страницы где находится Yandex Smart Captcha\n\nFull URL of the page where Yandex Smart Captcha is located"} }) %>
<%= _.template($('#input_constructor').html())({id:"itzezlpm", description:"sitekey", default_selector: "string", disable_int:true, value_string: "ydx_dQw4w9WgXcQ", help: {description: "Значение параметра sitekey Yandex Smart Captcha\n\nYandex Smart Captcha sitekey parameter value"} }) %>
<%= _.template($('#variable_constructor').html())({id:"Save", description:"Result", default_variable: "YANDEX_TOKEN", help: {description: ""}}) %>
</div>
<div class="tooltipinternal">
<div class="tr tooltip-paragraph-first-fold">Эта функция получает токен Yandex Smart Captcha через сервис решения капчи https://t.me/Xevil_check_bot</div>
<div class="tr tooltip-paragraph-last-fold">This feature receives a Yandex Smart Captcha token via the captcha solution service https://t.me/Xevil_check_bot</div>
</div>
<%= _.template($('#back').html())({action:"executeandadd", visible:true}) %>
