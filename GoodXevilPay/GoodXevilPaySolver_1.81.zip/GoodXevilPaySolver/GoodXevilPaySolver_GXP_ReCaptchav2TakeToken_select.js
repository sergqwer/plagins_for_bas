var scyjtgpq = GetInputConstructorValue("scyjtgpq", loader);
                 if(scyjtgpq["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var nmihecrv = GetInputConstructorValue("nmihecrv", loader);
                 if(nmihecrv["original"].length == 0)
                 {
                   Invalid("site_url" + " is empty");
                   return;
                 }
var nozggdcx = GetInputConstructorValue("nozggdcx", loader);
                 if(nozggdcx["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_ReCaptchav2TakeToken_code").html())({"scyjtgpq": scyjtgpq["updated"],"nmihecrv": nmihecrv["updated"],"nozggdcx": nozggdcx["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
