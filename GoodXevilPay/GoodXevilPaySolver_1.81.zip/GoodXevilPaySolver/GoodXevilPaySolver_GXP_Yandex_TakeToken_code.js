_call_function(GoodXevilPaySolver_GXP_Yandex_TakeToken,{ "apikey": (<%= nbpbsicm %>),"pageurl": (<%= iwynuyld %>),"sitekey": (<%= itzezlpm %>) })!
<%= variable %> = _result_function()
