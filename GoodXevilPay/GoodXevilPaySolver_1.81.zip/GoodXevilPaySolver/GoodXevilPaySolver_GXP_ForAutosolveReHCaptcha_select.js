var bwfietvh = GetInputConstructorValue("bwfietvh", loader);
                 if(bwfietvh["original"].length == 0)
                 {
                   Invalid("hCaptcha_USE" + " is empty");
                   return;
                 }
var vftgvsls = GetInputConstructorValue("vftgvsls", loader);
                 if(vftgvsls["original"].length == 0)
                 {
                   Invalid("ReCaptcha_USE" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_ForAutosolveReHCaptcha_code").html())({"bwfietvh": bwfietvh["updated"],"vftgvsls": vftgvsls["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
