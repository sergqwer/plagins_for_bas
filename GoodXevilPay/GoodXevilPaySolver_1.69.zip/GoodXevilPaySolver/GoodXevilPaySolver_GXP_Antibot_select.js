var itjxzgvz = GetInputConstructorValue("itjxzgvz", loader);
                 if(itjxzgvz["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var ahrkaxfs = GetInputConstructorValue("ahrkaxfs", loader);
                 if(ahrkaxfs["original"].length == 0)
                 {
                   Invalid("mouse" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_Antibot_code").html())({"itjxzgvz": itjxzgvz["updated"],"ahrkaxfs": ahrkaxfs["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
