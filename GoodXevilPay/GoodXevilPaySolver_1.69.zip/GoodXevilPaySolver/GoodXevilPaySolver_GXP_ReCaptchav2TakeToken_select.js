var pdxqifel = GetInputConstructorValue("pdxqifel", loader);
                 if(pdxqifel["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var ivgralfz = GetInputConstructorValue("ivgralfz", loader);
                 if(ivgralfz["original"].length == 0)
                 {
                   Invalid("site_url" + " is empty");
                   return;
                 }
var dctqgsvs = GetInputConstructorValue("dctqgsvs", loader);
                 if(dctqgsvs["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_ReCaptchav2TakeToken_code").html())({"pdxqifel": pdxqifel["updated"],"ivgralfz": ivgralfz["updated"],"dctqgsvs": dctqgsvs["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
