var onqefhqx = GetInputConstructorValue("onqefhqx", loader);
                 if(onqefhqx["original"].length == 0)
                 {
                   Invalid("hCaptcha_USE" + " is empty");
                   return;
                 }
var mkblptyk = GetInputConstructorValue("mkblptyk", loader);
                 if(mkblptyk["original"].length == 0)
                 {
                   Invalid("ReCaptcha_USE" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_ForAutosolveReHCaptcha_code").html())({"onqefhqx": onqefhqx["updated"],"mkblptyk": mkblptyk["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
