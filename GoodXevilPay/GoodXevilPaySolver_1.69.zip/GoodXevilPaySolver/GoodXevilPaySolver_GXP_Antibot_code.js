_call_function(GoodXevilPaySolver_GXP_Antibot,{ "apikey": (<%= itjxzgvz %>),"mouse": (<%= ahrkaxfs %>) })!
