var xxmvddqj = GetInputConstructorValue("xxmvddqj", loader);
                 if(xxmvddqj["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var puopexvv = GetInputConstructorValue("puopexvv", loader);
                 if(puopexvv["original"].length == 0)
                 {
                   Invalid("captcha_submit" + " is empty");
                   return;
                 }
var fomtwmnc = GetInputConstructorValue("fomtwmnc", loader);
                 if(fomtwmnc["original"].length == 0)
                 {
                   Invalid("foto_captcha" + " is empty");
                   return;
                 }
var sdipbsxu = GetInputConstructorValue("sdipbsxu", loader);
                 if(sdipbsxu["original"].length == 0)
                 {
                   Invalid("pixel_coef" + " is empty");
                   return;
                 }
var nueeitdb = GetInputConstructorValue("nueeitdb", loader);
                 if(nueeitdb["original"].length == 0)
                 {
                   Invalid("reload_captcha" + " is empty");
                   return;
                 }
var fhujjxzq = GetInputConstructorValue("fhujjxzq", loader);
                 if(fhujjxzq["original"].length == 0)
                 {
                   Invalid("type_data" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SolverGeetestIcon_code").html())({"xxmvddqj": xxmvddqj["updated"],"puopexvv": puopexvv["updated"],"fomtwmnc": fomtwmnc["updated"],"sdipbsxu": sdipbsxu["updated"],"nueeitdb": nueeitdb["updated"],"fhujjxzq": fhujjxzq["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
