var nqjwnfdz = GetInputConstructorValue("nqjwnfdz", loader);
                 if(nqjwnfdz["original"].length == 0)
                 {
                   Invalid("arrow_id" + " is empty");
                   return;
                 }
var wsdhkbzg = GetInputConstructorValue("wsdhkbzg", loader);
                 if(wsdhkbzg["original"].length == 0)
                 {
                   Invalid("Attempts" + " is empty");
                   return;
                 }
var szryunjv = GetInputConstructorValue("szryunjv", loader);
                 if(szryunjv["original"].length == 0)
                 {
                   Invalid("avtoupdate" + " is empty");
                   return;
                 }
var uwfmwefb = GetInputConstructorValue("uwfmwefb", loader);
                 if(uwfmwefb["original"].length == 0)
                 {
                   Invalid("button_id" + " is empty");
                   return;
                 }
var tgqlpogx = GetInputConstructorValue("tgqlpogx", loader);
                 if(tgqlpogx["original"].length == 0)
                 {
                   Invalid("coef" + " is empty");
                   return;
                 }
var jfxjwwcr = GetInputConstructorValue("jfxjwwcr", loader);
                 if(jfxjwwcr["original"].length == 0)
                 {
                   Invalid("image id" + " is empty");
                   return;
                 }
var bakrxskd = GetInputConstructorValue("bakrxskd", loader);
                 if(bakrxskd["original"].length == 0)
                 {
                   Invalid("key" + " is empty");
                   return;
                 }
var jtfbscwy = GetInputConstructorValue("jtfbscwy", loader);
                 if(jtfbscwy["original"].length == 0)
                 {
                   Invalid("pixel_koef" + " is empty");
                   return;
                 }
var hdlobxov = GetInputConstructorValue("hdlobxov", loader);
                 if(hdlobxov["original"].length == 0)
                 {
                   Invalid("reload_id" + " is empty");
                   return;
                 }
var llushswx = GetInputConstructorValue("llushswx", loader);
                 if(llushswx["original"].length == 0)
                 {
                   Invalid("slider_type" + " is empty");
                   return;
                 }
var swsrntnv = GetInputConstructorValue("swsrntnv", loader);
                 if(swsrntnv["original"].length == 0)
                 {
                   Invalid("speed" + " is empty");
                   return;
                 }
var litloeel = GetInputConstructorValue("litloeel", loader);
                 if(litloeel["original"].length == 0)
                 {
                   Invalid("type_slide" + " is empty");
                   return;
                 }
var pgeafeie = GetInputConstructorValue("pgeafeie", loader);
                 if(pgeafeie["original"].length == 0)
                 {
                   Invalid("type_swipe" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SliderSolver_code").html())({"nqjwnfdz": nqjwnfdz["updated"],"wsdhkbzg": wsdhkbzg["updated"],"szryunjv": szryunjv["updated"],"uwfmwefb": uwfmwefb["updated"],"tgqlpogx": tgqlpogx["updated"],"jfxjwwcr": jfxjwwcr["updated"],"bakrxskd": bakrxskd["updated"],"jtfbscwy": jtfbscwy["updated"],"hdlobxov": hdlobxov["updated"],"llushswx": llushswx["updated"],"swsrntnv": swsrntnv["updated"],"litloeel": litloeel["updated"],"pgeafeie": pgeafeie["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
