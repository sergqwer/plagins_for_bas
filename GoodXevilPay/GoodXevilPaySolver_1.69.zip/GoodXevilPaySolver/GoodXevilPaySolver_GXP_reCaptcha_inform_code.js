_call_function(GoodXevilPaySolver_GXP_reCaptcha_inform,{  })!
<%= variable %> = _result_function()
