_call_function(GoodXevilPaySolver_GXP_ForAutosolveReHCaptcha,{ "hCaptcha_USE": (<%= onqefhqx %>),"ReCaptcha_USE": (<%= mkblptyk %>) })!
