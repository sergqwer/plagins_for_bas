var hlccaunu = GetInputConstructorValue("hlccaunu", loader);
                 if(hlccaunu["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var troagrqp = GetInputConstructorValue("troagrqp", loader);
                 if(troagrqp["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var ddxdbtyk = GetInputConstructorValue("ddxdbtyk", loader);
                 if(ddxdbtyk["original"].length == 0)
                 {
                   Invalid("siteurl" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_BasiliskCaptcha_code").html())({"hlccaunu": hlccaunu["updated"],"troagrqp": troagrqp["updated"],"ddxdbtyk": ddxdbtyk["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
