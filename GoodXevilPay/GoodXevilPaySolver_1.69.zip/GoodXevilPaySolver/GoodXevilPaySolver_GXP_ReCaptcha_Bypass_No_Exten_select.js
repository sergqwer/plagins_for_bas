var aqcbgwxk = GetInputConstructorValue("aqcbgwxk", loader);
                 if(aqcbgwxk["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var hetasqmy = GetInputConstructorValue("hetasqmy", loader);
                 if(hetasqmy["original"].length == 0)
                 {
                   Invalid("cut_url" + " is empty");
                   return;
                 }
var ejyjljgf = GetInputConstructorValue("ejyjljgf", loader);
                 if(ejyjljgf["original"].length == 0)
                 {
                   Invalid("enterprise" + " is empty");
                   return;
                 }
var rimckjpq = GetInputConstructorValue("rimckjpq", loader);
                 if(rimckjpq["original"].length == 0)
                 {
                   Invalid("index" + " is empty");
                   return;
                 }
var fanhjfau = GetInputConstructorValue("fanhjfau", loader);
                 if(fanhjfau["original"].length == 0)
                 {
                   Invalid("invisible" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_ReCaptcha_Bypass_No_Exten_code").html())({"aqcbgwxk": aqcbgwxk["updated"],"hetasqmy": hetasqmy["updated"],"ejyjljgf": ejyjljgf["updated"],"rimckjpq": rimckjpq["updated"],"fanhjfau": fanhjfau["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
