_call_function(GoodXevilPaySolver_GXP_ReCaptchav2TakeToken,{ "APIKEY": (<%= pdxqifel %>),"site_url": (<%= ivgralfz %>),"sitekey": (<%= dctqgsvs %>) })!
<%= variable %> = _result_function()
