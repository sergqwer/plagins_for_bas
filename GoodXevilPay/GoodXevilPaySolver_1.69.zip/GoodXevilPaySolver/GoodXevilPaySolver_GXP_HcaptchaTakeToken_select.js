var ngpbpbpc = GetInputConstructorValue("ngpbpbpc", loader);
                 if(ngpbpbpc["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var rnlmcdhz = GetInputConstructorValue("rnlmcdhz", loader);
                 if(rnlmcdhz["original"].length == 0)
                 {
                   Invalid("site_url" + " is empty");
                   return;
                 }
var mngkydvg = GetInputConstructorValue("mngkydvg", loader);
                 if(mngkydvg["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_HcaptchaTakeToken_code").html())({"ngpbpbpc": ngpbpbpc["updated"],"rnlmcdhz": rnlmcdhz["updated"],"mngkydvg": mngkydvg["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
