_call_function(GoodXevilPaySolver_GXP_Namars,{ "apikey": (<%= ncmfbtrd %>) })!
<%= variable %> = _result_function()
