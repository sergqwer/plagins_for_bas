var klkoeutm = GetInputConstructorValue("klkoeutm", loader);
                 if(klkoeutm["original"].length == 0)
                 {
                   Invalid("custom_button" + " is empty");
                   return;
                 }
var ebkyhgnw = GetInputConstructorValue("ebkyhgnw", loader);
                 if(ebkyhgnw["original"].length == 0)
                 {
                   Invalid("max_time" + " is empty");
                   return;
                 }
var jaxnswic = GetInputConstructorValue("jaxnswic", loader);
                 if(jaxnswic["original"].length == 0)
                 {
                   Invalid("whait_element" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_AutoBypassCloudFlare_code").html())({"klkoeutm": klkoeutm["updated"],"ebkyhgnw": ebkyhgnw["updated"],"jaxnswic": jaxnswic["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
