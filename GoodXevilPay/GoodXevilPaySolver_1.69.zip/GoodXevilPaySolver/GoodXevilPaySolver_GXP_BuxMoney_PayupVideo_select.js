var trkeztwo = GetInputConstructorValue("trkeztwo", loader);
                 if(trkeztwo["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var ivwxiywt = GetInputConstructorValue("ivwxiywt", loader);
                 if(ivwxiywt["original"].length == 0)
                 {
                   Invalid("timer" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_BuxMoney_PayupVideo_code").html())({"trkeztwo": trkeztwo["updated"],"ivwxiywt": ivwxiywt["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
