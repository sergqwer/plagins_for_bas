_call_function(GoodXevilPaySolver_GXP_AutoBypassCloudFlare,{ "custom_button": (<%= qykdhgdc %>),"max_time": (<%= dqehhqvj %>),"whait_element": (<%= rlvptuju %>) })!
