var mjkbmklq = GetInputConstructorValue("mjkbmklq", loader);
                 if(mjkbmklq["original"].length == 0)
                 {
                   Invalid("arrow_id" + " is empty");
                   return;
                 }
var bxtwxhez = GetInputConstructorValue("bxtwxhez", loader);
                 if(bxtwxhez["original"].length == 0)
                 {
                   Invalid("avtoupdate" + " is empty");
                   return;
                 }
var qiclewaj = GetInputConstructorValue("qiclewaj", loader);
                 if(qiclewaj["original"].length == 0)
                 {
                   Invalid("button_id" + " is empty");
                   return;
                 }
var usfkywbr = GetInputConstructorValue("usfkywbr", loader);
                 if(usfkywbr["original"].length == 0)
                 {
                   Invalid("coef" + " is empty");
                   return;
                 }
var epjfhjmv = GetInputConstructorValue("epjfhjmv", loader);
                 if(epjfhjmv["original"].length == 0)
                 {
                   Invalid("image id" + " is empty");
                   return;
                 }
var ljcxobjd = GetInputConstructorValue("ljcxobjd", loader);
                 if(ljcxobjd["original"].length == 0)
                 {
                   Invalid("key" + " is empty");
                   return;
                 }
var vzjbgxvb = GetInputConstructorValue("vzjbgxvb", loader);
                 if(vzjbgxvb["original"].length == 0)
                 {
                   Invalid("pixel_koef" + " is empty");
                   return;
                 }
var egxajhfx = GetInputConstructorValue("egxajhfx", loader);
                 if(egxajhfx["original"].length == 0)
                 {
                   Invalid("reload_id" + " is empty");
                   return;
                 }
var zzyzcgod = GetInputConstructorValue("zzyzcgod", loader);
                 if(zzyzcgod["original"].length == 0)
                 {
                   Invalid("speed" + " is empty");
                   return;
                 }
var qqqclwal = GetInputConstructorValue("qqqclwal", loader);
                 if(qqqclwal["original"].length == 0)
                 {
                   Invalid("type_slide" + " is empty");
                   return;
                 }
var afzsimpr = GetInputConstructorValue("afzsimpr", loader);
                 if(afzsimpr["original"].length == 0)
                 {
                   Invalid("type_swipe" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SliderSolver_code").html())({"mjkbmklq": mjkbmklq["updated"],"bxtwxhez": bxtwxhez["updated"],"qiclewaj": qiclewaj["updated"],"usfkywbr": usfkywbr["updated"],"epjfhjmv": epjfhjmv["updated"],"ljcxobjd": ljcxobjd["updated"],"vzjbgxvb": vzjbgxvb["updated"],"egxajhfx": egxajhfx["updated"],"zzyzcgod": zzyzcgod["updated"],"qqqclwal": qqqclwal["updated"],"afzsimpr": afzsimpr["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
