_call_function(GoodXevilPaySolver_GXP_Faucetpay_PTC,{ "apikey": (<%= outnqfpt %>) })!
