var qykdhgdc = GetInputConstructorValue("qykdhgdc", loader);
                 if(qykdhgdc["original"].length == 0)
                 {
                   Invalid("custom_button" + " is empty");
                   return;
                 }
var dqehhqvj = GetInputConstructorValue("dqehhqvj", loader);
                 if(dqehhqvj["original"].length == 0)
                 {
                   Invalid("max_time" + " is empty");
                   return;
                 }
var rlvptuju = GetInputConstructorValue("rlvptuju", loader);
                 if(rlvptuju["original"].length == 0)
                 {
                   Invalid("whait_element" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_AutoBypassCloudFlare_code").html())({"qykdhgdc": qykdhgdc["updated"],"dqehhqvj": dqehhqvj["updated"],"rlvptuju": rlvptuju["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
