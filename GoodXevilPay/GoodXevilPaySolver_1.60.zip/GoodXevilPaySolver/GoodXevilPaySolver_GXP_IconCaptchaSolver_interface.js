<div class="container-fluid">
<%= _.template($('#input_constructor').html())({id:"scypatmt", description:"apikey", default_selector: "string", disable_int:true, value_string: "", help: {description: "apikey с сервиса \nhttps://t.me/Xevil_check_bot\n\napikey from the service \nhttps://t.me/Xevil_check_bot"} }) %>
</div>
<div class="tooltipinternal">
<div class="tr tooltip-paragraph-first-fold">Решает Icon капчу через сервис Solver Captcha TG, стоимость одного решения 0.006р</div>
<div class="tr tooltip-paragraph-last-fold">Solves Icon captcha via Solver Captcha TG service, the cost of one solution is 0.006p</div>
</div>
<%= _.template($('#back').html())({action:"executeandadd", visible:true}) %>
