var ihhtfxtd = GetInputConstructorValue("ihhtfxtd", loader);
                 if(ihhtfxtd["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var qilwsjzh = GetInputConstructorValue("qilwsjzh", loader);
                 if(qilwsjzh["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var yhnkhktp = GetInputConstructorValue("yhnkhktp", loader);
                 if(yhnkhktp["original"].length == 0)
                 {
                   Invalid("siteurl" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_BasiliskCaptcha_code").html())({"ihhtfxtd": ihhtfxtd["updated"],"qilwsjzh": qilwsjzh["updated"],"yhnkhktp": yhnkhktp["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
