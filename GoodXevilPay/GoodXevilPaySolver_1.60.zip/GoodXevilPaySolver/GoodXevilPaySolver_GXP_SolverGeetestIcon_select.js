var lizhzjae = GetInputConstructorValue("lizhzjae", loader);
                 if(lizhzjae["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var sadnjocw = GetInputConstructorValue("sadnjocw", loader);
                 if(sadnjocw["original"].length == 0)
                 {
                   Invalid("captcha_submit" + " is empty");
                   return;
                 }
var rexolroh = GetInputConstructorValue("rexolroh", loader);
                 if(rexolroh["original"].length == 0)
                 {
                   Invalid("foto_captcha" + " is empty");
                   return;
                 }
var xsxikrra = GetInputConstructorValue("xsxikrra", loader);
                 if(xsxikrra["original"].length == 0)
                 {
                   Invalid("pixel_coef" + " is empty");
                   return;
                 }
var dssqdsek = GetInputConstructorValue("dssqdsek", loader);
                 if(dssqdsek["original"].length == 0)
                 {
                   Invalid("reload_captcha" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SolverGeetestIcon_code").html())({"lizhzjae": lizhzjae["updated"],"sadnjocw": sadnjocw["updated"],"rexolroh": rexolroh["updated"],"xsxikrra": xsxikrra["updated"],"dssqdsek": dssqdsek["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
