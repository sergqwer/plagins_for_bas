_call_function(GoodXevilPaySolver_GXP_BasiliskCaptcha,{ "apikey": (<%= ihhtfxtd %>),"sitekey": (<%= qilwsjzh %>),"siteurl": (<%= yhnkhktp %>) })!
