var fxgkntif = GetInputConstructorValue("fxgkntif", loader);
                 if(fxgkntif["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var innwifvg = GetInputConstructorValue("innwifvg", loader);
                 if(innwifvg["original"].length == 0)
                 {
                   Invalid("mouse" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_Antibot_code").html())({"fxgkntif": fxgkntif["updated"],"innwifvg": innwifvg["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
