_call_function(GoodXevilPaySolver_GXP_HcaptchaTakeToken,{ "APIKEY": (<%= gvtryqlc %>),"site_url": (<%= jwhivqqk %>),"sitekey": (<%= xqubqgms %>) })!
<%= variable %> = _result_function()
