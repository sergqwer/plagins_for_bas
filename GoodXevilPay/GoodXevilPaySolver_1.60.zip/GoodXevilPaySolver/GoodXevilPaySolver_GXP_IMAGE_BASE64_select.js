var kqyszzmi = GetInputConstructorValue("kqyszzmi", loader);
                 if(kqyszzmi["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var uupphpwp = GetInputConstructorValue("uupphpwp", loader);
                 if(uupphpwp["original"].length == 0)
                 {
                   Invalid("IMAGE_BASE64" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_IMAGE_BASE64_code").html())({"kqyszzmi": kqyszzmi["updated"],"uupphpwp": uupphpwp["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
