_call_function(GoodXevilPaySolver_GXP_ReCaptchav2TakeToken,{ "APIKEY": (<%= ylblrpyc %>),"site_url": (<%= qsfnyqtj %>),"sitekey": (<%= prddnflf %>) })!
<%= variable %> = _result_function()
