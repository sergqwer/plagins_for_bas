var nlraffvf = GetInputConstructorValue("nlraffvf", loader);
                 if(nlraffvf["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var jaahcbjv = GetInputConstructorValue("jaahcbjv", loader);
                 if(jaahcbjv["original"].length == 0)
                 {
                   Invalid("index" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_ReCaptcha_Bypass_No_Exten_code").html())({"nlraffvf": nlraffvf["updated"],"jaahcbjv": jaahcbjv["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
