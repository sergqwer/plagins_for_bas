_call_function(GoodXevilPaySolver_GXP_HcaptchaTakeToken,{ "APIKEY": (<%= saptlpot %>),"site_url": (<%= iiazbmnl %>),"sitekey": (<%= hgmamqyk %>) })!
<%= variable %> = _result_function()
