_call_function(GoodXevilPaySolver_GXP_Namars,{ "apikey": (<%= rujeebvi %>) })!
<%= variable %> = _result_function()
