var xvdpqzxo = GetInputConstructorValue("xvdpqzxo", loader);
                 if(xvdpqzxo["original"].length == 0)
                 {
                   Invalid("arrow_id" + " is empty");
                   return;
                 }
var bevmqcvl = GetInputConstructorValue("bevmqcvl", loader);
                 if(bevmqcvl["original"].length == 0)
                 {
                   Invalid("avtoupdate" + " is empty");
                   return;
                 }
var wntasmep = GetInputConstructorValue("wntasmep", loader);
                 if(wntasmep["original"].length == 0)
                 {
                   Invalid("button_id" + " is empty");
                   return;
                 }
var ocazplca = GetInputConstructorValue("ocazplca", loader);
                 if(ocazplca["original"].length == 0)
                 {
                   Invalid("coef" + " is empty");
                   return;
                 }
var fnilasbe = GetInputConstructorValue("fnilasbe", loader);
                 if(fnilasbe["original"].length == 0)
                 {
                   Invalid("image id" + " is empty");
                   return;
                 }
var xdvcrsio = GetInputConstructorValue("xdvcrsio", loader);
                 if(xdvcrsio["original"].length == 0)
                 {
                   Invalid("key" + " is empty");
                   return;
                 }
var tlrmwgkd = GetInputConstructorValue("tlrmwgkd", loader);
                 if(tlrmwgkd["original"].length == 0)
                 {
                   Invalid("pixel_koef" + " is empty");
                   return;
                 }
var xtnekiyk = GetInputConstructorValue("xtnekiyk", loader);
                 if(xtnekiyk["original"].length == 0)
                 {
                   Invalid("reload_id" + " is empty");
                   return;
                 }
var yjkmjfap = GetInputConstructorValue("yjkmjfap", loader);
                 if(yjkmjfap["original"].length == 0)
                 {
                   Invalid("speed" + " is empty");
                   return;
                 }
var bwncyzxt = GetInputConstructorValue("bwncyzxt", loader);
                 if(bwncyzxt["original"].length == 0)
                 {
                   Invalid("type_slide" + " is empty");
                   return;
                 }
var ratdevmi = GetInputConstructorValue("ratdevmi", loader);
                 if(ratdevmi["original"].length == 0)
                 {
                   Invalid("type_swipe" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SliderSolver_code").html())({"xvdpqzxo": xvdpqzxo["updated"],"bevmqcvl": bevmqcvl["updated"],"wntasmep": wntasmep["updated"],"ocazplca": ocazplca["updated"],"fnilasbe": fnilasbe["updated"],"xdvcrsio": xdvcrsio["updated"],"tlrmwgkd": tlrmwgkd["updated"],"xtnekiyk": xtnekiyk["updated"],"yjkmjfap": yjkmjfap["updated"],"bwncyzxt": bwncyzxt["updated"],"ratdevmi": ratdevmi["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
