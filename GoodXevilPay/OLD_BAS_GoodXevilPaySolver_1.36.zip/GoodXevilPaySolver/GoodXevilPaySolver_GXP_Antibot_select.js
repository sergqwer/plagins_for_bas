var hcqtomjh = GetInputConstructorValue("hcqtomjh", loader);
                 if(hcqtomjh["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var zfwbwrlk = GetInputConstructorValue("zfwbwrlk", loader);
                 if(zfwbwrlk["original"].length == 0)
                 {
                   Invalid("mouse" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_Antibot_code").html())({"hcqtomjh": hcqtomjh["updated"],"zfwbwrlk": zfwbwrlk["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
