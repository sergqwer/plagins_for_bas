var gmmfgmej = GetInputConstructorValue("gmmfgmej", loader);
                 if(gmmfgmej["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var miihrigc = GetInputConstructorValue("miihrigc", loader);
                 if(miihrigc["original"].length == 0)
                 {
                   Invalid("timer" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_BuxMoney_PayupVideo_code").html())({"gmmfgmej": gmmfgmej["updated"],"miihrigc": miihrigc["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
