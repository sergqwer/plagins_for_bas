_call_function(GoodXevilPaySolver_GXP_ReCaptchav2TakeToken,{ "APIKEY": (<%= wriywstk %>),"site_url": (<%= yrbpitgt %>),"sitekey": (<%= zigyyfhv %>) })!
<%= variable %> = _result_function()
