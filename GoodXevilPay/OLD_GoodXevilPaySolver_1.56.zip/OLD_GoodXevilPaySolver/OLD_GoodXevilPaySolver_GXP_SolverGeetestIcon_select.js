var afcsvgpv = GetInputConstructorValue("afcsvgpv", loader);
                 if(afcsvgpv["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var posmumur = GetInputConstructorValue("posmumur", loader);
                 if(posmumur["original"].length == 0)
                 {
                   Invalid("captcha_submit" + " is empty");
                   return;
                 }
var kogjpwcu = GetInputConstructorValue("kogjpwcu", loader);
                 if(kogjpwcu["original"].length == 0)
                 {
                   Invalid("foto_captcha" + " is empty");
                   return;
                 }
var tibegrgh = GetInputConstructorValue("tibegrgh", loader);
                 if(tibegrgh["original"].length == 0)
                 {
                   Invalid("pixel_coef" + " is empty");
                   return;
                 }
var ljkibzbx = GetInputConstructorValue("ljkibzbx", loader);
                 if(ljkibzbx["original"].length == 0)
                 {
                   Invalid("reload_captcha" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#OLD_GoodXevilPaySolver_GXP_SolverGeetestIcon_code").html())({"afcsvgpv": afcsvgpv["updated"],"posmumur": posmumur["updated"],"kogjpwcu": kogjpwcu["updated"],"tibegrgh": tibegrgh["updated"],"ljkibzbx": ljkibzbx["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
