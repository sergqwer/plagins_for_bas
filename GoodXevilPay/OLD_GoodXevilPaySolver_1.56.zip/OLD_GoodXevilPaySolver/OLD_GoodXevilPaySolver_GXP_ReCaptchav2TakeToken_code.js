_call_function(OLD_GoodXevilPaySolver_GXP_ReCaptchav2TakeToken,{ "APIKEY": (<%= nqydffka %>),"site_url": (<%= jkuuvlpm %>),"sitekey": (<%= axjxovrb %>) })!
<%= variable %> = _result_function()
