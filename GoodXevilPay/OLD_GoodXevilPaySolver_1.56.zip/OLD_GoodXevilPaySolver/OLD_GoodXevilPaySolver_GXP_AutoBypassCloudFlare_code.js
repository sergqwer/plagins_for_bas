_call_function(OLD_GoodXevilPaySolver_GXP_AutoBypassCloudFlare,{ "custom_button": (<%= vtqjfqrs %>),"max_time": (<%= nslpqiel %>),"whait_element": (<%= smnozczf %>) })!
