var imfrjrso = GetInputConstructorValue("imfrjrso", loader);
                 if(imfrjrso["original"].length == 0)
                 {
                   Invalid("arrow_id" + " is empty");
                   return;
                 }
var ojkanxsb = GetInputConstructorValue("ojkanxsb", loader);
                 if(ojkanxsb["original"].length == 0)
                 {
                   Invalid("avtoupdate" + " is empty");
                   return;
                 }
var cxpqdqrs = GetInputConstructorValue("cxpqdqrs", loader);
                 if(cxpqdqrs["original"].length == 0)
                 {
                   Invalid("button_id" + " is empty");
                   return;
                 }
var octffxxd = GetInputConstructorValue("octffxxd", loader);
                 if(octffxxd["original"].length == 0)
                 {
                   Invalid("coef" + " is empty");
                   return;
                 }
var jkobfgam = GetInputConstructorValue("jkobfgam", loader);
                 if(jkobfgam["original"].length == 0)
                 {
                   Invalid("image id" + " is empty");
                   return;
                 }
var qdhbwpvl = GetInputConstructorValue("qdhbwpvl", loader);
                 if(qdhbwpvl["original"].length == 0)
                 {
                   Invalid("key" + " is empty");
                   return;
                 }
var gwctnapf = GetInputConstructorValue("gwctnapf", loader);
                 if(gwctnapf["original"].length == 0)
                 {
                   Invalid("pixel_koef" + " is empty");
                   return;
                 }
var aesosddk = GetInputConstructorValue("aesosddk", loader);
                 if(aesosddk["original"].length == 0)
                 {
                   Invalid("reload_id" + " is empty");
                   return;
                 }
var ggychsvn = GetInputConstructorValue("ggychsvn", loader);
                 if(ggychsvn["original"].length == 0)
                 {
                   Invalid("speed" + " is empty");
                   return;
                 }
var gawqarkw = GetInputConstructorValue("gawqarkw", loader);
                 if(gawqarkw["original"].length == 0)
                 {
                   Invalid("type_slide" + " is empty");
                   return;
                 }
var flreojsm = GetInputConstructorValue("flreojsm", loader);
                 if(flreojsm["original"].length == 0)
                 {
                   Invalid("type_swipe" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#OLD_GoodXevilPaySolver_GXP_SliderSolver_code").html())({"imfrjrso": imfrjrso["updated"],"ojkanxsb": ojkanxsb["updated"],"cxpqdqrs": cxpqdqrs["updated"],"octffxxd": octffxxd["updated"],"jkobfgam": jkobfgam["updated"],"qdhbwpvl": qdhbwpvl["updated"],"gwctnapf": gwctnapf["updated"],"aesosddk": aesosddk["updated"],"ggychsvn": ggychsvn["updated"],"gawqarkw": gawqarkw["updated"],"flreojsm": flreojsm["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
