var nqydffka = GetInputConstructorValue("nqydffka", loader);
                 if(nqydffka["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var jkuuvlpm = GetInputConstructorValue("jkuuvlpm", loader);
                 if(jkuuvlpm["original"].length == 0)
                 {
                   Invalid("site_url" + " is empty");
                   return;
                 }
var axjxovrb = GetInputConstructorValue("axjxovrb", loader);
                 if(axjxovrb["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#OLD_GoodXevilPaySolver_GXP_ReCaptchav2TakeToken_code").html())({"nqydffka": nqydffka["updated"],"jkuuvlpm": jkuuvlpm["updated"],"axjxovrb": axjxovrb["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
