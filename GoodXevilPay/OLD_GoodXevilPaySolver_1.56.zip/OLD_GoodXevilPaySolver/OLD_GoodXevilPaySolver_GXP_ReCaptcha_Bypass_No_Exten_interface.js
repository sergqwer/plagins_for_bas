<div class="container-fluid">
<%= _.template($('#input_constructor').html())({id:"zzbrcwqn", description:"apikey", default_selector: "string", disable_int:true, value_string: "", help: {description: "apikey с сервиса https://t.me/Xevil_check_bot\n\napikey from https://t.me/Xevil_check_bot"} }) %>
</div>
<div class="tooltipinternal">
<div class="tr tooltip-paragraph-first-fold">Автоматически решает ReCaptcha на странице без использования расширения, и сторонних js в коде страницы</div>
<div class="tr tooltip-paragraph-last-fold">Automatically solves ReCaptcha on the page without using extension, and third-party js in the page code</div>
</div>
<%= _.template($('#back').html())({action:"executeandadd", visible:true}) %>
