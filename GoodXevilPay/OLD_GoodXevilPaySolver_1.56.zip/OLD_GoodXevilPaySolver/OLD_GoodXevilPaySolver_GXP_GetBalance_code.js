_call_function(OLD_GoodXevilPaySolver_GXP_GetBalance,{ "APIKEY": (<%= fjxcvsny %>) })!
<%= variable %> = _result_function()
