_call_function(OLD_GoodXevilPaySolver_GXP_Antibot,{ "apikey": (<%= euxpvgce %>),"mouse": (<%= moyocsbw %>) })!
