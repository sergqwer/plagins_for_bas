var vtqjfqrs = GetInputConstructorValue("vtqjfqrs", loader);
                 if(vtqjfqrs["original"].length == 0)
                 {
                   Invalid("custom_button" + " is empty");
                   return;
                 }
var nslpqiel = GetInputConstructorValue("nslpqiel", loader);
                 if(nslpqiel["original"].length == 0)
                 {
                   Invalid("max_time" + " is empty");
                   return;
                 }
var smnozczf = GetInputConstructorValue("smnozczf", loader);
                 if(smnozczf["original"].length == 0)
                 {
                   Invalid("whait_element" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#OLD_GoodXevilPaySolver_GXP_AutoBypassCloudFlare_code").html())({"vtqjfqrs": vtqjfqrs["updated"],"nslpqiel": nslpqiel["updated"],"smnozczf": smnozczf["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
