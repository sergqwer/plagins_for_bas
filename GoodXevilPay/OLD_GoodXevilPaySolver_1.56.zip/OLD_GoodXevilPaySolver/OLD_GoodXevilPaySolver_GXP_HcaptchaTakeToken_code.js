_call_function(OLD_GoodXevilPaySolver_GXP_HcaptchaTakeToken,{ "APIKEY": (<%= dapkjsbv %>),"site_url": (<%= zsxxauza %>),"sitekey": (<%= vtsqrzvl %>) })!
<%= variable %> = _result_function()
