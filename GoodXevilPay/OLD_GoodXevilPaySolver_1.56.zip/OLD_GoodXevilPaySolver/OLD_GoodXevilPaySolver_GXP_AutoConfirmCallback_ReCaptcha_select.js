var bnsvujwg = GetInputConstructorValue("bnsvujwg", loader);
                 if(bnsvujwg["original"].length == 0)
                 {
                   Invalid("token" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#OLD_GoodXevilPaySolver_GXP_AutoConfirmCallback_ReCaptcha_code").html())({"bnsvujwg": bnsvujwg["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
