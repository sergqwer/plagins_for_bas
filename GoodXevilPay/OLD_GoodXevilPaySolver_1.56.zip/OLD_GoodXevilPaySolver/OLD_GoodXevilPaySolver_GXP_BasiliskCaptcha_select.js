var pliqdenn = GetInputConstructorValue("pliqdenn", loader);
                 if(pliqdenn["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var mdhzoqkj = GetInputConstructorValue("mdhzoqkj", loader);
                 if(mdhzoqkj["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var kfpewbvf = GetInputConstructorValue("kfpewbvf", loader);
                 if(kfpewbvf["original"].length == 0)
                 {
                   Invalid("siteurl" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#OLD_GoodXevilPaySolver_GXP_BasiliskCaptcha_code").html())({"pliqdenn": pliqdenn["updated"],"mdhzoqkj": mdhzoqkj["updated"],"kfpewbvf": kfpewbvf["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
