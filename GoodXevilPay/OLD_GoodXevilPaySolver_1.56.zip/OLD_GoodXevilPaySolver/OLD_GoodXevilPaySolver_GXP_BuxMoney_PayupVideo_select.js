var dupencah = GetInputConstructorValue("dupencah", loader);
                 if(dupencah["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var idouvnuw = GetInputConstructorValue("idouvnuw", loader);
                 if(idouvnuw["original"].length == 0)
                 {
                   Invalid("timer" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#OLD_GoodXevilPaySolver_GXP_BuxMoney_PayupVideo_code").html())({"dupencah": dupencah["updated"],"idouvnuw": idouvnuw["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
