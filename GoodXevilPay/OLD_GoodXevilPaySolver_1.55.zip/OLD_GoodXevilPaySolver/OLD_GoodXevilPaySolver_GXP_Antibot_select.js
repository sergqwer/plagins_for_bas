var nsrpdwys = GetInputConstructorValue("nsrpdwys", loader);
                 if(nsrpdwys["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var lzqdnfam = GetInputConstructorValue("lzqdnfam", loader);
                 if(lzqdnfam["original"].length == 0)
                 {
                   Invalid("mouse" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#OLD_GoodXevilPaySolver_GXP_Antibot_code").html())({"nsrpdwys": nsrpdwys["updated"],"lzqdnfam": lzqdnfam["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
