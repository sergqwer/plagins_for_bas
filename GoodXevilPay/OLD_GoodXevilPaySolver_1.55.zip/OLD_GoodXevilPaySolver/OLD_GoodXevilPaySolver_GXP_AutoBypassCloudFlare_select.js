var umroaomu = GetInputConstructorValue("umroaomu", loader);
                 if(umroaomu["original"].length == 0)
                 {
                   Invalid("custom_button" + " is empty");
                   return;
                 }
var cnbtapht = GetInputConstructorValue("cnbtapht", loader);
                 if(cnbtapht["original"].length == 0)
                 {
                   Invalid("max_time" + " is empty");
                   return;
                 }
var uygqupei = GetInputConstructorValue("uygqupei", loader);
                 if(uygqupei["original"].length == 0)
                 {
                   Invalid("whait_element" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#OLD_GoodXevilPaySolver_GXP_AutoBypassCloudFlare_code").html())({"umroaomu": umroaomu["updated"],"cnbtapht": cnbtapht["updated"],"uygqupei": uygqupei["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
