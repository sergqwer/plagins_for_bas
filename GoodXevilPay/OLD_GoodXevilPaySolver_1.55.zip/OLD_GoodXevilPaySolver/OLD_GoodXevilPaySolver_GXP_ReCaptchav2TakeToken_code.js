_call_function(OLD_GoodXevilPaySolver_GXP_ReCaptchav2TakeToken,{ "APIKEY": (<%= nqrtvqkc %>),"site_url": (<%= dpkfyuqb %>),"sitekey": (<%= mckfmlpn %>) })!
<%= variable %> = _result_function()
