var kzzgdlgd = GetInputConstructorValue("kzzgdlgd", loader);
                 if(kzzgdlgd["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var uuaqvqvw = GetInputConstructorValue("uuaqvqvw", loader);
                 if(uuaqvqvw["original"].length == 0)
                 {
                   Invalid("site_url" + " is empty");
                   return;
                 }
var gpijekeq = GetInputConstructorValue("gpijekeq", loader);
                 if(gpijekeq["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#OLD_GoodXevilPaySolver_GXP_HcaptchaTakeToken_code").html())({"kzzgdlgd": kzzgdlgd["updated"],"uuaqvqvw": uuaqvqvw["updated"],"gpijekeq": gpijekeq["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
