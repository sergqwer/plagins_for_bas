var iybthbeu = GetInputConstructorValue("iybthbeu", loader);
                 if(iybthbeu["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var okyglysp = GetInputConstructorValue("okyglysp", loader);
                 if(okyglysp["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var xcptmvcg = GetInputConstructorValue("xcptmvcg", loader);
                 if(xcptmvcg["original"].length == 0)
                 {
                   Invalid("siteurl" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#OLD_GoodXevilPaySolver_GXP_BasiliskCaptcha_code").html())({"iybthbeu": iybthbeu["updated"],"okyglysp": okyglysp["updated"],"xcptmvcg": xcptmvcg["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
