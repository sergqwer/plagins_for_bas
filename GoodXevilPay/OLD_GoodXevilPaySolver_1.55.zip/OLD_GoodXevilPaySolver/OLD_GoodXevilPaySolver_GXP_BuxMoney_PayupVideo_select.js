var dzjysznt = GetInputConstructorValue("dzjysznt", loader);
                 if(dzjysznt["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var bqtyomnl = GetInputConstructorValue("bqtyomnl", loader);
                 if(bqtyomnl["original"].length == 0)
                 {
                   Invalid("timer" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#OLD_GoodXevilPaySolver_GXP_BuxMoney_PayupVideo_code").html())({"dzjysznt": dzjysznt["updated"],"bqtyomnl": bqtyomnl["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
