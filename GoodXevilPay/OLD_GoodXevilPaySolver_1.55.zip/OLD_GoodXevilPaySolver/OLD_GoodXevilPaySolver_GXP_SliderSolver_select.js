var ukcaxonf = GetInputConstructorValue("ukcaxonf", loader);
                 if(ukcaxonf["original"].length == 0)
                 {
                   Invalid("arrow_id" + " is empty");
                   return;
                 }
var iklsqpwd = GetInputConstructorValue("iklsqpwd", loader);
                 if(iklsqpwd["original"].length == 0)
                 {
                   Invalid("avtoupdate" + " is empty");
                   return;
                 }
var smanxmqe = GetInputConstructorValue("smanxmqe", loader);
                 if(smanxmqe["original"].length == 0)
                 {
                   Invalid("button_id" + " is empty");
                   return;
                 }
var mrwyttsy = GetInputConstructorValue("mrwyttsy", loader);
                 if(mrwyttsy["original"].length == 0)
                 {
                   Invalid("coef" + " is empty");
                   return;
                 }
var zrrqhscp = GetInputConstructorValue("zrrqhscp", loader);
                 if(zrrqhscp["original"].length == 0)
                 {
                   Invalid("image id" + " is empty");
                   return;
                 }
var xxpybkup = GetInputConstructorValue("xxpybkup", loader);
                 if(xxpybkup["original"].length == 0)
                 {
                   Invalid("key" + " is empty");
                   return;
                 }
var qjrefksy = GetInputConstructorValue("qjrefksy", loader);
                 if(qjrefksy["original"].length == 0)
                 {
                   Invalid("pixel_koef" + " is empty");
                   return;
                 }
var pgtgzexm = GetInputConstructorValue("pgtgzexm", loader);
                 if(pgtgzexm["original"].length == 0)
                 {
                   Invalid("reload_id" + " is empty");
                   return;
                 }
var oxautpcj = GetInputConstructorValue("oxautpcj", loader);
                 if(oxautpcj["original"].length == 0)
                 {
                   Invalid("speed" + " is empty");
                   return;
                 }
var odadxjme = GetInputConstructorValue("odadxjme", loader);
                 if(odadxjme["original"].length == 0)
                 {
                   Invalid("type_slide" + " is empty");
                   return;
                 }
var xlijrihm = GetInputConstructorValue("xlijrihm", loader);
                 if(xlijrihm["original"].length == 0)
                 {
                   Invalid("type_swipe" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#OLD_GoodXevilPaySolver_GXP_SliderSolver_code").html())({"ukcaxonf": ukcaxonf["updated"],"iklsqpwd": iklsqpwd["updated"],"smanxmqe": smanxmqe["updated"],"mrwyttsy": mrwyttsy["updated"],"zrrqhscp": zrrqhscp["updated"],"xxpybkup": xxpybkup["updated"],"qjrefksy": qjrefksy["updated"],"pgtgzexm": pgtgzexm["updated"],"oxautpcj": oxautpcj["updated"],"odadxjme": odadxjme["updated"],"xlijrihm": xlijrihm["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
