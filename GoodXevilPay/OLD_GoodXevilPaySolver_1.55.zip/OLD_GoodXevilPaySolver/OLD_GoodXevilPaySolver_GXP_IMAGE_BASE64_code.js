_call_function(OLD_GoodXevilPaySolver_GXP_IMAGE_BASE64,{ "APIKEY": (<%= sgcwbiee %>),"IMAGE_BASE64": (<%= orgcrfzu %>) })!
<%= variable %> = _result_function()
