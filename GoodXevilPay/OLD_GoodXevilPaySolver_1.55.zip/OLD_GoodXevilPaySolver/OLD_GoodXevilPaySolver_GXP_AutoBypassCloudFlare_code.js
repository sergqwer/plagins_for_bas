_call_function(OLD_GoodXevilPaySolver_GXP_AutoBypassCloudFlare,{ "custom_button": (<%= umroaomu %>),"max_time": (<%= cnbtapht %>),"whait_element": (<%= uygqupei %>) })!
