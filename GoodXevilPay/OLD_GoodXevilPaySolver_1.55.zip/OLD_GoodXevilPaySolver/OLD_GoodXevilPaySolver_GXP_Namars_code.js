_call_function(OLD_GoodXevilPaySolver_GXP_Namars,{ "apikey": (<%= abmvhslk %>) })!
<%= variable %> = _result_function()
