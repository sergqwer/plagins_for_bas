var edglitii = GetInputConstructorValue("edglitii", loader);
                 if(edglitii["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var qfopqnwf = GetInputConstructorValue("qfopqnwf", loader);
                 if(qfopqnwf["original"].length == 0)
                 {
                   Invalid("captcha_submit" + " is empty");
                   return;
                 }
var zbogpdaw = GetInputConstructorValue("zbogpdaw", loader);
                 if(zbogpdaw["original"].length == 0)
                 {
                   Invalid("foto_captcha" + " is empty");
                   return;
                 }
var fivoqjvb = GetInputConstructorValue("fivoqjvb", loader);
                 if(fivoqjvb["original"].length == 0)
                 {
                   Invalid("pixel_coef" + " is empty");
                   return;
                 }
var aqfpjxfr = GetInputConstructorValue("aqfpjxfr", loader);
                 if(aqfpjxfr["original"].length == 0)
                 {
                   Invalid("reload_captcha" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#OLD_GoodXevilPaySolver_GXP_SolverGeetestIcon_code").html())({"edglitii": edglitii["updated"],"qfopqnwf": qfopqnwf["updated"],"zbogpdaw": zbogpdaw["updated"],"fivoqjvb": fivoqjvb["updated"],"aqfpjxfr": aqfpjxfr["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
