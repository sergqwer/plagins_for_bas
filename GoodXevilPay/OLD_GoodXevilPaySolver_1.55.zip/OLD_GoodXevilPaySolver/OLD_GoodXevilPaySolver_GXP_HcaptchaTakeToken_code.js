_call_function(OLD_GoodXevilPaySolver_GXP_HcaptchaTakeToken,{ "APIKEY": (<%= kzzgdlgd %>),"site_url": (<%= uuaqvqvw %>),"sitekey": (<%= gpijekeq %>) })!
<%= variable %> = _result_function()
