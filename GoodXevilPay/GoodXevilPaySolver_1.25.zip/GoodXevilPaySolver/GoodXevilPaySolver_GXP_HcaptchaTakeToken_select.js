var nbaiozir = GetInputConstructorValue("nbaiozir", loader);
                 if(nbaiozir["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var wvtsydlo = GetInputConstructorValue("wvtsydlo", loader);
                 if(wvtsydlo["original"].length == 0)
                 {
                   Invalid("site_url" + " is empty");
                   return;
                 }
var kwcantaa = GetInputConstructorValue("kwcantaa", loader);
                 if(kwcantaa["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_HcaptchaTakeToken_code").html())({"nbaiozir": nbaiozir["updated"],"wvtsydlo": wvtsydlo["updated"],"kwcantaa": kwcantaa["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
