_call_function(GoodXevilPaySolver_GXP_IMAGE_BASE64,{ "APIKEY": (<%= umocayyl %>),"IMAGE_BASE64": (<%= thwajnfd %>) })!
<%= variable %> = _result_function()
