var umocayyl = GetInputConstructorValue("umocayyl", loader);
                 if(umocayyl["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var thwajnfd = GetInputConstructorValue("thwajnfd", loader);
                 if(thwajnfd["original"].length == 0)
                 {
                   Invalid("IMAGE_BASE64" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_IMAGE_BASE64_code").html())({"umocayyl": umocayyl["updated"],"thwajnfd": thwajnfd["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
