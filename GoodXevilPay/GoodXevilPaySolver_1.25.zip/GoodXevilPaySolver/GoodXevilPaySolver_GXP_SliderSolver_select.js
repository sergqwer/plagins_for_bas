var ctgyrcbb = GetInputConstructorValue("ctgyrcbb", loader);
                 if(ctgyrcbb["original"].length == 0)
                 {
                   Invalid("arrow_id" + " is empty");
                   return;
                 }
var oxrrwwbf = GetInputConstructorValue("oxrrwwbf", loader);
                 if(oxrrwwbf["original"].length == 0)
                 {
                   Invalid("avtoupdate" + " is empty");
                   return;
                 }
var nbyvgumf = GetInputConstructorValue("nbyvgumf", loader);
                 if(nbyvgumf["original"].length == 0)
                 {
                   Invalid("button_id" + " is empty");
                   return;
                 }
var tviwponk = GetInputConstructorValue("tviwponk", loader);
                 if(tviwponk["original"].length == 0)
                 {
                   Invalid("coef" + " is empty");
                   return;
                 }
var tujxomqy = GetInputConstructorValue("tujxomqy", loader);
                 if(tujxomqy["original"].length == 0)
                 {
                   Invalid("image id" + " is empty");
                   return;
                 }
var pqwhejnv = GetInputConstructorValue("pqwhejnv", loader);
                 if(pqwhejnv["original"].length == 0)
                 {
                   Invalid("key" + " is empty");
                   return;
                 }
var qfkrtygn = GetInputConstructorValue("qfkrtygn", loader);
                 if(qfkrtygn["original"].length == 0)
                 {
                   Invalid("pixel_koef" + " is empty");
                   return;
                 }
var ygfotgol = GetInputConstructorValue("ygfotgol", loader);
                 if(ygfotgol["original"].length == 0)
                 {
                   Invalid("reload_id" + " is empty");
                   return;
                 }
var auswqoha = GetInputConstructorValue("auswqoha", loader);
                 if(auswqoha["original"].length == 0)
                 {
                   Invalid("speed" + " is empty");
                   return;
                 }
var qhkjgean = GetInputConstructorValue("qhkjgean", loader);
                 if(qhkjgean["original"].length == 0)
                 {
                   Invalid("type_slide" + " is empty");
                   return;
                 }
var kwmxognf = GetInputConstructorValue("kwmxognf", loader);
                 if(kwmxognf["original"].length == 0)
                 {
                   Invalid("type_swipe" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SliderSolver_code").html())({"ctgyrcbb": ctgyrcbb["updated"],"oxrrwwbf": oxrrwwbf["updated"],"nbyvgumf": nbyvgumf["updated"],"tviwponk": tviwponk["updated"],"tujxomqy": tujxomqy["updated"],"pqwhejnv": pqwhejnv["updated"],"qfkrtygn": qfkrtygn["updated"],"ygfotgol": ygfotgol["updated"],"auswqoha": auswqoha["updated"],"qhkjgean": qhkjgean["updated"],"kwmxognf": kwmxognf["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
