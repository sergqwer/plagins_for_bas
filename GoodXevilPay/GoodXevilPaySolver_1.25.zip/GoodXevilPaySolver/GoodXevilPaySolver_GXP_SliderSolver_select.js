var kerqtrtw = GetInputConstructorValue("kerqtrtw", loader);
                 if(kerqtrtw["original"].length == 0)
                 {
                   Invalid("arrow_id" + " is empty");
                   return;
                 }
var lqzjyddd = GetInputConstructorValue("lqzjyddd", loader);
                 if(lqzjyddd["original"].length == 0)
                 {
                   Invalid("avtoupdate" + " is empty");
                   return;
                 }
var jaufwexm = GetInputConstructorValue("jaufwexm", loader);
                 if(jaufwexm["original"].length == 0)
                 {
                   Invalid("button_id" + " is empty");
                   return;
                 }
var jfftteso = GetInputConstructorValue("jfftteso", loader);
                 if(jfftteso["original"].length == 0)
                 {
                   Invalid("coef" + " is empty");
                   return;
                 }
var hlbiospq = GetInputConstructorValue("hlbiospq", loader);
                 if(hlbiospq["original"].length == 0)
                 {
                   Invalid("image id" + " is empty");
                   return;
                 }
var domdojum = GetInputConstructorValue("domdojum", loader);
                 if(domdojum["original"].length == 0)
                 {
                   Invalid("key" + " is empty");
                   return;
                 }
var qwrozhex = GetInputConstructorValue("qwrozhex", loader);
                 if(qwrozhex["original"].length == 0)
                 {
                   Invalid("pixel_koef" + " is empty");
                   return;
                 }
var mjciwwgw = GetInputConstructorValue("mjciwwgw", loader);
                 if(mjciwwgw["original"].length == 0)
                 {
                   Invalid("reload_id" + " is empty");
                   return;
                 }
var nmfoomsl = GetInputConstructorValue("nmfoomsl", loader);
                 if(nmfoomsl["original"].length == 0)
                 {
                   Invalid("speed" + " is empty");
                   return;
                 }
var ipimvcfd = GetInputConstructorValue("ipimvcfd", loader);
                 if(ipimvcfd["original"].length == 0)
                 {
                   Invalid("type_slide" + " is empty");
                   return;
                 }
var odetdkle = GetInputConstructorValue("odetdkle", loader);
                 if(odetdkle["original"].length == 0)
                 {
                   Invalid("type_swipe" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SliderSolver_code").html())({"kerqtrtw": kerqtrtw["updated"],"lqzjyddd": lqzjyddd["updated"],"jaufwexm": jaufwexm["updated"],"jfftteso": jfftteso["updated"],"hlbiospq": hlbiospq["updated"],"domdojum": domdojum["updated"],"qwrozhex": qwrozhex["updated"],"mjciwwgw": mjciwwgw["updated"],"nmfoomsl": nmfoomsl["updated"],"ipimvcfd": ipimvcfd["updated"],"odetdkle": odetdkle["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
