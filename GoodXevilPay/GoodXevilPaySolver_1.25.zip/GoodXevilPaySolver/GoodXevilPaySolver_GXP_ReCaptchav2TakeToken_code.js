_call_function(GoodXevilPaySolver_GXP_ReCaptchav2TakeToken,{ "APIKEY": (<%= tvybuviw %>),"site_url": (<%= jqxshtvs %>),"sitekey": (<%= bwqnvazb %>) })!
<%= variable %> = _result_function()
