_call_function(GoodXevilPaySolver_GXP_ReCaptchav2TakeToken,{ "APIKEY": (<%= ctzbratw %>),"site_url": (<%= evcjojul %>),"sitekey": (<%= qhcxoyvg %>) })!
<%= variable %> = _result_function()
