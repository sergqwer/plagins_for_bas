_call_function(GoodXevilPaySolver_GXP_HcaptchaTakeToken,{ "APIKEY": (<%= nbaiozir %>),"site_url": (<%= wvtsydlo %>),"sitekey": (<%= kwcantaa %>) })!
<%= variable %> = _result_function()
