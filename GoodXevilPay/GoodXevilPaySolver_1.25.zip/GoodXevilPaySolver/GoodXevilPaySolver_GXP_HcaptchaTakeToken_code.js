_call_function(GoodXevilPaySolver_GXP_HcaptchaTakeToken,{ "APIKEY": (<%= kbejxctl %>),"site_url": (<%= gxhesanm %>),"sitekey": (<%= bfstlgfk %>) })!
<%= variable %> = _result_function()
