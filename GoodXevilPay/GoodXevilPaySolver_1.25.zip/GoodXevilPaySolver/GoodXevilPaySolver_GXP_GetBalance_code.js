_call_function(GoodXevilPaySolver_GXP_GetBalance,{ "APIKEY": (<%= lpovjgzk %>) })!
<%= variable %> = _result_function()
