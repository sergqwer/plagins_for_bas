_call_function(GoodXevilPaySolver_GXP_Antibot,{ "apikey": (<%= yupvsnxi %>),"mouse": (<%= zjabtcxg %>) })!
