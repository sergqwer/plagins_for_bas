var bcfhyyxq = GetInputConstructorValue("bcfhyyxq", loader);
                 if(bcfhyyxq["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var janzwdsi = GetInputConstructorValue("janzwdsi", loader);
                 if(janzwdsi["original"].length == 0)
                 {
                   Invalid("button_capthca" + " is empty");
                   return;
                 }
var krrdgjqo = GetInputConstructorValue("krrdgjqo", loader);
                 if(krrdgjqo["original"].length == 0)
                 {
                   Invalid("captcha_submit" + " is empty");
                   return;
                 }
var vdvrzgur = GetInputConstructorValue("vdvrzgur", loader);
                 if(vdvrzgur["original"].length == 0)
                 {
                   Invalid("foto_captcha" + " is empty");
                   return;
                 }
var egscetrd = GetInputConstructorValue("egscetrd", loader);
                 if(egscetrd["original"].length == 0)
                 {
                   Invalid("reload_captcha" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SolverGeetestIcon_code").html())({"bcfhyyxq": bcfhyyxq["updated"],"janzwdsi": janzwdsi["updated"],"krrdgjqo": krrdgjqo["updated"],"vdvrzgur": vdvrzgur["updated"],"egscetrd": egscetrd["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
