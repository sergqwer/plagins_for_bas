_call_function(GoodXevilPaySolver_GXP_HcaptchaTakeToken,{ "APIKEY": (<%= gsyakklq %>),"site_url": (<%= tsvwxkpv %>),"sitekey": (<%= rehgcjai %>) })!
<%= variable %> = _result_function()
