var xaciirxn = GetInputConstructorValue("xaciirxn", loader);
                 if(xaciirxn["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var tclhryva = GetInputConstructorValue("tclhryva", loader);
                 if(tclhryva["original"].length == 0)
                 {
                   Invalid("arab_fix" + " is empty");
                   return;
                 }
var dnffrwnw = GetInputConstructorValue("dnffrwnw", loader);
                 if(dnffrwnw["original"].length == 0)
                 {
                   Invalid("captcha_submit" + " is empty");
                   return;
                 }
var cnobdctr = GetInputConstructorValue("cnobdctr", loader);
                 if(cnobdctr["original"].length == 0)
                 {
                   Invalid("foto_captcha" + " is empty");
                   return;
                 }
var nilmcwmm = GetInputConstructorValue("nilmcwmm", loader);
                 if(nilmcwmm["original"].length == 0)
                 {
                   Invalid("pixel_coef" + " is empty");
                   return;
                 }
var msllzxpl = GetInputConstructorValue("msllzxpl", loader);
                 if(msllzxpl["original"].length == 0)
                 {
                   Invalid("reload_captcha" + " is empty");
                   return;
                 }
var syftgpiy = GetInputConstructorValue("syftgpiy", loader);
                 if(syftgpiy["original"].length == 0)
                 {
                   Invalid("type_data" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SolverGeetestIcon_code").html())({"xaciirxn": xaciirxn["updated"],"tclhryva": tclhryva["updated"],"dnffrwnw": dnffrwnw["updated"],"cnobdctr": cnobdctr["updated"],"nilmcwmm": nilmcwmm["updated"],"msllzxpl": msllzxpl["updated"],"syftgpiy": syftgpiy["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
