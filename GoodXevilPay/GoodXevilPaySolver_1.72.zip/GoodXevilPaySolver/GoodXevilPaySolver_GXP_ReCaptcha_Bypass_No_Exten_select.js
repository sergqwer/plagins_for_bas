var egqucufn = GetInputConstructorValue("egqucufn", loader);
                 if(egqucufn["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var mywnstnz = GetInputConstructorValue("mywnstnz", loader);
                 if(mywnstnz["original"].length == 0)
                 {
                   Invalid("cut_url" + " is empty");
                   return;
                 }
var hzgusjtc = GetInputConstructorValue("hzgusjtc", loader);
                 if(hzgusjtc["original"].length == 0)
                 {
                   Invalid("enterprise" + " is empty");
                   return;
                 }
var lckhvngl = GetInputConstructorValue("lckhvngl", loader);
                 if(lckhvngl["original"].length == 0)
                 {
                   Invalid("index" + " is empty");
                   return;
                 }
var muugcxuu = GetInputConstructorValue("muugcxuu", loader);
                 if(muugcxuu["original"].length == 0)
                 {
                   Invalid("invisible" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_ReCaptcha_Bypass_No_Exten_code").html())({"egqucufn": egqucufn["updated"],"mywnstnz": mywnstnz["updated"],"hzgusjtc": hzgusjtc["updated"],"lckhvngl": lckhvngl["updated"],"muugcxuu": muugcxuu["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
