var pdcustkn = GetInputConstructorValue("pdcustkn", loader);
                 if(pdcustkn["original"].length == 0)
                 {
                   Invalid("arrow_id" + " is empty");
                   return;
                 }
var vzzfuffe = GetInputConstructorValue("vzzfuffe", loader);
                 if(vzzfuffe["original"].length == 0)
                 {
                   Invalid("Attempts" + " is empty");
                   return;
                 }
var vidfssfi = GetInputConstructorValue("vidfssfi", loader);
                 if(vidfssfi["original"].length == 0)
                 {
                   Invalid("avtoupdate" + " is empty");
                   return;
                 }
var efmwefyn = GetInputConstructorValue("efmwefyn", loader);
                 if(efmwefyn["original"].length == 0)
                 {
                   Invalid("button_id" + " is empty");
                   return;
                 }
var ovgmanab = GetInputConstructorValue("ovgmanab", loader);
                 if(ovgmanab["original"].length == 0)
                 {
                   Invalid("coef" + " is empty");
                   return;
                 }
var leeujxmf = GetInputConstructorValue("leeujxmf", loader);
                 if(leeujxmf["original"].length == 0)
                 {
                   Invalid("image id" + " is empty");
                   return;
                 }
var gtaathyj = GetInputConstructorValue("gtaathyj", loader);
                 if(gtaathyj["original"].length == 0)
                 {
                   Invalid("key" + " is empty");
                   return;
                 }
var hddbzwsp = GetInputConstructorValue("hddbzwsp", loader);
                 if(hddbzwsp["original"].length == 0)
                 {
                   Invalid("pixel_koef" + " is empty");
                   return;
                 }
var rglwymga = GetInputConstructorValue("rglwymga", loader);
                 if(rglwymga["original"].length == 0)
                 {
                   Invalid("reload_id" + " is empty");
                   return;
                 }
var zsqejggb = GetInputConstructorValue("zsqejggb", loader);
                 if(zsqejggb["original"].length == 0)
                 {
                   Invalid("slider_type" + " is empty");
                   return;
                 }
var nodzfohi = GetInputConstructorValue("nodzfohi", loader);
                 if(nodzfohi["original"].length == 0)
                 {
                   Invalid("speed" + " is empty");
                   return;
                 }
var cegrusgy = GetInputConstructorValue("cegrusgy", loader);
                 if(cegrusgy["original"].length == 0)
                 {
                   Invalid("type_slide" + " is empty");
                   return;
                 }
var fmecrigu = GetInputConstructorValue("fmecrigu", loader);
                 if(fmecrigu["original"].length == 0)
                 {
                   Invalid("type_swipe" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SliderSolver_code").html())({"pdcustkn": pdcustkn["updated"],"vzzfuffe": vzzfuffe["updated"],"vidfssfi": vidfssfi["updated"],"efmwefyn": efmwefyn["updated"],"ovgmanab": ovgmanab["updated"],"leeujxmf": leeujxmf["updated"],"gtaathyj": gtaathyj["updated"],"hddbzwsp": hddbzwsp["updated"],"rglwymga": rglwymga["updated"],"zsqejggb": zsqejggb["updated"],"nodzfohi": nodzfohi["updated"],"cegrusgy": cegrusgy["updated"],"fmecrigu": fmecrigu["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
