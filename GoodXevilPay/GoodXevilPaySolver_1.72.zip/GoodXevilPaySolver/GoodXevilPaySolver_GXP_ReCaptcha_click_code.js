_call_function(GoodXevilPaySolver_GXP_ReCaptcha_click,{ "apikey": (<%= lzqylhqf %>),"CaptchaSelector": (<%= vparpdzu %>),"InvisibleCaptcha": (<%= mrijmnpr %>),"TrySolve": (<%= idierrlr %>) })!
