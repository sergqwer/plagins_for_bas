var qctnehyz = GetInputConstructorValue("qctnehyz", loader);
                 if(qctnehyz["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var sltgcfda = GetInputConstructorValue("sltgcfda", loader);
                 if(sltgcfda["original"].length == 0)
                 {
                   Invalid("site_url" + " is empty");
                   return;
                 }
var kkdqjukb = GetInputConstructorValue("kkdqjukb", loader);
                 if(kkdqjukb["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_TurnstileToken_code").html())({"qctnehyz": qctnehyz["updated"],"sltgcfda": sltgcfda["updated"],"kkdqjukb": kkdqjukb["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
