var gsyakklq = GetInputConstructorValue("gsyakklq", loader);
                 if(gsyakklq["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var tsvwxkpv = GetInputConstructorValue("tsvwxkpv", loader);
                 if(tsvwxkpv["original"].length == 0)
                 {
                   Invalid("site_url" + " is empty");
                   return;
                 }
var rehgcjai = GetInputConstructorValue("rehgcjai", loader);
                 if(rehgcjai["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_HcaptchaTakeToken_code").html())({"gsyakklq": gsyakklq["updated"],"tsvwxkpv": tsvwxkpv["updated"],"rehgcjai": rehgcjai["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
