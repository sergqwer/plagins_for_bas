var nuewvggs = GetInputConstructorValue("nuewvggs", loader);
                 if(nuewvggs["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var keeqqtst = GetInputConstructorValue("keeqqtst", loader);
                 if(keeqqtst["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var igtdewmg = GetInputConstructorValue("igtdewmg", loader);
                 if(igtdewmg["original"].length == 0)
                 {
                   Invalid("siteurl" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_BasiliskCaptcha_code").html())({"nuewvggs": nuewvggs["updated"],"keeqqtst": keeqqtst["updated"],"igtdewmg": igtdewmg["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
