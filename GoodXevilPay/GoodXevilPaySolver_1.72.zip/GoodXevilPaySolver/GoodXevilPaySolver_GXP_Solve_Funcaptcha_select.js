var moyghjft = GetInputConstructorValue("moyghjft", loader);
                 if(moyghjft["original"].length == 0)
                 {
                   Invalid("APIKey" + " is empty");
                   return;
                 }
var jfsebfij = GetInputConstructorValue("jfsebfij", loader);
                 if(jfsebfij["original"].length == 0)
                 {
                   Invalid("CaptchaNumber" + " is empty");
                   return;
                 }
var zgzkfyof = GetInputConstructorValue("zgzkfyof", loader);
                 if(zgzkfyof["original"].length == 0)
                 {
                   Invalid("CaptchaSelector" + " is empty");
                   return;
                 }
var ptcviayw = GetInputConstructorValue("ptcviayw", loader);
                 if(ptcviayw["original"].length == 0)
                 {
                   Invalid("MaxLimitTask" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_Solve_Funcaptcha_code").html())({"moyghjft": moyghjft["updated"],"jfsebfij": jfsebfij["updated"],"zgzkfyof": zgzkfyof["updated"],"ptcviayw": ptcviayw["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
