var ajzbwqaz = GetInputConstructorValue("ajzbwqaz", loader);
                 if(ajzbwqaz["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var zuaggcnh = GetInputConstructorValue("zuaggcnh", loader);
                 if(zuaggcnh["original"].length == 0)
                 {
                   Invalid("CaptchaSelector" + " is empty");
                   return;
                 }
var atunhwaw = GetInputConstructorValue("atunhwaw", loader);
                 if(atunhwaw["original"].length == 0)
                 {
                   Invalid("InvisibleCaptcha" + " is empty");
                   return;
                 }
var xknhfkri = GetInputConstructorValue("xknhfkri", loader);
                 if(xknhfkri["original"].length == 0)
                 {
                   Invalid("TrySolve" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_hCaptcha_Click_code").html())({"ajzbwqaz": ajzbwqaz["updated"],"zuaggcnh": zuaggcnh["updated"],"atunhwaw": atunhwaw["updated"],"xknhfkri": xknhfkri["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
