var jqtcenfz = GetInputConstructorValue("jqtcenfz", loader);
                 if(jqtcenfz["original"].length == 0)
                 {
                   Invalid("hCaptcha_USE" + " is empty");
                   return;
                 }
var hlhzaebv = GetInputConstructorValue("hlhzaebv", loader);
                 if(hlhzaebv["original"].length == 0)
                 {
                   Invalid("ReCaptcha_USE" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_ForAutosolveReHCaptcha_code").html())({"jqtcenfz": jqtcenfz["updated"],"hlhzaebv": hlhzaebv["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
