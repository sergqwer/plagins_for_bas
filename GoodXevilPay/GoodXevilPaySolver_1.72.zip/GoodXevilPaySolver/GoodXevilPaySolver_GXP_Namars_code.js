_call_function(GoodXevilPaySolver_GXP_Namars,{ "apikey": (<%= jtwxavbj %>) })!
<%= variable %> = _result_function()
