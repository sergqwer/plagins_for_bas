var lzqylhqf = GetInputConstructorValue("lzqylhqf", loader);
                 if(lzqylhqf["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var vparpdzu = GetInputConstructorValue("vparpdzu", loader);
                 if(vparpdzu["original"].length == 0)
                 {
                   Invalid("CaptchaSelector" + " is empty");
                   return;
                 }
var mrijmnpr = GetInputConstructorValue("mrijmnpr", loader);
                 if(mrijmnpr["original"].length == 0)
                 {
                   Invalid("InvisibleCaptcha" + " is empty");
                   return;
                 }
var idierrlr = GetInputConstructorValue("idierrlr", loader);
                 if(idierrlr["original"].length == 0)
                 {
                   Invalid("TrySolve" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_ReCaptcha_click_code").html())({"lzqylhqf": lzqylhqf["updated"],"vparpdzu": vparpdzu["updated"],"mrijmnpr": mrijmnpr["updated"],"idierrlr": idierrlr["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
