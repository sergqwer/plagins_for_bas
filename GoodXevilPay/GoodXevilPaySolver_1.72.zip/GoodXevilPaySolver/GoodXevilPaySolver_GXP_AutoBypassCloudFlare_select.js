var aaswnydn = GetInputConstructorValue("aaswnydn", loader);
                 if(aaswnydn["original"].length == 0)
                 {
                   Invalid("custom_button" + " is empty");
                   return;
                 }
var noyyoasc = GetInputConstructorValue("noyyoasc", loader);
                 if(noyyoasc["original"].length == 0)
                 {
                   Invalid("max_time" + " is empty");
                   return;
                 }
var etapxrxg = GetInputConstructorValue("etapxrxg", loader);
                 if(etapxrxg["original"].length == 0)
                 {
                   Invalid("whait_element" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_AutoBypassCloudFlare_code").html())({"aaswnydn": aaswnydn["updated"],"noyyoasc": noyyoasc["updated"],"etapxrxg": etapxrxg["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
