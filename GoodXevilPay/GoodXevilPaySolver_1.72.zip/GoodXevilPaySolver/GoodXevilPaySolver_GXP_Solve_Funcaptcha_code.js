_call_function(GoodXevilPaySolver_GXP_Solve_Funcaptcha,{ "APIKey": (<%= moyghjft %>),"CaptchaNumber": (<%= jfsebfij %>),"CaptchaSelector": (<%= zgzkfyof %>),"MaxLimitTask": (<%= ptcviayw %>) })!
