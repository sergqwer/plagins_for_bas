var atddtqyp = GetInputConstructorValue("atddtqyp", loader);
                 if(atddtqyp["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var brjkgdwk = GetInputConstructorValue("brjkgdwk", loader);
                 if(brjkgdwk["original"].length == 0)
                 {
                   Invalid("button_capthca" + " is empty");
                   return;
                 }
var vvajyqli = GetInputConstructorValue("vvajyqli", loader);
                 if(vvajyqli["original"].length == 0)
                 {
                   Invalid("captcha_submit" + " is empty");
                   return;
                 }
var iwacqsgg = GetInputConstructorValue("iwacqsgg", loader);
                 if(iwacqsgg["original"].length == 0)
                 {
                   Invalid("foto_captcha" + " is empty");
                   return;
                 }
var hlyafdco = GetInputConstructorValue("hlyafdco", loader);
                 if(hlyafdco["original"].length == 0)
                 {
                   Invalid("reload_captcha" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SolverGeetestIcon_code").html())({"atddtqyp": atddtqyp["updated"],"brjkgdwk": brjkgdwk["updated"],"vvajyqli": vvajyqli["updated"],"iwacqsgg": iwacqsgg["updated"],"hlyafdco": hlyafdco["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
