_call_function(GoodXevilPaySolver_GXP_ReCaptchav2TakeToken,{ "APIKEY": (<%= vcgsfzbt %>),"site_url": (<%= wcftqgss %>),"sitekey": (<%= riciksqh %>) })!
<%= variable %> = _result_function()
