_call_function(GoodXevilPaySolver_GXP_HcaptchaTakeToken,{ "APIKEY": (<%= cyobyrpe %>),"site_url": (<%= sqmcttsh %>),"sitekey": (<%= wtcqlyfl %>) })!
<%= variable %> = _result_function()
