var dopvdahi = GetInputConstructorValue("dopvdahi", loader);
                 if(dopvdahi["original"].length == 0)
                 {
                   Invalid("arrow_id" + " is empty");
                   return;
                 }
var iarttskx = GetInputConstructorValue("iarttskx", loader);
                 if(iarttskx["original"].length == 0)
                 {
                   Invalid("avtoupdate" + " is empty");
                   return;
                 }
var xbcdgoor = GetInputConstructorValue("xbcdgoor", loader);
                 if(xbcdgoor["original"].length == 0)
                 {
                   Invalid("button_id" + " is empty");
                   return;
                 }
var uuhjfaoj = GetInputConstructorValue("uuhjfaoj", loader);
                 if(uuhjfaoj["original"].length == 0)
                 {
                   Invalid("coef" + " is empty");
                   return;
                 }
var xcnxyelw = GetInputConstructorValue("xcnxyelw", loader);
                 if(xcnxyelw["original"].length == 0)
                 {
                   Invalid("image id" + " is empty");
                   return;
                 }
var gaykkcaz = GetInputConstructorValue("gaykkcaz", loader);
                 if(gaykkcaz["original"].length == 0)
                 {
                   Invalid("key" + " is empty");
                   return;
                 }
var mhdcljam = GetInputConstructorValue("mhdcljam", loader);
                 if(mhdcljam["original"].length == 0)
                 {
                   Invalid("pixel_koef" + " is empty");
                   return;
                 }
var cbfpvvah = GetInputConstructorValue("cbfpvvah", loader);
                 if(cbfpvvah["original"].length == 0)
                 {
                   Invalid("reload_id" + " is empty");
                   return;
                 }
var zxudvnzd = GetInputConstructorValue("zxudvnzd", loader);
                 if(zxudvnzd["original"].length == 0)
                 {
                   Invalid("speed" + " is empty");
                   return;
                 }
var hfjdhoyz = GetInputConstructorValue("hfjdhoyz", loader);
                 if(hfjdhoyz["original"].length == 0)
                 {
                   Invalid("type_slide" + " is empty");
                   return;
                 }
var opnturbs = GetInputConstructorValue("opnturbs", loader);
                 if(opnturbs["original"].length == 0)
                 {
                   Invalid("type_swipe" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SliderSolver_code").html())({"dopvdahi": dopvdahi["updated"],"iarttskx": iarttskx["updated"],"xbcdgoor": xbcdgoor["updated"],"uuhjfaoj": uuhjfaoj["updated"],"xcnxyelw": xcnxyelw["updated"],"gaykkcaz": gaykkcaz["updated"],"mhdcljam": mhdcljam["updated"],"cbfpvvah": cbfpvvah["updated"],"zxudvnzd": zxudvnzd["updated"],"hfjdhoyz": hfjdhoyz["updated"],"opnturbs": opnturbs["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
