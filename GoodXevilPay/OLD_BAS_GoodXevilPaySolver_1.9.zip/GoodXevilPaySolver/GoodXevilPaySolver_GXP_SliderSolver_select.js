var ehhjyvue = GetInputConstructorValue("ehhjyvue", loader);
                 if(ehhjyvue["original"].length == 0)
                 {
                   Invalid("arrow_id" + " is empty");
                   return;
                 }
var bfenufgj = GetInputConstructorValue("bfenufgj", loader);
                 if(bfenufgj["original"].length == 0)
                 {
                   Invalid("avtoupdate" + " is empty");
                   return;
                 }
var tpvyjbbo = GetInputConstructorValue("tpvyjbbo", loader);
                 if(tpvyjbbo["original"].length == 0)
                 {
                   Invalid("button_id" + " is empty");
                   return;
                 }
var mllsvndk = GetInputConstructorValue("mllsvndk", loader);
                 if(mllsvndk["original"].length == 0)
                 {
                   Invalid("coef" + " is empty");
                   return;
                 }
var ydkajgxb = GetInputConstructorValue("ydkajgxb", loader);
                 if(ydkajgxb["original"].length == 0)
                 {
                   Invalid("image id" + " is empty");
                   return;
                 }
var fmgrvrnr = GetInputConstructorValue("fmgrvrnr", loader);
                 if(fmgrvrnr["original"].length == 0)
                 {
                   Invalid("key" + " is empty");
                   return;
                 }
var hjxmzxia = GetInputConstructorValue("hjxmzxia", loader);
                 if(hjxmzxia["original"].length == 0)
                 {
                   Invalid("pixel_koef" + " is empty");
                   return;
                 }
var teaoukqt = GetInputConstructorValue("teaoukqt", loader);
                 if(teaoukqt["original"].length == 0)
                 {
                   Invalid("reload_id" + " is empty");
                   return;
                 }
var ajaouupy = GetInputConstructorValue("ajaouupy", loader);
                 if(ajaouupy["original"].length == 0)
                 {
                   Invalid("speed" + " is empty");
                   return;
                 }
var bpwnyqln = GetInputConstructorValue("bpwnyqln", loader);
                 if(bpwnyqln["original"].length == 0)
                 {
                   Invalid("type_slide" + " is empty");
                   return;
                 }
var ealzloor = GetInputConstructorValue("ealzloor", loader);
                 if(ealzloor["original"].length == 0)
                 {
                   Invalid("type_swipe" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SliderSolver_code").html())({"ehhjyvue": ehhjyvue["updated"],"bfenufgj": bfenufgj["updated"],"tpvyjbbo": tpvyjbbo["updated"],"mllsvndk": mllsvndk["updated"],"ydkajgxb": ydkajgxb["updated"],"fmgrvrnr": fmgrvrnr["updated"],"hjxmzxia": hjxmzxia["updated"],"teaoukqt": teaoukqt["updated"],"ajaouupy": ajaouupy["updated"],"bpwnyqln": bpwnyqln["updated"],"ealzloor": ealzloor["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
