var cokizuqi = GetInputConstructorValue("cokizuqi", loader);
                 if(cokizuqi["original"].length == 0)
                 {
                   Invalid("arrow_id" + " is empty");
                   return;
                 }
var pqpwyfxn = GetInputConstructorValue("pqpwyfxn", loader);
                 if(pqpwyfxn["original"].length == 0)
                 {
                   Invalid("avtoupdate" + " is empty");
                   return;
                 }
var arpxtkfr = GetInputConstructorValue("arpxtkfr", loader);
                 if(arpxtkfr["original"].length == 0)
                 {
                   Invalid("button_id" + " is empty");
                   return;
                 }
var dpckindb = GetInputConstructorValue("dpckindb", loader);
                 if(dpckindb["original"].length == 0)
                 {
                   Invalid("coef" + " is empty");
                   return;
                 }
var jivzlvvw = GetInputConstructorValue("jivzlvvw", loader);
                 if(jivzlvvw["original"].length == 0)
                 {
                   Invalid("image id" + " is empty");
                   return;
                 }
var bbtoqrkw = GetInputConstructorValue("bbtoqrkw", loader);
                 if(bbtoqrkw["original"].length == 0)
                 {
                   Invalid("key" + " is empty");
                   return;
                 }
var swzsstzd = GetInputConstructorValue("swzsstzd", loader);
                 if(swzsstzd["original"].length == 0)
                 {
                   Invalid("pixel_koef" + " is empty");
                   return;
                 }
var istipbun = GetInputConstructorValue("istipbun", loader);
                 if(istipbun["original"].length == 0)
                 {
                   Invalid("reload_id" + " is empty");
                   return;
                 }
var lytxrpij = GetInputConstructorValue("lytxrpij", loader);
                 if(lytxrpij["original"].length == 0)
                 {
                   Invalid("speed" + " is empty");
                   return;
                 }
var wkgpbeot = GetInputConstructorValue("wkgpbeot", loader);
                 if(wkgpbeot["original"].length == 0)
                 {
                   Invalid("type_slide" + " is empty");
                   return;
                 }
var jkyrnlsm = GetInputConstructorValue("jkyrnlsm", loader);
                 if(jkyrnlsm["original"].length == 0)
                 {
                   Invalid("type_swipe" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SliderSolver_code").html())({"cokizuqi": cokizuqi["updated"],"pqpwyfxn": pqpwyfxn["updated"],"arpxtkfr": arpxtkfr["updated"],"dpckindb": dpckindb["updated"],"jivzlvvw": jivzlvvw["updated"],"bbtoqrkw": bbtoqrkw["updated"],"swzsstzd": swzsstzd["updated"],"istipbun": istipbun["updated"],"lytxrpij": lytxrpij["updated"],"wkgpbeot": wkgpbeot["updated"],"jkyrnlsm": jkyrnlsm["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
