_call_function(GoodXevilPaySolver_GXP_ReCaptchav2TakeToken,{ "APIKEY": (<%= zrphnpeq %>),"site_url": (<%= lyxjagbz %>),"sitekey": (<%= eaondpvh %>) })!
<%= variable %> = _result_function()
