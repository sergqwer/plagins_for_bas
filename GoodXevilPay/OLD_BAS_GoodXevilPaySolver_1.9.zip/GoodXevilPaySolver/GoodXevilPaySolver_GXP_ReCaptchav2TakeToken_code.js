_call_function(GoodXevilPaySolver_GXP_ReCaptchav2TakeToken,{ "APIKEY": (<%= rxkinmkw %>),"site_url": (<%= hywxptzl %>),"sitekey": (<%= mijaccbz %>) })!
<%= variable %> = _result_function()
