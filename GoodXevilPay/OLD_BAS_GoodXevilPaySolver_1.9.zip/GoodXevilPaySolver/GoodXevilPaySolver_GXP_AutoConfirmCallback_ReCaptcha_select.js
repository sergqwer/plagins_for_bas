var grfobcpw = GetInputConstructorValue("grfobcpw", loader);
                 if(grfobcpw["original"].length == 0)
                 {
                   Invalid("token" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_AutoConfirmCallback_ReCaptcha_code").html())({"grfobcpw": grfobcpw["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
