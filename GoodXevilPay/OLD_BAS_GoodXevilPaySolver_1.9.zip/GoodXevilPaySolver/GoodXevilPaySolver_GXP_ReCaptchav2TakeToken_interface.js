<div class="container-fluid">
<%= _.template($('#input_constructor').html())({id:"zrphnpeq", description:"APIKEY", default_selector: "string", disable_int:true, value_string: "", help: {description: "apikey с сервиса https://t.me/Xevil_check_bot"} }) %>
<%= _.template($('#input_constructor').html())({id:"lyxjagbz", description:"site_url", default_selector: "string", disable_int:true, value_string: "", help: {description: "Полный URL страницы где находится ReCaptcha v2"} }) %>
<%= _.template($('#input_constructor').html())({id:"eaondpvh", description:"sitekey", default_selector: "string", disable_int:true, value_string: "", help: {description: "Значение параметра data-sitekey ReCaptcha v2"} }) %>
<%= _.template($('#variable_constructor').html())({id:"Save", description:"Результат", default_variable: "RECAPTCHA_TOKEN", help: {description: "Токен ReCaptcha v2"}}) %>
</div>
<div class="tooltipinternal">
<div class="tr tooltip-paragraph-first-fold">Эта функция получает токен ReCaptcha v2 через сервис решения капчи https://t.me/Xevil_check_bot</div>
</div>
<%= _.template($('#back').html())({action:"executeandadd", visible:true}) %>
