var rxkinmkw = GetInputConstructorValue("rxkinmkw", loader);
                 if(rxkinmkw["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var hywxptzl = GetInputConstructorValue("hywxptzl", loader);
                 if(hywxptzl["original"].length == 0)
                 {
                   Invalid("site_url" + " is empty");
                   return;
                 }
var mijaccbz = GetInputConstructorValue("mijaccbz", loader);
                 if(mijaccbz["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_ReCaptchav2TakeToken_code").html())({"rxkinmkw": rxkinmkw["updated"],"hywxptzl": hywxptzl["updated"],"mijaccbz": mijaccbz["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
