_call_function(GoodXevilPaySolver_GXP_IMAGE_BASE64,{ "APIKEY": (<%= dnffktcd %>),"IMAGE_BASE64": (<%= iveanuwt %>) })!
<%= variable %> = _result_function()
