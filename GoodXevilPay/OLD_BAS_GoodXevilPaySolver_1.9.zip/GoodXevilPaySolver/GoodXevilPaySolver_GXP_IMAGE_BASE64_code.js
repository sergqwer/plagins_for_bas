_call_function(GoodXevilPaySolver_GXP_IMAGE_BASE64,{ "APIKEY": (<%= bnchckcs %>),"IMAGE_BASE64": (<%= xucozlmv %>) })!
<%= variable %> = _result_function()
