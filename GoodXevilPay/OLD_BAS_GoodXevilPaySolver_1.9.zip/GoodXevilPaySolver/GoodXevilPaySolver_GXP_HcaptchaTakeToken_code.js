_call_function(GoodXevilPaySolver_GXP_HcaptchaTakeToken,{ "APIKEY": (<%= xgtleatc %>),"site_url": (<%= tpppdccv %>),"sitekey": (<%= syyslntv %>) })!
<%= variable %> = _result_function()
