_call_function(GoodXevilPaySolver_GXP_HcaptchaTakeToken,{ "APIKEY": (<%= xajvqvlz %>),"site_url": (<%= mplpuldp %>),"sitekey": (<%= ptbcswmd %>) })!
<%= variable %> = _result_function()
