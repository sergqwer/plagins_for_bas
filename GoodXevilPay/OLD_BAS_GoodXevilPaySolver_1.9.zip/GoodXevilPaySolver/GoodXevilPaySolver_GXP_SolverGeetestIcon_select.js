var rrelvrjc = GetInputConstructorValue("rrelvrjc", loader);
                 if(rrelvrjc["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var uylvqife = GetInputConstructorValue("uylvqife", loader);
                 if(uylvqife["original"].length == 0)
                 {
                   Invalid("button_capthca" + " is empty");
                   return;
                 }
var myzdzoho = GetInputConstructorValue("myzdzoho", loader);
                 if(myzdzoho["original"].length == 0)
                 {
                   Invalid("captcha_submit" + " is empty");
                   return;
                 }
var urerjdwy = GetInputConstructorValue("urerjdwy", loader);
                 if(urerjdwy["original"].length == 0)
                 {
                   Invalid("foto_captcha" + " is empty");
                   return;
                 }
var fpejszgj = GetInputConstructorValue("fpejszgj", loader);
                 if(fpejszgj["original"].length == 0)
                 {
                   Invalid("reload_captcha" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SolverGeetestIcon_code").html())({"rrelvrjc": rrelvrjc["updated"],"uylvqife": uylvqife["updated"],"myzdzoho": myzdzoho["updated"],"urerjdwy": urerjdwy["updated"],"fpejszgj": fpejszgj["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
