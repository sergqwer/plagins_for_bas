var lmqtzcsu = GetInputConstructorValue("lmqtzcsu", loader);
                 if(lmqtzcsu["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var teryhvcl = GetInputConstructorValue("teryhvcl", loader);
                 if(teryhvcl["original"].length == 0)
                 {
                   Invalid("button_capthca" + " is empty");
                   return;
                 }
var prphfaqp = GetInputConstructorValue("prphfaqp", loader);
                 if(prphfaqp["original"].length == 0)
                 {
                   Invalid("captcha_submit" + " is empty");
                   return;
                 }
var bksfmgnv = GetInputConstructorValue("bksfmgnv", loader);
                 if(bksfmgnv["original"].length == 0)
                 {
                   Invalid("foto_captcha" + " is empty");
                   return;
                 }
var dexytwru = GetInputConstructorValue("dexytwru", loader);
                 if(dexytwru["original"].length == 0)
                 {
                   Invalid("reload_captcha" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SolverGeetestIcon_code").html())({"lmqtzcsu": lmqtzcsu["updated"],"teryhvcl": teryhvcl["updated"],"prphfaqp": prphfaqp["updated"],"bksfmgnv": bksfmgnv["updated"],"dexytwru": dexytwru["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
