var xgtleatc = GetInputConstructorValue("xgtleatc", loader);
                 if(xgtleatc["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var tpppdccv = GetInputConstructorValue("tpppdccv", loader);
                 if(tpppdccv["original"].length == 0)
                 {
                   Invalid("site_url" + " is empty");
                   return;
                 }
var syyslntv = GetInputConstructorValue("syyslntv", loader);
                 if(syyslntv["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_HcaptchaTakeToken_code").html())({"xgtleatc": xgtleatc["updated"],"tpppdccv": tpppdccv["updated"],"syyslntv": syyslntv["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
