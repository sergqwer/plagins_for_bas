var gnlfqxqv = GetInputConstructorValue("gnlfqxqv", loader);
                 if(gnlfqxqv["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var foebover = GetInputConstructorValue("foebover", loader);
                 if(foebover["original"].length == 0)
                 {
                   Invalid("timer" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_BuxMoney_PayupVideo_code").html())({"gnlfqxqv": gnlfqxqv["updated"],"foebover": foebover["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
