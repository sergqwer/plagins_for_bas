_call_function(GoodXevilPaySolver_GXP_HcaptchaTakeToken,{ "APIKEY": (<%= tpyecgxz %>),"site_url": (<%= mdfmgxmv %>),"sitekey": (<%= vwzvbzrv %>) })!
<%= variable %> = _result_function()
