_call_function(GoodXevilPaySolver_GXP_IMAGE_BASE64,{ "APIKEY": (<%= msdpbdyv %>),"IMAGE_BASE64": (<%= jaumzrbf %>) })!
<%= variable %> = _result_function()
