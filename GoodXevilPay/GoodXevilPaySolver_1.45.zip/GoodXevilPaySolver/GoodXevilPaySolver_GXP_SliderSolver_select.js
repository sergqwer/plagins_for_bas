var opsfnbyc = GetInputConstructorValue("opsfnbyc", loader);
                 if(opsfnbyc["original"].length == 0)
                 {
                   Invalid("arrow_id" + " is empty");
                   return;
                 }
var fjmrgjig = GetInputConstructorValue("fjmrgjig", loader);
                 if(fjmrgjig["original"].length == 0)
                 {
                   Invalid("avtoupdate" + " is empty");
                   return;
                 }
var kxpygbww = GetInputConstructorValue("kxpygbww", loader);
                 if(kxpygbww["original"].length == 0)
                 {
                   Invalid("button_id" + " is empty");
                   return;
                 }
var bchnoyyr = GetInputConstructorValue("bchnoyyr", loader);
                 if(bchnoyyr["original"].length == 0)
                 {
                   Invalid("coef" + " is empty");
                   return;
                 }
var pkhedloz = GetInputConstructorValue("pkhedloz", loader);
                 if(pkhedloz["original"].length == 0)
                 {
                   Invalid("image id" + " is empty");
                   return;
                 }
var fbstilvp = GetInputConstructorValue("fbstilvp", loader);
                 if(fbstilvp["original"].length == 0)
                 {
                   Invalid("key" + " is empty");
                   return;
                 }
var wtaqqjxe = GetInputConstructorValue("wtaqqjxe", loader);
                 if(wtaqqjxe["original"].length == 0)
                 {
                   Invalid("pixel_koef" + " is empty");
                   return;
                 }
var sabakklb = GetInputConstructorValue("sabakklb", loader);
                 if(sabakklb["original"].length == 0)
                 {
                   Invalid("reload_id" + " is empty");
                   return;
                 }
var usstcnyc = GetInputConstructorValue("usstcnyc", loader);
                 if(usstcnyc["original"].length == 0)
                 {
                   Invalid("speed" + " is empty");
                   return;
                 }
var hjencgsj = GetInputConstructorValue("hjencgsj", loader);
                 if(hjencgsj["original"].length == 0)
                 {
                   Invalid("type_slide" + " is empty");
                   return;
                 }
var odjoipyp = GetInputConstructorValue("odjoipyp", loader);
                 if(odjoipyp["original"].length == 0)
                 {
                   Invalid("type_swipe" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SliderSolver_code").html())({"opsfnbyc": opsfnbyc["updated"],"fjmrgjig": fjmrgjig["updated"],"kxpygbww": kxpygbww["updated"],"bchnoyyr": bchnoyyr["updated"],"pkhedloz": pkhedloz["updated"],"fbstilvp": fbstilvp["updated"],"wtaqqjxe": wtaqqjxe["updated"],"sabakklb": sabakklb["updated"],"usstcnyc": usstcnyc["updated"],"hjencgsj": hjencgsj["updated"],"odjoipyp": odjoipyp["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
