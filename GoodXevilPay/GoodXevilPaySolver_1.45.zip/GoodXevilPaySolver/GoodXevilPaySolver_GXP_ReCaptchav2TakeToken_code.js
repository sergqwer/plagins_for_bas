_call_function(GoodXevilPaySolver_GXP_ReCaptchav2TakeToken,{ "APIKEY": (<%= gbmwqlig %>),"site_url": (<%= mcceoeoi %>),"sitekey": (<%= zrslieop %>) })!
<%= variable %> = _result_function()
