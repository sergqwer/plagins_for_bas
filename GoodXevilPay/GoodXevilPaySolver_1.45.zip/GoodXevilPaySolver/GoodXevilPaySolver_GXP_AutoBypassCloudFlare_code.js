_call_function(GoodXevilPaySolver_GXP_AutoBypassCloudFlare,{ "custom_button": (<%= polxddpt %>),"max_time": (<%= xxixkira %>),"whait_element": (<%= wfxpycsc %>) })!
