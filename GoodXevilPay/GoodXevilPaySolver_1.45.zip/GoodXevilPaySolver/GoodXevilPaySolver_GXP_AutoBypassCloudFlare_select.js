var polxddpt = GetInputConstructorValue("polxddpt", loader);
                 if(polxddpt["original"].length == 0)
                 {
                   Invalid("custom_button" + " is empty");
                   return;
                 }
var xxixkira = GetInputConstructorValue("xxixkira", loader);
                 if(xxixkira["original"].length == 0)
                 {
                   Invalid("max_time" + " is empty");
                   return;
                 }
var wfxpycsc = GetInputConstructorValue("wfxpycsc", loader);
                 if(wfxpycsc["original"].length == 0)
                 {
                   Invalid("whait_element" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_AutoBypassCloudFlare_code").html())({"polxddpt": polxddpt["updated"],"xxixkira": xxixkira["updated"],"wfxpycsc": wfxpycsc["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
