var kxwkvsbu = GetInputConstructorValue("kxwkvsbu", loader);
                 if(kxwkvsbu["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var gujywesg = GetInputConstructorValue("gujywesg", loader);
                 if(gujywesg["original"].length == 0)
                 {
                   Invalid("button_capthca" + " is empty");
                   return;
                 }
var lkqrdnxz = GetInputConstructorValue("lkqrdnxz", loader);
                 if(lkqrdnxz["original"].length == 0)
                 {
                   Invalid("captcha_submit" + " is empty");
                   return;
                 }
var jmgcjqmc = GetInputConstructorValue("jmgcjqmc", loader);
                 if(jmgcjqmc["original"].length == 0)
                 {
                   Invalid("foto_captcha" + " is empty");
                   return;
                 }
var jgbxbuog = GetInputConstructorValue("jgbxbuog", loader);
                 if(jgbxbuog["original"].length == 0)
                 {
                   Invalid("reload_captcha" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SolverGeetestIcon_code").html())({"kxwkvsbu": kxwkvsbu["updated"],"gujywesg": gujywesg["updated"],"lkqrdnxz": lkqrdnxz["updated"],"jmgcjqmc": jmgcjqmc["updated"],"jgbxbuog": jgbxbuog["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
