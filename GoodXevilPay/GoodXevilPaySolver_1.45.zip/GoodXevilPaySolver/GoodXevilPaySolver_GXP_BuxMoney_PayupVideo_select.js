var lyawlfna = GetInputConstructorValue("lyawlfna", loader);
                 if(lyawlfna["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var vcifmnml = GetInputConstructorValue("vcifmnml", loader);
                 if(vcifmnml["original"].length == 0)
                 {
                   Invalid("timer" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_BuxMoney_PayupVideo_code").html())({"lyawlfna": lyawlfna["updated"],"vcifmnml": vcifmnml["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
