var nztqvpvp = GetInputConstructorValue("nztqvpvp", loader);
                 if(nztqvpvp["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var sbjfvnll = GetInputConstructorValue("sbjfvnll", loader);
                 if(sbjfvnll["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var bhhizgir = GetInputConstructorValue("bhhizgir", loader);
                 if(bhhizgir["original"].length == 0)
                 {
                   Invalid("siteurl" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_BasiliskCaptcha_code").html())({"nztqvpvp": nztqvpvp["updated"],"sbjfvnll": sbjfvnll["updated"],"bhhizgir": bhhizgir["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
