var aozwccym = GetInputConstructorValue("aozwccym", loader);
                 if(aozwccym["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var dhysncsv = GetInputConstructorValue("dhysncsv", loader);
                 if(dhysncsv["original"].length == 0)
                 {
                   Invalid("captcha_submit" + " is empty");
                   return;
                 }
var drxgwvbt = GetInputConstructorValue("drxgwvbt", loader);
                 if(drxgwvbt["original"].length == 0)
                 {
                   Invalid("foto_captcha" + " is empty");
                   return;
                 }
var jwwlwgli = GetInputConstructorValue("jwwlwgli", loader);
                 if(jwwlwgli["original"].length == 0)
                 {
                   Invalid("pixel_coef" + " is empty");
                   return;
                 }
var zsnvewyb = GetInputConstructorValue("zsnvewyb", loader);
                 if(zsnvewyb["original"].length == 0)
                 {
                   Invalid("reload_captcha" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SolverGeetestIcon_code").html())({"aozwccym": aozwccym["updated"],"dhysncsv": dhysncsv["updated"],"drxgwvbt": drxgwvbt["updated"],"jwwlwgli": jwwlwgli["updated"],"zsnvewyb": zsnvewyb["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
