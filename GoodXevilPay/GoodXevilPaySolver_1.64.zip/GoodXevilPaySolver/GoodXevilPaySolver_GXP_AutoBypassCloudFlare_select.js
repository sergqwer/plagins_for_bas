var otuemris = GetInputConstructorValue("otuemris", loader);
                 if(otuemris["original"].length == 0)
                 {
                   Invalid("custom_button" + " is empty");
                   return;
                 }
var qsgnjafe = GetInputConstructorValue("qsgnjafe", loader);
                 if(qsgnjafe["original"].length == 0)
                 {
                   Invalid("max_time" + " is empty");
                   return;
                 }
var nwmphmlg = GetInputConstructorValue("nwmphmlg", loader);
                 if(nwmphmlg["original"].length == 0)
                 {
                   Invalid("whait_element" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_AutoBypassCloudFlare_code").html())({"otuemris": otuemris["updated"],"qsgnjafe": qsgnjafe["updated"],"nwmphmlg": nwmphmlg["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
