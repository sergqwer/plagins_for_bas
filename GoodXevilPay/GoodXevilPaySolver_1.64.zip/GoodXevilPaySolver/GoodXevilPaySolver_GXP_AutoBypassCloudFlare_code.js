_call_function(GoodXevilPaySolver_GXP_AutoBypassCloudFlare,{ "custom_button": (<%= otuemris %>),"max_time": (<%= qsgnjafe %>),"whait_element": (<%= nwmphmlg %>) })!
