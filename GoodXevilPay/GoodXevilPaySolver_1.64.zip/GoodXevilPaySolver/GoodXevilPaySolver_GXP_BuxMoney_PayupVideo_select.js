var btznnobx = GetInputConstructorValue("btznnobx", loader);
                 if(btznnobx["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var bwpocbgp = GetInputConstructorValue("bwpocbgp", loader);
                 if(bwpocbgp["original"].length == 0)
                 {
                   Invalid("timer" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_BuxMoney_PayupVideo_code").html())({"btznnobx": btznnobx["updated"],"bwpocbgp": bwpocbgp["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
