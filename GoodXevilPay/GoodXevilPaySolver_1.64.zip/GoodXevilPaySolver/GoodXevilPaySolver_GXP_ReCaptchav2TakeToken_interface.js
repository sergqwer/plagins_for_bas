<div class="container-fluid">
<%= _.template($('#input_constructor').html())({id:"ofuswxzp", description:"APIKEY", default_selector: "string", disable_int:true, value_string: "", help: {description: "apikey с сервиса https://t.me/Xevil_check_bot\n\napikey from https://t.me/Xevil_check_bot"} }) %>
<%= _.template($('#input_constructor').html())({id:"sfiarzme", description:"site_url", default_selector: "string", disable_int:true, value_string: "", help: {description: "Полный URL страницы где находится ReCaptcha v2\n\nFull URL of the page where ReCaptcha v2 is located"} }) %>
<%= _.template($('#input_constructor').html())({id:"cmaaobzn", description:"sitekey", default_selector: "string", disable_int:true, value_string: "", help: {description: "Значение параметра data-sitekey ReCaptcha v2\n\nReCaptcha v2 data-sitekey parameter value"} }) %>
<%= _.template($('#variable_constructor').html())({id:"Save", description:"Result", default_variable: "RECAPTCHA_TOKEN", help: {description: "Токен ReCaptcha v2\nReCaptcha v2 token"}}) %>
</div>
<div class="tooltipinternal">
<div class="tr tooltip-paragraph-first-fold">Эта функция получает токен ReCaptcha v2 через сервис решения капчи https://t.me/Xevil_check_bot</div>
<div class="tr tooltip-paragraph-last-fold">This feature receives a ReCaptcha v2 token via the captcha solution service https://t.me/Xevil_check_bot</div>
</div>
<%= _.template($('#back').html())({action:"executeandadd", visible:true}) %>
