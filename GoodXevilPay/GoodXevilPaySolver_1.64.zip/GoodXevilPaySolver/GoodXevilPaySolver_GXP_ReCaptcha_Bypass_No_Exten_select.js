var atlksaor = GetInputConstructorValue("atlksaor", loader);
                 if(atlksaor["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var iasjyusn = GetInputConstructorValue("iasjyusn", loader);
                 if(iasjyusn["original"].length == 0)
                 {
                   Invalid("index" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_ReCaptcha_Bypass_No_Exten_code").html())({"atlksaor": atlksaor["updated"],"iasjyusn": iasjyusn["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
