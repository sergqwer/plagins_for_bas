_call_function(GoodXevilPaySolver_GXP_ReCaptchav2TakeToken,{ "APIKEY": (<%= ofuswxzp %>),"site_url": (<%= sfiarzme %>),"sitekey": (<%= cmaaobzn %>) })!
<%= variable %> = _result_function()
