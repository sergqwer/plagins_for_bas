var ymwrrynw = GetInputConstructorValue("ymwrrynw", loader);
                 if(ymwrrynw["original"].length == 0)
                 {
                   Invalid("arrow_id" + " is empty");
                   return;
                 }
var zvtllxap = GetInputConstructorValue("zvtllxap", loader);
                 if(zvtllxap["original"].length == 0)
                 {
                   Invalid("avtoupdate" + " is empty");
                   return;
                 }
var caxxvpob = GetInputConstructorValue("caxxvpob", loader);
                 if(caxxvpob["original"].length == 0)
                 {
                   Invalid("button_id" + " is empty");
                   return;
                 }
var aoltupkq = GetInputConstructorValue("aoltupkq", loader);
                 if(aoltupkq["original"].length == 0)
                 {
                   Invalid("coef" + " is empty");
                   return;
                 }
var rmqyqvbs = GetInputConstructorValue("rmqyqvbs", loader);
                 if(rmqyqvbs["original"].length == 0)
                 {
                   Invalid("image id" + " is empty");
                   return;
                 }
var dnplmipe = GetInputConstructorValue("dnplmipe", loader);
                 if(dnplmipe["original"].length == 0)
                 {
                   Invalid("key" + " is empty");
                   return;
                 }
var pvwwidms = GetInputConstructorValue("pvwwidms", loader);
                 if(pvwwidms["original"].length == 0)
                 {
                   Invalid("pixel_koef" + " is empty");
                   return;
                 }
var wdpympxo = GetInputConstructorValue("wdpympxo", loader);
                 if(wdpympxo["original"].length == 0)
                 {
                   Invalid("reload_id" + " is empty");
                   return;
                 }
var ggroopym = GetInputConstructorValue("ggroopym", loader);
                 if(ggroopym["original"].length == 0)
                 {
                   Invalid("slider_type" + " is empty");
                   return;
                 }
var rkiitxmp = GetInputConstructorValue("rkiitxmp", loader);
                 if(rkiitxmp["original"].length == 0)
                 {
                   Invalid("speed" + " is empty");
                   return;
                 }
var nqkfqrky = GetInputConstructorValue("nqkfqrky", loader);
                 if(nqkfqrky["original"].length == 0)
                 {
                   Invalid("type_slide" + " is empty");
                   return;
                 }
var tiwdrqrp = GetInputConstructorValue("tiwdrqrp", loader);
                 if(tiwdrqrp["original"].length == 0)
                 {
                   Invalid("type_swipe" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SliderSolver_code").html())({"ymwrrynw": ymwrrynw["updated"],"zvtllxap": zvtllxap["updated"],"caxxvpob": caxxvpob["updated"],"aoltupkq": aoltupkq["updated"],"rmqyqvbs": rmqyqvbs["updated"],"dnplmipe": dnplmipe["updated"],"pvwwidms": pvwwidms["updated"],"wdpympxo": wdpympxo["updated"],"ggroopym": ggroopym["updated"],"rkiitxmp": rkiitxmp["updated"],"nqkfqrky": nqkfqrky["updated"],"tiwdrqrp": tiwdrqrp["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
