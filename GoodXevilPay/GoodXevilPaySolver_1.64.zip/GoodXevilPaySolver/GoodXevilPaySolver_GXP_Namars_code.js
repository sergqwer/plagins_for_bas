_call_function(GoodXevilPaySolver_GXP_Namars,{ "apikey": (<%= kjubwabw %>) })!
<%= variable %> = _result_function()
