var ziwfqscp = GetInputConstructorValue("ziwfqscp", loader);
                 if(ziwfqscp["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var fufnkwsy = GetInputConstructorValue("fufnkwsy", loader);
                 if(fufnkwsy["original"].length == 0)
                 {
                   Invalid("Service_Solver" + " is empty");
                   return;
                 }
var euysqnqe = GetInputConstructorValue("euysqnqe", loader);
                 if(euysqnqe["original"].length == 0)
                 {
                   Invalid("site_url" + " is empty");
                   return;
                 }
var avscbhca = GetInputConstructorValue("avscbhca", loader);
                 if(avscbhca["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_TurnstileToken_code").html())({"ziwfqscp": ziwfqscp["updated"],"fufnkwsy": fufnkwsy["updated"],"euysqnqe": euysqnqe["updated"],"avscbhca": avscbhca["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
