_call_function(GoodXevilPaySolver_GXP_HcaptchaAutoSolver,{ "apikey": (<%= qafcmiok %>),"Service_Solver": (<%= juaglbnj %>) })!
<%= variable %> = _result_function()
