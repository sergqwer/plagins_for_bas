var remkuumt = GetInputConstructorValue("remkuumt", loader);
                 if(remkuumt["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var dbfvupsi = GetInputConstructorValue("dbfvupsi", loader);
                 if(dbfvupsi["original"].length == 0)
                 {
                   Invalid("site_url" + " is empty");
                   return;
                 }
var urkpsgsy = GetInputConstructorValue("urkpsgsy", loader);
                 if(urkpsgsy["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_ReCaptchav2TakeToken_code").html())({"remkuumt": remkuumt["updated"],"dbfvupsi": dbfvupsi["updated"],"urkpsgsy": urkpsgsy["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
