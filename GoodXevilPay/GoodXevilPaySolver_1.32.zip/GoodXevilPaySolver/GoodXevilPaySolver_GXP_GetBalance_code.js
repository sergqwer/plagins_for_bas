_call_function(GoodXevilPaySolver_GXP_GetBalance,{ "APIKEY": (<%= lffmpoqd %>) })!
<%= variable %> = _result_function()
