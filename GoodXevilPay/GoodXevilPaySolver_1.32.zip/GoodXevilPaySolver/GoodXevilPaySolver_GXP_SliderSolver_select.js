var peimmimz = GetInputConstructorValue("peimmimz", loader);
                 if(peimmimz["original"].length == 0)
                 {
                   Invalid("arrow_id" + " is empty");
                   return;
                 }
var zsfgrtww = GetInputConstructorValue("zsfgrtww", loader);
                 if(zsfgrtww["original"].length == 0)
                 {
                   Invalid("avtoupdate" + " is empty");
                   return;
                 }
var nrwlidxb = GetInputConstructorValue("nrwlidxb", loader);
                 if(nrwlidxb["original"].length == 0)
                 {
                   Invalid("button_id" + " is empty");
                   return;
                 }
var gwezfmgc = GetInputConstructorValue("gwezfmgc", loader);
                 if(gwezfmgc["original"].length == 0)
                 {
                   Invalid("coef" + " is empty");
                   return;
                 }
var ormzcekq = GetInputConstructorValue("ormzcekq", loader);
                 if(ormzcekq["original"].length == 0)
                 {
                   Invalid("image id" + " is empty");
                   return;
                 }
var tlnhzspd = GetInputConstructorValue("tlnhzspd", loader);
                 if(tlnhzspd["original"].length == 0)
                 {
                   Invalid("key" + " is empty");
                   return;
                 }
var jujuszsj = GetInputConstructorValue("jujuszsj", loader);
                 if(jujuszsj["original"].length == 0)
                 {
                   Invalid("pixel_koef" + " is empty");
                   return;
                 }
var gdgskpbf = GetInputConstructorValue("gdgskpbf", loader);
                 if(gdgskpbf["original"].length == 0)
                 {
                   Invalid("reload_id" + " is empty");
                   return;
                 }
var hssfszna = GetInputConstructorValue("hssfszna", loader);
                 if(hssfszna["original"].length == 0)
                 {
                   Invalid("speed" + " is empty");
                   return;
                 }
var zyhodoos = GetInputConstructorValue("zyhodoos", loader);
                 if(zyhodoos["original"].length == 0)
                 {
                   Invalid("type_slide" + " is empty");
                   return;
                 }
var caglfsiv = GetInputConstructorValue("caglfsiv", loader);
                 if(caglfsiv["original"].length == 0)
                 {
                   Invalid("type_swipe" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SliderSolver_code").html())({"peimmimz": peimmimz["updated"],"zsfgrtww": zsfgrtww["updated"],"nrwlidxb": nrwlidxb["updated"],"gwezfmgc": gwezfmgc["updated"],"ormzcekq": ormzcekq["updated"],"tlnhzspd": tlnhzspd["updated"],"jujuszsj": jujuszsj["updated"],"gdgskpbf": gdgskpbf["updated"],"hssfszna": hssfszna["updated"],"zyhodoos": zyhodoos["updated"],"caglfsiv": caglfsiv["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
