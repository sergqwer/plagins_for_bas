var vsczufwq = GetInputConstructorValue("vsczufwq", loader);
                 if(vsczufwq["original"].length == 0)
                 {
                   Invalid("arrow_id" + " is empty");
                   return;
                 }
var dsqaogqy = GetInputConstructorValue("dsqaogqy", loader);
                 if(dsqaogqy["original"].length == 0)
                 {
                   Invalid("avtoupdate" + " is empty");
                   return;
                 }
var yfzpvspd = GetInputConstructorValue("yfzpvspd", loader);
                 if(yfzpvspd["original"].length == 0)
                 {
                   Invalid("button_id" + " is empty");
                   return;
                 }
var bntrsrtl = GetInputConstructorValue("bntrsrtl", loader);
                 if(bntrsrtl["original"].length == 0)
                 {
                   Invalid("coef" + " is empty");
                   return;
                 }
var mpotwhxq = GetInputConstructorValue("mpotwhxq", loader);
                 if(mpotwhxq["original"].length == 0)
                 {
                   Invalid("image id" + " is empty");
                   return;
                 }
var jjpixkyb = GetInputConstructorValue("jjpixkyb", loader);
                 if(jjpixkyb["original"].length == 0)
                 {
                   Invalid("key" + " is empty");
                   return;
                 }
var tsoxxlxp = GetInputConstructorValue("tsoxxlxp", loader);
                 if(tsoxxlxp["original"].length == 0)
                 {
                   Invalid("pixel_koef" + " is empty");
                   return;
                 }
var rmdygrbq = GetInputConstructorValue("rmdygrbq", loader);
                 if(rmdygrbq["original"].length == 0)
                 {
                   Invalid("reload_id" + " is empty");
                   return;
                 }
var uyxjklfr = GetInputConstructorValue("uyxjklfr", loader);
                 if(uyxjklfr["original"].length == 0)
                 {
                   Invalid("speed" + " is empty");
                   return;
                 }
var zwgodqcn = GetInputConstructorValue("zwgodqcn", loader);
                 if(zwgodqcn["original"].length == 0)
                 {
                   Invalid("type_slide" + " is empty");
                   return;
                 }
var jakgsszc = GetInputConstructorValue("jakgsszc", loader);
                 if(jakgsszc["original"].length == 0)
                 {
                   Invalid("type_swipe" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SliderSolver_code").html())({"vsczufwq": vsczufwq["updated"],"dsqaogqy": dsqaogqy["updated"],"yfzpvspd": yfzpvspd["updated"],"bntrsrtl": bntrsrtl["updated"],"mpotwhxq": mpotwhxq["updated"],"jjpixkyb": jjpixkyb["updated"],"tsoxxlxp": tsoxxlxp["updated"],"rmdygrbq": rmdygrbq["updated"],"uyxjklfr": uyxjklfr["updated"],"zwgodqcn": zwgodqcn["updated"],"jakgsszc": jakgsszc["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
