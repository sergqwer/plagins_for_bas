_call_function(GoodXevilPaySolver_GXP_ReCaptchav2TakeToken,{ "APIKEY": (<%= ynavxfqx %>),"site_url": (<%= sqdgkdmj %>),"sitekey": (<%= wwojwvxn %>) })!
<%= variable %> = _result_function()
