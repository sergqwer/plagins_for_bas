_call_function(GoodXevilPaySolver_GXP_ReCaptchav2TakeToken,{ "APIKEY": (<%= remkuumt %>),"site_url": (<%= dbfvupsi %>),"sitekey": (<%= urkpsgsy %>) })!
<%= variable %> = _result_function()
