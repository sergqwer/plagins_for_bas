_call_function(GoodXevilPaySolver_GXP_IMAGE_BASE64,{ "APIKEY": (<%= svbdtwtj %>),"IMAGE_BASE64": (<%= vhhxuzpw %>) })!
<%= variable %> = _result_function()
