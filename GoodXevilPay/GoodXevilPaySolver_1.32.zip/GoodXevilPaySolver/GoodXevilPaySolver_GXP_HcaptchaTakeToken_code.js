_call_function(GoodXevilPaySolver_GXP_HcaptchaTakeToken,{ "APIKEY": (<%= cevyomnl %>),"site_url": (<%= rhkesrbj %>),"sitekey": (<%= yiyrlluy %>) })!
<%= variable %> = _result_function()
