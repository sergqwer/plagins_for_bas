var cwaupzpz = GetInputConstructorValue("cwaupzpz", loader);
                 if(cwaupzpz["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var wkcsfqsy = GetInputConstructorValue("wkcsfqsy", loader);
                 if(wkcsfqsy["original"].length == 0)
                 {
                   Invalid("button_capthca" + " is empty");
                   return;
                 }
var pgywolmt = GetInputConstructorValue("pgywolmt", loader);
                 if(pgywolmt["original"].length == 0)
                 {
                   Invalid("captcha_submit" + " is empty");
                   return;
                 }
var nfbhmavz = GetInputConstructorValue("nfbhmavz", loader);
                 if(nfbhmavz["original"].length == 0)
                 {
                   Invalid("foto_captcha" + " is empty");
                   return;
                 }
var jbocfnhk = GetInputConstructorValue("jbocfnhk", loader);
                 if(jbocfnhk["original"].length == 0)
                 {
                   Invalid("reload_captcha" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SolverGeetestIcon_code").html())({"cwaupzpz": cwaupzpz["updated"],"wkcsfqsy": wkcsfqsy["updated"],"pgywolmt": pgywolmt["updated"],"nfbhmavz": nfbhmavz["updated"],"jbocfnhk": jbocfnhk["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
