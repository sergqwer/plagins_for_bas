var zqexwado = GetInputConstructorValue("zqexwado", loader);
                 if(zqexwado["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var fkkwoagi = GetInputConstructorValue("fkkwoagi", loader);
                 if(fkkwoagi["original"].length == 0)
                 {
                   Invalid("button_capthca" + " is empty");
                   return;
                 }
var hxuzeozd = GetInputConstructorValue("hxuzeozd", loader);
                 if(hxuzeozd["original"].length == 0)
                 {
                   Invalid("captcha_submit" + " is empty");
                   return;
                 }
var lddvqvgg = GetInputConstructorValue("lddvqvgg", loader);
                 if(lddvqvgg["original"].length == 0)
                 {
                   Invalid("foto_captcha" + " is empty");
                   return;
                 }
var xtfvyyql = GetInputConstructorValue("xtfvyyql", loader);
                 if(xtfvyyql["original"].length == 0)
                 {
                   Invalid("reload_captcha" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SolverGeetestIcon_code").html())({"zqexwado": zqexwado["updated"],"fkkwoagi": fkkwoagi["updated"],"hxuzeozd": hxuzeozd["updated"],"lddvqvgg": lddvqvgg["updated"],"xtfvyyql": xtfvyyql["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
