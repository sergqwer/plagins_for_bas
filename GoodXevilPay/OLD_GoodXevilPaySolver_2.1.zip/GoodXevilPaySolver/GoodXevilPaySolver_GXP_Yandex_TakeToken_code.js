_call_function(GoodXevilPaySolver_GXP_Yandex_TakeToken,{ "apikey": (<%= kjunlokl %>),"pageurl": (<%= mlgqqpjm %>),"sitekey": (<%= ulynmyzo %>) })!
<%= variable %> = _result_function()
