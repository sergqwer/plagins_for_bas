var qzjkcmhb = GetInputConstructorValue("qzjkcmhb", loader);
                 if(qzjkcmhb["original"].length == 0)
                 {
                   Invalid("arrow_id" + " is empty");
                   return;
                 }
var wqkfjbuy = GetInputConstructorValue("wqkfjbuy", loader);
                 if(wqkfjbuy["original"].length == 0)
                 {
                   Invalid("Attempts" + " is empty");
                   return;
                 }
var bwhmlevt = GetInputConstructorValue("bwhmlevt", loader);
                 if(bwhmlevt["original"].length == 0)
                 {
                   Invalid("avtoupdate" + " is empty");
                   return;
                 }
var iitwzniu = GetInputConstructorValue("iitwzniu", loader);
                 if(iitwzniu["original"].length == 0)
                 {
                   Invalid("button_id" + " is empty");
                   return;
                 }
var sqjzdtav = GetInputConstructorValue("sqjzdtav", loader);
                 if(sqjzdtav["original"].length == 0)
                 {
                   Invalid("coef" + " is empty");
                   return;
                 }
var salxkuta = GetInputConstructorValue("salxkuta", loader);
                 if(salxkuta["original"].length == 0)
                 {
                   Invalid("image id" + " is empty");
                   return;
                 }
var vjdfhash = GetInputConstructorValue("vjdfhash", loader);
                 if(vjdfhash["original"].length == 0)
                 {
                   Invalid("key" + " is empty");
                   return;
                 }
var cgmmxwgn = GetInputConstructorValue("cgmmxwgn", loader);
                 if(cgmmxwgn["original"].length == 0)
                 {
                   Invalid("pixel_koef" + " is empty");
                   return;
                 }
var cdprlutz = GetInputConstructorValue("cdprlutz", loader);
                 if(cdprlutz["original"].length == 0)
                 {
                   Invalid("reload_id" + " is empty");
                   return;
                 }
var gwzocqhq = GetInputConstructorValue("gwzocqhq", loader);
                 if(gwzocqhq["original"].length == 0)
                 {
                   Invalid("slider_type" + " is empty");
                   return;
                 }
var usilaalw = GetInputConstructorValue("usilaalw", loader);
                 if(usilaalw["original"].length == 0)
                 {
                   Invalid("speed" + " is empty");
                   return;
                 }
var lsfbkobq = GetInputConstructorValue("lsfbkobq", loader);
                 if(lsfbkobq["original"].length == 0)
                 {
                   Invalid("type_slide" + " is empty");
                   return;
                 }
var xxoeyuqa = GetInputConstructorValue("xxoeyuqa", loader);
                 if(xxoeyuqa["original"].length == 0)
                 {
                   Invalid("type_swipe" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SliderSolver_code").html())({"qzjkcmhb": qzjkcmhb["updated"],"wqkfjbuy": wqkfjbuy["updated"],"bwhmlevt": bwhmlevt["updated"],"iitwzniu": iitwzniu["updated"],"sqjzdtav": sqjzdtav["updated"],"salxkuta": salxkuta["updated"],"vjdfhash": vjdfhash["updated"],"cgmmxwgn": cgmmxwgn["updated"],"cdprlutz": cdprlutz["updated"],"gwzocqhq": gwzocqhq["updated"],"usilaalw": usilaalw["updated"],"lsfbkobq": lsfbkobq["updated"],"xxoeyuqa": xxoeyuqa["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
