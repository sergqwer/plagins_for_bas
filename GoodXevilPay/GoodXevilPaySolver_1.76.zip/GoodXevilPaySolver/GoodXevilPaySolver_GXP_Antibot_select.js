var fvyzrxze = GetInputConstructorValue("fvyzrxze", loader);
                 if(fvyzrxze["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var tikvokqy = GetInputConstructorValue("tikvokqy", loader);
                 if(tikvokqy["original"].length == 0)
                 {
                   Invalid("mouse" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_Antibot_code").html())({"fvyzrxze": fvyzrxze["updated"],"tikvokqy": tikvokqy["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
