_call_function(GoodXevilPaySolver_GXP_ForAutosolveReHCaptcha,{ "hCaptcha_USE": (<%= ohtrfwcs %>),"ReCaptcha_USE": (<%= ppwgetsk %>) })!
