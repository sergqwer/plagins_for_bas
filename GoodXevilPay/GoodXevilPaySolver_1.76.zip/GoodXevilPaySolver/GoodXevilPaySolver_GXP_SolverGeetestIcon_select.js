var uktuuwxm = GetInputConstructorValue("uktuuwxm", loader);
                 if(uktuuwxm["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var iankzrie = GetInputConstructorValue("iankzrie", loader);
                 if(iankzrie["original"].length == 0)
                 {
                   Invalid("arab_fix" + " is empty");
                   return;
                 }
var zpqdnihz = GetInputConstructorValue("zpqdnihz", loader);
                 if(zpqdnihz["original"].length == 0)
                 {
                   Invalid("captcha_submit" + " is empty");
                   return;
                 }
var ipakienm = GetInputConstructorValue("ipakienm", loader);
                 if(ipakienm["original"].length == 0)
                 {
                   Invalid("foto_captcha" + " is empty");
                   return;
                 }
var ffpytqvr = GetInputConstructorValue("ffpytqvr", loader);
                 if(ffpytqvr["original"].length == 0)
                 {
                   Invalid("pixel_coef" + " is empty");
                   return;
                 }
var jqvakjuq = GetInputConstructorValue("jqvakjuq", loader);
                 if(jqvakjuq["original"].length == 0)
                 {
                   Invalid("reload_captcha" + " is empty");
                   return;
                 }
var tovhxduf = GetInputConstructorValue("tovhxduf", loader);
                 if(tovhxduf["original"].length == 0)
                 {
                   Invalid("type_data" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SolverGeetestIcon_code").html())({"uktuuwxm": uktuuwxm["updated"],"iankzrie": iankzrie["updated"],"zpqdnihz": zpqdnihz["updated"],"ipakienm": ipakienm["updated"],"ffpytqvr": ffpytqvr["updated"],"jqvakjuq": jqvakjuq["updated"],"tovhxduf": tovhxduf["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
