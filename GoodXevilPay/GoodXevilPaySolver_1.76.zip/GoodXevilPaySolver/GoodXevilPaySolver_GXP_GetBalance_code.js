_call_function(GoodXevilPaySolver_GXP_GetBalance,{ "APIKEY": (<%= ugnojrpj %>) })!
<%= variable %> = _result_function()
