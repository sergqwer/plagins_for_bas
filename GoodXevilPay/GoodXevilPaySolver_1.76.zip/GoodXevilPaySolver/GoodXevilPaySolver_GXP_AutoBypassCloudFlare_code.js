_call_function(GoodXevilPaySolver_GXP_AutoBypassCloudFlare,{ "custom_button": (<%= frwhqvwa %>),"max_time": (<%= yezdrmgy %>),"whait_element": (<%= cupdbkxf %>) })!
