<div class="container-fluid">
<%= _.template($('#input_constructor').html())({id:"olxydywk", description:"apikey", default_selector: "string", disable_expression:true, disable_int:true, value_string: "", help: {description: "apikey с бота в телеграмме https://t.me/Xevil_check_bot"} }) %>
</div>
<div class="tooltipinternal">
<div class="tr tooltip-paragraph-first-fold">Автоматически решает капчу на сайте https://surfearner.com/, для работы требуется функция SurfEarner AllowCache</div>
<div class="tr tooltip-paragraph-last-fold">Automatically solves captcha on https://surfearner.com/, requires SurfEarner AllowCache function to operate</div>
</div>
<%= _.template($('#back').html())({action:"executeandadd", visible:true}) %>
