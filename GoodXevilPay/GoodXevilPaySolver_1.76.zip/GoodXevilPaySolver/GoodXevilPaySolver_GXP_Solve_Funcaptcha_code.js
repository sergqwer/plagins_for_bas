_call_function(GoodXevilPaySolver_GXP_Solve_Funcaptcha,{ "APIKey": (<%= xwtnfhzc %>),"CaptchaNumber": (<%= evmcapms %>),"CaptchaSelector": (<%= renqajyv %>),"MaxLimitTask": (<%= zjbjhnha %>) })!
