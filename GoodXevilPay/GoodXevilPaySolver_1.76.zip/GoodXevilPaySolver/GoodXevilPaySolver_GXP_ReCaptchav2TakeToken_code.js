_call_function(GoodXevilPaySolver_GXP_ReCaptchav2TakeToken,{ "APIKEY": (<%= btdlvqcx %>),"site_url": (<%= hakrhugw %>),"sitekey": (<%= zinqcvtw %>) })!
<%= variable %> = _result_function()
