_call_function(GoodXevilPaySolver_GXP_Namars,{ "apikey": (<%= nbvlbldi %>) })!
<%= variable %> = _result_function()
