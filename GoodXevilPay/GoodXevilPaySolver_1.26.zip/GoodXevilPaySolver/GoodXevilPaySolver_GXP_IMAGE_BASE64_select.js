var xyjxsnln = GetInputConstructorValue("xyjxsnln", loader);
                 if(xyjxsnln["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var xeuxibeh = GetInputConstructorValue("xeuxibeh", loader);
                 if(xeuxibeh["original"].length == 0)
                 {
                   Invalid("IMAGE_BASE64" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_IMAGE_BASE64_code").html())({"xyjxsnln": xyjxsnln["updated"],"xeuxibeh": xeuxibeh["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
