_call_function(GoodXevilPaySolver_GXP_HcaptchaTakeToken,{ "APIKEY": (<%= buvliasf %>),"site_url": (<%= ejkyrwsn %>),"sitekey": (<%= aqeubufs %>) })!
<%= variable %> = _result_function()
