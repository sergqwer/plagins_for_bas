var knuotxph = GetInputConstructorValue("knuotxph", loader);
                 if(knuotxph["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var lvkeumus = GetInputConstructorValue("lvkeumus", loader);
                 if(lvkeumus["original"].length == 0)
                 {
                   Invalid("button_capthca" + " is empty");
                   return;
                 }
var eqvllsns = GetInputConstructorValue("eqvllsns", loader);
                 if(eqvllsns["original"].length == 0)
                 {
                   Invalid("captcha_submit" + " is empty");
                   return;
                 }
var ymjspxxb = GetInputConstructorValue("ymjspxxb", loader);
                 if(ymjspxxb["original"].length == 0)
                 {
                   Invalid("foto_captcha" + " is empty");
                   return;
                 }
var iytgrpbr = GetInputConstructorValue("iytgrpbr", loader);
                 if(iytgrpbr["original"].length == 0)
                 {
                   Invalid("reload_captcha" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SolverGeetestIcon_code").html())({"knuotxph": knuotxph["updated"],"lvkeumus": lvkeumus["updated"],"eqvllsns": eqvllsns["updated"],"ymjspxxb": ymjspxxb["updated"],"iytgrpbr": iytgrpbr["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
