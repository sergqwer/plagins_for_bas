var jnhblnae = GetInputConstructorValue("jnhblnae", loader);
                 if(jnhblnae["original"].length == 0)
                 {
                   Invalid("arrow_id" + " is empty");
                   return;
                 }
var vxdoyiuw = GetInputConstructorValue("vxdoyiuw", loader);
                 if(vxdoyiuw["original"].length == 0)
                 {
                   Invalid("avtoupdate" + " is empty");
                   return;
                 }
var tbffcpur = GetInputConstructorValue("tbffcpur", loader);
                 if(tbffcpur["original"].length == 0)
                 {
                   Invalid("button_id" + " is empty");
                   return;
                 }
var itvhkvkb = GetInputConstructorValue("itvhkvkb", loader);
                 if(itvhkvkb["original"].length == 0)
                 {
                   Invalid("coef" + " is empty");
                   return;
                 }
var pqrxvfvg = GetInputConstructorValue("pqrxvfvg", loader);
                 if(pqrxvfvg["original"].length == 0)
                 {
                   Invalid("image id" + " is empty");
                   return;
                 }
var fccuwyjv = GetInputConstructorValue("fccuwyjv", loader);
                 if(fccuwyjv["original"].length == 0)
                 {
                   Invalid("key" + " is empty");
                   return;
                 }
var qihaovum = GetInputConstructorValue("qihaovum", loader);
                 if(qihaovum["original"].length == 0)
                 {
                   Invalid("pixel_koef" + " is empty");
                   return;
                 }
var nxucmfis = GetInputConstructorValue("nxucmfis", loader);
                 if(nxucmfis["original"].length == 0)
                 {
                   Invalid("reload_id" + " is empty");
                   return;
                 }
var agbrmkdu = GetInputConstructorValue("agbrmkdu", loader);
                 if(agbrmkdu["original"].length == 0)
                 {
                   Invalid("speed" + " is empty");
                   return;
                 }
var zdwdbtmw = GetInputConstructorValue("zdwdbtmw", loader);
                 if(zdwdbtmw["original"].length == 0)
                 {
                   Invalid("type_slide" + " is empty");
                   return;
                 }
var ofcuvmyc = GetInputConstructorValue("ofcuvmyc", loader);
                 if(ofcuvmyc["original"].length == 0)
                 {
                   Invalid("type_swipe" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SliderSolver_code").html())({"jnhblnae": jnhblnae["updated"],"vxdoyiuw": vxdoyiuw["updated"],"tbffcpur": tbffcpur["updated"],"itvhkvkb": itvhkvkb["updated"],"pqrxvfvg": pqrxvfvg["updated"],"fccuwyjv": fccuwyjv["updated"],"qihaovum": qihaovum["updated"],"nxucmfis": nxucmfis["updated"],"agbrmkdu": agbrmkdu["updated"],"zdwdbtmw": zdwdbtmw["updated"],"ofcuvmyc": ofcuvmyc["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
