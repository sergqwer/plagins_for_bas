var mzbwgfvp = GetInputConstructorValue("mzbwgfvp", loader);
                 if(mzbwgfvp["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var oftaurci = GetInputConstructorValue("oftaurci", loader);
                 if(oftaurci["original"].length == 0)
                 {
                   Invalid("mouse" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_Antibot_code").html())({"mzbwgfvp": mzbwgfvp["updated"],"oftaurci": oftaurci["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
