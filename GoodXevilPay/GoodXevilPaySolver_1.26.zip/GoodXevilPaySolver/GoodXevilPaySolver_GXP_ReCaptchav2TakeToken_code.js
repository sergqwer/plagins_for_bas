_call_function(GoodXevilPaySolver_GXP_ReCaptchav2TakeToken,{ "APIKEY": (<%= wsjsemna %>),"site_url": (<%= mqfszjon %>),"sitekey": (<%= sxqlphbt %>) })!
<%= variable %> = _result_function()
