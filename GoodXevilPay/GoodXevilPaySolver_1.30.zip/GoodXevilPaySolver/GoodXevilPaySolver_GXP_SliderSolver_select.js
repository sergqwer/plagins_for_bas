var qxlnxmxu = GetInputConstructorValue("qxlnxmxu", loader);
                 if(qxlnxmxu["original"].length == 0)
                 {
                   Invalid("arrow_id" + " is empty");
                   return;
                 }
var laizarcy = GetInputConstructorValue("laizarcy", loader);
                 if(laizarcy["original"].length == 0)
                 {
                   Invalid("avtoupdate" + " is empty");
                   return;
                 }
var mhejtllm = GetInputConstructorValue("mhejtllm", loader);
                 if(mhejtllm["original"].length == 0)
                 {
                   Invalid("button_id" + " is empty");
                   return;
                 }
var czwicheo = GetInputConstructorValue("czwicheo", loader);
                 if(czwicheo["original"].length == 0)
                 {
                   Invalid("coef" + " is empty");
                   return;
                 }
var wnuqdlge = GetInputConstructorValue("wnuqdlge", loader);
                 if(wnuqdlge["original"].length == 0)
                 {
                   Invalid("image id" + " is empty");
                   return;
                 }
var adfujqer = GetInputConstructorValue("adfujqer", loader);
                 if(adfujqer["original"].length == 0)
                 {
                   Invalid("key" + " is empty");
                   return;
                 }
var tkxtqnav = GetInputConstructorValue("tkxtqnav", loader);
                 if(tkxtqnav["original"].length == 0)
                 {
                   Invalid("pixel_koef" + " is empty");
                   return;
                 }
var nhrgdxtj = GetInputConstructorValue("nhrgdxtj", loader);
                 if(nhrgdxtj["original"].length == 0)
                 {
                   Invalid("reload_id" + " is empty");
                   return;
                 }
var kkpckrpw = GetInputConstructorValue("kkpckrpw", loader);
                 if(kkpckrpw["original"].length == 0)
                 {
                   Invalid("speed" + " is empty");
                   return;
                 }
var guhsyjhg = GetInputConstructorValue("guhsyjhg", loader);
                 if(guhsyjhg["original"].length == 0)
                 {
                   Invalid("type_slide" + " is empty");
                   return;
                 }
var ypwfyqiv = GetInputConstructorValue("ypwfyqiv", loader);
                 if(ypwfyqiv["original"].length == 0)
                 {
                   Invalid("type_swipe" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SliderSolver_code").html())({"qxlnxmxu": qxlnxmxu["updated"],"laizarcy": laizarcy["updated"],"mhejtllm": mhejtllm["updated"],"czwicheo": czwicheo["updated"],"wnuqdlge": wnuqdlge["updated"],"adfujqer": adfujqer["updated"],"tkxtqnav": tkxtqnav["updated"],"nhrgdxtj": nhrgdxtj["updated"],"kkpckrpw": kkpckrpw["updated"],"guhsyjhg": guhsyjhg["updated"],"ypwfyqiv": ypwfyqiv["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
