var ibpniqnc = GetInputConstructorValue("ibpniqnc", loader);
                 if(ibpniqnc["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var pdiafnmz = GetInputConstructorValue("pdiafnmz", loader);
                 if(pdiafnmz["original"].length == 0)
                 {
                   Invalid("button_capthca" + " is empty");
                   return;
                 }
var hfkgvrwo = GetInputConstructorValue("hfkgvrwo", loader);
                 if(hfkgvrwo["original"].length == 0)
                 {
                   Invalid("captcha_submit" + " is empty");
                   return;
                 }
var pgfcncph = GetInputConstructorValue("pgfcncph", loader);
                 if(pgfcncph["original"].length == 0)
                 {
                   Invalid("foto_captcha" + " is empty");
                   return;
                 }
var npbhsseq = GetInputConstructorValue("npbhsseq", loader);
                 if(npbhsseq["original"].length == 0)
                 {
                   Invalid("reload_captcha" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SolverGeetestIcon_code").html())({"ibpniqnc": ibpniqnc["updated"],"pdiafnmz": pdiafnmz["updated"],"hfkgvrwo": hfkgvrwo["updated"],"pgfcncph": pgfcncph["updated"],"npbhsseq": npbhsseq["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
