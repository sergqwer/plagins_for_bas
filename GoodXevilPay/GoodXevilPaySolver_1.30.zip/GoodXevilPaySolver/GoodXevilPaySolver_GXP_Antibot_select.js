var rakpadve = GetInputConstructorValue("rakpadve", loader);
                 if(rakpadve["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var neoffhhg = GetInputConstructorValue("neoffhhg", loader);
                 if(neoffhhg["original"].length == 0)
                 {
                   Invalid("mouse" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_Antibot_code").html())({"rakpadve": rakpadve["updated"],"neoffhhg": neoffhhg["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
