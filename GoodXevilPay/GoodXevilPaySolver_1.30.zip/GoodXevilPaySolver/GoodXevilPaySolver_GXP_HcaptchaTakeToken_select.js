var ghupcdey = GetInputConstructorValue("ghupcdey", loader);
                 if(ghupcdey["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var kzfvflno = GetInputConstructorValue("kzfvflno", loader);
                 if(kzfvflno["original"].length == 0)
                 {
                   Invalid("site_url" + " is empty");
                   return;
                 }
var kdllhcbm = GetInputConstructorValue("kdllhcbm", loader);
                 if(kdllhcbm["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_HcaptchaTakeToken_code").html())({"ghupcdey": ghupcdey["updated"],"kzfvflno": kzfvflno["updated"],"kdllhcbm": kdllhcbm["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
