_call_function(GoodXevilPaySolver_GXP_ReCaptchav2TakeToken,{ "APIKEY": (<%= voobsmrs %>),"site_url": (<%= lndxnfuz %>),"sitekey": (<%= tlnjihhy %>) })!
<%= variable %> = _result_function()
