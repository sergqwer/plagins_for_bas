_call_function(GoodXevilPaySolver_GXP_HcaptchaTakeToken,{ "APIKEY": (<%= ghupcdey %>),"site_url": (<%= kzfvflno %>),"sitekey": (<%= kdllhcbm %>) })!
<%= variable %> = _result_function()
