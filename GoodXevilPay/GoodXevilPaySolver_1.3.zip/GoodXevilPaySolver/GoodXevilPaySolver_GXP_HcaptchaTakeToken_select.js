var wqqffqyp = GetInputConstructorValue("wqqffqyp", loader);
                 if(wqqffqyp["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var rxiudrca = GetInputConstructorValue("rxiudrca", loader);
                 if(rxiudrca["original"].length == 0)
                 {
                   Invalid("site_url" + " is empty");
                   return;
                 }
var aztcaegs = GetInputConstructorValue("aztcaegs", loader);
                 if(aztcaegs["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_HcaptchaTakeToken_code").html())({"wqqffqyp": wqqffqyp["updated"],"rxiudrca": rxiudrca["updated"],"aztcaegs": aztcaegs["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
