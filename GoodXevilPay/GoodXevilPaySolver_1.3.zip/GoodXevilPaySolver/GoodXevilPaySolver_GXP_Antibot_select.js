var oprcuohc = GetInputConstructorValue("oprcuohc", loader);
                 if(oprcuohc["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var mzlcspwn = GetInputConstructorValue("mzlcspwn", loader);
                 if(mzlcspwn["original"].length == 0)
                 {
                   Invalid("mouse" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_Antibot_code").html())({"oprcuohc": oprcuohc["updated"],"mzlcspwn": mzlcspwn["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
