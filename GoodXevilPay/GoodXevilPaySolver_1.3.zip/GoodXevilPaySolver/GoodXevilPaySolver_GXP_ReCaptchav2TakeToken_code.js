_call_function(GoodXevilPaySolver_GXP_ReCaptchav2TakeToken,{ "APIKEY": (<%= mrnlevon %>),"site_url": (<%= bzfoddfn %>),"sitekey": (<%= cryqclkr %>) })!
<%= variable %> = _result_function()
