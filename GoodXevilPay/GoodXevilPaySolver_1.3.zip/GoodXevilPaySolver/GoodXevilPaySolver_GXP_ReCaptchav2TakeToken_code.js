_call_function(GoodXevilPaySolver_GXP_ReCaptchav2TakeToken,{ "APIKEY": (<%= kyagsael %>),"site_url": (<%= lhnotbfh %>),"sitekey": (<%= szxnjtlj %>) })!
<%= variable %> = _result_function()
