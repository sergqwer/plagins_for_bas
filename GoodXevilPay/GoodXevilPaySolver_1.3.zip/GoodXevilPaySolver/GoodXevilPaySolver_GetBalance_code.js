_call_function(GoodXevilPaySolver_GetBalance,{ "APIKEY": (<%= lsfhoiyg %>) })!
<%= variable %> = _result_function()
