_call_function(GoodXevilPaySolver_GXP_GetBalance,{ "APIKEY": (<%= rluzwbgu %>) })!
<%= variable %> = _result_function()
