_call_function(GoodXevilPaySolver_ReCaptchav2TakeToken,{ "APIKEY": (<%= cymuvzux %>),"site_url": (<%= ifcnjark %>),"sitekey": (<%= rhcuxbvo %>) })!
<%= variable %> = _result_function()
