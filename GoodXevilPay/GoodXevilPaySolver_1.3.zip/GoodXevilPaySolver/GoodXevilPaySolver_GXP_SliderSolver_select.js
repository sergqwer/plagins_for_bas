var xwdgxbkb = GetInputConstructorValue("xwdgxbkb", loader);
                 if(xwdgxbkb["original"].length == 0)
                 {
                   Invalid("arrow_id" + " is empty");
                   return;
                 }
var dypsegol = GetInputConstructorValue("dypsegol", loader);
                 if(dypsegol["original"].length == 0)
                 {
                   Invalid("avtoupdate" + " is empty");
                   return;
                 }
var nkamdkox = GetInputConstructorValue("nkamdkox", loader);
                 if(nkamdkox["original"].length == 0)
                 {
                   Invalid("button_id" + " is empty");
                   return;
                 }
var lofpesbl = GetInputConstructorValue("lofpesbl", loader);
                 if(lofpesbl["original"].length == 0)
                 {
                   Invalid("coef" + " is empty");
                   return;
                 }
var hlogkywa = GetInputConstructorValue("hlogkywa", loader);
                 if(hlogkywa["original"].length == 0)
                 {
                   Invalid("image id" + " is empty");
                   return;
                 }
var fttwhjvm = GetInputConstructorValue("fttwhjvm", loader);
                 if(fttwhjvm["original"].length == 0)
                 {
                   Invalid("key" + " is empty");
                   return;
                 }
var pyarbouo = GetInputConstructorValue("pyarbouo", loader);
                 if(pyarbouo["original"].length == 0)
                 {
                   Invalid("pixel_koef" + " is empty");
                   return;
                 }
var qhfaxand = GetInputConstructorValue("qhfaxand", loader);
                 if(qhfaxand["original"].length == 0)
                 {
                   Invalid("reload_id" + " is empty");
                   return;
                 }
var irsrnwoo = GetInputConstructorValue("irsrnwoo", loader);
                 if(irsrnwoo["original"].length == 0)
                 {
                   Invalid("speed" + " is empty");
                   return;
                 }
var fidefwqv = GetInputConstructorValue("fidefwqv", loader);
                 if(fidefwqv["original"].length == 0)
                 {
                   Invalid("type_slide" + " is empty");
                   return;
                 }
var qtwbqysf = GetInputConstructorValue("qtwbqysf", loader);
                 if(qtwbqysf["original"].length == 0)
                 {
                   Invalid("type_swipe" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SliderSolver_code").html())({"xwdgxbkb": xwdgxbkb["updated"],"dypsegol": dypsegol["updated"],"nkamdkox": nkamdkox["updated"],"lofpesbl": lofpesbl["updated"],"hlogkywa": hlogkywa["updated"],"fttwhjvm": fttwhjvm["updated"],"pyarbouo": pyarbouo["updated"],"qhfaxand": qhfaxand["updated"],"irsrnwoo": irsrnwoo["updated"],"fidefwqv": fidefwqv["updated"],"qtwbqysf": qtwbqysf["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
