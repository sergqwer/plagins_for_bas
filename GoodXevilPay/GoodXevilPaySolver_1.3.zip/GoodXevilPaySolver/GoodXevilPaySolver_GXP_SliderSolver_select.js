var ymeuqrmy = GetInputConstructorValue("ymeuqrmy", loader);
                 if(ymeuqrmy["original"].length == 0)
                 {
                   Invalid("arrow_id" + " is empty");
                   return;
                 }
var oulpatcm = GetInputConstructorValue("oulpatcm", loader);
                 if(oulpatcm["original"].length == 0)
                 {
                   Invalid("avtoupdate" + " is empty");
                   return;
                 }
var myxobogh = GetInputConstructorValue("myxobogh", loader);
                 if(myxobogh["original"].length == 0)
                 {
                   Invalid("button_id" + " is empty");
                   return;
                 }
var vztngxyi = GetInputConstructorValue("vztngxyi", loader);
                 if(vztngxyi["original"].length == 0)
                 {
                   Invalid("coef" + " is empty");
                   return;
                 }
var gwkkpuuv = GetInputConstructorValue("gwkkpuuv", loader);
                 if(gwkkpuuv["original"].length == 0)
                 {
                   Invalid("image id" + " is empty");
                   return;
                 }
var xbmdpgqy = GetInputConstructorValue("xbmdpgqy", loader);
                 if(xbmdpgqy["original"].length == 0)
                 {
                   Invalid("key" + " is empty");
                   return;
                 }
var jtjgmbby = GetInputConstructorValue("jtjgmbby", loader);
                 if(jtjgmbby["original"].length == 0)
                 {
                   Invalid("pixel_koef" + " is empty");
                   return;
                 }
var bxwsbfxp = GetInputConstructorValue("bxwsbfxp", loader);
                 if(bxwsbfxp["original"].length == 0)
                 {
                   Invalid("reload_id" + " is empty");
                   return;
                 }
var mzqnfgrd = GetInputConstructorValue("mzqnfgrd", loader);
                 if(mzqnfgrd["original"].length == 0)
                 {
                   Invalid("speed" + " is empty");
                   return;
                 }
var iskxsyuy = GetInputConstructorValue("iskxsyuy", loader);
                 if(iskxsyuy["original"].length == 0)
                 {
                   Invalid("type_slide" + " is empty");
                   return;
                 }
var kjjqzwtg = GetInputConstructorValue("kjjqzwtg", loader);
                 if(kjjqzwtg["original"].length == 0)
                 {
                   Invalid("type_swipe" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SliderSolver_code").html())({"ymeuqrmy": ymeuqrmy["updated"],"oulpatcm": oulpatcm["updated"],"myxobogh": myxobogh["updated"],"vztngxyi": vztngxyi["updated"],"gwkkpuuv": gwkkpuuv["updated"],"xbmdpgqy": xbmdpgqy["updated"],"jtjgmbby": jtjgmbby["updated"],"bxwsbfxp": bxwsbfxp["updated"],"mzqnfgrd": mzqnfgrd["updated"],"iskxsyuy": iskxsyuy["updated"],"kjjqzwtg": kjjqzwtg["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
