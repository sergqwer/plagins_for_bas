<div class="container-fluid">
<%= _.template($('#input_constructor').html())({id:"mwtjsfqf", description:"apikey", default_selector: "string", disable_int:true, value_string: "", help: {description: "Ваш api ключ с сервиса https://t.me/Xevil_check_bot"} }) %>
<%= _.template($('#input_constructor').html())({id:"jsanylys", description:"button_capthca", default_selector: "string", disable_int:true, value_string: " >CSS> .geetest_btn_click", help: {description: "Идентификатор кнопки, после нажатия которой появляется капча"} }) %>
<%= _.template($('#input_constructor').html())({id:"fiagwxim", description:"captcha_submit", default_selector: "string", disable_int:true, value_string: " >CSS> .geetest_submit", help: {description: "Идентификатор кнопки, подтвердить решение"} }) %>
<%= _.template($('#input_constructor').html())({id:"utcyoqcl", description:"foto_captcha", default_selector: "string", disable_int:true, value_string: " >CSS> .geetest_bg", help: {description: "Идентификатор кнопки, фото капчи"} }) %>
<%= _.template($('#input_constructor').html())({id:"wogpnplv", description:"reload_captcha", default_selector: "string", disable_int:true, value_string: " >CSS> .geetest_refresh", help: {description: "Идентификатор кнопки, обновление капчи"} }) %>
</div>
<div class="tooltipinternal">
<div class="tr tooltip-paragraph-first-fold">Автоматически решает Geetest Icon на странице, для работы требуется функция GXP_AllowCacheForGeetestIcon</div>
</div>
<%= _.template($('#back').html())({action:"executeandadd", visible:true}) %>
