var mcqacosn = GetInputConstructorValue("mcqacosn", loader);
                 if(mcqacosn["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var rcrwadvb = GetInputConstructorValue("rcrwadvb", loader);
                 if(rcrwadvb["original"].length == 0)
                 {
                   Invalid("button_capthca" + " is empty");
                   return;
                 }
var qvyxfkop = GetInputConstructorValue("qvyxfkop", loader);
                 if(qvyxfkop["original"].length == 0)
                 {
                   Invalid("captcha_submit" + " is empty");
                   return;
                 }
var nhlojnjn = GetInputConstructorValue("nhlojnjn", loader);
                 if(nhlojnjn["original"].length == 0)
                 {
                   Invalid("foto_captcha" + " is empty");
                   return;
                 }
var duxzgmfl = GetInputConstructorValue("duxzgmfl", loader);
                 if(duxzgmfl["original"].length == 0)
                 {
                   Invalid("reload_captcha" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SolverGeetestIcon_code").html())({"mcqacosn": mcqacosn["updated"],"rcrwadvb": rcrwadvb["updated"],"qvyxfkop": qvyxfkop["updated"],"nhlojnjn": nhlojnjn["updated"],"duxzgmfl": duxzgmfl["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
