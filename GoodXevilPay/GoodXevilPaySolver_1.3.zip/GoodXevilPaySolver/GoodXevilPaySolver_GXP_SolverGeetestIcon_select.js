var mwtjsfqf = GetInputConstructorValue("mwtjsfqf", loader);
                 if(mwtjsfqf["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var jsanylys = GetInputConstructorValue("jsanylys", loader);
                 if(jsanylys["original"].length == 0)
                 {
                   Invalid("button_capthca" + " is empty");
                   return;
                 }
var fiagwxim = GetInputConstructorValue("fiagwxim", loader);
                 if(fiagwxim["original"].length == 0)
                 {
                   Invalid("captcha_submit" + " is empty");
                   return;
                 }
var utcyoqcl = GetInputConstructorValue("utcyoqcl", loader);
                 if(utcyoqcl["original"].length == 0)
                 {
                   Invalid("foto_captcha" + " is empty");
                   return;
                 }
var wogpnplv = GetInputConstructorValue("wogpnplv", loader);
                 if(wogpnplv["original"].length == 0)
                 {
                   Invalid("reload_captcha" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SolverGeetestIcon_code").html())({"mwtjsfqf": mwtjsfqf["updated"],"jsanylys": jsanylys["updated"],"fiagwxim": fiagwxim["updated"],"utcyoqcl": utcyoqcl["updated"],"wogpnplv": wogpnplv["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
