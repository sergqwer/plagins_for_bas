_call_function(GoodXevilPaySolver_GXP_HcaptchaTakeToken,{ "APIKEY": (<%= wqqffqyp %>),"site_url": (<%= rxiudrca %>),"sitekey": (<%= aztcaegs %>) })!
<%= variable %> = _result_function()
