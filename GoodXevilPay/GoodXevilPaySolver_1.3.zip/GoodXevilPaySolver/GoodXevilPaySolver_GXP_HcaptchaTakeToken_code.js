_call_function(GoodXevilPaySolver_GXP_HcaptchaTakeToken,{ "APIKEY": (<%= nwffulwy %>),"site_url": (<%= tptabien %>),"sitekey": (<%= iwtqwajw %>) })!
<%= variable %> = _result_function()
