_call_function(GoodXevilPaySolver_HcaptchaTakeToken,{ "APIKEY": (<%= ogelnozv %>),"site_url": (<%= vptezhsk %>),"sitekey": (<%= jonhxonh %>) })!
<%= variable %> = _result_function()
