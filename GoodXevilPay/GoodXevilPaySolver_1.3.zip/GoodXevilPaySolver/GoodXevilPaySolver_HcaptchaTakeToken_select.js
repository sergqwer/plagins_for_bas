var ogelnozv = GetInputConstructorValue("ogelnozv", loader);
                 if(ogelnozv["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var vptezhsk = GetInputConstructorValue("vptezhsk", loader);
                 if(vptezhsk["original"].length == 0)
                 {
                   Invalid("site_url" + " is empty");
                   return;
                 }
var jonhxonh = GetInputConstructorValue("jonhxonh", loader);
                 if(jonhxonh["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_HcaptchaTakeToken_code").html())({"ogelnozv": ogelnozv["updated"],"vptezhsk": vptezhsk["updated"],"jonhxonh": jonhxonh["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
