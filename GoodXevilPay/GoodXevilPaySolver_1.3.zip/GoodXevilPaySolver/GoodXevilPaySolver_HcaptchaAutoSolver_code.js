_call_function(GoodXevilPaySolver_HcaptchaAutoSolver,{ "apikey": (<%= gdvkgqmm %>) })!
