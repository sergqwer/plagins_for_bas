_call_function(OLD_GoodXevilPaySolver_GXP_ReCaptchav2TakeToken,{ "APIKEY": (<%= khrgejoo %>),"site_url": (<%= kzikxvqz %>),"sitekey": (<%= szglrhgj %>) })!
<%= variable %> = _result_function()
