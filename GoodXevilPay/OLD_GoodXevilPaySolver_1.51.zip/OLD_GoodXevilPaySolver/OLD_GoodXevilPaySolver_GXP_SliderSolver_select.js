var epmltjne = GetInputConstructorValue("epmltjne", loader);
                 if(epmltjne["original"].length == 0)
                 {
                   Invalid("arrow_id" + " is empty");
                   return;
                 }
var tvyrtlaq = GetInputConstructorValue("tvyrtlaq", loader);
                 if(tvyrtlaq["original"].length == 0)
                 {
                   Invalid("avtoupdate" + " is empty");
                   return;
                 }
var jlflgqxr = GetInputConstructorValue("jlflgqxr", loader);
                 if(jlflgqxr["original"].length == 0)
                 {
                   Invalid("button_id" + " is empty");
                   return;
                 }
var tkukzjdr = GetInputConstructorValue("tkukzjdr", loader);
                 if(tkukzjdr["original"].length == 0)
                 {
                   Invalid("coef" + " is empty");
                   return;
                 }
var ndxemxjd = GetInputConstructorValue("ndxemxjd", loader);
                 if(ndxemxjd["original"].length == 0)
                 {
                   Invalid("image id" + " is empty");
                   return;
                 }
var ivmdxtmf = GetInputConstructorValue("ivmdxtmf", loader);
                 if(ivmdxtmf["original"].length == 0)
                 {
                   Invalid("key" + " is empty");
                   return;
                 }
var cewpajev = GetInputConstructorValue("cewpajev", loader);
                 if(cewpajev["original"].length == 0)
                 {
                   Invalid("pixel_koef" + " is empty");
                   return;
                 }
var ddatgcbq = GetInputConstructorValue("ddatgcbq", loader);
                 if(ddatgcbq["original"].length == 0)
                 {
                   Invalid("reload_id" + " is empty");
                   return;
                 }
var hmelmhza = GetInputConstructorValue("hmelmhza", loader);
                 if(hmelmhza["original"].length == 0)
                 {
                   Invalid("speed" + " is empty");
                   return;
                 }
var odfnirrs = GetInputConstructorValue("odfnirrs", loader);
                 if(odfnirrs["original"].length == 0)
                 {
                   Invalid("type_slide" + " is empty");
                   return;
                 }
var ratxftgn = GetInputConstructorValue("ratxftgn", loader);
                 if(ratxftgn["original"].length == 0)
                 {
                   Invalid("type_swipe" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#OLD_GoodXevilPaySolver_GXP_SliderSolver_code").html())({"epmltjne": epmltjne["updated"],"tvyrtlaq": tvyrtlaq["updated"],"jlflgqxr": jlflgqxr["updated"],"tkukzjdr": tkukzjdr["updated"],"ndxemxjd": ndxemxjd["updated"],"ivmdxtmf": ivmdxtmf["updated"],"cewpajev": cewpajev["updated"],"ddatgcbq": ddatgcbq["updated"],"hmelmhza": hmelmhza["updated"],"odfnirrs": odfnirrs["updated"],"ratxftgn": ratxftgn["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
