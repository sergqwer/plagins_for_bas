_call_function(OLD_GoodXevilPaySolver_GXP_IMAGE_BASE64,{ "APIKEY": (<%= lmujnhkr %>),"IMAGE_BASE64": (<%= khvsvmfy %>) })!
<%= variable %> = _result_function()
