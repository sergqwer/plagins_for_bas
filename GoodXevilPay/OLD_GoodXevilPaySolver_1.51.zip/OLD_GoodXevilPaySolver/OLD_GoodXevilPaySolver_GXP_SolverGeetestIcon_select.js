var nuntjrdi = GetInputConstructorValue("nuntjrdi", loader);
                 if(nuntjrdi["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var vpccwcte = GetInputConstructorValue("vpccwcte", loader);
                 if(vpccwcte["original"].length == 0)
                 {
                   Invalid("button_capthca" + " is empty");
                   return;
                 }
var npwmxcnq = GetInputConstructorValue("npwmxcnq", loader);
                 if(npwmxcnq["original"].length == 0)
                 {
                   Invalid("captcha_submit" + " is empty");
                   return;
                 }
var gbkhokiw = GetInputConstructorValue("gbkhokiw", loader);
                 if(gbkhokiw["original"].length == 0)
                 {
                   Invalid("foto_captcha" + " is empty");
                   return;
                 }
var szzhmnxj = GetInputConstructorValue("szzhmnxj", loader);
                 if(szzhmnxj["original"].length == 0)
                 {
                   Invalid("pixel_coef" + " is empty");
                   return;
                 }
var xyxqcqyq = GetInputConstructorValue("xyxqcqyq", loader);
                 if(xyxqcqyq["original"].length == 0)
                 {
                   Invalid("reload_captcha" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#OLD_GoodXevilPaySolver_GXP_SolverGeetestIcon_code").html())({"nuntjrdi": nuntjrdi["updated"],"vpccwcte": vpccwcte["updated"],"npwmxcnq": npwmxcnq["updated"],"gbkhokiw": gbkhokiw["updated"],"szzhmnxj": szzhmnxj["updated"],"xyxqcqyq": xyxqcqyq["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
