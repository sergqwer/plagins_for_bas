_call_function(OLD_GoodXevilPaySolver_GXP_AutoBypassCloudFlare,{ "custom_button": (<%= qkzksdnw %>),"max_time": (<%= gvoqdjmu %>),"whait_element": (<%= pypwtast %>) })!
