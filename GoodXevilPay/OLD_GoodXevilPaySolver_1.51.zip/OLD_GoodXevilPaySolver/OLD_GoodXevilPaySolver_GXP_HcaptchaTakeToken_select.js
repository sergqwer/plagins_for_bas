var lqewijgn = GetInputConstructorValue("lqewijgn", loader);
                 if(lqewijgn["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var cfeomobx = GetInputConstructorValue("cfeomobx", loader);
                 if(cfeomobx["original"].length == 0)
                 {
                   Invalid("site_url" + " is empty");
                   return;
                 }
var zmukxcmm = GetInputConstructorValue("zmukxcmm", loader);
                 if(zmukxcmm["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#OLD_GoodXevilPaySolver_GXP_HcaptchaTakeToken_code").html())({"lqewijgn": lqewijgn["updated"],"cfeomobx": cfeomobx["updated"],"zmukxcmm": zmukxcmm["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
