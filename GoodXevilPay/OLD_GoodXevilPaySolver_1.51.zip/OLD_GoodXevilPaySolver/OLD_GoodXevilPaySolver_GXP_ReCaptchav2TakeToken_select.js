var khrgejoo = GetInputConstructorValue("khrgejoo", loader);
                 if(khrgejoo["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var kzikxvqz = GetInputConstructorValue("kzikxvqz", loader);
                 if(kzikxvqz["original"].length == 0)
                 {
                   Invalid("site_url" + " is empty");
                   return;
                 }
var szglrhgj = GetInputConstructorValue("szglrhgj", loader);
                 if(szglrhgj["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#OLD_GoodXevilPaySolver_GXP_ReCaptchav2TakeToken_code").html())({"khrgejoo": khrgejoo["updated"],"kzikxvqz": kzikxvqz["updated"],"szglrhgj": szglrhgj["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
