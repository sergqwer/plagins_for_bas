_call_function(OLD_GoodXevilPaySolver_GXP_HcaptchaTakeToken,{ "APIKEY": (<%= lqewijgn %>),"site_url": (<%= cfeomobx %>),"sitekey": (<%= zmukxcmm %>) })!
<%= variable %> = _result_function()
