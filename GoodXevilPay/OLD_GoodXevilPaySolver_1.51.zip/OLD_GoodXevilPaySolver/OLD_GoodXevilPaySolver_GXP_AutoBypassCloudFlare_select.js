var qkzksdnw = GetInputConstructorValue("qkzksdnw", loader);
                 if(qkzksdnw["original"].length == 0)
                 {
                   Invalid("custom_button" + " is empty");
                   return;
                 }
var gvoqdjmu = GetInputConstructorValue("gvoqdjmu", loader);
                 if(gvoqdjmu["original"].length == 0)
                 {
                   Invalid("max_time" + " is empty");
                   return;
                 }
var pypwtast = GetInputConstructorValue("pypwtast", loader);
                 if(pypwtast["original"].length == 0)
                 {
                   Invalid("whait_element" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#OLD_GoodXevilPaySolver_GXP_AutoBypassCloudFlare_code").html())({"qkzksdnw": qkzksdnw["updated"],"gvoqdjmu": gvoqdjmu["updated"],"pypwtast": pypwtast["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
