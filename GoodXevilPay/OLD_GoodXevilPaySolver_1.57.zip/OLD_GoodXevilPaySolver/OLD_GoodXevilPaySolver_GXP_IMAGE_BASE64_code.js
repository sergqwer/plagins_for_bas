_call_function(OLD_GoodXevilPaySolver_GXP_IMAGE_BASE64,{ "APIKEY": (<%= xcoffowf %>),"IMAGE_BASE64": (<%= wkgeczxm %>) })!
<%= variable %> = _result_function()
