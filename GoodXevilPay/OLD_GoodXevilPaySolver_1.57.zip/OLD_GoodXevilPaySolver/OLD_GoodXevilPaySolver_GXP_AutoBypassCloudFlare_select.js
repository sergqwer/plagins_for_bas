var rwhnfjzm = GetInputConstructorValue("rwhnfjzm", loader);
                 if(rwhnfjzm["original"].length == 0)
                 {
                   Invalid("custom_button" + " is empty");
                   return;
                 }
var bdymyocm = GetInputConstructorValue("bdymyocm", loader);
                 if(bdymyocm["original"].length == 0)
                 {
                   Invalid("max_time" + " is empty");
                   return;
                 }
var quddocna = GetInputConstructorValue("quddocna", loader);
                 if(quddocna["original"].length == 0)
                 {
                   Invalid("whait_element" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#OLD_GoodXevilPaySolver_GXP_AutoBypassCloudFlare_code").html())({"rwhnfjzm": rwhnfjzm["updated"],"bdymyocm": bdymyocm["updated"],"quddocna": quddocna["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
