_call_function(OLD_GoodXevilPaySolver_GXP_AutoConfirmCallback_ReCaptcha,{ "token": (<%= punkmbjs %>) })!
