var rogyyffd = GetInputConstructorValue("rogyyffd", loader);
                 if(rogyyffd["original"].length == 0)
                 {
                   Invalid("arrow_id" + " is empty");
                   return;
                 }
var qwxjfkyv = GetInputConstructorValue("qwxjfkyv", loader);
                 if(qwxjfkyv["original"].length == 0)
                 {
                   Invalid("avtoupdate" + " is empty");
                   return;
                 }
var fptdldrk = GetInputConstructorValue("fptdldrk", loader);
                 if(fptdldrk["original"].length == 0)
                 {
                   Invalid("button_id" + " is empty");
                   return;
                 }
var vocngxfy = GetInputConstructorValue("vocngxfy", loader);
                 if(vocngxfy["original"].length == 0)
                 {
                   Invalid("coef" + " is empty");
                   return;
                 }
var tngpgcqb = GetInputConstructorValue("tngpgcqb", loader);
                 if(tngpgcqb["original"].length == 0)
                 {
                   Invalid("image id" + " is empty");
                   return;
                 }
var reguorbx = GetInputConstructorValue("reguorbx", loader);
                 if(reguorbx["original"].length == 0)
                 {
                   Invalid("key" + " is empty");
                   return;
                 }
var kyuqddlq = GetInputConstructorValue("kyuqddlq", loader);
                 if(kyuqddlq["original"].length == 0)
                 {
                   Invalid("pixel_koef" + " is empty");
                   return;
                 }
var zuytinzr = GetInputConstructorValue("zuytinzr", loader);
                 if(zuytinzr["original"].length == 0)
                 {
                   Invalid("reload_id" + " is empty");
                   return;
                 }
var ypdjwnol = GetInputConstructorValue("ypdjwnol", loader);
                 if(ypdjwnol["original"].length == 0)
                 {
                   Invalid("speed" + " is empty");
                   return;
                 }
var xdxndxhs = GetInputConstructorValue("xdxndxhs", loader);
                 if(xdxndxhs["original"].length == 0)
                 {
                   Invalid("type_slide" + " is empty");
                   return;
                 }
var lzcdcktv = GetInputConstructorValue("lzcdcktv", loader);
                 if(lzcdcktv["original"].length == 0)
                 {
                   Invalid("type_swipe" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#OLD_GoodXevilPaySolver_GXP_SliderSolver_code").html())({"rogyyffd": rogyyffd["updated"],"qwxjfkyv": qwxjfkyv["updated"],"fptdldrk": fptdldrk["updated"],"vocngxfy": vocngxfy["updated"],"tngpgcqb": tngpgcqb["updated"],"reguorbx": reguorbx["updated"],"kyuqddlq": kyuqddlq["updated"],"zuytinzr": zuytinzr["updated"],"ypdjwnol": ypdjwnol["updated"],"xdxndxhs": xdxndxhs["updated"],"lzcdcktv": lzcdcktv["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
