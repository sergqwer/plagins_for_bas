_call_function(OLD_GoodXevilPaySolver_GXP_AutoBypassCloudFlare,{ "custom_button": (<%= rwhnfjzm %>),"max_time": (<%= bdymyocm %>),"whait_element": (<%= quddocna %>) })!
