var frhlvxhf = GetInputConstructorValue("frhlvxhf", loader);
                 if(frhlvxhf["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var mwryrzhx = GetInputConstructorValue("mwryrzhx", loader);
                 if(mwryrzhx["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var mvjywtoe = GetInputConstructorValue("mvjywtoe", loader);
                 if(mvjywtoe["original"].length == 0)
                 {
                   Invalid("siteurl" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#OLD_GoodXevilPaySolver_GXP_BasiliskCaptcha_code").html())({"frhlvxhf": frhlvxhf["updated"],"mwryrzhx": mwryrzhx["updated"],"mvjywtoe": mvjywtoe["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
