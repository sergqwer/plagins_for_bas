var kvmdsyxv = GetInputConstructorValue("kvmdsyxv", loader);
                 if(kvmdsyxv["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var cgrstnjp = GetInputConstructorValue("cgrstnjp", loader);
                 if(cgrstnjp["original"].length == 0)
                 {
                   Invalid("captcha_submit" + " is empty");
                   return;
                 }
var bwqkjtqx = GetInputConstructorValue("bwqkjtqx", loader);
                 if(bwqkjtqx["original"].length == 0)
                 {
                   Invalid("foto_captcha" + " is empty");
                   return;
                 }
var ndnlxpbh = GetInputConstructorValue("ndnlxpbh", loader);
                 if(ndnlxpbh["original"].length == 0)
                 {
                   Invalid("pixel_coef" + " is empty");
                   return;
                 }
var rnzfdmbq = GetInputConstructorValue("rnzfdmbq", loader);
                 if(rnzfdmbq["original"].length == 0)
                 {
                   Invalid("reload_captcha" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#OLD_GoodXevilPaySolver_GXP_SolverGeetestIcon_code").html())({"kvmdsyxv": kvmdsyxv["updated"],"cgrstnjp": cgrstnjp["updated"],"bwqkjtqx": bwqkjtqx["updated"],"ndnlxpbh": ndnlxpbh["updated"],"rnzfdmbq": rnzfdmbq["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
