var dwdkhyct = GetInputConstructorValue("dwdkhyct", loader);
                 if(dwdkhyct["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#OLD_GoodXevilPaySolver_GXP_IconCaptchaSolver_code").html())({"dwdkhyct": dwdkhyct["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
