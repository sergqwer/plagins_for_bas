_call_function(OLD_GoodXevilPaySolver_GXP_HcaptchaTakeToken,{ "APIKEY": (<%= ljodasgq %>),"site_url": (<%= clcjyrzg %>),"sitekey": (<%= xvjvguqr %>) })!
<%= variable %> = _result_function()
