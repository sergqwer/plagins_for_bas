var ljodasgq = GetInputConstructorValue("ljodasgq", loader);
                 if(ljodasgq["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var clcjyrzg = GetInputConstructorValue("clcjyrzg", loader);
                 if(clcjyrzg["original"].length == 0)
                 {
                   Invalid("site_url" + " is empty");
                   return;
                 }
var xvjvguqr = GetInputConstructorValue("xvjvguqr", loader);
                 if(xvjvguqr["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#OLD_GoodXevilPaySolver_GXP_HcaptchaTakeToken_code").html())({"ljodasgq": ljodasgq["updated"],"clcjyrzg": clcjyrzg["updated"],"xvjvguqr": xvjvguqr["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
