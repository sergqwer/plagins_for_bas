_call_function(OLD_GoodXevilPaySolver_GXP_ReCaptchav2TakeToken,{ "APIKEY": (<%= aliuvwvz %>),"site_url": (<%= jnxurzjm %>),"sitekey": (<%= egtwxryg %>) })!
<%= variable %> = _result_function()
