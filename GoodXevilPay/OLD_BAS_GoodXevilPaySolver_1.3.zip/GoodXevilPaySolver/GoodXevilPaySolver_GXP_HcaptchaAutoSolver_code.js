_call_function(GoodXevilPaySolver_GXP_HcaptchaAutoSolver,{ "apikey": (<%= cxpxeftn %>) })!
