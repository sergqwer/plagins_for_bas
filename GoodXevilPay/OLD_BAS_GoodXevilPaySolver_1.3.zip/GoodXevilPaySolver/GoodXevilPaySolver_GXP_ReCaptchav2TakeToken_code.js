_call_function(GoodXevilPaySolver_GXP_ReCaptchav2TakeToken,{ "APIKEY": (<%= fpbfxtbn %>),"site_url": (<%= wgaqnzqx %>),"sitekey": (<%= zqivkxgq %>) })!
<%= variable %> = _result_function()
