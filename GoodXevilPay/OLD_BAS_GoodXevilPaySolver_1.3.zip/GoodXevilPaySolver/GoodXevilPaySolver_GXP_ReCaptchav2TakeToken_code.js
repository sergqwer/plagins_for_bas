_call_function(GoodXevilPaySolver_GXP_ReCaptchav2TakeToken,{ "APIKEY": (<%= juiiwczu %>),"site_url": (<%= cdmkeutn %>),"sitekey": (<%= ekzfjrcu %>) })!
<%= variable %> = _result_function()
