_call_function(GoodXevilPaySolver_GXP_HcaptchaTakeToken,{ "APIKEY": (<%= dijcdpih %>),"site_url": (<%= jcmmniqe %>),"sitekey": (<%= mijqdftq %>) })!
<%= variable %> = _result_function()
