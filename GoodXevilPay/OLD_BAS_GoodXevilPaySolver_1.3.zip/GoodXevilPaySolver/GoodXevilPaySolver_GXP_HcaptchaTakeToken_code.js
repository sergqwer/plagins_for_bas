_call_function(GoodXevilPaySolver_GXP_HcaptchaTakeToken,{ "APIKEY": (<%= zntzjndi %>),"site_url": (<%= lcxokdrq %>),"sitekey": (<%= ducaxehn %>) })!
<%= variable %> = _result_function()
