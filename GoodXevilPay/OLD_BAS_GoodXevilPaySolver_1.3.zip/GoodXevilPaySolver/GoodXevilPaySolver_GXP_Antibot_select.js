var wmyedabo = GetInputConstructorValue("wmyedabo", loader);
                 if(wmyedabo["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var lzatfkxd = GetInputConstructorValue("lzatfkxd", loader);
                 if(lzatfkxd["original"].length == 0)
                 {
                   Invalid("mouse" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_Antibot_code").html())({"wmyedabo": wmyedabo["updated"],"lzatfkxd": lzatfkxd["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
