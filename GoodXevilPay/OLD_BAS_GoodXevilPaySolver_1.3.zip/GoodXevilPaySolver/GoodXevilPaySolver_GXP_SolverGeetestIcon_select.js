var xoeklixa = GetInputConstructorValue("xoeklixa", loader);
                 if(xoeklixa["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var pjmdrhqy = GetInputConstructorValue("pjmdrhqy", loader);
                 if(pjmdrhqy["original"].length == 0)
                 {
                   Invalid("button_capthca" + " is empty");
                   return;
                 }
var yyyygtpy = GetInputConstructorValue("yyyygtpy", loader);
                 if(yyyygtpy["original"].length == 0)
                 {
                   Invalid("captcha_submit" + " is empty");
                   return;
                 }
var iyqzwhiy = GetInputConstructorValue("iyqzwhiy", loader);
                 if(iyqzwhiy["original"].length == 0)
                 {
                   Invalid("foto_captcha" + " is empty");
                   return;
                 }
var lxgnbvwv = GetInputConstructorValue("lxgnbvwv", loader);
                 if(lxgnbvwv["original"].length == 0)
                 {
                   Invalid("reload_captcha" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SolverGeetestIcon_code").html())({"xoeklixa": xoeklixa["updated"],"pjmdrhqy": pjmdrhqy["updated"],"yyyygtpy": yyyygtpy["updated"],"iyqzwhiy": iyqzwhiy["updated"],"lxgnbvwv": lxgnbvwv["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
