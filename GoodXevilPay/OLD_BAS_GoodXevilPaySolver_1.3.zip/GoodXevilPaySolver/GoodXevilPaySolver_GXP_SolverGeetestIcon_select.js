var myljswvj = GetInputConstructorValue("myljswvj", loader);
                 if(myljswvj["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var xryokbpc = GetInputConstructorValue("xryokbpc", loader);
                 if(xryokbpc["original"].length == 0)
                 {
                   Invalid("button_capthca" + " is empty");
                   return;
                 }
var dkqkapsy = GetInputConstructorValue("dkqkapsy", loader);
                 if(dkqkapsy["original"].length == 0)
                 {
                   Invalid("captcha_submit" + " is empty");
                   return;
                 }
var cplajhye = GetInputConstructorValue("cplajhye", loader);
                 if(cplajhye["original"].length == 0)
                 {
                   Invalid("foto_captcha" + " is empty");
                   return;
                 }
var emqwport = GetInputConstructorValue("emqwport", loader);
                 if(emqwport["original"].length == 0)
                 {
                   Invalid("reload_captcha" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SolverGeetestIcon_code").html())({"myljswvj": myljswvj["updated"],"xryokbpc": xryokbpc["updated"],"dkqkapsy": dkqkapsy["updated"],"cplajhye": cplajhye["updated"],"emqwport": emqwport["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
