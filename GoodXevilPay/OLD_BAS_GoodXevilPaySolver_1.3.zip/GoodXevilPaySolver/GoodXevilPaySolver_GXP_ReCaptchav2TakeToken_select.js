var fpbfxtbn = GetInputConstructorValue("fpbfxtbn", loader);
                 if(fpbfxtbn["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var wgaqnzqx = GetInputConstructorValue("wgaqnzqx", loader);
                 if(wgaqnzqx["original"].length == 0)
                 {
                   Invalid("site_url" + " is empty");
                   return;
                 }
var zqivkxgq = GetInputConstructorValue("zqivkxgq", loader);
                 if(zqivkxgq["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_ReCaptchav2TakeToken_code").html())({"fpbfxtbn": fpbfxtbn["updated"],"wgaqnzqx": wgaqnzqx["updated"],"zqivkxgq": zqivkxgq["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
