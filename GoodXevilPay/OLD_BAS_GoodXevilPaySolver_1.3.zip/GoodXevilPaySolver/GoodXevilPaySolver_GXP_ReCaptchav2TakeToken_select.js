var juiiwczu = GetInputConstructorValue("juiiwczu", loader);
                 if(juiiwczu["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var cdmkeutn = GetInputConstructorValue("cdmkeutn", loader);
                 if(cdmkeutn["original"].length == 0)
                 {
                   Invalid("site_url" + " is empty");
                   return;
                 }
var ekzfjrcu = GetInputConstructorValue("ekzfjrcu", loader);
                 if(ekzfjrcu["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_ReCaptchav2TakeToken_code").html())({"juiiwczu": juiiwczu["updated"],"cdmkeutn": cdmkeutn["updated"],"ekzfjrcu": ekzfjrcu["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
