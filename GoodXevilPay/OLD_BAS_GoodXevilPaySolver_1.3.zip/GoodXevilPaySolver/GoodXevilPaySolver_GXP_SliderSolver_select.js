var gletnqzg = GetInputConstructorValue("gletnqzg", loader);
                 if(gletnqzg["original"].length == 0)
                 {
                   Invalid("arrow_id" + " is empty");
                   return;
                 }
var eneerjru = GetInputConstructorValue("eneerjru", loader);
                 if(eneerjru["original"].length == 0)
                 {
                   Invalid("avtoupdate" + " is empty");
                   return;
                 }
var kquaulnn = GetInputConstructorValue("kquaulnn", loader);
                 if(kquaulnn["original"].length == 0)
                 {
                   Invalid("button_id" + " is empty");
                   return;
                 }
var gouldurn = GetInputConstructorValue("gouldurn", loader);
                 if(gouldurn["original"].length == 0)
                 {
                   Invalid("coef" + " is empty");
                   return;
                 }
var ogpyhofx = GetInputConstructorValue("ogpyhofx", loader);
                 if(ogpyhofx["original"].length == 0)
                 {
                   Invalid("image id" + " is empty");
                   return;
                 }
var gaqkmiqw = GetInputConstructorValue("gaqkmiqw", loader);
                 if(gaqkmiqw["original"].length == 0)
                 {
                   Invalid("key" + " is empty");
                   return;
                 }
var qyorwxam = GetInputConstructorValue("qyorwxam", loader);
                 if(qyorwxam["original"].length == 0)
                 {
                   Invalid("pixel_koef" + " is empty");
                   return;
                 }
var fiknaxhn = GetInputConstructorValue("fiknaxhn", loader);
                 if(fiknaxhn["original"].length == 0)
                 {
                   Invalid("reload_id" + " is empty");
                   return;
                 }
var sallgwtf = GetInputConstructorValue("sallgwtf", loader);
                 if(sallgwtf["original"].length == 0)
                 {
                   Invalid("speed" + " is empty");
                   return;
                 }
var saezuqau = GetInputConstructorValue("saezuqau", loader);
                 if(saezuqau["original"].length == 0)
                 {
                   Invalid("type_slide" + " is empty");
                   return;
                 }
var rnvxaiwy = GetInputConstructorValue("rnvxaiwy", loader);
                 if(rnvxaiwy["original"].length == 0)
                 {
                   Invalid("type_swipe" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SliderSolver_code").html())({"gletnqzg": gletnqzg["updated"],"eneerjru": eneerjru["updated"],"kquaulnn": kquaulnn["updated"],"gouldurn": gouldurn["updated"],"ogpyhofx": ogpyhofx["updated"],"gaqkmiqw": gaqkmiqw["updated"],"qyorwxam": qyorwxam["updated"],"fiknaxhn": fiknaxhn["updated"],"sallgwtf": sallgwtf["updated"],"saezuqau": saezuqau["updated"],"rnvxaiwy": rnvxaiwy["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
