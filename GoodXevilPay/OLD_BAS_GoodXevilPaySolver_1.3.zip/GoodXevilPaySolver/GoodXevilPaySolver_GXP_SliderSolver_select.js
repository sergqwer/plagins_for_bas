var jlwzyteo = GetInputConstructorValue("jlwzyteo", loader);
                 if(jlwzyteo["original"].length == 0)
                 {
                   Invalid("arrow_id" + " is empty");
                   return;
                 }
var hrahrlky = GetInputConstructorValue("hrahrlky", loader);
                 if(hrahrlky["original"].length == 0)
                 {
                   Invalid("avtoupdate" + " is empty");
                   return;
                 }
var qrqjbsgx = GetInputConstructorValue("qrqjbsgx", loader);
                 if(qrqjbsgx["original"].length == 0)
                 {
                   Invalid("button_id" + " is empty");
                   return;
                 }
var iyjhvduk = GetInputConstructorValue("iyjhvduk", loader);
                 if(iyjhvduk["original"].length == 0)
                 {
                   Invalid("coef" + " is empty");
                   return;
                 }
var pqakzouv = GetInputConstructorValue("pqakzouv", loader);
                 if(pqakzouv["original"].length == 0)
                 {
                   Invalid("image id" + " is empty");
                   return;
                 }
var nhyheskd = GetInputConstructorValue("nhyheskd", loader);
                 if(nhyheskd["original"].length == 0)
                 {
                   Invalid("key" + " is empty");
                   return;
                 }
var jujmqfxw = GetInputConstructorValue("jujmqfxw", loader);
                 if(jujmqfxw["original"].length == 0)
                 {
                   Invalid("pixel_koef" + " is empty");
                   return;
                 }
var ripmpzgy = GetInputConstructorValue("ripmpzgy", loader);
                 if(ripmpzgy["original"].length == 0)
                 {
                   Invalid("reload_id" + " is empty");
                   return;
                 }
var kprsvjaf = GetInputConstructorValue("kprsvjaf", loader);
                 if(kprsvjaf["original"].length == 0)
                 {
                   Invalid("speed" + " is empty");
                   return;
                 }
var mismhovs = GetInputConstructorValue("mismhovs", loader);
                 if(mismhovs["original"].length == 0)
                 {
                   Invalid("type_slide" + " is empty");
                   return;
                 }
var xaooilib = GetInputConstructorValue("xaooilib", loader);
                 if(xaooilib["original"].length == 0)
                 {
                   Invalid("type_swipe" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SliderSolver_code").html())({"jlwzyteo": jlwzyteo["updated"],"hrahrlky": hrahrlky["updated"],"qrqjbsgx": qrqjbsgx["updated"],"iyjhvduk": iyjhvduk["updated"],"pqakzouv": pqakzouv["updated"],"nhyheskd": nhyheskd["updated"],"jujmqfxw": jujmqfxw["updated"],"ripmpzgy": ripmpzgy["updated"],"kprsvjaf": kprsvjaf["updated"],"mismhovs": mismhovs["updated"],"xaooilib": xaooilib["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
