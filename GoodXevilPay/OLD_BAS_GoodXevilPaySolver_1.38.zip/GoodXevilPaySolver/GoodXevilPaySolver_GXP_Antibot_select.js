var ztosyihp = GetInputConstructorValue("ztosyihp", loader);
                 if(ztosyihp["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var hobgzhts = GetInputConstructorValue("hobgzhts", loader);
                 if(hobgzhts["original"].length == 0)
                 {
                   Invalid("mouse" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_Antibot_code").html())({"ztosyihp": ztosyihp["updated"],"hobgzhts": hobgzhts["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
