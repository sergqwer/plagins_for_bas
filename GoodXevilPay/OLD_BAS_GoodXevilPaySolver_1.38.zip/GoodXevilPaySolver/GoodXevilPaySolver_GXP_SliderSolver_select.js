var zrzmajvx = GetInputConstructorValue("zrzmajvx", loader);
                 if(zrzmajvx["original"].length == 0)
                 {
                   Invalid("arrow_id" + " is empty");
                   return;
                 }
var neqtisil = GetInputConstructorValue("neqtisil", loader);
                 if(neqtisil["original"].length == 0)
                 {
                   Invalid("avtoupdate" + " is empty");
                   return;
                 }
var dhwqrcum = GetInputConstructorValue("dhwqrcum", loader);
                 if(dhwqrcum["original"].length == 0)
                 {
                   Invalid("button_id" + " is empty");
                   return;
                 }
var zzbdvfgp = GetInputConstructorValue("zzbdvfgp", loader);
                 if(zzbdvfgp["original"].length == 0)
                 {
                   Invalid("coef" + " is empty");
                   return;
                 }
var fixtqvaw = GetInputConstructorValue("fixtqvaw", loader);
                 if(fixtqvaw["original"].length == 0)
                 {
                   Invalid("image id" + " is empty");
                   return;
                 }
var qnnygmop = GetInputConstructorValue("qnnygmop", loader);
                 if(qnnygmop["original"].length == 0)
                 {
                   Invalid("key" + " is empty");
                   return;
                 }
var jyerpmgv = GetInputConstructorValue("jyerpmgv", loader);
                 if(jyerpmgv["original"].length == 0)
                 {
                   Invalid("pixel_koef" + " is empty");
                   return;
                 }
var ndkfpnhb = GetInputConstructorValue("ndkfpnhb", loader);
                 if(ndkfpnhb["original"].length == 0)
                 {
                   Invalid("reload_id" + " is empty");
                   return;
                 }
var uhcibhfs = GetInputConstructorValue("uhcibhfs", loader);
                 if(uhcibhfs["original"].length == 0)
                 {
                   Invalid("speed" + " is empty");
                   return;
                 }
var dswigodt = GetInputConstructorValue("dswigodt", loader);
                 if(dswigodt["original"].length == 0)
                 {
                   Invalid("type_slide" + " is empty");
                   return;
                 }
var nzbqqwuh = GetInputConstructorValue("nzbqqwuh", loader);
                 if(nzbqqwuh["original"].length == 0)
                 {
                   Invalid("type_swipe" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SliderSolver_code").html())({"zrzmajvx": zrzmajvx["updated"],"neqtisil": neqtisil["updated"],"dhwqrcum": dhwqrcum["updated"],"zzbdvfgp": zzbdvfgp["updated"],"fixtqvaw": fixtqvaw["updated"],"qnnygmop": qnnygmop["updated"],"jyerpmgv": jyerpmgv["updated"],"ndkfpnhb": ndkfpnhb["updated"],"uhcibhfs": uhcibhfs["updated"],"dswigodt": dswigodt["updated"],"nzbqqwuh": nzbqqwuh["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
