var pchvlarr = GetInputConstructorValue("pchvlarr", loader);
                 if(pchvlarr["original"].length == 0)
                 {
                   Invalid("arrow_id" + " is empty");
                   return;
                 }
var grdsxauj = GetInputConstructorValue("grdsxauj", loader);
                 if(grdsxauj["original"].length == 0)
                 {
                   Invalid("avtoupdate" + " is empty");
                   return;
                 }
var ahoqbsxt = GetInputConstructorValue("ahoqbsxt", loader);
                 if(ahoqbsxt["original"].length == 0)
                 {
                   Invalid("button_id" + " is empty");
                   return;
                 }
var zmmfbbno = GetInputConstructorValue("zmmfbbno", loader);
                 if(zmmfbbno["original"].length == 0)
                 {
                   Invalid("coef" + " is empty");
                   return;
                 }
var mpodjywq = GetInputConstructorValue("mpodjywq", loader);
                 if(mpodjywq["original"].length == 0)
                 {
                   Invalid("image id" + " is empty");
                   return;
                 }
var gthunjmh = GetInputConstructorValue("gthunjmh", loader);
                 if(gthunjmh["original"].length == 0)
                 {
                   Invalid("key" + " is empty");
                   return;
                 }
var gjbfizrc = GetInputConstructorValue("gjbfizrc", loader);
                 if(gjbfizrc["original"].length == 0)
                 {
                   Invalid("pixel_koef" + " is empty");
                   return;
                 }
var tqoowzhr = GetInputConstructorValue("tqoowzhr", loader);
                 if(tqoowzhr["original"].length == 0)
                 {
                   Invalid("reload_id" + " is empty");
                   return;
                 }
var qczkankd = GetInputConstructorValue("qczkankd", loader);
                 if(qczkankd["original"].length == 0)
                 {
                   Invalid("speed" + " is empty");
                   return;
                 }
var bktsrgad = GetInputConstructorValue("bktsrgad", loader);
                 if(bktsrgad["original"].length == 0)
                 {
                   Invalid("type_slide" + " is empty");
                   return;
                 }
var wtbpebod = GetInputConstructorValue("wtbpebod", loader);
                 if(wtbpebod["original"].length == 0)
                 {
                   Invalid("type_swipe" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SliderSolver_code").html())({"pchvlarr": pchvlarr["updated"],"grdsxauj": grdsxauj["updated"],"ahoqbsxt": ahoqbsxt["updated"],"zmmfbbno": zmmfbbno["updated"],"mpodjywq": mpodjywq["updated"],"gthunjmh": gthunjmh["updated"],"gjbfizrc": gjbfizrc["updated"],"tqoowzhr": tqoowzhr["updated"],"qczkankd": qczkankd["updated"],"bktsrgad": bktsrgad["updated"],"wtbpebod": wtbpebod["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
