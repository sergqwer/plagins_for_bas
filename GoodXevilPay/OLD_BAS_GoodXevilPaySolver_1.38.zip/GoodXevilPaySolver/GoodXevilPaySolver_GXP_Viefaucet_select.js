var txyqrrcs = GetInputConstructorValue("txyqrrcs", loader);
                 if(txyqrrcs["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_Viefaucet_code").html())({"txyqrrcs": txyqrrcs["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
