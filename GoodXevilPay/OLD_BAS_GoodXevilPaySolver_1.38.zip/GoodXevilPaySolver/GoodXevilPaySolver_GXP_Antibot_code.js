_call_function(GoodXevilPaySolver_GXP_Antibot,{ "apikey": (<%= ztosyihp %>),"mouse": (<%= hobgzhts %>) })!
