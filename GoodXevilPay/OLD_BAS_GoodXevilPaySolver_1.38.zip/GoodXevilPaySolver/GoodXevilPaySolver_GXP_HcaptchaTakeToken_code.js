_call_function(GoodXevilPaySolver_GXP_HcaptchaTakeToken,{ "APIKEY": (<%= xgkomwto %>),"site_url": (<%= heovndxm %>),"sitekey": (<%= gptjmqfo %>) })!
<%= variable %> = _result_function()
