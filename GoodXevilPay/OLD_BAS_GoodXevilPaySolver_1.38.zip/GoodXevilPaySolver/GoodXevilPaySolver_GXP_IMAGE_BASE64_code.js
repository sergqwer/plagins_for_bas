_call_function(GoodXevilPaySolver_GXP_IMAGE_BASE64,{ "APIKEY": (<%= ajupraet %>),"IMAGE_BASE64": (<%= wzlkqeei %>) })!
<%= variable %> = _result_function()
