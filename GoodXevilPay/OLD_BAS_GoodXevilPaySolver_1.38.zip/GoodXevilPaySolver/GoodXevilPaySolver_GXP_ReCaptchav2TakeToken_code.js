_call_function(GoodXevilPaySolver_GXP_ReCaptchav2TakeToken,{ "APIKEY": (<%= emarmrqk %>),"site_url": (<%= eyiifako %>),"sitekey": (<%= lhgndwoc %>) })!
<%= variable %> = _result_function()
