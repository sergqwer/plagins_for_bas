_call_function(GoodXevilPaySolver_GXP_ReCaptchav2TakeToken,{ "APIKEY": (<%= spzpuwdj %>),"site_url": (<%= vqcvfaky %>),"sitekey": (<%= djmlgtiv %>) })!
<%= variable %> = _result_function()
