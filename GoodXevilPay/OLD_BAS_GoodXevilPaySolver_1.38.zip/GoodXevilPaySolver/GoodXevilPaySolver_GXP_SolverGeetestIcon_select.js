var jcftonhb = GetInputConstructorValue("jcftonhb", loader);
                 if(jcftonhb["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var hgcvnlxk = GetInputConstructorValue("hgcvnlxk", loader);
                 if(hgcvnlxk["original"].length == 0)
                 {
                   Invalid("button_capthca" + " is empty");
                   return;
                 }
var yeaykmhq = GetInputConstructorValue("yeaykmhq", loader);
                 if(yeaykmhq["original"].length == 0)
                 {
                   Invalid("captcha_submit" + " is empty");
                   return;
                 }
var cffyhxur = GetInputConstructorValue("cffyhxur", loader);
                 if(cffyhxur["original"].length == 0)
                 {
                   Invalid("foto_captcha" + " is empty");
                   return;
                 }
var rliyjadj = GetInputConstructorValue("rliyjadj", loader);
                 if(rliyjadj["original"].length == 0)
                 {
                   Invalid("reload_captcha" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SolverGeetestIcon_code").html())({"jcftonhb": jcftonhb["updated"],"hgcvnlxk": hgcvnlxk["updated"],"yeaykmhq": yeaykmhq["updated"],"cffyhxur": cffyhxur["updated"],"rliyjadj": rliyjadj["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
