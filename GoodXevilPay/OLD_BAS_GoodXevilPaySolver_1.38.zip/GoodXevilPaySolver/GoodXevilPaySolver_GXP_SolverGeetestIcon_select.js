var ejfamrqr = GetInputConstructorValue("ejfamrqr", loader);
                 if(ejfamrqr["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var etrqqksb = GetInputConstructorValue("etrqqksb", loader);
                 if(etrqqksb["original"].length == 0)
                 {
                   Invalid("button_capthca" + " is empty");
                   return;
                 }
var ngnuiwqk = GetInputConstructorValue("ngnuiwqk", loader);
                 if(ngnuiwqk["original"].length == 0)
                 {
                   Invalid("captcha_submit" + " is empty");
                   return;
                 }
var iutiohyr = GetInputConstructorValue("iutiohyr", loader);
                 if(iutiohyr["original"].length == 0)
                 {
                   Invalid("foto_captcha" + " is empty");
                   return;
                 }
var zueycygo = GetInputConstructorValue("zueycygo", loader);
                 if(zueycygo["original"].length == 0)
                 {
                   Invalid("reload_captcha" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SolverGeetestIcon_code").html())({"ejfamrqr": ejfamrqr["updated"],"etrqqksb": etrqqksb["updated"],"ngnuiwqk": ngnuiwqk["updated"],"iutiohyr": iutiohyr["updated"],"zueycygo": zueycygo["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
