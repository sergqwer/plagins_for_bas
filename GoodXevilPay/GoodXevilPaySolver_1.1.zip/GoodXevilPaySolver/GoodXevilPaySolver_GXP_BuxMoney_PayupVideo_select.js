var uksoeohw = GetInputConstructorValue("uksoeohw", loader);
                 if(uksoeohw["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var fkfrqazx = GetInputConstructorValue("fkfrqazx", loader);
                 if(fkfrqazx["original"].length == 0)
                 {
                   Invalid("timer" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_BuxMoney_PayupVideo_code").html())({"uksoeohw": uksoeohw["updated"],"fkfrqazx": fkfrqazx["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
