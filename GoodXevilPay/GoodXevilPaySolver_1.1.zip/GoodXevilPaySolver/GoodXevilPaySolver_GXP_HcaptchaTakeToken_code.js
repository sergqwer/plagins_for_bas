_call_function(GoodXevilPaySolver_GXP_HcaptchaTakeToken,{ "APIKEY": (<%= nlfqpjkk %>),"site_url": (<%= hfdycuwl %>),"sitekey": (<%= axupdbud %>) })!
<%= variable %> = _result_function()
