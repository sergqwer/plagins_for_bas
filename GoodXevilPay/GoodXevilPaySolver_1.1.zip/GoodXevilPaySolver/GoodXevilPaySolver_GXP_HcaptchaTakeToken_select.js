var nlfqpjkk = GetInputConstructorValue("nlfqpjkk", loader);
                 if(nlfqpjkk["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var hfdycuwl = GetInputConstructorValue("hfdycuwl", loader);
                 if(hfdycuwl["original"].length == 0)
                 {
                   Invalid("site_url" + " is empty");
                   return;
                 }
var axupdbud = GetInputConstructorValue("axupdbud", loader);
                 if(axupdbud["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_HcaptchaTakeToken_code").html())({"nlfqpjkk": nlfqpjkk["updated"],"hfdycuwl": hfdycuwl["updated"],"axupdbud": axupdbud["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
