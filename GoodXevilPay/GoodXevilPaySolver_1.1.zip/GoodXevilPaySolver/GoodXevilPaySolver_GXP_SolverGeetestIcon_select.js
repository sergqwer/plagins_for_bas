var fxylxffn = GetInputConstructorValue("fxylxffn", loader);
                 if(fxylxffn["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var ornbjvkw = GetInputConstructorValue("ornbjvkw", loader);
                 if(ornbjvkw["original"].length == 0)
                 {
                   Invalid("button_capthca" + " is empty");
                   return;
                 }
var uauonhsi = GetInputConstructorValue("uauonhsi", loader);
                 if(uauonhsi["original"].length == 0)
                 {
                   Invalid("captcha_submit" + " is empty");
                   return;
                 }
var dkhawcva = GetInputConstructorValue("dkhawcva", loader);
                 if(dkhawcva["original"].length == 0)
                 {
                   Invalid("foto_captcha" + " is empty");
                   return;
                 }
var phkusolp = GetInputConstructorValue("phkusolp", loader);
                 if(phkusolp["original"].length == 0)
                 {
                   Invalid("reload_captcha" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SolverGeetestIcon_code").html())({"fxylxffn": fxylxffn["updated"],"ornbjvkw": ornbjvkw["updated"],"uauonhsi": uauonhsi["updated"],"dkhawcva": dkhawcva["updated"],"phkusolp": phkusolp["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
