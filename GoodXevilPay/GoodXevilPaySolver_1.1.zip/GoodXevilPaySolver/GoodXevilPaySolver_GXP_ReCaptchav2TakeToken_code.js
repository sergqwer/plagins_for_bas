_call_function(GoodXevilPaySolver_GXP_ReCaptchav2TakeToken,{ "APIKEY": (<%= xaadeuqe %>),"site_url": (<%= awqqcdqu %>),"sitekey": (<%= htdjeftv %>) })!
<%= variable %> = _result_function()
