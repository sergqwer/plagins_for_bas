var dpbvxdap = GetInputConstructorValue("dpbvxdap", loader);
                 if(dpbvxdap["original"].length == 0)
                 {
                   Invalid("arrow_id" + " is empty");
                   return;
                 }
var rcxgtdgb = GetInputConstructorValue("rcxgtdgb", loader);
                 if(rcxgtdgb["original"].length == 0)
                 {
                   Invalid("avtoupdate" + " is empty");
                   return;
                 }
var tzdvxveh = GetInputConstructorValue("tzdvxveh", loader);
                 if(tzdvxveh["original"].length == 0)
                 {
                   Invalid("button_id" + " is empty");
                   return;
                 }
var djhqupfh = GetInputConstructorValue("djhqupfh", loader);
                 if(djhqupfh["original"].length == 0)
                 {
                   Invalid("coef" + " is empty");
                   return;
                 }
var mebrmqjp = GetInputConstructorValue("mebrmqjp", loader);
                 if(mebrmqjp["original"].length == 0)
                 {
                   Invalid("image id" + " is empty");
                   return;
                 }
var wbkmwvyp = GetInputConstructorValue("wbkmwvyp", loader);
                 if(wbkmwvyp["original"].length == 0)
                 {
                   Invalid("key" + " is empty");
                   return;
                 }
var ryoyugqm = GetInputConstructorValue("ryoyugqm", loader);
                 if(ryoyugqm["original"].length == 0)
                 {
                   Invalid("pixel_koef" + " is empty");
                   return;
                 }
var mzhkoyta = GetInputConstructorValue("mzhkoyta", loader);
                 if(mzhkoyta["original"].length == 0)
                 {
                   Invalid("reload_id" + " is empty");
                   return;
                 }
var ogtdgmmp = GetInputConstructorValue("ogtdgmmp", loader);
                 if(ogtdgmmp["original"].length == 0)
                 {
                   Invalid("speed" + " is empty");
                   return;
                 }
var redxvoua = GetInputConstructorValue("redxvoua", loader);
                 if(redxvoua["original"].length == 0)
                 {
                   Invalid("type_slide" + " is empty");
                   return;
                 }
var fnptxsfu = GetInputConstructorValue("fnptxsfu", loader);
                 if(fnptxsfu["original"].length == 0)
                 {
                   Invalid("type_swipe" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SliderSolver_code").html())({"dpbvxdap": dpbvxdap["updated"],"rcxgtdgb": rcxgtdgb["updated"],"tzdvxveh": tzdvxveh["updated"],"djhqupfh": djhqupfh["updated"],"mebrmqjp": mebrmqjp["updated"],"wbkmwvyp": wbkmwvyp["updated"],"ryoyugqm": ryoyugqm["updated"],"mzhkoyta": mzhkoyta["updated"],"ogtdgmmp": ogtdgmmp["updated"],"redxvoua": redxvoua["updated"],"fnptxsfu": fnptxsfu["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
