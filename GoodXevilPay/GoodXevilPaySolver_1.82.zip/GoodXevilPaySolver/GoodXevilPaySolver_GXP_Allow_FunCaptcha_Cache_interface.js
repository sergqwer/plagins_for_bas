<div class="container-fluid">
</div>
<div class="tooltipinternal">
<div class="tr tooltip-paragraph-first-fold">Разрешает кеш для решения FunCaptcha. Вызывать до загрузки страницы с капчей, можно в начале скрипта, настройки сбрасываются при переключении вкладок</div>
<div class="tr tooltip-paragraph-last-fold">Enables cache to resolve FunCaptcha. Call before loading page with captcha, can be at the beginning of the script, settings are reset when switching tabs</div>
</div>
<%= _.template($('#back').html())({action:"executeandadd", visible:true}) %>
