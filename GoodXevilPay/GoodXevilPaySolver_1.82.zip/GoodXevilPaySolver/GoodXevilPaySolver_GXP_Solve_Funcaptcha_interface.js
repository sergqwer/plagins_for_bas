<div class="container-fluid">
<%= _.template($('#input_constructor').html())({id:"gbkorcpt", description:"APIKey", default_selector: "string", disable_int:true, value_string: "", help: {description: "apikey с сервиса https://t.me/Xevil_check_bot\n\napikey from https://t.me/Xevil_check_bot"} }) %>
<%= _.template($('#input_constructor').html())({id:"bpgluykd", description:"CaptchaNumber", default_selector: "int", disable_string:true, value_number: 0, min_number:-999999, max_number:999999, help: {description: "Номер капчи на странице\n\nCaptcha number on the page"} }) %>
<%= _.template($('#input_constructor').html())({id:"asxcbdgv", description:"CaptchaSelector", default_selector: "string", disable_int:true, value_string: ">CSS> iframe[id$='Frame'] >FRAME> >CSS> iframe>FRAME> >CSS> #game-core-frame>FRAME> >CSS> button[data-theme*='verifyButton']", help: {description: "Селектор hCaptcha\n\nThe hCaptcha selector"} }) %>
<%= _.template($('#input_constructor').html())({id:"zhobyzlr", description:"MaxLimitTask", default_selector: "int", disable_string:true, value_number: 20, min_number:-999999, max_number:999999, help: {description: "Количество попыток решения капчи\n\nNumber of attempts to solve captcha"} }) %>
</div>
<div class="tooltipinternal">
<div class="tr tooltip-paragraph-first-fold">Решает кликами FunCaptcha через сервис https://t.me/Xevil_check_bot, оплачивается каждое изображение</div>
<div class="tr tooltip-paragraph-last-fold">Resolves by FunCaptcha clicks through the service https://t.me/Xevil_check_bot, paid per image</div>
</div>
<%= _.template($('#back').html())({action:"executeandadd", visible:true}) %>
