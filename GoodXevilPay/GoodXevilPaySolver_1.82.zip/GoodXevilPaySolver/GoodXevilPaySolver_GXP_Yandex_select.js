var nliplsjr = GetInputConstructorValue("nliplsjr", loader);
                 if(nliplsjr["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var zoshbbcq = GetInputConstructorValue("zoshbbcq", loader);
                 if(zoshbbcq["original"].length == 0)
                 {
                   Invalid("CaptchaSelector" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_Yandex_code").html())({"nliplsjr": nliplsjr["updated"],"zoshbbcq": zoshbbcq["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
