var sivlieko = GetInputConstructorValue("sivlieko", loader);
                 if(sivlieko["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var orkdslvn = GetInputConstructorValue("orkdslvn", loader);
                 if(orkdslvn["original"].length == 0)
                 {
                   Invalid("enterprise" + " is empty");
                   return;
                 }
var nwkuibzy = GetInputConstructorValue("nwkuibzy", loader);
                 if(nwkuibzy["original"].length == 0)
                 {
                   Invalid("index" + " is empty");
                   return;
                 }
var jtndartf = GetInputConstructorValue("jtndartf", loader);
                 if(jtndartf["original"].length == 0)
                 {
                   Invalid("invisible" + " is empty");
                   return;
                 }
var dlrkihkk = GetInputConstructorValue("dlrkihkk", loader);
                 if(dlrkihkk["original"].length == 0)
                 {
                   Invalid("recaptchaframe" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_ReCaptcha_Bypass_No_Exten_code").html())({"sivlieko": sivlieko["updated"],"orkdslvn": orkdslvn["updated"],"nwkuibzy": nwkuibzy["updated"],"jtndartf": jtndartf["updated"],"dlrkihkk": dlrkihkk["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
