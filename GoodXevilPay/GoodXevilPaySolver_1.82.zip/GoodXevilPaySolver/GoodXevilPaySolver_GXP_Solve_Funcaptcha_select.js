var gbkorcpt = GetInputConstructorValue("gbkorcpt", loader);
                 if(gbkorcpt["original"].length == 0)
                 {
                   Invalid("APIKey" + " is empty");
                   return;
                 }
var bpgluykd = GetInputConstructorValue("bpgluykd", loader);
                 if(bpgluykd["original"].length == 0)
                 {
                   Invalid("CaptchaNumber" + " is empty");
                   return;
                 }
var asxcbdgv = GetInputConstructorValue("asxcbdgv", loader);
                 if(asxcbdgv["original"].length == 0)
                 {
                   Invalid("CaptchaSelector" + " is empty");
                   return;
                 }
var zhobyzlr = GetInputConstructorValue("zhobyzlr", loader);
                 if(zhobyzlr["original"].length == 0)
                 {
                   Invalid("MaxLimitTask" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_Solve_Funcaptcha_code").html())({"gbkorcpt": gbkorcpt["updated"],"bpgluykd": bpgluykd["updated"],"asxcbdgv": asxcbdgv["updated"],"zhobyzlr": zhobyzlr["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
