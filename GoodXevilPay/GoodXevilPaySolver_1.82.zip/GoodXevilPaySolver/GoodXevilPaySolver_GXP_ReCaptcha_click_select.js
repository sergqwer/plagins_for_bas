var xicakktf = GetInputConstructorValue("xicakktf", loader);
                 if(xicakktf["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var ghdffsmd = GetInputConstructorValue("ghdffsmd", loader);
                 if(ghdffsmd["original"].length == 0)
                 {
                   Invalid("CaptchaSelector" + " is empty");
                   return;
                 }
var iscvlzua = GetInputConstructorValue("iscvlzua", loader);
                 if(iscvlzua["original"].length == 0)
                 {
                   Invalid("InvisibleCaptcha" + " is empty");
                   return;
                 }
var liangrvj = GetInputConstructorValue("liangrvj", loader);
                 if(liangrvj["original"].length == 0)
                 {
                   Invalid("TrySolve" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_ReCaptcha_click_code").html())({"xicakktf": xicakktf["updated"],"ghdffsmd": ghdffsmd["updated"],"iscvlzua": iscvlzua["updated"],"liangrvj": liangrvj["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
