_call_function(GoodXevilPaySolver_GXP_HcaptchaTakeToken,{ "APIKEY": (<%= zgjytvzr %>),"site_url": (<%= nlxcefns %>),"sitekey": (<%= zlhczayx %>) })!
<%= variable %> = _result_function()
