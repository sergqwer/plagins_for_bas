_call_function(GoodXevilPaySolver_GXP_ReCaptchav2TakeToken,{ "APIKEY": (<%= scyjtgpq %>),"site_url": (<%= nmihecrv %>),"sitekey": (<%= nozggdcx %>) })!
<%= variable %> = _result_function()
