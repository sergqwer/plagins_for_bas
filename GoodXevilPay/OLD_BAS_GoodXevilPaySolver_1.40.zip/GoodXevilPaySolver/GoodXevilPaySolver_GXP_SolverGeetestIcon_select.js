var vexuckij = GetInputConstructorValue("vexuckij", loader);
                 if(vexuckij["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var zhtfizew = GetInputConstructorValue("zhtfizew", loader);
                 if(zhtfizew["original"].length == 0)
                 {
                   Invalid("button_capthca" + " is empty");
                   return;
                 }
var tyzjwarw = GetInputConstructorValue("tyzjwarw", loader);
                 if(tyzjwarw["original"].length == 0)
                 {
                   Invalid("captcha_submit" + " is empty");
                   return;
                 }
var tpjtxwjx = GetInputConstructorValue("tpjtxwjx", loader);
                 if(tpjtxwjx["original"].length == 0)
                 {
                   Invalid("foto_captcha" + " is empty");
                   return;
                 }
var cnsauymp = GetInputConstructorValue("cnsauymp", loader);
                 if(cnsauymp["original"].length == 0)
                 {
                   Invalid("reload_captcha" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SolverGeetestIcon_code").html())({"vexuckij": vexuckij["updated"],"zhtfizew": zhtfizew["updated"],"tyzjwarw": tyzjwarw["updated"],"tpjtxwjx": tpjtxwjx["updated"],"cnsauymp": cnsauymp["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
