var igusqapl = GetInputConstructorValue("igusqapl", loader);
                 if(igusqapl["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var tvtddrkh = GetInputConstructorValue("tvtddrkh", loader);
                 if(tvtddrkh["original"].length == 0)
                 {
                   Invalid("timer" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_BuxMoney_PayupVideo_code").html())({"igusqapl": igusqapl["updated"],"tvtddrkh": tvtddrkh["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
