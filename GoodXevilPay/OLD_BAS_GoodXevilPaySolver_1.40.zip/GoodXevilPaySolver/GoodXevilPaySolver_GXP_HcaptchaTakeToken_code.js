_call_function(GoodXevilPaySolver_GXP_HcaptchaTakeToken,{ "APIKEY": (<%= eckugroo %>),"site_url": (<%= nhehnpfq %>),"sitekey": (<%= lihmtamy %>) })!
<%= variable %> = _result_function()
