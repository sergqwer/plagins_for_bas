var kpigsqio = GetInputConstructorValue("kpigsqio", loader);
                 if(kpigsqio["original"].length == 0)
                 {
                   Invalid("arrow_id" + " is empty");
                   return;
                 }
var fagljjxb = GetInputConstructorValue("fagljjxb", loader);
                 if(fagljjxb["original"].length == 0)
                 {
                   Invalid("avtoupdate" + " is empty");
                   return;
                 }
var lbmochfh = GetInputConstructorValue("lbmochfh", loader);
                 if(lbmochfh["original"].length == 0)
                 {
                   Invalid("button_id" + " is empty");
                   return;
                 }
var wvzrtwuh = GetInputConstructorValue("wvzrtwuh", loader);
                 if(wvzrtwuh["original"].length == 0)
                 {
                   Invalid("coef" + " is empty");
                   return;
                 }
var eavujxqd = GetInputConstructorValue("eavujxqd", loader);
                 if(eavujxqd["original"].length == 0)
                 {
                   Invalid("image id" + " is empty");
                   return;
                 }
var bwhlzjba = GetInputConstructorValue("bwhlzjba", loader);
                 if(bwhlzjba["original"].length == 0)
                 {
                   Invalid("key" + " is empty");
                   return;
                 }
var cddmzomg = GetInputConstructorValue("cddmzomg", loader);
                 if(cddmzomg["original"].length == 0)
                 {
                   Invalid("pixel_koef" + " is empty");
                   return;
                 }
var rtbwtexn = GetInputConstructorValue("rtbwtexn", loader);
                 if(rtbwtexn["original"].length == 0)
                 {
                   Invalid("reload_id" + " is empty");
                   return;
                 }
var xhwjljjo = GetInputConstructorValue("xhwjljjo", loader);
                 if(xhwjljjo["original"].length == 0)
                 {
                   Invalid("speed" + " is empty");
                   return;
                 }
var opscvyqp = GetInputConstructorValue("opscvyqp", loader);
                 if(opscvyqp["original"].length == 0)
                 {
                   Invalid("type_slide" + " is empty");
                   return;
                 }
var sknegwak = GetInputConstructorValue("sknegwak", loader);
                 if(sknegwak["original"].length == 0)
                 {
                   Invalid("type_swipe" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SliderSolver_code").html())({"kpigsqio": kpigsqio["updated"],"fagljjxb": fagljjxb["updated"],"lbmochfh": lbmochfh["updated"],"wvzrtwuh": wvzrtwuh["updated"],"eavujxqd": eavujxqd["updated"],"bwhlzjba": bwhlzjba["updated"],"cddmzomg": cddmzomg["updated"],"rtbwtexn": rtbwtexn["updated"],"xhwjljjo": xhwjljjo["updated"],"opscvyqp": opscvyqp["updated"],"sknegwak": sknegwak["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
