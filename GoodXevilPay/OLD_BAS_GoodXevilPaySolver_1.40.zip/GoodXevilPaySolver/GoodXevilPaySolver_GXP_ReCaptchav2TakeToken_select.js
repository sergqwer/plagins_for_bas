var uhpewzio = GetInputConstructorValue("uhpewzio", loader);
                 if(uhpewzio["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var fkpvkaaw = GetInputConstructorValue("fkpvkaaw", loader);
                 if(fkpvkaaw["original"].length == 0)
                 {
                   Invalid("site_url" + " is empty");
                   return;
                 }
var pahnvipv = GetInputConstructorValue("pahnvipv", loader);
                 if(pahnvipv["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_ReCaptchav2TakeToken_code").html())({"uhpewzio": uhpewzio["updated"],"fkpvkaaw": fkpvkaaw["updated"],"pahnvipv": pahnvipv["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
