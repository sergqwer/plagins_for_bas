_call_function(GoodXevilPaySolver_GXP_GetBalance,{ "APIKEY": (<%= tvdwwiar %>) })!
<%= variable %> = _result_function()
