var trdnttbt = GetInputConstructorValue("trdnttbt", loader);
                 if(trdnttbt["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var zfjkmhqb = GetInputConstructorValue("zfjkmhqb", loader);
                 if(zfjkmhqb["original"].length == 0)
                 {
                   Invalid("mouse" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_Antibot_code").html())({"trdnttbt": trdnttbt["updated"],"zfjkmhqb": zfjkmhqb["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
