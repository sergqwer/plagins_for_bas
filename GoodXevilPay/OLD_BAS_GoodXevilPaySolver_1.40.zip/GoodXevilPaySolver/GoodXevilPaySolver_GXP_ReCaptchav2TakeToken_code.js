_call_function(GoodXevilPaySolver_GXP_ReCaptchav2TakeToken,{ "APIKEY": (<%= uhpewzio %>),"site_url": (<%= fkpvkaaw %>),"sitekey": (<%= pahnvipv %>) })!
<%= variable %> = _result_function()
