var ndvewsuv = GetInputConstructorValue("ndvewsuv", loader);
                 if(ndvewsuv["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#OLD_GoodXevilPaySolver_GXP_RsCaptchaSolver_code").html())({"ndvewsuv": ndvewsuv["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
