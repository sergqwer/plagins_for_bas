var gylgcasr = GetInputConstructorValue("gylgcasr", loader);
                 if(gylgcasr["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var sgrdpjws = GetInputConstructorValue("sgrdpjws", loader);
                 if(sgrdpjws["original"].length == 0)
                 {
                   Invalid("captcha_submit" + " is empty");
                   return;
                 }
var pgoqxqlx = GetInputConstructorValue("pgoqxqlx", loader);
                 if(pgoqxqlx["original"].length == 0)
                 {
                   Invalid("foto_captcha" + " is empty");
                   return;
                 }
var yoyvwvxv = GetInputConstructorValue("yoyvwvxv", loader);
                 if(yoyvwvxv["original"].length == 0)
                 {
                   Invalid("pixel_coef" + " is empty");
                   return;
                 }
var erytugct = GetInputConstructorValue("erytugct", loader);
                 if(erytugct["original"].length == 0)
                 {
                   Invalid("reload_captcha" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#OLD_GoodXevilPaySolver_GXP_SolverGeetestIcon_code").html())({"gylgcasr": gylgcasr["updated"],"sgrdpjws": sgrdpjws["updated"],"pgoqxqlx": pgoqxqlx["updated"],"yoyvwvxv": yoyvwvxv["updated"],"erytugct": erytugct["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
