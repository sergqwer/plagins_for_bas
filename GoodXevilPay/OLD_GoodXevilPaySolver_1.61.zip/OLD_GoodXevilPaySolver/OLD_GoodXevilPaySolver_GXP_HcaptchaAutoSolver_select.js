var qgjxoupx = GetInputConstructorValue("qgjxoupx", loader);
                 if(qgjxoupx["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#OLD_GoodXevilPaySolver_GXP_HcaptchaAutoSolver_code").html())({"qgjxoupx": qgjxoupx["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
