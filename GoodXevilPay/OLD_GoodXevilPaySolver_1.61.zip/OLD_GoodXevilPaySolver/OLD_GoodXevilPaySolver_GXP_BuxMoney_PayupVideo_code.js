_call_function(OLD_GoodXevilPaySolver_GXP_BuxMoney_PayupVideo,{ "apikey": (<%= hvzliway %>),"timer": (<%= mjarlgsc %>) })!
