var zktzfzxb = GetInputConstructorValue("zktzfzxb", loader);
                 if(zktzfzxb["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var wfocwwwe = GetInputConstructorValue("wfocwwwe", loader);
                 if(wfocwwwe["original"].length == 0)
                 {
                   Invalid("mouse" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#OLD_GoodXevilPaySolver_GXP_Antibot_code").html())({"zktzfzxb": zktzfzxb["updated"],"wfocwwwe": wfocwwwe["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
