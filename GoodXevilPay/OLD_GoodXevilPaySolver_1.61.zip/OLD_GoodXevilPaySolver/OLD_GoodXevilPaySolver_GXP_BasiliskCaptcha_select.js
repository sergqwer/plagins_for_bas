var knukulfw = GetInputConstructorValue("knukulfw", loader);
                 if(knukulfw["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var szpydgrf = GetInputConstructorValue("szpydgrf", loader);
                 if(szpydgrf["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var ointohku = GetInputConstructorValue("ointohku", loader);
                 if(ointohku["original"].length == 0)
                 {
                   Invalid("siteurl" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#OLD_GoodXevilPaySolver_GXP_BasiliskCaptcha_code").html())({"knukulfw": knukulfw["updated"],"szpydgrf": szpydgrf["updated"],"ointohku": ointohku["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
