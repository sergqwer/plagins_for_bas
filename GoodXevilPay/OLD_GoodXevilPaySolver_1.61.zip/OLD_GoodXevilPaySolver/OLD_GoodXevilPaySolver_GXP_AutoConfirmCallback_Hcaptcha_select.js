var ejgyqfyk = GetInputConstructorValue("ejgyqfyk", loader);
                 if(ejgyqfyk["original"].length == 0)
                 {
                   Invalid("token" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#OLD_GoodXevilPaySolver_GXP_AutoConfirmCallback_Hcaptcha_code").html())({"ejgyqfyk": ejgyqfyk["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
