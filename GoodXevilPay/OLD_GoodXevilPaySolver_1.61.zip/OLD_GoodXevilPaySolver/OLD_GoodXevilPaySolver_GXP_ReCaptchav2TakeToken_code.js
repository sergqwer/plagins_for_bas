_call_function(OLD_GoodXevilPaySolver_GXP_ReCaptchav2TakeToken,{ "APIKEY": (<%= lwndidfm %>),"site_url": (<%= ctvcgawb %>),"sitekey": (<%= zdkhsooq %>) })!
<%= variable %> = _result_function()
