_call_function(OLD_GoodXevilPaySolver_GXP_AutoBypassCloudFlare,{ "custom_button": (<%= zjfdzrgg %>),"max_time": (<%= zhgfoelx %>),"whait_element": (<%= wvapupio %>) })!
