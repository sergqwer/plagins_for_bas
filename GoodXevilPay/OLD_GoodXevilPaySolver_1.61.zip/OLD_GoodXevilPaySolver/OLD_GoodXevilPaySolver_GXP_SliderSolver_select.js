var rltqfelz = GetInputConstructorValue("rltqfelz", loader);
                 if(rltqfelz["original"].length == 0)
                 {
                   Invalid("arrow_id" + " is empty");
                   return;
                 }
var rcjaaeok = GetInputConstructorValue("rcjaaeok", loader);
                 if(rcjaaeok["original"].length == 0)
                 {
                   Invalid("avtoupdate" + " is empty");
                   return;
                 }
var prctkddv = GetInputConstructorValue("prctkddv", loader);
                 if(prctkddv["original"].length == 0)
                 {
                   Invalid("button_id" + " is empty");
                   return;
                 }
var lsnqaiii = GetInputConstructorValue("lsnqaiii", loader);
                 if(lsnqaiii["original"].length == 0)
                 {
                   Invalid("coef" + " is empty");
                   return;
                 }
var dfylyavl = GetInputConstructorValue("dfylyavl", loader);
                 if(dfylyavl["original"].length == 0)
                 {
                   Invalid("image id" + " is empty");
                   return;
                 }
var jtiieyyd = GetInputConstructorValue("jtiieyyd", loader);
                 if(jtiieyyd["original"].length == 0)
                 {
                   Invalid("key" + " is empty");
                   return;
                 }
var vgtvfbze = GetInputConstructorValue("vgtvfbze", loader);
                 if(vgtvfbze["original"].length == 0)
                 {
                   Invalid("pixel_koef" + " is empty");
                   return;
                 }
var uyerdcxm = GetInputConstructorValue("uyerdcxm", loader);
                 if(uyerdcxm["original"].length == 0)
                 {
                   Invalid("reload_id" + " is empty");
                   return;
                 }
var dmmvdpuf = GetInputConstructorValue("dmmvdpuf", loader);
                 if(dmmvdpuf["original"].length == 0)
                 {
                   Invalid("speed" + " is empty");
                   return;
                 }
var mjeumwhi = GetInputConstructorValue("mjeumwhi", loader);
                 if(mjeumwhi["original"].length == 0)
                 {
                   Invalid("type_slide" + " is empty");
                   return;
                 }
var hlfzqrbg = GetInputConstructorValue("hlfzqrbg", loader);
                 if(hlfzqrbg["original"].length == 0)
                 {
                   Invalid("type_swipe" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#OLD_GoodXevilPaySolver_GXP_SliderSolver_code").html())({"rltqfelz": rltqfelz["updated"],"rcjaaeok": rcjaaeok["updated"],"prctkddv": prctkddv["updated"],"lsnqaiii": lsnqaiii["updated"],"dfylyavl": dfylyavl["updated"],"jtiieyyd": jtiieyyd["updated"],"vgtvfbze": vgtvfbze["updated"],"uyerdcxm": uyerdcxm["updated"],"dmmvdpuf": dmmvdpuf["updated"],"mjeumwhi": mjeumwhi["updated"],"hlfzqrbg": hlfzqrbg["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
