_call_function(OLD_GoodXevilPaySolver_GXP_HcaptchaTakeToken,{ "APIKEY": (<%= zvfvichp %>),"site_url": (<%= taeswndi %>),"sitekey": (<%= vjawgqla %>) })!
<%= variable %> = _result_function()
