_call_function(OLD_GoodXevilPaySolver_GXP_Namars,{ "apikey": (<%= lwkxzltt %>) })!
<%= variable %> = _result_function()
