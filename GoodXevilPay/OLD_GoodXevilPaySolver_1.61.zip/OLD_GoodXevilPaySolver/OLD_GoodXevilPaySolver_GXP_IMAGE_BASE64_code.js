_call_function(OLD_GoodXevilPaySolver_GXP_IMAGE_BASE64,{ "APIKEY": (<%= raclkxwy %>),"IMAGE_BASE64": (<%= hnhuhsbz %>) })!
<%= variable %> = _result_function()
