var zjfdzrgg = GetInputConstructorValue("zjfdzrgg", loader);
                 if(zjfdzrgg["original"].length == 0)
                 {
                   Invalid("custom_button" + " is empty");
                   return;
                 }
var zhgfoelx = GetInputConstructorValue("zhgfoelx", loader);
                 if(zhgfoelx["original"].length == 0)
                 {
                   Invalid("max_time" + " is empty");
                   return;
                 }
var wvapupio = GetInputConstructorValue("wvapupio", loader);
                 if(wvapupio["original"].length == 0)
                 {
                   Invalid("whait_element" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#OLD_GoodXevilPaySolver_GXP_AutoBypassCloudFlare_code").html())({"zjfdzrgg": zjfdzrgg["updated"],"zhgfoelx": zhgfoelx["updated"],"wvapupio": wvapupio["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
