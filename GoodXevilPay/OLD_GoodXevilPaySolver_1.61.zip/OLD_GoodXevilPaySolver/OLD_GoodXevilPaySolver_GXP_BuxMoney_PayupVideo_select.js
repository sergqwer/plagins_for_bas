var hvzliway = GetInputConstructorValue("hvzliway", loader);
                 if(hvzliway["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var mjarlgsc = GetInputConstructorValue("mjarlgsc", loader);
                 if(mjarlgsc["original"].length == 0)
                 {
                   Invalid("timer" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#OLD_GoodXevilPaySolver_GXP_BuxMoney_PayupVideo_code").html())({"hvzliway": hvzliway["updated"],"mjarlgsc": mjarlgsc["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
