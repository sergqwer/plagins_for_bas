_call_function(OLD_GoodXevilPaySolver_GXP_BasiliskCaptcha,{ "apikey": (<%= knukulfw %>),"sitekey": (<%= szpydgrf %>),"siteurl": (<%= ointohku %>) })!
