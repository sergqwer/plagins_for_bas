<div class="container-fluid">
<%= _.template($('#input_constructor').html())({id:"highpcra", description:"Solve Service", default_selector: "string", variants: ["SCTG", "Multibot"], disable_expression:true, disable_int:true, value_string: "SCTG", help: {description: "<div>Выберите нужный вам сервис для решения капчи</div><div>Choose the service you need to solve captcha</div>"} }) %>
<%= _.template($('#input_constructor').html())({id:"hyzodkwq", description:"ApiKey", default_selector: "string", disable_int:true, value_string: "", help: {description: "<div>apikey с сервиса https://t.me/Xevil_check_bot или https://multibot.in/</div><div>apikey from https://t.me/Xevil_check_bot or https://multibot.in/</div>"} }) %>
<%= _.template($('#input_constructor').html())({id:"pxqyxuli", description:"URL", default_selector: "string", disable_int:true, value_string: "", help: {description: "<div>Полный URL страницы где находится ReCaptcha v2</div><div>Full URL of the page where ReCaptcha v2 is located</div>"} }) %>
<%= _.template($('#input_constructor').html())({id:"uzeowkvg", description:"data-sitekey", default_selector: "string", disable_int:true, value_string: "", help: {description: "<div>Значение параметра data-sitekey ReCaptcha v2</div><div>ReCaptcha v2 data-sitekey parameter value</div>"} }) %>
<%= _.template($('#variable_constructor').html())({id:"Save", description:"Result", default_variable: "RECAPTCHA_TOKEN", help: {description: "Токен ReCaptcha v2\nReCaptcha v2 token"}}) %>
</div>
<div class="tooltipinternal">
<div class="tr tooltip-paragraph-first-fold">Эта функция получает токен ReCaptcha v2 через сервис решения капчи https://t.me/Xevil_check_bot</div>
<div class="tr tooltip-paragraph-first-fold">This feature receives a ReCaptcha v2 token via the captcha solution service https://t.me/Xevil_check_bot</div>
</div>
<%= _.template($('#back').html())({action:"executeandadd", visible:true}) %>
