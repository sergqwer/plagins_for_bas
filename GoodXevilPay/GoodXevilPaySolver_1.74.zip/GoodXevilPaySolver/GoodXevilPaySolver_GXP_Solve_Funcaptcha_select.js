var ybcpieii = GetInputConstructorValue("ybcpieii", loader);
                 if(ybcpieii["original"].length == 0)
                 {
                   Invalid("APIKey" + " is empty");
                   return;
                 }
var lutrhmbn = GetInputConstructorValue("lutrhmbn", loader);
                 if(lutrhmbn["original"].length == 0)
                 {
                   Invalid("CaptchaNumber" + " is empty");
                   return;
                 }
var zorbadls = GetInputConstructorValue("zorbadls", loader);
                 if(zorbadls["original"].length == 0)
                 {
                   Invalid("CaptchaSelector" + " is empty");
                   return;
                 }
var riwvtflv = GetInputConstructorValue("riwvtflv", loader);
                 if(riwvtflv["original"].length == 0)
                 {
                   Invalid("MaxLimitTask" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_Solve_Funcaptcha_code").html())({"ybcpieii": ybcpieii["updated"],"lutrhmbn": lutrhmbn["updated"],"zorbadls": zorbadls["updated"],"riwvtflv": riwvtflv["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
