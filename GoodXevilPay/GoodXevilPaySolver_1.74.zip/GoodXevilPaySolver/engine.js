function GoodXevilPaySolver_GXP_Yandex_TakeToken()
   {
   
      
      
      VAR_APIKEY = _function_argument("apikey")
      

      
      
      VAR_PAGEURL = _function_argument("pageurl")
      

      
      
      VAR_SITEKEY = _function_argument("sitekey")
      

      
      
      var regexp_result = native("regexp", "first", JSON.stringify({text: VAR_APIKEY,regexp:("([0-9A-Za-z\u005c|]\u007b20,50\u007d)").toString()}))
      if(regexp_result.length == 0)
      regexp_result = []
      else
      regexp_result = JSON.parse(regexp_result)
      VAR_ALL_MATCH = regexp_result.pop()
      if(typeof(VAR_ALL_MATCH) == 'undefined' || !VAR_ALL_MATCH)
      VAR_ALL_MATCH = ""
      VAR_LIST_WITH_GROUPS = regexp_result
      VAR_APIKEY = regexp_result[0]
      if(typeof(VAR_APIKEY) == 'undefined' || !VAR_APIKEY)
      VAR_APIKEY = ""
      if(regexp_result.length == 0)
      {
      VAR_APIKEY = VAR_ALL_MATCH
      }
      if(VAR_ALL_MATCH != "" && Array.isArray(VAR_ALL_MATCH))
      VAR_LIST_WITH_GROUPS.unshift(VAR_ALL_MATCH)
      

      
      
      solver_properties_clear("capmonster")
      solver_property("capmonster","serverurl","http://sctg.xyz")
      solver_property("capmonster","key",VAR_APIKEY)
      solver_property("capmonster","method","yandex")
      solver_property("capmonster","pageurl",VAR_PAGEURL)
      solver_property("capmonster","sitekey",VAR_SITEKEY)
      solve_base64_no_fail("capmonster", "")!
      VAR_SAVED_CONTENT = _result();
      

      
      
      _function_return(VAR_SAVED_CONTENT)
      

   }
   

function GoodXevilPaySolver_GXP_GeeTestImages_CacheAllow()
   {
   
      
      
      /*Browser*/
      cache_allow("*/verify?callback=*")!
      

      
      
      /*Browser*/
      cache_allow("*/nine/*")!
      

      
      
      /*Browser*/
      cache_allow("*/nine_prompt/*")!
      

   }
   

function GoodXevilPaySolver_GXP_GeeTestImages()
   {
   
      
      
      /*Browser*/
      cache_allow("*/verify?callback=*")!
      

      
      
      /*Browser*/
      cache_allow("*/nine/*")!
      

      
      
      /*Browser*/
      cache_allow("*/nine_prompt/*")!
      

      
      
      VAR_APIKEY = _function_argument("apikey")
      

      
      
      VAR_IMAGES_BUTTON = _function_argument("images_button")
      

      
      
      VAR_RELOAD_BUTTON = _function_argument("reload_button")
      

      
      
      var regexp_result = native("regexp", "first", JSON.stringify({text: VAR_APIKEY,regexp:("([0-9A-Za-z\u005c|]\u007b20,50\u007d)").toString()}))
      if(regexp_result.length == 0)
      regexp_result = []
      else
      regexp_result = JSON.parse(regexp_result)
      VAR_ALL_MATCH = regexp_result.pop()
      if(typeof(VAR_ALL_MATCH) == 'undefined' || !VAR_ALL_MATCH)
      VAR_ALL_MATCH = ""
      VAR_LIST_WITH_GROUPS = regexp_result
      VAR_APIKEY = regexp_result[0]
      if(typeof(VAR_APIKEY) == 'undefined' || !VAR_APIKEY)
      VAR_APIKEY = ""
      if(regexp_result.length == 0)
      {
      VAR_APIKEY = VAR_ALL_MATCH
      }
      if(VAR_ALL_MATCH != "" && Array.isArray(VAR_ALL_MATCH))
      VAR_LIST_WITH_GROUPS.unshift(VAR_ALL_MATCH)
      

      
      
      _do(function(){
      _set_action_info({ name: "For" });
      VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(0)
      if(VAR_CYCLE_INDEX > parseInt(5))_break();
      
         
         
         _call(function()
         {
         _on_fail(function(){
         VAR_LAST_ERROR = _result()
         VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
         VAR_WAS_ERROR = false
         _break(1,true)
         })
         CYCLES.Current().RemoveLabel("function")
         
            
            
            _set_if_expression("W1tDWUNMRV9JTkRFWF1dICE9IDA=");
            _if(VAR_CYCLE_INDEX != 0,function(){
            
               
               
               /*Browser*/
               cache_data_clear()!
               

               
               
               VAR_BTN_INDEX = 0
               

               
               
               _do(function(){
               _set_action_info({ name: "For" });
               VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(0)
               if(VAR_CYCLE_INDEX > parseInt(15))_break();
               
                  
                  
                  _set_if_expression("W1tDWUNMRV9JTkRFWF1dID49IDE0");
                  _if(VAR_CYCLE_INDEX >= 14,function(){
                  
                     
                     
                     fail((_K==="en" ? "Fail solve captcha" : "Ошибка при решении капчи"));
                     

                  })!
                  

                  
                  
                  /*Browser*/
                  ;_SELECTOR=VAR_RELOAD_BUTTON + "\u003eAT\u003e" + VAR_CYCLE_INDEX;
                  get_element_selector(_SELECTOR, false).nowait().exist()!
                  VAR_IS_EXISTS = _result() == 1
                  _if(VAR_IS_EXISTS, function(){
                  get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
                  VAR_IS_EXISTS = _result().indexOf("true")>=0
                  })!
                  

                  
                  
                  _set_if_expression("W1tJU19FWElTVFNdXQ==");
                  _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
                  
                     
                     
                     VAR_BTN_INDEX = VAR_CYCLE_INDEX
                     

                     
                     
                     _break("function")
                     

                  })!
                  

               })!
               

               
               
               /*Browser*/
               _SELECTOR = VAR_RELOAD_BUTTON + "\u003eAT\u003e" + VAR_BTN_INDEX;waiter_timeout_next(1000)
               waiter_nofail_next();
               wait_element_visible(_SELECTOR)!
               _call(_random_point, {})!
               _if(_result().length > 0, function(){
               move( {} )!
               get_element_selector(_SELECTOR, false).nowait().clarify(X,Y)!
               _call(_clarify, {} )!
               mouse(X,Y)!
               })!
               

            })!
            

            
            
            _set_if_expression("W1tDWUNMRV9JTkRFWF1dID49IDQ=");
            _if(VAR_CYCLE_INDEX >= 4,function(){
            
               
               
               fail((_K==="en" ? "Fail solve captcha" : "Ошибка при решении капчи"));
               

            })!
            

            
            
            /*Browser*/
            waiter_timeout_next(30000)
            wait_load("*/nine_prompt/*")!
            

            
            
            /*Browser*/
            waiter_timeout_next(15000)
            wait_load("*/nine/*")!
            

            
            
            _call(function()
            {
            _on_fail(function(){
            VAR_LAST_ERROR = _result()
            VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
            VAR_WAS_ERROR = false
            _break(1,true)
            })
            CYCLES.Current().RemoveLabel("function")
            
               
               
               /*Browser*/
               waiter_timeout_next(5000)
               wait_async_load()!
               

            },null)!
            

            
            
            /*Browser*/
            wait_load("*/nine/*")!
            cache_get_base64("*/nine/*")!
            VAR_NINE_IMAGES_B64 = _result()
            

            
            
            /*Browser*/
            wait_load("*/nine_prompt/*")!
            cache_get_base64("*/nine_prompt/*")!
            VAR_NINE_TASK_IMAGES_B64 = _result()
            

            
            
            solver_properties_clear("capmonster")
            solver_property("capmonster","serverurl","http://sctg.xyz")
            solver_property("capmonster","key",VAR_APIKEY)
            solver_property("capmonster","method","geetestimages")
            solver_property("capmonster","mainimg",VAR_NINE_IMAGES_B64)
            solver_property("capmonster","task",VAR_NINE_TASK_IMAGES_B64)
            solver_property("capmonster","textinstructions","1")
            solve_base64_no_fail("capmonster", "")!
            VAR_SAVED_CONTENT = _result();
            

            
            
            VAR_STRING_MATCHES = Boolean(native("regexp", "ismatch", JSON.stringify({text: VAR_SAVED_CONTENT,regexp:("(_)").toString()})) == "true")
            

            
            
            _set_if_expression("W1tTVFJJTkdfTUFUQ0hFU11d");
            _if(typeof(VAR_STRING_MATCHES) !== "undefined" ? (VAR_STRING_MATCHES) : undefined,function(){
            
               
               
               _next("function")
               

            })!
            

            
            
            VAR_DATA = VAR_SAVED_CONTENT.split(":")[1].replace(/x/g, "").replace(/=/g, "").replace(/y/g, "").replace(/y/g, "").split(";")
            

            
            
            /*Browser*/
            scroll(1,1)!
            

            
            
            VAR_BTN_INDEX = 0
            

            
            
            _do(function(){
            _set_action_info({ name: "For" });
            VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(0)
            if(VAR_CYCLE_INDEX > parseInt(15))_break();
            
               
               
               _set_if_expression("W1tDWUNMRV9JTkRFWF1dID49IDE0");
               _if(VAR_CYCLE_INDEX >= 14,function(){
               
                  
                  
                  fail((_K==="en" ? "Fail solve captcha" : "Ошибка при решении капчи"));
                  

               })!
               

               
               
               /*Browser*/
               ;_SELECTOR=VAR_IMAGES_BUTTON + "\u003eAT\u003e" + VAR_CYCLE_INDEX;
               get_element_selector(_SELECTOR, false).nowait().exist()!
               VAR_IS_EXISTS = _result() == 1
               _if(VAR_IS_EXISTS, function(){
               get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
               VAR_IS_EXISTS = _result().indexOf("true")>=0
               })!
               

               
               
               _set_if_expression("W1tJU19FWElTVFNdXQ==");
               _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
               
                  
                  
                  VAR_BTN_INDEX = VAR_CYCLE_INDEX
                  

                  
                  
                  _break("function")
                  

               })!
               

            })!
            

            
            
            /*Browser*/
            _SELECTOR = VAR_IMAGES_BUTTON + "\u003eAT\u003e" + VAR_BTN_INDEX;
            wait_element(_SELECTOR)!
            get_element_selector(_SELECTOR, false).script("(function(){var rect = _BAS_HIDE(BrowserAutomationStudio_GetBoundingClientRect)(self);return (rect.left + positionx) + '|' + (rect.top + positiony) + '|' + (rect.right - rect.left) + '|' + (rect.bottom - rect.top) + '|' + (rect.left + positionx + scrollx) + '|' + (rect.top + positiony + scrolly)})();")!
            if(_result().length > 0)
            {
            var split = _result().split("|")
            VAR_X = parseInt(split[0])
            VAR_Y = parseInt(split[1])
            VAR_WIDTH = parseInt(split[2])
            VAR_HEIGHT = parseInt(split[3])
            VAR_ABSOLUTE_X = parseInt(split[4])
            VAR_ABSOLUTE_Y = parseInt(split[5])
            }
            

            
            
            _do_with_params({"foreach_data":(VAR_DATA)},function(){
            _set_action_info({ name: "Foreach" });
            VAR_CYCLE_INDEX = _iterator() - 1
            if(VAR_CYCLE_INDEX > _cycle_param("foreach_data").length - 1)_break();
            VAR_FOREACH_DATA = _cycle_param("foreach_data")[VAR_CYCLE_INDEX]
            
               
               
               VAR_X_TMP = parseInt(VAR_FOREACH_DATA.split(",")[0]);
               VAR_Y_TMP = parseInt(VAR_FOREACH_DATA.split(",")[1]);
               

               
               
               VAR_RANDOM_NUMBER = Math.floor(Math.random() * (parseInt(300) - parseInt(100) + 1)) + parseInt(100)
               

               
               
               sleep(VAR_RANDOM_NUMBER)!
               

               
               
               /*Browser*/
               move(VAR_X + VAR_X_TMP,VAR_Y + VAR_Y_TMP,  {} )!
               mouse(VAR_X + VAR_X_TMP,VAR_Y + VAR_Y_TMP)!
               

            })!
            

            
            
            /*Browser*/
            waiter_timeout_next(15000)
            wait_load("*/verify?callback=*")!
            

            
            
            /*Browser*/
            wait_load("*/verify?callback=*")!
            cache_get_string("*/verify?callback=*")!
            VAR_RESULT_SOLVE = _result()
            

            
            
            VAR_STRING_MATCHES = Boolean(native("regexp", "ismatch", JSON.stringify({text: VAR_RESULT_SOLVE,regexp:("(\u0022result\u0022:\u0022fail\u0022)").toString()})) == "true")
            

            
            
            _set_if_expression("W1tTVFJJTkdfTUFUQ0hFU11dID09IGZhbHNl");
            _if(VAR_STRING_MATCHES == false,function(){
            
               
               
               _break("function")
               

            })!
            

         },null)!
         

      })!
      

   }
   

function GoodXevilPaySolver_GXP_Yandex()
   {
   
      
      
      VAR_CAPTCHASELECTOR = _function_argument("CaptchaSelector")
      

      
      
      VAR_APIKEY = _function_argument("apikey")
      

      
      
      var regexp_result = native("regexp", "first", JSON.stringify({text: VAR_APIKEY,regexp:("([0-9A-Za-z\u005c|]\u007b20,50\u007d)").toString()}))
      if(regexp_result.length == 0)
      regexp_result = []
      else
      regexp_result = JSON.parse(regexp_result)
      VAR_ALL_MATCH = regexp_result.pop()
      if(typeof(VAR_ALL_MATCH) == 'undefined' || !VAR_ALL_MATCH)
      VAR_ALL_MATCH = ""
      VAR_LIST_WITH_GROUPS = regexp_result
      VAR_APIKEY = regexp_result[0]
      if(typeof(VAR_APIKEY) == 'undefined' || !VAR_APIKEY)
      VAR_APIKEY = ""
      if(regexp_result.length == 0)
      {
      VAR_APIKEY = VAR_ALL_MATCH
      }
      if(VAR_ALL_MATCH != "" && Array.isArray(VAR_ALL_MATCH))
      VAR_LIST_WITH_GROUPS.unshift(VAR_ALL_MATCH)
      

      
      
      _set_if_expression("W1tDQVBUQ0hBU0VMRUNUT1JdXSAhPSAib2ZmIg==");
      _if(VAR_CAPTCHASELECTOR != "off",function(){
      
         
         
         _do(function(){
         _set_action_info({ name: "While" });
         VAR_CYCLE_INDEX = _iterator() - 1
         BREAK_CONDITION = true;
         if(!BREAK_CONDITION)_break();
         
            
            
            _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gNjA=");
            _if(VAR_CYCLE_INDEX > 60,function(){
            
               
               
               fail((_K==="en" ? "Captcha was not found" : "Капча не найдена"));
               

            })!
            

            
            
            sleep(1000)!
            

            
            
            /*Browser*/
            ;_SELECTOR=VAR_CAPTCHASELECTOR;
            get_element_selector(_SELECTOR, false).nowait().exist()!
            VAR_IS_EXISTS = _result() == 1
            _if(VAR_IS_EXISTS, function(){
            get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
            VAR_IS_EXISTS = _result().indexOf("true")>=0
            })!
            

            
            
            _set_if_expression("W1tJU19FWElTVFNdXQ==");
            _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
            
               
               
               _break("function")
               

            })!
            

         })!
         

         
         
         /*Browser*/
         _SELECTOR = VAR_CAPTCHASELECTOR;
         wait_element_visible(_SELECTOR)!
         _call(_random_point, {})!
         _if(_result().length > 0, function(){
         move( {} )!
         get_element_selector(_SELECTOR, false).clarify(X,Y)!
         _call(_clarify, {} )!
         mouse(X,Y)!
         })!
         

      })!
      

      
      
      VAR_CLEAN_FRAME_IMAGE = " \u003eCSS\u003e .SmartCaptcha-Overlay \u003e iframe\u003eFRAME\u003e \u003eCSS\u003e .Captcha-ModalContent"
      

      
      
      VAR_ALL_GOOD = false
      

      
      
      _do(function(){
      _set_action_info({ name: "For" });
      VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(0)
      if(VAR_CYCLE_INDEX > parseInt(5))_break();
      
         
         
         _set_if_expression("W1tDWUNMRV9JTkRFWF1dID49IDQ=");
         _if(VAR_CYCLE_INDEX >= 4,function(){
         
            
            
            fail((_K==="en" ? "Captcha not solved" : "Капча не решена"));
            

         })!
         

         
         
         _do(function(){
         _set_action_info({ name: "While" });
         VAR_CYCLE_INDEX = _iterator() - 1
         BREAK_CONDITION = true;
         if(!BREAK_CONDITION)_break();
         
            
            
            _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gMyAmJiBbW0FMTF9HT09EXV0=");
            _if(VAR_CYCLE_INDEX > 3 && VAR_ALL_GOOD,function(){
            
               
               
               _function_return("")
               

            })!
            

            
            
            _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gNjA=");
            _if(VAR_CYCLE_INDEX > 60,function(){
            
               
               
               fail((_K==="en" ? "Captcha was not found" : "Капча не найдена"));
               

            })!
            

            
            
            sleep(1000)!
            

            
            
            /*Browser*/
            ;_SELECTOR=VAR_CLEAN_FRAME_IMAGE;
            get_element_selector(_SELECTOR, false).nowait().exist()!
            VAR_IS_EXISTS = _result() == 1
            _if(VAR_IS_EXISTS, function(){
            get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
            VAR_IS_EXISTS = _result().indexOf("true")>=0
            })!
            

            
            
            _set_if_expression("W1tJU19FWElTVFNdXQ==");
            _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
            
               
               
               /*Browser*/
               _SELECTOR = VAR_CLEAN_FRAME_IMAGE;
               wait_element(_SELECTOR)!
               get_element_selector(_SELECTOR, false).script("(function(){var rect = _BAS_HIDE(BrowserAutomationStudio_GetBoundingClientRect)(self);return (rect.left + positionx) + '|' + (rect.top + positiony) + '|' + (rect.right - rect.left) + '|' + (rect.bottom - rect.top) + '|' + (rect.left + positionx + scrollx) + '|' + (rect.top + positiony + scrolly)})();")!
               if(_result().length > 0)
               {
               var split = _result().split("|")
               VAR_RELATIVE_X = parseInt(split[0])
               VAR_RELATIVE_Y = parseInt(split[1])
               VAR_WIDTH = parseInt(split[2])
               VAR_HEIGHT = parseInt(split[3])
               VAR_ABSOLUTE_X = parseInt(split[4])
               VAR_ABSOLUTE_Y = parseInt(split[5])
               }
               

               
               
               _set_if_expression("W1tBQlNPTFVURV9YXV0gPiAw");
               _if(VAR_ABSOLUTE_X > 0,function(){
               
                  
                  
                  _break("function")
                  

               })!
               

            })!
            

         })!
         

         
         
         _set_if_expression("W1tDWUNMRV9JTkRFWF1dICE9IDA=");
         _if(VAR_CYCLE_INDEX != 0,function(){
         
            
            
            /*Browser*/
            _SELECTOR = " \u003eCSS\u003e .SmartCaptcha-Overlay \u003e iframe\u003eFRAME\u003e \u003eCSS\u003e .AdvancedCaptcha-FormActions \u003e :nth-child(1) \u003e svg \u003e path";
            wait_element_visible(_SELECTOR)!
            _call(_random_point, {})!
            _if(_result().length > 0, function(){
            move( {} )!
            get_element_selector(_SELECTOR, false).clarify(X,Y)!
            _call(_clarify, {} )!
            mouse(X,Y)!
            })!
            

            
            
            _call(function()
            {
            _on_fail(function(){
            VAR_LAST_ERROR = _result()
            VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
            VAR_WAS_ERROR = false
            _break(1,true)
            })
            CYCLES.Current().RemoveLabel("function")
            
               
               
               /*Browser*/
               waiter_timeout_next(5000)
               wait_async_load()!
               

            },null)!
            

         })!
         

         
         
         /*Browser*/
         ;_SELECTOR=" \u003eCSS\u003e #captcha-alert";
         get_element_selector(_SELECTOR, false).nowait().exist()!
         VAR_IS_EXISTS = _result() == 1
         _if(VAR_IS_EXISTS, function(){
         get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
         VAR_IS_EXISTS = _result().indexOf("true")>=0
         })!
         

         
         
         _set_if_expression("W1tJU19FWElTVFNdXQ==");
         _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
         
            
            
            fail((_K==="en" ? "Website error" : "Ошибка на сайте"));
            

         })!
         

         
         
         /*Browser*/
         scroll(1,1)!
         

         
         
         /*Browser*/
         _SELECTOR = VAR_CLEAN_FRAME_IMAGE;
         wait_element(_SELECTOR)!
         get_element_selector(_SELECTOR, false).exist()!
         _if(_result() == "1", function(){
         get_element_selector(_SELECTOR, false).render_base64()!
         VAR_SCREENSHOT_BASE64 = _result()
         })!
         

         
         
         /*Browser*/
         _SELECTOR = VAR_CLEAN_FRAME_IMAGE;
         wait_element(_SELECTOR)!
         get_element_selector(_SELECTOR, false).script("(function(){var rect = _BAS_HIDE(BrowserAutomationStudio_GetBoundingClientRect)(self);return (rect.left + positionx) + '|' + (rect.top + positiony) + '|' + (rect.right - rect.left) + '|' + (rect.bottom - rect.top) + '|' + (rect.left + positionx + scrollx) + '|' + (rect.top + positiony + scrolly)})();")!
         if(_result().length > 0)
         {
         var split = _result().split("|")
         VAR_X = parseInt(split[0])
         VAR_Y = parseInt(split[1])
         VAR_WIDTH = parseInt(split[2])
         VAR_HEIGHT = parseInt(split[3])
         VAR_ABSOLUTE_X = parseInt(split[4])
         VAR_ABSOLUTE_Y = parseInt(split[5])
         }
         

         
         
         _call(function()
         {
         _on_fail(function(){
         VAR_LAST_ERROR = _result()
         VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
         VAR_WAS_ERROR = false
         _break(1,true)
         })
         CYCLES.Current().RemoveLabel("function")
         
            
            
            solver_properties_clear("capmonster")
            solver_property("capmonster","serverurl","http://sctg.xyz/")
            solver_property("capmonster","key",VAR_APIKEY)
            solver_property("capmonster","method","yandeximg")
            solver_property("capmonster","body",VAR_SCREENSHOT_BASE64)
            solve_base64_no_fail("capmonster", "")!
            VAR_SAVED_CONTENT = _result();
            

            
            
            VAR_STRING_MATCHES = Boolean(native("regexp", "ismatch", JSON.stringify({text: VAR_SAVED_CONTENT,regexp:("(ERROR)").toString()})) == "true")
            

            
            
            VAR_STRING_MATCHES2 = Boolean(native("regexp", "ismatch", JSON.stringify({text: VAR_SAVED_CONTENT,regexp:("(_FAIL)").toString()})) == "true")
            

            
            
            VAR_STRING_MATCHES3 = Boolean(native("regexp", "ismatch", JSON.stringify({text: VAR_SAVED_CONTENT,regexp:("(_)").toString()})) == "true")
            

            
            
            _set_if_expression("W1tTVFJJTkdfTUFUQ0hFU11dIHx8IFtbU1RSSU5HX01BVENIRVMyXV0gfHwgW1tTVFJJTkdfTUFUQ0hFUzNdXQ==");
            _if(VAR_STRING_MATCHES || VAR_STRING_MATCHES2 || VAR_STRING_MATCHES3,function(){
            
               
               
               _next("function")
               

            })!
            

            
            
            VAR_PARSED_LIST = (VAR_SAVED_CONTENT).split(";")
            

            
            
            VAR_LIST_LENGTH = (VAR_PARSED_LIST).length
            

            
            
            _set_if_expression("W1tMSVNUX0xFTkdUSF1dIDwgMQ==");
            _if(VAR_LIST_LENGTH < 1,function(){
            
               
               
               fail((_K==="en" ? "Unclear response from the server: " + VAR_SAVED_CONTENT : "Не понятный ответ от сервера: " + VAR_SAVED_CONTENT));
               

            })!
            

            
            
            /*Browser*/
            scroll(1,1)!
            

            
            
            _do_with_params({"foreach_data":(VAR_PARSED_LIST)},function(){
            _set_action_info({ name: "Foreach" });
            VAR_CYCLE_INDEX = _iterator() - 1
            if(VAR_CYCLE_INDEX > _cycle_param("foreach_data").length - 1)_break();
            VAR_FOREACH_DATA = _cycle_param("foreach_data")[VAR_CYCLE_INDEX]
            
               
               
               VAR_SCAN_RESULT_LIST = native("regexp", "scan", JSON.stringify({text: VAR_FOREACH_DATA,regexp:("\u005cd+").toString()}))
               if(VAR_SCAN_RESULT_LIST.length == 0)
               VAR_SCAN_RESULT_LIST = []
               else
               VAR_SCAN_RESULT_LIST = JSON.parse(VAR_SCAN_RESULT_LIST)
               

               
               
               VAR_LIST_LENGTH = (VAR_SCAN_RESULT_LIST).length
               

               
               
               _set_if_expression("W1tMSVNUX0xFTkdUSF1dICE9IDI=");
               _if(VAR_LIST_LENGTH != 2,function(){
               
                  
                  
                  fail((_K==="en" ? "Unclear response from the server" : "Не понятный ответ от сервера"));
                  

               })!
               

               
               
               VAR_X_XEVIL = parseInt(VAR_SCAN_RESULT_LIST[0]);
               VAR_Y_XEVIL = parseInt(VAR_SCAN_RESULT_LIST[1]);
               

               
               
               /*Browser*/
               move(VAR_X + VAR_X_XEVIL,VAR_Y + VAR_Y_XEVIL,  {} )!
               mouse(VAR_X + VAR_X_XEVIL,VAR_Y + VAR_Y_XEVIL)!
               

            })!
            

            
            
            /*Browser*/
            _SELECTOR = " \u003eCSS\u003e .SmartCaptcha-Overlay \u003e iframe\u003eFRAME\u003e \u003eCSS\u003e .CaptchaButton-ProgressWrapper";
            wait_element_visible(_SELECTOR)!
            _call(_random_point, {})!
            _if(_result().length > 0, function(){
            move( {} )!
            get_element_selector(_SELECTOR, false).clarify(X,Y)!
            _call(_clarify, {} )!
            mouse(X,Y)!
            })!
            

            
            
            VAR_ALL_GOOD = true
            

         },null)!
         

      })!
      

      
      
      _load("https://www.coinw.com/front/register?redirectUrl=%2F", "", true)!
      

   }
   

function GoodXevilPaySolver_GXP_TurnstileToken()
   {
   
      
      
      VAR_APIKEY = _function_argument("APIKEY")
      

      
      
      VAR_SITE_URL = _function_argument("site_url")
      

      
      
      VAR_SITEKEY = _function_argument("sitekey")
      

      
      
      var regexp_result = native("regexp", "first", JSON.stringify({text: VAR_APIKEY,regexp:("([0-9A-Za-z\u005c|]\u007b20,50\u007d)").toString()}))
      if(regexp_result.length == 0)
      regexp_result = []
      else
      regexp_result = JSON.parse(regexp_result)
      VAR_ALL_MATCH = regexp_result.pop()
      if(typeof(VAR_ALL_MATCH) == 'undefined' || !VAR_ALL_MATCH)
      VAR_ALL_MATCH = ""
      VAR_LIST_WITH_GROUPS = regexp_result
      VAR_APIKEY = regexp_result[0]
      if(typeof(VAR_APIKEY) == 'undefined' || !VAR_APIKEY)
      VAR_APIKEY = ""
      if(regexp_result.length == 0)
      {
      VAR_APIKEY = VAR_ALL_MATCH
      }
      if(VAR_ALL_MATCH != "" && Array.isArray(VAR_ALL_MATCH))
      VAR_LIST_WITH_GROUPS.unshift(VAR_ALL_MATCH)
      

      
      
      solver_properties_clear("capmonster")
      solver_property("capmonster","serverurl","http://sctg.xyz")
      solver_property("capmonster","key",VAR_APIKEY)
      solver_property("capmonster","method","turnstile")
      solver_property("capmonster","pageurl",VAR_SITE_URL)
      solver_property("capmonster","sitekey",VAR_SITEKEY)
      solve_base64_no_fail("capmonster", "")!
      VAR_SAVED_CONTENT = _result();
      

      
      
      _function_return(VAR_SAVED_CONTENT)
      

   }
   

function GoodXevilPaySolver_GXP_ReCaptcha_CacheAllow()
   {
   
      
      
      /*Browser*/
      cache_allow("recaptcha/*/payload")!
      

   }
   

function GoodXevilPaySolver_GXP_ReCaptcha_click()
   {
   
      
      
      VAR_GLOBAL_SELECTOR = _function_argument("CaptchaSelector")
      

      
      
      VAR_KEY_MODULE = _function_argument("apikey")
      

      
      
      VAR_TRY_NUMBER = _function_argument("TrySolve")
      

      
      
      VAR_IS_INVISIBLE_CAPTCHA = _function_argument("InvisibleCaptcha")
      

      
      
	/*Browser*/
	cache_allow("recaptcha/*/payload")!




	VAR_NUMBER_CAPTCHA_MODULE = 0




	VAR_CYCLE_INDEX = 0




	VAR_IS_EXISTS_1 = "false"




	VAR_IS_EXISTS_2 = "false"




	VAR_ERROR_LOAD = "0"




	VAR_ERROR_RECAPTCHA_PAYLOAD = 0




	VAR_ERROR_FIND_MAIN_SELECTOR = "0"




	VAR_RECAPTCHA_2_INVISIBLE = 0




	VAR_RECAPTCHA_PREFIX_SECOND_FRAME = ""




	VAR_RECAPTCHA_PREFIX_SECOND_FRAME_ELEMENT = ""




	VAR_ERROR_CAPTCHA_UNSOLVABLE_MODULE = 0




	VAR_ERROR_KEY = "0"




	VAR_ERROR_BALANCE = "0"




	VAR_ERROR_LANG = "0"



	VAR_IS_CHANGED_SCROLL_Y = 0




	VAR_ERROR_PICK_IMAGE = 0




	VAR_RECAPTCHA_MODULE_ENABLED = 0




	VAR_HCAPTCHA_MODULE_ENABLED = 0




	VAR_FUNCAPTCHA_MODULE_ENABLED = 0




	VAR_NAME_MODULE_AUTOSUBMIT = "NaN"




	VAR_BAS_CAPMONSTER_IMAGE_ID = 0




	VAR_ERROR_BAN_IP = 0




	VAR_ALL_FRAMES_CAPTCHA = 0




	VAR_FRAME_NUMBER_CAPTCHA = 0




	VAR_ALREADY_CHECK_FRAME = 0




	VAR_WAIT_FRAME_TIMEOUT = 0




	VAR_IFRAME_XML_MODULE = "random_string_gener"




	VAR_GREEN_TICK = false




	VAR_BAS_MODULE_VERSION = "7.8"




	VAR_OLD_VERSION_BAS_MODULE = 0




	_call(function()
	{
	_on_fail(function(){
	VAR_LAST_ERROR = _result()
	VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
	VAR_WAS_ERROR = false
	_break(1,true)
	})
	CYCLES.Current().RemoveLabel("function")

	 
	 
	 {
	 var info = _get_current_browser_version_info("extended")
	 VAR_BROWSER_VERSION_ID = info.id
	 VAR_BROWSER_VERSION_STRING = info.browser_version
	 VAR_BROWSER_ARCHITECTURE = info.architecture
	 }
	 

	 
	 
	 //// Проверить установлены ли модули с автосабмитом.
	 if (typeof NumbersParseRecaptcha2 === 'function') VAR_RECAPTCHA_MODULE_ENABLED = 1, VAR_NAME_MODULE_AUTOSUBMIT = "ReCaptcha 2 Autosubmit";
	 if (typeof BASCaptchaSolver.helpers.HCaptchaHelper === 'function') VAR_HCAPTCHA_MODULE_ENABLED = 1, VAR_NAME_MODULE_AUTOSUBMIT = "hCaptcha Autosubmit";
	 if (typeof BASCaptchaSolver.helpers.FunCaptchaHelper === 'function') VAR_FUNCAPTCHA_MODULE_ENABLED = 1, VAR_NAME_MODULE_AUTOSUBMIT = "FunCaptcha Autosubmit";
	 //// Проверить версию BAS. Версия BAS 25.3.0 имеет движок версии 118
	 var VersionBrowserStringModule = VAR_BROWSER_VERSION_STRING;
	 var NumbersBeforeDotModule = VersionBrowserStringModule.split('.')[0];
	 var BrowserVersionIntModule = parseInt(NumbersBeforeDotModule);
	 if (BrowserVersionIntModule < 118) VAR_OLD_VERSION_BAS_MODULE = 1;
	 

	},null)!




	_set_if_expression("W1tGVU5DQVBUQ0hBX01PRFVMRV9FTkFCTEVEXV0gPT0gMSB8fCBbW1JFQ0FQVENIQV9NT0RVTEVfRU5BQkxFRF1dID09IDEgfHwgW1tIQ0FQVENIQV9NT0RVTEVfRU5BQkxFRF1dID09IDE=");
	_if(VAR_FUNCAPTCHA_MODULE_ENABLED == 1 || VAR_RECAPTCHA_MODULE_ENABLED == 1 || VAR_HCAPTCHA_MODULE_ENABLED == 1,function(){

	 
	 
	 fail((_K==="en" ? "Solve the captcha failed, to continue solving captchas by clicks requires to disable module " +VAR_NAME_MODULE_AUTOSUBMIT + " and also remove all actions from the script associated with it and retry solve captcha again" : "Решить капчу не удалось, для продолжения решения капчи кликами требуется отключить сторонний встроенный модуль в BAS: " +VAR_NAME_MODULE_AUTOSUBMIT + ", а также удалить все действия из файла сценария связанные с ним и повторить попытку"));
	 

	})!




	_set_if_expression("W1tXQVNfRVJST1JdXSB8fCBbW09MRF9WRVJTSU9OX0JBU19NT0RVTEVdXSA9PSAx");
	_if(VAR_WAS_ERROR || VAR_OLD_VERSION_BAS_MODULE == 1,function(){

	 
	 
	 _set_if_expression("W1tMQVNUX0VSUk9SXV0uaW5kZXhPZigiZ2V0X2N1cnJlbnRfYnJvd3Nlcl92ZXJzaW9uX2luZm8iKSA+PSAwIHx8IFtbT0xEX1ZFUlNJT05fQkFTX01PRFVMRV1dID09IDE=");
	 _if(VAR_LAST_ERROR.indexOf("get_current_browser_version_info") >= 0 || VAR_OLD_VERSION_BAS_MODULE == 1,function(){
	 
		
		
		fail((_K==="en" ? "Captcha solved failed, for the version module" +VAR_BAS_MODULE_VERSION + " requires BAS version 26.3.0 or higher version" : "Решить капчу не удалось, для модуля версии " +VAR_BAS_MODULE_VERSION + " требуется установить версию BAS 26.3.0 или версию старше"));
		

	 })!
	 

	})!




	_call(function()
	{
	_on_fail(function(){
	VAR_LAST_ERROR = _result()
	VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
	VAR_WAS_ERROR = false
	_break(1,true)
	})
	CYCLES.Current().RemoveLabel("function")},null)!




	_set_if_expression("W1tJU19JTlZJU0lCTEVfQ0FQVENIQV1d");
	_if(typeof(VAR_IS_INVISIBLE_CAPTCHA) !== "undefined" ? (VAR_IS_INVISIBLE_CAPTCHA) : undefined,function(){

	 
	 
	 /*Browser*/
	 waiter_timeout_next(45000)
	 wait_load("recaptcha/*/payload")!
	 

	 
	 
	 sleep(rand(100,500))!
	 

	})!




	_call(function()
	{
	_on_fail(function(){
	VAR_LAST_ERROR = _result()
	VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
	VAR_WAS_ERROR = false
	_break(1,true)
	})
	CYCLES.Current().RemoveLabel("function")

	 VAR_SPEED = 200;
	 VAR_GRAVITY = 12;
	 VAR_DEVIATION = 5;
	 VAR_IS_MOBILE = _IS_MOBILE;
	 

	 
	 
	 _set_if_expression("W1tJU19NT0JJTEVdXSA9PSBmYWxzZSAmJiByYW5kICgxLDEwKSA+IDM=");
	 _if(VAR_IS_MOBILE == false && rand (1,10) > 3,function(){
	 
		
		
		_do(function(){
		_set_action_info({ name: "While" });
		VAR_CYCLE_INDEX = _iterator() - 1
		BREAK_CONDITION = VAR_CYCLE_INDEX < 2;
		if(!BREAK_CONDITION)_break();
		
		   
		   
		   _get_browser_screen_settings()!
		   ;(function(){
		   var result = JSON.parse(_result())
		   VAR_SCROLL_X = result["ScrollX"]
		   VAR_SCROLL_Y = result["ScrollY"]
		   VAR_CURSOR_X = result["CursorX"]
		   VAR_CURSOR_Y = result["CursorY"]
		   VAR_BROWSER_WIDTH = result["Width"]
		   VAR_BROWSER_HEIGHT = result["Height"]
		   })();
		   

		   
		   
		   var scroll_x=parseInt(VAR_CURSOR_Y);
		   var scroll_y=parseInt(VAR_SCROLL_Y);
		   var browser_h=parseInt(VAR_BROWSER_HEIGHT);
		   //-------------------- Привели все в числа, считаем позицию ---------------------
		   var absolut_y = VAR_CURSOR_Y + VAR_SCROLL_Y;
		   var y_without_scroll = absolut_y - VAR_SCROLL_Y;
		   var check_y_top = VAR_BROWSER_HEIGHT/12;
		   var check_y_down = VAR_BROWSER_HEIGHT/100*92;
		   var move_y_top = VAR_BROWSER_HEIGHT/10;
		   var move_y_down = VAR_BROWSER_HEIGHT/100*80;
		   // -------------------------- Округляем ----------------------------------
		   VAR_CHECK_Y_TOP = check_y_top.toFixed();
		   VAR_CHECK_Y_DOWN = check_y_down.toFixed();
		   VAR_Y_WITHOUNT_SCROLL = y_without_scroll.toFixed();
		   VAR_MOVE_Y_TOP = move_y_top.toFixed();
		   VAR_MOVE_Y_DOWN = move_y_down.toFixed();
		   // ----------------- Снова приводим к числу ------------------------
		   VAR_CHECK_Y_TOP=parseInt(VAR_CHECK_Y_TOP);
		   VAR_CHECK_Y_DOWN=parseInt(VAR_CHECK_Y_DOWN);
		   VAR_Y_WITHOUNT_SCROLL=parseInt(VAR_Y_WITHOUNT_SCROLL);
		   VAR_MOVE_Y_TOP=parseInt(VAR_MOVE_Y_TOP);
		   VAR_MOVE_Y_DOWN=parseInt(VAR_MOVE_Y_DOWN);
		   

		   
		   
		   /*Browser*/
		   move(rand(VAR_BROWSER_WIDTH/5,VAR_BROWSER_WIDTH/1.3),rand(VAR_MOVE_Y_TOP + VAR_SCROLL_Y,VAR_MOVE_Y_DOWN + VAR_SCROLL_Y),  {} )!
		   

		   
		   
		   _set_if_expression("cmFuZCAoMSwxMCkgPiA1");
		   _if(rand (1,10) > 5,function(){
		   
			  
			  
			  _break("function")
			  

		   })!
		   

		})!
		

	 })!
	 

	 
	 
	 VAR_RECAPTCHA_PREFIX = VAR_GLOBAL_SELECTOR;
	 VAR_RECAPTCHA_PREFIX_FIRST_FRAME = VAR_RECAPTCHA_PREFIX;
	 {
	 var index = VAR_RECAPTCHA_PREFIX.toString().lastIndexOf(">FRAME>")
	 if(index >= 0)
	 VAR_RECAPTCHA_PREFIX = VAR_RECAPTCHA_PREFIX.substring(0,index)
	 VAR_RECAPTCHA_PREFIX_FIRST_FRAME = VAR_RECAPTCHA_PREFIX
	 index = VAR_RECAPTCHA_PREFIX.toString().lastIndexOf(">FRAME>")
	 if(index >= 0)
	 VAR_RECAPTCHA_PREFIX = VAR_RECAPTCHA_PREFIX.substring(0,index + ">FRAME>".length)
	 else
	 VAR_RECAPTCHA_PREFIX = ""
	 }
	 

	 
	 
	 _do(function(){
	 _set_action_info({ name: "For" });
	 VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
	 if(VAR_CYCLE_INDEX > parseInt(100))_break();
	 
		
		
		/*Browser*/
		;_SELECTOR=VAR_RECAPTCHA_PREFIX + "\u003eCSS\u003eiframe";
		get_element_selector(_SELECTOR, false).nowait().exist()!
		VAR_IS_EXISTS = _result() == 1
		

		
		
		_set_if_expression("W1tJU19FWElTVFNdXQ==");
		_if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
		
		   
		   
		   /*Browser*/
		   ;_SELECTOR=VAR_RECAPTCHA_PREFIX + "\u003eCSS\u003eiframe";
		   get_element_selector(_SELECTOR, true).length()!
		   VAR_ALL_FRAMES_CAPTCHA = _result()
		   

		})!
		

		
		
		/*Browser*/
		;_SELECTOR=VAR_RECAPTCHA_PREFIX + "\u003eCSS\u003eiframe\u003eAT\u003e" + VAR_FRAME_NUMBER_CAPTCHA;
		get_element_selector(_SELECTOR, false).nowait().exist()!
		VAR_IS_EXISTS = _result() == 1
		

		
		
		_set_if_expression("W1tJU19FWElTVFNdXQ==");
		_if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
		
		   
		   
		   /*Browser*/
		   _SELECTOR = VAR_RECAPTCHA_PREFIX + "\u003eCSS\u003eiframe\u003eAT\u003e" + VAR_FRAME_NUMBER_CAPTCHA;
		   wait_element(_SELECTOR)!
		   get_element_selector(_SELECTOR, false).xml()!
		   VAR_IFRAME_XML_MODULE = _result()
		   

		})!
		

		
		
		_set_if_expression("W1tJRlJBTUVfWE1MX01PRFVMRV1dLmluZGV4T2YoIi9iZnJhbWUiKSA+PSAw");
		_if(VAR_IFRAME_XML_MODULE.indexOf("/bframe") >= 0,function(){
		
		   
		   
		   /*Browser*/
		   ;_SELECTOR=VAR_RECAPTCHA_PREFIX + "\u003eCSS\u003eiframe\u003eAT\u003e" + VAR_FRAME_NUMBER_CAPTCHA;
		   get_element_selector(_SELECTOR, false).nowait().exist()!
		   VAR_IS_EXISTS = _result() == 1
		   _if(VAR_IS_EXISTS, function(){
		   get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
		   VAR_IS_EXISTS = _result().indexOf("true")>=0
		   })!
		   

		   
		   
		   _set_if_expression("W1tJU19FWElTVFNdXQ==");
		   _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
		   
			  
			  
			  /*Browser*/
			  _SELECTOR = VAR_RECAPTCHA_PREFIX + "\u003eCSS\u003eiframe\u003eAT\u003e" + VAR_FRAME_NUMBER_CAPTCHA;
			  wait_element(_SELECTOR)!
			  get_element_selector(_SELECTOR, false).attr("name")!
			  VAR_SAVED_ATTRIBUTE = _result()
			  

			  
			  
			  VAR_RECAPTCHA_PREFIX_SECOND_FRAME = VAR_RECAPTCHA_PREFIX + ">CSS>iframe[name=\"" + _result() + "\"]" + ">AT>" + VAR_NUMBER_CAPTCHA_MODULE + ">FRAME> >CSS> body";
			  VAR_RECAPTCHA_PREFIX_SECOND_FRAME_ELEMENT = VAR_RECAPTCHA_PREFIX + ">CSS>iframe[name=\"" + _result() + "\"]" + ">AT>" + VAR_NUMBER_CAPTCHA_MODULE
			  

			  
			  
			  _break("function")
			  

		   })!
		   

		})!
		

		
		
		_set_if_expression("W1tGUkFNRV9OVU1CRVJfQ0FQVENIQV1dID49IFtbQUxMX0ZSQU1FU19DQVBUQ0hBXV0gLSAx");
		_if(VAR_FRAME_NUMBER_CAPTCHA >= VAR_ALL_FRAMES_CAPTCHA - 1,function(){
		
		   
		   
		   VAR_NUMBER_CAPTCHA_MODULE = 0
		   

		   
		   
		   VAR_FRAME_NUMBER_CAPTCHA = 0
		   

		   
		   
		   _break("function")
		   

		})!
		

		
		
		VAR_FRAME_NUMBER_CAPTCHA = parseInt(VAR_FRAME_NUMBER_CAPTCHA) + parseInt(1)
		

	 })!
	 

	 
	 
	 _cycle_params().if_else = VAR_RECAPTCHA_PREFIX_SECOND_FRAME == "";
	 _set_if_expression("W1tSRUNBUFRDSEFfUFJFRklYX1NFQ09ORF9GUkFNRV1dID09ICIi");
	 _if(_cycle_params().if_else,function(){
	 
		
		
		_do(function(){
		_set_action_info({ name: "For" });
		VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
		if(VAR_CYCLE_INDEX > parseInt(50))_break();
		
		   
		   
		   /*Browser*/
		   ;_SELECTOR=VAR_GLOBAL_SELECTOR;
		   get_element_selector(_SELECTOR, false).nowait().exist()!
		   VAR_IS_EXISTS = _result() == 1
		   _if(VAR_IS_EXISTS, function(){
		   get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
		   VAR_IS_EXISTS = _result().indexOf("true")>=0
		   })!
		   

		   
		   
		   _cycle_params().if_else = typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined;
		   _set_if_expression("W1tJU19FWElTVFNdXQ==");
		   _if(_cycle_params().if_else,function(){
		   
			  
			  
			  _cycle_params().if_else = VAR_GLOBAL_SELECTOR == ">CSS>iframe[src*='anchor']>FRAME> >CSS> #recaptcha-anchor-label";
			  _set_if_expression("W1tHTE9CQUxfU0VMRUNUT1JdXSA9PSAiPkNTUz5pZnJhbWVbc3JjKj0nYW5jaG9yJ10+RlJBTUU+ID5DU1M+ICNyZWNhcHRjaGEtYW5jaG9yLWxhYmVsIg==");
			  _if(_cycle_params().if_else,function(){
			  
				 
				 
				 VAR_RANDOM_NUMBER_CLICK = Math.floor(Math.random() * (parseInt(10) - parseInt(1) + 1)) + parseInt(1)
				 

				 
				 
				 _set_if_expression("W1tSQU5ET01fTlVNQkVSX0NMSUNLXV0gPD0gNA==");
				 _if(VAR_RANDOM_NUMBER_CLICK <= 4,function(){
				 
					
					
					/*Browser*/
					_SELECTOR = VAR_GLOBAL_SELECTOR;waiter_timeout_next(8000)
					wait_element_visible(_SELECTOR)!
					_call(_random_point, {})!
					_if(_result().length > 0, function(){
					move( {} )!
					get_element_selector(_SELECTOR, false).clarify(X,Y)!
					_call(_clarify, {} )!
					mouse(X,Y)!
					})!
					

				 })!
				 

				 
				 
				 _set_if_expression("W1tSQU5ET01fTlVNQkVSX0NMSUNLXV0gPiA0ICYmIFtbUkFORE9NX05VTUJFUl9DTElDS11dIDw9IDc=");
				 _if(VAR_RANDOM_NUMBER_CLICK > 4 && VAR_RANDOM_NUMBER_CLICK <= 7,function(){
				 
					
					
					/*Browser*/
					_SELECTOR = "\u003eCSS\u003eiframe[src*=\u0027anchor\u0027]\u003eFRAME\u003e \u003eCSS\u003e div[class$=\u0022checkbox-border\u0022]";waiter_timeout_next(8000)
					wait_element_visible(_SELECTOR)!
					_call(_random_point, {})!
					_if(_result().length > 0, function(){
					move( {} )!
					get_element_selector(_SELECTOR, false).clarify(X,Y)!
					_call(_clarify, {} )!
					mouse(X,Y)!
					})!
					

				 })!
				 

				 
				 
				 _set_if_expression("W1tSQU5ET01fTlVNQkVSX0NMSUNLXV0gPiA3");
				 _if(VAR_RANDOM_NUMBER_CLICK > 7,function(){
				 
					
					
					/*Browser*/
					_SELECTOR = "\u003eCSS\u003eiframe[src*=\u0027anchor\u0027]\u003eFRAME\u003e \u003eCSS\u003e div[class^=\u0022rc-anchor-content\u0022]";waiter_timeout_next(8000)
					wait_element_visible(_SELECTOR)!
					_call(_random_point, {})!
					_if(_result().length > 0, function(){
					move( {} )!
					get_element_selector(_SELECTOR, false).clarify(X,Y)!
					_call(_clarify, {} )!
					mouse(X,Y)!
					})!
					

				 })!
				 

			  })!
			  

			  
			  
			  _if(!_cycle_params().if_else,function(){
			  
				 
				 
				 /*Browser*/
				 _SELECTOR = VAR_GLOBAL_SELECTOR;waiter_timeout_next(8000)
				 wait_element_visible(_SELECTOR)!
				 _call(_random_point, {})!
				 _if(_result().length > 0, function(){
				 move( {} )!
				 get_element_selector(_SELECTOR, false).clarify(X,Y)!
				 _call(_clarify, {} )!
				 mouse(X,Y)!
				 })!
				 

			  })!
			  delete _cycle_params().if_else;
			  

			  
			  
			  _break("function")
			  

		   })!
		   

		   
		   
		   _if(!_cycle_params().if_else,function(){
		   
			  
			  
			  sleep(rand(500,1000))!
			  

		   })!
		   delete _cycle_params().if_else;
		   

		   
		   
		   _set_if_expression("IVtbSVNfRVhJU1RTXV0=");
		   _if(!VAR_IS_EXISTS,function(){
		   
			  
			  
			  _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gcmFuZCAoNDAsNTEp");
			  _if(VAR_CYCLE_INDEX > rand (40,51),function(){
			  
				 
				 
				 VAR_ERROR_FIND_MAIN_SELECTOR = "1"
				 

			  })!
			  

		   })!
		   

		})!
		

	 })!
	 

	 
	 
	 _if(!_cycle_params().if_else,function(){
	 
		
		
		VAR_RECAPTCHA_2_INVISIBLE = 1
		

	 })!
	 delete _cycle_params().if_else;
	 

	},null)!




	_set_if_expression("W1tXQVNfRVJST1JdXQ==");
	_if(typeof(VAR_WAS_ERROR) !== "undefined" ? (VAR_WAS_ERROR) : undefined,function(){

	 
	 
	 _set_if_expression("W1tMQVNUX0VSUk9SXV0gPT09ICdBYm9ydGVkIEJ5IFVzZXInIHx8IFtbTEFTVF9FUlJPUl1dICA9PT0gJ9Cf0YDQtdGA0LLQsNC90L4g0J/QvtC70YzQt9C+0LLQsNGC0LXQu9C10Lwn");
	 _if(VAR_LAST_ERROR === 'Aborted By User' || VAR_LAST_ERROR  === 'Прервано Пользователем',function(){
	 
		
		
		_function_return(false)
		

	 })!
	 

	 
	 
	 /*Browser*/
	 cache_data_clear()!
	 

	 
	 
	 fail(VAR_LAST_ERROR)
	 

	})!




	_set_if_expression("W1tFUlJPUl9GSU5EX01BSU5fU0VMRUNUT1JdXSA9PSAx");
	_if(VAR_ERROR_FIND_MAIN_SELECTOR == 1,function(){

	 
	 
	 _set_if_expression("W1tJU19JTlZJU0lCTEVfQ0FQVENIQV1dID09PSBmYWxzZQ==");
	 _if(VAR_IS_INVISIBLE_CAPTCHA === false,function(){
	 
		
		
		fail((_K==="en" ? "Failed to solve ReCaptcha 2. Timeout wait of ReCaptcha 2 main selector with 'I am not robot' button" : "Не удалось решить ReCaptcha 2. Таймаут загрузки основного селектора ReCaptcha 2 c кнопкой 'Я не робот'"));
		

	 })!
	 

	 
	 
	 _set_if_expression("W1tJU19JTlZJU0lCTEVfQ0FQVENIQV1dID09PSB0cnVl");
	 _if(VAR_IS_INVISIBLE_CAPTCHA === true,function(){
	 
		
		
		fail((_K==="en" ? "Failed to solve ReCaptcha 2. Invisible ReCaptcha 2 open captcha window selector wait timeout" : "Не удалось решить ReCaptcha 2. Таймаут ожидания селектора открытого окна Invisible ReCaptcha 2."));
		

	 })!
	 

	})!




	_set_if_expression("W1tFUlJPUl9CQU5fSVBdXSA9PSAx");
	_if(VAR_ERROR_BAN_IP == 1,function(){

	 
	 
	 /*Browser*/
	 cache_data_clear()!
	 

	 
	 
	 fail((_K==="en" ? "IP address banned Repaptcha 2. Automated queries" : "IP адрес забанен ReСaptсha2 за автоматические запросы"));
	 

	})!




	VAR_SAVED_XML = ""




	VAR_TRY_CAPTCHA = "0"




	VAR_RECAPTCHA_2_CLOSED = "0"




	VAR_CAPTCHA_FAIL = "0"




	VAR_ERROR_LOAD = "0"




	VAR_COORDINATES_ALDREADY_GET_4X4 = "0"




	VAR_COORDINATES_ALDREADY_GET_3X3 = "0"




	VAR_ALL_FRAMES_CAPTCHA = 0




	VAR_IFRAME_XML_MODULE = "random_string_gener"




	VAR_FRAME_NUMBER_CAPTCHA = 0




	VAR_ALREADY_CHECK_FRAME = 0




	VAR_FIRST_LOAD_CAPTCHA = true




	VAR_FIRST_LOAD_BUTTON = true




	/// Селектор который передал юзер модулю приведем в нормальный вид
	get_selector_normal = function(s) {
	var e={},i,b=0,c,x,l=0,a,r='',w=String.fromCharCode,L=s.length;
	var A="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
	for(i=0;i<64;i++){e[A.charAt(i)]=i;}
	for(x=0;x<L;x++){
	c=e[s.charAt(x)];b=(b<<6)+c;l+=6;
	while(l>=8){((a=(b>>>(l-=8))&0xff)||(x<(L-2)))&&(r+=w(a));}
	}
	return r;
	};




	_do(function(){
	_set_action_info({ name: "For" });
	VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
	if(VAR_CYCLE_INDEX > parseInt(500))_break();

	 
	 
	 VAR_RELOAD_SUCCESS_BUTTON = 0
	 

	 
	 
	 VAR_RECAPTCHA_2_CLOSED = 0
	 

	 
	 
	 VAR_CYCLE_INDEX = 0
	 

	 
	 
	 _set_if_expression("W1tFUlJPUl9MT0FEXV0gPT0gMQ==");
	 _if(VAR_ERROR_LOAD == 1,function(){
	 
		
		
		/*Browser*/
		cache_data_clear()!
		

		
		
		fail((_K==="en" ? "Error Load frame Recaptcha2" : "Не удалось дождатся открытия окна капчи"));
		

	 })!
	 

	 
	 
	 _set_if_expression("W1tFUlJPUl9LRVldXSA9PSAx");
	 _if(VAR_ERROR_KEY == 1,function(){
	 
		
		
		/*Browser*/
		cache_data_clear()!
		

		
		
		fail((_K==="en" ? "API secret key from captcha recognition service is wrong ERROR_WRONG_USER_KEY" : "Секретный ключ API от сервиса распознавания капчи неподходит ERROR_WRONG_USER_KEY"));
		

	 })!
	 

	 
	 
	 _set_if_expression("W1tFUlJPUl9CQUxBTkNFXV0gPT0gMQ==");
	 _if(VAR_ERROR_BALANCE == 1,function(){
	 
		
		
		/*Browser*/
		cache_data_clear()!
		

		
		
		fail((_K==="en" ? "The balance on the captcha service has ended - ERROR_ZERO_BALANCE" : "Закончился баланс на сервисе распознавания капчи - ERROR_ZERO_BALANCE"));
		

	 })!
	 

	 
	 
	 _set_if_expression("W1tDQVBUQ0hBX0ZBSUxdXSA+IDE=");
	 _if(VAR_CAPTCHA_FAIL > 1,function(){
	 
		
		
		/*Browser*/
		cache_data_clear()!
		

		
		
		_cycle_params().if_else = VAR_SAVED_CONTENT.indexOf("<html>") >= 0;
		_set_if_expression("W1tTQVZFRF9DT05URU5UXV0uaW5kZXhPZigiPGh0bWw+IikgPj0gMA==");
		_if(_cycle_params().if_else,function(){
		
		   
		   
		   fail((_K==="en" ? "ReCaptcha 2 solved failed. CaptchaGuru solving service is not working at the moment" : "ReCaptcha 2 не была решена, причина: сервис по решению каптч CaptchaGuru не работает в данный момент."));
		   

		})!
		

		
		
		_if(!_cycle_params().if_else,function(){
		
		   
		   
		   fail((_K==="en" ? "Failed to solve ReCaptcha 2, reason - " +VAR_SAVED_CONTENT : "Не удалось решить ReCaptcha 2, причина - " +VAR_SAVED_CONTENT));
		   

		})!
		delete _cycle_params().if_else;
		

	 })!
	 

	 
	 
	 _set_if_expression("W1tFUlJPUl9DQVBUQ0hBX1VOU09MVkFCTEVfTU9EVUxFXV0gPiAx");
	 _if(VAR_ERROR_CAPTCHA_UNSOLVABLE_MODULE > 1,function(){
	 
		
		
		/*Browser*/
		cache_data_clear()!
		

		
		
		sleep(100)!
		

		
		
		fail((_K==="en" ? "Failed to solve ReCaptcha2 - SCTG was unable to solve the last 3 tasks/pictures, error type: ERROR_CPATCHA_UNSOLVABLE" : "Не удалось решить Recaptcha2 - SCTG не смог решить 2 последних задания/картинки. Ошибка: ERROR_CAPTCHA_UNSOLVABLE"));
		

	 })!
	 

	 
	 
	 _do(function(){
	 _set_action_info({ name: "For" });
	 VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
	 if(VAR_CYCLE_INDEX > parseInt(300))_break();
	 
		
		
		VAR_WAIT_FRAME_TIMEOUT = parseInt(VAR_WAIT_FRAME_TIMEOUT) + parseInt(1)
		

		
		
		/*Browser*/
		;_SELECTOR=VAR_RECAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eXPATH\u003e //*[@id=\u0022recaptcha-anchor\u0022][@aria-checked=\u0022true\u0022]";
		get_element_selector(_SELECTOR, false).nowait().exist()!
		VAR_IS_EXISTS = _result() == 1
		

		
		
		_set_if_expression("W1tJU19FWElTVFNdXSA9PSB0cnVlICYmIFtbUkVTVUxUX1NFTEVDVE9SXV0gIT0gMQ==");
		_if(VAR_IS_EXISTS == true,function(){
		
		   
		   
		   VAR_GREEN_TICK = true
		   

		   
		   
		   /*Browser*/
		   cache_data_clear()!
		   

		   
		   
		   _break("function")
		   

		})!
		
		
		_set_if_expression("W1tSRUNBUFRDSEFfMl9JTlZJU0lCTEVdXSA9PSAwICYmIFtbRklSU1RfTE9BRF9DQVBUQ0hBXV0gPT0gZmFsc2UgJiYgW1tSRVNVTFRfU0VMRUNUT1JdXSAhPSAx");
		_if(VAR_RECAPTCHA_2_INVISIBLE == 0 && VAR_FIRST_LOAD_CAPTCHA == false,function(){
		
		   
		   
		   /*Browser*/
		   ;_SELECTOR=VAR_RECAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eXPATH\u003e //*[@id=\u0022recaptcha-anchor\u0022]";
		   get_element_selector(_SELECTOR, false).nowait().exist()!
		   VAR_IS_EXISTS = _result() == 1
		   

		   
		   
		   _set_if_expression("W1tJU19FWElTVFNdXSA9PSBmYWxzZSAmJiBbW1JFU1VMVF9TRUxFQ1RPUl1dICE9IDE=");
		   _if(VAR_IS_EXISTS == false,function(){
		   
			  
			  
			  VAR_GREEN_TICK = true
			  

			  
			  
			  /*Browser*/
			  cache_data_clear()!
			  

			  
			  
			  _break("function")
			  

		   })!
		   

		})!
		

		
		
		_set_if_expression("W1tSRUNBUFRDSEFfMl9JTlZJU0lCTEVdXSA+IDAgJiYgW1tGSVJTVF9MT0FEX0NBUFRDSEFdXSA9PSBmYWxzZSAmJiBbW1JFU1VMVF9TRUxFQ1RPUl1dICE9IDE=");
		_if(VAR_RECAPTCHA_2_INVISIBLE > 0 && VAR_FIRST_LOAD_CAPTCHA == false,function(){
		
		   
		   
		   /*Browser*/
		   ;_SELECTOR=VAR_RECAPTCHA_PREFIX_SECOND_FRAME_ELEMENT;
		   get_element_selector(_SELECTOR, false).nowait().exist()!
		   VAR_IS_EXISTS = _result() == 1
		   _if(VAR_IS_EXISTS, function(){
		   get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
		   VAR_IS_EXISTS = _result().indexOf("true")>=0
		   })!
		   

		   
		   
		   _set_if_expression("W1tJU19FWElTVFNdXSA9PSBmYWxzZSAmJiBbW0NZQ0xFX0lOREVYXV0gPj0gMQ==");
		   _if(VAR_IS_EXISTS == false && VAR_CYCLE_INDEX >= 1,function(){
		   
			  
			  
			  VAR_GREEN_TICK = true
			  

			  
			  
			  _set_if_expression("W1tJU19JTlZJU0lCTEVfQ0FQVENIQV1dID09IGZhbHNl");
			  _if(VAR_IS_INVISIBLE_CAPTCHA == false,function(){
			  
				 
				 
				 /*Browser*/
				 cache_data_clear()!
				 

			  })!
			  

			  
			  
			  _break("function")
			  

		   })!
		   

		   
		   
		   _set_if_expression("W1tJU19FWElTVFNdXSA9PSB0cnVlICYmIFtbQ1lDTEVfSU5ERVhdXSA+PSAz");
		   _if(VAR_IS_EXISTS == true && VAR_CYCLE_INDEX >= 3,function(){
		   
			  
			  
			  /*Browser*/
			  _SELECTOR = VAR_RECAPTCHA_PREFIX_SECOND_FRAME + "\u003eXPATH\u003e id(\u0022rc-imageselect-target\u0022)";
			  wait_element(_SELECTOR)!
			  get_element_selector(_SELECTOR, false).script("(function(){var rect = _BAS_HIDE(BrowserAutomationStudio_GetBoundingClientRect)(self);return (rect.left + positionx) + '|' + (rect.top + positiony) + '|' + (rect.right - rect.left) + '|' + (rect.bottom - rect.top)})();")!
			  if(_result().length > 0)
			  {
			  var split = _result().split("|")
			  VAR_X_MODULE = parseInt(split[0])
			  VAR_Y_MODULE = parseInt(split[1])
			  VAR_WIDTH_MODULE = parseInt(split[2])
			  VAR_HEIGHT_MODULE = parseInt(split[3])
			  }
			  

			  
			  
			  _set_if_expression("W1tZX01PRFVMRV1dIDwgLTEwMDA=");
			  _if(VAR_Y_MODULE < -1000,function(){
			  
				 
				 
				 VAR_GREEN_TICK = true
				 

				 
				 
				 _set_if_expression("W1tJU19JTlZJU0lCTEVfQ0FQVENIQV1dID09IGZhbHNl");
				 _if(VAR_IS_INVISIBLE_CAPTCHA == false,function(){
				 
					
					
					/*Browser*/
					cache_data_clear()!
					

				 })!
				 

				 
				 
				 _break("function")
				 

			  })!
			  

		   })!
		   

		})!
		

		
		
		/*Browser*/
		;_SELECTOR=VAR_RECAPTCHA_PREFIX_SECOND_FRAME + "\u003eXPATH\u003e //div[@class=\u0022rc-doscaptcha-body\u0022]";
		get_element_selector(_SELECTOR, false).nowait().exist()!
		VAR_IS_EXISTS = _result() == 1
		_if(VAR_IS_EXISTS, function(){
		get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
		VAR_IS_EXISTS = _result().indexOf("true")>=0
		})!
		

		
		
		_set_if_expression("W1tJU19FWElTVFNdXQ==");
		_if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
		
		   
		   
		   fail((_K==="en" ? "IP address banned Repaptcha 2. Automated queries" : "Не удалось решить ReСaptcha 2. IP адрес забанен за автоматические запросы"));
		   

		})!
		

		
		
		_cycle_params().if_else = VAR_RECAPTCHA_PREFIX_SECOND_FRAME == "";
		_set_if_expression("W1tSRUNBUFRDSEFfUFJFRklYX1NFQ09ORF9GUkFNRV1dID09ICIi");
		_if(_cycle_params().if_else,function(){
		
		   
		   
		   _do(function(){
		   _set_action_info({ name: "For" });
		   VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
		   if(VAR_CYCLE_INDEX > parseInt(30))_break();
		   
			  
			  
			  /*Browser*/
			  ;_SELECTOR=VAR_RECAPTCHA_PREFIX + "\u003eCSS\u003eiframe";
			  get_element_selector(_SELECTOR, false).nowait().exist()!
			  VAR_IS_EXISTS = _result() == 1
			  

			  
			  
			  _set_if_expression("W1tJU19FWElTVFNdXQ==");
			  _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
			  
				 
				 
				 /*Browser*/
				 ;_SELECTOR=VAR_RECAPTCHA_PREFIX + "\u003eCSS\u003eiframe";
				 get_element_selector(_SELECTOR, true).length()!
				 VAR_ALL_FRAMES_CAPTCHA = _result()
				 

			  })!
			  

			  
			  
			  /*Browser*/
			  ;_SELECTOR=VAR_RECAPTCHA_PREFIX + "\u003eCSS\u003eiframe\u003eAT\u003e" + VAR_FRAME_NUMBER_CAPTCHA;
			  get_element_selector(_SELECTOR, false).nowait().exist()!
			  VAR_IS_EXISTS = _result() == 1
			  

			  
			  
			  _set_if_expression("W1tJU19FWElTVFNdXQ==");
			  _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
			  
				 
				 
				 /*Browser*/
				 _SELECTOR = VAR_RECAPTCHA_PREFIX + "\u003eCSS\u003eiframe\u003eAT\u003e" + VAR_FRAME_NUMBER_CAPTCHA;
				 wait_element(_SELECTOR)!
				 get_element_selector(_SELECTOR, false).xml()!
				 VAR_IFRAME_XML_MODULE = _result()
				 

			  })!
			  

			  
			  
			  _set_if_expression("W1tJRlJBTUVfWE1MX01PRFVMRV1dLmluZGV4T2YoIi9iZnJhbWUiKSA+PSAw");
			  _if(VAR_IFRAME_XML_MODULE.indexOf("/bframe") >= 0,function(){
			  
				 
				 
				 /*Browser*/
				 ;_SELECTOR=VAR_RECAPTCHA_PREFIX + "\u003eCSS\u003eiframe\u003eAT\u003e" + VAR_FRAME_NUMBER_CAPTCHA;
				 get_element_selector(_SELECTOR, false).nowait().exist()!
				 VAR_IS_EXISTS = _result() == 1
				 _if(VAR_IS_EXISTS, function(){
				 get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
				 VAR_IS_EXISTS = _result().indexOf("true")>=0
				 })!
				 

				 
				 
				 _set_if_expression("W1tJU19FWElTVFNdXQ==");
				 _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
				 
					
					
					/*Browser*/
					_SELECTOR = VAR_RECAPTCHA_PREFIX + "\u003eCSS\u003eiframe\u003eAT\u003e" + VAR_FRAME_NUMBER_CAPTCHA;
					wait_element(_SELECTOR)!
					get_element_selector(_SELECTOR, false).attr("name")!
					VAR_SAVED_ATTRIBUTE = _result()
					

					
					
					VAR_RECAPTCHA_PREFIX_SECOND_FRAME = VAR_RECAPTCHA_PREFIX + ">CSS>iframe[name=\"" + _result() + "\"]" + ">AT>" + VAR_NUMBER_CAPTCHA_MODULE + ">FRAME> >CSS> body";
					VAR_RECAPTCHA_PREFIX_SECOND_FRAME_ELEMENT = VAR_RECAPTCHA_PREFIX + ">CSS>iframe[name=\"" + _result() + "\"]" + ">AT>" + VAR_NUMBER_CAPTCHA_MODULE
					

					
					
					_break("function")
					

				 })!
				 

			  })!
			  

			  
			  
			  _set_if_expression("W1tGUkFNRV9OVU1CRVJfQ0FQVENIQV1dID49IFtbQUxMX0ZSQU1FU19DQVBUQ0hBXV0gLSAx");
			  _if(VAR_FRAME_NUMBER_CAPTCHA >= VAR_ALL_FRAMES_CAPTCHA - 1,function(){
			  
				 
				 
				 VAR_FRAME_NUMBER_CAPTCHA = 0
				 

				 
				 
				 VAR_NUMBER_CAPTCHA_MODULE = 0
				 

				 
				 
				 _break("function")
				 

			  })!
			  

			  
			  
			  VAR_FRAME_NUMBER_CAPTCHA = parseInt(VAR_FRAME_NUMBER_CAPTCHA) + parseInt(1)
			  

		   })!
		   

		})!
		

		
		
		_if(!_cycle_params().if_else,function(){
		
		   
		   
		   /*Browser*/
		   ;_SELECTOR=VAR_RECAPTCHA_PREFIX_SECOND_FRAME_ELEMENT;
		   get_element_selector(_SELECTOR, false).nowait().exist()!
		   VAR_IS_EXISTS = _result() == 1
		   _if(VAR_IS_EXISTS, function(){
		   get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
		   VAR_IS_EXISTS = _result().indexOf("true")>=0
		   })!
		   

		   
		   
		   _set_if_expression("W1tJU19FWElTVFNdXSAmJiBbW1JFU1VMVF9TRUxFQ1RPUl1dICE9IDE=");
		   _if(VAR_IS_EXISTS,function(){
		   
			  
			  
			  _break("function")
			  

		   })!
		   

		})!
		delete _cycle_params().if_else;
		

		
		
		/*Browser*/
		;_SELECTOR=VAR_RECAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eXPATH\u003e id(\u0022rc-anchor-container\u0022)/div[@class=\u0022rc-anchor-error-msg-container\u0022]";
		get_element_selector(_SELECTOR, false).nowait().exist()!
		VAR_IS_EXISTS = _result() == 1
		_if(VAR_IS_EXISTS, function(){
		get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
		VAR_IS_EXISTS = _result().indexOf("true")>=0
		})!
		

		
		
		_set_if_expression("W1tJU19FWElTVFNdXSAmJiBbW0ZJUlNUX0xPQURfQ0FQVENIQV1dID09IGZhbHNl");
		_if(VAR_IS_EXISTS && VAR_FIRST_LOAD_CAPTCHA == false,function(){
		
		   
		   
		   VAR_SAVED_TEXT = "\u0027\u0027"
		   

		   
		   
		   /*Browser*/
		   _SELECTOR = VAR_RECAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eXPATH\u003e id(\u0022rc-anchor-container\u0022)/div[@class=\u0022rc-anchor-error-msg-container\u0022]";
		   wait_element(_SELECTOR)!
		   get_element_selector(_SELECTOR, false).text()!
		   VAR_SAVED_TEXT = _result()
		   

		   
		   
		   /*Browser*/
		   cache_data_clear()!
		   

		   
		   
		   fail(VAR_SAVED_TEXT)
		   

		})!
		

		
		
		_set_if_expression("W1tXQUlUX0ZSQU1FX1RJTUVPVVRdXSA9PSAxNiB8fCBbW1dBSVRfRlJBTUVfVElNRU9VVF1dID09IDMy");
		_if(VAR_WAIT_FRAME_TIMEOUT == 16 || VAR_WAIT_FRAME_TIMEOUT == 32,function(){
		
		   
		   
		   sleep(rand(1000,3000))!
		   

		})!
		

		
		
		_set_if_expression("W1tXQUlUX0ZSQU1FX1RJTUVPVVRdXSA+PSAzMCAmJiBbW0ZJUlNUX0xPQURfQ0FQVENIQV1dID09IGZhbHNlICYmIFtbUkVTVUxUX1NFTEVDVE9SXV0gIT0gMQ==");
		_if(VAR_WAIT_FRAME_TIMEOUT >= 30 && VAR_FIRST_LOAD_CAPTCHA == false,function(){
		
		   
		   
		   /*Browser*/
		   cache_data_clear()!
		   

		   
		   
		   fail((_K==="en" ? "Failed to solve the ReCaptcha. The captcha window is closed." : "Решить ReCaptcha 2 не удалось. Окно с капчей не было открыто."));
		   

		})!
		

		
		
		_set_if_expression("W1tXQUlUX0ZSQU1FX1RJTUVPVVRdXSA+IDQwICYmIFtbRklSU1RfTE9BRF9DQVBUQ0hBXV0gPT0gdHJ1ZSAmJiBbW1JFU1VMVF9TRUxFQ1RPUl1dICE9IDE=");
		_if(VAR_WAIT_FRAME_TIMEOUT > 40 && VAR_FIRST_LOAD_CAPTCHA == true,function(){
		
		   
		   
		   /*Browser*/
		   cache_data_clear()!
		   

		   
		   
		   fail((_K==="en" ? "Failed to solve ReCaptcha2. Timeout for opening captcha window with images" : "Не удалось решить ReCaptcha2, слишком долгое ожидание открытия окна каптчи с изображениями"));
		   

		})!
		

	 })!
	 

	 
	 
	 VAR_CYCLE_INDEX = 0
	 

	 
	 
	 VAR_WAIT_FRAME_TIMEOUT = 0
	 

	 
	 
	 VAR_FIRST_LOAD_BUTTON = false
	 

	 
	 
	 _set_if_expression("W1tHUkVFTl9USUNLXV0gPT0gdHJ1ZQ==");
	 _if(VAR_GREEN_TICK == true,function(){
	 
		
		
		_function_return("")
		

	 })!
	 

	 
	 
	 VAR_TRY_CAPTCHA = parseInt(VAR_TRY_CAPTCHA) + parseInt(1)
	 

	 
	 
	 _set_if_expression("W1tUUllfQ0FQVENIQV1dID49IFtbVFJZX05VTUJFUl1d");
	 _if(VAR_TRY_CAPTCHA >= VAR_TRY_NUMBER,function(){
	 
		
		
		sleep(4000)!
		

		
		
		/*Browser*/
		cache_data_clear()!
		

		
		
		/*Browser*/
		;_SELECTOR=VAR_RECAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eXPATH\u003e //*[@id=\u0022recaptcha-anchor\u0022][@aria-checked=\u0022true\u0022]";
		get_element_selector(_SELECTOR, false).nowait().exist()!
		VAR_IS_EXISTS = _result() == 1
		_if(VAR_IS_EXISTS, function(){
		get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
		VAR_IS_EXISTS = _result().indexOf("true")>=0
		})!
		

		
		
		_set_if_expression("W1tJU19FWElTVFNdXSA9PSB0cnVlICYmIFtbUkVTVUxUX1NFTEVDVE9SXV0gIT0gMQ==");
		_if(VAR_IS_EXISTS == true,function(){
		
		   
		   
		   _function_return("")
		   

		})!
		

		
		
		fail((_K==="en" ? "Failed to solve the captcha. ReCaptcha 2 attempts solve limit exceeded" : "Решить капчу не удалось. Превышен лимит попыток решить ReCaptcha 2"))
		

	 })!
	 

	 
	 
	 _call(function()
	 {
	 _on_fail(function(){
	 VAR_LAST_ERROR = _result()
	 VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
	 VAR_WAS_ERROR = false
	 _break(1,true)
	 })
	 CYCLES.Current().RemoveLabel("function")
	 
		
		
		/*Browser*/
		;_SELECTOR=VAR_RECAPTCHA_PREFIX_SECOND_FRAME + "\u003eXPATH\u003e //div[@class=\u0022rc-imageselect-error-select-more\u0022]";
		get_element_selector(_SELECTOR, false).nowait().exist()!
		VAR_IS_EXISTS_1 = _result() == 1
		_if(VAR_IS_EXISTS_1, function(){
		get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
		VAR_IS_EXISTS_1 = _result().indexOf("true")>=0
		})!
		

		
		
		/*Browser*/
		;_SELECTOR=VAR_RECAPTCHA_PREFIX_SECOND_FRAME + "\u003eXPATH\u003e //div[@class=\u0022rc-imageselect-error-dynamic-more\u0022]";
		get_element_selector(_SELECTOR, false).nowait().exist()!
		VAR_IS_EXISTS_2 = _result() == 1
		_if(VAR_IS_EXISTS_2, function(){
		get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
		VAR_IS_EXISTS_2 = _result().indexOf("true")>=0
		})!
		

		
		
		_call(function()
		{
		_on_fail(function(){
		VAR_LAST_ERROR = _result()
		VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
		VAR_WAS_ERROR = false
		_break(1,true)
		})
		CYCLES.Current().RemoveLabel("function")
		
		   
		   
		   _set_if_expression("W1tJU19FWElTVFNfMV1dIHx8IFtbSVNfRVhJU1RTXzJdXQ==");
		   _if(VAR_IS_EXISTS_1 || VAR_IS_EXISTS_2,function(){
		   
			  
			  
			  VAR_BAS_CAPMONSTER_IMAGE_ID = "0"
			  

			  
			  
			  _set_if_expression("W1tSRUNBUFRDSEFfMl9JTlZJU0lCTEVdXSA9PSAx");
			  _if(VAR_RECAPTCHA_2_INVISIBLE == 1,function(){
			  
				 
				 
				 VAR_RECAPTCHA_2_INVISIBLE = parseInt(VAR_RECAPTCHA_2_INVISIBLE) + parseInt(1)
				 

			  })!
			  

			  
			  
			  /*Browser*/
			  cache_data_clear()!
			  

			  
			  
			  sleep(500)!
			  

			  
			  
			  /*Browser*/
			  _SELECTOR = VAR_RECAPTCHA_PREFIX_SECOND_FRAME + "\u003eXPATH\u003e id(\u0022recaptcha-reload-button\u0022)";
			  wait_element_visible(_SELECTOR)!
			  _call(_random_point, {})!
			  _if(_result().length > 0, function(){
			  move( {"speed": VAR_SPEED,"gravity": VAR_GRAVITY,"deviation": VAR_DEVIATION} )!
			  get_element_selector(_SELECTOR, false).clarify(X,Y)!
			  _call(_clarify, {"speed": VAR_SPEED,"gravity": VAR_GRAVITY,"deviation": VAR_DEVIATION} )!
			  mouse(X,Y)!
			  })!
			  

			  
			  
			  _set_if_expression("W1tSRUNBUFRDSEFfMl9JTlZJU0lCTEVdXSA9PSAx");
			  _if(VAR_RECAPTCHA_2_INVISIBLE == 1,function(){
			  
				 
				 
				 VAR_RECAPTCHA_2_INVISIBLE = parseInt(VAR_RECAPTCHA_2_INVISIBLE) + parseInt(1)
				 

			  })!
			  

			  
			  
			  sleep(500)!
			  

		   })!
		   

		},null)!
		

		
		
		_set_if_expression("W1tXQVNfRVJST1JdXQ==");
		_if(typeof(VAR_WAS_ERROR) !== "undefined" ? (VAR_WAS_ERROR) : undefined,function(){
		
		   
		   
		   _set_if_expression("W1tMQVNUX0VSUk9SXV0gPT09ICdBYm9ydGVkIEJ5IFVzZXInIHx8IFtbTEFTVF9FUlJPUl1dICA9PT0gJ9Cf0YDQtdGA0LLQsNC90L4g0J/QvtC70YzQt9C+0LLQsNGC0LXQu9C10Lwn");
		   _if(VAR_LAST_ERROR === 'Aborted By User' || VAR_LAST_ERROR  === 'Прервано Пользователем',function(){
		   
			  
			  
			  _function_return(false)
			  

		   })!
		   

		   
		   
		   log("Произошла ошибка : " + VAR_LAST_ERROR)
		   

		})!
		

	 },null)!
	 

	 
	 
	 _set_if_expression("W1tJU19FWElTVFNfMV1dIHx8IFtbSVNfRVhJU1RTXzJdXQ==");
	 _if(VAR_IS_EXISTS_1 || VAR_IS_EXISTS_2,function(){
	 
		
		
		_next("function")
		

	 })!
	 

	 
	 
	 _set_if_expression("W1tXQVNfRVJST1JdXQ==");
	 _if(typeof(VAR_WAS_ERROR) !== "undefined" ? (VAR_WAS_ERROR) : undefined,function(){
	 
		
		
		_set_if_expression("W1tMQVNUX0VSUk9SXV0gPT09ICdBYm9ydGVkIEJ5IFVzZXInIHx8IFtbTEFTVF9FUlJPUl1dICA9PT0gJ9Cf0YDQtdGA0LLQsNC90L4g0J/QvtC70YzQt9C+0LLQsNGC0LXQu9C10Lwn");
		_if(VAR_LAST_ERROR === 'Aborted By User' || VAR_LAST_ERROR  === 'Прервано Пользователем',function(){
		
		   
		   
		   _function_return(false)
		   

		})!
		

		
		
		/*Browser*/
		cache_data_clear()!
		

		
		
		fail(VAR_LAST_ERROR)
		

	 })!
	 

	 
	 
	 _call(function()
	 {
	 _on_fail(function(){
	 VAR_LAST_ERROR = _result()
	 VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
	 VAR_WAS_ERROR = false
	 _break(1,true)
	 })
	 CYCLES.Current().RemoveLabel("function")
	 
		
		
		_get_browser_screen_settings()!
		;(function(){
		var result = JSON.parse(_result())
		VAR_SCROLL_X = result["ScrollX"]
		VAR_SCROLL_Y = result["ScrollY"]
		VAR_CURSOR_X = result["CursorX"]
		VAR_CURSOR_Y = result["CursorY"]
		VAR_BROWSER_WIDTH = result["Width"]
		VAR_BROWSER_HEIGHT = result["Height"]
		})();
		

		
		
		_set_if_expression("W1tGSVJTVF9MT0FEX0NBUFRDSEFdXSA9PSB0cnVlICYmIFtbU0NST0xMX1ldXSAhPSAw");
		_if(VAR_FIRST_LOAD_CAPTCHA == true && VAR_SCROLL_Y != 0,function(){
		
		   
		   
		   /*Browser*/
		   ;_SELECTOR=VAR_RECAPTCHA_PREFIX_SECOND_FRAME + " \u003eXPATH\u003e //*[@class=\u0022rc-imageselect-table-33\u0022]";
		   get_element_selector(_SELECTOR, false).nowait().exist()!
		   VAR_IS_EXISTS = _result() == 1
		   

		   
		   
		   _set_if_expression("W1tJU19FWElTVFNdXQ==");
		   _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
		   
			  
			  
			  VAR_RANDOM_NUMBER_SQUARE = Math.floor(Math.random() * (parseInt(12) - parseInt(8) + 1)) + parseInt(8)
			  

			  
			  
			  _set_if_expression("W1tSQU5ET01fTlVNQkVSX1NRVUFSRV1dID09IDg=");
			  _if(VAR_RANDOM_NUMBER_SQUARE == 8,function(){
			  
				 
				 
				 /*Browser*/
				 _SELECTOR = VAR_RECAPTCHA_PREFIX_SECOND_FRAME + " \u003eXPATH\u003e //*[@tabindex=\u00228\u0022]";
				 wait_element_visible(_SELECTOR)!
				 _call(_random_point, {})!
				 _if(_result().length > 0, function(){
				 move( {} )!
				 get_element_selector(_SELECTOR, false).clarify(X,Y)!
				 _call(_clarify, {} )!
				 })!
				 

			  })!
			  

			  
			  
			  _set_if_expression("W1tSQU5ET01fTlVNQkVSX1NRVUFSRV1dID09IDk=");
			  _if(VAR_RANDOM_NUMBER_SQUARE == 9,function(){
			  
				 
				 
				 /*Browser*/
				 _SELECTOR = VAR_RECAPTCHA_PREFIX_SECOND_FRAME + " \u003eXPATH\u003e //*[@tabindex=\u00229\u0022]";
				 wait_element_visible(_SELECTOR)!
				 _call(_random_point, {})!
				 _if(_result().length > 0, function(){
				 move( {} )!
				 get_element_selector(_SELECTOR, false).clarify(X,Y)!
				 _call(_clarify, {} )!
				 })!
				 

			  })!
			  

			  
			  
			  _set_if_expression("W1tSQU5ET01fTlVNQkVSX1NRVUFSRV1dID09IDEw");
			  _if(VAR_RANDOM_NUMBER_SQUARE == 10,function(){
			  
				 
				 
				 /*Browser*/
				 _SELECTOR = VAR_RECAPTCHA_PREFIX_SECOND_FRAME + " \u003eXPATH\u003e //*[@tabindex=\u002210\u0022]";
				 wait_element_visible(_SELECTOR)!
				 _call(_random_point, {})!
				 _if(_result().length > 0, function(){
				 move( {} )!
				 get_element_selector(_SELECTOR, false).clarify(X,Y)!
				 _call(_clarify, {} )!
				 })!
				 

			  })!
			  

			  
			  
			  _set_if_expression("W1tSQU5ET01fTlVNQkVSX1NRVUFSRV1dID09IDEx");
			  _if(VAR_RANDOM_NUMBER_SQUARE == 11,function(){
			  
				 
				 
				 /*Browser*/
				 _SELECTOR = VAR_RECAPTCHA_PREFIX_SECOND_FRAME + " \u003eXPATH\u003e //*[@tabindex=\u002211\u0022]";
				 wait_element_visible(_SELECTOR)!
				 _call(_random_point, {})!
				 _if(_result().length > 0, function(){
				 move( {} )!
				 get_element_selector(_SELECTOR, false).clarify(X,Y)!
				 _call(_clarify, {} )!
				 })!
				 

			  })!
			  

			  
			  
			  _set_if_expression("W1tSQU5ET01fTlVNQkVSX1NRVUFSRV1dID09IDEy");
			  _if(VAR_RANDOM_NUMBER_SQUARE == 12,function(){
			  
				 
				 
				 /*Browser*/
				 _SELECTOR = VAR_RECAPTCHA_PREFIX_SECOND_FRAME + " \u003eXPATH\u003e //*[@tabindex=\u002212\u0022]";
				 wait_element_visible(_SELECTOR)!
				 _call(_random_point, {})!
				 _if(_result().length > 0, function(){
				 move( {} )!
				 get_element_selector(_SELECTOR, false).clarify(X,Y)!
				 _call(_clarify, {} )!
				 })!
				 

			  })!
			  

		   })!
		   

		})!
		

	 },null)!
	 

	 
	 
	 VAR_FIRST_LOAD_CAPTCHA = false
	 

	 
	 
	 /*Browser*/
	 ;_SELECTOR=VAR_RECAPTCHA_PREFIX_SECOND_FRAME + "\u003eXPATH\u003e //div[@class=\u0022rc-doscaptcha-body\u0022]";
	 get_element_selector(_SELECTOR, false).nowait().exist()!
	 VAR_IS_EXISTS = _result() == 1
	 _if(VAR_IS_EXISTS, function(){
	 get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
	 VAR_IS_EXISTS = _result().indexOf("true")>=0
	 })!
	 

	 
	 
	 _set_if_expression("W1tJU19FWElTVFNdXQ==");
	 _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
	 
		
		
		fail((_K==="en" ? "IP address banned Repaptcha 2. Automated queries" : "Не удалось решить ReСaptcha 2. IP адрес забанен за автоматические запросы"));
		

	 })!
	 

	 
	 
	 _call(function()
	 {
	 _on_fail(function(){
	 VAR_LAST_ERROR = _result()
	 VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
	 VAR_WAS_ERROR = false
	 _break(1,true)
	 })
	 CYCLES.Current().RemoveLabel("function")
	 
		
		
		VAR_CYCLE_INDEX = 0
		

		
		
		_set_if_expression("W1tSRUNBUFRDSEFfMl9JTlZJU0lCTEVdXSA9PSAx");
		_if(VAR_RECAPTCHA_2_INVISIBLE == 1,function(){
		
		   
		   
		   _do(function(){
		   _set_action_info({ name: "For" });
		   VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
		   if(VAR_CYCLE_INDEX > parseInt(60))_break();
		   
			  
			  
			  /*Browser*/
			  ;_SELECTOR=VAR_RECAPTCHA_PREFIX_SECOND_FRAME;
			  get_element_selector(_SELECTOR, false).nowait().exist()!
			  VAR_IS_EXISTS = _result() == 1
			  _if(VAR_IS_EXISTS, function(){
			  get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
			  VAR_IS_EXISTS = _result().indexOf("true")>=0
			  })!
			  

			  
			  
			  _set_if_expression("W1tJU19FWElTVFNdXSA9PSB0cnVl");
			  _if(VAR_IS_EXISTS == true,function(){
			  
				 
				 
				 _break("function")
				 

			  })!
			  

			  
			  
			  _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gNTA=");
			  _if(VAR_CYCLE_INDEX > 50,function(){
			  
				 
				 
				 VAR_ERROR_LOAD = "1"
				 

			  })!
			  

			  
			  
			  sleep(100)!
			  

		   })!
		   

		   
		   
		   /*Browser*/
		   _SELECTOR = VAR_RECAPTCHA_PREFIX_SECOND_FRAME + "\u003eXPATH\u003e id(\u0022rc-imageselect-target\u0022)";
		   wait_element(_SELECTOR)!
		   get_element_selector(_SELECTOR, false).exist()!
		   _if(_result() == "1", function(){
		   get_element_selector(_SELECTOR, false).render_base64()!
		   VAR_IMAGE_BASE_64 = _result()
		   })!
		   

		})!
		

		
		
		_set_if_expression("W1tCQVNfQ0FQTU9OU1RFUl9JTUFHRV9JRF1dID09IDAgJiYgW1tSRUNBUFRDSEFfMl9JTlZJU0lCTEVdXSAhPSAx");
		_if(VAR_BAS_CAPMONSTER_IMAGE_ID == 0 && VAR_RECAPTCHA_2_INVISIBLE != 1,function(){
		
		   
		   
		   /*Browser*/
		   ;_SELECTOR=VAR_RECAPTCHA_PREFIX_SECOND_FRAME;
		   get_element_selector(_SELECTOR, false).nowait().exist()!
		   VAR_IS_EXISTS = _result() == 1
		   _if(VAR_IS_EXISTS, function(){
		   get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
		   VAR_IS_EXISTS = _result().indexOf("true")>=0
		   })!
		   

		   
		   
		   _cycle_params().if_else = typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined;
		   _set_if_expression("W1tJU19FWElTVFNdXQ==");
		   _if(_cycle_params().if_else,function(){
		   
			  
			  
			  VAR_RECAPTCHA_2_CLOSED = 0
			  

			  
			  
			  _do(function(){
			  _set_action_info({ name: "For" });
			  VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
			  if(VAR_CYCLE_INDEX > parseInt(20))_break();
			  
				 
				 
				 /*Browser*/
				 is_load("recaptcha/*/payload")!
				 VAR_SAVED_IS_LOADED = _result()
				 

				 
				 
				 _set_if_expression("W1tTQVZFRF9JU19MT0FERURdXSA9PSAx");
				 _if(VAR_SAVED_IS_LOADED == 1,function(){
				 
					
					
					VAR_ERROR_RECAPTCHA_PAYLOAD = 0
					

					
					
					_break("function")
					

				 })!
				 

				 
				 
				 _set_if_expression("W1tFUlJPUl9SRUNBUFRDSEFfUEFZTE9BRF1dID4gNA==");
				 _if(VAR_ERROR_RECAPTCHA_PAYLOAD > 4,function(){
				 
					
					
					VAR_TRY_CAPTCHA = parseInt(VAR_TRY_CAPTCHA) + parseInt(25)
					

					
					
					VAR_RECAPTCHA_2_CLOSED = 1
					

					
					
					_break("function")
					

				 })!
				 

				 
				 
				 _set_if_expression("W1tFUlJPUl9SRUNBUFRDSEFfUEFZTE9BRF1dID4gMg==");
				 _if(VAR_ERROR_RECAPTCHA_PAYLOAD > 2,function(){
				 
					
					
					VAR_BAS_CAPMONSTER_IMAGE_ID = 0
					

					
					
					_call(function()
					{
					_on_fail(function(){
					VAR_LAST_ERROR = _result()
					VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
					VAR_WAS_ERROR = false
					_break(1,true)
					})
					CYCLES.Current().RemoveLabel("function")
					
					   
					   
					   /*Browser*/
					   ;_SELECTOR=VAR_RECAPTCHA_PREFIX_SECOND_FRAME + "\u003eXPATH\u003e id(\u0022recaptcha-reload-button\u0022)";
					   get_element_selector(_SELECTOR, false).nowait().exist()!
					   VAR_IS_EXISTS = _result() == 1
					   _if(VAR_IS_EXISTS, function(){
					   get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
					   VAR_IS_EXISTS = _result().indexOf("true")>=0
					   })!
					   

					   
					   
					   _set_if_expression("W1tJU19FWElTVFNdXQ==");
					   _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
					   
						  
						  
						  /*Browser*/
						  cache_data_clear()!
						  

						  
						  
						  /*Browser*/
						  _SELECTOR = VAR_RECAPTCHA_PREFIX_SECOND_FRAME + "\u003eXPATH\u003e id(\u0022recaptcha-reload-button\u0022)";
						  wait_element_visible(_SELECTOR)!
						  _call(_random_point, {})!
						  _if(_result().length > 0, function(){
						  move( {"speed": VAR_SPEED,"gravity": VAR_GRAVITY,"deviation": VAR_DEVIATION} )!
						  get_element_selector(_SELECTOR, false).clarify(X,Y)!
						  _call(_clarify, {"speed": VAR_SPEED,"gravity": VAR_GRAVITY,"deviation": VAR_DEVIATION} )!
						  mouse(X,Y)!
						  })!
						  

						  
						  
						  VAR_RECAPTCHA_2_CLOSED = 1
						  

						  
						  
						  _break("function")
						  

					   })!
					   

					},null)!
					

				 })!
				 

				 
				 
				 _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gNQ==");
				 _if(VAR_CYCLE_INDEX > 5,function(){
				 
					
					
					/*Browser*/
					;_SELECTOR=VAR_RECAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eXPATH\u003e //*[@id=\u0022recaptcha-anchor\u0022][@aria-checked=\u0022true\u0022]";
					get_element_selector(_SELECTOR, false).nowait().exist()!
					VAR_IS_EXISTS = _result() == 1
					_if(VAR_IS_EXISTS, function(){
					get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
					VAR_IS_EXISTS = _result().indexOf("true")>=0
					})!
					

					
					
					_set_if_expression("W1tJU19FWElTVFNdXSA9PSB0cnVl");
					_if(VAR_IS_EXISTS == true,function(){
					
					   
					   
					   VAR_RECAPTCHA_2_CLOSED = 1
					   

					   
					   
					   _break("function")
					   

					})!
					

				 })!
				 

				 
				 
				 sleep(100)!
				 

				 
				 
				 _set_if_expression("W1tDWUNMRV9JTkRFWF1dID09IDE5");
				 _if(VAR_CYCLE_INDEX == 19,function(){
				 
					
					
					VAR_ERROR_RECAPTCHA_PAYLOAD = parseInt(VAR_ERROR_RECAPTCHA_PAYLOAD) + parseInt(1)
					

					
					
					VAR_RECAPTCHA_2_CLOSED = 1
					

					
					
					_break("function")
					

				 })!
				 

			  })!
			  

		   })!
		   

		   
		   
		   _if(!_cycle_params().if_else,function(){
		   
			  
			  
			  VAR_RECAPTCHA_2_CLOSED = 1
			  

		   })!
		   delete _cycle_params().if_else;
		   

		   
		   
		   _set_if_expression("W1tSRUNBUFRDSEFfMl9DTE9TRURdXSA9PSAw");
		   _if(VAR_RECAPTCHA_2_CLOSED == 0,function(){
		   
			  
			  
			  _do(function(){
			  _set_action_info({ name: "For" });
			  VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
			  if(VAR_CYCLE_INDEX > parseInt(100))_break();
			  
				 
				 
				 /*Browser*/
				 ;_SELECTOR=VAR_RECAPTCHA_PREFIX_SECOND_FRAME_ELEMENT;
				 get_element_selector(_SELECTOR, false).nowait().exist()!
				 VAR_IS_EXISTS = _result() == 1
				 _if(VAR_IS_EXISTS, function(){
				 get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
				 VAR_IS_EXISTS = _result().indexOf("true")>=0
				 })!
				 

				 
				 
				 _set_if_expression("IVtbSVNfRVhJU1RTXV0=");
				 _if(!VAR_IS_EXISTS,function(){
				 
					
					
					VAR_RECAPTCHA_2_CLOSED = "1"
					

					
					
					_break("function")
					

				 })!
				 

				 
				 
				 cache_get_base64("recaptcha/*/payload")!
				 var image_id = native("imageprocessing", "load", _result())
				 var image_size = native("imageprocessing", "getsize", image_id)
				 var image_w = parseInt(image_size.split(",")[0])
				 var image_h = parseInt(image_size.split(",")[1])
				 VAR_SQUARE_WIDHT = image_w;
				 VAR_SQUARE_HEIGHT = image_h;
				 if (image_h == 0 && VAR_CYCLE_INDEX > rand (35,48)) fail((_K === "en" ? "Failed to wait for ReCaptcha2 image from request cache" : "Не удалось дождаться картинку ReCaptcha2 из кэша запроса"))
				 if (image_h > 99) {
				 VAR_IMAGE_BASE_64 = _result()
				 _break()
				 }
				 sleep(400)!
				 

			  })!
			  

		   })!
		   

		})!
		

	 },null)!
	 

	 
	 
	 _set_if_expression("W1tSRUNBUFRDSEFfMl9DTE9TRURdXSA9PSAx");
	 _if(VAR_RECAPTCHA_2_CLOSED == 1,function(){
	 
		
		
		sleep(rand(100,400))!
		

		
		
		_next("function")
		

	 })!
	 

	 
	 
	 _set_if_expression("W1tXQVNfRVJST1JdXQ==");
	 _if(typeof(VAR_WAS_ERROR) !== "undefined" ? (VAR_WAS_ERROR) : undefined,function(){
	 
		
		
		_set_if_expression("W1tMQVNUX0VSUk9SXV0gPT09ICdBYm9ydGVkIEJ5IFVzZXInIHx8IFtbTEFTVF9FUlJPUl1dICA9PT0gJ9Cf0YDQtdGA0LLQsNC90L4g0J/QvtC70YzQt9C+0LLQsNGC0LXQu9C10Lwn");
		_if(VAR_LAST_ERROR === 'Aborted By User' || VAR_LAST_ERROR  === 'Прервано Пользователем',function(){
		
		   
		   
		   _function_return(false)
		   

		})!
		

		
		
		VAR_BAS_CAPMONSTER_IMAGE_ID = 0
		

		
		
		_set_if_expression("W1tSRUNBUFRDSEFfMl9JTlZJU0lCTEVdXSA9PSAx");
		_if(VAR_RECAPTCHA_2_INVISIBLE == 1,function(){
		
		   
		   
		   VAR_RECAPTCHA_2_INVISIBLE = parseInt(VAR_RECAPTCHA_2_INVISIBLE) + parseInt(1)
		   

		})!
		

		
		
		_call(function()
		{
		_on_fail(function(){
		VAR_LAST_ERROR = _result()
		VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
		VAR_WAS_ERROR = false
		_break(1,true)
		})
		CYCLES.Current().RemoveLabel("function")
		
		   
		   
		   /*Browser*/
		   ;_SELECTOR=VAR_RECAPTCHA_PREFIX_SECOND_FRAME + "\u003eXPATH\u003e id(\u0022recaptcha-reload-button\u0022)";
		   get_element_selector(_SELECTOR, false).nowait().exist()!
		   VAR_IS_EXISTS = _result() == 1
		   _if(VAR_IS_EXISTS, function(){
		   get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
		   VAR_IS_EXISTS = _result().indexOf("true")>=0
		   })!
		   

		   
		   
		   _set_if_expression("W1tJU19FWElTVFNdXQ==");
		   _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
		   
			  
			  
			  /*Browser*/
			  cache_data_clear()!
			  

			  
			  
			  /*Browser*/
			  _SELECTOR = VAR_RECAPTCHA_PREFIX_SECOND_FRAME + "\u003eXPATH\u003e id(\u0022recaptcha-reload-button\u0022)";
			  wait_element_visible(_SELECTOR)!
			  _call(_random_point, {})!
			  _if(_result().length > 0, function(){
			  move( {"speed": VAR_SPEED,"gravity": VAR_GRAVITY,"deviation": VAR_DEVIATION} )!
			  get_element_selector(_SELECTOR, false).clarify(X,Y)!
			  _call(_clarify, {"speed": VAR_SPEED,"gravity": VAR_GRAVITY,"deviation": VAR_DEVIATION} )!
			  mouse(X,Y)!
			  })!
			  

		   })!
		   

		},null)!
		

		
		
		VAR_RELOAD_SUCCESS_BUTTON = "1"
		

	 })!
	 

	 
	 
	 _set_if_expression("W1tSRUxPQURfU1VDQ0VTU19CVVRUT05dXSA9PSAx");
	 _if(VAR_RELOAD_SUCCESS_BUTTON == 1,function(){
	 
		
		
		_next("function")
		

	 })!
	 

	 
	 
	 _set_if_expression("W1tCQVNfQ0FQTU9OU1RFUl9JTUFHRV9JRF1dID09IDA=");
	 _if(VAR_BAS_CAPMONSTER_IMAGE_ID == 0,function(){
	 
		
		
		/*Browser*/
		;_SELECTOR=VAR_RECAPTCHA_PREFIX_SECOND_FRAME + "\u003eXPATH\u003e //table[@class=\u0022rc-imageselect-table-44\u0022]";
		get_element_selector(_SELECTOR, false).nowait().exist()!
		VAR_IS44 = _result() == 1
		_if(VAR_IS44, function(){
		get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
		VAR_IS44 = _result().indexOf("true")>=0
		})!
		

		
		
		/*Browser*/
		;_SELECTOR=VAR_RECAPTCHA_PREFIX_SECOND_FRAME + "\u003eXPATH\u003e //table[@class=\u0022rc-imageselect-table-33\u0022]";
		get_element_selector(_SELECTOR, false).nowait().exist()!
		VAR_IS33 = _result() == 1
		_if(VAR_IS33, function(){
		get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
		VAR_IS33 = _result().indexOf("true")>=0
		})!
		

		
		
		_set_if_expression("IVtbSVMzM11dICYmICFbW0lTNDRdXQ==");
		_if(!VAR_IS33 && !VAR_IS44,function(){
		
		   
		   
		   fail((_K==="en" ? "Failed to solve ReCaptcha 2. This captcha type is unknown" : "Не удалось решить ReCaptcha 2, загрузился неизвестный тип каптчи"));
		   

		})!
		

		
		
		/*Browser*/
		_SELECTOR = VAR_RECAPTCHA_PREFIX_SECOND_FRAME + "\u003eCSS\u003e strong";
		wait_element(_SELECTOR)!
		get_element_selector(_SELECTOR, false).text()!
		VAR_CURRENT_TASK = _result()
		

		
		
		VAR_SET_TASK = VAR_CURRENT_TASK
		

	 })!
	 

	 
	 
	 _call(function()
	 {
	 _on_fail(function(){
	 VAR_LAST_ERROR = _result()
	 VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
	 VAR_WAS_ERROR = false
	 _break(1,true)
	 })
	 CYCLES.Current().RemoveLabel("function")
	 
		
		
		_get_browser_screen_settings()!
		;(function(){
		var result = JSON.parse(_result())
		VAR_SCROLL_X = result["ScrollX"]
		VAR_SCROLL_Y = result["ScrollY"]
		VAR_CURSOR_X = result["CursorX"]
		VAR_CURSOR_Y = result["CursorY"]
		VAR_BROWSER_WIDTH = result["Width"]
		VAR_BROWSER_HEIGHT = result["Height"]
		})();
		

		
		
		/*Browser*/
		;_SELECTOR=VAR_RECAPTCHA_PREFIX_SECOND_FRAME + "\u003eXPATH\u003e//div[@class=\u0022rc-imageselect-incorrect-response\u0022]";
		get_element_selector(_SELECTOR, false).nowait().exist()!
		VAR_ERROR_EXISTS = _result() == 1
		_if(VAR_ERROR_EXISTS, function(){
		get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
		VAR_ERROR_EXISTS = _result().indexOf("true")>=0
		})!
		

		
		
		_set_if_expression("W1tCQVNfQ0FQTU9OU1RFUl9JTUFHRV9JRF1dID09IDAgJiYgW1tDT09SRElOQVRFU19BTERSRUFEWV9HRVRfNFg0XV0gPT0gMCAmJiBbW0lTNDRdXSA9PSB0cnVlIHx8IFtbSVNfQ0hBTkdFRF9TQ1JPTExfWV1dICE9IFtbU0NST0xMX1ldXSAmJiBbW0lTNDRdXSA9PSB0cnVl");
		_if(VAR_BAS_CAPMONSTER_IMAGE_ID == 0 && VAR_COORDINATES_ALDREADY_GET_4X4 == 0 && VAR_IS44 == true || VAR_IS_CHANGED_SCROLL_Y != VAR_SCROLL_Y && VAR_IS44 == true,function(){
		
		   
		   
		   VAR_IS_CHANGED_SCROLL_Y = VAR_SCROLL_Y
		   

		   
		   
		   VAR_ELEMENT_SELECTOR = VAR_RECAPTCHA_PREFIX_SECOND_FRAME + "\u003eXPATH\u003e //*[@class=\u0022rc-imageselect-tile\u0022][@tabindex=\u00224\u0022]"
		   

		   
		   
		   _SELECTOR = VAR_ELEMENT_SELECTOR;
		   get_element_selector(_SELECTOR, false).script("(function(){var rect = _BAS_HIDE(BrowserAutomationStudio_GetBoundingClientRect)(self);return (rect.left + positionx) + '|' + (rect.top + positiony) + '|' + (rect.right - rect.left) + '|' + (rect.bottom - rect.top)})();")!
		   var split = _result().split("|");
		   var x = parseInt(split[0]), y = parseInt(split[1]), w = parseInt(split[2]), h = parseInt(split[3]);
		   _get_browser_screen_settings()!
		   var result_recaptcha = JSON.parse(_result());
		   var scroll_x = result_recaptcha["ScrollX"], scroll_y = result_recaptcha["ScrollY"]
		   var margin_top_bottom = 50; //percent
		   var margin_left_top = 50; // percent
		   div = 1;
		   var x_min = x + w/100*margin_left_top + parseInt(scroll_x), x_max = x+w/div-w/100*margin_left_top + parseInt(scroll_x);
		   var y_min = y + h/100*margin_top_bottom + parseInt(scroll_y), y_max = y+h - h/100*margin_top_bottom + parseInt(scroll_y);
		   x = rand(x_min, x_max);
		   y = rand(y_min, y_max);
		   x = x.toFixed();
		   y = y.toFixed();
		   if (VAR_IS33 == true)
		   {
		   /// Первый квадрат
		   VAR_FIRST_PIC_X = parseInt(x);
		   VAR_FIRST_PIC_Y = parseInt(y);
		   // Второй и т.д.
		   VAR_SECOND_PIC_X = VAR_FIRST_PIC_X + w;
		   VAR_SECOND_PIC_Y = VAR_FIRST_PIC_Y;
		   VAR_THIRD_PIC_X = VAR_SECOND_PIC_X + w;
		   VAR_THIRD_PIC_Y = VAR_FIRST_PIC_Y;
		   VAR_FOUR_PIC_X = VAR_FIRST_PIC_X
		   VAR_FOUR_PIC_Y = VAR_FIRST_PIC_Y + h;
		   VAR_FIVE_PIC_X = VAR_SECOND_PIC_X
		   VAR_FIVE_PIC_Y = VAR_SECOND_PIC_Y + h;
		   VAR_SIX_PIC_X = VAR_THIRD_PIC_X;
		   VAR_SIX_PIC_Y = VAR_THIRD_PIC_Y + h;
		   VAR_SEVEN_PIC_X = VAR_FOUR_PIC_X;
		   VAR_SEVEN_PIC_Y = VAR_FOUR_PIC_Y + h;
		   VAR_EIGHT_PIC_X = VAR_FIVE_PIC_X
		   VAR_EIGHT_PIC_Y = VAR_FIVE_PIC_Y + h;
		   VAR_NINE_PIC_X = VAR_SIX_PIC_X
		   VAR_NINE_PIC_Y = VAR_SIX_PIC_Y + h;
		   }
		   if (VAR_IS44 == true)
		   {
		   /// Первый квадрат
		   VAR_FIRST_PIC_X = parseInt(x);
		   VAR_FIRST_PIC_Y = parseInt(y);
		   // Второй и т.д.
		   VAR_SECOND_PIC_X = VAR_FIRST_PIC_X + w;
		   VAR_SECOND_PIC_Y = VAR_FIRST_PIC_Y;
		   VAR_THIRD_PIC_X = VAR_SECOND_PIC_X + w;
		   VAR_THIRD_PIC_Y = VAR_FIRST_PIC_Y;
		   VAR_FOUR_PIC_X = VAR_THIRD_PIC_X + w;
		   VAR_FOUR_PIC_Y = VAR_FIRST_PIC_Y
		   VAR_FIVE_PIC_X = VAR_FIRST_PIC_X
		   VAR_FIVE_PIC_Y = VAR_SECOND_PIC_Y + h;
		   VAR_SIX_PIC_X = VAR_SECOND_PIC_X;
		   VAR_SIX_PIC_Y = VAR_SECOND_PIC_Y + h;
		   VAR_SEVEN_PIC_X = VAR_THIRD_PIC_X;
		   VAR_SEVEN_PIC_Y = VAR_THIRD_PIC_Y + h;
		   VAR_EIGHT_PIC_X = VAR_FOUR_PIC_X
		   VAR_EIGHT_PIC_Y = VAR_FOUR_PIC_Y + h;
		   VAR_NINE_PIC_X = VAR_FIVE_PIC_X
		   VAR_NINE_PIC_Y = VAR_FIVE_PIC_Y + h;
		   VAR_TEN_PIC_X = VAR_SIX_PIC_X
		   VAR_TEN_PIC_Y = VAR_SIX_PIC_Y + h;
		   VAR_ELEVEN_PIC_X = VAR_SEVEN_PIC_X
		   VAR_ELEVEN_PIC_Y = VAR_SEVEN_PIC_Y + h;
		   VAR_TWELVE_PIC_X = VAR_EIGHT_PIC_X
		   VAR_TWELVE_PIC_Y = VAR_EIGHT_PIC_Y + h;
		   VAR_THIRTEEN_PIC_X = VAR_NINE_PIC_X
		   VAR_THIRTEEN_PIC_Y = VAR_NINE_PIC_Y + h;
		   VAR_FOURTEEN_PIC_X = VAR_TEN_PIC_X
		   VAR_FOURTEEN_PIC_Y = VAR_TEN_PIC_Y + h;
		   VAR_FIVETEEN_PIC_X = VAR_ELEVEN_PIC_X
		   VAR_FIVETEEN_PIC_Y = VAR_ELEVEN_PIC_Y + h;
		   VAR_SIXTEEN_PIC_X = VAR_TWELVE_PIC_X
		   VAR_SIXTEEN_PIC_Y = VAR_TWELVE_PIC_Y + h;
		   }
		   

		   
		   
		   VAR_COORDINATES_ALDREADY_GET_4X4 = "1"
		   

		   
		   
		   VAR_COORDINATES_ALDREADY_GET_3X3 = "0"
		   

		})!
		

		
		
		_set_if_expression("W1tCQVNfQ0FQTU9OU1RFUl9JTUFHRV9JRF1dID09IDAgJiYgW1tDT09SRElOQVRFU19BTERSRUFEWV9HRVRfM1gzXV0gPT0gMCAmJiBbW0lTMzNdXSA9PSB0cnVlIHx8IFtbSVNfQ0hBTkdFRF9TQ1JPTExfWV1dICE9IFtbU0NST0xMX1ldXSAmJiBbW0lTMzNdXSA9PSB0cnVl");
		_if(VAR_BAS_CAPMONSTER_IMAGE_ID == 0 && VAR_COORDINATES_ALDREADY_GET_3X3 == 0 && VAR_IS33 == true || VAR_IS_CHANGED_SCROLL_Y != VAR_SCROLL_Y && VAR_IS33 == true,function(){
		
		   
		   
		   VAR_IS_CHANGED_SCROLL_Y = VAR_SCROLL_Y
		   

		   
		   
		   VAR_ELEMENT_SELECTOR = VAR_RECAPTCHA_PREFIX_SECOND_FRAME + "\u003eXPATH\u003e //*[@class=\u0022rc-imageselect-tile\u0022][@tabindex=\u00224\u0022]"
		   

		   
		   
		   _SELECTOR = VAR_ELEMENT_SELECTOR;
		   get_element_selector(_SELECTOR, false).script("(function(){var rect = _BAS_HIDE(BrowserAutomationStudio_GetBoundingClientRect)(self);return (rect.left + positionx) + '|' + (rect.top + positiony) + '|' + (rect.right - rect.left) + '|' + (rect.bottom - rect.top)})();")!
		   var split = _result().split("|");
		   var x = parseInt(split[0]), y = parseInt(split[1]), w = parseInt(split[2]), h = parseInt(split[3]);
		   _get_browser_screen_settings()!
		   var result_recaptcha = JSON.parse(_result());
		   var scroll_x = result_recaptcha["ScrollX"], scroll_y = result_recaptcha["ScrollY"]
		   var margin_top_bottom = 50; //percent
		   var margin_left_top = 50; // percent
		   div = 1;
		   var x_min = x + w/100*margin_left_top + parseInt(scroll_x), x_max = x+w/div-w/100*margin_left_top + parseInt(scroll_x);
		   var y_min = y + h/100*margin_top_bottom + parseInt(scroll_y), y_max = y+h - h/100*margin_top_bottom + parseInt(scroll_y);
		   x = rand(x_min, x_max);
		   y = rand(y_min, y_max);
		   x = x.toFixed();
		   y = y.toFixed();
		   if (VAR_IS33 == true)
		   {
		   /// Первый квадрат
		   VAR_FIRST_PIC_X = parseInt(x);
		   VAR_FIRST_PIC_Y = parseInt(y);
		   // Второй и т.д.
		   VAR_SECOND_PIC_X = VAR_FIRST_PIC_X + w;
		   VAR_SECOND_PIC_Y = VAR_FIRST_PIC_Y;
		   VAR_THIRD_PIC_X = VAR_SECOND_PIC_X + w;
		   VAR_THIRD_PIC_Y = VAR_FIRST_PIC_Y;
		   VAR_FOUR_PIC_X = VAR_FIRST_PIC_X
		   VAR_FOUR_PIC_Y = VAR_FIRST_PIC_Y + h;
		   VAR_FIVE_PIC_X = VAR_SECOND_PIC_X
		   VAR_FIVE_PIC_Y = VAR_SECOND_PIC_Y + h;
		   VAR_SIX_PIC_X = VAR_THIRD_PIC_X;
		   VAR_SIX_PIC_Y = VAR_THIRD_PIC_Y + h;
		   VAR_SEVEN_PIC_X = VAR_FOUR_PIC_X;
		   VAR_SEVEN_PIC_Y = VAR_FOUR_PIC_Y + h;
		   VAR_EIGHT_PIC_X = VAR_FIVE_PIC_X
		   VAR_EIGHT_PIC_Y = VAR_FIVE_PIC_Y + h;
		   VAR_NINE_PIC_X = VAR_SIX_PIC_X
		   VAR_NINE_PIC_Y = VAR_SIX_PIC_Y + h;
		   }
		   if (VAR_IS44 == true)
		   {
		   /// Первый квадрат
		   VAR_FIRST_PIC_X = parseInt(x);
		   VAR_FIRST_PIC_Y = parseInt(y);
		   // Второй и т.д.
		   VAR_SECOND_PIC_X = VAR_FIRST_PIC_X + w;
		   VAR_SECOND_PIC_Y = VAR_FIRST_PIC_Y;
		   VAR_THIRD_PIC_X = VAR_SECOND_PIC_X + w;
		   VAR_THIRD_PIC_Y = VAR_FIRST_PIC_Y;
		   VAR_FOUR_PIC_X = VAR_THIRD_PIC_X + w;
		   VAR_FOUR_PIC_Y = VAR_FIRST_PIC_Y
		   VAR_FIVE_PIC_X = VAR_FIRST_PIC_X
		   VAR_FIVE_PIC_Y = VAR_SECOND_PIC_Y + h;
		   VAR_SIX_PIC_X = VAR_SECOND_PIC_X;
		   VAR_SIX_PIC_Y = VAR_SECOND_PIC_Y + h;
		   VAR_SEVEN_PIC_X = VAR_THIRD_PIC_X;
		   VAR_SEVEN_PIC_Y = VAR_THIRD_PIC_Y + h;
		   VAR_EIGHT_PIC_X = VAR_FOUR_PIC_X
		   VAR_EIGHT_PIC_Y = VAR_FOUR_PIC_Y + h;
		   VAR_NINE_PIC_X = VAR_FIVE_PIC_X
		   VAR_NINE_PIC_Y = VAR_FIVE_PIC_Y + h;
		   VAR_TEN_PIC_X = VAR_SIX_PIC_X
		   VAR_TEN_PIC_Y = VAR_SIX_PIC_Y + h;
		   VAR_ELEVEN_PIC_X = VAR_SEVEN_PIC_X
		   VAR_ELEVEN_PIC_Y = VAR_SEVEN_PIC_Y + h;
		   VAR_TWELVE_PIC_X = VAR_EIGHT_PIC_X
		   VAR_TWELVE_PIC_Y = VAR_EIGHT_PIC_Y + h;
		   VAR_THIRTEEN_PIC_X = VAR_NINE_PIC_X
		   VAR_THIRTEEN_PIC_Y = VAR_NINE_PIC_Y + h;
		   VAR_FOURTEEN_PIC_X = VAR_TEN_PIC_X
		   VAR_FOURTEEN_PIC_Y = VAR_TEN_PIC_Y + h;
		   VAR_FIVETEEN_PIC_X = VAR_ELEVEN_PIC_X
		   VAR_FIVETEEN_PIC_Y = VAR_ELEVEN_PIC_Y + h;
		   VAR_SIXTEEN_PIC_X = VAR_TWELVE_PIC_X
		   VAR_SIXTEEN_PIC_Y = VAR_TWELVE_PIC_Y + h;
		   }
		   

		   
		   
		   VAR_COORDINATES_ALDREADY_GET_4X4 = "0"
		   

		   
		   
		   VAR_COORDINATES_ALDREADY_GET_3X3 = "1"
		   

		})!
		

	 },null)!
	 

	 
	 
	 _set_if_expression("W1tXQVNfRVJST1JdXQ==");
	 _if(typeof(VAR_WAS_ERROR) !== "undefined" ? (VAR_WAS_ERROR) : undefined,function(){
	 
		
		
		_set_if_expression("W1tMQVNUX0VSUk9SXV0gPT09ICdBYm9ydGVkIEJ5IFVzZXInIHx8IFtbTEFTVF9FUlJPUl1dICA9PT0gJ9Cf0YDQtdGA0LLQsNC90L4g0J/QvtC70YzQt9C+0LLQsNGC0LXQu9C10Lwn");
		_if(VAR_LAST_ERROR === 'Aborted By User' || VAR_LAST_ERROR  === 'Прервано Пользователем',function(){
		
		   
		   
		   _function_return(false)
		   

		})!
		

		
		
		_next("function")
		

	 })!
	 

	 
	 
	 _call(function()
	 {
	 _on_fail(function(){
	 VAR_LAST_ERROR = _result()
	 VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
	 VAR_WAS_ERROR = false
	 _break(1,true)
	 })
	 CYCLES.Current().RemoveLabel("function")
	 
		
		
		_set_if_expression("W1tJU19NT0JJTEVdXSA9PT0gZmFsc2UgJiYgcmFuZCAoMSwxMCkgPiAzICYmIFtbQkFTX0NBUE1PTlNURVJfSU1BR0VfSURdXSA9PSAw");
		_if(VAR_IS_MOBILE === false && rand (1,10) > 3 && VAR_BAS_CAPMONSTER_IMAGE_ID == 0,function(){
		
		   
		   
		   _get_browser_screen_settings()!
		   ;(function(){
		   var result = JSON.parse(_result())
		   VAR_SCROLL_X = result["ScrollX"]
		   VAR_SCROLL_Y = result["ScrollY"]
		   VAR_CURSOR_X = result["CursorX"]
		   VAR_CURSOR_Y = result["CursorY"]
		   VAR_BROWSER_WIDTH = result["Width"]
		   VAR_BROWSER_HEIGHT = result["Height"]
		   })();
		   

		   
		   
		   /*Browser*/
		   ;_SELECTOR=VAR_RECAPTCHA_PREFIX_SECOND_FRAME + "\u003eXPATH\u003e id(\u0022rc-imageselect-target\u0022)";
		   get_element_selector(_SELECTOR, false).nowait().exist()!
		   VAR_IS_EXISTS = _result() == 1
		   _if(VAR_IS_EXISTS, function(){
		   get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
		   VAR_IS_EXISTS = _result().indexOf("true")>=0
		   })!
		   

		   
		   
		   _set_if_expression("IVtbSVNfRVhJU1RTXV0=");
		   _if(!VAR_IS_EXISTS,function(){
		   
			  
			  
			  VAR_RECAPTCHA_2_CLOSED = "1"
			  

		   })!
		   

		   
		   
		   _set_if_expression("W1tSRUNBUFRDSEFfMl9DTE9TRURdXSA9PSAw");
		   _if(VAR_RECAPTCHA_2_CLOSED == 0,function(){
		   
			  
			  
			  /*Browser*/
			  _SELECTOR = VAR_RECAPTCHA_PREFIX_SECOND_FRAME + "\u003eXPATH\u003e id(\u0022rc-imageselect-target\u0022)";
			  wait_element(_SELECTOR)!
			  get_element_selector(_SELECTOR, false).script("(function(){var rect = _BAS_HIDE(BrowserAutomationStudio_GetBoundingClientRect)(self);return (rect.left + positionx) + '|' + (rect.top + positiony) + '|' + (rect.right - rect.left) + '|' + (rect.bottom - rect.top)})();")!
			  if(_result().length > 0)
			  {
			  var split = _result().split("|")
			  VAR_X = parseInt(split[0])
			  VAR_Y = parseInt(split[1])
			  VAR_CAPTCHA_WIDTH = parseInt(split[2])
			  VAR_CAPTCHA_HEIGHT = parseInt(split[3])
			  }
			  

			  
			  
			  /*Browser*/
			  move(rand(VAR_X/100*105,(VAR_X+VAR_CAPTCHA_WIDTH)/100*93).toFixed(),rand(VAR_Y + VAR_SCROLL_Y/100*105,VAR_Y + VAR_SCROLL_Y + VAR_CAPTCHA_HEIGHT/100*90).toFixed(),  {} )!
			  

		   })!
		   

		})!
		

	 },null)!
	 

	 
	 
	 _set_if_expression("W1tSRUNBUFRDSEFfMl9DTE9TRURdXSA9PSAx");
	 _if(VAR_RECAPTCHA_2_CLOSED == 1,function(){
	 
		
		
		sleep(rand(100,400))!
		

		
		
		_next("function")
		

	 })!
	 

	 
	 
	 _set_if_expression("W1tXQVNfRVJST1JdXQ==");
	 _if(typeof(VAR_WAS_ERROR) !== "undefined" ? (VAR_WAS_ERROR) : undefined,function(){
	 
		
		
		_set_if_expression("W1tMQVNUX0VSUk9SXV0gPT09ICdBYm9ydGVkIEJ5IFVzZXInIHx8IFtbTEFTVF9FUlJPUl1dICA9PT0gJ9Cf0YDQtdGA0LLQsNC90L4g0J/QvtC70YzQt9C+0LLQsNGC0LXQu9C10Lwn");
		_if(VAR_LAST_ERROR === 'Aborted By User' || VAR_LAST_ERROR  === 'Прервано Пользователем',function(){
		
		   
		   
		   _function_return(false)
		   

		})!
		

		
		
		/*Browser*/
		cache_data_clear()!
		

		
		
		fail(VAR_LAST_ERROR)
		

	 })!
	 

	 
	 
	 _call(function()
	 {
	 _on_fail(function(){
	 VAR_LAST_ERROR = _result()
	 VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
	 VAR_WAS_ERROR = false
	 _break(1,true)
	 })
	 CYCLES.Current().RemoveLabel("function")
	 
		
		
		_set_if_expression("W1tJTUFHRV9CQVNFXzY0XV0gPT0gOTk5OTk5OTk5OQ==");
		_if(VAR_IMAGE_BASE_64 == 9999999999,function(){
		
		   
		   
		   _set_if_expression("W1tJUzMzXV0gPT0gdHJ1ZQ==");
		   _if(VAR_IS33 == true,function(){
		   
			  
			  
			  VAR_RAND_PICTURE = rand (1,50000)
			  

			  
			  
			  native("filesystem", "writefile", JSON.stringify({path: "C:/Images/ReCaptcha2/3x3/" + VAR_SET_TASK + "/" + VAR_RAND_PICTURE + ".jpg",value: (VAR_IMAGE_BASE_64).toString(),base64:true,append:false}))
			  

		   })!
		   

		   
		   
		   _set_if_expression("W1tJUzQ0XV0gPT0gdHJ1ZQ==");
		   _if(VAR_IS44 == true,function(){
		   
			  
			  
			  VAR_RAND_PICTURE = rand (1,50000)
			  

			  
			  
			  native("filesystem", "writefile", JSON.stringify({path: "C:/Images/ReCaptcha2/4x4/" + VAR_SET_TASK + "/" + VAR_RAND_PICTURE + ".jpg",value: (VAR_IMAGE_BASE_64).toString(),base64:true,append:false}))
			  

		   })!
		   

		})!
		

	 },null)!
	 

	 
	 
	 _call(function()
	 {
	 _on_fail(function(){
	 VAR_LAST_ERROR = _result()
	 VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
	 VAR_WAS_ERROR = false
	 _break(1,true)
	 })
	 CYCLES.Current().RemoveLabel("function")
	 
		
		
		VAR_CYCLE_INDEX = 0
		

		
		
		VAR_RECAPTCHA_2_CLOSED = 0
		

		
		
		_do(function(){
		_set_action_info({ name: "For" });
		VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
		if(VAR_CYCLE_INDEX > parseInt(20))_break();
		
		   
		   
		   ///Чистим
		   solver_properties_clear("capmonster")
			   
		   if (VAR_IS33 === true) VAR_SIZE_BOX_CAPTCHA = 9;
		   if (VAR_IS44 === true) VAR_SIZE_BOX_CAPTCHA = 16;
		   /// Формирумем основной запрос
		   solver_property("capmonster","serverurl","http://sctg.xyz")
		   solver_property("capmonster","key",VAR_KEY_MODULE)
		   solver_property("capmonster","textinstructions",VAR_SET_TASK)
		   solver_property("capmonster","method","userrecaptcha")
		   solver_property("capmonster","sizex",VAR_SIZE_BOX_CAPTCHA)
		   solver_property("capmonster","body",VAR_IMAGE_BASE_64)
		   //// Отправляем
		   solve_base64_no_fail("capmonster", "")!
		   //solve_base64_no_fail("capmonster", VAR_IMAGE_BASE_64)!
		   VAR_SAVED_CONTENT = _result();
		   

		   
		   
		   _set_if_expression("W1tTQVZFRF9DT05URU5UXV0uaW5kZXhPZigiRVJST1JfQ0FQVENIQV9VTlNPTFZBQkxFIikgPj0gMA==");
		   _if(VAR_SAVED_CONTENT.indexOf("ERROR_CAPTCHA_UNSOLVABLE") >= 0,function(){
		   
			  
			  
			  VAR_ERROR_CAPTCHA_UNSOLVABLE_MODULE = parseInt(VAR_ERROR_CAPTCHA_UNSOLVABLE_MODULE) + parseInt(1)
			  

			  
			  
			  VAR_BAS_CAPMONSTER_IMAGE_ID = 0
			  

			  
			  
			  _set_if_expression("W1tSRUNBUFRDSEFfMl9JTlZJU0lCTEVdXSA9PSAx");
			  _if(VAR_RECAPTCHA_2_INVISIBLE == 1,function(){
			  
				 
				 
				 VAR_RECAPTCHA_2_INVISIBLE = parseInt(VAR_RECAPTCHA_2_INVISIBLE) + parseInt(1)
				 

			  })!
			  

			  
			  
			  /*Browser*/
			  cache_data_clear()!
			  

			  
			  
			  /*Browser*/
			  _SELECTOR = VAR_RECAPTCHA_PREFIX_SECOND_FRAME + "\u003eXPATH\u003e id(\u0022recaptcha-reload-button\u0022)";
			  wait_element_visible(_SELECTOR)!
			  _call(_random_point, {})!
			  _if(_result().length > 0, function(){
			  move( {"speed": VAR_SPEED,"gravity": VAR_GRAVITY,"deviation": VAR_DEVIATION} )!
			  get_element_selector(_SELECTOR, false).clarify(X,Y)!
			  _call(_clarify, {"speed": VAR_SPEED,"gravity": VAR_GRAVITY,"deviation": VAR_DEVIATION} )!
			  mouse(X,Y)!
			  })!
			  

			  
			  
			  sleep(100)!
			  

			  
			  
			  _break("function")
			  

		   })!
		   

		   
		   
		   _set_if_expression("W1tTQVZFRF9DT05URU5UXV0uaW5kZXhPZigiRVJST1JfV1JPTkdfVVNFUl9LRVkiKSA+PSAw");
		   _if(VAR_SAVED_CONTENT.indexOf("ERROR_WRONG_USER_KEY") >= 0,function(){
		   
			  
			  
			  VAR_ERROR_KEY = "1"
			  

			  
			  
			  _break("function")
			  

		   })!
		   

		   
		   
		   _set_if_expression("W1tTQVZFRF9DT05URU5UXV0uaW5kZXhPZigiRVJST1JfWkVST19CQUxBTkNFIikgPj0gMA==");
		   _if(VAR_SAVED_CONTENT.indexOf("ERROR_ZERO_BALANCE") >= 0,function(){
		   
			  
			  
			  VAR_ERROR_BALANCE = "1"
			  

			  
			  
			  _break("function")
			  

		   })!
		   

		   
		   
		   _set_if_expression("W1tTQVZFRF9DT05URU5UXV0uaW5kZXhPZigiQ0FQVENIQV9GQUlMIikgPj0gMA==");
		   _if(VAR_SAVED_CONTENT.indexOf("CAPTCHA_FAIL") >= 0,function(){
		   
			  
			  
			  sleep(rand(1000,2000))!
			  

			  
			  
			  VAR_CAPTCHA_FAIL = parseInt(VAR_CAPTCHA_FAIL) + parseInt(1)
			  

			  
			  
			  _break("function")
			  

		   })!
		   

		   
		   
		   _cycle_params().if_else = VAR_SAVED_CONTENT.match(/[0-9]/) || VAR_SAVED_CONTENT == "sorry" || VAR_SAVED_CONTENT == "notpic";
		   _set_if_expression("W1tTQVZFRF9DT05URU5UXV0ubWF0Y2goL1swLTldLykgfHwgW1tTQVZFRF9DT05URU5UXV0gPT0gInNvcnJ5IiB8fCBbW1NBVkVEX0NPTlRFTlRdXSA9PSAibm90cGljIg==");
		   _if(_cycle_params().if_else,function(){
		   
			  
			  
			  VAR_ERROR_CAPTCHA_UNSOLVABLE_MODULE = 0
			  

			  
			  
			  VAR_LISTS_SQUARE = VAR_SAVED_CONTENT
			  

			  
			  
			  _set_if_expression("W1tMSVNUU19TUVVBUkVdXS5pbmRleE9mKCJjb29yZGluYXRlcyIpID49IDA=");
			  _if(VAR_LISTS_SQUARE.indexOf("coordinates") >= 0,function(){
			  
				 
				 
				 /*Browser*/
				 ;_SELECTOR=VAR_RECAPTCHA_PREFIX_SECOND_FRAME + "\u003eXPATH\u003e id(\u0022recaptcha-reload-button\u0022)";
				 get_element_selector(_SELECTOR, false).nowait().exist()!
				 VAR_IS_EXISTS = _result() == 1
				 _if(VAR_IS_EXISTS, function(){
				 get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
				 VAR_IS_EXISTS = _result().indexOf("true")>=0
				 })!
				 

				 
				 
				 _set_if_expression("W1tJU19FWElTVFNdXQ==");
				 _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
				 
					
					
					/*Browser*/
					cache_data_clear()!
					

					
					
					VAR_BAS_CAPMONSTER_IMAGE_ID = 0
					

					
					
					/*Browser*/
					_SELECTOR = VAR_RECAPTCHA_PREFIX_SECOND_FRAME + "\u003eXPATH\u003e id(\u0022recaptcha-reload-button\u0022)";
					wait_element_visible(_SELECTOR)!
					_call(_random_point, {})!
					_if(_result().length > 0, function(){
					move( {"speed": VAR_SPEED,"gravity": VAR_GRAVITY,"deviation": VAR_DEVIATION} )!
					get_element_selector(_SELECTOR, false).clarify(X,Y)!
					_call(_clarify, {"speed": VAR_SPEED,"gravity": VAR_GRAVITY,"deviation": VAR_DEVIATION} )!
					mouse(X,Y)!
					})!
					

					
					
					_break("function")
					

				 })!
				 

			  })!
			  

			  
			  
			  _set_if_expression("W1tMSVNUU19TUVVBUkVdXSA9PSAic29ycnkiIHx8IFtbTElTVFNfU1FVQVJFXV0gPT0gIm5vdHBpYyI=");
			  _if(VAR_LISTS_SQUARE == "sorry" || VAR_LISTS_SQUARE == "notpic",function(){
			  
				 
				 
				 VAR_BAS_CAPMONSTER_IMAGE_ID = 0
				 

				 
				 
				 _set_if_expression("W1tSRUNBUFRDSEFfMl9JTlZJU0lCTEVdXSA9PSAx");
				 _if(VAR_RECAPTCHA_2_INVISIBLE == 1,function(){
				 
					
					
					VAR_RECAPTCHA_2_INVISIBLE = parseInt(VAR_RECAPTCHA_2_INVISIBLE) + parseInt(1)
					

				 })!
				 

				 
				 
				 /*Browser*/
				 cache_data_clear()!
				 

				 
				 
				 /*Browser*/
				 _SELECTOR = VAR_RECAPTCHA_PREFIX_SECOND_FRAME + "\u003eCSS\u003e #recaptcha-verify-button";
				 wait_element_visible(_SELECTOR)!
				 _call(_random_point, {})!
				 _if(_result().length > 0, function(){
				 move( {"speed": VAR_SPEED,"gravity": VAR_GRAVITY,"deviation": VAR_DEVIATION} )!
				 get_element_selector(_SELECTOR, false).clarify(X,Y)!
				 _call(_clarify, {"speed": VAR_SPEED,"gravity": VAR_GRAVITY,"deviation": VAR_DEVIATION} )!
				 mouse(X,Y)!
				 })!
				 

				 
				 
				 sleep(100)!
				 

				 
				 
				 _break("function")
				 

			  })!
			  

			  
			  
			  VAR_LISTS_SQUARE = native("regexp", "scan", JSON.stringify({text: VAR_LISTS_SQUARE,regexp:("[0-9]+").toString()}))
			  if(VAR_LISTS_SQUARE.length == 0)
			  VAR_LISTS_SQUARE = []
			  else
			  VAR_LISTS_SQUARE = JSON.parse(VAR_LISTS_SQUARE)
			  

			  
			  
			  ;(function (a) {var j, x, i;for (i = a.length; i; i--) {j = Math.floor(Math.random() * i);x = a[i - 1]; a[i - 1] = a[j];a[j] = x;}})(VAR_LISTS_SQUARE)
			  

			  
			  
			  VAR_FOREACH_DATA = 0
			  

			  
			  
			  _do_with_params({"foreach_data":(VAR_LISTS_SQUARE)},function(){
			  _set_action_info({ name: "Foreach" });
			  VAR_CYCLE_INDEX = _iterator() - 1
			  if(VAR_CYCLE_INDEX > _cycle_param("foreach_data").length - 1)_break();
			  VAR_FOREACH_DATA = _cycle_param("foreach_data")[VAR_CYCLE_INDEX]
			  
				 
				 
				 VAR_FOREACH_DATA = Number(VAR_FOREACH_DATA)+3;
				 if (VAR_FOREACH_DATA == 4)
				 {
				 VAR_PIC_X = VAR_FIRST_PIC_X
				 VAR_PIC_Y = VAR_FIRST_PIC_Y
				 }
				 if (VAR_FOREACH_DATA == 5)
				 {
				 VAR_PIC_X = VAR_SECOND_PIC_X
				 VAR_PIC_Y = VAR_SECOND_PIC_Y
				 }
				 if (VAR_FOREACH_DATA == 6)
				 {
				 VAR_PIC_X = VAR_THIRD_PIC_X
				 VAR_PIC_Y = VAR_THIRD_PIC_Y
				 }
				 if (VAR_FOREACH_DATA == 7)
				 {
				 VAR_PIC_X = VAR_FOUR_PIC_X
				 VAR_PIC_Y = VAR_FOUR_PIC_Y
				 }
				 if (VAR_FOREACH_DATA == 8)
				 {
				 VAR_PIC_X = VAR_FIVE_PIC_X
				 VAR_PIC_Y = VAR_FIVE_PIC_Y
				 }
				 if (VAR_FOREACH_DATA == 9)
				 {
				 VAR_PIC_X = VAR_SIX_PIC_X
				 VAR_PIC_Y = VAR_SIX_PIC_Y
				 }
				 if (VAR_FOREACH_DATA == 10)
				 {
				 VAR_PIC_X = VAR_SEVEN_PIC_X
				 VAR_PIC_Y = VAR_SEVEN_PIC_Y
				 }
				 if (VAR_FOREACH_DATA == 11)
				 {
				 VAR_PIC_X = VAR_EIGHT_PIC_X
				 VAR_PIC_Y = VAR_EIGHT_PIC_Y
				 }
				 if (VAR_FOREACH_DATA == 12)
				 {
				 VAR_PIC_X = VAR_NINE_PIC_X
				 VAR_PIC_Y = VAR_NINE_PIC_Y
				 }
				 if (VAR_FOREACH_DATA == 13)
				 {
				 VAR_PIC_X = VAR_TEN_PIC_X
				 VAR_PIC_Y = VAR_TEN_PIC_Y
				 }
				 if (VAR_FOREACH_DATA == 14)
				 {
				 VAR_PIC_X = VAR_ELEVEN_PIC_X
				 VAR_PIC_Y = VAR_ELEVEN_PIC_Y
				 }
				 if (VAR_FOREACH_DATA == 15)
				 {
				 VAR_PIC_X = VAR_TWELVE_PIC_X
				 VAR_PIC_Y = VAR_TWELVE_PIC_Y
				 }
				 if (VAR_FOREACH_DATA == 16)
				 {
				 VAR_PIC_X = VAR_THIRTEEN_PIC_X
				 VAR_PIC_Y = VAR_THIRTEEN_PIC_Y
				 }
				 if (VAR_FOREACH_DATA == 17)
				 {
				 VAR_PIC_X = VAR_FOURTEEN_PIC_X
				 VAR_PIC_Y = VAR_FOURTEEN_PIC_Y
				 }
				 if (VAR_FOREACH_DATA == 18)
				 {
				 VAR_PIC_X = VAR_FIVETEEN_PIC_X
				 VAR_PIC_Y = VAR_FIVETEEN_PIC_Y
				 }
				 if (VAR_FOREACH_DATA == 19)
				 {
				 VAR_PIC_X = VAR_SIXTEEN_PIC_X
				 VAR_PIC_Y = VAR_SIXTEEN_PIC_Y
				 }
				 

				 
				 
				 _set_if_expression("cmFuZCAoMSwxMCkgPiA4ICYmIFtbSVM0NF1dID09IHRydWU=");
				 _if(rand (1,10) > 8 && VAR_IS44 == true,function(){
				 
					
					
					sleep(100)!
					

				 })!
				 

				 
				 
				 _set_if_expression("W1tJUzMzXV0gPT0gdHJ1ZQ==");
				 _if(VAR_IS33 == true,function(){
				 
					
					
					/*Browser*/
					cache_data_clear()!
					

				 })!
				 

				 
				 
				 _set_if_expression("W1tFUlJPUl9FWElTVFNdXSA9PSBmYWxzZQ==");
				 _if(VAR_ERROR_EXISTS == false,function(){
				 
					
					
					_set_if_expression("W1tJUzMzXV0gPT0gdHJ1ZQ==");
					_if(VAR_IS33 == true,function(){
					
					   
					   
					   VAR_PIC_X_CLICK = 0;
					   VAR_PIC_Y_CLICK = 0;
					   VAR_PIC_X_CLICK = VAR_PIC_X + rand(-10,+10);
					   VAR_PIC_Y_CLICK = VAR_PIC_Y + rand(-10,+10);
					   

					   
					   
					   /*Browser*/
					   move(VAR_PIC_X_CLICK,VAR_PIC_Y_CLICK,  {"speed": VAR_SPEED,"gravity": VAR_GRAVITY,"deviation": VAR_DEVIATION} )!
					   mouse(VAR_PIC_X_CLICK,VAR_PIC_Y_CLICK)!
					   

					})!
					

					
					
					_set_if_expression("W1tJUzQ0XV0gPT0gdHJ1ZQ==");
					_if(VAR_IS44 == true,function(){
					
					   
					   
					   VAR_PIC_X_CLICK = 0;
					   VAR_PIC_Y_CLICK = 0;
					   VAR_PIC_X_CLICK = VAR_PIC_X + rand(-5,+5);
					   VAR_PIC_Y_CLICK = VAR_PIC_Y + rand(-5,+5);
					   

					   
					   
					   /*Browser*/
					   move(VAR_PIC_X_CLICK,VAR_PIC_Y_CLICK,  {"speed": VAR_SPEED,"gravity": VAR_GRAVITY,"deviation": VAR_DEVIATION} )!
					   mouse(VAR_PIC_X_CLICK,VAR_PIC_Y_CLICK)!
					   

					})!
					

				 })!
				 

				 
				 
				 _set_if_expression("W1tFUlJPUl9FWElTVFNdXSA9PSB0cnVl");
				 _if(VAR_ERROR_EXISTS == true,function(){
				 
					
					
					VAR_PIC_X_CLICK = 0;
					VAR_PIC_Y_CLICK = 0;
					VAR_PIC_X_CLICK = VAR_PIC_X + rand(-4,+4);
					VAR_PIC_Y_CLICK = VAR_PIC_Y + rand(-4,+4);
					

					
					
					/*Browser*/
					move(VAR_PIC_X_CLICK,VAR_PIC_Y_CLICK,  {"speed": VAR_SPEED,"gravity": VAR_GRAVITY,"deviation": VAR_DEVIATION} )!
					mouse(VAR_PIC_X_CLICK,VAR_PIC_Y_CLICK)!
					

				 })!
				 

				 
				 
				 _set_if_expression("W1tJUzMzXV0gPT0gdHJ1ZQ==");
				 _if(VAR_IS33 == true,function(){
				 
					
					
					/*Browser*/
					;_SELECTOR=VAR_RECAPTCHA_PREFIX_SECOND_FRAME + "\u003eXPATH\u003e//*[@class=\u0022rc-imageselect-tile rc-imageselect-tileselected\u0022]";
					get_element_selector(_SELECTOR, false).nowait().exist()!
					VAR_IS_EXISTS = _result() == 1
					_if(VAR_IS_EXISTS, function(){
					get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
					VAR_IS_EXISTS = _result().indexOf("true")>=0
					})!
					

					
					
					_set_if_expression("W1tJU19FWElTVFNdXSA9PSBmYWxzZQ==");
					_if(VAR_IS_EXISTS == false,function(){
					
					   
					   
					   if (VAR_FOREACH_DATA == 4)
					   {
					   VAR_X_IMAGE = 0;
					   VAR_Y_IMAGE = 0;
					   }
					   if (VAR_FOREACH_DATA == 5)
					   {
					   VAR_X_IMAGE = 100;
					   VAR_Y_IMAGE = 0;
					   }
					   if (VAR_FOREACH_DATA == 6)
					   {
					   VAR_X_IMAGE = 200;
					   VAR_Y_IMAGE = 0;
					   }
					   if (VAR_FOREACH_DATA == 7)
					   {
					   VAR_X_IMAGE = 0;
					   VAR_Y_IMAGE = 100;
					   }
					   if (VAR_FOREACH_DATA == 8)
					   {
					   VAR_X_IMAGE = 100;
					   VAR_Y_IMAGE = 100;
					   }
					   if (VAR_FOREACH_DATA == 9)
					   {
					   VAR_X_IMAGE = 200;
					   VAR_Y_IMAGE = 100;
					   }
					   if (VAR_FOREACH_DATA == 10)
					   {
					   VAR_X_IMAGE = 0;
					   VAR_Y_IMAGE = 200;
					   }
					   if (VAR_FOREACH_DATA == 11)
					   {
					   VAR_X_IMAGE = 100;
					   VAR_Y_IMAGE = 200;
					   }
					   if (VAR_FOREACH_DATA == 12)
					   {
					   VAR_X_IMAGE = 200;
					   VAR_Y_IMAGE = 200;
					   }
					   

					   
					   
					   /*Browser*/
					   ;_SELECTOR=VAR_RECAPTCHA_PREFIX_SECOND_FRAME_ELEMENT;
					   get_element_selector(_SELECTOR, false).nowait().exist()!
					   VAR_IS_EXISTS = _result() == 1
					   _if(VAR_IS_EXISTS, function(){
					   get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
					   VAR_IS_EXISTS = _result().indexOf("true")>=0
					   })!
					   

					   
					   
					   _cycle_params().if_else = typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined;
					   _set_if_expression("W1tJU19FWElTVFNdXQ==");
					   _if(_cycle_params().if_else,function(){
					   
						  
						  
						  VAR_RECAPTCHA_2_CLOSED = 0
						  

					   })!
					   

					   
					   
					   _if(!_cycle_params().if_else,function(){
					   
						  
						  
						  VAR_RECAPTCHA_2_CLOSED = "1"
						  

						  
						  
						  _break("function")
						  

					   })!
					   delete _cycle_params().if_else;
					   

					   
					   
					   VAR_SAVED_CROP_IMAGE = "not_exists_pic"
					   

					   
					   
					   _do(function(){
					   _set_action_info({ name: "For" });
					   VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
					   if(VAR_CYCLE_INDEX > parseInt(60))_break();
					   
						  
						  
						  /*Browser*/
						  ;_SELECTOR=VAR_RECAPTCHA_PREFIX_SECOND_FRAME_ELEMENT;
						  get_element_selector(_SELECTOR, false).nowait().exist()!
						  VAR_IS_EXISTS = _result() == 1
						  _if(VAR_IS_EXISTS, function(){
						  get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
						  VAR_IS_EXISTS = _result().indexOf("true")>=0
						  })!
						  

						  
						  
						  _set_if_expression("IVtbSVNfRVhJU1RTXV0=");
						  _if(!VAR_IS_EXISTS,function(){
						  
							 
							 
							 VAR_RECAPTCHA_2_CLOSED = 1
							 

							 
							 
							 _break("function")
							 

						  })!
						  

						  
						  
						  cache_get_base64("recaptcha/*/payload")!
						  var image_id = native("imageprocessing", "load", _result())
						  var image_size = native("imageprocessing", "getsize", image_id)
						  var image_h = parseInt(image_size.split(",")[1])
						  //// Не удалось дождатся пикчу (загрузилcя белый квадрат в сетке 3x3)
						  if (image_h == 0 && VAR_CYCLE_INDEX > 40) _break()
						  //// Ждём в кэше маленькую картинку
						  if (image_h > 49) {
						  VAR_SAVED_CROP_IMAGE = _result()
						  _break()
						  }
						  sleep(400)!
						  

					   })!
					   

					   
					   
					   _set_if_expression("W1tSRUNBUFRDSEFfMl9DTE9TRURdXSA9PSAx");
					   _if(VAR_RECAPTCHA_2_CLOSED == 1,function(){
					   
						  
						  
						  _break("function")
						  

					   })!
					   

					   
					   
					   _set_if_expression("dHlwZW9mIFtbU0FWRURfQ1JPUF9JTUFHRV1dID09ICd1bmRlZmluZWQn");
					   _if(typeof VAR_SAVED_CROP_IMAGE == 'undefined',function(){
					   
						  
						  
						  /*Browser*/
						  ;_SELECTOR=VAR_RECAPTCHA_PREFIX_SECOND_FRAME + "\u003eXPATH\u003e id(\u0022recaptcha-reload-button\u0022)";
						  get_element_selector(_SELECTOR, false).nowait().exist()!
						  VAR_IS_EXISTS = _result() == 1
						  _if(VAR_IS_EXISTS, function(){
						  get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
						  VAR_IS_EXISTS = _result().indexOf("true")>=0
						  })!
						  

						  
						  
						  _set_if_expression("W1tJU19FWElTVFNdXQ==");
						  _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
						  
							 
							 
							 VAR_BAS_CAPMONSTER_IMAGE_ID = 0
							 

							 
							 
							 /*Browser*/
							 cache_data_clear()!
							 

							 
							 
							 /*Browser*/
							 _SELECTOR = VAR_RECAPTCHA_PREFIX_SECOND_FRAME + "\u003eXPATH\u003e id(\u0022recaptcha-reload-button\u0022)";
							 wait_element_visible(_SELECTOR)!
							 _call(_random_point, {})!
							 _if(_result().length > 0, function(){
							 move( {"speed": VAR_SPEED,"gravity": VAR_GRAVITY,"deviation": VAR_DEVIATION} )!
							 get_element_selector(_SELECTOR, false).clarify(X,Y)!
							 _call(_clarify, {"speed": VAR_SPEED,"gravity": VAR_GRAVITY,"deviation": VAR_DEVIATION} )!
							 mouse(X,Y)!
							 })!
							 

						  })!
						  

						  
						  
						  _break("function")
						  

					   })!
					   

					   
					   
					   _set_if_expression("W1tTQVZFRF9DUk9QX0lNQUdFXV0gPT0gIm5vdF9leGlzdHNfcGljIg==");
					   _if(VAR_SAVED_CROP_IMAGE == "not_exists_pic",function(){
					   
						  
						  
						  /*Browser*/
						  ;_SELECTOR=VAR_RECAPTCHA_PREFIX_SECOND_FRAME + "\u003eXPATH\u003e id(\u0022recaptcha-reload-button\u0022)";
						  get_element_selector(_SELECTOR, false).nowait().exist()!
						  VAR_IS_EXISTS = _result() == 1
						  _if(VAR_IS_EXISTS, function(){
						  get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
						  VAR_IS_EXISTS = _result().indexOf("true")>=0
						  })!
						  

						  
						  
						  _set_if_expression("W1tJU19FWElTVFNdXQ==");
						  _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
						  
							 
							 
							 VAR_BAS_CAPMONSTER_IMAGE_ID = 0
							 

							 
							 
							 /*Browser*/
							 cache_data_clear()!
							 

							 
							 
							 /*Browser*/
							 _SELECTOR = VAR_RECAPTCHA_PREFIX_SECOND_FRAME + "\u003eXPATH\u003e id(\u0022recaptcha-reload-button\u0022)";
							 wait_element_visible(_SELECTOR)!
							 _call(_random_point, {})!
							 _if(_result().length > 0, function(){
							 move( {"speed": VAR_SPEED,"gravity": VAR_GRAVITY,"deviation": VAR_DEVIATION} )!
							 get_element_selector(_SELECTOR, false).clarify(X,Y)!
							 _call(_clarify, {"speed": VAR_SPEED,"gravity": VAR_GRAVITY,"deviation": VAR_DEVIATION} )!
							 mouse(X,Y)!
							 })!
							 

						  })!
						  

						  
						  
						  _break("function")
						  

					   })!
					   

					   
					   
					   VAR_IMAGE_BASE_64 = native("imageprocessing", "load", VAR_IMAGE_BASE_64)
					   

					   
					   
					   VAR_LOADED_CROP = native("imageprocessing", "load", VAR_SAVED_CROP_IMAGE)
					   

					   
					   
					   _set_if_expression("W1tSRUNBUFRDSEFfMl9JTlZJU0lCTEVdXSA9PSAx");
					   _if(VAR_RECAPTCHA_2_INVISIBLE == 1,function(){
					   
						  
						  
						  native("imageprocessing", "resize", (VAR_IMAGE_BASE_64) + "," + (300) + "," + (300))
						  

						  
						  
						  VAR_RECAPTCHA_2_INVISIBLE = parseInt(VAR_RECAPTCHA_2_INVISIBLE) + parseInt(1)
						  

					   })!
					   

					   
					   
					   native("imageprocessing", "insert", (VAR_IMAGE_BASE_64) + "," + (VAR_LOADED_CROP) + ","  + (VAR_X_IMAGE) + "," + (VAR_Y_IMAGE))
					   

					   
					   
					   VAR_IMAGE_BASE_64 = native("imageprocessing", "getdata", VAR_IMAGE_BASE_64)
					   

					   
					   
					   native("imageprocessing", "delete", VAR_IMAGE_BASE_64)
					   

					   
					   
					   native("imageprocessing", "delete", VAR_LOADED_CROP)
					   

					   
					   
					   _set_if_expression("W1tSRUNBUFRDSEFfMl9JTlZJU0lCTEVdXSAgPT0gOTk5OTk5OQ==");
					   _if(VAR_RECAPTCHA_2_INVISIBLE  == 9999999,function(){
					   
						  
						  
						  VAR_THREAD_INDEX = thread_number()
						  

						  
						  
						  native("filesystem", "writefile", JSON.stringify({path: "C:\u005cImages\u005cRecaptcha2" + VAR_THREAD_INDEX + ".png",value: (VAR_IMAGE_BASE_64).toString(),base64:true,append:false}))
						  

						  
						  
						  native("filesystem", "writefile", JSON.stringify({path: "C:\u005cImages\u005cRecaptcha2_Crop" + VAR_THREAD_INDEX + ".png",value: (VAR_SAVED_CROP_IMAGE).toString(),base64:true,append:false}))
						  

					   })!
					   

					   
					   
					   VAR_BAS_CAPMONSTER_IMAGE_ID = 1
					   

					   
					   
					   sleep(100)!
					   

					})!
					

				 })!
				 

			  })!
			  

			  
			  
			  _set_if_expression("W1tSRUNBUFRDSEFfMl9DTE9TRURdXSA9PSAx");
			  _if(VAR_RECAPTCHA_2_CLOSED == 1,function(){
			  
				 
				 
				 _break("function")
				 

			  })!
			  

			  
			  
			  _set_if_expression("W1tJUzMzXV0gPT0gdHJ1ZQ==");
			  _if(VAR_IS33 == true,function(){
			  
				 
				 
				 /*Browser*/
				 ;_SELECTOR=VAR_RECAPTCHA_PREFIX_SECOND_FRAME + "\u003eXPATH\u003e//*[@class=\u0022rc-imageselect-tile rc-imageselect-tileselected\u0022]";
				 get_element_selector(_SELECTOR, false).nowait().exist()!
				 VAR_IS_EXISTS = _result() == 1
				 _if(VAR_IS_EXISTS, function(){
				 get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
				 VAR_IS_EXISTS = _result().indexOf("true")>=0
				 })!
				 

				 
				 
				 _set_if_expression("W1tJU19FWElTVFNdXQ==");
				 _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
				 
					
					
					/*Browser*/
					cache_data_clear()!
					

					
					
					/*Browser*/
					_SELECTOR = VAR_RECAPTCHA_PREFIX_SECOND_FRAME + "\u003eXPATH\u003e id(\u0022recaptcha-verify-button\u0022)";
					wait_element_visible(_SELECTOR)!
					_call(_random_point, {})!
					_if(_result().length > 0, function(){
					move( {"speed": VAR_SPEED,"gravity": VAR_GRAVITY,"deviation": VAR_DEVIATION} )!
					get_element_selector(_SELECTOR, false).clarify(X,Y)!
					_call(_clarify, {"speed": VAR_SPEED,"gravity": VAR_GRAVITY,"deviation": VAR_DEVIATION} )!
					mouse(X,Y)!
					})!
					

					
					
					sleep(100)!
					

				 })!
				 

				 
				 
				 /*Browser*/
				 ;_SELECTOR=VAR_RECAPTCHA_PREFIX_SECOND_FRAME + "\u003eXPATH\u003e //div[@class=\u0022rc-imageselect-error-select-more\u0022]";
				 get_element_selector(_SELECTOR, false).nowait().exist()!
				 VAR_IS_EXISTS_1 = _result() == 1
				 _if(VAR_IS_EXISTS_1, function(){
				 get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
				 VAR_IS_EXISTS_1 = _result().indexOf("true")>=0
				 })!
				 

				 
				 
				 /*Browser*/
				 ;_SELECTOR=VAR_RECAPTCHA_PREFIX_SECOND_FRAME + "\u003eXPATH\u003e //div[@class=\u0022rc-imageselect-error-dynamic-more\u0022]";
				 get_element_selector(_SELECTOR, false).nowait().exist()!
				 VAR_IS_EXISTS_2 = _result() == 1
				 _if(VAR_IS_EXISTS_2, function(){
				 get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
				 VAR_IS_EXISTS_2 = _result().indexOf("true")>=0
				 })!
				 

				 
				 
				 _set_if_expression("W1tJU19FWElTVFNfMV1dIHx8IFtbSVNfRVhJU1RTXzJdXQ==");
				 _if(VAR_IS_EXISTS_1 || VAR_IS_EXISTS_2,function(){
				 
					
					
					VAR_BAS_CAPMONSTER_IMAGE_ID = 0
					

					
					
					_set_if_expression("W1tSRUNBUFRDSEFfMl9JTlZJU0lCTEVdXSA9PSAx");
					_if(VAR_RECAPTCHA_2_INVISIBLE == 1,function(){
					
					   
					   
					   VAR_RECAPTCHA_2_INVISIBLE = parseInt(VAR_RECAPTCHA_2_INVISIBLE) + parseInt(1)
					   

					})!
					

					
					
					/*Browser*/
					cache_data_clear()!
					

					
					
					/*Browser*/
					_SELECTOR = VAR_RECAPTCHA_PREFIX_SECOND_FRAME + "\u003eXPATH\u003e id(\u0022recaptcha-reload-button\u0022)";
					wait_element_visible(_SELECTOR)!
					_call(_random_point, {})!
					_if(_result().length > 0, function(){
					move( {"speed": VAR_SPEED,"gravity": VAR_GRAVITY,"deviation": VAR_DEVIATION} )!
					get_element_selector(_SELECTOR, false).clarify(X,Y)!
					_call(_clarify, {"speed": VAR_SPEED,"gravity": VAR_GRAVITY,"deviation": VAR_DEVIATION} )!
					mouse(X,Y)!
					})!
					

				 })!
				 

			  })!
			  

			  
			  
			  _set_if_expression("W1tJUzQ0XV0gPT0gdHJ1ZQ==");
			  _if(VAR_IS44 == true,function(){
			  
				 
				 
				 /*Browser*/
				 cache_data_clear()!
				 

				 
				 
				 /*Browser*/
				 _SELECTOR = VAR_RECAPTCHA_PREFIX_SECOND_FRAME + "\u003eXPATH\u003e id(\u0022recaptcha-verify-button\u0022)";
				 wait_element_visible(_SELECTOR)!
				 _call(_random_point, {})!
				 _if(_result().length > 0, function(){
				 move( {"speed": VAR_SPEED,"gravity": VAR_GRAVITY,"deviation": VAR_DEVIATION} )!
				 get_element_selector(_SELECTOR, false).clarify(X,Y)!
				 _call(_clarify, {"speed": VAR_SPEED,"gravity": VAR_GRAVITY,"deviation": VAR_DEVIATION} )!
				 mouse(X,Y)!
				 })!
				 

				 
				 
				 sleep(100)!
				 

			  })!
			  

			  
			  
			  _set_if_expression("W1tSRUNBUFRDSEFfMl9JTlZJU0lCTEVdXSA9PSAx");
			  _if(VAR_RECAPTCHA_2_INVISIBLE == 1,function(){
			  
				 
				 
				 VAR_RECAPTCHA_2_INVISIBLE = parseInt(VAR_RECAPTCHA_2_INVISIBLE) + parseInt(1)
				 

			  })!
			  
			  
			  sleep(rand(200,500))!
			  

			  
			  
			  _break("function")
			  

		   })!
		   

		   
		   
		   _if(!_cycle_params().if_else,function(){
		   
			  
			  
			  sleep(1000)!
			  

			  
			  
			  VAR_ERROR_CAPTCHA_UNSOLVABLE_MODULE = parseInt(VAR_ERROR_CAPTCHA_UNSOLVABLE_MODULE) + parseInt(1)
			  

			  
			  
			  /*Browser*/
			  ;_SELECTOR=VAR_RECAPTCHA_PREFIX_SECOND_FRAME + "\u003eXPATH\u003e id(\u0022recaptcha-reload-button\u0022)";
			  get_element_selector(_SELECTOR, false).nowait().exist()!
			  VAR_IS_EXISTS = _result() == 1
			  _if(VAR_IS_EXISTS, function(){
			  get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
			  VAR_IS_EXISTS = _result().indexOf("true")>=0
			  })!
			  

			  
			  
			  _set_if_expression("W1tJU19FWElTVFNdXQ==");
			  _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
			  
				 
				 
				 /*Browser*/
				 cache_data_clear()!
				 

				 
				 
				 /*Browser*/
				 _SELECTOR = VAR_RECAPTCHA_PREFIX_SECOND_FRAME + "\u003eXPATH\u003e id(\u0022recaptcha-reload-button\u0022)";
				 wait_element_visible(_SELECTOR)!
				 _call(_random_point, {})!
				 _if(_result().length > 0, function(){
				 move( {"speed": VAR_SPEED,"gravity": VAR_GRAVITY,"deviation": VAR_DEVIATION} )!
				 get_element_selector(_SELECTOR, false).clarify(X,Y)!
				 _call(_clarify, {"speed": VAR_SPEED,"gravity": VAR_GRAVITY,"deviation": VAR_DEVIATION} )!
				 mouse(X,Y)!
				 })!
				 

			  })!
			  

			  
			  
			  _break("function")
			  

		   })!
		   delete _cycle_params().if_else;
		   

		})!
		

	 },null)!
	 

	 
	 
	 _set_if_expression("W1tXQVNfRVJST1JdXQ==");
	 _if(typeof(VAR_WAS_ERROR) !== "undefined" ? (VAR_WAS_ERROR) : undefined,function(){
	 
		
		
		_set_if_expression("W1tMQVNUX0VSUk9SXV0gPT09ICdBYm9ydGVkIEJ5IFVzZXInIHx8IFtbTEFTVF9FUlJPUl1dICA9PT0gJ9Cf0YDQtdGA0LLQsNC90L4g0J/QvtC70YzQt9C+0LLQsNGC0LXQu9C10Lwn");
		_if(VAR_LAST_ERROR === 'Aborted By User' || VAR_LAST_ERROR  === 'Прервано Пользователем',function(){
		
		   
		   
		   _function_return(false)
		   

		})!
		

		
		
		sleep(1000)!
		

		
		
		VAR_BAS_CAPMONSTER_IMAGE_ID = 0
		

		
		
		_set_if_expression("W1tSRUNBUFRDSEFfMl9JTlZJU0lCTEVdXSA9PSAx");
		_if(VAR_RECAPTCHA_2_INVISIBLE == 1,function(){
		
		   
		   
		   VAR_RECAPTCHA_2_INVISIBLE = parseInt(VAR_RECAPTCHA_2_INVISIBLE) + parseInt(1)
		   

		})!
		

		
		
		_set_if_expression("W1tMQVNUX0VSUk9SXV0uaW5kZXhPZigicGF5bG9hZCIpID49IDAg");
		_if(VAR_LAST_ERROR.indexOf("payload") >= 0 ,function(){
		
		   
		   
		   _call(function()
		   {
		   _on_fail(function(){
		   VAR_LAST_ERROR = _result()
		   VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
		   VAR_WAS_ERROR = false
		   _break(1,true)
		   })
		   CYCLES.Current().RemoveLabel("function")
		   
			  
			  
			  /*Browser*/
			  ;_SELECTOR=VAR_RECAPTCHA_PREFIX_SECOND_FRAME + "\u003eXPATH\u003e id(\u0022recaptcha-reload-button\u0022)";
			  get_element_selector(_SELECTOR, false).nowait().exist()!
			  VAR_IS_EXISTS = _result() == 1
			  _if(VAR_IS_EXISTS, function(){
			  get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
			  VAR_IS_EXISTS = _result().indexOf("true")>=0
			  })!
			  

			  
			  
			  _set_if_expression("W1tJU19FWElTVFNdXQ==");
			  _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
			  
				 
				 
				 /*Browser*/
				 cache_data_clear()!
				 

				 
				 
				 /*Browser*/
				 _SELECTOR = VAR_RECAPTCHA_PREFIX_SECOND_FRAME + "\u003eXPATH\u003e id(\u0022recaptcha-reload-button\u0022)";
				 wait_element_visible(_SELECTOR)!
				 _call(_random_point, {})!
				 _if(_result().length > 0, function(){
				 move( {"speed": VAR_SPEED,"gravity": VAR_GRAVITY,"deviation": VAR_DEVIATION} )!
				 get_element_selector(_SELECTOR, false).clarify(X,Y)!
				 _call(_clarify, {"speed": VAR_SPEED,"gravity": VAR_GRAVITY,"deviation": VAR_DEVIATION} )!
				 mouse(X,Y)!
				 })!
				 

			  })!
			  

		   },null)!
		   

		})!
		

	 })!
	 

	 
	 
	 _next("function")
	 

	})!
      

   }
   

function GoodXevilPaySolver_GXP_hCaptcha_CacheAllow()
   {
   
      
      
      /*Browser*/
      cache_allow("*hcaptcha.com/getcaptcha*")!
      

      
      
      /*Browser*/
      cache_allow("*img*hcaptcha.com/*")!
      

   }
   

function GoodXevilPaySolver_GXP_Allow_FunCaptcha_Cache()
   {
   
      
      
      /*Browser*/
      cache_allow("*blob*")!
      

      
      
      /*Browser*/
      cache_allow("*/fc/gfc*")!
      

      
      
      /*Browser*/
      cache_allow("*/rtig/image*")!
      

   }
   

function GoodXevilPaySolver_GXP_Solve_Funcaptcha()
   {
   
      
      
      VAR_GLOBAL_SELECTOR = _function_argument("CaptchaSelector")
      

      
      
      VAR_KEY_MODULE = _function_argument("APIKey")
      

      
      
      VAR_TRY_MAX_CAPTCHA_PICTURE = _function_argument("MaxLimitTask")
      

      
      
      VAR_NUMBER_CAPTCHA_MODULE = _function_argument("CaptchaNumber")
      

      
      
	VAR_CYCLE_INDEX = 0




	VAR_FUNCAPTCHA_TYPE = "0"




	VAR_ERROR_LOAD = "0"




	VAR_CACHE_ERROR = "0"




	VAR_ERROR_SOLVE = "0"




	VAR_ERROR_TASK = "0"




	VAR_ERROR_FIND_MAIN_SELECTOR = "0"




	VAR_ERROR_CAPTCHA_UNSOLVABLE_MODULE = 0




	VAR_ERROR_LOAD_NEXT_PICTURE_FUNCAPTCHA = 0




	VAR_FUNCAPTCHA_PREFIX_SECOND_FRAME = ""




	VAR_RECAPTCHA_MODULE_ENABLED = 0




	VAR_HCAPTCHA_MODULE_ENABLED = 0




	VAR_FUNCAPTCHA_MODULE_ENABLED = 0




	VAR_NAME_MODULE_AUTOSUBMIT = "NaN"




	VAR_SQUARE_NUMBER_3 = 0




	VAR_RESULT_SELECTOR = 0




	VAR_TILE_NORMAL_VIEW = 0




	VAR_SET_TASK = ""




	VAR_CURRENT_TASK_NUMBER_SOLVE = 0




	VAR_CURRENT_TASK_NUMBERS = 1




	VAR_ALL_TASK_NUMBERS = 1




	VAR_GREEN_TICK = false




	VAR_RAND_MODULE_IMAGE = "0"




	VAR_NUMBER_WAIT_TASK = rand(65,90)




	VAR_ERROR_WAIT_TASK_FUNCAPTCHA = 0




	VAR_ALL_JSON_FUNCAP = ""




	VAR_SET_TASK = ""




	VAR_ERROR_TASK_GAME_LITE = 0




	VAR_SAVED_CACHE_MODULE = ""




	VAR_CHECK_EMPTY_BODY = ""




	VAR_OLD_VERSION_BAS_MODULE = 0




	_call(function()
	{
	_on_fail(function(){
	VAR_LAST_ERROR = _result()
	VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
	VAR_WAS_ERROR = false
	_break(1,true)
	})
	CYCLES.Current().RemoveLabel("function")

	 
	 
	 {
	 var info = _get_current_browser_version_info("extended")
	 VAR_BROWSER_VERSION_ID = info.id
	 VAR_BROWSER_VERSION_STRING = info.browser_version
	 VAR_BROWSER_ARCHITECTURE = info.architecture
	 }
	 

	 
	 
	 //// Проверить установлены ли модули с автосабмитом.
	 if (typeof NumbersParseRecaptcha2 === 'function') VAR_RECAPTCHA_MODULE_ENABLED = 1, VAR_NAME_MODULE_AUTOSUBMIT = "ReCaptcha 2 Autosubmit";
	 if (typeof BASCaptchaSolver.helpers.HCaptchaHelper === 'function') VAR_HCAPTCHA_MODULE_ENABLED = 1, VAR_NAME_MODULE_AUTOSUBMIT = "hCaptcha Autosubmit";
	 if (typeof BASCaptchaSolver.helpers.FunCaptchaHelper === 'function') VAR_FUNCAPTCHA_MODULE_ENABLED = 1, VAR_NAME_MODULE_AUTOSUBMIT = "FunCaptcha Autosubmit";
	 //// Проверить версию BAS. Версия BAS 25.3.0 имеет движок версии 118
	 var VersionBrowserStringModule = VAR_BROWSER_VERSION_STRING;
	 var NumbersBeforeDotModule = VersionBrowserStringModule.split('.')[0];
	 var BrowserVersionIntModule = parseInt(NumbersBeforeDotModule);
	 if (BrowserVersionIntModule < 118) VAR_OLD_VERSION_BAS_MODULE = 1;
	 

	},null)!




	_set_if_expression("W1tGVU5DQVBUQ0hBX01PRFVMRV9FTkFCTEVEXV0gPT0gMSB8fCBbW1JFQ0FQVENIQV9NT0RVTEVfRU5BQkxFRF1dID09IDEgfHwgW1tIQ0FQVENIQV9NT0RVTEVfRU5BQkxFRF1dID09IDE=");
	_if(VAR_FUNCAPTCHA_MODULE_ENABLED == 1 || VAR_RECAPTCHA_MODULE_ENABLED == 1 || VAR_HCAPTCHA_MODULE_ENABLED == 1,function(){

	 
	 
	 /*Browser*/
	 cache_data_clear()!
	 

	 
	 
	 fail((_K==="en" ? "Solve the captcha failed, to continue solving captchas by clicks requires to disable module " +VAR_NAME_MODULE_AUTOSUBMIT + " and also remove all actions from the script associated with it and retry solve captcha again" : "Решить капчу не удалось, для продолжения решения капчи кликами требуется отключить сторонний встроенный модуль в BAS: " +VAR_NAME_MODULE_AUTOSUBMIT + ", а также удалить все действия из файла сценария связанные с ним и повторить попытку"));
	 

	})!




	_set_if_expression("W1tXQVNfRVJST1JdXSB8fCBbW09MRF9WRVJTSU9OX0JBU19NT0RVTEVdXSA9PSAx");
	_if(VAR_WAS_ERROR || VAR_OLD_VERSION_BAS_MODULE == 1,function(){

	 
	 
	 _set_if_expression("W1tMQVNUX0VSUk9SXV0uaW5kZXhPZigiZ2V0X2N1cnJlbnRfYnJvd3Nlcl92ZXJzaW9uX2luZm8iKSA+PSAwIHx8IFtbT0xEX1ZFUlNJT05fQkFTX01PRFVMRV1dID09IDE=");
	 _if(VAR_LAST_ERROR.indexOf("get_current_browser_version_info") >= 0 || VAR_OLD_VERSION_BAS_MODULE == 1,function(){
	 
		
		
		/*Browser*/
		cache_data_clear()!
		

		
		
		fail((_K==="en" ? "Captcha solved failed, for the version module" +VAR_BAS_MODULE_VERSION + " requires BAS version 26.3.0 or higher version" : "Решить капчу не удалось, для модуля версии " +VAR_BAS_MODULE_VERSION + " требуется установить версию BAS 26.3.0 или версию старше"));
		

	 })!
	 

	})!



	_call(function()
	{
	_on_fail(function(){
	VAR_LAST_ERROR = _result()
	VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
	VAR_WAS_ERROR = false
	_break(1,true)
	})
	CYCLES.Current().RemoveLabel("function")},null)!




	_call(function()
	{
	_on_fail(function(){
	VAR_LAST_ERROR = _result()
	VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
	VAR_WAS_ERROR = false
	_break(1,true)
	})
	CYCLES.Current().RemoveLabel("function")

	 VAR_SPEED = 200;
	 VAR_GRAVITY = 12;
	 VAR_DEVIATION = 5;
	 VAR_IS_MOBILE = _IS_MOBILE;
	 

	 
	 
	 _set_if_expression("W1tJU19NT0JJTEVdXSA9PSBmYWxzZSAmJiByYW5kICgxLDEwKSA+IDM=");
	 _if(VAR_IS_MOBILE == false && rand (1,10) > 3,function(){
	 
		
		
		_do(function(){
		_set_action_info({ name: "While" });
		VAR_CYCLE_INDEX = _iterator() - 1
		BREAK_CONDITION = VAR_CYCLE_INDEX < 2;
		if(!BREAK_CONDITION)_break();
		
		   
		   
		   _get_browser_screen_settings()!
		   ;(function(){
		   var result = JSON.parse(_result())
		   VAR_SCROLL_X = result["ScrollX"]
		   VAR_SCROLL_Y = result["ScrollY"]
		   VAR_CURSOR_X = result["CursorX"]
		   VAR_CURSOR_Y = result["CursorY"]
		   VAR_BROWSER_WIDTH = result["Width"]
		   VAR_BROWSER_HEIGHT = result["Height"]
		   })();
		   

		   
		   
		   var scroll_x=parseInt(VAR_CURSOR_Y);
		   var scroll_y=parseInt(VAR_SCROLL_Y);
		   var browser_h=parseInt(VAR_BROWSER_HEIGHT);
		   //-------------------- Привели все в числа, считаем позицию ---------------------
		   var absolut_y = VAR_CURSOR_Y + VAR_SCROLL_Y;
		   var y_without_scroll = absolut_y - VAR_SCROLL_Y;
		   var check_y_top = VAR_BROWSER_HEIGHT/12;
		   var check_y_down = VAR_BROWSER_HEIGHT/100*92;
		   var move_y_top = VAR_BROWSER_HEIGHT/10;
		   var move_y_down = VAR_BROWSER_HEIGHT/100*80;
		   // -------------------------- Округляем ----------------------------------
		   VAR_CHECK_Y_TOP = check_y_top.toFixed();
		   VAR_CHECK_Y_DOWN = check_y_down.toFixed();
		   VAR_Y_WITHOUNT_SCROLL = y_without_scroll.toFixed();
		   VAR_MOVE_Y_TOP = move_y_top.toFixed();
		   VAR_MOVE_Y_DOWN = move_y_down.toFixed();
		   // ----------------- Снова приводим к числу ------------------------
		   VAR_CHECK_Y_TOP=parseInt(VAR_CHECK_Y_TOP);
		   VAR_CHECK_Y_DOWN=parseInt(VAR_CHECK_Y_DOWN);
		   VAR_Y_WITHOUNT_SCROLL=parseInt(VAR_Y_WITHOUNT_SCROLL);
		   VAR_MOVE_Y_TOP=parseInt(VAR_MOVE_Y_TOP);
		   VAR_MOVE_Y_DOWN=parseInt(VAR_MOVE_Y_DOWN);
		   

		   
		   
		   /*Browser*/
		   move(rand(VAR_BROWSER_WIDTH/5,VAR_BROWSER_WIDTH/1.3),rand(VAR_MOVE_Y_TOP + VAR_SCROLL_Y,VAR_MOVE_Y_DOWN + VAR_SCROLL_Y),  {} )!
		   

		   
		   
		   _set_if_expression("cmFuZCAoMSwxMCkgPiA1");
		   _if(rand (1,10) > 5,function(){
		   
			  
			  
			  _break("function")
			  

		   })!
		   

		})!
		

	 })!
	 

	 
	 
	 VAR_FUNCAPTCHA_PREFIX = VAR_GLOBAL_SELECTOR;
	 VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME = VAR_FUNCAPTCHA_PREFIX;
	 {
	 var index = VAR_FUNCAPTCHA_PREFIX.toString().lastIndexOf(">FRAME>")
	 if(index >= 0)
	 VAR_FUNCAPTCHA_PREFIX = VAR_FUNCAPTCHA_PREFIX.substring(0,index)
	 VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME = VAR_FUNCAPTCHA_PREFIX
	 index = VAR_FUNCAPTCHA_PREFIX.toString().lastIndexOf(">FRAME>")
	 if(index >= 0)
	 VAR_FUNCAPTCHA_PREFIX = VAR_FUNCAPTCHA_PREFIX.substring(0,index + ">FRAME>".length)
	 else
	 VAR_FUNCAPTCHA_PREFIX = ""
	 index = VAR_FUNCAPTCHA_PREFIX.toString().lastIndexOf(">FRAME>")
	 if(index >= 0)
	 VAR_FUNCAPTCHA_PREFIX = VAR_FUNCAPTCHA_PREFIX.substring(0,index + ">FRAME>".length)
	 else
	 VAR_FUNCAPTCHA_PREFIX = ""
	 }
	 

	 
	 
	 _set_if_expression("W1tGVU5DQVBUQ0hBX1BSRUZJWF9TRUNPTkRfRlJBTUVdXSA9PSAiIg==");
	 _if(VAR_FUNCAPTCHA_PREFIX_SECOND_FRAME == "",function(){
	 
		
		
		_do(function(){
		_set_action_info({ name: "For" });
		VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
		if(VAR_CYCLE_INDEX > parseInt(50))_break();
		
		   
		   
		   /*Browser*/
		   ;_SELECTOR=VAR_GLOBAL_SELECTOR;
		   get_element_selector(_SELECTOR, false).nowait().exist()!
		   VAR_IS_EXISTS = _result() == 1
		   _if(VAR_IS_EXISTS, function(){
		   get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
		   VAR_IS_EXISTS = _result().indexOf("true")>=0
		   })!
		   

		   
		   
		   _cycle_params().if_else = typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined;
		   _set_if_expression("W1tJU19FWElTVFNdXQ==");
		   _if(_cycle_params().if_else,function(){
		   
			  
			  
			  /*Browser*/
			  _SELECTOR = VAR_GLOBAL_SELECTOR;waiter_timeout_next(8000)
			  wait_element_visible(_SELECTOR)!
			  _call(_random_point, {})!
			  _if(_result().length > 0, function(){
			  move( {} )!
			  get_element_selector(_SELECTOR, false).clarify(X,Y)!
			  _call(_clarify, {} )!
			  mouse(X,Y)!
			  })!
			  

			  
			  
			  _break("function")
			  

		   })!
		   

		   
		   
		   _if(!_cycle_params().if_else,function(){
		   
			  
			  
			  sleep(rand(700,1000))!
			  

		   })!
		   delete _cycle_params().if_else;
		   

		   
		   
		   _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gcmFuZCAoNDIsNTAp");
		   _if(VAR_CYCLE_INDEX > rand (42,50),function(){
		   
			  
			  
			  VAR_ERROR_FIND_MAIN_SELECTOR = "1"
			  

		   })!
		   

		})!
		

	 })!
	 

	},null)!




	_set_if_expression("W1tXQVNfRVJST1JdXQ==");
	_if(typeof(VAR_WAS_ERROR) !== "undefined" ? (VAR_WAS_ERROR) : undefined,function(){

	 
	 
	 _set_if_expression("W1tMQVNUX0VSUk9SXV0gPT09ICdBYm9ydGVkIEJ5IFVzZXInIHx8IFtbTEFTVF9FUlJPUl1dICA9PT0gJ9Cf0YDQtdGA0LLQsNC90L4g0J/QvtC70YzQt9C+0LLQsNGC0LXQu9C10Lwn");
	 _if(VAR_LAST_ERROR === 'Aborted By User' || VAR_LAST_ERROR  === 'Прервано Пользователем',function(){
	 
		
		
		_function_return(false)
		

	 })!
	 

	 
	 
	 /*Browser*/
	 cache_data_clear()!
	 

	 
	 
	 fail(VAR_LAST_ERROR)
	 

	})!




	_set_if_expression("W1tFUlJPUl9GSU5EX01BSU5fU0VMRUNUT1JdXSA9PSAx");
	_if(VAR_ERROR_FIND_MAIN_SELECTOR == 1,function(){

	 
	 
	 /*Browser*/
	 cache_data_clear()!
	 

	 
	 
	 fail((_K==="en" ? "Funcaptcha was not resolved. Failed to wait for the 'Open captcha' button to load (Сaptcha selector load timeout)" : "Funcaptcha не была решена. Не удалось дождаться загрузки кнопки 'Открыть каптчу' (таймаут поиска селектора капчи)."));
	 

	})!




	_call(function()
	{
	_on_fail(function(){
	VAR_LAST_ERROR = _result()
	VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
	VAR_WAS_ERROR = false
	_break(1,true)
	})
	CYCLES.Current().RemoveLabel("function")

	 
	 
	 _do(function(){
	 _set_action_info({ name: "For" });
	 VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
	 if(VAR_CYCLE_INDEX > parseInt(200))_break();
	 
		
		
		/*Browser*/
		is_load("*/fc/gfc*")!
		VAR_WAIT_LOAD_TASK = _result()
		

		
		
		/*Browser*/
		is_load("*game-lite-mode/fc*")!
		VAR_WAIT_LOAD_TASK_LITE = _result()
		

		
		
		_set_if_expression("W1tXQUlUX0xPQURfVEFTS11dID09IDEgfHwgW1tXQUlUX0xPQURfVEFTS19MSVRFXV0gPT0gMQ==");
		_if(VAR_WAIT_LOAD_TASK == 1 || VAR_WAIT_LOAD_TASK_LITE == 1,function(){
		
		   
		   
		   _break("function")
		   

		})!
		

		
		
		_set_if_expression("W1tDWUNMRV9JTkRFWF1dID49IFtbTlVNQkVSX1dBSVRfVEFTS11d");
		_if(VAR_CYCLE_INDEX >= VAR_NUMBER_WAIT_TASK,function(){
		
		   
		   
		   VAR_ERROR_WAIT_TASK_FUNCAPTCHA = 1
		   

		   
		   
		   _break("function")
		   

		})!
		

		
		
		_set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gW1tOVU1CRVJfV0FJVF9UQVNLXV0vMg==");
		_if(VAR_CYCLE_INDEX > VAR_NUMBER_WAIT_TASK/2,function(){
		
		   
		   
		   /*Browser*/
		   ;_SELECTOR=VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e div[class*=\u0027error box screen\u0027]";
		   get_element_selector(_SELECTOR, false).nowait().exist()!
		   VAR_TIMEOUT_ERROR_1 = _result() == 1
		   _if(VAR_TIMEOUT_ERROR_1, function(){
		   get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
		   VAR_TIMEOUT_ERROR_1 = _result().indexOf("true")>=0
		   })!
		   

		   
		   
		   /*Browser*/
		   ;_SELECTOR=VAR_FUNCAPTCHA_PREFIX + " \u003eCSS\u003e #sub-frame-error";
		   get_element_selector(_SELECTOR, false).nowait().exist()!
		   VAR_TIMEOUT_ERROR_2 = _result() == 1
		   _if(VAR_TIMEOUT_ERROR_2, function(){
		   get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
		   VAR_TIMEOUT_ERROR_2 = _result().indexOf("true")>=0
		   })!
		   

		   
		   
		   /*Browser*/
		   ;_SELECTOR=VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e #sub-frame-error";
		   get_element_selector(_SELECTOR, false).nowait().exist()!
		   VAR_TIMEOUT_ERROR_3 = _result() == 1
		   _if(VAR_TIMEOUT_ERROR_3, function(){
		   get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
		   VAR_TIMEOUT_ERROR_3 = _result().indexOf("true")>=0
		   })!
		   

		   
		   
		   /*Browser*/
		   ;_SELECTOR=VAR_FUNCAPTCHA_PREFIX + " \u003eCSS\u003e #timeout_widget";
		   get_element_selector(_SELECTOR, false).nowait().exist()!
		   VAR_TIMEOUT_ERROR_4 = _result() == 1
		   _if(VAR_TIMEOUT_ERROR_4, function(){
		   get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
		   VAR_TIMEOUT_ERROR_4 = _result().indexOf("true")>=0
		   })!
		   

		   
		   
		   _set_if_expression("W1tUSU1FT1VUX0VSUk9SXzFdXSA9PSB0cnVlIHx8IFtbVElNRU9VVF9FUlJPUl8yXV0gPT0gdHJ1ZSB8fCBbW1RJTUVPVVRfRVJST1JfM11dID09IHRydWUgfHwgW1tUSU1FT1VUX0VSUk9SXzRdXSA9PSB0cnVl");
		   _if(VAR_TIMEOUT_ERROR_1 == true || VAR_TIMEOUT_ERROR_2 == true || VAR_TIMEOUT_ERROR_3 == true || VAR_TIMEOUT_ERROR_4 == true,function(){
		   
			  
			  
			  VAR_ERROR_LOAD = "1"
			  

			  
			  
			  _break("function")
			  

		   })!
		   

		})!
		

		
		
		sleep(rand(200,500))!
		

	 })!
	 

	},null)!




	_set_if_expression("W1tFUlJPUl9MT0FEXV0gPT0gMQ==");
	_if(VAR_ERROR_LOAD == 1,function(){

	 
	 
	 /*Browser*/
	 cache_data_clear()!
	 

	 
	 
	 fail((_K==="en" ? "Funcaptcha was not solved, the connection to a verification server was interrupted - ERROR_CAPTCHA_TIMEOUT" : "Funcaptcha не была решена. Не удалось загрузить iframe страницу c каптчей - ERROR_CAPTCHA_TIMEOUT"));
	 

	})!




	_set_if_expression("W1tFUlJPUl9XQUlUX1RBU0tfRlVOQ0FQVENIQV1dID09PSAx");
	_if(VAR_ERROR_WAIT_TASK_FUNCAPTCHA === 1,function(){

	 
	 
	 /*Browser*/
	 cache_data_clear()!
	 

	 
	 
	 fail((_K==="en" ? "FunCaptcha was not solved, could not wait URL with tasks. Timeout waiting - */fc/gfc*" : "Funcaptcha не была решена, не удалось загрузить URL со списком заданий. Таймаут ожидания - */fc/gfc*"));
	 

	})!




	_set_if_expression("W1tXQVNfRVJST1JdXQ==");
	_if(typeof(VAR_WAS_ERROR) !== "undefined" ? (VAR_WAS_ERROR) : undefined,function(){

	 
	 
	 _set_if_expression("W1tMQVNUX0VSUk9SXV0gPT09ICdBYm9ydGVkIEJ5IFVzZXInIHx8IFtbTEFTVF9FUlJPUl1dICA9PT0gJ9Cf0YDQtdGA0LLQsNC90L4g0J/QvtC70YzQt9C+0LLQsNGC0LXQu9C10Lwn");
	 _if(VAR_LAST_ERROR === 'Aborted By User' || VAR_LAST_ERROR  === 'Прервано Пользователем',function(){
	 
		
		
		_function_return(false)
		

	 })!
	 

	 
	 
	 fail(VAR_LAST_ERROR)
	 

	})!




	_call(function()
	{
	_on_fail(function(){
	VAR_LAST_ERROR = _result()
	VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
	VAR_WAS_ERROR = false
	_break(1,true)
	})
	CYCLES.Current().RemoveLabel("function")

	 
	 
	 _do(function(){
	 _set_action_info({ name: "For" });
	 VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
	 if(VAR_CYCLE_INDEX > parseInt(40))_break();
	 
		
		
		/*Browser*/
		_cache_get_all("*/fc/gfc*")!
		VAR_ALL_JSON_FUNCAP = JSON.parse(_result())
		

		
		
		/*Browser*/
		is_load("*game-lite-mode/fc*")!
		VAR_WAIT_LOAD_TASK_LITE = _result()
		

		
		
		_set_if_expression("W1tXQUlUX0xPQURfVEFTS19MSVRFXV0gPT0gMQ==");
		_if(VAR_WAIT_LOAD_TASK_LITE == 1,function(){
		
		   
		   
		   VAR_CURRENT_TASK_NUMBERS = 2
		   

		   
		   
		   _break("function")
		   

		})!
		

		
		
		VAR_ALL_JSON_FUNCAP_LENGTH = (VAR_ALL_JSON_FUNCAP).length
		

		
		
		_set_if_expression("W1tBTExfSlNPTl9GVU5DQVBdXSAhPSAnJyAmJiBbW0FMTF9KU09OX0ZVTkNBUF9MRU5HVEhdXSA9PSAx");
		_if(VAR_ALL_JSON_FUNCAP != '' && VAR_ALL_JSON_FUNCAP_LENGTH == 1,function(){
		
		   
		   
		   /*Browser*/
		   wait_load("*/fc/gfc*")!
		   cache_get_string("*/fc/gfc*")!
		   VAR_SAVED_CACHE_MODULE = _result()
		   

		})!
		

		
		
		_set_if_expression("W1tBTExfSlNPTl9GVU5DQVBdXSAhPSAnJyAmJiBbW0FMTF9KU09OX0ZVTkNBUF9MRU5HVEhdXSA+IDE=");
		_if(VAR_ALL_JSON_FUNCAP != '' && VAR_ALL_JSON_FUNCAP_LENGTH > 1,function(){
		
		   
		   
		   _do(function(){
		   _set_action_info({ name: "While" });
		   VAR_CYCLE_INDEX = _iterator() - 1
		   BREAK_CONDITION = VAR_ALL_JSON_FUNCAP !=0;
		   if(!BREAK_CONDITION)_break();
		   
			  
			  
			  _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gNDA=");
			  _if(VAR_CYCLE_INDEX > 40,function(){
			  
				 
				 
				 _break("function")
				 

			  })!
			  

			  
			  
			  VAR_ALL_JSON_FUNCAP_LENGTH = (VAR_ALL_JSON_FUNCAP).length
			  

			  
			  
			  VAR_LIST_ELEMENT_BAS_MODULE = (VAR_ALL_JSON_FUNCAP)[0];
			  VAR_ALL_JSON_FUNCAP.splice(0,1)
			  

			  
			  
			  _set_if_expression("dHlwZW9mKFtbTElTVF9FTEVNRU5UX0JBU19NT0RVTEVdXSkgPT09ICJ1bmRlZmluZWQi");
			  _if(typeof(VAR_LIST_ELEMENT_BAS_MODULE) === "undefined",function(){
			  
				 
				 
				 _break("function")
				 

			  })!
			  

			  
			  
			  /// Функция декодирования
			  function decodeBase64Module(base64StringModule) {
			  var decodedStringModule = "";
			  var keyStr = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";
			  var chr1, chr2, chr3;
			  var enc1, enc2, enc3, enc4;
			  var i = 0;
			  base64StringModule = base64StringModule.replace(/[^A-Za-z0-9+/=]/g, "");
			  while (i < base64StringModule.length) {
			  enc1 = keyStr.indexOf(base64StringModule.charAt(i++));
			  enc2 = keyStr.indexOf(base64StringModule.charAt(i++));
			  enc3 = keyStr.indexOf(base64StringModule.charAt(i++));
			  enc4 = keyStr.indexOf(base64StringModule.charAt(i++));
			  chr1 = (enc1 << 2) | (enc2 >> 4);
			  chr2 = ((enc2 & 15) << 4) | (enc3 >> 2);
			  chr3 = ((enc3 & 3) << 6) | enc4;
			  decodedStringModule += String.fromCharCode(chr1);
			  if (enc3 !== 64) {
			  decodedStringModule += String.fromCharCode(chr2);
			  }
			  if (enc4 !== 64) {
			  decodedStringModule += String.fromCharCode(chr3);
			  }
			  }
			  return decodedStringModule;
			  }
			  // Функция проверка валидности JSON
			  function isJSONValid(jsonString) {
			  try {
			  JSON.parse(jsonString);
			  return true;
			  } catch (error) {
			  return false;
			  }
			  }
			  /// Ищем задание в каждом элементе кэша
			  if (VAR_LIST_ELEMENT_BAS_MODULE.hasOwnProperty("body")) VAR_CHECK_EMPTY_BODY = VAR_LIST_ELEMENT_BAS_MODULE.body
			  if (VAR_CHECK_EMPTY_BODY != '') VAR_SAVED_CACHE_MODULE = decodeBase64Module(VAR_CHECK_EMPTY_BODY);
			  // Проверяем валидный JSON
			  var jsonStringModule = VAR_SAVED_CACHE_MODULE
			  if (isJSONValid(jsonStringModule)) {
			  VAR_IS_JSON_VALID = true
			  } else {
			  VAR_IS_JSON_VALID = false
			  }
			  

			  
			  
			  _set_if_expression("W1tJU19KU09OX1ZBTElEXV0gPT0gZmFsc2U=");
			  _if(VAR_IS_JSON_VALID == false,function(){
			  
				 
				 
				 _next("function")
				 

			  })!
			  

			  
			  
			  _set_if_expression("W1tTQVZFRF9DQUNIRV9NT0RVTEVdXS5pbmRleE9mKCJnYW1lX2RhdGEiKSA+PSAw");
			  _if(VAR_SAVED_CACHE_MODULE.indexOf("game_data") >= 0,function(){
			  
				 
				 
				 _break("function")
				 

			  })!
			  

			  
			  
			  sleep(200)!
			  

		   })!
		   

		})!
		

		
		
		// Проверяем, спарсили ли кэш из body
		function isJSONValid(jsonStringModule) {
		try {
		JSON.parse(jsonStringModule);
		return true;
		} catch (error) {
		return false;
		}
		}
		var jsonStringModule = VAR_SAVED_CACHE_MODULE
		if (isJSONValid(jsonStringModule)) {
		VAR_IS_JSON_VALID = true
		} else {
		VAR_IS_JSON_VALID = false
		}
		

		
		
		_set_if_expression("W1tJU19KU09OX1ZBTElEXV0gPT09IHRydWU=");
		_if(VAR_IS_JSON_VALID === true,function(){
		
		   
		   
		   /// Парсим задание
		   VAR_SAVED_CACHE_MODULE = JSON.parse(VAR_SAVED_CACHE_MODULE);
		   ///Game Item, Game_Chidldren, Game_Lite
		   if (VAR_SAVED_CACHE_MODULE.hasOwnProperty("game_data") &&
		   VAR_SAVED_CACHE_MODULE.game_data.hasOwnProperty("game_variant")){
		   VAR_SET_TASK = VAR_SAVED_CACHE_MODULE.game_data.game_variant
		   VAR_CURRENT_TASK_NUMBERS = VAR_SAVED_CACHE_MODULE.game_data.waves;
		   VAR_ALL_TASK_NUMBERS = VAR_SAVED_CACHE_MODULE.game_data.waves;
		   }
		   /// GameBox и GameTile
		   if (VAR_SAVED_CACHE_MODULE.hasOwnProperty("game_data") &&
		   VAR_SAVED_CACHE_MODULE.game_data.hasOwnProperty("instruction_string")){
		   VAR_SET_TASK = VAR_SAVED_CACHE_MODULE.game_data.instruction_string
		   VAR_CURRENT_TASK_NUMBERS = VAR_SAVED_CACHE_MODULE.game_data.waves;
		   VAR_ALL_TASK_NUMBERS = VAR_SAVED_CACHE_MODULE.game_data.waves;
		   }
		   

		})!
		

		
		
		_set_if_expression("W1tTRVRfVEFTS11dICE9ICIi");
		_if(VAR_SET_TASK != "",function(){
		
		   
		   
		   _break("function")
		   

		})!
		

		
		
		_set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gMzA=");
		_if(VAR_CYCLE_INDEX > 30,function(){
		
		   
		   
		   VAR_CACHE_ERROR = "1"
		   

		   
		   
		   _break("function")
		   

		})!
		

		
		
		sleep(rand(100,900))!
		

	 })!
	 

	},null)!




	_set_if_expression("W1tXQVNfRVJST1JdXQ==");
	_if(typeof(VAR_WAS_ERROR) !== "undefined" ? (VAR_WAS_ERROR) : undefined,function(){

	 
	 
	 _set_if_expression("W1tMQVNUX0VSUk9SXV0gPT09ICdBYm9ydGVkIEJ5IFVzZXInIHx8IFtbTEFTVF9FUlJPUl1dICA9PT0gJ9Cf0YDQtdGA0LLQsNC90L4g0J/QvtC70YzQt9C+0LLQsNGC0LXQu9C10Lwn");
	 _if(VAR_LAST_ERROR === 'Aborted By User' || VAR_LAST_ERROR  === 'Прервано Пользователем',function(){
	 
		
		
		_function_return(false)
		

	 })!
	 

	 
	 
	 /*Browser*/
	 cache_data_clear()!
	 

	 
	 
	 fail((_K==="en" ? "FunCaptcha has not been resolved. Error parsing cache: */fc/gfc*" : "Funcaptcha не была решена. Произошла неизвестная ошибка парсинга кэша - */fc/gfc*"));
	 

	})!




	_set_if_expression("W1tDQUNIRV9FUlJPUl1dID09IDE=");
	_if(VAR_CACHE_ERROR == 1,function(){

	 
	 
	 /*Browser*/
	 cache_data_clear()!
	 

	 
	 
	 fail((_K==="en" ? "FunCaptcha was not solved, could not get task from URL - */fc/gfc*" : "Funcaptcha не была решена, не удалось спарсить задание из маски URL - */fc/gfc*"));
	 

	})!




	VAR_TRY_CAPTCHA = "0"




	VAR_CAPTCHA_FAIL = "0"




	VAR_ERROR_KEY = "0"




	VAR_ERROR_BALANCE = "0"




	VAR_ERROR_LANG = "0"




	VAR_GET_ALL_COORDINATES = "0"




	VAR_FIRST_LOAD_CAPTCHA = true




	VAR_FIRST_LOAD_BUTTON = true




	VAR_SAVED_CACHE_MODULE = ""




	VAR_ALL_JSON_FUNCAP = ""




	VAR_LIST_ELEMENT_BAS_MODULE = ""




	_do(function(){
	_set_action_info({ name: "For" });
	VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
	if(VAR_CYCLE_INDEX > parseInt(500))_break();

	 
	 
	 VAR_CYCLE_INDEX = 0
	 

	 
	 
	 _set_if_expression("W1tFUlJPUl9LRVldXSA9PSAx");
	 _if(VAR_ERROR_KEY == 1,function(){
	 
		
		
		/*Browser*/
		cache_data_clear()!
		

		
		
		fail((_K==="en" ? "API secret key from captcha recognition service is wrong ERROR_WRONG_USER_KEY" : "Секретный ключ API от сервиса распознавания капчи неправильный ERROR_WRONG_USER_KEY"));
		

	 })!
	 

	 
	 
	 _set_if_expression("W1tFUlJPUl9CQUxBTkNFXV0gPT0gMQ==");
	 _if(VAR_ERROR_BALANCE == 1,function(){
	 
		
		
		/*Browser*/
		cache_data_clear()!
		

		
		
		fail((_K==="en" ? "The balance on the captcha service has ended - ERROR_ZERO_BALANCE" : "Закончился баланс на сервисе распознавания капчи - ERROR_ZERO_BALANCE"));
		

	 })!
	 

	 
	 
	 _set_if_expression("W1tFUlJPUl9UQVNLXV0gPiAx");
	 _if(VAR_ERROR_TASK > 1,function(){
		

		
		
		/*Browser*/
		cache_data_clear()!
		

		
		
		fail((_K==="en" ? "This Funcaptcha task or image type is not supported service SCTG: " +VAR_SET_TASK : "FunCaptcha не была решена. Сервис SCTG не умеет решать это изображение с таким заданием: " +VAR_SET_TASK));
		

	 })!
	 

	 
	 
	 _set_if_expression("W1tDQVBUQ0hBX0ZBSUxdXSA+IDE=");
	 _if(VAR_CAPTCHA_FAIL > 1,function(){
	 
		
		
		/*Browser*/
		cache_data_clear()!
		

		
		
		_cycle_params().if_else = VAR_SAVED_CONTENT.indexOf("<html>") >= 0;
		_set_if_expression("W1tTQVZFRF9DT05URU5UXV0uaW5kZXhPZigiPGh0bWw+IikgPj0gMA==");
		_if(_cycle_params().if_else,function(){
		
		   
		   
		   fail((_K==="en" ? "Funcaptcha solved failed. SCTG solving service is not working at the moment" : "Funcaptcha не была решена, причина: сервис по решению каптч SCTG не работает в данный момент."));
		   

		})!
		

		
		
		_if(!_cycle_params().if_else,function(){
		
		   
		   
		   fail((_K==="en" ? "Failed to solve FunCaptcha, reason - " +VAR_SAVED_CONTENT : "Не удалось решить FunCaptcha, причина - " +VAR_SAVED_CONTENT));
		   

		})!
		delete _cycle_params().if_else;
		

	 })!
	 

	 
	 
	 _set_if_expression("W1tFUlJPUl9DQVBUQ0hBX1VOU09MVkFCTEVfTU9EVUxFXV0gPiAx");
	 _if(VAR_ERROR_CAPTCHA_UNSOLVABLE_MODULE > 1,function(){
		

		
		
		/*Browser*/
		cache_data_clear()!
		

		
		
		sleep(100)!
		

		
		
		fail((_K==="en" ? "Failed to solve FunCaptcha - SCTG was unable to solve the last 3 tasks/pictures, error type: ERROR_CPATCHA_UNSOLVABLE" : "Не удалось решить FunCaptcha - SCTG не смог решить 3 последних задания/картинки. Ошибка: ERROR_CAPTCHA_UNSOLVABLE"));
		

	 })!
	 

	 
	 
	 _do(function(){
	 _set_action_info({ name: "For" });
	 VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
	 if(VAR_CYCLE_INDEX > parseInt(85))_break();
	 
		
		
		_set_if_expression("W1tGSVJTVF9MT0FEX0JVVFRPTl1dID09IHRydWU=");
		_if(VAR_FIRST_LOAD_BUTTON == true,function(){
		
		   
		   
		   /*Browser*/
		   ;_SELECTOR=VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e #verifyButton";
		   get_element_selector(_SELECTOR, false).nowait().exist()!
		   VAR_IS_EXISTS = _result() == 1
		   

		   
		   
		   _set_if_expression("W1tJU19FWElTVFNdXQ==");
		   _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
		   
			  
			  
			  /*Browser*/
			  _SELECTOR = VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e #verifyButton";
			  wait_element_visible(_SELECTOR)!
			  _call(_random_point, {})!
			  _if(_result().length > 0, function(){
			  move( {} )!
			  get_element_selector(_SELECTOR, false).clarify(X,Y)!
			  _call(_clarify, {} )!
			  mouse(X,Y)!
			  })!
			  

		   })!
		   

		   
		   
		   /*Browser*/
		   ;_SELECTOR=VAR_FUNCAPTCHA_PREFIX + " \u003eCSS\u003e #verifyButton";
		   get_element_selector(_SELECTOR, false).nowait().exist()!
		   VAR_IS_EXISTS = _result() == 1
		   

		   
		   
		   _set_if_expression("W1tJU19FWElTVFNdXQ==");
		   _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
		   
			  
			  
			  /*Browser*/
			  _SELECTOR = VAR_FUNCAPTCHA_PREFIX + " \u003eCSS\u003e #verifyButton";
			  wait_element_visible(_SELECTOR)!
			  _call(_random_point, {})!
			  _if(_result().length > 0, function(){
			  move( {} )!
			  get_element_selector(_SELECTOR, false).clarify(X,Y)!
			  _call(_clarify, {} )!
			  mouse(X,Y)!
			  })!
			  

		   })!
		   

		})!
		

		
		
		_set_if_expression("W1tDVVJSRU5UX1RBU0tfTlVNQkVSU11dIDwgMQ==");
		_if(VAR_CURRENT_TASK_NUMBERS < 1,function(){
		
		   
		   
		   /*Browser*/
		   ;_SELECTOR=VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e #wrong_children_exclamation";
		   get_element_selector(_SELECTOR, false).nowait().exist()!
		   VAR_WRONG_CAPTCHA_SOLVE_1 = _result() == 1
		   

		   
		   
		   /*Browser*/
		   ;_SELECTOR=VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e div[class*=\u0027match-game-fail\u0027]";
		   get_element_selector(_SELECTOR, false).nowait().exist()!
		   VAR_WRONG_CAPTCHA_SOLVE_2 = _result() == 1
		   

		   
		   
		   /*Browser*/
		   ;_SELECTOR=VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e div[class*=\u0027tile-game-fail\u0027]";
		   get_element_selector(_SELECTOR, false).nowait().exist()!
		   VAR_WRONG_CAPTCHA_SOLVE_3 = _result() == 1
		   

		   
		   
		   /*Browser*/
		   ;_SELECTOR=VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e div[id*=\u0027descriptionTryAgain\u0027]";
		   get_element_selector(_SELECTOR, false).nowait().exist()!
		   VAR_WRONG_CAPTCHA_SOLVE_4 = _result() == 1
		   

		   
		   
		   _set_if_expression("W1tXUk9OR19DQVBUQ0hBX1NPTFZFXzFdXSA9PSB0cnVlIHx8IFtbV1JPTkdfQ0FQVENIQV9TT0xWRV8yXV0gPT0gdHJ1ZSB8fCBbW1dST05HX0NBUFRDSEFfU09MVkVfM11dID09IHRydWUgfHwgW1tXUk9OR19DQVBUQ0hBX1NPTFZFXzRdXSA9PSB0cnVl");
		   _if(VAR_WRONG_CAPTCHA_SOLVE_1 == true || VAR_WRONG_CAPTCHA_SOLVE_2 == true || VAR_WRONG_CAPTCHA_SOLVE_3 == true || VAR_WRONG_CAPTCHA_SOLVE_4 == true,function(){
		   
			  
			  
			  VAR_ERROR_SOLVE = "1"
			  

			  
			  
			  _break("function")
			  

		   })!
		   

		})!
		

		
		
		_set_if_expression("W1tGSVJTVF9MT0FEX0JVVFRPTl1dID09IHRydWUgfHwgW1tDVVJSRU5UX1RBU0tfTlVNQkVSU11dIDwgMQ==");
		_if(VAR_FIRST_LOAD_BUTTON == true || VAR_CURRENT_TASK_NUMBERS < 1,function(){
		
		   
		   
		   /*Browser*/
		   ;_SELECTOR=VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e #game_challengeItem";
		   get_element_selector(_SELECTOR, false).nowait().exist()!
		   VAR_IS_EXISTS = _result() == 1
		   _if(VAR_IS_EXISTS, function(){
		   get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
		   VAR_IS_EXISTS = _result().indexOf("true")>=0
		   })!
		   

		   
		   
		   /*Browser*/
		   ;_SELECTOR=VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e div[class*=\u0027match-game box screen\u0027]";
		   get_element_selector(_SELECTOR, false).nowait().exist()!
		   VAR_IS_EXISTS_2 = _result() == 1
		   _if(VAR_IS_EXISTS_2, function(){
		   get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
		   VAR_IS_EXISTS_2 = _result().indexOf("true")>=0
		   })!
		   

		   
		   
		   /*Browser*/
		   ;_SELECTOR=VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e div[class*=\u0027tile-game box screen\u0027]";
		   get_element_selector(_SELECTOR, false).nowait().exist()!
		   VAR_IS_EXISTS_3 = _result() == 1
		   _if(VAR_IS_EXISTS_3, function(){
		   get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
		   VAR_IS_EXISTS_3 = _result().indexOf("true")>=0
		   })!
		   

		   
		   
		   /*Browser*/
		   ;_SELECTOR=VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e legend[id*=\u0027game-header\u0027]";
		   get_element_selector(_SELECTOR, false).nowait().exist()!
		   VAR_IS_EXISTS_4 = _result() == 1
		   _if(VAR_IS_EXISTS_4, function(){
		   get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
		   VAR_IS_EXISTS_4 = _result().indexOf("true")>=0
		   })!
		   

		   
		   
		   /*Browser*/
		   ;_SELECTOR=VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e a[id*=\u0027Frame_children_arrow\u0027]";
		   get_element_selector(_SELECTOR, false).nowait().exist()!
		   VAR_IS_EXISTS_5 = _result() == 1
		   _if(VAR_IS_EXISTS_5, function(){
		   get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
		   VAR_IS_EXISTS_5 = _result().indexOf("true")>=0
		   })!
		   

		   
		   
		   _set_if_expression("W1tJU19FWElTVFNdXSA9PSB0cnVlIHx8IFtbSVNfRVhJU1RTXzJdXSA9PSB0cnVlIHx8IFtbSVNfRVhJU1RTXzNdXSA9PSB0cnVlIHx8IFtbSVNfRVhJU1RTXzRdXSA9PSB0cnVlIHx8IFtbSVNfRVhJU1RTXzVdXSA9PSB0cnVl");
		   _if(VAR_IS_EXISTS == true || VAR_IS_EXISTS_2 == true || VAR_IS_EXISTS_3 == true || VAR_IS_EXISTS_4 == true || VAR_IS_EXISTS_5 == true,function(){
		   
			  
			  
			  _set_if_expression("W1tJU19FWElTVFNdXQ==");
			  _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
			  
				 
				 
				 VAR_FUNCAPTCHA_TYPE = "Game_Item"
				 

			  })!
			  

			  
			  
			  _set_if_expression("W1tJU19FWElTVFNfMl1d");
			  _if(typeof(VAR_IS_EXISTS_2) !== "undefined" ? (VAR_IS_EXISTS_2) : undefined,function(){
			  
				 
				 
				 VAR_FUNCAPTCHA_TYPE = "Game_Box"
				 

			  })!
			  

			  
			  
			  _set_if_expression("W1tJU19FWElTVFNfM11d");
			  _if(typeof(VAR_IS_EXISTS_3) !== "undefined" ? (VAR_IS_EXISTS_3) : undefined,function(){
			  
				 
				 
				 VAR_FUNCAPTCHA_TYPE = "Game_Tile"
				 

			  })!
			  

			  
			  
			  _set_if_expression("W1tJU19FWElTVFNfNF1d");
			  _if(typeof(VAR_IS_EXISTS_4) !== "undefined" ? (VAR_IS_EXISTS_4) : undefined,function(){
			  
				 
				 
				 VAR_FUNCAPTCHA_TYPE = "Game_Lite"
				 

			  })!
			  

			  
			  
			  _set_if_expression("W1tJU19FWElTVFNfNV1d");
			  _if(typeof(VAR_IS_EXISTS_5) !== "undefined" ? (VAR_IS_EXISTS_5) : undefined,function(){
			  
				 
				 
				 VAR_FUNCAPTCHA_TYPE = "Game_Children"
				 

			  })!
			  

			  
			  
			  _break("function")
			  

		   })!
		   

		   
		   
		   _set_if_expression("W1tJU19FWElTVFNdXSA9PSBmYWxzZSAmJiBbW0lTX0VYSVNUU18yXV0gPT0gZmFsc2UgJiYgW1tJU19FWElTVFNfM11dID09IGZhbHNlICYmIFtbSVNfRVhJU1RTXzRdXSA9PSBmYWxzZSAmJiBbW0lTX0VYSVNUU181XV0gPT0gZmFsc2UgJiYgW1tGSVJTVF9MT0FEX0NBUFRDSEFdXSA9PSBmYWxzZSAmJiBbW0NZQ0xFX0lOREVYXV0gPiAxICYmIFtbUkVTVUxUX1NFTEVDVE9SXV0gIT0gMQ==");
		   _if(VAR_IS_EXISTS == false && VAR_IS_EXISTS_2 == false && VAR_IS_EXISTS_3 == false && VAR_IS_EXISTS_4 == false && VAR_IS_EXISTS_5 == false && VAR_FIRST_LOAD_CAPTCHA == false && VAR_CYCLE_INDEX > 1 && VAR_RESULT_SELECTOR != 1,function(){
		   
			  
			  
			  /*Browser*/
			  cache_data_clear()!
			  

			  
			  
			  VAR_GREEN_TICK = true
			  

			  
			  
			  _break("function")
			  

		   })!
		   

		})!

		

		
		
		_set_if_expression("dHlwZW9mKFtbU0hPUlRfVEFTS11dKSAhPSAidW5kZWZpbmVkIiAmJiByYW5kICgxLDEwKSA+IDc=");
		_if(typeof(VAR_SHORT_TASK) != "undefined" && rand (1,10) > 7,function(){
		
		   
		   
		   sleep(rand(20000,60000))!
		   

		})!
		

		
		
		_set_if_expression("W1tDVVJSRU5UX1RBU0tfTlVNQkVSU11dID4gMCAmJiBbW0ZJUlNUX0xPQURfQlVUVE9OXV0gPT0gZmFsc2U=");
		_if(VAR_CURRENT_TASK_NUMBERS > 0 && VAR_FIRST_LOAD_BUTTON == false,function(){
		
		   
		   
		   _break("function")
		   

		})!
		

		
		
		_set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gNDAgJiYgW1tGSVJTVF9MT0FEX0JVVFRPTl1dID09IHRydWUgJiYgW1tSRVNVTFRfU0VMRUNUT1JdXSAhPSAx");
		_if(VAR_CYCLE_INDEX > 40 && VAR_FIRST_LOAD_BUTTON == true && VAR_RESULT_SELECTOR != 1,function(){
		
		   
		   
		   VAR_FIRST_LOAD_BUTTON = false
		   

		   
		   
		   sleep(rand(1000,2000))!
		   

		   
		   
		   /*Browser*/
		   ;_SELECTOR=VAR_GLOBAL_SELECTOR;
		   get_element_selector(_SELECTOR, false).nowait().exist()!
		   VAR_IS_EXISTS = _result() == 1
		   _if(VAR_IS_EXISTS, function(){
		   get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
		   VAR_IS_EXISTS = _result().indexOf("true")>=0
		   })!
		   

		   
		   
		   _set_if_expression("W1tJU19FWElTVFNdXQ==");
		   _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
		   
			  
			  
			  /*Browser*/
			  _SELECTOR = VAR_GLOBAL_SELECTOR;waiter_timeout_next(8000)
			  wait_element_visible(_SELECTOR)!
			  _call(_random_point, {})!
			  _if(_result().length > 0, function(){
			  move( {} )!
			  get_element_selector(_SELECTOR, false).clarify(X,Y)!
			  _call(_clarify, {} )!
			  mouse(X,Y)!
			  })!
			  

			  
			  
			  sleep(rand(2000,4000))!
			  

		   })!
		   

		})!
		

		
		
		_set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gNjAgJiYgW1tGSVJTVF9MT0FEX0NBUFRDSEFdXSA9PSB0cnVlICYmIFtbUkVTVUxUX1NFTEVDVE9SXV0gIT0gMQ==");
		_if(VAR_CYCLE_INDEX > 60 && VAR_FIRST_LOAD_CAPTCHA == true && VAR_RESULT_SELECTOR != 1,function(){
		
		   
		   
		   /*Browser*/
		   cache_data_clear()!
		   

		   
		   
		   fail((_K==="en" ? "Failed to solve FunCaptcha. This captcha type is unknown for current module solve method" : "Не удалось решить FunCaptcha, модуль не умеет решать такой тип капчи"));
		   

		})!
		

		
		
		_set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gODAgJiYgW1tGSVJTVF9MT0FEX0NBUFRDSEFdXSA9PSBmYWxzZSAmJiBbW1JFU1VMVF9TRUxFQ1RPUl1dICE9IDE=");
		_if(VAR_CYCLE_INDEX > 80 && VAR_FIRST_LOAD_CAPTCHA == false && VAR_RESULT_SELECTOR != 1,function(){
		
		   
		   
		   /*Browser*/
		   cache_data_clear()!
		   

		   
		   
		   fail((_K==="en" ? "Failed to solve the captcha. The captcha window is closed." : "Решить капчу не удалось. Окно с капчей не было открыто."));
		   

		})!
		

	 })!
	 

	 
	 
	 VAR_CYCLE_INDEX = 0
	 

	 
	 
	 VAR_FIRST_LOAD_BUTTON = false
	 

	 
	 
	 _set_if_expression("W1tHUkVFTl9USUNLXV0gPT0gdHJ1ZSAmJiBbW1JFU1VMVF9TRUxFQ1RPUl1dICE9IDE=");
	 _if(VAR_GREEN_TICK == true && VAR_RESULT_SELECTOR != 1,function(){
	 
		
		
		/*Browser*/
		cache_data_clear()!
		

		
		
		_function_return("")
		

	 })!
	 

	 
	 
	 _set_if_expression("W1tDVVJSRU5UX1RBU0tfTlVNQkVSU11dID4gW1tUUllfTUFYX0NBUFRDSEFfUElDVFVSRV1d");
	 _if(VAR_CURRENT_TASK_NUMBERS > VAR_TRY_MAX_CAPTCHA_PICTURE,function(){
	 
		
		
		/*Browser*/
		cache_data_clear()!
		

		
		
		fail((_K==="en" ? "The FunCaptcha could not be solved. Reason: Low browser/proxy quality. Too many tasks " +VAR_CURRENT_TASK_NUMBERS + ". Check the quality of the browser and proxy. FunCaptcha type: " +VAR_FUNCAPTCHA_TYPE+ ". Short task: " +VAR_SET_TASK+ "" : "FunCaptcha решить не удалось. Причина: низкое качество браузера/прокси. Слишком много заданий: " +VAR_CURRENT_TASK_NUMBERS + ". Тип каптчи: " +VAR_FUNCAPTCHA_TYPE+ ". Задание: " +VAR_SET_TASK+ ""));
		

	 })!
	 

	 
	 
	 _set_if_expression("W1tFUlJPUl9TT0xWRV1dID09IDE=");
	 _if(VAR_ERROR_SOLVE == 1,function(){
	 
		
		
		/*Browser*/
		cache_data_clear()!
		

		
		
		fail((_K==="en" ? "Failed to solve FunCaptcha, SCTG service solved your captcha incorrectly, error type: ERROR_CAPTCHA_SOLVE. FunCaptcha type " + VAR_FUNCAPTCHA_TYPE + ". Short task: " + VAR_SET_TASK : "Не удалось решить FunCaptcha, сервис SCTG решил вашу каптчу неправильно, тип ошибки: ERROR_CAPTCHA_SOLVE. Тип каптчи: " + VAR_FUNCAPTCHA_TYPE + ". Задание: " + VAR_SET_TASK));
		

	 })!
	 

	 
	 
	 VAR_TRY_CAPTCHA = parseInt(VAR_TRY_CAPTCHA) + parseInt(1)
	 

	 
	 
	 _set_if_expression("W1tUUllfQ0FQVENIQV1dID4gODA=");
	 _if(VAR_TRY_CAPTCHA > 80,function(){
	 
		
		
		/*Browser*/
		cache_data_clear()!
		

		
		
		fail((_K==="en" ? "Failed to solve the captcha. FunCaptcha attempts limit exceeded" : "Решить FunCaptcha не удалось. Превышен общий лимит попыток решить каптчу."));
		

	 })!
	 

	 
	 
	 _call(function()
	 {
	 _on_fail(function(){
	 VAR_LAST_ERROR = _result()
	 VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
	 VAR_WAS_ERROR = false
	 _break(1,true)
	 })
	 CYCLES.Current().RemoveLabel("function")
	 
		
		
		_get_browser_screen_settings()!
		;(function(){
		var result = JSON.parse(_result())
		VAR_SCROLL_X = result["ScrollX"]
		VAR_SCROLL_Y = result["ScrollY"]
		VAR_CURSOR_X = result["CursorX"]
		VAR_CURSOR_Y = result["CursorY"]
		VAR_BROWSER_WIDTH = result["Width"]
		VAR_BROWSER_HEIGHT = result["Height"]
		})();
		

		
		
		_set_if_expression("W1tGVU5DQVBUQ0hBX1RZUEVdXSA9PSAiR2FtZV9JdGVtIg==");
		_if(VAR_FUNCAPTCHA_TYPE == "Game_Item",function(){
		
		   
		   
		   /*Browser*/
		   ;_SELECTOR=VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e #game_challengeItem";
		   get_element_selector(_SELECTOR, false).nowait().exist()!
		   VAR_IS_EXISTS = _result() == 1
		   

		   
		   
		   _set_if_expression("IVtbSVNfRVhJU1RTXV0=");
		   _if(!VAR_IS_EXISTS,function(){
		   
			  
			  
			  sleep(rand(100,500))!
			  

			  
			  
			  _next("function")
			  

		   })!
		   

		   
		   
		   /*Browser*/
		   _SELECTOR = VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e #game_challengeItem";
		   wait_element(_SELECTOR)!
		   get_element_selector(_SELECTOR, false).script("(function(){var rect = _BAS_HIDE(BrowserAutomationStudio_GetBoundingClientRect)(self);return (rect.left + positionx) + '|' + (rect.top + positiony) + '|' + (rect.right - rect.left) + '|' + (rect.bottom - rect.top)})();")!
		   if(_result().length > 0)
		   {
		   var split = _result().split("|")
		   VAR_X = parseInt(split[0])
		   VAR_Y = parseInt(split[1])
		   VAR_CAPTCHA_WIDTH = parseInt(split[2])
		   VAR_CAPTCHA_HEIGHT = parseInt(split[3])
		   }
		   

		   
		   
		   _set_if_expression("cmFuZCAoMSwxMCkgPiA1");
		   _if(rand (1,10) > 5,function(){
		   
			  
			  
			  /*Browser*/
			  move(rand(VAR_X/100*115,(VAR_X+VAR_CAPTCHA_WIDTH)/100*93).toFixed(),rand(VAR_Y + VAR_SCROLL_Y/100*120,VAR_Y + VAR_SCROLL_Y + VAR_CAPTCHA_HEIGHT/100*90).toFixed(),  {} )!
			  

		   })!
		   

		})!
		

		
		
		_set_if_expression("W1tGVU5DQVBUQ0hBX1RZUEVdXSA9PSAiR2FtZV9UaWxlIg==");
		_if(VAR_FUNCAPTCHA_TYPE == "Game_Tile",function(){
		
		   
		   
		   /*Browser*/
		   ;_SELECTOR=VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e div[class*=\u0027tile-game box screen\u0027]";
		   get_element_selector(_SELECTOR, false).nowait().exist()!
		   VAR_IS_EXISTS = _result() == 1
		   

		   
		   
		   _set_if_expression("IVtbSVNfRVhJU1RTXV0=");
		   _if(!VAR_IS_EXISTS,function(){
		   
			  
			  
			  sleep(rand(100,500))!
			  

			  
			  
			  _next("function")
			  

		   })!
		   

		   
		   
		   /*Browser*/
		   _SELECTOR = VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e div[class*=\u0027tile-game box screen\u0027]";
		   wait_element(_SELECTOR)!
		   get_element_selector(_SELECTOR, false).script("(function(){var rect = _BAS_HIDE(BrowserAutomationStudio_GetBoundingClientRect)(self);return (rect.left + positionx) + '|' + (rect.top + positiony) + '|' + (rect.right - rect.left) + '|' + (rect.bottom - rect.top)})();")!
		   if(_result().length > 0)
		   {
		   var split = _result().split("|")
		   VAR_X = parseInt(split[0])
		   VAR_Y = parseInt(split[1])
		   VAR_CAPTCHA_WIDTH = parseInt(split[2])
		   VAR_CAPTCHA_HEIGHT = parseInt(split[3])
		   }
		   

		   
		   
		   _set_if_expression("cmFuZCAoMSwxMCkgPiA1");
		   _if(rand (1,10) > 5,function(){
		   
			  
			  
			  /*Browser*/
			  move(rand(VAR_X/100*115,(VAR_X+VAR_CAPTCHA_WIDTH)/100*93).toFixed(),rand(VAR_Y + VAR_SCROLL_Y/100*120,VAR_Y + VAR_SCROLL_Y + VAR_CAPTCHA_HEIGHT/100*90).toFixed(),  {} )!
			  

		   })!
		   

		})!
		

		
		
		_set_if_expression("W1tGVU5DQVBUQ0hBX1RZUEVdXSA9PSAiR2FtZV9Cb3gi");
		_if(VAR_FUNCAPTCHA_TYPE == "Game_Box",function(){
		
		   
		   
		   /*Browser*/
		   ;_SELECTOR=VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e img[aria-label*=\u00271\u0027]";
		   get_element_selector(_SELECTOR, false).nowait().exist()!
		   VAR_IS_EXISTS = _result() == 1
		   

		   
		   
		   _set_if_expression("IVtbSVNfRVhJU1RTXV0=");
		   _if(!VAR_IS_EXISTS,function(){
		   
			  
			  
			  sleep(rand(100,500))!
			  

			  
			  
			  _next("function")
			  

		   })!
		   

		   
		   
		   _set_if_expression("W1tJU19FWElTVFNdXQ==");
		   _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
		   
			  
			  
			  /*Browser*/
			  _SELECTOR = VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e a[class*=\u0027right-arrow\u0027]";
			  wait_element_visible(_SELECTOR)!
			  _call(_random_point, {})!
			  _if(_result().length > 0, function(){
			  move( {} )!
			  get_element_selector(_SELECTOR, false).clarify(X,Y)!
			  _call(_clarify, {} )!
			  })!
			  

		   })!
		   

		})!
		

		
		
		_set_if_expression("W1tGVU5DQVBUQ0hBX1RZUEVdXSA9PSAiR2FtZV9MaXRlIg==");
		_if(VAR_FUNCAPTCHA_TYPE == "Game_Lite",function(){
		
		   
		   
		   /*Browser*/
		   ;_SELECTOR=VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e img[id*=\u0027challenge-image\u0027]";
		   get_element_selector(_SELECTOR, false).nowait().exist()!
		   VAR_IS_EXISTS = _result() == 1
		   

		   
		   
		   _set_if_expression("IVtbSVNfRVhJU1RTXV0=");
		   _if(!VAR_IS_EXISTS,function(){
		   
			  
			  
			  sleep(rand(100,500))!
			  

			  
			  
			  _next("function")
			  

		   })!
		   

		   
		   
		   /*Browser*/
		   _SELECTOR = VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e img[id*=\u0027challenge-image\u0027]";
		   wait_element(_SELECTOR)!
		   get_element_selector(_SELECTOR, false).script("(function(){var rect = _BAS_HIDE(BrowserAutomationStudio_GetBoundingClientRect)(self);return (rect.left + positionx) + '|' + (rect.top + positiony) + '|' + (rect.right - rect.left) + '|' + (rect.bottom - rect.top)})();")!
		   if(_result().length > 0)
		   {
		   var split = _result().split("|")
		   VAR_X = parseInt(split[0])
		   VAR_Y = parseInt(split[1])
		   VAR_CAPTCHA_WIDTH = parseInt(split[2])
		   VAR_CAPTCHA_HEIGHT = parseInt(split[3])
		   }
		   

		   
		   
		   _set_if_expression("cmFuZCAoMSwxMCkgPiA1");
		   _if(rand (1,10) > 5,function(){
		   
			  
			  
			  /*Browser*/
			  move(rand(VAR_X/100*115,(VAR_X+VAR_CAPTCHA_WIDTH)/100*93).toFixed(),rand(VAR_Y + VAR_SCROLL_Y/100*120,VAR_Y + VAR_SCROLL_Y + VAR_CAPTCHA_HEIGHT/100*90).toFixed(),  {} )!
			  

		   })!
		   

		})!
		

		
		
		_set_if_expression("W1tGVU5DQVBUQ0hBX1RZUEVdXSA9PSAiR2FtZV9DaGlsZHJlbiI=");
		_if(VAR_FUNCAPTCHA_TYPE == "Game_Children",function(){
		
		   
		   
		   /*Browser*/
		   ;_SELECTOR=VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e a[id*=\u0027children_arrowRight\u0027]";
		   get_element_selector(_SELECTOR, false).nowait().exist()!
		   VAR_IS_EXISTS = _result() == 1
		   

		   
		   
		   _set_if_expression("IVtbSVNfRVhJU1RTXV0=");
		   _if(!VAR_IS_EXISTS,function(){
		   
			  
			  
			  sleep(rand(100,500))!
			  

			  
			  
			  _next("function")
			  

		   })!
		   

		   
		   
		   _set_if_expression("W1tJU19FWElTVFNdXQ==");
		   _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
		   
			  
			  
			  /*Browser*/
			  _SELECTOR = VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e a[id*=\u0027children_arrowRight\u0027]";
			  wait_element_visible(_SELECTOR)!
			  _call(_random_point, {})!
			  _if(_result().length > 0, function(){
			  move( {} )!
			  get_element_selector(_SELECTOR, false).clarify(X,Y)!
			  _call(_clarify, {} )!
			  })!
			  

		   })!
		   

		})!
		

	 },null)!
	 

	 
	 
	 _call(function()
	 {
	 _on_fail(function(){
	 VAR_LAST_ERROR = _result()
	 VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
	 VAR_WAS_ERROR = false
	 _break(1,true)
	 })
	 CYCLES.Current().RemoveLabel("function")
	 
		
		
		_get_browser_screen_settings()!
		;(function(){
		var result = JSON.parse(_result())
		VAR_SCROLL_X = result["ScrollX"]
		VAR_SCROLL_Y = result["ScrollY"]
		VAR_CURSOR_X = result["CursorX"]
		VAR_CURSOR_Y = result["CursorY"]
		VAR_BROWSER_WIDTH = result["Width"]
		VAR_BROWSER_HEIGHT = result["Height"]
		})();
		

		
		
		_set_if_expression("W1tHRVRfQUxMX0NPT1JESU5BVEVTXV0gPT0gMCB8fCAhKFtbSVNfQ0hBTkdFRF9TQ1JPTExfWV1dIDw9IFtbU0NST0xMX1ldXSArIDQgJiYgW1tJU19DSEFOR0VEX1NDUk9MTF9ZXV0gPj0gW1tTQ1JPTExfWV1dIC0gNCk=");
		_if(VAR_GET_ALL_COORDINATES == 0 || !(VAR_IS_CHANGED_SCROLL_Y <= VAR_SCROLL_Y + 4 && VAR_IS_CHANGED_SCROLL_Y >= VAR_SCROLL_Y - 4),function(){
		
		   
		   
		   VAR_IS_CHANGED_SCROLL_Y = VAR_SCROLL_Y
		   

		   
		   
		   _set_if_expression("W1tGVU5DQVBUQ0hBX1RZUEVdXSA9PSAiR2FtZV9JdGVtIg==");
		   _if(VAR_FUNCAPTCHA_TYPE == "Game_Item",function(){
		   
			  
			  
			  VAR_ELEMENT_SELECTOR = VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e #image1 \u003e a"
			  

			  
			  
			  _SELECTOR = VAR_ELEMENT_SELECTOR;
			  get_element_selector(_SELECTOR, false).script("(function(){var rect = _BAS_HIDE(BrowserAutomationStudio_GetBoundingClientRect)(self);return (rect.left + positionx) + '|' + (rect.top + positiony) + '|' + (rect.right - rect.left) + '|' + (rect.bottom - rect.top)})();")!
			  var split = _result().split("|");
			  var x = parseInt(split[0]), y = parseInt(split[1]), w = parseInt(split[2]), h = parseInt(split[3]);
			  /// Первый квадрат
			  VAR_SQUARE_BUTTON_X = parseInt(x) + VAR_SCROLL_X;
			  VAR_SQUARE_BUTTON_Y = parseInt(y) + VAR_SCROLL_Y;
			  VAR_SQUARE_WIDTH = parseInt(w)
			  VAR_SQUARE_HEIGHT = parseInt(h)
			  //// Реальный рамзер всех 6 квадратов
			  VAR_REAL_SIZE_WIDTH = VAR_SQUARE_WIDTH * 3;
			  VAR_REAL_SIZE_HEIGHT = VAR_SQUARE_HEIGHT * 2;
			  

		   })!
		   

		   
		   
		   _set_if_expression("W1tGVU5DQVBUQ0hBX1RZUEVdXSA9PSAiR2FtZV9UaWxlIg==");
		   _if(VAR_FUNCAPTCHA_TYPE == "Game_Tile",function(){
		   
			  
			  
			  VAR_ELEMENT_SELECTOR = VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e button[class*=\u0027tile box\u0027]"
			  

			  
			  
			  _SELECTOR = VAR_ELEMENT_SELECTOR;
			  get_element_selector(_SELECTOR, false).script("(function(){var rect = _BAS_HIDE(BrowserAutomationStudio_GetBoundingClientRect)(self);return (rect.left + positionx) + '|' + (rect.top + positiony) + '|' + (rect.right - rect.left) + '|' + (rect.bottom - rect.top)})();")!
			  var split = _result().split("|");
			  var x = parseInt(split[0]), y = parseInt(split[1]), w = parseInt(split[2]), h = parseInt(split[3]);
			  /// Первый квадрат (Версия плитки)
			  VAR_SQUARE_BUTTON_X = parseInt(x) + VAR_SCROLL_X;
			  VAR_SQUARE_BUTTON_Y = parseInt(y) + VAR_SCROLL_Y;
			  VAR_SQUARE_WIDTH = parseInt(w)
			  VAR_SQUARE_HEIGHT = parseInt(h)
			  //// Реальный рамзер всех 6 квадратов
			  VAR_REAL_SIZE_WIDTH = VAR_SQUARE_WIDTH * 3;
			  VAR_REAL_SIZE_HEIGHT = VAR_SQUARE_HEIGHT * 2;
			  

			  
			  
			  VAR_ELEMENT_SELECTOR = VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e button[class*=\u0027tile box\u0027]\u003eAT\u003e2"
			  

			  
			  
			  _SELECTOR = VAR_ELEMENT_SELECTOR;
			  get_element_selector(_SELECTOR, false).script("(function(){var rect = _BAS_HIDE(BrowserAutomationStudio_GetBoundingClientRect)(self);return (rect.left + positionx) + '|' + (rect.top + positiony) + '|' + (rect.right - rect.left) + '|' + (rect.bottom - rect.top)})();")!
			  var split = _result().split("|");
			  var x = parseInt(split[0]), y = parseInt(split[1]), w = parseInt(split[2]), h = parseInt(split[3]);
			  /// Третий квадрат квадрат (Версия плитки)
			  VAR_SQUARE_NUMBER_3 = parseInt(x);
			  

			  
			  
			  _cycle_params().if_else = VAR_SQUARE_BUTTON_X + VAR_SQUARE_WIDTH*2 == VAR_SQUARE_NUMBER_3;
			  _set_if_expression("W1tTUVVBUkVfQlVUVE9OX1hdXSArIFtbU1FVQVJFX1dJRFRIXV0qMiA9PSBbW1NRVUFSRV9OVU1CRVJfM11d");
			  _if(_cycle_params().if_else,function(){
			  
				 
				 
				 VAR_TILE_NORMAL_VIEW = true
				 

			  })!
			  

			  
			  
			  _if(!_cycle_params().if_else,function(){
			  
				 
				 
				 VAR_TILE_NORMAL_VIEW = false
				 

			  })!
			  delete _cycle_params().if_else;
			  

		   })!
		   

		   
		   
		   _set_if_expression("W1tGVU5DQVBUQ0hBX1RZUEVdXSA9PSAiR2FtZV9Cb3gi");
		   _if(VAR_FUNCAPTCHA_TYPE == "Game_Box",function(){
		   
			  
			  
			  VAR_ELEMENT_SELECTOR = VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e a[class*=\u0027right-arrow\u0027]"
			  

			  
			  
			  _SELECTOR = VAR_ELEMENT_SELECTOR;
			  get_element_selector(_SELECTOR, false).script("(function(){var rect = _BAS_HIDE(BrowserAutomationStudio_GetBoundingClientRect)(self);return (rect.left + positionx) + '|' + (rect.top + positiony) + '|' + (rect.right - rect.left) + '|' + (rect.bottom - rect.top)})();")!
			  var split = _result().split("|");
			  var x = parseInt(split[0]), y = parseInt(split[1]), w = parseInt(split[2]), h = parseInt(split[3]);
			  /// Первый квадрат
			  VAR_DIRECT_BUTTON_X = parseInt(x) + VAR_SCROLL_X;
			  VAR_DIRECT_BUTTON_Y = parseInt(y) + VAR_SCROLL_Y;
			  VAR_DIRECT_WIDTH = parseInt(w)
			  VAR_DIRECT_HEIGHT = parseInt(h)
			  ////Высчитаем центр стрелочки
			  VAR_DIRECT_BUTTON_X = VAR_DIRECT_BUTTON_X + VAR_DIRECT_WIDTH/2;
			  VAR_DIRECT_BUTTON_Y = VAR_DIRECT_BUTTON_Y + VAR_DIRECT_HEIGHT/2;
			  

		   })!
		   

		   
		   
		   _set_if_expression("W1tGVU5DQVBUQ0hBX1RZUEVdXSA9PSAiR2FtZV9MaXRlIg==");
		   _if(VAR_FUNCAPTCHA_TYPE == "Game_Lite",function(){
		   
			  
			  
			  VAR_ELEMENT_SELECTOR = VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e input[name*=\u0027challenge-image-overlay-0\u0027]"
			  

			  
			  
			  _SELECTOR = VAR_ELEMENT_SELECTOR;
			  get_element_selector(_SELECTOR, false).script("(function(){var rect = _BAS_HIDE(BrowserAutomationStudio_GetBoundingClientRect)(self);return (rect.left + positionx) + '|' + (rect.top + positiony) + '|' + (rect.right - rect.left) + '|' + (rect.bottom - rect.top)})();")!
			  var split = _result().split("|");
			  var x = parseInt(split[0]), y = parseInt(split[1]), w = parseInt(split[2]), h = parseInt(split[3]);
			  /// Первый квадрат
			  VAR_SQUARE_BUTTON_X = parseInt(x) + VAR_SCROLL_X;
			  VAR_SQUARE_BUTTON_Y = parseInt(y) + VAR_SCROLL_Y;
			  VAR_SQUARE_WIDTH = parseInt(w)
			  VAR_SQUARE_HEIGHT = parseInt(h)
			  //// Реальный рамзер всех 6 квадратов
			  VAR_REAL_SIZE_WIDTH = VAR_SQUARE_WIDTH * 3;
			  VAR_REAL_SIZE_HEIGHT = VAR_SQUARE_HEIGHT * 2;
			  

		   })!
		   

		   
		   
		   _set_if_expression("W1tGVU5DQVBUQ0hBX1RZUEVdXSA9PSAiR2FtZV9DaGlsZHJlbiI=");
		   _if(VAR_FUNCAPTCHA_TYPE == "Game_Children",function(){
		   
			  
			  
			  VAR_ELEMENT_SELECTOR = VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e a[id*=\u0027children_arrowRight\u0027]"
			  

			  
			  
			  _SELECTOR = VAR_ELEMENT_SELECTOR;
			  get_element_selector(_SELECTOR, false).script("(function(){var rect = _BAS_HIDE(BrowserAutomationStudio_GetBoundingClientRect)(self);return (rect.left + positionx) + '|' + (rect.top + positiony) + '|' + (rect.right - rect.left) + '|' + (rect.bottom - rect.top)})();")!
			  var split = _result().split("|");
			  var x = parseInt(split[0]), y = parseInt(split[1]), w = parseInt(split[2]), h = parseInt(split[3]);
			  /// Первый квадрат
			  VAR_DIRECT_BUTTON_X = parseInt(x) + VAR_SCROLL_X;
			  VAR_DIRECT_BUTTON_Y = parseInt(y) + VAR_SCROLL_Y;
			  VAR_DIRECT_WIDTH = parseInt(w)
			  VAR_DIRECT_HEIGHT = parseInt(h)
			  ////Высчитаем центр стрелочки
			  VAR_DIRECT_BUTTON_X = VAR_DIRECT_BUTTON_X + VAR_DIRECT_WIDTH/2;
			  VAR_DIRECT_BUTTON_Y = VAR_DIRECT_BUTTON_Y + VAR_DIRECT_HEIGHT/2;
			  

		   })!
		   

		   
		   
		   VAR_GET_ALL_COORDINATES = "1"
		   

		})!
		

	 },null)!
	 

	 
	 
	 _set_if_expression("W1tXQVNfRVJST1JdXQ==");
	 _if(typeof(VAR_WAS_ERROR) !== "undefined" ? (VAR_WAS_ERROR) : undefined,function(){
	 
		
		
		_set_if_expression("W1tMQVNUX0VSUk9SXV0gPT09ICdBYm9ydGVkIEJ5IFVzZXInIHx8IFtbTEFTVF9FUlJPUl1dICA9PT0gJ9Cf0YDQtdGA0LLQsNC90L4g0J/QvtC70YzQt9C+0LLQsNGC0LXQu9C10Lwn");
		_if(VAR_LAST_ERROR === 'Aborted By User' || VAR_LAST_ERROR  === 'Прервано Пользователем',function(){
		
		   
		   
		   _function_return(false)
		   

		})!
		

		
		
		/*Browser*/
		cache_data_clear()!
		

		
		
		fail(VAR_LAST_ERROR)
		

	 })!
	 

	 
	 
	 _call(function()
	 {
	 _on_fail(function(){
	 VAR_LAST_ERROR = _result()
	 VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
	 VAR_WAS_ERROR = false
	 _break(1,true)
	 })
	 CYCLES.Current().RemoveLabel("function")
	 
		
		
		_set_if_expression("W1tGVU5DQVBUQ0hBX1RZUEVdXSA9PSAiR2FtZV9JdGVtIg==");
		_if(VAR_FUNCAPTCHA_TYPE == "Game_Item",function(){
		
		   
		   
		   _set_if_expression("W1tGSVJTVF9MT0FEX0NBUFRDSEFdXSA9PSB0cnVl");
		   _if(VAR_FIRST_LOAD_CAPTCHA == true,function(){
		   
			  
			  
			  /*Browser*/
			  wait_load("*rtig/image*")!
			  

		   })!
		   

		   
		   
		   /*Browser*/
		   ;_SELECTOR=VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e #game_challengeItem";
		   get_element_selector(_SELECTOR, false).nowait().exist()!
		   VAR_IS_EXISTS = _result() == 1
		   _if(VAR_IS_EXISTS, function(){
		   get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
		   VAR_IS_EXISTS = _result().indexOf("true")>=0
		   })!
		   

		   
		   
		   _set_if_expression("W1tJU19FWElTVFNdXSA9PSBmYWxzZQ==");
		   _if(VAR_IS_EXISTS == false,function(){
		   
			  
			  
			  sleep(200)!
			  

			  
			  
			  _next("function")
			  

		   })!
		   

		   
		   
		   /*Browser*/
		   _SELECTOR = VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e #game_challengeItem_image";waiter_timeout_next(20000)
		   wait_element(_SELECTOR)!
		   

		   
		   
		   sleep(200)!
		   

		   
		   
		   /*Browser*/
		   _SELECTOR = VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e #game_challengeItem_image";
		   wait_element(_SELECTOR)!
		   get_element_selector(_SELECTOR, false).attr("src")!
		   VAR_SAVED_ATTRIBUTE = _result()
		   

		   
		   
		   _set_if_expression("W1tTQVZFRF9BVFRSSUJVVEVdXS5pbmRleE9mKCJkYXRhOmltYWdlL2dpZjtiYXNlNjQiKSA+PSAw");
		   _if(VAR_SAVED_ATTRIBUTE.indexOf("data:image/gif;base64") >= 0,function(){
		   
			  
			  
			  var replace_string_funcap = "data:image/gif;base64,"
			  VAR_IMAGE_BASE_64 = VAR_SAVED_ATTRIBUTE.replace(replace_string_funcap, "")
			  

			  
			  
			  VAR_LOADED_IMAGE_ID = native("imageprocessing", "load", VAR_IMAGE_BASE_64)
			  

			  
			  
			  var split = native("imageprocessing", "convert", (VAR_LOADED_IMAGE_ID) + "," + ("jpeg"))
			  

			  
			  
			  {
			  var split = native("imageprocessing", "getsize", VAR_LOADED_IMAGE_ID).split(",")
			  VAR_GET_IMAGE_W = parseInt(split[0])
			  VAR_GET_IMAGE_H = parseInt(split[1])
			  }
			  

			  
			  
			  VAR_IMAGE_BASE_64 = native("imageprocessing", "getdata", VAR_LOADED_IMAGE_ID)
			  

			  
			  
			  native("imageprocessing", "delete", VAR_LOADED_IMAGE_ID)
			  

		   })!
		   

		   
		   
		   _set_if_expression("W1tTQVZFRF9BVFRSSUJVVEVdXS5pbmRleE9mKCJkYXRhOmltYWdlL2pwZWc7YmFzZTY0IikgPj0gMA==");
		   _if(VAR_SAVED_ATTRIBUTE.indexOf("data:image/jpeg;base64") >= 0,function(){
		   
			  
			  
			  var replace_string_funcap = "data:image/jpeg;base64,"
			  VAR_IMAGE_BASE_64 = VAR_SAVED_ATTRIBUTE.replace(replace_string_funcap, "")
			  

			  
			  
			  VAR_LOADED_IMAGE_ID = native("imageprocessing", "load", VAR_IMAGE_BASE_64)
			  

			  
			  
			  {
			  var split = native("imageprocessing", "getsize", VAR_LOADED_IMAGE_ID).split(",")
			  VAR_GET_IMAGE_W = parseInt(split[0])
			  VAR_GET_IMAGE_H = parseInt(split[1])
			  }
			  

			  
			  
			  native("imageprocessing", "delete", VAR_LOADED_IMAGE_ID)
			  

		   })!
		   

		})!
		

		
		
		_set_if_expression("W1tGVU5DQVBUQ0hBX1RZUEVdXSA9PSAiR2FtZV9UaWxlIg==");
		_if(VAR_FUNCAPTCHA_TYPE == "Game_Tile",function(){
		
		   
		   
		   /*Browser*/
		   ;_SELECTOR=VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e div[class*=\u0027tile-game box screen\u0027]";
		   get_element_selector(_SELECTOR, false).nowait().exist()!
		   VAR_IS_EXISTS = _result() == 1
		   _if(VAR_IS_EXISTS, function(){
		   get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
		   VAR_IS_EXISTS = _result().indexOf("true")>=0
		   })!
		   

		   
		   
		   _set_if_expression("W1tJU19FWElTVFNdXSA9PSBmYWxzZQ==");
		   _if(VAR_IS_EXISTS == false,function(){
		   
			  
			  
			  sleep(200)!
			  

			  
			  
			  _next("function")
			  

		   })!
		   

		   
		   
		   /*Browser*/
		   waiter_timeout_next(45000)
		   wait_load("*blob*")!
		   

		   
		   
		   /*Browser*/
		   wait_load("*blob*")!
		   cache_get_base64("*blob*")!
		   VAR_IMAGE_BASE_64 = _result()
		   

		   
		   
		   VAR_LOADED_IMAGE_ID = native("imageprocessing", "load", VAR_IMAGE_BASE_64)
		   

		   
		   
		   {
		   var split = native("imageprocessing", "getsize", VAR_LOADED_IMAGE_ID).split(",")
		   VAR_GET_IMAGE_W = parseInt(split[0])
		   VAR_GET_IMAGE_H = parseInt(split[1])
		   }
		   

		   
		   
		   native("imageprocessing", "delete", VAR_LOADED_IMAGE_ID)
		   

		})!
		

		
		
		_set_if_expression("W1tGVU5DQVBUQ0hBX1RZUEVdXSA9PSAiR2FtZV9MaXRlIg==");
		_if(VAR_FUNCAPTCHA_TYPE == "Game_Lite",function(){
		
		   
		   
		   /*Browser*/
		   ;_SELECTOR=VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e img[id*=\u0027challenge-image\u0027]";
		   get_element_selector(_SELECTOR, false).nowait().exist()!
		   VAR_IS_EXISTS = _result() == 1
		   _if(VAR_IS_EXISTS, function(){
		   get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
		   VAR_IS_EXISTS = _result().indexOf("true")>=0
		   })!
		   

		   
		   
		   _set_if_expression("W1tJU19FWElTVFNdXSA9PSBmYWxzZQ==");
		   _if(VAR_IS_EXISTS == false,function(){
		   
			  
			  
			  sleep(400)!
			  

			  
			  
			  _next("function")
			  

		   })!
		   

		   
		   
		   /*Browser*/
		   waiter_timeout_next(45000)
		   wait_load("*/rtig/image*")!
		   

		   
		   
		   /*Browser*/
		   wait_load("*/rtig/image*")!
		   cache_get_base64("*/rtig/image*")!
		   VAR_IMAGE_BASE_64 = _result()
		   

		   
		   
		   VAR_LOADED_IMAGE_ID = native("imageprocessing", "load", VAR_IMAGE_BASE_64)
		   

		   
		   
		   {
		   var split = native("imageprocessing", "getsize", VAR_LOADED_IMAGE_ID).split(",")
		   VAR_GET_IMAGE_W = parseInt(split[0])
		   VAR_GET_IMAGE_H = parseInt(split[1])
		   }
		   

		   
		   
		   native("imageprocessing", "delete", VAR_LOADED_IMAGE_ID)
		   

		})!
		

		
		
		_set_if_expression("W1tGVU5DQVBUQ0hBX1RZUEVdXSA9PSAiR2FtZV9Cb3gi");
		_if(VAR_FUNCAPTCHA_TYPE == "Game_Box",function(){
		
		   
		   
		   /*Browser*/
		   ;_SELECTOR=VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e div[class*=\u0027match-game box screen\u0027]";
		   get_element_selector(_SELECTOR, false).nowait().exist()!
		   VAR_IS_EXISTS = _result() == 1
		   _if(VAR_IS_EXISTS, function(){
		   get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
		   VAR_IS_EXISTS = _result().indexOf("true")>=0
		   })!
		   

		   
		   
		   _set_if_expression("W1tJU19FWElTVFNdXSA9PSBmYWxzZQ==");
		   _if(VAR_IS_EXISTS == false,function(){
		   
			  
			  
			  sleep(300)!
			  

			  
			  
			  _next("function")
			  

		   })!
		   

		   
		   
		   /*Browser*/
		   waiter_timeout_next(45000)
		   wait_load("*blob*")!
		   

		   
		   
		   /*Browser*/
		   wait_load("*blob*")!
		   cache_get_base64("*blob*")!
		   VAR_IMAGE_BASE_64 = _result()
		   

		})!
		

		
		
		_set_if_expression("W1tGVU5DQVBUQ0hBX1RZUEVdXSA9PSAiR2FtZV9DaGlsZHJlbiI=");
		_if(VAR_FUNCAPTCHA_TYPE == "Game_Children",function(){
		
		   
		   
		   _set_if_expression("W1tGSVJTVF9MT0FEX0NBUFRDSEFdXSA9PSB0cnVl");
		   _if(VAR_FIRST_LOAD_CAPTCHA == true,function(){
		   
			  
			  
			  /*Browser*/
			  wait_load("*rtig/image*")!
			  

		   })!
		   

		   
		   
		   /*Browser*/
		   ;_SELECTOR=VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e img[id*=\u0027children_challengeImage\u0027]";
		   get_element_selector(_SELECTOR, false).nowait().exist()!
		   VAR_IS_EXISTS = _result() == 1
		   _if(VAR_IS_EXISTS, function(){
		   get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
		   VAR_IS_EXISTS = _result().indexOf("true")>=0
		   })!
		   

		   
		   
		   _set_if_expression("W1tJU19FWElTVFNdXSA9PSBmYWxzZQ==");
		   _if(VAR_IS_EXISTS == false,function(){
		   
			  
			  
			  sleep(500)!
			  

			  
			  
			  _next("function")
			  

		   })!
		   

		   
		   
		   /*Browser*/
		   _SELECTOR = VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e img[id*=\u0027children_challengeImage\u0027]";waiter_timeout_next(20000)
		   wait_element(_SELECTOR)!
		   

		   
		   
		   /*Browser*/
		   _SELECTOR = VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e img[id*=\u0027children_challengeImage\u0027]";
		   wait_element(_SELECTOR)!
		   get_element_selector(_SELECTOR, false).script('_BAS_SAFE(Window.getComputedStyle)(self)[' + JSON.stringify("background") + ']')!
		   VAR_SAVED_STYLE = _result()
		   

		   
		   
		   // Извлекаем
		   var Module_inputString = VAR_SAVED_STYLE
		   var Module_regex = /data:image([^"]*)"/;
		   var Module_match = Module_inputString.match(Module_regex);
		   if (Module_match && Module_match.length >= 2) VAR_SAVED_STYLE = Module_match[1];
		   

		   
		   
		   _set_if_expression("W1tTQVZFRF9TVFlMRV1dLmluZGV4T2YoIi9naWY7YmFzZTY0IikgPj0gMA==");
		   _if(VAR_SAVED_STYLE.indexOf("/gif;base64") >= 0,function(){
		   
			  
			  
			  var replace_string_funcap = "/gif;base64,"
			  VAR_IMAGE_BASE_64 = VAR_SAVED_STYLE.replace(replace_string_funcap, "")
			  

		   })!
		   

		   
		   
		   _set_if_expression("W1tTQVZFRF9TVFlMRV1dLmluZGV4T2YoIi9qcGVnO2Jhc2U2NCIpID49IDA=");
		   _if(VAR_SAVED_STYLE.indexOf("/jpeg;base64") >= 0,function(){
		   
			  
			  
			  var replace_string_funcap = "/jpeg;base64,"
			  VAR_IMAGE_BASE_64 = VAR_SAVED_STYLE.replace(replace_string_funcap, "")
			  

		   })!
		   

		})!
		

	 },null)!
	 

	 
	 
	 _set_if_expression("W1tXQVNfRVJST1JdXQ==");
	 _if(typeof(VAR_WAS_ERROR) !== "undefined" ? (VAR_WAS_ERROR) : undefined,function(){
	 
		
		
		/*Browser*/
		cache_data_clear()!
		

		
		
		fail(VAR_LAST_ERROR)
		

	 })!
	 

	 
	 
	 _call(function()
	 {
	 _on_fail(function(){
	 VAR_LAST_ERROR = _result()
	 VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
	 VAR_WAS_ERROR = false
	 _break(1,true)
	 })
	 CYCLES.Current().RemoveLabel("function")
	 
		
		
		_set_if_expression("W1tGVU5DQVBUQ0hBX1RZUEVdXSA9PSAiR2FtZV9MaXRlIiAmJiBbW0ZJUlNUX0xPQURfQ0FQVENIQV1dID09IHRydWU=");
		_if(VAR_FUNCAPTCHA_TYPE == "Game_Lite" && VAR_FIRST_LOAD_CAPTCHA == true,function(){
		
		   
		   
		   /*Browser*/
		   _SELECTOR = VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e legend[id*=\u0027game-header\u0027]";
		   wait_element(_SELECTOR)!
		   get_element_selector(_SELECTOR, false).text()!
		   VAR_SET_TASK = _result()
		   

		   
		   
		   function removeLastDot(currenttask) {
		   var trimmedString = currenttask.trim();
		   if (!trimmedString || trimmedString.length === 0) {
		   return trimmedString;
		   }
		   if (trimmedString.slice(-1) === '.') {
		   return trimmedString.slice(0, -1);
		   }
		   return trimmedString;
		   }
		   VAR_SET_TASK = removeLastDot(VAR_SET_TASK);
		   

		   
		   
		   _set_if_expression("IShbW1NFVF9UQVNLXV0uaW5kZXhPZigiUGljayIpID49IDAp");
		   _if(!(VAR_SET_TASK.indexOf("Pick") >= 0),function(){
		   
			  
			  
			  VAR_ERROR_TASK_GAME_LITE = "1"
			  

		   })!
		   

		   
		   
		   VAR_CYCLE_INDEX = 0
		   

		   
		   
		   _do(function(){
		   _set_action_info({ name: "While" });
		   VAR_CYCLE_INDEX = _iterator() - 1
		   BREAK_CONDITION = VAR_CYCLE_INDEX < 4;
		   if(!BREAK_CONDITION)_break();
		   
			  
			  
			  /*Browser*/
			  ;_SELECTOR=VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e fieldset \u003e div \u003eAT\u003e " + VAR_CYCLE_INDEX;
			  get_element_selector(_SELECTOR, false).nowait().exist()!
			  VAR_IS_EXISTS = _result() == 1
			  _if(VAR_IS_EXISTS, function(){
			  get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
			  VAR_IS_EXISTS = _result().indexOf("true")>=0
			  })!
			  

			  
			  
			  _set_if_expression("W1tJU19FWElTVFNdXQ==");
			  _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
			  
				 
				 
				 /*Browser*/
				 _SELECTOR = VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e fieldset \u003e div \u003eAT\u003e " + VAR_CYCLE_INDEX;
				 wait_element(_SELECTOR)!
				 get_element_selector(_SELECTOR, false).text()!
				 VAR_MAX_NUMBERS_TASK = _result()
				 

				 
				 
				 function findLargestNumber(str) {
				 var bignumber = str.match(/-?\d+(\.\d+)?/g);
				 if (!bignumber || bignumber.length === 0) {
				 return null;
				 }
				 var numericValues = bignumber.map(function(num) {
				 return parseFloat(num);
				 });
				 var largestNumber = Math.max.apply(null, numericValues);
				 if (largestNumber <= 20)
				 {
				 return largestNumber
				 }
				 else
				 {
				 return 1
				 }
				 }
				 VAR_CURRENT_TASK_NUMBERS = findLargestNumber(VAR_MAX_NUMBERS_TASK);
				 

				 
				 
				 VAR_ALL_TASK_NUMBERS = VAR_CURRENT_TASK_NUMBERS
				 

			  })!
			  

		   })!
		   

		})!
		

	 },null)!
	 

	 
	 
	 _set_if_expression("W1tXQVNfRVJST1JdXQ==");
	 _if(typeof(VAR_WAS_ERROR) !== "undefined" ? (VAR_WAS_ERROR) : undefined,function(){
	 
		
		
		_set_if_expression("W1tMQVNUX0VSUk9SXV0gPT09ICdBYm9ydGVkIEJ5IFVzZXInIHx8IFtbTEFTVF9FUlJPUl1dICA9PT0gJ9Cf0YDQtdGA0LLQsNC90L4g0J/QvtC70YzQt9C+0LLQsNGC0LXQu9C10Lwn");
		_if(VAR_LAST_ERROR === 'Aborted By User' || VAR_LAST_ERROR  === 'Прервано Пользователем',function(){
		
		   
		   
		   _function_return(false)
		   

		})!
		

		
		
		/*Browser*/
		cache_data_clear()!
		

		
		
		fail(VAR_LAST_ERROR)
		

	 })!
	 

	 
	 
	 _set_if_expression("W1tFUlJPUl9UQVNLX0dBTUVfTElURV1dID09IDE=");
	 _if(VAR_ERROR_TASK_GAME_LITE == 1,function(){
	 
		
		
		/*Browser*/
		cache_data_clear()!
		

		
		
		fail((_K==="en" ? "Failed to solve FunCaptcha, this type of captcha " + VAR_FUNCAPTCHA_TYPE + " module supports English language only." : "Не удалось решить FunCaptcha, этот вид каптчи: " + VAR_FUNCAPTCHA_TYPE + " модуль поддерживает только на английском языке."));
		

	 })!
	 

	 
	 
	 VAR_FIRST_LOAD_CAPTCHA = false
	 

	 
	 
	 _set_if_expression("dHlwZW9mKFtbSU1BR0VfQkFTRV82NF1dKSA9PSAidW5kZWZpbmVkIg==");
	 _if(typeof(VAR_IMAGE_BASE_64) == "undefined",function(){
	 
		
		
		_next("function")
		

	 })!
	 

	 
	 
	 _call(function()
	 {
	 _on_fail(function(){
	 VAR_LAST_ERROR = _result()
	 VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
	 VAR_WAS_ERROR = false
	 _break(1,true)
	 })
	 CYCLES.Current().RemoveLabel("function")
	 
		
		
		_do(function(){
		_set_action_info({ name: "For" });
		VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
		if(VAR_CYCLE_INDEX > parseInt(20))_break();
		
		   
		   
		   ///Чистим
		   solver_properties_clear("capmonster")	   
		   if (VAR_FUNCAPTCHA_TYPE == "Game_Item") var now_return_type = "funcap|";
		   if (VAR_FUNCAPTCHA_TYPE == "Game_Tile") var now_return_type = "funcap|";
		   if (VAR_FUNCAPTCHA_TYPE == "Game_Lite") var now_return_type = "funcap|";
		   if (VAR_FUNCAPTCHA_TYPE == "Game_Box") var now_return_type = "funcap2|";
		   if (VAR_FUNCAPTCHA_TYPE == "Game_Children") var now_return_type = "funcap2|";

		   /// Формирумем основной запрос
		   solver_property("capmonster","serverurl","http://sctg.xyz")
		   solver_property("capmonster","key",VAR_KEY_MODULE)
		   solver_property("capmonster","imginstructions",VAR_SET_TASK)
		   solver_property("capmonster","click",now_return_type)
		   solver_property("capmonster","method","post")
		   //// Отправляем
		   solve_base64_no_fail("capmonster", VAR_IMAGE_BASE_64)!
		   VAR_SAVED_CONTENT = _result();
		   

		   
		   
		   _set_if_expression("W1tTQVZFRF9DT05URU5UXV0uaW5kZXhPZigiRVJST1JfQ0FQVENIQV9VTlNPTFZBQkxFIikgPj0gMA==");
		   _if(VAR_SAVED_CONTENT.indexOf("ERROR_CAPTCHA_UNSOLVABLE") >= 0,function(){
		   
			  
			  
			  VAR_ERROR_TASK = parseInt(VAR_ERROR_TASK) + parseInt(1)
			  

			  
			  
			  sleep(1000)!
			  

			  
			  
			  _break("function")
			  

		   })!
		   

		   
		   
		   _set_if_expression("W1tTQVZFRF9DT05URU5UXV0uaW5kZXhPZigiRVJST1JfV1JPTkdfVVNFUl9LRVkiKSA+PSAw");
		   _if(VAR_SAVED_CONTENT.indexOf("ERROR_WRONG_USER_KEY") >= 0,function(){
		   
			  
			  
			  VAR_ERROR_KEY = "1"
			  

			  
			  
			  _break("function")
			  

		   })!
		   

		   
		   
		   _set_if_expression("W1tTQVZFRF9DT05URU5UXV0uaW5kZXhPZigiRVJST1JfWkVST19CQUxBTkNFIikgPj0gMA==");
		   _if(VAR_SAVED_CONTENT.indexOf("ERROR_ZERO_BALANCE") >= 0,function(){
		   
			  
			  
			  VAR_ERROR_BALANCE = "1"
			  

			  
			  
			  _break("function")
			  

		   })!
		   

		   
		   
		   _set_if_expression("W1tTQVZFRF9DT05URU5UXV0uaW5kZXhPZigiQ0FQVENIQV9GQUlMIikgPj0gMA==");
		   _if(VAR_SAVED_CONTENT.indexOf("CAPTCHA_FAIL") >= 0,function(){
		   
			  
			  
			  sleep(rand(1000,2000))!
			  

			  
			  
			  VAR_CAPTCHA_FAIL = parseInt(VAR_CAPTCHA_FAIL) + parseInt(1)
			  

			  
			  
			  _break("function")
			  

		   })!
		   

		   
		   
		   _cycle_params().if_else = VAR_SAVED_CONTENT.match(/^\d+$/) && (VAR_FUNCAPTCHA_TYPE == "Game_Box" || VAR_FUNCAPTCHA_TYPE == "Game_Children") || VAR_SAVED_CONTENT.match(/[0-9]/) && VAR_SAVED_CONTENT.indexOf("coordinates") >= 0 && VAR_FUNCAPTCHA_TYPE != "Game_Box" && VAR_FUNCAPTCHA_TYPE != "Game_Children";
		   _set_if_expression("W1tTQVZFRF9DT05URU5UXV0ubWF0Y2goL15cZCskLykgJiYgKFtbRlVOQ0FQVENIQV9UWVBFXV0gPT0gIkdhbWVfQm94IiB8fCBbW0ZVTkNBUFRDSEFfVFlQRV1dID09ICJHYW1lX0NoaWxkcmVuIikgfHwgW1tTQVZFRF9DT05URU5UXV0ubWF0Y2goL1swLTldLykgJiYgW1tTQVZFRF9DT05URU5UXV0uaW5kZXhPZigiY29vcmRpbmF0ZXMiKSA+PSAwICYmIFtbRlVOQ0FQVENIQV9UWVBFXV0gIT0gIkdhbWVfQm94IiAmJiBbW0ZVTkNBUFRDSEFfVFlQRV1dICE9ICJHYW1lX0NoaWxkcmVuIg==");
		   _if(_cycle_params().if_else,function(){
			  

			  
			  
			  /*Browser*/
			  cache_data_clear()!
			  

			  
			  
			  _set_if_expression("W1tGVU5DQVBUQ0hBX1RZUEVdXSA9PSAiR2FtZV9JdGVtIiB8fCBbW0ZVTkNBUFRDSEFfVFlQRV1dID09ICJHYW1lX0xpdGUiIHx8IFtbRlVOQ0FQVENIQV9UWVBFXV0gPT0gIkdhbWVfVGlsZSI=");
			  _if(VAR_FUNCAPTCHA_TYPE == "Game_Item" || VAR_FUNCAPTCHA_TYPE == "Game_Lite" || VAR_FUNCAPTCHA_TYPE == "Game_Tile",function(){
			  
				 
				 
				 VAR_LISTS_COORDINATES = VAR_SAVED_CONTENT
				 VAR_LISTS_COORDINATES = VAR_LISTS_COORDINATES.split("coordinates:")[1];
				 VAR_LISTS_COORDINATES = VAR_LISTS_COORDINATES.split(";");
				 

				 
				 
				 ;(function (a) {var j, x, i;for (i = a.length; i; i--) {j = Math.floor(Math.random() * i);x = a[i - 1]; a[i - 1] = a[j];a[j] = x;}})(VAR_LISTS_COORDINATES)
				 

				 
				 
				 _do_with_params({"foreach_data":(VAR_LISTS_COORDINATES)},function(){
				 _set_action_info({ name: "Foreach" });
				 VAR_CYCLE_INDEX = _iterator() - 1
				 if(VAR_CYCLE_INDEX > _cycle_param("foreach_data").length - 1)_break();
				 VAR_FOREACH_DATA = _cycle_param("foreach_data")[VAR_CYCLE_INDEX]
				 
					
					
					var csv_parse_result = csv_parse(VAR_FOREACH_DATA)
					VAR_ANSWER_X = csv_parse_result[0]
					if(typeof(VAR_ANSWER_X) == 'undefined' || !VAR_ANSWER_X)
					{
					VAR_ANSWER_X = ""
					}
					VAR_ANSWER_Y = csv_parse_result[1]
					if(typeof(VAR_ANSWER_Y) == 'undefined' || !VAR_ANSWER_Y)
					{
					VAR_ANSWER_Y = ""
					}
					

					
					
					VAR_ANSWER_X = VAR_ANSWER_X.replace(/[^0-9]/g, '');
					VAR_ANSWER_Y = VAR_ANSWER_Y.replace(/[^0-9]/g, '');
					VAR_ANSWER_X = parseInt(VAR_ANSWER_X)
					VAR_ANSWER_Y = parseInt(VAR_ANSWER_Y)
					if (VAR_TILE_NORMAL_VIEW == 0 || VAR_TILE_NORMAL_VIEW == true)
					{
					/// Реальные размеры картинки из кэша
					var bigWidth = VAR_GET_IMAGE_W;
					var bigHeight = VAR_GET_IMAGE_H;
					/// Реальные размеры картинки из СSS окна
					var smallWidth = VAR_REAL_SIZE_WIDTH;
					var smallHeight = VAR_REAL_SIZE_HEIGHT;
					// Координата x и y на большой картинке
					var xBig = VAR_ANSWER_X;
					var yBig = VAR_ANSWER_Y;
					/// Преобразуем в новую координату
					VAR_ANSWER_X = xBig / bigWidth  * smallWidth;
					VAR_ANSWER_Y = yBig / bigHeight * smallHeight;
					}
					if (VAR_FUNCAPTCHA_TYPE == "Game_Tile" && VAR_TILE_NORMAL_VIEW == false) {
					/// Переворачиваем координаты
					if (VAR_ANSWER_X == 150 && VAR_ANSWER_Y == 150) VAR_ANSWER_X = 50, VAR_ANSWER_Y = 250
					if (VAR_ANSWER_X == 50 && VAR_ANSWER_Y == 150) VAR_ANSWER_X = 150, VAR_ANSWER_Y = 150
					if (VAR_ANSWER_X == 250 && VAR_ANSWER_Y == 50) VAR_ANSWER_X = 50, VAR_ANSWER_Y = 150
					if (VAR_ANSWER_X == 250 && VAR_ANSWER_Y == 150) VAR_ANSWER_X = 150, VAR_ANSWER_Y = 250
					}
					

					
					
					VAR_SQUARE_BUTTON_X_CLICK = 0;
					VAR_SQUARE_BUTTON_Y_CLICK = 0;
					VAR_SQUARE_BUTTON_X_CLICK = VAR_SQUARE_BUTTON_X + VAR_ANSWER_X + rand (-10,+10);
					VAR_SQUARE_BUTTON_Y_CLICK = VAR_SQUARE_BUTTON_Y + VAR_ANSWER_Y + rand (-10,+10);
					

					
					
					/*Browser*/
					move(VAR_SQUARE_BUTTON_X_CLICK,VAR_SQUARE_BUTTON_Y_CLICK,  {"speed": VAR_SPEED,"gravity": VAR_GRAVITY,"deviation": VAR_DEVIATION} )!
					mouse(VAR_SQUARE_BUTTON_X_CLICK,VAR_SQUARE_BUTTON_Y_CLICK)!
					

				 })!
				 

			  })!
			  

			  
			  
			  _set_if_expression("KFtbRlVOQ0FQVENIQV9UWVBFXV0gPT0gIkdhbWVfQm94IiB8fCBbW0ZVTkNBUFRDSEFfVFlQRV1dID09ICJHYW1lX0NoaWxkcmVuIikgJiYgW1tTQVZFRF9DT05URU5UXV0gIT0x");
			  _if((VAR_FUNCAPTCHA_TYPE == "Game_Box" || VAR_FUNCAPTCHA_TYPE == "Game_Children") && VAR_SAVED_CONTENT !=1,function(){
			  
				 
				 
				 _do(function(){
				 _set_action_info({ name: "For" });
				 VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
				 if(VAR_CYCLE_INDEX > parseInt(VAR_SAVED_CONTENT - 1))_break();
				 
					
					
					VAR_DIRECT_BUTTON_X_CLICK = 0;
					VAR_DIRECT_BUTTON_Y_CLICK = 0;
					VAR_DIRECT_BUTTON_X_CLICK = VAR_DIRECT_BUTTON_X + rand(-6,+6);
					VAR_DIRECT_BUTTON_Y_CLICK = VAR_DIRECT_BUTTON_Y + rand(-6,+6);
					

					
					
					/*Browser*/
					move(VAR_DIRECT_BUTTON_X_CLICK,VAR_DIRECT_BUTTON_Y_CLICK,  {} )!
					mouse(VAR_DIRECT_BUTTON_X_CLICK,VAR_DIRECT_BUTTON_Y_CLICK)!
					

					
					
					_cycle_params().if_else = rand (1,10) > 5;
					_set_if_expression("cmFuZCAoMSwxMCkgPiA1");
					_if(_cycle_params().if_else,function(){
					
					   
					   
					   sleep(rand(100,200))!
					   

					})!
					

					
					
					_if(!_cycle_params().if_else,function(){
					
					   
					   
					   sleep(rand(400,800))!
					   

					})!
					delete _cycle_params().if_else;
					

					
					
					_set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gMjU=");
					_if(VAR_CYCLE_INDEX > 25,function(){
					
					   
					   
					   _break("function")
					   

					})!
					

				 })!
				 

				 
				 
				 /*Browser*/
				 ;_SELECTOR=VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e img[style*=\u0027blob\u0027]";
				 get_element_selector(_SELECTOR, false).nowait().exist()!
				 VAR_IS_EXISTS = _result() == 1
				 _if(VAR_IS_EXISTS, function(){
				 get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
				 VAR_IS_EXISTS = _result().indexOf("true")>=0
				 })!
				 

				 
				 
				 _set_if_expression("W1tJU19FWElTVFNdXQ==");
				 _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
				 
					
					
					sleep(100)!
					

					
					
					/*Browser*/
					_SELECTOR = VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e img[style*=\u0027blob\u0027]";
					wait_element(_SELECTOR)!
					get_element_selector(_SELECTOR, false).attr("aria-label")!
					VAR_SAVED_ATTRIBUTE = _result()
					

					
					
					function findSmallestNumber(str) {
					var numbers = str.match(/-?\d+(\.\d+)?/g); // получаем все числа из строки
					var smallest = Math.min.apply(Math, numbers); // находим минимальное число
					return smallest;
					}
					var str = VAR_SAVED_ATTRIBUTE
					VAR_MIN_NUMBERS_TASK = findSmallestNumber(str);
					

					
					
					_set_if_expression("W1tNSU5fTlVNQkVSU19UQVNLXV0gPT0gMQ==");
					_if(VAR_MIN_NUMBERS_TASK == 1,function(){
					
					   
					   
					   VAR_ELEMENT_SELECTOR = VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e a[class*=\u0027left-arrow\u0027]"
					   

					   
					   
					   _SELECTOR = VAR_ELEMENT_SELECTOR;
					   get_element_selector(_SELECTOR, false).script("(function(){var rect = _BAS_HIDE(BrowserAutomationStudio_GetBoundingClientRect)(self);return (rect.left + positionx) + '|' + (rect.top + positiony) + '|' + (rect.right - rect.left) + '|' + (rect.bottom - rect.top)})();")!
					   var split = _result().split("|");
					   var x = parseInt(split[0]), y = parseInt(split[1]), w = parseInt(split[2]), h = parseInt(split[3]);
					   /// Первый квадрат
					   VAR_DIRECT_BUTTON_X = parseInt(x)
					   VAR_DIRECT_BUTTON_Y = parseInt(y) + VAR_SCROLL_Y;
					   VAR_DIRECT_WIDTH = parseInt(w)
					   VAR_DIRECT_HEIGHT = parseInt(h)
					   ////Высчитаем центр стрелочки
					   VAR_DIRECT_BUTTON_X = VAR_DIRECT_BUTTON_X + VAR_DIRECT_WIDTH/2;
					   VAR_DIRECT_BUTTON_Y = VAR_DIRECT_BUTTON_Y + VAR_DIRECT_HEIGHT/2;
					   

					   
					   
					   _do(function(){
					   _set_action_info({ name: "For" });
					   VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
					   if(VAR_CYCLE_INDEX > parseInt(10))_break();
					   
						  
						  
						  _set_if_expression("W1tTQVZFRF9DT05URU5UXV0gPT0gNg==");
						  _if(VAR_SAVED_CONTENT == 6,function(){
						  
							 
							 
							 VAR_SAVED_CONTENT = "1"
							 

							 
							 
							 _break("function")
							 

						  })!
						  

						  
						  
						  _set_if_expression("W1tTQVZFRF9DT05URU5UXV0gPT0gNQ==");
						  _if(VAR_SAVED_CONTENT == 5,function(){
						  
							 
							 
							 VAR_SAVED_CONTENT = "2"
							 

							 
							 
							 _break("function")
							 

						  })!
						  

						  
						  
						  _set_if_expression("W1tTQVZFRF9DT05URU5UXV0gPT0gNA==");
						  _if(VAR_SAVED_CONTENT == 4,function(){
						  
							 
							 
							 VAR_SAVED_CONTENT = "3"
							 

							 
							 
							 _break("function")
							 

						  })!
						  

						  
						  
						  _set_if_expression("W1tTQVZFRF9DT05URU5UXV0gPT0gMw==");
						  _if(VAR_SAVED_CONTENT == 3,function(){
						  
							 
							 
							 VAR_SAVED_CONTENT = "4"
							 

							 
							 
							 _break("function")
							 

						  })!
						  

						  
						  
						  _set_if_expression("W1tTQVZFRF9DT05URU5UXV0gPT0gMg==");
						  _if(VAR_SAVED_CONTENT == 2,function(){
						  
							 
							 
							 VAR_SAVED_CONTENT = "5"
							 

							 
							 
							 _break("function")
							 

						  })!
						  

						  
						  
						  sleep(300)!
						  

					   })!
					   

					   
					   
					   _do(function(){
					   _set_action_info({ name: "For" });
					   VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
					   if(VAR_CYCLE_INDEX > parseInt(VAR_SAVED_CONTENT))_break();
					   
						  
						  
						  VAR_DIRECT_BUTTON_X_CLICK = 0;
						  VAR_DIRECT_BUTTON_Y_CLICK = 0;
						  VAR_DIRECT_BUTTON_X_CLICK = VAR_DIRECT_BUTTON_X + rand(-3,+3);
						  VAR_DIRECT_BUTTON_Y_CLICK = VAR_DIRECT_BUTTON_Y + rand(-3,+3);
						  

						  
						  
						  /*Browser*/
						  move(VAR_DIRECT_BUTTON_X_CLICK,VAR_DIRECT_BUTTON_Y_CLICK,  {} )!
						  mouse(VAR_DIRECT_BUTTON_X_CLICK,VAR_DIRECT_BUTTON_Y_CLICK)!
						  

						  
						  
						  _cycle_params().if_else = rand (1,10) > 5;
						  _set_if_expression("cmFuZCAoMSwxMCkgPiA1");
						  _if(_cycle_params().if_else,function(){
						  
							 
							 
							 sleep(rand(100,200))!
							 

						  })!
						  

						  
						  
						  _if(!_cycle_params().if_else,function(){
						  
							 
							 
							 sleep(rand(400,800))!
							 

						  })!
						  delete _cycle_params().if_else;
						  

						  
						  
						  _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gMjA=");
						  _if(VAR_CYCLE_INDEX > 20,function(){
						  
							 
							 
							 _break("function")
							 

						  })!
						  

					   })!
					   

					   
					   
					   VAR_GET_ALL_COORDINATES = "0"
					   

					})!
					

				 })!
				 

				 
				 
				 /*Browser*/
				 ;_SELECTOR=VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e img[id*=\u0027children_challengeImage\u0027]";
				 get_element_selector(_SELECTOR, false).nowait().exist()!
				 VAR_IS_EXISTS = _result() == 1
				 _if(VAR_IS_EXISTS, function(){
				 get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
				 VAR_IS_EXISTS = _result().indexOf("true")>=0
				 })!
				 

				 
				 
				 _set_if_expression("W1tJU19FWElTVFNdXQ==");
				 _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
				 
					
					
					sleep(100)!
					

					
					
					/*Browser*/
					_SELECTOR = VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e img[id*=\u0027children_challengeImage\u0027]";
					wait_element(_SELECTOR)!
					get_element_selector(_SELECTOR, false).attr("aria-label")!
					VAR_SAVED_ATTRIBUTE = _result()
					

					
					
					function findSmallestNumber(str) {
					var numbers = str.match(/-?\d+(\.\d+)?/g); // получаем все числа из строки
					var smallest = Math.min.apply(Math, numbers); // находим минимальное число
					return smallest;
					}
					var str = VAR_SAVED_ATTRIBUTE
					VAR_MIN_NUMBERS_TASK = findSmallestNumber(str);
					

					
					
					_set_if_expression("W1tNSU5fTlVNQkVSU19UQVNLXV0gPT0gMQ==");
					_if(VAR_MIN_NUMBERS_TASK == 1,function(){
					
					   
					   
					   VAR_ELEMENT_SELECTOR = VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e a[id*=\u0027Frame_children_arrowLeft\u0027]"
					   

					   
					   
					   _SELECTOR = VAR_ELEMENT_SELECTOR;
					   get_element_selector(_SELECTOR, false).script("(function(){var rect = _BAS_HIDE(BrowserAutomationStudio_GetBoundingClientRect)(self);return (rect.left + positionx) + '|' + (rect.top + positiony) + '|' + (rect.right - rect.left) + '|' + (rect.bottom - rect.top)})();")!
					   var split = _result().split("|");
					   var x = parseInt(split[0]), y = parseInt(split[1]), w = parseInt(split[2]), h = parseInt(split[3]);
					   /// Первый квадрат
					   VAR_DIRECT_BUTTON_X = parseInt(x)
					   VAR_DIRECT_BUTTON_Y = parseInt(y) + VAR_SCROLL_Y;
					   VAR_DIRECT_WIDTH = parseInt(w)
					   VAR_DIRECT_HEIGHT = parseInt(h)
					   ////Высчитаем центр стрелочки
					   VAR_DIRECT_BUTTON_X = VAR_DIRECT_BUTTON_X + VAR_DIRECT_WIDTH/2;
					   VAR_DIRECT_BUTTON_Y = VAR_DIRECT_BUTTON_Y + VAR_DIRECT_HEIGHT/2;
					   

					   
					   
					   _do(function(){
					   _set_action_info({ name: "For" });
					   VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
					   if(VAR_CYCLE_INDEX > parseInt(10))_break();
					   
						  
						  
						  _set_if_expression("W1tTQVZFRF9DT05URU5UXV0gPT0gNg==");
						  _if(VAR_SAVED_CONTENT == 6,function(){
						  
							 
							 
							 VAR_SAVED_CONTENT = "1"
							 

							 
							 
							 _break("function")
							 

						  })!
						  

						  
						  
						  _set_if_expression("W1tTQVZFRF9DT05URU5UXV0gPT0gNQ==");
						  _if(VAR_SAVED_CONTENT == 5,function(){
						  
							 
							 
							 VAR_SAVED_CONTENT = "2"
							 

							 
							 
							 _break("function")
							 

						  })!
						  

						  
						  
						  _set_if_expression("W1tTQVZFRF9DT05URU5UXV0gPT0gNA==");
						  _if(VAR_SAVED_CONTENT == 4,function(){
						  
							 
							 
							 VAR_SAVED_CONTENT = "3"
							 

							 
							 
							 _break("function")
							 

						  })!
						  

						  
						  
						  _set_if_expression("W1tTQVZFRF9DT05URU5UXV0gPT0gMw==");
						  _if(VAR_SAVED_CONTENT == 3,function(){
						  
							 
							 
							 VAR_SAVED_CONTENT = "4"
							 

							 
							 
							 _break("function")
							 

						  })!
						  

						  
						  
						  _set_if_expression("W1tTQVZFRF9DT05URU5UXV0gPT0gMg==");
						  _if(VAR_SAVED_CONTENT == 2,function(){
						  
							 
							 
							 VAR_SAVED_CONTENT = "5"
							 

							 
							 
							 _break("function")
							 

						  })!
						  

						  
						  
						  sleep(300)!
						  

					   })!
					   

					   
					   
					   _do(function(){
					   _set_action_info({ name: "For" });
					   VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
					   if(VAR_CYCLE_INDEX > parseInt(VAR_SAVED_CONTENT))_break();
					   
						  
						  
						  VAR_DIRECT_BUTTON_X_CLICK = 0;
						  VAR_DIRECT_BUTTON_Y_CLICK = 0;
						  VAR_DIRECT_BUTTON_X_CLICK = VAR_DIRECT_BUTTON_X + rand(-3,+3);
						  VAR_DIRECT_BUTTON_Y_CLICK = VAR_DIRECT_BUTTON_Y + rand(-3,+3);
						  

						  
						  
						  /*Browser*/
						  move(VAR_DIRECT_BUTTON_X_CLICK,VAR_DIRECT_BUTTON_Y_CLICK,  {} )!
						  mouse(VAR_DIRECT_BUTTON_X_CLICK,VAR_DIRECT_BUTTON_Y_CLICK)!
						  

						  
						  
						  _cycle_params().if_else = rand (1,10) > 5;
						  _set_if_expression("cmFuZCAoMSwxMCkgPiA1");
						  _if(_cycle_params().if_else,function(){
						  
							 
							 
							 sleep(rand(100,200))!
							 

						  })!
						  

						  
						  
						  _if(!_cycle_params().if_else,function(){
						  
							 
							 
							 sleep(rand(400,800))!
							 

						  })!
						  delete _cycle_params().if_else;
						  

						  
						  
						  _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gMjA=");
						  _if(VAR_CYCLE_INDEX > 20,function(){
						  
							 
							 
							 _break("function")
							 

						  })!
						  

					   })!
					   

					   
					   
					   VAR_GET_ALL_COORDINATES = "0"
					   

					})!
					

				 })!
				 

			  })!
			  

			  
			  
			  VAR_ERROR_TASK = 0
			  

			  
			  
			  VAR_CURRENT_TASK_NUMBERS = parseInt(VAR_CURRENT_TASK_NUMBERS) + parseInt(-1)
			  

			  
			  
			  sleep(200)!
			  

			  
			  
			  _set_if_expression("W1tGVU5DQVBUQ0hBX1RZUEVdXSA9PSAiR2FtZV9JdGVtIiAmJiBbW0NVUlJFTlRfVEFTS19OVU1CRVJTXV0gIT0w");
			  _if(VAR_FUNCAPTCHA_TYPE == "Game_Item" && VAR_CURRENT_TASK_NUMBERS !=0,function(){
			  
				 
				 
				 /*Browser*/
				 _SELECTOR = VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e #game_challengeItem_image";waiter_timeout_next(20000)
				 wait_element(_SELECTOR)!
				 

			  })!
			  

			  
			  
			  _set_if_expression("W1tGVU5DQVBUQ0hBX1RZUEVdXSA9PSAiR2FtZV9UaWxlIiAmJiBbW0NVUlJFTlRfVEFTS19OVU1CRVJTXV0gIT0w");
			  _if(VAR_FUNCAPTCHA_TYPE == "Game_Tile" && VAR_CURRENT_TASK_NUMBERS !=0,function(){
			  
				 
				 
				 /*Browser*/
				 _SELECTOR = VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e div[class*=\u0027tile-game box screen\u0027]";waiter_timeout_next(20000)
				 wait_element(_SELECTOR)!
				 

			  })!
			  

			  
			  
			  _set_if_expression("W1tGVU5DQVBUQ0hBX1RZUEVdXSA9PSAiR2FtZV9MaXRlIiAmJiBbW0NVUlJFTlRfVEFTS19OVU1CRVJTXV0gIT0w");
			  _if(VAR_FUNCAPTCHA_TYPE == "Game_Lite" && VAR_CURRENT_TASK_NUMBERS !=0,function(){
			  
				 
				 
				 /*Browser*/
				 _SELECTOR = VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e img[id*=\u0027challenge-image\u0027]";waiter_timeout_next(20000)
				 wait_element(_SELECTOR)!
				 

			  })!
			  

			  
			  
			  _set_if_expression("W1tGVU5DQVBUQ0hBX1RZUEVdXSA9PSAiR2FtZV9Cb3gi");
			  _if(VAR_FUNCAPTCHA_TYPE == "Game_Box",function(){
			  
				 
				 
				 _do(function(){
				 _set_action_info({ name: "For" });
				 VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
				 if(VAR_CYCLE_INDEX > parseInt(60))_break();
				 
					
					
					/*Browser*/
					;_SELECTOR=VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e div[class*=\u0027match-game box screen\u0027] \u003eCSS\u003e button";
					get_element_selector(_SELECTOR, false).nowait().exist()!
					VAR_IS_EXISTS = _result() == 1
					_if(VAR_IS_EXISTS, function(){
					get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
					VAR_IS_EXISTS = _result().indexOf("true")>=0
					})!
					

					
					
					_set_if_expression("W1tJU19FWElTVFNdXQ==");
					_if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
					
					   
					   
					   /*Browser*/
					   _SELECTOR = VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e div[class*=\u0027match-game box screen\u0027] \u003eCSS\u003e button";
					   wait_element_visible(_SELECTOR)!
					   _call(_random_point, {})!
					   _if(_result().length > 0, function(){
					   move( {} )!
					   get_element_selector(_SELECTOR, false).clarify(X,Y)!
					   _call(_clarify, {} )!
					   mouse(X,Y)!
					   })!
					   

					   
					   
					   _break("function")
					   

					})!
					

					
					
					sleep(100)!
					

				 })!
				 

				 
				 
				 _set_if_expression("W1tDVVJSRU5UX1RBU0tfTlVNQkVSU11dICE9IDA=");
				 _if(VAR_CURRENT_TASK_NUMBERS != 0,function(){
				 
					
					
					/*Browser*/
					_SELECTOR = VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e div[class*=\u0027match-game box screen\u0027]";waiter_timeout_next(20000)
					wait_element(_SELECTOR)!
					

				 })!
				 

			  })!
			  

			  
			  
			  _set_if_expression("W1tGVU5DQVBUQ0hBX1RZUEVdXSA9PSAiR2FtZV9DaGlsZHJlbiI=");
			  _if(VAR_FUNCAPTCHA_TYPE == "Game_Children",function(){
			  
				 
				 
				 _do(function(){
				 _set_action_info({ name: "For" });
				 VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
				 if(VAR_CYCLE_INDEX > parseInt(60))_break();
				 
					
					
					/*Browser*/
					;_SELECTOR=VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e div[id*=\u0027game_children_buttonContainer\u0027]";
					get_element_selector(_SELECTOR, false).nowait().exist()!
					VAR_IS_EXISTS = _result() == 1
					_if(VAR_IS_EXISTS, function(){
					get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
					VAR_IS_EXISTS = _result().indexOf("true")>=0
					})!
					

					
					
					_set_if_expression("W1tJU19FWElTVFNdXQ==");
					_if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
					
					   
					   
					   /*Browser*/
					   _SELECTOR = VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e div[id*=\u0027game_children_buttonContainer\u0027]";
					   wait_element_visible(_SELECTOR)!
					   _call(_random_point, {})!
					   _if(_result().length > 0, function(){
					   move( {} )!
					   get_element_selector(_SELECTOR, false).clarify(X,Y)!
					   _call(_clarify, {} )!
					   mouse(X,Y)!
					   })!
					   

					   
					   
					   _break("function")
					   

					})!
					

					
					
					sleep(100)!
					

				 })!
				 

				 
				 
				 _set_if_expression("W1tDVVJSRU5UX1RBU0tfTlVNQkVSU11dICE9IDA=");
				 _if(VAR_CURRENT_TASK_NUMBERS != 0,function(){
				 
					
					
					/*Browser*/
					_SELECTOR = VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e img[id*=\u0027children_challengeImage\u0027]";waiter_timeout_next(20000)
					wait_element(_SELECTOR)!
					

				 })!
				 

			  })!
			  

			  
			  
			  _set_if_expression("W1tDVVJSRU5UX1RBU0tfTlVNQkVSU11dIDwgMQ==");
			  _if(VAR_CURRENT_TASK_NUMBERS < 1,function(){
			  
				 
				 
				 _cycle_params().if_else = VAR_IS_MOBILE === false;
				 _set_if_expression("W1tJU19NT0JJTEVdXSA9PT0gZmFsc2U=");
				 _if(_cycle_params().if_else,function(){
				 
					
					
					sleep(rand(100,900))!
					

					
					
					_get_browser_screen_settings()!
					;(function(){
					var result = JSON.parse(_result())
					VAR_SCROLL_X = result["ScrollX"]
					VAR_SCROLL_Y = result["ScrollY"]
					VAR_CURSOR_X = result["CursorX"]
					VAR_CURSOR_Y = result["CursorY"]
					VAR_BROWSER_WIDTH = result["Width"]
					VAR_BROWSER_HEIGHT = result["Height"]
					})();
					

					
					
					var scroll_x=parseInt(VAR_CURSOR_Y);
					var scroll_y=parseInt(VAR_SCROLL_Y);
					var browser_h=parseInt(VAR_BROWSER_HEIGHT);
					//-------------------- Привели все в числа, считаем позицию ---------------------
					var absolut_y = VAR_CURSOR_Y + VAR_SCROLL_Y;
					var y_without_scroll = absolut_y - VAR_SCROLL_Y;
					var check_y_top = VAR_BROWSER_HEIGHT/12;
					var check_y_down = VAR_BROWSER_HEIGHT/100*92;
					var move_y_top = VAR_BROWSER_HEIGHT/10;
					var move_y_down = VAR_BROWSER_HEIGHT/100*80;
					// -------------------------- Округляем ----------------------------------
					VAR_CHECK_Y_TOP = check_y_top.toFixed();
					VAR_CHECK_Y_DOWN = check_y_down.toFixed();
					VAR_Y_WITHOUNT_SCROLL = y_without_scroll.toFixed();
					VAR_MOVE_Y_TOP = move_y_top.toFixed();
					VAR_MOVE_Y_DOWN = move_y_down.toFixed();
					// ----------------- Снова приводим к числу ------------------------
					VAR_CHECK_Y_TOP=parseInt(VAR_CHECK_Y_TOP);
					VAR_CHECK_Y_DOWN=parseInt(VAR_CHECK_Y_DOWN);
					VAR_Y_WITHOUNT_SCROLL=parseInt(VAR_Y_WITHOUNT_SCROLL);
					VAR_MOVE_Y_TOP=parseInt(VAR_MOVE_Y_TOP);
					VAR_MOVE_Y_DOWN=parseInt(VAR_MOVE_Y_DOWN);
					

					
					
					/*Browser*/
					move(rand(VAR_BROWSER_WIDTH/5,VAR_BROWSER_WIDTH/1.3),rand(VAR_MOVE_Y_TOP + VAR_SCROLL_Y,VAR_MOVE_Y_DOWN + VAR_SCROLL_Y),  {} )!
					

				 })!
				 

				 
				 
				 _if(!_cycle_params().if_else,function(){
				 
					
					
					sleep(rand(100,500))!
					

				 })!
				 delete _cycle_params().if_else;
				 

			  })!

			  
			  
			  _break("function")
			  

		   })!
		   

		   
		   
		   _if(!_cycle_params().if_else,function(){
		   
			  
			  
			  sleep(1000)!
			  

			  
			  
			  VAR_ERROR_CAPTCHA_UNSOLVABLE_MODULE = parseInt(VAR_ERROR_CAPTCHA_UNSOLVABLE_MODULE) + parseInt(1)
			  

			  
			  
			  _break("function")
			  

		   })!
		   delete _cycle_params().if_else;
		   

		})!
		

		
		
		_next("function")
		

	 },null)!
	 

	 
	 
	 _set_if_expression("W1tXQVNfRVJST1JdXQ==");
	 _if(typeof(VAR_WAS_ERROR) !== "undefined" ? (VAR_WAS_ERROR) : undefined,function(){
	 
		
		
		_set_if_expression("W1tMQVNUX0VSUk9SXV0gPT09ICdBYm9ydGVkIEJ5IFVzZXInIHx8IFtbTEFTVF9FUlJPUl1dICA9PT0gJ9Cf0YDQtdGA0LLQsNC90L4g0J/QvtC70YzQt9C+0LLQsNGC0LXQu9C10Lwn");
		_if(VAR_LAST_ERROR === 'Aborted By User' || VAR_LAST_ERROR  === 'Прервано Пользователем',function(){
		
		   
		   
		   _function_return(false)
		   

		})!
		

		
		
		VAR_ERROR_LOAD_NEXT_PICTURE_FUNCAPTCHA = 1
		

		
		
		sleep(1000)!
		

		
		
		_next("function")
		

	 })!
	 

	})!
      

   }
   

function GoodXevilPaySolver_GXP_BasiliskCaptcha()
   {
   
      
      
      _set_if_expression("ZmFsc2U=");
      _if(false,function(){
      
         
         
         /*Browser*/
         cache_allow("*/ptc/create-session")!
         

         
         
         VAR_SITEKEY = _function_argument("sitekey")
         

         
         
         VAR_SITEURL = _function_argument("siteurl")
         

         
         
         var regexp_result = native("regexp", "first", JSON.stringify({text: VAR_APIKEY,regexp:("([0-9A-Za-z\u005c|]\u007b20,50\u007d)").toString()}))
         if(regexp_result.length == 0)
         regexp_result = []
         else
         regexp_result = JSON.parse(regexp_result)
         VAR_ALL_MATCH = regexp_result.pop()
         if(typeof(VAR_ALL_MATCH) == 'undefined' || !VAR_ALL_MATCH)
         VAR_ALL_MATCH = ""
         VAR_LIST_WITH_GROUPS = regexp_result
         VAR_APIKEY = regexp_result[0]
         if(typeof(VAR_APIKEY) == 'undefined' || !VAR_APIKEY)
         VAR_APIKEY = ""
         if(regexp_result.length == 0)
         {
         VAR_APIKEY = VAR_ALL_MATCH
         }
         if(VAR_ALL_MATCH != "" && Array.isArray(VAR_ALL_MATCH))
         VAR_LIST_WITH_GROUPS.unshift(VAR_ALL_MATCH)
         

         
         
         solver_properties_clear("capmonster")
         solver_property("capmonster","serverurl","http://sctg.xyz/")
         solver_property("capmonster","key",VAR_APIKEY)
         solver_property("capmonster","method","basilisk")
         solver_property("capmonster","siteurl",VAR_SITEURL)
         solver_property("capmonster","sitekey",VAR_SITEKEY)
         solve_base64_no_fail("capmonster", "")!
         VAR_SAVED_CONTENT = _result();
         

         
         
         VAR_STRING_MATCHES = Boolean(native("regexp", "ismatch", JSON.stringify({text: VAR_SAVED_CONTENT,regexp:("(ERROR)").toString()})) == "true")
         

         
         
         VAR_STRING_MATCHES2 = Boolean(native("regexp", "ismatch", JSON.stringify({text: VAR_SAVED_CONTENT,regexp:("(_FAIL)").toString()})) == "true")
         

         
         
         _set_if_expression("W1tTVFJJTkdfTUFUQ0hFU11dIHx8IFtbU1RSSU5HX01BVENIRVMyXV0=");
         _if(VAR_STRING_MATCHES || VAR_STRING_MATCHES2,function(){
         
            
            
            fail((_K==="en" ? "Captcha is not solvable" : "Captcha не решена"));
            

         })!
         

         
         
         page().script2("BasiliskCaptcha.prototype.getResult=function()\u007breturn [[SAVED_CONTENT]]\u007d",JSON.stringify(_read_variables(["VAR_SAVED_CONTENT"])))!
         var _parse_result = JSON.parse(_result())
         _write_variables(JSON.parse(_parse_result.variables))
         if(!_parse_result.is_success)
         fail(_parse_result.error)
         

      })!
      

      
      
      /*Browser*/
      cache_data_clear()!
      

      
      
      VAR_BUTTON_ID = " \u003eXPATH\u003e //input[@name=\u0022captcha-response\u0022 and @value]/.."
      

      
      
      VAR_IMAGE_ID = " \u003eXPATH\u003e /html/body/div/div/div/div/canvas[@style=\u0022width: 100%;\u0022]"
      

      
      
      VAR_RELOAD_ID = " \u003eXPATH\u003e /html/body/div/div/div/div[@style=\u0022display: flex;\u0022]/div[contains(@style, \u0022-27\u0022)]"
      

      
      
      VAR_ARROW_ID = " \u003eXPATH\u003e /html/body/div/div/div/div//div[contains(@style, \u0022width: 17px; height: 15px;\u0022)]/../../div"
      

      
      
      VAR_TYPE_SLIDE = 1
      

      
      
      VAR_COEF = 1
      

      
      
      VAR_SLIDER_TYPE = "1"
      

      
      
      VAR_ATTEMPTS = 5
      

      
      
      VAR_KEY = _function_argument("apikey")
      

      
      
      VAR_PIXEL_KOEF = -27
      

      
      
      VAR_AVTOUPDATE = false
      

      
      
      VAR_SPEED = 1
      

      
      
      VAR_ATTEMPTS = VAR_ATTEMPTS - 1
      

      
      
      VAR_CAPTCHA_ID = 0
      

      
      
      var regexp_result = native("regexp", "first", JSON.stringify({text: VAR_KEY,regexp:("([0-9A-Za-z\u005c|]\u007b20,50\u007d)").toString()}))
      if(regexp_result.length == 0)
      regexp_result = []
      else
      regexp_result = JSON.parse(regexp_result)
      VAR_ALL_MATCH = regexp_result.pop()
      if(typeof(VAR_ALL_MATCH) == 'undefined' || !VAR_ALL_MATCH)
      VAR_ALL_MATCH = ""
      VAR_LIST_WITH_GROUPS = regexp_result
      VAR_KEY = regexp_result[0]
      if(typeof(VAR_KEY) == 'undefined' || !VAR_KEY)
      VAR_KEY = ""
      if(regexp_result.length == 0)
      {
      VAR_KEY = VAR_ALL_MATCH
      }
      if(VAR_ALL_MATCH != "" && Array.isArray(VAR_ALL_MATCH))
      VAR_LIST_WITH_GROUPS.unshift(VAR_ALL_MATCH)
      

      
      
      VAR_TYPE_SWIPE = 1
      

      
      
      _call(function()
      {
      _on_fail(function(){
      VAR_LAST_ERROR = _result()
      VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
      VAR_WAS_ERROR = false
      _break(1,true)
      })
      CYCLES.Current().RemoveLabel("function")
      
         
         
         /*Browser*/
         waiter_timeout_next(5000)
         wait_async_load()!
         

      },null)!
      

      
      
      /*Browser*/
      ;_SELECTOR=VAR_IMAGE_ID + "\u003eAT\u003e" + VAR_CAPTCHA_ID;
      get_element_selector(_SELECTOR, false).nowait().exist()!
      VAR_IS_EXISTS = _result() == 1
      _if(VAR_IS_EXISTS, function(){
      get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
      VAR_IS_EXISTS = _result().indexOf("true")>=0
      })!
      

      
      
      _do(function(){
      _set_action_info({ name: "While" });
      VAR_CYCLE_INDEX = _iterator() - 1
      BREAK_CONDITION = VAR_IS_EXISTS == false;
      if(!BREAK_CONDITION)_break();
      
         
         
         _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gNQ==");
         _if(VAR_CYCLE_INDEX > 5,function(){
         
            
            
            fail((_K==="en" ? "Captcha not found, reload the page" : "Капча не найдена, перезагрузите страницу"));
            

         })!
         

         
         
         _set_if_expression("W1tCVVRUT05fSURdXSAhPSAiTk9ORSI=");
         _if(VAR_BUTTON_ID != "NONE",function(){
         
            
            
            /*Browser*/
            ;_SELECTOR=VAR_BUTTON_ID;
            get_element_selector(_SELECTOR, false).nowait().exist()!
            VAR_IS_EXISTS = _result() == 1
            _if(VAR_IS_EXISTS, function(){
            get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
            VAR_IS_EXISTS = _result().indexOf("true")>=0
            })!
            

            
            
            _cycle_params().if_else = VAR_IS_EXISTS == false;
            _set_if_expression("W1tJU19FWElTVFNdXSA9PSBmYWxzZQ==");
            _if(_cycle_params().if_else,function(){
            
               
               
               fail((_K==="en" ? "Captcha not found, reload the page" : "Капча не найдена, перезагрузите страницу"));
               

            })!
            

            
            
            _if(!_cycle_params().if_else,function(){
            
               
               
               /*Browser*/
               _SELECTOR = VAR_BUTTON_ID;
               wait_element_visible(_SELECTOR)!
               _call(_random_point, {})!
               _if(_result().length > 0, function(){
               move( {} )!
               get_element_selector(_SELECTOR, false).clarify(X,Y)!
               _call(_clarify, {} )!
               mouse(X,Y)!
               })!
               

               
               
               _call(function()
               {
               _on_fail(function(){
               VAR_LAST_ERROR = _result()
               VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
               VAR_WAS_ERROR = false
               _break(1,true)
               })
               CYCLES.Current().RemoveLabel("function")
               
                  
                  
                  /*Browser*/
                  IDDLE_EMULATION_END = Date.now() + 1000 * (2)
                  IDDLE_EMULATION_DISTRIBUTION = [2,3,3,3,4,4]
                  _get_browser_screen_settings()!
                  IDDLE_EMULATION_RESULT = JSON.parse(_result())
                  IDDLE_CURSOR_POSITION_X = IDDLE_EMULATION_RESULT["CursorX"]
                  IDDLE_CURSOR_POSITION_Y = IDDLE_EMULATION_RESULT["CursorY"]
                  IDDLE_CURSOR_POSITION_WIDTH = IDDLE_EMULATION_RESULT["Width"]
                  IDDLE_CURSOR_POSITION_HEIGHT = IDDLE_EMULATION_RESULT["Height"]
                  IDDLE_CURSOR_POSITION_WAS_SCROLL = false
                  _do(function(){
                  if(Date.now() >= IDDLE_EMULATION_END)
                  _break()
                  IDDLE_EMULATION_CURRENT_ITEM = IDDLE_EMULATION_DISTRIBUTION[Math.floor(Math.random()*IDDLE_EMULATION_DISTRIBUTION.length)]
                  if(_iterator() == 1 && IDDLE_EMULATION_DISTRIBUTION.indexOf(2)>=0)
                  IDDLE_EMULATION_CURRENT_ITEM = 2
                  _if(IDDLE_EMULATION_CURRENT_ITEM == 1, function(){
                  //scroll
                  IDDLE_EMULATION_CURRENT_DIRECTION = (rand(1,2) == 2) ? "<MOUSESCROLLUP>" : "<MOUSESCROLLDOWN>"
                  if(!IDDLE_CURSOR_POSITION_WAS_SCROLL)
                  IDDLE_EMULATION_CURRENT_DIRECTION = "<MOUSESCROLLDOWN>"
                  IDDLE_CURSOR_POSITION_WAS_SCROLL = true
                  IDDLE_EMULATION_CURRENT_NUMBER = rand(1,5)
                  _do(function(){
                  if(_iterator() >= IDDLE_EMULATION_CURRENT_NUMBER)
                  _break()
                  _type(IDDLE_EMULATION_CURRENT_DIRECTION,1000)!
                  sleep(rand(300,1000))!
                  })!
                  })!
                  _if(IDDLE_EMULATION_CURRENT_ITEM == 2, function(){
                  //long move
                  page().script("document.documentElement.scrollLeft")!
                  IDDLE_CURSOR_POSITION_SCROLL_X = parseInt(_result())
                  page().script("document.documentElement.scrollTop")!
                  IDDLE_CURSOR_POSITION_SCROLL_Y = parseInt(_result())
                  IDDLE_CURSOR_POSITION_X = rand(1,IDDLE_CURSOR_POSITION_WIDTH)
                  IDDLE_CURSOR_POSITION_Y = rand(1,IDDLE_CURSOR_POSITION_HEIGHT)
                  move(IDDLE_CURSOR_POSITION_SCROLL_X + IDDLE_CURSOR_POSITION_X,IDDLE_CURSOR_POSITION_SCROLL_Y + IDDLE_CURSOR_POSITION_Y)!
                  })!
                  _if(IDDLE_EMULATION_CURRENT_ITEM == 3, function(){
                  //short move
                  if(IDDLE_CURSOR_POSITION_X < 0 || IDDLE_CURSOR_POSITION_Y < 0)
                  _break()
                  page().script("document.documentElement.scrollLeft")!
                  IDDLE_CURSOR_POSITION_SCROLL_X = parseInt(_result())
                  page().script("document.documentElement.scrollTop")!
                  IDDLE_CURSOR_POSITION_SCROLL_Y = parseInt(_result())
                  IDDLE_EMULATION_CURRENT_NUMBER = rand(1,4)
                  _do(function(){
                  if(_iterator() >= IDDLE_EMULATION_CURRENT_NUMBER)
                  _break()
                  IDDLE_CURSOR_POSITION_X += rand(-50,50)
                  IDDLE_CURSOR_POSITION_Y += rand(-50,50)
                  if(IDDLE_CURSOR_POSITION_X > IDDLE_CURSOR_POSITION_WIDTH)
                  IDDLE_CURSOR_POSITION_X = IDDLE_CURSOR_POSITION_WIDTH
                  if(IDDLE_CURSOR_POSITION_Y > IDDLE_CURSOR_POSITION_HEIGHT)
                  IDDLE_CURSOR_POSITION_Y = IDDLE_CURSOR_POSITION_HEIGHT
                  if(IDDLE_CURSOR_POSITION_X < 0)
                  IDDLE_CURSOR_POSITION_X = 0
                  if(IDDLE_CURSOR_POSITION_Y < 0)
                  IDDLE_CURSOR_POSITION_Y = 0
                  move(IDDLE_CURSOR_POSITION_SCROLL_X + IDDLE_CURSOR_POSITION_X,IDDLE_CURSOR_POSITION_SCROLL_Y + IDDLE_CURSOR_POSITION_Y)!
                  _if(rand(1,10) > 3,function(){
                  sleep(rand(10,300))!
                  })!
                  })!
                  })!
                  _if(IDDLE_EMULATION_CURRENT_ITEM == 4, function(){
                  //sleep
                  sleep(rand(500,5000))!
                  })!
                  })!
                  

               },null)!
               

            })!
            delete _cycle_params().if_else;
            

         })!
         

         
         
         /*Browser*/
         ;_SELECTOR=VAR_IMAGE_ID;
         get_element_selector(_SELECTOR, true).length()!
         VAR_ELEMENT_LENGTH = _result()
         

         
         
         _cycle_params().if_else = VAR_ELEMENT_LENGTH > 1;
         _set_if_expression("W1tFTEVNRU5UX0xFTkdUSF1dID4gMQ==");
         _if(_cycle_params().if_else,function(){
         
            
            
            _do(function(){
            _set_action_info({ name: "For" });
            VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(0)
            if(VAR_CYCLE_INDEX > parseInt(VAR_ELEMENT_LENGTH - 1))_break();
            
               
               
               /*Browser*/
               ;_SELECTOR=VAR_IMAGE_ID + "\u003eAT\u003e" + VAR_CYCLE_INDEX;
               get_element_selector(_SELECTOR, false).nowait().exist()!
               VAR_IS_EXISTS = _result() == 1
               _if(VAR_IS_EXISTS, function(){
               get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
               VAR_IS_EXISTS = _result().indexOf("true")>=0
               })!
               

               
               
               _set_if_expression("W1tJU19FWElTVFNdXQ==");
               _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
               
                  
                  
                  VAR_CAPTCHA_ID = VAR_CYCLE_INDEX
                  

                  
                  
                  _break("function")
                  

               })!
               

            })!
            

         })!
         

         
         
         _if(!_cycle_params().if_else,function(){
         
            
            
            /*Browser*/
            ;_SELECTOR=VAR_IMAGE_ID + "\u003eAT\u003e" + VAR_CAPTCHA_ID;
            get_element_selector(_SELECTOR, false).nowait().exist()!
            VAR_IS_EXISTS = _result() == 1
            _if(VAR_IS_EXISTS, function(){
            get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
            VAR_IS_EXISTS = _result().indexOf("true")>=0
            })!
            

         })!
         delete _cycle_params().if_else;
         

      })!
      

      
      
      /*Browser*/
      ;_SELECTOR=VAR_IMAGE_ID + "\u003eAT\u003e" + VAR_CAPTCHA_ID;
      get_element_selector(_SELECTOR, false).nowait().exist()!
      VAR_IS_EXISTS = _result() == 1
      _if(VAR_IS_EXISTS, function(){
      get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
      VAR_IS_EXISTS = _result().indexOf("true")>=0
      })!
      

      
      
      /*Browser*/
      cache_allow("*/challenge/icons-challenge")!
      

      
      
      _do(function(){
      _set_action_info({ name: "While" });
      VAR_CYCLE_INDEX = _iterator() - 1
      BREAK_CONDITION = VAR_IS_EXISTS;
      if(!BREAK_CONDITION)_break();
      
         
         
         /*Browser*/
         _cache_get_all("*/challenge/icons-challenge")!
         VAR_CACHE_LIST = JSON.parse(_result())
         

         
         
         VAR_LIST_LENGTH = (VAR_CACHE_LIST).length
         

         
         
         _set_if_expression("W1tMSVNUX0xFTkdUSF1dICE9IDA=");
         _if(VAR_LIST_LENGTH != 0,function(){
         
            
            
            /*Browser*/
            wait_load("*/challenge/icons-challenge")!
            cache_get_string("*/challenge/icons-challenge")!
            VAR_SAVED_CACHE = _result()
            

            
            
            _set_if_expression("W1tTQVZFRF9DQUNIRV1dICE9ICIi");
            _if(VAR_SAVED_CACHE != "",function(){
            
               
               
               _break("function")
               

            })!
            

         })!
         

         
         
         /*Browser*/
         cache_data_clear()!
         

         
         
         _set_if_expression("W1tDWUNMRV9JTkRFWF1dID49IFtbQVRURU1QVFNdXQ==");
         _if(VAR_CYCLE_INDEX >= VAR_ATTEMPTS,function(){
         
            
            
            fail((_K==="en" ? "The captcha has not been solved in 10 tries" : "Капча не решена за 10 попыток"));
            

         })!
         

         
         
         /*Browser*/
         _SELECTOR = VAR_IMAGE_ID + "\u003eAT\u003e" + VAR_CAPTCHA_ID;
         wait_element(_SELECTOR)!
         get_element_selector(_SELECTOR, false).exist()!
         _if(_result() == "1", function(){
         get_element_selector(_SELECTOR, false).render_base64()!
         VAR_SCREENSHOT_BASE64 = _result()
         })!
         

         
         
         VAR_STRING_LENGTH = VAR_SCREENSHOT_BASE64.length
         

         
         
         _set_if_expression("W1tTVFJJTkdfTEVOR1RIXV0gPCAxMDAwICYmIFtbQ1lDTEVfSU5ERVhdXSA9PSAw");
         _if(VAR_STRING_LENGTH < 1000 && VAR_CYCLE_INDEX == 0,function(){
         
            
            
            fail((_K==="en" ? "The image is too small, you obviously set the wrong image ID" : "Слишком маленькая картинка, вы явно задали не тот идентификатор изображения"));
            

         })!
         

         
         
         _set_if_expression("W1tTVFJJTkdfTEVOR1RIXV0gPCAxMDAwICYmIFtbQ1lDTEVfSU5ERVhdXSAhPSAw");
         _if(VAR_STRING_LENGTH < 1000 && VAR_CYCLE_INDEX != 0,function(){
         
            
            
            _function_return("good")
            

         })!
         

         
         
         _do(function(){
         _set_action_info({ name: "For" });
         VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
         if(VAR_CYCLE_INDEX > parseInt(3))_break();
         
            
            
            _set_if_expression("W1tDWUNMRV9JTkRFWF1dID49IDM=");
            _if(VAR_CYCLE_INDEX >= 3,function(){
            
               
               
               fail_user(VAR_LAST_ERROR,false)
               

            })!
            

            
            
            _call(function()
            {
            _on_fail(function(){
            VAR_LAST_ERROR = _result()
            VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
            VAR_WAS_ERROR = false
            _break(1,true)
            })
            CYCLES.Current().RemoveLabel("function")
            
               
               
               _cycle_params().if_else = VAR_SLIDER_TYPE == 2;
               _set_if_expression("W1tTTElERVJfVFlQRV1dID09IDI=");
               _if(_cycle_params().if_else,function(){
               
                  
                  
                  _switch_http_client_main()
                  http_client_post("http://sctg.xyz/in.php", ["method","slidermany","key",VAR_KEY,"body",VAR_SCREENSHOT_BASE64], {"content-type":("multipart"), "encoding":("UTF-8"), "method":("POST"),headers:("")})!
                  

               })!
               

               
               
               _if(!_cycle_params().if_else,function(){
               
                  
                  
                  _switch_http_client_main()
                  http_client_post("http://sctg.xyz/in.php", ["method","geetest","key",VAR_KEY,"body",VAR_SCREENSHOT_BASE64], {"content-type":("multipart"), "encoding":("UTF-8"), "method":("POST"),headers:("")})!
                  

               })!
               delete _cycle_params().if_else;
               

               
               
               _switch_http_client_main()
               VAR_SAVED_CONTENT = http_client_encoded_content("utf-8")
               

               
               
               _break("function")
               

            },null)!
            

         })!
         

         
         
         VAR_STRING_CONTAINS = Boolean(native("regexp", "ismatch", JSON.stringify({text: VAR_SAVED_CONTENT,regexp:("(\u005c|)").toString()})) == "true")
         

         
         
         _set_if_expression("W1tTVFJJTkdfQ09OVEFJTlNdXSA9PSBmYWxzZQ==");
         _if(VAR_STRING_CONTAINS == false,function(){
         
            
            
            fail_user(VAR_SAVED_CONTENT,false)
            

         })!
         

         
         
         sleep(1000)!
         

         
         
         VAR_ID = VAR_SAVED_CONTENT.split("|")[1]
         

         
         
         _do(function(){
         _set_action_info({ name: "For" });
         VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
         if(VAR_CYCLE_INDEX > parseInt(3))_break();
         
            
            
            _set_if_expression("W1tDWUNMRV9JTkRFWF1dID49IDM=");
            _if(VAR_CYCLE_INDEX >= 3,function(){
            
               
               
               fail_user(VAR_LAST_ERROR,false)
               

            })!
            

            
            
            _call(function()
            {
            _on_fail(function(){
            VAR_LAST_ERROR = _result()
            VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
            VAR_WAS_ERROR = false
            _break(1,true)
            })
            CYCLES.Current().RemoveLabel("function")
            
               
               
               _switch_http_client_main()
               http_client_get2("http://sctg.xyz/res.php?key=" + VAR_KEY + "\u0026id=" + VAR_ID,{method:("GET"),headers:("")})!
               

               
               
               _switch_http_client_main()
               VAR_SAVED_CONTENT = http_client_encoded_content("utf-8")
               

               
               
               _do(function(){
               _set_action_info({ name: "While" });
               VAR_CYCLE_INDEX = _iterator() - 1
               BREAK_CONDITION = VAR_SAVED_CONTENT == "CAPCHA_NOT_READY";
               if(!BREAK_CONDITION)_break();
               
                  
                  
                  sleep(1000)!
                  

                  
                  
                  _switch_http_client_main()
                  http_client_get2("http://sctg.xyz/res.php?key=" + VAR_KEY + "\u0026id=" + VAR_ID,{method:("GET"),headers:("")})!
                  

                  
                  
                  _switch_http_client_main()
                  VAR_SAVED_CONTENT = http_client_encoded_content("utf-8")
                  

               })!
               

               
               
               _break("function")
               

            },null)!
            

         })!
         

         
         
         VAR_STRING_CONTAINS = Boolean(native("regexp", "ismatch", JSON.stringify({text: VAR_SAVED_CONTENT,regexp:("(\u005c|)").toString()})) == "true")
         

         
         
         _set_if_expression("W1tTVFJJTkdfQ09OVEFJTlNdXSA9PSBmYWxzZQ==");
         _if(VAR_STRING_CONTAINS == false,function(){
         
            
            
            /*Browser*/
            _SELECTOR = VAR_RELOAD_ID + "\u003eAT\u003e" + VAR_CAPTCHA_ID;waiter_timeout_next(1000)
            waiter_nofail_next();
            wait_element_visible(_SELECTOR)!
            _call(_random_point, {})!
            _if(_result().length > 0, function(){
            move( {} )!
            get_element_selector(_SELECTOR, false).nowait().clarify(X,Y)!
            _call(_clarify, {} )!
            mouse(X,Y)!
            })!
            

            
            
            _call(function()
            {
            _on_fail(function(){
            VAR_LAST_ERROR = _result()
            VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
            VAR_WAS_ERROR = false
            _break(1,true)
            })
            CYCLES.Current().RemoveLabel("function")
            
               
               
               /*Browser*/
               waiter_timeout_next(15000)
               wait_async_load()!
               

            },null)!
            

            
            
            _next("function")
            

         })!
         

         
         
         VAR_SCAN_RESULT_LIST = native("regexp", "scan", JSON.stringify({text: VAR_SAVED_CONTENT,regexp:("\u005cd+").toString()}))
         if(VAR_SCAN_RESULT_LIST.length == 0)
         VAR_SCAN_RESULT_LIST = []
         else
         VAR_SCAN_RESULT_LIST = JSON.parse(VAR_SCAN_RESULT_LIST)
         

         
         
         VAR_LIST_LENGTH = (VAR_SCAN_RESULT_LIST).length
         

         
         
         _set_if_expression("W1tMSVNUX0xFTkdUSF1dICE9IDM=");
         _if(VAR_LIST_LENGTH != 3,function(){
         
            
            
            fail((_K==="en" ? "Unclear response from the server" : "Не понятный ответ от сервера"));
            

         })!
         

         
         
         VAR_X_XEVIL = (parseInt(VAR_SCAN_RESULT_LIST[0]) * VAR_COEF) + VAR_PIXEL_KOEF;
         VAR_Y_XEVIL = parseInt(VAR_SCAN_RESULT_LIST[1]);
         VAR_W_XEVIL = parseInt(VAR_SCAN_RESULT_LIST[2]);
         

         
         
         /*Browser*/
         scroll(1,1)!
         

         
         
         /*Browser*/
         _SELECTOR = VAR_ARROW_ID + "\u003eAT\u003e" + VAR_CAPTCHA_ID;
         wait_element(_SELECTOR)!
         get_element_selector(_SELECTOR, false).script("(function(){var rect = _BAS_HIDE(BrowserAutomationStudio_GetBoundingClientRect)(self);return (rect.left + positionx) + '|' + (rect.top + positiony) + '|' + (rect.right - rect.left) + '|' + (rect.bottom - rect.top) + '|' + (rect.left + positionx + scrollx) + '|' + (rect.top + positiony + scrolly)})();")!
         if(_result().length > 0)
         {
         var split = _result().split("|")
         VAR_X = parseInt(split[0])
         VAR_Y = parseInt(split[1])
         VAR_WIDTH = parseInt(split[2])
         VAR_HEIGHT = parseInt(split[3])
         VAR_ABSOLUTE_X = parseInt(split[4])
         VAR_ABSOLUTE_Y = parseInt(split[5])
         }
         

         
         
         _cycle_params().if_else = VAR_TYPE_SLIDE == true;
         _set_if_expression("W1tUWVBFX1NMSURFXV0gPT0gdHJ1ZQ==");
         _if(_cycle_params().if_else,function(){
         
            
            
            /*Browser*/
            move(VAR_X + (VAR_WIDTH/2),VAR_Y + (VAR_HEIGHT/2),  {"speed": 100*VAR_SPEED,"gravity": 6,"deviation": 2.5} )!
            mouse_down(VAR_X + (VAR_WIDTH/2),VAR_Y + (VAR_HEIGHT/2))!
            

         })!
         

         
         
         _if(!_cycle_params().if_else,function(){
         
            
            
            /*Browser*/
            _SELECTOR = VAR_ARROW_ID + "\u003eAT\u003e" + VAR_CAPTCHA_ID;
            wait_element_visible(_SELECTOR)!
            _call(_random_point, {})!
            _if(_result().length > 0, function(){
            move( {} )!
            get_element_selector(_SELECTOR, false).clarify(X,Y)!
            _call(_clarify, {} )!
            mouse_down(X,Y)!
            })!
            

         })!
         delete _cycle_params().if_else;
         

         
         
         _set_if_expression("W1tUWVBFX1NXSVBFXV0gPT0gMQ==");
         _if(VAR_TYPE_SWIPE == 1,function(){
         
            
            
            VAR_RANDOM_SPEED = Math.floor(Math.random() * (parseInt(200) - parseInt(100) + 1)) + parseInt(100)
            

            
            
            VAR_RANDOM_PR = Math.floor(Math.random() * (parseInt(9) - parseInt(5) + 1)) + parseInt(5)
            

            
            
            /*Browser*/
            move(VAR_X + (VAR_X_XEVIL/1.2),VAR_Y,  {"speed": VAR_RANDOM_SPEED*VAR_SPEED,"gravity": VAR_RANDOM_PR,"deviation": 4} )!
            

            
            
            VAR_RANDOM_SPEED = Math.floor(Math.random() * (parseInt(60) - parseInt(10) + 1)) + parseInt(10)
            

            
            
            VAR_RANDOM_PR = Math.floor(Math.random() * (parseInt(10) - parseInt(7) + 1)) + parseInt(7)
            

            
            
            /*Browser*/
            move(VAR_X+VAR_X_XEVIL + VAR_W_XEVIL/2,VAR_Y,  {"speed": VAR_RANDOM_SPEED*VAR_SPEED,"gravity": VAR_RANDOM_PR,"deviation": 0} )!
            

            
            
            VAR_RANDOM_Y = Math.floor(Math.random() * (parseInt(15) - parseInt(-15) + 1)) + parseInt(-15)
            

            
            
            /*Browser*/
            var move_settings =  {"speed": 50*VAR_SPEED,"gravity": 9,"deviation": 0} ;
            move_settings["do_mouse_up"] = "true"
            move(VAR_X+VAR_X_XEVIL + VAR_W_XEVIL/2,VAR_Y + VAR_RANDOM_Y, move_settings)!
            

         })!
         

         
         
         _set_if_expression("W1tUWVBFX1NXSVBFXV0gPT0gMg==");
         _if(VAR_TYPE_SWIPE == 2,function(){
         
            
            
            VAR_RANDOM_SPEED = Math.floor(Math.random() * (parseInt(40) - parseInt(20) + 1)) + parseInt(20)
            

            
            
            VAR_RANDOM_PR = Math.floor(Math.random() * (parseInt(4) - parseInt(3) + 1)) + parseInt(3)
            

            
            
            VAR_RANDOM_RT = Math.floor(Math.random() * (parseInt(2) - parseInt(1) + 1)) + parseInt(1)
            

            
            
            VAR_RANDOM_Y = Math.floor(Math.random() * (parseInt(5) - parseInt(-5) + 1)) + parseInt(-5)
            

            
            
            /*Browser*/
            var move_settings =  {"speed": VAR_RANDOM_SPEED*VAR_SPEED,"gravity": VAR_RANDOM_PR,"deviation": VAR_RANDOM_RT} ;
            move_settings["do_mouse_up"] = "true"
            move(VAR_WIDTH/2 + VAR_X+VAR_X_XEVIL + VAR_W_XEVIL/2,VAR_Y + VAR_RANDOM_Y, move_settings)!
            

         })!
         

         
         
         _set_if_expression("W1tUWVBFX1NXSVBFXV0gPT0gMw==");
         _if(VAR_TYPE_SWIPE == 3,function(){
         
            
            
            VAR_RANDOM_SPEED = Math.floor(Math.random() * (parseInt(200) - parseInt(150) + 1)) + parseInt(150)
            

            
            
            VAR_RANDOM_PR = Math.floor(Math.random() * (parseInt(4) - parseInt(3) + 1)) + parseInt(3)
            

            
            
            VAR_RANDOM_RT = Math.floor(Math.random() * (parseInt(3) - parseInt(2) + 1)) + parseInt(2)
            

            
            
            VAR_RANDOM_Y = Math.floor(Math.random() * (parseInt(5) - parseInt(-5) + 1)) + parseInt(-5)
            

            
            
            /*Browser*/
            var move_settings =  {"speed": VAR_RANDOM_SPEED*VAR_SPEED,"gravity": VAR_RANDOM_PR,"deviation": VAR_RANDOM_RT} ;
            move_settings["do_mouse_up"] = "true"
            move(VAR_WIDTH/2 + VAR_X+VAR_X_XEVIL + VAR_W_XEVIL/2,VAR_Y + VAR_RANDOM_Y, move_settings)!
            

         })!
         

         
         
         _set_if_expression("W1tUWVBFX1NXSVBFXV0gPT0gNA==");
         _if(VAR_TYPE_SWIPE == 4,function(){
         
            
            
            VAR_RANDOM_SPEED = Math.floor(Math.random() * (parseInt(200) - parseInt(150) + 1)) + parseInt(150)
            

            
            
            VAR_RANDOM_PR = Math.floor(Math.random() * (parseInt(9) - parseInt(7) + 1)) + parseInt(7)
            

            
            
            VAR_RANDOM_RT = Math.floor(Math.random() * (parseInt(1) - parseInt(0) + 1)) + parseInt(0)
            

            
            
            VAR_RANDOM_Y = Math.floor(Math.random() * (parseInt(5) - parseInt(-5) + 1)) + parseInt(-5)
            

            
            
            /*Browser*/
            var move_settings =  {"speed": VAR_RANDOM_SPEED*VAR_SPEED,"gravity": VAR_RANDOM_PR,"deviation": VAR_RANDOM_RT} ;
            move_settings["do_mouse_up"] = "true"
            move(VAR_WIDTH/2 + VAR_X+VAR_X_XEVIL + VAR_W_XEVIL/2,VAR_Y + VAR_RANDOM_Y, move_settings)!
            

         })!
         

         
         
         _call(function()
         {
         _on_fail(function(){
         VAR_LAST_ERROR = _result()
         VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
         VAR_WAS_ERROR = false
         _break(1,true)
         })
         CYCLES.Current().RemoveLabel("function")
         
            
            
            /*Browser*/
            waiter_timeout_next(5000)
            wait_async_load()!
            

         },null)!
         

         
         
         /*Browser*/
         ;_SELECTOR=VAR_IMAGE_ID + "\u003eAT\u003e" + VAR_CAPTCHA_ID;
         get_element_selector(_SELECTOR, false).nowait().exist()!
         VAR_IS_EXISTS = _result() == 1
         _if(VAR_IS_EXISTS, function(){
         get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
         VAR_IS_EXISTS = _result().indexOf("true")>=0
         })!
         

         
         
         /*Browser*/
         ;_SELECTOR=VAR_ARROW_ID + "\u003eAT\u003e" + VAR_CAPTCHA_ID;
         get_element_selector(_SELECTOR, false).nowait().exist()!
         VAR_IS_EXISTS2 = _result() == 1
         _if(VAR_IS_EXISTS2, function(){
         get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
         VAR_IS_EXISTS2 = _result().indexOf("true")>=0
         })!
         

         
         
         /*Browser*/
         ;_SELECTOR=VAR_RELOAD_ID + "\u003eAT\u003e" + VAR_CAPTCHA_ID;
         get_element_selector(_SELECTOR, false).nowait().exist()!
         VAR_IS_EXISTS3 = _result() == 1
         _if(VAR_IS_EXISTS3, function(){
         get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
         VAR_IS_EXISTS3 = _result().indexOf("true")>=0
         })!
         

      })!
      

      
      
      /*Browser*/
      _SELECTOR = VAR_IMAGE_ID + "\u003eAT\u003e" + VAR_CAPTCHA_ID;
      wait_element(_SELECTOR)!
      get_element_selector(_SELECTOR, false).exist()!
      _if(_result() == "1", function(){
      get_element_selector(_SELECTOR, false).render_base64()!
      VAR_SCREENSHOT_BASE64 = _result()
      })!
      

      
      
      VAR_TEXTINSTR = VAR_SAVED_CACHE.split('"icons_order"')[1]
      

      
      
      _call(function()
      {
      _on_fail(function(){
      VAR_LAST_ERROR = _result()
      VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
      VAR_WAS_ERROR = false
      _break(1,true)
      })
      CYCLES.Current().RemoveLabel("function")
      
         
         
         solver_properties_clear("capmonster")
         solver_property("capmonster","serverurl","http://sctg.xyz")
         solver_property("capmonster","key",VAR_KEY)
         solver_property("capmonster","method","basiliskimg")
         solver_property("capmonster","body",VAR_SCREENSHOT_BASE64)
         solver_property("capmonster","textinstructions",VAR_TEXTINSTR)
         solve_base64_no_fail("capmonster", "")!
         VAR_SAVED_CONTENT = _result();
         

      },null)!
      

      
      
      _set_if_expression("W1tXQVNfRVJST1JdXQ==");
      _if(typeof(VAR_WAS_ERROR) !== "undefined" ? (VAR_WAS_ERROR) : undefined,function(){
      
         
         
         fail((_K==="en" ? "Fail solve captcha" : "Ошибка при решении капчи"));
         

      })!
      

      
      
      VAR_STRING_MATCHES = Boolean(native("regexp", "ismatch", JSON.stringify({text: VAR_SAVED_CONTENT,regexp:("(_)").toString()})) == "true")
      

      
      
      _set_if_expression("W1tTVFJJTkdfTUFUQ0hFU11d");
      _if(typeof(VAR_STRING_MATCHES) !== "undefined" ? (VAR_STRING_MATCHES) : undefined,function(){
      
         
         
         fail((_K==="en" ? "Fail solve captcha" : "Ошибка при решении капчи"));
         

      })!
      

      
      
      VAR_DATA = VAR_SAVED_CONTENT.split(":")[1].replace(/x/g, "").replace(/=/g, "").replace(/y/g, "").replace(/y/g, "").split(";")
      

      
      
      /*Browser*/
      scroll(1,1)!
      

      
      
      /*Browser*/
      _SELECTOR = VAR_IMAGE_ID + "\u003eAT\u003e" + VAR_CAPTCHA_ID;
      wait_element(_SELECTOR)!
      get_element_selector(_SELECTOR, false).script("(function(){var rect = _BAS_HIDE(BrowserAutomationStudio_GetBoundingClientRect)(self);return (rect.left + positionx) + '|' + (rect.top + positiony) + '|' + (rect.right - rect.left) + '|' + (rect.bottom - rect.top) + '|' + (rect.left + positionx + scrollx) + '|' + (rect.top + positiony + scrolly)})();")!
      if(_result().length > 0)
      {
      var split = _result().split("|")
      VAR_X = parseInt(split[0])
      VAR_Y = parseInt(split[1])
      VAR_WIDTH = parseInt(split[2])
      VAR_HEIGHT = parseInt(split[3])
      VAR_ABSOLUTE_X = parseInt(split[4])
      VAR_ABSOLUTE_Y = parseInt(split[5])
      }
      

      
      
      _do_with_params({"foreach_data":(VAR_DATA)},function(){
      _set_action_info({ name: "Foreach" });
      VAR_CYCLE_INDEX = _iterator() - 1
      if(VAR_CYCLE_INDEX > _cycle_param("foreach_data").length - 1)_break();
      VAR_FOREACH_DATA = _cycle_param("foreach_data")[VAR_CYCLE_INDEX]
      
         
         
         VAR_X_TMP = parseInt(VAR_FOREACH_DATA.split(",")[0]);
         VAR_Y_TMP = parseInt(VAR_FOREACH_DATA.split(",")[1]);
         

         
         
         VAR_RANDOM_NUMBER = Math.floor(Math.random() * (parseInt(300) - parseInt(100) + 1)) + parseInt(100)
         

         
         
         sleep(VAR_RANDOM_NUMBER)!
         

         
         
         /*Browser*/
         move(VAR_X + VAR_X_TMP,VAR_Y + VAR_Y_TMP,  {} )!
         mouse(VAR_X + VAR_X_TMP,VAR_Y + VAR_Y_TMP)!
         

      })!
      

      
      
      /*Browser*/
      _SELECTOR = " \u003eCSS\u003e :nth-child(1) \u003e button";
      wait_element_visible(_SELECTOR)!
      _call(_random_point, {})!
      _if(_result().length > 0, function(){
      move( {} )!
      get_element_selector(_SELECTOR, false).clarify(X,Y)!
      _call(_clarify, {} )!
      mouse(X,Y)!
      })!
      

      
      
      _do(function(){
      _set_action_info({ name: "While" });
      VAR_CYCLE_INDEX = _iterator() - 1
      BREAK_CONDITION = true;
      if(!BREAK_CONDITION)_break();
      
         
         
         sleep(1000)!
         

         
         
         _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gMTU=");
         _if(VAR_CYCLE_INDEX > 15,function(){
         
            
            
            fail((_K==="en" ? "Fail solve captcha" : "Ошибка при решении капчи"));
            

         })!
         

         
         
         /*Browser*/
         ;_SELECTOR=" \u003eXPATH\u003e //input[@name=\u0022captcha-response\u0022 and @value=\u0022\u0022]/..";
         get_element_selector(_SELECTOR, false).nowait().exist()!
         VAR_IS_EXISTS = _result() == 1
         _if(VAR_IS_EXISTS, function(){
         get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
         VAR_IS_EXISTS = _result().indexOf("true")>=0
         })!
         

         
         
         _set_if_expression("W1tJU19FWElTVFNdXSA9PSBmYWxzZQ==");
         _if(VAR_IS_EXISTS == false,function(){
         
            
            
            _break("function")
            

         })!
         

      })!
      

   }
   

function GoodXevilPaySolver_GXP_hCaptcha_Click()
   {
   
      
      
      VAR_GLOBAL_SELECTOR = _function_argument("CaptchaSelector")
      

      
      
      VAR_KEY_MODULE = _function_argument("apikey")
      

      
      
      VAR_TRY_NUMBER = _function_argument("TrySolve")
      

      
      
      VAR_IS_INVISIBLE_CAPTCHA = _function_argument("InvisibleCaptcha")
      

      
      
	VAR_CACHE_DELETE = true




	VAR_NUMBER_CAPTCHA_MODULE = 0




	VAR_CYCLE_INDEX = 0




	VAR_UNKNOWN_CAPTCHA = 0




	VAR_SIZE_CAPTCHA_MODULE = 1




	VAR_ERROR_LOAD = "0"




	VAR_ERROR_GET_TASK = 0




	VAR_IS_CHANGED_HCAPTHA = false




	VAR_IS_EXISTS_HCAPTCHA_2_NOTASK = false




	VAR_IS_LOG = false




	VAR_HCAPTCHA_CLOSED = 0




	VAR_ERROR_FIND_MAIN_SELECTOR = 0




	VAR_HCAPTCHA_INVISIBLE = 0




	VAR_NUMBER_CRUMB = 0




	VAR_ERROR_CACHE_TASK_PARSING = 0




	VAR_CURRENT_LANG_MODULE = 0




	VAR_ERROR_CAPTCHA_UNSOLVABLE_MODULE = 0




	VAR_HCAPTCHA_PREFIX_SECOND_FRAME = ""




	VAR_RECAPTCHA_MODULE_ENABLED = 0




	VAR_HCAPTCHA_MODULE_ENABLED = 0




	VAR_FUNCAPTCHA_MODULE_ENABLED = 0




	VAR_ALREADY_SCROLLED_INTO_RELOAD = 0




	VAR_ALREADY_SCROLLED_INTO_SQUARE = 0




	VAR_HCAPTCHA_PREFIX_SECOND_FRAME = ""




	VAR_HCAPTCHA_PREFIX_SECOND_FRAME_ELEMENT = ""




	VAR_ALL_FRAMES_CAPTCHA = 0




	VAR_WAIT_FRAME_TIMEOUT = 0




	VAR_IFRAME_XML_MODULE = "random_string_gener"




	VAR_FRAME_NUMBER_CAPTCHA = 0




	VAR_ALREADY_CHECK_FRAME = 0




	VAR_NAME_MODULE_AUTOSUBMIT = "NaN"




	VAR_ALL_HCAPTCHA_IMAGE_LIST = ""




	VAR_CHECK_EMPTY_BODY = ""




	VAR_SAVED_CACHE_MODULE = ""




	VAR_SET_TASK = ""




	VAR_ALL_HCAPTCHA_IMAGE_LIST_COUNT = 0




	VAR_HCAPTCHA_MAIN_PICTRURE_SIZE = 0




	VAR_LIST_ELEMENT_BAS_MODULE = ""




	VAR_HCAPTCHA_TYPE_4 = false




	VAR_BAS_MODULE_VERSION = "7.12"




	VAR_OLD_VERSION_BAS_MODULE = 0




	_call(function()
	{
	_on_fail(function(){
	VAR_LAST_ERROR = _result()
	VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
	VAR_WAS_ERROR = false
	_break(1,true)
	})
	CYCLES.Current().RemoveLabel("function")

	 
	 
	 {
	 var info = _get_current_browser_version_info("extended")
	 VAR_BROWSER_VERSION_ID = info.id
	 VAR_BROWSER_VERSION_STRING = info.browser_version
	 VAR_BROWSER_ARCHITECTURE = info.architecture
	 }
	 

	 
	 
	 //// Проверить установлены ли модули с автосабмитом.
	 if (typeof NumbersParseRecaptcha2 === 'function') VAR_RECAPTCHA_MODULE_ENABLED = 1, VAR_NAME_MODULE_AUTOSUBMIT = "ReCaptcha 2 Autosubmit";
	 if (typeof BASCaptchaSolver.helpers.HCaptchaHelper === 'function') VAR_HCAPTCHA_MODULE_ENABLED = 1, VAR_NAME_MODULE_AUTOSUBMIT = "hCaptcha Autosubmit";
	 if (typeof BASCaptchaSolver.helpers.FunCaptchaHelper === 'function') VAR_FUNCAPTCHA_MODULE_ENABLED = 1, VAR_NAME_MODULE_AUTOSUBMIT = "FunCaptcha Autosubmit";
	 //// Проверить версию BAS. Версия BAS 25.3.0 имеет движок версии 118
	 var VersionBrowserStringModule = VAR_BROWSER_VERSION_STRING;
	 var NumbersBeforeDotModule = VersionBrowserStringModule.split('.')[0];
	 var BrowserVersionIntModule = parseInt(NumbersBeforeDotModule);
	 if (BrowserVersionIntModule < 118) VAR_OLD_VERSION_BAS_MODULE = 1;
	 

	},null)!




	_set_if_expression("W1tGVU5DQVBUQ0hBX01PRFVMRV9FTkFCTEVEXV0gPT0gMSB8fCBbW1JFQ0FQVENIQV9NT0RVTEVfRU5BQkxFRF1dID09IDEgfHwgW1tIQ0FQVENIQV9NT0RVTEVfRU5BQkxFRF1dID09IDE=");
	_if(VAR_FUNCAPTCHA_MODULE_ENABLED == 1 || VAR_RECAPTCHA_MODULE_ENABLED == 1 || VAR_HCAPTCHA_MODULE_ENABLED == 1,function(){

	 
	 
	 fail((_K==="en" ? "Solve the captcha failed, to continue solving captchas by clicks requires to disable module " +VAR_NAME_MODULE_AUTOSUBMIT + " and also remove all actions from the script associated with it and retry solve captcha again" : "Решить капчу не удалось, для продолжения решения капчи кликами требуется отключить сторонний встроенный модуль в BAS: " +VAR_NAME_MODULE_AUTOSUBMIT + ", а также удалить все действия из файла сценария связанные с ним и повторить попытку"));
	 

	})!




	_set_if_expression("W1tXQVNfRVJST1JdXSB8fCBbW09MRF9WRVJTSU9OX0JBU19NT0RVTEVdXSA9PSAx");
	_if(VAR_WAS_ERROR || VAR_OLD_VERSION_BAS_MODULE == 1,function(){

	 
	 
	 _set_if_expression("W1tMQVNUX0VSUk9SXV0uaW5kZXhPZigiZ2V0X2N1cnJlbnRfYnJvd3Nlcl92ZXJzaW9uX2luZm8iKSA+PSAwIHx8IFtbT0xEX1ZFUlNJT05fQkFTX01PRFVMRV1dID09IDE=");
	 _if(VAR_LAST_ERROR.indexOf("get_current_browser_version_info") >= 0 || VAR_OLD_VERSION_BAS_MODULE == 1,function(){
	 
		
		
		fail((_K==="en" ? "Captcha solved failed, for the version module" +VAR_BAS_MODULE_VERSION + " requires BAS version 26.3.0 or higher version" : "Решить капчу не удалось, для модуля версии " +VAR_BAS_MODULE_VERSION + " требуется установить версию BAS 26.3.0 или версию старше"));
		

	 })!
	 

	})!





	_call(function()
	{
	_on_fail(function(){
	VAR_LAST_ERROR = _result()
	VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
	VAR_WAS_ERROR = false
	_break(1,true)
	})
	CYCLES.Current().RemoveLabel("function")},null)!




	VAR_GREEN_TICK = false




	/*Browser*/
	cache_allow("*hcaptcha.com/getcaptcha*")!




	/*Browser*/
	cache_allow("*img*hcaptcha.com/*")!




	_set_if_expression("W1tJU19JTlZJU0lCTEVfQ0FQVENIQV1d");
	_if(typeof(VAR_IS_INVISIBLE_CAPTCHA) !== "undefined" ? (VAR_IS_INVISIBLE_CAPTCHA) : undefined,function(){

	 
	 
	 /*Browser*/
	 waiter_timeout_next(45000)
	 wait_load("*img*hcaptcha.com/*")!
	 

	 
	 
	 /*Browser*/
	 wait_load("*hcaptcha.com/getcaptcha*")!
	 

	})!




	_call(function()
	{
	_on_fail(function(){
	VAR_LAST_ERROR = _result()
	VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
	VAR_WAS_ERROR = false
	_break(1,true)
	})
	CYCLES.Current().RemoveLabel("function")

	 
	 
	 VAR_SPEED = 200;
	 VAR_GRAVITY = 12;
	 VAR_DEVIATION = 5;
	 VAR_IS_MOBILE = _IS_MOBILE;
	 

	 
	 
	 _set_if_expression("W1tJU19NT0JJTEVdXSA9PSBmYWxzZSAmJiByYW5kICgxLDEwKSA+IDM=");
	 _if(VAR_IS_MOBILE == false && rand (1,10) > 3,function(){
	 
		
		
		_do(function(){
		_set_action_info({ name: "While" });
		VAR_CYCLE_INDEX = _iterator() - 1
		BREAK_CONDITION = VAR_CYCLE_INDEX < 2;
		if(!BREAK_CONDITION)_break();
		
		   
		   
		   _get_browser_screen_settings()!
		   ;(function(){
		   var result = JSON.parse(_result())
		   VAR_SCROLL_X = result["ScrollX"]
		   VAR_SCROLL_Y = result["ScrollY"]
		   VAR_CURSOR_X = result["CursorX"]
		   VAR_CURSOR_Y = result["CursorY"]
		   VAR_CURSOR_ABSOLUTE_X = result["CursorX"] + result["ScrollX"]
		   VAR_CURSOR_ABSOLUTE_Y = result["CursorY"] + result["ScrollY"]
		   VAR_BROWSER_WIDTH = result["Width"]
		   VAR_BROWSER_HEIGHT = result["Height"]
		   })();
		   

		   
		   
		   var scroll_x=parseInt(VAR_CURSOR_Y);
		   var scroll_y=parseInt(VAR_SCROLL_Y);
		   var browser_h=parseInt(VAR_BROWSER_HEIGHT);
		   //-------------------- Привели все в числа, считаем позицию ---------------------
		   var absolut_y = VAR_CURSOR_Y + VAR_SCROLL_Y;
		   var y_without_scroll = absolut_y - VAR_SCROLL_Y;
		   var check_y_top = VAR_BROWSER_HEIGHT/12;
		   var check_y_down = VAR_BROWSER_HEIGHT/100*92;
		   var move_y_top = VAR_BROWSER_HEIGHT/10;
		   var move_y_down = VAR_BROWSER_HEIGHT/100*80;
		   // -------------------------- Округляем ----------------------------------
		   VAR_CHECK_Y_TOP = check_y_top.toFixed();
		   VAR_CHECK_Y_DOWN = check_y_down.toFixed();
		   VAR_Y_WITHOUNT_SCROLL = y_without_scroll.toFixed();
		   VAR_MOVE_Y_TOP = move_y_top.toFixed();
		   VAR_MOVE_Y_DOWN = move_y_down.toFixed();
		   // ----------------- Снова приводим к числу ------------------------
		   VAR_CHECK_Y_TOP=parseInt(VAR_CHECK_Y_TOP);
		   VAR_CHECK_Y_DOWN=parseInt(VAR_CHECK_Y_DOWN);
		   VAR_Y_WITHOUNT_SCROLL=parseInt(VAR_Y_WITHOUNT_SCROLL);
		   VAR_MOVE_Y_TOP=parseInt(VAR_MOVE_Y_TOP);
		   VAR_MOVE_Y_DOWN=parseInt(VAR_MOVE_Y_DOWN);
		   

		   
		   
		   /*Browser*/
		   move(rand(VAR_BROWSER_WIDTH/5,VAR_BROWSER_WIDTH/1.3),rand(VAR_MOVE_Y_TOP + VAR_SCROLL_Y,VAR_MOVE_Y_DOWN + VAR_SCROLL_Y),  {} )!
		   

		   
		   
		   _set_if_expression("cmFuZCAoMSwxMCkgPiA1");
		   _if(rand (1,10) > 5,function(){
		   
			  
			  
			  _break("function")
			  

		   })!
		   

		})!
		

	 })!
	 

	 
	 
	 VAR_HCAPTCHA_PREFIX = VAR_GLOBAL_SELECTOR;
	 VAR_HCAPTCHA_PREFIX_FIRST_FRAME = VAR_HCAPTCHA_PREFIX;
	 {
	 var index = VAR_HCAPTCHA_PREFIX.toString().lastIndexOf(">FRAME>")
	 if(index >= 0)
	 VAR_HCAPTCHA_PREFIX = VAR_HCAPTCHA_PREFIX.substring(0,index)
	 VAR_HCAPTCHA_PREFIX_FIRST_FRAME = VAR_HCAPTCHA_PREFIX
	 index = VAR_HCAPTCHA_PREFIX.toString().lastIndexOf(">FRAME>")
	 if(index >= 0)
	 VAR_HCAPTCHA_PREFIX = VAR_HCAPTCHA_PREFIX.substring(0,index + ">FRAME>".length)
	 else
	 VAR_HCAPTCHA_PREFIX = ""
	 }
	 

	 
	 
	 _do(function(){
	 _set_action_info({ name: "For" });
	 VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
	 if(VAR_CYCLE_INDEX > parseInt(100))_break();
	 
		
		
		/*Browser*/
		;_SELECTOR=VAR_HCAPTCHA_PREFIX + "\u003eCSS\u003eiframe";
		get_element_selector(_SELECTOR, false).nowait().exist()!
		VAR_IS_EXISTS = _result() == 1
		

		
		
		_set_if_expression("W1tJU19FWElTVFNdXQ==");
		_if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
		
		   
		   
		   /*Browser*/
		   ;_SELECTOR=VAR_HCAPTCHA_PREFIX + "\u003eCSS\u003eiframe";
		   get_element_selector(_SELECTOR, true).length()!
		   VAR_ALL_FRAMES_CAPTCHA = _result()
		   

		})!
		

		
		
		/*Browser*/
		;_SELECTOR=VAR_HCAPTCHA_PREFIX + "\u003eCSS\u003eiframe\u003eAT\u003e" + VAR_FRAME_NUMBER_CAPTCHA;
		get_element_selector(_SELECTOR, false).nowait().exist()!
		VAR_IS_EXISTS = _result() == 1
		

		
		
		_set_if_expression("W1tJU19FWElTVFNdXQ==");
		_if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
		
		   
		   
		   /*Browser*/
		   _SELECTOR = VAR_HCAPTCHA_PREFIX + "\u003eCSS\u003eiframe\u003eAT\u003e" + VAR_FRAME_NUMBER_CAPTCHA;
		   wait_element(_SELECTOR)!
		   get_element_selector(_SELECTOR, false).xml()!
		   VAR_IFRAME_XML_MODULE = _result()
		   

		})!
		

		
		
		_set_if_expression("W1tJRlJBTUVfWE1MX01PRFVMRV1dLmluZGV4T2YoIi9zdGF0aWMvaGNhcHRjaGEuaHRtbCIpID49IDAgJiYgW1tJRlJBTUVfWE1MX01PRFVMRV1dLmluZGV4T2YoIiNmcmFtZT1jaGFsbGVuZ2UiKSA+PSAw");
		_if(VAR_IFRAME_XML_MODULE.indexOf("/static/hcaptcha.html") >= 0 && VAR_IFRAME_XML_MODULE.indexOf("#frame=challenge") >= 0,function(){
		
		   
		   
		   /*Browser*/
		   ;_SELECTOR=VAR_HCAPTCHA_PREFIX + "\u003eCSS\u003eiframe\u003eAT\u003e" + VAR_FRAME_NUMBER_CAPTCHA + "\u003eFRAME\u003eCSS\u003ehtml";
		   get_element_selector(_SELECTOR, false).nowait().exist()!
		   VAR_IS_EXISTS = _result() == 1
		   

		   
		   
		   _set_if_expression("W1tJU19FWElTVFNdXQ==");
		   _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
		   
			  
			  
			  _SELECTOR = VAR_HCAPTCHA_PREFIX + "\u003eCSS\u003eiframe\u003eAT\u003e" + VAR_FRAME_NUMBER_CAPTCHA + "\u003eFRAME\u003eCSS\u003ehtml";
			  wait_element(_SELECTOR)!
			  get_element_selector(_SELECTOR, false).script2("window.send_ = XMLHttpRequest.prototype.send;\r\nXMLHttpRequest.prototype.send = function() \u007b\r\n    if (arguments[0].indexOf(\u0027host=\u0027) \u003e -1) \u007b\r\n        let d = arguments[0]\r\n        if(d.indexOf(\u0027action\u0027) \u003e -1)\u007b\r\n            arguments[0] = d.replace(/(?\u003c=action\u005c=)(.+?)(?=\u0026)/g,\u0027challenge-abandon-retry\u0027);\r\n        \u007delse\u007b\r\n            arguments[0] = d+\u0027\u0026action=challenge-abandon-retry\u0027;\r\n        \u007d\r\n    \u007d\r\n    window.send_.apply(this, arguments);\r\n\u007d\r\nXMLHttpRequest.prototype.open.toString  = function()\u007b\r\n    return \u0027function open() \u007b [native code] \u007d\u0027\r\n\u007d",JSON.stringify(_read_variables([])))!
			  var _parse_result = JSON.parse(_result())
			  _write_variables(JSON.parse(_parse_result.variables))
			  if(!_parse_result.is_success)
			  fail(_parse_result.error)
			  

		   })!
		   

		   
		   
		   /*Browser*/
		   ;_SELECTOR=VAR_HCAPTCHA_PREFIX + "\u003eCSS\u003eiframe\u003eAT\u003e" + VAR_FRAME_NUMBER_CAPTCHA;
		   get_element_selector(_SELECTOR, false).nowait().exist()!
		   VAR_IS_EXISTS = _result() == 1
		   _if(VAR_IS_EXISTS, function(){
		   get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
		   VAR_IS_EXISTS = _result().indexOf("true")>=0
		   })!
		   

		   
		   
		   _set_if_expression("W1tJU19FWElTVFNdXQ==");
		   _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
		   
			  
			  
			  /*Browser*/
			  _SELECTOR = VAR_HCAPTCHA_PREFIX + "\u003eCSS\u003eiframe\u003eAT\u003e" + VAR_FRAME_NUMBER_CAPTCHA;
			  wait_element(_SELECTOR)!
			  get_element_selector(_SELECTOR, false).attr("title")!
			  VAR_SAVED_ATTRIBUTE = _result()
			  

			  
			  
			  VAR_HCAPTCHA_PREFIX_SECOND_FRAME = VAR_HCAPTCHA_PREFIX + ">CSS>iframe[title=\"" + _result() + "\"]" + ">AT>" + VAR_NUMBER_CAPTCHA_MODULE + ">FRAME> >CSS> body";
			  VAR_HCAPTCHA_PREFIX_SECOND_FRAME_ELEMENT = VAR_HCAPTCHA_PREFIX + ">CSS>iframe[title=\"" + _result() + "\"]" + ">AT>" + VAR_NUMBER_CAPTCHA_MODULE
			  

			  
			  
			  _break("function")
			  

		   })!
		   

		   
		   
		   VAR_NUMBER_CAPTCHA_MODULE = parseInt(VAR_NUMBER_CAPTCHA_MODULE) + parseInt(1)
		   

		})!
		

		
		
		_set_if_expression("W1tGUkFNRV9OVU1CRVJfQ0FQVENIQV1dID49IFtbQUxMX0ZSQU1FU19DQVBUQ0hBXV0gLSAx");
		_if(VAR_FRAME_NUMBER_CAPTCHA >= VAR_ALL_FRAMES_CAPTCHA - 1,function(){
		
		   
		   
		   VAR_NUMBER_CAPTCHA_MODULE = 0
		   

		   
		   
		   VAR_FRAME_NUMBER_CAPTCHA = 0
		   

		   
		   
		   _break("function")
		   

		})!
		

		
		
		VAR_FRAME_NUMBER_CAPTCHA = parseInt(VAR_FRAME_NUMBER_CAPTCHA) + parseInt(1)
		

	 })!
	 

	 
	 
	 _cycle_params().if_else = VAR_HCAPTCHA_PREFIX_SECOND_FRAME == "";
	 _set_if_expression("W1tIQ0FQVENIQV9QUkVGSVhfU0VDT05EX0ZSQU1FXV0gPT0gIiI=");
	 _if(_cycle_params().if_else,function(){
	 
		
		
		_do(function(){
		_set_action_info({ name: "For" });
		VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
		if(VAR_CYCLE_INDEX > parseInt(51))_break();
		
		   
		   
		   _set_if_expression("W1tJU19MT0ddXSA9PSB0cnVl");
		   _if(VAR_IS_LOG == true,function(){
		   
			  
			  
			  _info((_K==="en" ? "Тест": "Ждём кнопку я не робот"));
			  

		   })!
		   

		   
		   
		   /*Browser*/
		   ;_SELECTOR=VAR_GLOBAL_SELECTOR;
		   get_element_selector(_SELECTOR, false).nowait().exist()!
		   VAR_IS_EXISTS = _result() == 1
		   _if(VAR_IS_EXISTS, function(){
		   get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
		   VAR_IS_EXISTS = _result().indexOf("true")>=0
		   })!
		   

		   
		   
		   _cycle_params().if_else = typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined;
		   _set_if_expression("W1tJU19FWElTVFNdXQ==");
		   _if(_cycle_params().if_else,function(){
		   
			  
			  
			  _set_if_expression("W1tJU19MT0ddXSA9PSB0cnVl");
			  _if(VAR_IS_LOG == true,function(){
			  
				 
				 
				 _info((_K==="en" ? "Тест": "Кнопка я не робот найдена, нажимаем на кнопку"));
				 

			  })!
			  

			  
			  
			  _cycle_params().if_else = VAR_GLOBAL_SELECTOR == ">CSS> iframe[src*='checkbox']>FRAME> >CSS> #checkbox";
			  _set_if_expression("W1tHTE9CQUxfU0VMRUNUT1JdXSA9PSAiPkNTUz4gaWZyYW1lW3NyYyo9J2NoZWNrYm94J10+RlJBTUU+ID5DU1M+ICNjaGVja2JveCI=");
			  _if(_cycle_params().if_else,function(){
			  
				 
				 
				 VAR_RANDOM_NUMBER_CLICK = Math.floor(Math.random() * (parseInt(12) - parseInt(1) + 1)) + parseInt(1)
				 

				 
				 
				 _set_if_expression("W1tSQU5ET01fTlVNQkVSX0NMSUNLXV0gPD0gNA==");
				 _if(VAR_RANDOM_NUMBER_CLICK <= 4,function(){
				 
					
					
					/*Browser*/
					_SELECTOR = VAR_GLOBAL_SELECTOR;waiter_timeout_next(8000)
					wait_element_visible(_SELECTOR)!
					_call(_random_point, {})!
					_if(_result().length > 0, function(){
					move( {} )!
					get_element_selector(_SELECTOR, false).clarify(X,Y)!
					_call(_clarify, {} )!
					mouse(X,Y)!
					})!
					

				 })!
				 

				 
				 
				 _set_if_expression("W1tSQU5ET01fTlVNQkVSX0NMSUNLXV0gPiA0");
				 _if(VAR_RANDOM_NUMBER_CLICK > 4,function(){
				 
					
					
					_get_browser_screen_settings()!
					;(function(){
					var result = JSON.parse(_result())
					VAR_SCROLL_X = result["ScrollX"]
					VAR_SCROLL_Y = result["ScrollY"]
					VAR_CURSOR_X = result["CursorX"]
					VAR_CURSOR_Y = result["CursorY"]
					VAR_CURSOR_ABSOLUTE_X = result["CursorX"] + result["ScrollX"]
					VAR_CURSOR_ABSOLUTE_Y = result["CursorY"] + result["ScrollY"]
					VAR_BROWSER_WIDTH = result["Width"]
					VAR_BROWSER_HEIGHT = result["Height"]
					})();
					

					
					
					/*Browser*/
					_SELECTOR = "\u003eCSS\u003e iframe[src*=\u0027checkbox\u0027]\u003eFRAME\u003e \u003eCSS\u003e div[class*=\u0027label-container\u0027]";
					wait_element(_SELECTOR)!
					get_element_selector(_SELECTOR, false).script("(function(){var rect = _BAS_HIDE(BrowserAutomationStudio_GetBoundingClientRect)(self);return (rect.left + positionx) + '|' + (rect.top + positiony) + '|' + (rect.right - rect.left) + '|' + (rect.bottom - rect.top) + '|' + (rect.left + positionx + scrollx) + '|' + (rect.top + positiony + scrolly)})();")!
					if(_result().length > 0)
					{
					var split = _result().split("|")
					VAR_X_HCAPTCHA = parseInt(split[0])
					VAR_Y_HCAPTCHA = parseInt(split[1])
					VAR_WIDTH_HCAPTCHA = parseInt(split[2])
					VAR_HEIGHT_HCAPTCHA = parseInt(split[3])
					VAR_ABSOLUTE_X = parseInt(split[4])
					VAR_ABSOLUTE_Y = parseInt(split[5])
					}
					

					
					
					function getRandomNonInteger(min, max) {
					const random = Math.random() * (max - min) + min;
					return Math.floor(random) !== random ? random : getRandomNonInteger(min, max);
					}
					VAR_X_HCAPTCHA_MIN = getRandomNonInteger(2, 10);
					VAR_Y_HCAPTCHA_MIN = getRandomNonInteger(1.5, 2.7);
					

					
					
					/*Browser*/
					move(VAR_SCROLL_X + VAR_X_HCAPTCHA + VAR_WIDTH_HCAPTCHA/VAR_X_HCAPTCHA_MIN,VAR_SCROLL_Y + VAR_Y_HCAPTCHA + VAR_HEIGHT_HCAPTCHA/VAR_Y_HCAPTCHA_MIN,  {} )!
					mouse(VAR_SCROLL_X + VAR_X_HCAPTCHA + VAR_WIDTH_HCAPTCHA/VAR_X_HCAPTCHA_MIN,VAR_SCROLL_Y + VAR_Y_HCAPTCHA + VAR_HEIGHT_HCAPTCHA/VAR_Y_HCAPTCHA_MIN)!
					

				 })!
				 

			  })!
			  

			  
			  
			  _if(!_cycle_params().if_else,function(){
			  
				 
				 
				 /*Browser*/
				 _SELECTOR = VAR_GLOBAL_SELECTOR;waiter_timeout_next(8000)
				 wait_element_visible(_SELECTOR)!
				 _call(_random_point, {})!
				 _if(_result().length > 0, function(){
				 move( {} )!
				 get_element_selector(_SELECTOR, false).clarify(X,Y)!
				 _call(_clarify, {} )!
				 mouse(X,Y)!
				 })!
				 

			  })!
			  delete _cycle_params().if_else;
			  

			  
			  
			  _break("function")
			  

		   })!
		   

		   
		   
		   _if(!_cycle_params().if_else,function(){
		   
			  
			  
			  sleep(rand(500,1000))!
			  

		   })!
		   delete _cycle_params().if_else;
		   

		   
		   
		   _set_if_expression("IVtbSVNfRVhJU1RTXV0=");
		   _if(!VAR_IS_EXISTS,function(){
		   
			  
			  
			  _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gcmFuZCAoNDIsNDkp");
			  _if(VAR_CYCLE_INDEX > rand (42,49),function(){
			  
				 
				 
				 VAR_ERROR_FIND_MAIN_SELECTOR = "1"
				 

			  })!
			  

		   })!
		   

		})!
		

	 })!
	 

	 
	 
	 _if(!_cycle_params().if_else,function(){
	 
		
		
		_set_if_expression("W1tJU19MT0ddXSA9PSB0cnVl");
		_if(VAR_IS_LOG == true,function(){
		
		   
		   
		   _info((_K==="en" ? "Тест": "Капча уже открыта, решаем эту каптчу как Invisisible"));
		   

		})!
		

		
		
		VAR_HCAPTCHA_INVISIBLE = 1
		

	 })!
	 delete _cycle_params().if_else;
	 

	},null)!




	_set_if_expression("W1tXQVNfRVJST1JdXQ==");
	_if(typeof(VAR_WAS_ERROR) !== "undefined" ? (VAR_WAS_ERROR) : undefined,function(){

	 
	 
	 _set_if_expression("W1tMQVNUX0VSUk9SXV0gPT09ICdBYm9ydGVkIEJ5IFVzZXInIHx8IFtbTEFTVF9FUlJPUl1dICA9PT0gJ9Cf0YDQtdGA0LLQsNC90L4g0J/QvtC70YzQt9C+0LLQsNGC0LXQu9C10Lwn");
	 _if(VAR_LAST_ERROR === 'Aborted By User' || VAR_LAST_ERROR  === 'Прервано Пользователем',function(){
	 
		
		
		_function_return(false)
		

	 })!
	 

	 
	 
	 fail(VAR_LAST_ERROR)
	 

	})!




	_set_if_expression("W1tFUlJPUl9GSU5EX01BSU5fU0VMRUNUT1JdXSA9PSAx");
	_if(VAR_ERROR_FIND_MAIN_SELECTOR == 1,function(){

	 
	 
	 _set_if_expression("W1tJU19JTlZJU0lCTEVfQ0FQVENIQV1dID09PSBmYWxzZQ==");
	 _if(VAR_IS_INVISIBLE_CAPTCHA === false,function(){
	 
		
		
		fail((_K==="en" ? "Failed to solve hCaptcha. Timeout wait of hCaptcha main selector with 'I am human' button" : "Не удалось решить hСaptcha. Таймаут загрузки основного селектора hCaptcha c кнопкой 'Я человек'"));
		

	 })!
	 

	 
	 
	 _set_if_expression("W1tJU19JTlZJU0lCTEVfQ0FQVENIQV1dID09PSB0cnVl");
	 _if(VAR_IS_INVISIBLE_CAPTCHA === true,function(){
	 
		
		
		fail((_K==="en" ? "Failed to solve hCaptcha. Invisible hCaptcha open captcha window selector wait timeout" : "Не удалось решить hСaptcha. Таймаут ожидания селектора открытого окна Invisible hCaptcha."));
		

	 })!
	 

	})!




	VAR_TRY_CAPTCHA = "0"




	VAR_FRAME_NUMBER_CAPTCHA = 0




	VAR_HCAPTCHA_CLOSED = "0"




	VAR_CAPTCHA_FAIL = "0"




	VAR_ERROR_LOAD = "0"




	VAR_ERROR_KEY = "0"




	VAR_ERROR_BALANCE = "0"




	VAR_ERROR_LANG = "0"




	VAR_ALL_FRAMES_CAPTCHA = 0




	VAR_IFRAME_XML_MODULE = "random_string_gener"




	VAR_FRAME_NUMBER_CAPTCHA = 0




	VAR_GET_ALL_COORDINATES = 0




	VAR_FIRST_LOAD_CAPTCHA = true




	VAR_FIRST_LOAD_BUTTON = true





	_do(function(){
	_set_action_info({ name: "For" });
	VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
	if(VAR_CYCLE_INDEX > parseInt(500))_break();

	 
	 
	 VAR_CYCLE_INDEX = 0
	 

	 
	 
	 VAR_HCAPTCHA_CLOSED = 0
	 

	 
	 
	 _set_if_expression("W1tFUlJPUl9LRVldXSA9PSAx");
	 _if(VAR_ERROR_KEY == 1,function(){
	 
		
		
		fail((_K==="en" ? "Не удалось решить hСaptcha. API secret key from captcha recognition is wrong ERROR_WRONG_USER_KEY" : "Не удалось решить hСaptcha. Секретный ключ API от сервиса распознавания неправильный ERROR_WRONG_USER_KEY"));
		

	 })!
	 

	 
	 
	 _set_if_expression("W1tFUlJPUl9CQUxBTkNFXV0gPT0gMQ==");
	 _if(VAR_ERROR_BALANCE == 1,function(){
	 
		
		
		fail((_K==="en" ? "The balance on the captcha service has ended - ERROR_ZERO_BALANCE" : "Закончился баланс на сервисе распознавания капчи - ERROR_ZERO_BALANCE"));
		

	 })!
	 

	 
	 
	 _set_if_expression("W1tDQVBUQ0hBX0ZBSUxdXSA+IDE=");
	 _if(VAR_CAPTCHA_FAIL > 1,function(){
	 
		
		
		/*Browser*/
		cache_data_clear()!
		

		
		
		_cycle_params().if_else = VAR_SAVED_CONTENT.indexOf("<html>") >= 0;
		_set_if_expression("W1tTQVZFRF9DT05URU5UXV0uaW5kZXhPZigiPGh0bWw+IikgPj0gMA==");
		_if(_cycle_params().if_else,function(){
		
		   
		   
		   fail((_K==="en" ? "hCaptcha solved failed. SCTG solving service is not working at the moment" : "hCaptcha не была решена, причина: сервис по решение каптч SCTG не работает в данный момент."));
		  

		})!
		

		
		
		_if(!_cycle_params().if_else,function(){
		
		   
		   
		   fail((_K==="en" ? "Failed to solve hCaptcha, reason - " +VAR_SAVED_CONTENT : "Не удалось решить hCaptcha, причина - " +VAR_SAVED_CONTENT));
		   

		})!
		delete _cycle_params().if_else;
		

	 })!
	 

	 
	 
	 _set_if_expression("W1tVTktOT1dOX0NBUFRDSEFdXSA+IDM=");
	 _if(VAR_UNKNOWN_CAPTCHA > 3,function(){
	 
		
		
		/*Browser*/
		cache_data_clear()!
		

		
		
		fail((_K==="en" ? "Failed to solve hCaptcha. This captcha type is unknown" : "Не удалось решить hCaptcha, модуль не умеет решать этот тип капчи"));
			

	 })!
	 

	 
	 
	 _set_if_expression("W1tFUlJPUl9DQVBUQ0hBX1VOU09MVkFCTEVfTU9EVUxFXV0gPiAy");
	 _if(VAR_ERROR_CAPTCHA_UNSOLVABLE_MODULE > 2,function(){
	 
		
		
		/*Browser*/
		cache_data_clear()!
		

		
		
		sleep(100)!
		

		
		
		   fail((_K==="en" ? "Failed to solve hCaptcha. Service SCTG cant solve this captcha, error type: ERROR_CAPTCHA_UNSOLVABLE" : "Не удалось решить hCaptcha. Сервис SCTG не умеет решать эту каптчу. Код ошибки: ERROR_CAPTCHA_UNSOLVABLE"));
			

	 })!
	 

	 
	 
	 _do(function(){
	 _set_action_info({ name: "For" });
	 VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
	 if(VAR_CYCLE_INDEX > parseInt(300))_break();
	 
		
		
		VAR_WAIT_FRAME_TIMEOUT = parseInt(VAR_WAIT_FRAME_TIMEOUT) + parseInt(1)
		

		
		
		/*Browser*/
		;_SELECTOR=VAR_HCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e #checkbox[aria-checked=\u0027true\u0027]";
		get_element_selector(_SELECTOR, false).nowait().exist()!
		VAR_IS_EXISTS = _result() == 1
		

		
		
		_set_if_expression("W1tJU19FWElTVFNdXSA9PSB0cnVlICYmIFtbUkVTVUxUX1NFTEVDVE9SXV0gIT0gMQ==");
		_if(VAR_IS_EXISTS == true,function(){
		
		   
		   
		   VAR_GREEN_TICK = true
		   

		   
		   
		   _set_if_expression("W1tDQUNIRV9ERUxFVEVdXSA9PSB0cnVl");
		   _if(VAR_CACHE_DELETE == true,function(){
		   
			  
			  
			  /*Browser*/
			  cache_data_clear()!
			  

		   })!
		   

		   
		   
		   _break("function")
		   

		})!
		

		
		
		/*Browser*/
		;_SELECTOR=VAR_HCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e #status[aria-hidden=\u0027false\u0027]";
		get_element_selector(_SELECTOR, false).nowait().exist()!
		VAR_IS_EXISTS = _result() == 1
		_if(VAR_IS_EXISTS, function(){
		get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
		VAR_IS_EXISTS = _result().indexOf("true")>=0
		})!
		

		
		
		_set_if_expression("W1tJU19FWElTVFNdXSA9PSB0cnVl");
		_if(VAR_IS_EXISTS == true,function(){
		
		   
		   
		   /*Browser*/
		   cache_data_clear()!
		   

		   
		   
		   fail((_K==="en" ? "Failed to solve hCaptcha. Rate limited or Network error" : "Не удалось решить hcaptcha, ваш компьютер или сеть отправили слишком много запросов"));
		

		})!
		

		
		
		_set_if_expression("W1tIQ0FQVENIQV9JTlZJU0lCTEVdXSA+IDAgJiYgW1tGSVJTVF9MT0FEX0NBUFRDSEFdXSA9PSBmYWxzZSAmJiBbW05VTUJFUl9DUlVNQl1dID09IDAgJiYgW1tSRVNVTFRfU0VMRUNUT1JdXSAhPSAxICYmIFtbQ1lDTEVfSU5ERVhdXSA+IDE=");
		_if(VAR_HCAPTCHA_INVISIBLE > 0 && VAR_FIRST_LOAD_CAPTCHA == false && VAR_NUMBER_CRUMB == 0 && VAR_CYCLE_INDEX > 1,function(){
		
		   
		   
		   /*Browser*/
		   ;_SELECTOR=VAR_HCAPTCHA_PREFIX_SECOND_FRAME_ELEMENT;
		   get_element_selector(_SELECTOR, false).nowait().exist()!
		   VAR_IS_EXISTS = _result() == 1
		   _if(VAR_IS_EXISTS, function(){
		   get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
		   VAR_IS_EXISTS = _result().indexOf("true")>=0
		   })!
		   

		   
		   
		   _set_if_expression("IVtbRVBJQ19HQU1FU19DVVNUT01fQ0hFQ0tdXQ==");
		   _if(true,function(){
		   
			  
			  
			  _set_if_expression("W1tJU19FWElTVFNdXSA9PSBmYWxzZSAmJiBbW0NZQ0xFX0lOREVYXV0gPj0gMQ==");
			  _if(VAR_IS_EXISTS == false && VAR_CYCLE_INDEX >= 1,function(){
			  
				 
				 
				 VAR_GREEN_TICK = true
				 

				 
				 
				 _set_if_expression("W1tDQUNIRV9ERUxFVEVdXSA9PSB0cnVl");
				 _if(VAR_CACHE_DELETE == true,function(){
				 
					
					
					/*Browser*/
					cache_data_clear()!
					

				 })!
				 

				 
				 
				 _break("function")
				 

			  })!
			  

			  
			  
			  _set_if_expression("W1tJU19FWElTVFNdXSA9PSB0cnVlICYmIFtbQ1lDTEVfSU5ERVhdXSA+PSA0");
			  _if(VAR_IS_EXISTS == true && VAR_CYCLE_INDEX >= 4,function(){
			  
				 
				 
				 /*Browser*/
				 _SELECTOR = VAR_HCAPTCHA_PREFIX_SECOND_FRAME + "\u003eXPATH\u003e //div[@class=\u0022interface-challenge\u0022]";
				 wait_element(_SELECTOR)!
				 get_element_selector(_SELECTOR, false).script("(function(){var rect = _BAS_HIDE(BrowserAutomationStudio_GetBoundingClientRect)(self);return (rect.left + positionx) + '|' + (rect.top + positiony) + '|' + (rect.right - rect.left) + '|' + (rect.bottom - rect.top) + '|' + (rect.left + positionx + scrollx) + '|' + (rect.top + positiony + scrolly)})();")!
				 if(_result().length > 0)
				 {
				 var split = _result().split("|")
				 VAR_X_MODULE = parseInt(split[0])
				 VAR_Y_MODULE = parseInt(split[1])
				 VAR_WIDTH_MODULE = parseInt(split[2])
				 VAR_HEIGHT_MODULE = parseInt(split[3])
				 VAR_ABSOLUTE_X = parseInt(split[4])
				 VAR_ABSOLUTE_Y = parseInt(split[5])
				 }
				 

				 
				 
				 _set_if_expression("W1tZX01PRFVMRV1dIDwgLTEwMDA=");
				 _if(VAR_Y_MODULE < -1000,function(){
				 
					
					
					VAR_GREEN_TICK = true
					

					
					
					_set_if_expression("W1tDQUNIRV9ERUxFVEVdXSA9PSB0cnVl");
					_if(VAR_CACHE_DELETE == true,function(){
					
					   
					   
					   /*Browser*/
					   cache_data_clear()!
					   

					})!
					

					
					
					_break("function")
					

				 })!
				 

			  })!
			  

		   })!
		   

		})!
		

		
		
		_cycle_params().if_else = VAR_HCAPTCHA_PREFIX_SECOND_FRAME == "";
		_set_if_expression("W1tIQ0FQVENIQV9QUkVGSVhfU0VDT05EX0ZSQU1FXV0gPT0gIiI=");
		_if(_cycle_params().if_else,function(){
		
		   
		   
		   _set_if_expression("W1tJU19MT0ddXSA9PSB0cnVl");
		   _if(VAR_IS_LOG == true,function(){
		   
			  
			  
			  _info((_K==="en" ? "Тест": "Ждём когда модуль откроет окно с hCaptcha. Попытка: " + VAR_WAIT_FRAME_TIMEOUT));
			  

		   })!
		   

		   
		   
		   _do(function(){
		   _set_action_info({ name: "For" });
		   VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
		   if(VAR_CYCLE_INDEX > parseInt(30))_break();
		   
			  
			  
			  /*Browser*/
			  ;_SELECTOR=VAR_HCAPTCHA_PREFIX + "\u003eCSS\u003eiframe";
			  get_element_selector(_SELECTOR, false).nowait().exist()!
			  VAR_IS_EXISTS = _result() == 1
			  

			  
			  
			  _set_if_expression("W1tJU19FWElTVFNdXQ==");
			  _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
			  
				 
				 
				 /*Browser*/
				 ;_SELECTOR=VAR_HCAPTCHA_PREFIX + "\u003eCSS\u003eiframe";
				 get_element_selector(_SELECTOR, true).length()!
				 VAR_ALL_FRAMES_CAPTCHA = _result()
				 

			  })!
			  

			  
			  
			  /*Browser*/
			  ;_SELECTOR=VAR_HCAPTCHA_PREFIX + "\u003eCSS\u003eiframe\u003eAT\u003e" + VAR_FRAME_NUMBER_CAPTCHA;
			  get_element_selector(_SELECTOR, false).nowait().exist()!
			  VAR_IS_EXISTS = _result() == 1
			  

			  
			  
			  _set_if_expression("W1tJU19FWElTVFNdXQ==");
			  _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
			  
				 
				 
				 /*Browser*/
				 _SELECTOR = VAR_HCAPTCHA_PREFIX + "\u003eCSS\u003eiframe\u003eAT\u003e" + VAR_FRAME_NUMBER_CAPTCHA;
				 wait_element(_SELECTOR)!
				 get_element_selector(_SELECTOR, false).xml()!
				 VAR_IFRAME_XML_MODULE = _result()
				 

			  })!
			  

			  
			  
			  _set_if_expression("W1tJRlJBTUVfWE1MX01PRFVMRV1dLmluZGV4T2YoIi9zdGF0aWMvaGNhcHRjaGEuaHRtbCIpID49IDAgJiYgW1tJRlJBTUVfWE1MX01PRFVMRV1dLmluZGV4T2YoIiNmcmFtZT1jaGFsbGVuZ2UiKSA+PSAw");
			  _if(VAR_IFRAME_XML_MODULE.indexOf("/static/hcaptcha.html") >= 0 && VAR_IFRAME_XML_MODULE.indexOf("#frame=challenge") >= 0,function(){
			  
				 
				 
				 /*Browser*/
				 ;_SELECTOR=VAR_HCAPTCHA_PREFIX + "\u003eCSS\u003eiframe\u003eAT\u003e" + VAR_FRAME_NUMBER_CAPTCHA;
				 get_element_selector(_SELECTOR, false).nowait().exist()!
				 VAR_IS_EXISTS = _result() == 1
				 _if(VAR_IS_EXISTS, function(){
				 get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
				 VAR_IS_EXISTS = _result().indexOf("true")>=0
				 })!
				 

				 
				 
				 _set_if_expression("W1tJU19FWElTVFNdXQ==");
				 _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
				 
					
					
					/*Browser*/
					_SELECTOR = VAR_HCAPTCHA_PREFIX + "\u003eCSS\u003eiframe\u003eAT\u003e" + VAR_FRAME_NUMBER_CAPTCHA;
					wait_element(_SELECTOR)!
					get_element_selector(_SELECTOR, false).attr("title")!
					VAR_SAVED_ATTRIBUTE = _result()
					

					
					
					VAR_HCAPTCHA_PREFIX_SECOND_FRAME = VAR_HCAPTCHA_PREFIX + ">CSS>iframe[title=\"" + _result() + "\"]" + ">AT>" + VAR_NUMBER_CAPTCHA_MODULE + ">FRAME> >CSS> body";
					VAR_HCAPTCHA_PREFIX_SECOND_FRAME_ELEMENT = VAR_HCAPTCHA_PREFIX + ">CSS>iframe[title=\"" + _result() + "\"]" + ">AT>" + VAR_NUMBER_CAPTCHA_MODULE
					

					
					
					_break("function")
					

				 })!
				 

				 
				 
				 VAR_NUMBER_CAPTCHA_MODULE = parseInt(VAR_NUMBER_CAPTCHA_MODULE) + parseInt(1)
				 

			  })!
			  

			  
			  
			  _set_if_expression("W1tGUkFNRV9OVU1CRVJfQ0FQVENIQV1dID49IFtbQUxMX0ZSQU1FU19DQVBUQ0hBXV0gLSAx");
			  _if(VAR_FRAME_NUMBER_CAPTCHA >= VAR_ALL_FRAMES_CAPTCHA - 1,function(){
			  
				 
				 
				 VAR_FRAME_NUMBER_CAPTCHA = 0
				 

				 
				 
				 VAR_NUMBER_CAPTCHA_MODULE = 0
				 

				 
				 
				 _break("function")
				 

			  })!
			  

			  
			  
			  VAR_FRAME_NUMBER_CAPTCHA = parseInt(VAR_FRAME_NUMBER_CAPTCHA) + parseInt(1)
			  

		   })!
		   

		})!
		

		
		
		_if(!_cycle_params().if_else,function(){
		
		   
		   
		   /*Browser*/
		   ;_SELECTOR=VAR_HCAPTCHA_PREFIX_SECOND_FRAME_ELEMENT;
		   get_element_selector(_SELECTOR, false).nowait().exist()!
		   VAR_IS_EXISTS = _result() == 1
		   _if(VAR_IS_EXISTS, function(){
		   get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
		   VAR_IS_EXISTS = _result().indexOf("true")>=0
		   })!
		   

		   
		   
		   _set_if_expression("W1tJU19FWElTVFNdXSAmJiBbW1JFU1VMVF9TRUxFQ1RPUl1dICE9IDE=");
		   _if(VAR_IS_EXISTS,function(){
		   
			  
			  
			  _break("function")
			  

		   })!
		   

		})!
		delete _cycle_params().if_else;
		

		
		
		_set_if_expression("W1tXQUlUX0ZSQU1FX1RJTUVPVVRdXSA9PSAxNiB8fCBbW1dBSVRfRlJBTUVfVElNRU9VVF1dID09IDMy");
		_if(VAR_WAIT_FRAME_TIMEOUT == 16 || VAR_WAIT_FRAME_TIMEOUT == 32,function(){
		
		   
		   
		   sleep(rand(1000,3000))!
		   

		})!
		

		
		
		_set_if_expression("W1tXQUlUX0ZSQU1FX1RJTUVPVVRdXSA+PSAzMCAmJiBbW0ZJUlNUX0xPQURfQ0FQVENIQV1dID09IGZhbHNlICYmIFtbUkVTVUxUX1NFTEVDVE9SXV0gIT0gMQ==");
		_if(VAR_WAIT_FRAME_TIMEOUT >= 30 && VAR_FIRST_LOAD_CAPTCHA == false,function(){
		
		   
		   
		   /*Browser*/
		   cache_data_clear()!
		   

		   
		   
		   fail((_K==="en" ? "Failed to solve the hcaptcha. The captcha window is closed." : "Не удалось решить hcaptcha. Окно с капчей не было открыто."));
		   

		})!
		

		
		
		_set_if_expression("W1tXQUlUX0ZSQU1FX1RJTUVPVVRdXSA+IDQwICYmIFtbRklSU1RfTE9BRF9DQVBUQ0hBXV0gPT0gdHJ1ZSAmJiBbW1JFU1VMVF9TRUxFQ1RPUl1dICE9IDE=");
		_if(VAR_WAIT_FRAME_TIMEOUT > 40 && VAR_FIRST_LOAD_CAPTCHA == true,function(){
		
		   
		   
		   /*Browser*/
		   cache_data_clear()!
		   

		   
		   
		   fail((_K==="en" ? "Failed to solve hCaptcha. Timeout for opening captcha window with images" : "Не удалось решить hcaptcha, слишком долгое ожидание открытия окна каптчи с изображениями"));
		   

		})!
		

	 })!
	 

	 
	 
	 VAR_CYCLE_INDEX = 0
	 

	 
	 
	 VAR_WAIT_FRAME_TIMEOUT = 0
	 

	 
	 
	 VAR_FIRST_LOAD_BUTTON = false
	 

	 
	 
	 _set_if_expression("W1tHUkVFTl9USUNLXV0gPT0gdHJ1ZQ==");
	 _if(VAR_GREEN_TICK == true,function(){
	 
		
		
		VAR_IMAGE_BASE_64 = "\u0027\u0027"
		

		
		
		VAR_IMAGE_BASE_64_CACHE = "\u0027\u0027"
		

		
		
		_set_if_expression("W1tJU19MT0ddXSA9PSB0cnVl");
		_if(VAR_IS_LOG == true,function(){
		
		   
		   
		   _info((_K==="en" ? "Тест": "Каптча решена успешно"));
		   

		})!
		

		
		
		_function_return("")
		

	 })!
	 

	 
	 
	 VAR_TRY_CAPTCHA = parseInt(VAR_TRY_CAPTCHA) + parseInt(1)
	 

	 
	 
	 _set_if_expression("W1tUUllfQ0FQVENIQV1dID49IFtbVFJZX05VTUJFUl1d");
	 _if(VAR_TRY_CAPTCHA >= VAR_TRY_NUMBER,function(){
	 
		
		
		sleep(4000)!
		

		
		
		/*Browser*/
		;_SELECTOR=VAR_HCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e #checkbox[aria-checked=\u0027true\u0027]";
		get_element_selector(_SELECTOR, false).nowait().exist()!
		VAR_IS_EXISTS = _result() == 1
		_if(VAR_IS_EXISTS, function(){
		get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
		VAR_IS_EXISTS = _result().indexOf("true")>=0
		})!
		

		
		
		_cycle_params().if_else = VAR_IS_EXISTS == true;
		_set_if_expression("W1tJU19FWElTVFNdXSA9PSB0cnVlICYmIFtbUkVTVUxUX1NFTEVDVE9SXV0gIT0gMQ==");
		_if(_cycle_params().if_else,function(){
		
		   
		   
		   _set_if_expression("W1tDQUNIRV9ERUxFVEVdXSA9PSB0cnVl");
		   _if(VAR_CACHE_DELETE == true,function(){
		   
			  
			  
			  /*Browser*/
			  cache_data_clear()!
			  

		   })!
		   

		   
		   
		   _function_return("")
		   

		})!
		

		
		
		_if(!_cycle_params().if_else,function(){
		
		   
		   
		   /*Browser*/
		   cache_data_clear()!
		   

		})!
		delete _cycle_params().if_else;
		

		
		
		fail((_K==="en" ? "Failed to solve the captcha. hCaptcha attempts limit exceeded" : "Не удалось решить hСaptcha. Превышен лимит попыток решения этой каптчи"))
		

	 })!
	 

	 
	 
	 _call(function()
	 {
	 _on_fail(function(){
	 VAR_LAST_ERROR = _result()
	 VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
	 VAR_WAS_ERROR = false
	 _break(1,true)
	 })
	 CYCLES.Current().RemoveLabel("function")
	 
		
		
		_set_if_expression("W1tIQ0FQVENIQV9JTlZJU0lCTEVdXSA9PSAx");
		_if(VAR_HCAPTCHA_INVISIBLE == 1,function(){
		
		   
		   
		   VAR_CYCLE_INDEX = 0
		   

		   
		   
		   _do(function(){
		   _set_action_info({ name: "For" });
		   VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
		   if(VAR_CYCLE_INDEX > parseInt(60))_break();
		   
			  
			  
			  /*Browser*/
			  ;_SELECTOR=VAR_HCAPTCHA_PREFIX_SECOND_FRAME + "\u003eCSS\u003e .task-grid";
			  get_element_selector(_SELECTOR, false).nowait().exist()!
			  VAR_HCAPTCHA_TYPE_1 = _result() == 1
			  _if(VAR_HCAPTCHA_TYPE_1, function(){
			  get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
			  VAR_HCAPTCHA_TYPE_1 = _result().indexOf("true")>=0
			  })!
			  

			  
			  
			  /*Browser*/
			  ;_SELECTOR=VAR_HCAPTCHA_PREFIX_SECOND_FRAME + "\u003eCSS\u003e .bounding-box-example";
			  get_element_selector(_SELECTOR, false).nowait().exist()!
			  VAR_HCAPTCHA_TYPE_2 = _result() == 1
			  _if(VAR_HCAPTCHA_TYPE_2, function(){
			  get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
			  VAR_HCAPTCHA_TYPE_2 = _result().indexOf("true")>=0
			  })!
			  

			  
			  
			  /*Browser*/
			  ;_SELECTOR=VAR_HCAPTCHA_PREFIX_SECOND_FRAME + "\u003eCSS\u003e .task-answers";
			  get_element_selector(_SELECTOR, false).nowait().exist()!
			  VAR_HCAPTCHA_TYPE_3 = _result() == 1
			  _if(VAR_HCAPTCHA_TYPE_3, function(){
			  get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
			  VAR_HCAPTCHA_TYPE_3 = _result().indexOf("true")>=0
			  })!
			  

			  
			  
			  /*Browser*/
			  ;_SELECTOR=VAR_HCAPTCHA_PREFIX_SECOND_FRAME + "\u003eCSS\u003e canvas";
			  get_element_selector(_SELECTOR, false).nowait().exist()!
			  VAR_HCAPTCHA_TYPE_4 = _result() == 1
			  _if(VAR_HCAPTCHA_TYPE_4, function(){
			  get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
			  VAR_HCAPTCHA_TYPE_4 = _result().indexOf("true")>=0
			  })!
			  

			  
			  
			  _set_if_expression("W1tIQ0FQVENIQV9UWVBFXzFdXSA9PSB0cnVlIHx8IFtbSENBUFRDSEFfVFlQRV8yXV0gPT0gdHJ1ZSB8fCBbW0hDQVBUQ0hBX1RZUEVfM11dID09IHRydWUgfHwgW1tIQ0FQVENIQV9UWVBFXzRdXSA9PSB0cnVl");
			  _if(VAR_HCAPTCHA_TYPE_1 == true || VAR_HCAPTCHA_TYPE_2 == true || VAR_HCAPTCHA_TYPE_3 == true || VAR_HCAPTCHA_TYPE_4 == true,function(){
			  
				 
				 
				 _break("function")
				 

			  })!
			  

			  
			  
			  _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gNTA=");
			  _if(VAR_CYCLE_INDEX > 50,function(){
			  
				 
				 
				 VAR_ERROR_LOAD = 1
				 

			  })!
			  

			  
			  
			  sleep(rand(200,600))!
			  

		   })!
		   

		   
		   
		   _set_if_expression("W1tFUlJPUl9MT0FEXV0gPT0gMQ==");
		   _if(VAR_ERROR_LOAD == 1,function(){
		   
			  
			  
			  _next("function")
			  

		   })!
		   

		})!
		

		
		
		_set_if_expression("W1tIQ0FQVENIQV9JTlZJU0lCTEVdXSA9PSAwIHx8IFtbSENBUFRDSEFfSU5WSVNJQkxFXV0gPiAx");
		_if(VAR_HCAPTCHA_INVISIBLE == 0 || VAR_HCAPTCHA_INVISIBLE > 1,function(){
		
		   
		   
		   VAR_CYCLE_INDEX = 0
		   

		   
		   
		   /*Browser*/
		   ;_SELECTOR=VAR_HCAPTCHA_PREFIX_SECOND_FRAME_ELEMENT;
		   get_element_selector(_SELECTOR, false).nowait().exist()!
		   VAR_IS_EXISTS = _result() == 1
		   _if(VAR_IS_EXISTS, function(){
		   get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
		   VAR_IS_EXISTS = _result().indexOf("true")>=0
		   })!
		   

		   
		   
		   _cycle_params().if_else = typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined;
		   _set_if_expression("W1tJU19FWElTVFNdXQ==");
		   _if(_cycle_params().if_else,function(){
		   
			  
			  
			  VAR_HCAPTCHA_CLOSED = 0
			  

			  
			  
			  _do(function(){
			  _set_action_info({ name: "For" });
			  VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
			  if(VAR_CYCLE_INDEX > parseInt(20))_break();
			  
				 
				 
				 /*Browser*/
				 is_load("*img*hcaptcha.com/*")!
				 VAR_SAVED_IS_IMAGE = _result()
				 

				 
				 
				 /*Browser*/
				 is_load("*hcaptcha.com/getcaptcha*")!
				 VAR_SAVED_IS_TASK = _result()
				 

				 
				 
				 _set_if_expression("W1tJU19MT0ddXSA9PSB0cnVl");
				 _if(VAR_IS_LOG == true,function(){
				 
					
					
					_info((_K==="en" ? "Тест": "Ждём загрузки картинок url *img*hcaptcha.com/*. Статус - : "+ VAR_SAVED_IS_IMAGE + " Ждём когда загрузится url для заданий *hcaptcha.com/getcaptcha*. Статус - : " + VAR_SAVED_IS_TASK));
					

				 })!
				 

				 
				 
				 _set_if_expression("W1tTQVZFRF9JU19JTUFHRV1dID09IDEgJiYgW1tTQVZFRF9JU19UQVNLXV0gPT0gMSAmJiBbW05VTUJFUl9DUlVNQl1dID09IDA=");
				 _if(VAR_SAVED_IS_IMAGE == 1 && VAR_SAVED_IS_TASK == 1 && VAR_NUMBER_CRUMB == 0,function(){
				 
					
					
					_set_if_expression("W1tJU19MT0ddXSA9PSB0cnVl");
					_if(VAR_IS_LOG == true,function(){
					
					   
					   
					   _info((_K==="en" ? "Тест": "Дождались загрузки картинок url *img*hcaptcha.com/*. Статус - : "+ VAR_SAVED_IS_IMAGE + " Дождались загрузки url для заданий *hcaptcha.com/getcaptcha*. Статус - : " + VAR_SAVED_IS_TASK));
					   

					})!
					

					
					
					_break("function")
					

				 })!
				 

				 
				 
				 _set_if_expression("W1tTQVZFRF9JU19JTUFHRV1dID09IDEgJiYgW1tOVU1CRVJfQ1JVTUJdXSA+IDA=");
				 _if(VAR_SAVED_IS_IMAGE == 1 && VAR_NUMBER_CRUMB > 0,function(){
				 
					
					
					_set_if_expression("W1tJU19MT0ddXSA9PSB0cnVl");
					_if(VAR_IS_LOG == true,function(){
					
					   
					   
					   _info((_K==="en" ? "Тест": "Ждём загрузки картинок url *img*hcaptcha.com/*. Статус - : "+ VAR_SAVED_IS_IMAGE + " Ждём когда загрузится url для заданий *hcaptcha.com/getcaptcha*. Статус - : " + VAR_SAVED_IS_TASK));
					   

					})!
					

					
					
					_break("function")
					

				 })!
				 

				 
				 
				 sleep(100)!
				 

				 
				 
				 _set_if_expression("W1tDWUNMRV9JTkRFWF1dID09IDE5");
				 _if(VAR_CYCLE_INDEX == 19,function(){
				 
					
					
					_set_if_expression("W1tJU19MT0ddXSA9PSB0cnVl");
					_if(VAR_IS_LOG == true,function(){
					
					   
					   
					   _info((_K==="en" ? "Тест": "Не удалось дождатся загрузки *hcaptcha.com/getcaptcha* или *img*hcaptcha.com/*. Возвращаемя в цикл проверить открыта ли капча и есть уже галка, а также проверить другие ошибки "));
					   

					})!
					

					
					
					VAR_HCAPTCHA_CLOSED = 1
					

					
					
					_break("function")
					

				 })!
				 

			  })!
			  

		   })!
		   

		   
		   
		   _if(!_cycle_params().if_else,function(){
		   
			  
			  
			  VAR_HCAPTCHA_CLOSED = 1
			  

		   })!
		   delete _cycle_params().if_else;
		   

		   
		   
		   _set_if_expression("W1tIQ0FQVENIQV9DTE9TRURdXSA9PSAw");
		   _if(VAR_HCAPTCHA_CLOSED == 0,function(){
		   
			  
			  
			  /*Browser*/
			  ;_SELECTOR=VAR_HCAPTCHA_PREFIX_SECOND_FRAME_ELEMENT;
			  get_element_selector(_SELECTOR, false).nowait().exist()!
			  VAR_IS_EXISTS = _result() == 1
			  _if(VAR_IS_EXISTS, function(){
			  get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
			  VAR_IS_EXISTS = _result().indexOf("true")>=0
			  })!
			  

			  
			  
			  _set_if_expression("IVtbSVNfRVhJU1RTXV0=");
			  _if(!VAR_IS_EXISTS,function(){
			  
				 
				 
				 VAR_HCAPTCHA_CLOSED = 1
				 

				 
				 
				 _break("function")
				 

			  })!
			  

			  
			  
			  _do(function(){
			  _set_action_info({ name: "For" });
			  VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
			  if(VAR_CYCLE_INDEX > parseInt(100))_break();
			  
				 
				 
				 /*Browser*/
				 ;_SELECTOR=VAR_HCAPTCHA_PREFIX_SECOND_FRAME_ELEMENT;
				 get_element_selector(_SELECTOR, false).nowait().exist()!
				 VAR_IS_EXISTS = _result() == 1
				 _if(VAR_IS_EXISTS, function(){
				 get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
				 VAR_IS_EXISTS = _result().indexOf("true")>=0
				 })!
				 

				 
				 
				 _set_if_expression("IVtbSVNfRVhJU1RTXV0=");
				 _if(!VAR_IS_EXISTS,function(){
				 
					
					
					VAR_HCAPTCHA_CLOSED = 1
					

					
					
					_break("function")
					

				 })!
				 

				 
				 
				 cache_get_base64("*img*hcaptcha.com/*")!
				 var image_id = native("imageprocessing", "load", _result())
				 var image_size = native("imageprocessing", "getsize", image_id)
				 var image_w = parseInt(image_size.split(",")[0])
				 var image_h = parseInt(image_size.split(",")[1])
				 if (VAR_IS_LOG === true) _info((_K==="en" ? "Тест": "Проверяем, что картинка загрузилась не битой. Текущий размер. Высота: "+ image_h +". Ширина: "+image_w));
				 if (image_h < 1 && VAR_CYCLE_INDEX > rand (45,55)) fail((_K === "en" ? "Failed to wait for hCaptcha image from request cache" : "Не удалось дождаться картинку hCaptcha из кэша запроса"))
				 if (image_h > 0) {
				 VAR_IMAGE_BASE_64_CACHE = _result()
				 _break()
				 }
				 sleep(400)!
				 

			  })!
			  

		   })!
		   

		})!
		

	 },null)!
	 

	 
	 
	 _set_if_expression("W1tIQ0FQVENIQV9DTE9TRURdXSA9PSAx");
	 _if(VAR_HCAPTCHA_CLOSED == 1,function(){
	 
		
		
		sleep(1000)!
		

		
		
		_set_if_expression("cmFuZCAoMSwxMCkgPiAy");
		_if(rand (1,10) > 2,function(){
		
		   
		   
		   VAR_TRY_CAPTCHA = parseInt(VAR_TRY_CAPTCHA) + parseInt(-1)
		   

		})!
		

		
		
		_next("function")
		

	 })!
	 

	 
	 
	 _set_if_expression("W1tXQVNfRVJST1JdXQ==");
	 _if(typeof(VAR_WAS_ERROR) !== "undefined" ? (VAR_WAS_ERROR) : undefined,function(){
	 
		
		
		_set_if_expression("W1tMQVNUX0VSUk9SXV0gPT09ICdBYm9ydGVkIEJ5IFVzZXInIHx8IFtbTEFTVF9FUlJPUl1dICA9PT0gJ9Cf0YDQtdGA0LLQsNC90L4g0J/QvtC70YzQt9C+0LLQsNGC0LXQu9C10Lwn");
		_if(VAR_LAST_ERROR === 'Aborted By User' || VAR_LAST_ERROR  === 'Прервано Пользователем',function(){
		
		   
		   
		   _function_return(false)
		   

		})!
		

		
		
		sleep(rand(1000,3000))!
		

		
		
		/*Browser*/
		;_SELECTOR=VAR_HCAPTCHA_PREFIX_SECOND_FRAME_ELEMENT;
		get_element_selector(_SELECTOR, false).nowait().exist()!
		VAR_IS_EXISTS = _result() == 1
		

		
		
		_set_if_expression("IVtbSVNfRVhJU1RTXV0=");
		_if(!VAR_IS_EXISTS,function(){
		
		   
		   
		   VAR_HCAPTCHA_CLOSED = "1"
		   

		})!
		

		
		
		_set_if_expression("W1tIQ0FQVENIQV9DTE9TRURdXSA9PSAw");
		_if(VAR_HCAPTCHA_CLOSED == 0,function(){
		
		   
		   
		   _call(function()
		   {
		   _on_fail(function(){
		   VAR_LAST_ERROR = _result()
		   VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
		   VAR_WAS_ERROR = false
		   _break(1,true)
		   })
		   CYCLES.Current().RemoveLabel("function")
		   
			  
			  
			  /*Browser*/
			  ;_SELECTOR=VAR_HCAPTCHA_PREFIX_SECOND_FRAME + "\u003eCSS\u003e .refresh";
			  get_element_selector(_SELECTOR, false).nowait().exist()!
			  VAR_IS_EXISTS = _result() == 1
			  _if(VAR_IS_EXISTS, function(){
			  get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
			  VAR_IS_EXISTS = _result().indexOf("true")>=0
			  })!
			  

			  
			  
			  _set_if_expression("W1tJU19FWElTVFNdXQ==");
			  _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
			  
				 
				 
				 /*Browser*/
				 cache_data_clear()!
				 

				 
				 
				 VAR_NUMBER_CRUMB = "0"
				 

				 
				 
				 VAR_HCAPTCHA_INVISIBLE = parseInt(VAR_HCAPTCHA_INVISIBLE) + parseInt(2)
				 

				 
				 
				 /*Browser*/
				 _SELECTOR = VAR_HCAPTCHA_PREFIX_SECOND_FRAME + "\u003eCSS\u003e .refresh";
				 wait_element_visible(_SELECTOR)!
				 _call(_random_point, {})!
				 _if(_result().length > 0, function(){
				 move( {} )!
				 get_element_selector(_SELECTOR, false).clarify(X,Y)!
				 _call(_clarify, {} )!
				 mouse(X,Y)!
				 })!
				 

			  })!
			  

		   },null)!
		   

		})!
		

		
		
		VAR_HCAPTCHA_INVISIBLE = parseInt(VAR_HCAPTCHA_INVISIBLE) + parseInt(2)
		

		
		
		VAR_HCAPTCHA_CLOSED = "2"
		

		
		
		sleep(1000)!
		

	 })!
	 

	 
	 
	 _call(function()
	 {
	 _on_fail(function(){
	 VAR_LAST_ERROR = _result()
	 VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
	 VAR_WAS_ERROR = false
	 _break(1,true)
	 })
	 CYCLES.Current().RemoveLabel("function")
	 
		
		
		_set_if_expression("W1tIQ0FQVENIQV9DTE9TRURdXSA9PSAw");
		_if(VAR_HCAPTCHA_CLOSED == 0,function(){
		
		   
		   
		   /*Browser*/
		   ;_SELECTOR=VAR_HCAPTCHA_PREFIX_SECOND_FRAME_ELEMENT + " \u003eFRAME\u003e \u003eCSS\u003e div.task-grid \u003e div[tabindex=\u0027-1\u0027]";
		   get_element_selector(_SELECTOR, false).nowait().exist()!
		   VAR_IS_EXISTS = _result() == 1
		   _if(VAR_IS_EXISTS, function(){
		   get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
		   VAR_IS_EXISTS = _result().indexOf("true")>=0
		   })!
		   

		   
		   
		   _set_if_expression("W1tJU19FWElTVFNdXQ==");
		   _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
		   
			  
			  
			  VAR_HCAPTCHA_CLOSED = "2"
			  

		   })!
		   

		})!
		

	 },null)!
	 

	 
	 
	 _set_if_expression("W1tIQ0FQVENIQV9DTE9TRURdXSA9PSAxIHx8IFtbSENBUFRDSEFfQ0xPU0VEXV0gPT0gMg==");
	 _if(VAR_HCAPTCHA_CLOSED == 1 || VAR_HCAPTCHA_CLOSED == 2,function(){
	 
		
		
		VAR_HCAPTCHA_CLOSED = "0"
		

		
		
		sleep(1000)!
		

		
		
		_next("function")
		

	 })!
	 

	 
	 
	 _call(function()
	 {
	 _on_fail(function(){
	 VAR_LAST_ERROR = _result()
	 VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
	 VAR_WAS_ERROR = false
	 _break(1,true)
	 })
	 CYCLES.Current().RemoveLabel("function")
	 
		
		
		_set_if_expression("W1tOVU1CRVJfQ1JVTUJdXSA9PSAw");
		_if(VAR_NUMBER_CRUMB == 0,function(){
		
		   
		   
		   _set_if_expression("W1tJU19MT0ddXSA9PSB0cnVl");
		   _if(VAR_IS_LOG == true,function(){
		   
			  
			  
			  _info((_K==="en" ? "Тест": "Ждём появления кнопки Submit"));
			  

		   })!
		   

		   
		   
		   /*Browser*/
		   _SELECTOR = VAR_HCAPTCHA_PREFIX_SECOND_FRAME + "\u003eCSS\u003e .button-submit";
		   wait_element_visible(_SELECTOR)!
		   

		   
		   
		   /*Browser*/
		   ;_SELECTOR=VAR_HCAPTCHA_PREFIX_SECOND_FRAME + "\u003eCSS\u003e div[aria-label*=\u00279\u0027]";
		   get_element_selector(_SELECTOR, false).nowait().exist()!
		   VAR_HCAPTCHA_TYPE_1 = _result() == 1
		   _if(VAR_HCAPTCHA_TYPE_1, function(){
		   get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
		   VAR_HCAPTCHA_TYPE_1 = _result().indexOf("true")>=0
		   })!
		   

		   
		   
		   /*Browser*/
		   ;_SELECTOR=VAR_HCAPTCHA_PREFIX_SECOND_FRAME + "\u003eCSS\u003e .bounding-box-example";
		   get_element_selector(_SELECTOR, false).nowait().exist()!
		   VAR_HCAPTCHA_TYPE_2 = _result() == 1
		   _if(VAR_HCAPTCHA_TYPE_2, function(){
		   get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
		   VAR_HCAPTCHA_TYPE_2 = _result().indexOf("true")>=0
		   })!
		   

		   
		   
		   /*Browser*/
		   ;_SELECTOR=VAR_HCAPTCHA_PREFIX_SECOND_FRAME + "\u003eCSS\u003e .task-answers";
		   get_element_selector(_SELECTOR, false).nowait().exist()!
		   VAR_HCAPTCHA_TYPE_3 = _result() == 1
		   _if(VAR_HCAPTCHA_TYPE_3, function(){
		   get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
		   VAR_HCAPTCHA_TYPE_3 = _result().indexOf("true")>=0
		   })!
		   

		   
		   
		   _set_if_expression("W1tIQ0FQVENIQV9UWVBFXzJdXSA9PSBmYWxzZQ==");
		   _if(VAR_HCAPTCHA_TYPE_2 == false,function(){
		   
			  
			  
			  /*Browser*/
			  ;_SELECTOR=VAR_HCAPTCHA_PREFIX_SECOND_FRAME + "\u003eCSS\u003e canvas";
			  get_element_selector(_SELECTOR, false).nowait().exist()!
			  VAR_HCAPTCHA_TYPE_4 = _result() == 1
			  _if(VAR_HCAPTCHA_TYPE_4, function(){
			  get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
			  VAR_HCAPTCHA_TYPE_4 = _result().indexOf("true")>=0
			  })!
			  

		   })!
		   

		   
		   
		   _set_if_expression("W1tIQ0FQVENIQV9UWVBFXzFdXSA9PSB0cnVlICYmIFtbSVNfQ0hBTkdFRF9IQ0FQVEhBXV0gIT0gIkhDQVBUQ0hBX1RZUEVfMSIgfHwgW1tIQ0FQVENIQV9UWVBFXzJdXSA9PSB0cnVlICYmIFtbSVNfQ0hBTkdFRF9IQ0FQVEhBXV0gIT0gIkhDQVBUQ0hBX1RZUEVfMiIgfHwgW1tIQ0FQVENIQV9UWVBFXzNdXSA9PSB0cnVlICYmIFtbSVNfQ0hBTkdFRF9IQ0FQVEhBXV0gIT0gIkhDQVBUQ0hBX1RZUEVfMyIgfHwgW1tIQ0FQVENIQV9UWVBFXzRdXSA9PSB0cnVlICYmIFtbSVNfQ0hBTkdFRF9IQ0FQVEhBXV0gIT0gIkhDQVBUQ0hBX1RZUEVfNCI=");
		   _if(VAR_HCAPTCHA_TYPE_1 == true && VAR_IS_CHANGED_HCAPTHA != "HCAPTCHA_TYPE_1" || VAR_HCAPTCHA_TYPE_2 == true && VAR_IS_CHANGED_HCAPTHA != "HCAPTCHA_TYPE_2" || VAR_HCAPTCHA_TYPE_3 == true && VAR_IS_CHANGED_HCAPTHA != "HCAPTCHA_TYPE_3" || VAR_HCAPTCHA_TYPE_4 == true && VAR_IS_CHANGED_HCAPTHA != "HCAPTCHA_TYPE_4",function(){
		   
			  
			  
			  _set_if_expression("W1tJU19MT0ddXSA9PSB0cnVl");
			  _if(VAR_IS_LOG == true,function(){
			  
				 
				 
				 _info((_K==="en" ? "Тест": "Изменился тип каптчи"));
				 

			  })!
			  

			  
			  
			  VAR_GET_ALL_COORDINATES = 0
			  

		   })!
		   

		   
		   
		   _set_if_expression("W1tIQ0FQVENIQV9UWVBFXzFdXSA9PSB0cnVl");
		   _if(VAR_HCAPTCHA_TYPE_1 == true,function(){
		   
			  
			  
			  VAR_UNKNOWN_CAPTCHA = 0
			  

			  
			  
			  VAR_IS_CHANGED_HCAPTHA = "HCAPTCHA_TYPE_1"
			  VAR_TYPE_TASK = "grid"
				
			  

			  
			  
			  _set_if_expression("W1tJU19MT0ddXSA9PSB0cnVl");
			  _if(VAR_IS_LOG == true,function(){
			  
				 
				 
				 _info((_K==="en" ? "Тест": "Каптча получена. Тип каптчи: 9 квадратов с сеткой 3x3"));
				 

			  })!
			  

		   })!
		   

		   
		   
		   _set_if_expression("W1tIQ0FQVENIQV9UWVBFXzJdXSA9PSB0cnVl");
		   _if(VAR_HCAPTCHA_TYPE_2 == true,function(){
		   
			  
			  
			  VAR_UNKNOWN_CAPTCHA = 0
			  

			  
			  
			  VAR_HCAPTCHA_TYPE_4 = false
			  

			  
			  
			  VAR_IS_CHANGED_HCAPTHA = "HCAPTCHA_TYPE_2"
			  VAR_TYPE_TASK = "canvas"
			  

			  
			  
			  _set_if_expression("W1tJU19MT0ddXSA9PSB0cnVl");
			  _if(VAR_IS_LOG == true,function(){
			  
				 
				 
				 _info((_K==="en" ? "Тест": "Каптча получена. Тип каптчи: Изображение Canvas с подсказками"));
				 

			  })!
			  

		   })!
		   

		   
		   
		   _set_if_expression("W1tIQ0FQVENIQV9UWVBFXzNdXSA9PSB0cnVl");
		   _if(VAR_HCAPTCHA_TYPE_3 == true,function(){
		   
			  
			  
			  VAR_UNKNOWN_CAPTCHA = 0
			  

			  
			  
			  VAR_IS_CHANGED_HCAPTHA = "HCAPTCHA_TYPE_3"
			  VAR_TYPE_TASK = "content"
			  

			  
			  
			  _set_if_expression("W1tJU19MT0ddXSA9PSB0cnVl");
			  _if(VAR_IS_LOG == true,function(){
			  
				 
				 
				 _info((_K==="en" ? "Тест": "Каптча получена. Тип каптчи: Выберите правильный ответ из нескольких предложенных справа"));
				 

			  })!
			  

		   })!
		   

		   
		   
		   _set_if_expression("W1tIQ0FQVENIQV9UWVBFXzRdXSA9PSB0cnVl");
		   _if(VAR_HCAPTCHA_TYPE_4 == true,function(){
		   
			  
			  
			  VAR_UNKNOWN_CAPTCHA = 0
			  

			  
			  
			  VAR_IS_CHANGED_HCAPTHA = "HCAPTCHA_TYPE_4"
			  VAR_TYPE_TASK = "canvas"
			  

			  
			  
			  _set_if_expression("W1tJU19MT0ddXSA9PSB0cnVl");
			  _if(VAR_IS_LOG == true,function(){
			  
				 
				 
				 _info((_K==="en" ? "Тест": "Каптча получена. Тип каптчи: Изображение Canvas без подсказок"));
				 

			  })!
			  

		   })!
		   

		   
		   
		   _set_if_expression("W1tIQ0FQVENIQV9UWVBFXzFdXSA9PSBmYWxzZSAmJiBbW0hDQVBUQ0hBX1RZUEVfMl1dID09IGZhbHNlICYmIFtbSENBUFRDSEFfVFlQRV8zXV0gPT0gZmFsc2UgJiYgW1tIQ0FQVENIQV9UWVBFXzRdXSA9PSBmYWxzZQ==");
		   _if(VAR_HCAPTCHA_TYPE_1 == false && VAR_HCAPTCHA_TYPE_2 == false && VAR_HCAPTCHA_TYPE_3 == false && VAR_HCAPTCHA_TYPE_4 == false,function(){
		   
			  
			  
			  VAR_UNKNOWN_CAPTCHA = parseInt(VAR_UNKNOWN_CAPTCHA) + parseInt(1)
			  

		   })!
		   

		})!
		

	 },null)!
	 

	 
	 
	 _set_if_expression("W1tXQVNfRVJST1JdXQ==");
	 _if(typeof(VAR_WAS_ERROR) !== "undefined" ? (VAR_WAS_ERROR) : undefined,function(){
	 
		
		
		_set_if_expression("W1tMQVNUX0VSUk9SXV0gPT09ICdBYm9ydGVkIEJ5IFVzZXInIHx8IFtbTEFTVF9FUlJPUl1dICA9PT0gJ9Cf0YDQtdGA0LLQsNC90L4g0J/QvtC70YzQt9C+0LLQsNGC0LXQu9C10Lwn");
		_if(VAR_LAST_ERROR === 'Aborted By User' || VAR_LAST_ERROR  === 'Прервано Пользователем',function(){
		
		   
		   
		   _function_return(false)
		   

		})!
		

		
		
		/*Browser*/
		cache_data_clear()!
		

		
		
		fail(VAR_LAST_ERROR)
		

	 })!
	 

	 
	 
	 _set_if_expression("W1tVTktOT1dOX0NBUFRDSEFdXSA+IDA=");
	 _if(VAR_UNKNOWN_CAPTCHA > 0,function(){
	 
		
		
		sleep(2000)!
		

		
		
		_next("function")
		

	 })!
	 

	 
	 
	 _call(function()
	 {
	 _on_fail(function(){
	 VAR_LAST_ERROR = _result()
	 VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
	 VAR_WAS_ERROR = false
	 _break(1,true)
	 })
	 CYCLES.Current().RemoveLabel("function")
	 
		
		
		_set_if_expression("KFtbSENBUFRDSEFfVFlQRV8yXV0gPT0gdHJ1ZSB8fCBbW0hDQVBUQ0hBX1RZUEVfM11dID09IHRydWUgfHwgW1tIQ0FQVENIQV9UWVBFXzRdXSA9PSB0cnVlKSAmJiBbW0hDQVBUQ0hBX0lOVklTSUJMRV1dICE9IDE=");
		_if((VAR_HCAPTCHA_TYPE_2 == true || VAR_HCAPTCHA_TYPE_3 == true || VAR_HCAPTCHA_TYPE_4 == true) && VAR_HCAPTCHA_INVISIBLE != 1,function(){
		
		   
		   
		   _set_if_expression("W1tJU19MT0ddXSA9PSB0cnVl");
		   _if(VAR_IS_LOG == true,function(){
		   
			  
			  
			  _info((_K==="en" ? "Тест": "Парсим весь кэш"));
			  

		   })!
		   

		   
		   
		   VAR_ALL_HCAPTCHA_IMAGE_LIST_COUNT = 0
		   

		   
		   
		   VAR_CHECK_EMPTY_BODY = ""
		   

		   
		   
		   VAR_LIST_ELEMENT_BAS_MODULE = ""
		   

		   
		   
		   VAR_ALL_HCAPTCHA_IMAGE_LIST = ""
		   

		   
		   
		   VAR_HCAPTCHA_MAIN_PICTRURE_SIZE = 0
		   

		   
		   
		   _do(function(){
		   _set_action_info({ name: "For" });
		   VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
		   if(VAR_CYCLE_INDEX > parseInt(125))_break();
		   
			  
			  
			  _set_if_expression("W1tBTExfSENBUFRDSEFfSU1BR0VfTElTVF9DT1VOVF1dID09IDA=");
			  _if(VAR_ALL_HCAPTCHA_IMAGE_LIST_COUNT == 0,function(){
			  
				 
				 
				 /*Browser*/
				 _cache_get_all("*img*hcaptcha.com/*")!
				 VAR_ALL_HCAPTCHA_IMAGE_LIST = JSON.parse(_result())
				 

			  })!
			  

			  
			  
			  VAR_ALL_HCAPTCHA_IMAGE_LIST_COUNT = (VAR_ALL_HCAPTCHA_IMAGE_LIST).length
			  

			  
			  
			  _cycle_params().if_else = VAR_ALL_HCAPTCHA_IMAGE_LIST_COUNT > 0;
			  _set_if_expression("W1tBTExfSENBUFRDSEFfSU1BR0VfTElTVF9DT1VOVF1dID4gMA==");
			  _if(_cycle_params().if_else,function(){
			  
				 
				 
				 VAR_LIST_ELEMENT_BAS_MODULE = (VAR_ALL_HCAPTCHA_IMAGE_LIST)[0];
				 VAR_ALL_HCAPTCHA_IMAGE_LIST.splice(0,1)
				 

				 
				 
				 /// Ищем картинку в каждом элементе кэша
				 if (VAR_LIST_ELEMENT_BAS_MODULE.hasOwnProperty("body")) VAR_CHECK_EMPTY_BODY = VAR_LIST_ELEMENT_BAS_MODULE.body
				 if (VAR_CHECK_EMPTY_BODY != '') {
				 var image_id = native("imageprocessing", "load", VAR_CHECK_EMPTY_BODY)
				 var image_size = native("imageprocessing", "getsize", image_id)
				 var image_w = parseInt(image_size.split(",")[0])
				 var image_h = parseInt(image_size.split(",")[1])
				 if (VAR_IS_LOG === true) _info((_K==="en" ? "Тест": "Проверяем, что основная большая картинка загрузилась не битой. Текущий размер. Высота: "+ image_h +". Ширина: "+image_w));
				 if (image_h <= 160 && VAR_CYCLE_INDEX > rand (45,55)) fail((_K === "en" ? "Failed to wait for hCaptcha image from request cache" : "Не удалось дождаться картинку hCaptcha из кэша запроса"))
				 VAR_HCAPTCHA_MAIN_PICTRURE_SIZE = image_h;
				 }
				 else sleep(400)!
				 

			  })!
			  

			  
			  
			  _if(!_cycle_params().if_else,function(){
			  
				 
				 
				 sleep(rand(300,500))!
				 

			  })!
			  delete _cycle_params().if_else;
			  

			  
			  
			  _set_if_expression("KFtbSENBUFRDSEFfVFlQRV8yXV0gPT0gdHJ1ZSB8fCBbW0hDQVBUQ0hBX1RZUEVfNF1dID09IHRydWUpICYmIFtbSENBUFRDSEFfTUFJTl9QSUNUUlVSRV9TSVpFXV0gPj0gMjAw");
			  _if((VAR_HCAPTCHA_TYPE_2 == true || VAR_HCAPTCHA_TYPE_4 == true) && VAR_HCAPTCHA_MAIN_PICTRURE_SIZE >= 200,function(){
			  
				 
				 
				 VAR_ALL_HCAPTCHA_IMAGE_LIST = ""
				 

				 
				 
				 _break("function")
				 

			  })!
			  

			  
			  
			  _set_if_expression("W1tIQ0FQVENIQV9UWVBFXzNdXSA9PSB0cnVlICYmIFtbSENBUFRDSEFfTUFJTl9QSUNUUlVSRV9TSVpFXV0gPiAxMDA=");
			  _if(VAR_HCAPTCHA_TYPE_3 == true && VAR_HCAPTCHA_MAIN_PICTRURE_SIZE > 100,function(){
			  
				 
				 
				 VAR_ALL_HCAPTCHA_IMAGE_LIST = ""
				 

				 
				 
				 _break("function")
				 

			  })!
			  

		   })!
		   

		   
		   
		   _set_if_expression("W1tIQ0FQVENIQV9UWVBFXzJdXSA9PSB0cnVlIHx8IFtbSENBUFRDSEFfVFlQRV80XV0gPT0gdHJ1ZQ==");
		   _if(VAR_HCAPTCHA_TYPE_2 == true || VAR_HCAPTCHA_TYPE_4 == true,function(){
		   
			  
			  
			  /*Browser*/
			  ;_SELECTOR=VAR_HCAPTCHA_PREFIX_SECOND_FRAME_ELEMENT + " \u003eFRAME\u003e \u003eCSS\u003e canvas";
			  get_element_selector(_SELECTOR, false).nowait().exist()!
			  VAR_IS_EXISTS = _result() == 1
			  _if(VAR_IS_EXISTS, function(){
			  get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
			  VAR_IS_EXISTS = _result().indexOf("true")>=0
			  })!
			  

			  
			  
			  _set_if_expression("IVtbSVNfRVhJU1RTXV0=");
			  _if(!VAR_IS_EXISTS,function(){
			  
				 
				 
				 sleep(rand(1000,4000))!
				 

				 
				 
				 _next("function")
				 

			  })!
			  

		   })!
		   

		})!
		

	 },null)!
	 

	 
	 
	 _set_if_expression("W1tXQVNfRVJST1JdXQ==");
	 _if(typeof(VAR_WAS_ERROR) !== "undefined" ? (VAR_WAS_ERROR) : undefined,function(){
	 
		
		
		_set_if_expression("W1tMQVNUX0VSUk9SXV0gPT09ICdBYm9ydGVkIEJ5IFVzZXInIHx8IFtbTEFTVF9FUlJPUl1dICA9PT0gJ9Cf0YDQtdGA0LLQsNC90L4g0J/QvtC70YzQt9C+0LLQsNGC0LXQu9C10Lwn");
		_if(VAR_LAST_ERROR === 'Aborted By User' || VAR_LAST_ERROR  === 'Прервано Пользователем',function(){
		
		   
		   
		   _function_return(false)
		   

		})!
		

		
		
		/*Browser*/
		cache_data_clear()!
		

		
		
		fail(VAR_LAST_ERROR)
		

	 })!
	 

	 
	 
	 _call(function()
	 {
	 _on_fail(function(){
	 VAR_LAST_ERROR = _result()
	 VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
	 VAR_WAS_ERROR = false
	 _break(1,true)
	 })
	 CYCLES.Current().RemoveLabel("function")
	 
		
		
		_get_browser_screen_settings()!
		;(function(){
		var result = JSON.parse(_result())
		VAR_SCROLL_X = result["ScrollX"]
		VAR_SCROLL_Y = result["ScrollY"]
		VAR_CURSOR_X = result["CursorX"]
		VAR_CURSOR_Y = result["CursorY"]
		VAR_CURSOR_ABSOLUTE_X = result["CursorX"] + result["ScrollX"]
		VAR_CURSOR_ABSOLUTE_Y = result["CursorY"] + result["ScrollY"]
		VAR_BROWSER_WIDTH = result["Width"]
		VAR_BROWSER_HEIGHT = result["Height"]
		})();
		

		
		
		_set_if_expression("W1tHRVRfQUxMX0NPT1JESU5BVEVTXV0gPT0gMCB8fCAhKFtbSVNfQ0hBTkdFRF9TQ1JPTExfWV1dIDw9IFtbU0NST0xMX1ldXSArIDQgJiYgW1tJU19DSEFOR0VEX1NDUk9MTF9ZXV0gPj0gW1tTQ1JPTExfWV1dIC0gNCk=");
		_if(VAR_GET_ALL_COORDINATES == 0 || !(VAR_IS_CHANGED_SCROLL_Y <= VAR_SCROLL_Y + 4 && VAR_IS_CHANGED_SCROLL_Y >= VAR_SCROLL_Y - 4),function(){
		
		   
		   
		   _set_if_expression("W1tJU19MT0ddXSA9PSB0cnVl");
		   _if(VAR_IS_LOG == true,function(){
		   
			  
			  
			  _info((_K==="en" ? "Тест": "Получаем координаты для всех кнопок капчи"));
			  

		   })!
		   

		   
		   
		   VAR_IS_CHANGED_SCROLL_Y = VAR_SCROLL_Y
		   

		   
		   
		   VAR_ELEMENT_SELECTOR = VAR_HCAPTCHA_PREFIX_SECOND_FRAME + "\u003eCSS\u003e .refresh"
		   

		   
		   
		   _SELECTOR = VAR_ELEMENT_SELECTOR;
		   get_element_selector(_SELECTOR, false).script("(function(){var rect = _BAS_HIDE(BrowserAutomationStudio_GetBoundingClientRect)(self);return (rect.left + positionx) + '|' + (rect.top + positiony) + '|' + (rect.right - rect.left) + '|' + (rect.bottom - rect.top)})();")!
		   var split = _result().split("|");
		   var x = parseInt(split[0]), y = parseInt(split[1]), w = parseInt(split[2]), h = parseInt(split[3]);
		   _get_browser_screen_settings()!
		   var newresult = JSON.parse(_result());
		   var scroll_x = newresult["ScrollX"], scroll_y = newresult["ScrollY"]
		   var margin_top_bottom = 50; //percent
		   var margin_left_top = 50; // percent
		   div = 1;
		   var x_min = x + w/100*margin_left_top + parseInt(scroll_x), x_max = x+w/div-w/100*margin_left_top + parseInt(scroll_x);
		   var y_min = y + h/100*margin_top_bottom + parseInt(scroll_y), y_max = y+h - h/100*margin_top_bottom + parseInt(scroll_y);
		   x = rand(x_min, x_max);
		   y = rand(y_min, y_max);
		   x = x.toFixed();
		   y = y.toFixed();
		   /// Кнопка Reload
		   VAR_RELOAD_BUTTON_X = parseInt(x);
		   VAR_RELOAD_BUTTON_Y = parseInt(y);
		   

		   
		   
		   VAR_ELEMENT_SELECTOR = VAR_HCAPTCHA_PREFIX_SECOND_FRAME + "\u003eCSS\u003e .button-submit"
		   

		   
		   
		   _SELECTOR = VAR_ELEMENT_SELECTOR;
		   get_element_selector(_SELECTOR, false).script("(function(){var rect = _BAS_HIDE(BrowserAutomationStudio_GetBoundingClientRect)(self);return (rect.left + positionx) + '|' + (rect.top + positiony) + '|' + (rect.right - rect.left) + '|' + (rect.bottom - rect.top)})();")!
		   var split = _result().split("|");
		   var x = parseInt(split[0]), y = parseInt(split[1]), w = parseInt(split[2]), h = parseInt(split[3]);
		   _get_browser_screen_settings()!
		   var newresult = JSON.parse(_result());
		   var scroll_x = newresult["ScrollX"], scroll_y = newresult["ScrollY"]
		   var margin_top_bottom = 50; //percent
		   var margin_left_top = 50; // percent
		   div = 1;
		   var x_min = x + w/100*margin_left_top + parseInt(scroll_x), x_max = x+w/div-w/100*margin_left_top + parseInt(scroll_x);
		   var y_min = y + h/100*margin_top_bottom + parseInt(scroll_y), y_max = y+h - h/100*margin_top_bottom + parseInt(scroll_y);
		   x = rand(x_min, x_max);
		   y = rand(y_min, y_max);
		   x = x.toFixed();
		   y = y.toFixed();
		   /// Кнопка подтвердить
		   VAR_SUBMIT_BUTTON_X = parseInt(x);
		   VAR_SUBMIT_BUTTON_Y = parseInt(y);
		   

		   
		   
		   /*Browser*/
		   ;_SELECTOR=VAR_HCAPTCHA_PREFIX_SECOND_FRAME + "\u003eCSS\u003e.task-grid";
		   get_element_selector(_SELECTOR, false).nowait().exist()!
		   VAR_IS_EXISTS_HCAPTCHA_1 = _result() == 1
		   _if(VAR_IS_EXISTS_HCAPTCHA_1, function(){
		   get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
		   VAR_IS_EXISTS_HCAPTCHA_1 = _result().indexOf("true")>=0
		   })!
		   

		   
		   
		   _set_if_expression("W1tJU19FWElTVFNfSENBUFRDSEFfMV1d");
		   _if(typeof(VAR_IS_EXISTS_HCAPTCHA_1) !== "undefined" ? (VAR_IS_EXISTS_HCAPTCHA_1) : undefined,function(){
		   
			  
			  
			  VAR_ELEMENT_SELECTOR = VAR_HCAPTCHA_PREFIX_SECOND_FRAME
			  

		   })!
		   

		   
		   
		   /*Browser*/
		   ;_SELECTOR=VAR_HCAPTCHA_PREFIX_SECOND_FRAME + "\u003eCSS\u003e .bounding-box-example";
		   get_element_selector(_SELECTOR, false).nowait().exist()!
		   VAR_IS_EXISTS_HCAPTCHA_2 = _result() == 1
		   _if(VAR_IS_EXISTS_HCAPTCHA_2, function(){
		   get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
		   VAR_IS_EXISTS_HCAPTCHA_2 = _result().indexOf("true")>=0
		   })!
		   

		   
		   
		   _set_if_expression("W1tJU19FWElTVFNfSENBUFRDSEFfMl1d");
		   _if(typeof(VAR_IS_EXISTS_HCAPTCHA_2) !== "undefined" ? (VAR_IS_EXISTS_HCAPTCHA_2) : undefined,function(){
		   
			  
			  
			  VAR_ELEMENT_SELECTOR = VAR_HCAPTCHA_PREFIX_SECOND_FRAME + "\u003eCSS\u003e canvas"
			  

		   })!
		   

		   
		   
		   /*Browser*/
		   ;_SELECTOR=VAR_HCAPTCHA_PREFIX_SECOND_FRAME + "\u003eCSS\u003e .task-wrapper";
		   get_element_selector(_SELECTOR, false).nowait().exist()!
		   VAR_IS_EXISTS_HCAPTCHA_3 = _result() == 1
		   _if(VAR_IS_EXISTS_HCAPTCHA_3, function(){
		   get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
		   VAR_IS_EXISTS_HCAPTCHA_3 = _result().indexOf("true")>=0
		   })!
		   

		   
		   
		   _set_if_expression("W1tJU19FWElTVFNfSENBUFRDSEFfM11d");
		   _if(typeof(VAR_IS_EXISTS_HCAPTCHA_3) !== "undefined" ? (VAR_IS_EXISTS_HCAPTCHA_3) : undefined,function(){
		   
			  
			  
			  VAR_ELEMENT_SELECTOR = VAR_HCAPTCHA_PREFIX_SECOND_FRAME + "\u003eCSS\u003e div[class=\u0027answer-bg\u0027]\u003eAT\u003e0"
			  

			  
			  
			  _SELECTOR = VAR_ELEMENT_SELECTOR;
			  get_element_selector(_SELECTOR, false).script("(function(){var rect = _BAS_HIDE(BrowserAutomationStudio_GetBoundingClientRect)(self);return (rect.left + positionx) + '|' + (rect.top + positiony) + '|' + (rect.right - rect.left) + '|' + (rect.bottom - rect.top)})();")!
			  var split = _result().split("|");
			  var x = parseInt(split[0]), y = parseInt(split[1]), w = parseInt(split[2]), h = parseInt(split[3]);
			  /// Кнопка подтвердить
			  VAR_ANSWER_SQUARE_WIDTH = parseInt(w);
			  VAR_ANSWER_SQUARE_HEIGHT = parseInt(h);
			  

			  
			  
			  VAR_ELEMENT_SELECTOR = VAR_HCAPTCHA_PREFIX_SECOND_FRAME + "\u003eCSS\u003e .task-wrapper"
			  

		   })!
		   

		   
		   
		   _set_if_expression("W1tJU19FWElTVFNfSENBUFRDSEFfMV1dID09IGZhbHNlICYmIFtbSVNfRVhJU1RTX0hDQVBUQ0hBXzJdXSA9PSBmYWxzZSAmJiBbW0lTX0VYSVNUU19IQ0FQVENIQV8zXV0gPT0gZmFsc2U=");
		   _if(VAR_IS_EXISTS_HCAPTCHA_1 == false && VAR_IS_EXISTS_HCAPTCHA_2 == false && VAR_IS_EXISTS_HCAPTCHA_3 == false,function(){
		   
			  
			  
			  /*Browser*/
			  ;_SELECTOR=VAR_HCAPTCHA_PREFIX_SECOND_FRAME + "\u003eCSS\u003e div[class=\u0027description-text\u0027]";
			  get_element_selector(_SELECTOR, false).nowait().exist()!
			  VAR_IS_EXISTS_HCAPTCHA_2_NOTASK = _result() == 1
			  

			  
			  
			  _set_if_expression("W1tJU19FWElTVFNfSENBUFRDSEFfMl9OT1RBU0tdXQ==");
			  _if(typeof(VAR_IS_EXISTS_HCAPTCHA_2_NOTASK) !== "undefined" ? (VAR_IS_EXISTS_HCAPTCHA_2_NOTASK) : undefined,function(){
			  
				 
				 
				 _set_if_expression("W1tJU19MT0ddXSA9PSB0cnVl");
				 _if(VAR_IS_LOG == true,function(){
				 
					
					
					_info((_K==="en" ? "Тест": "Этот тип Canvas hCaptсha не содержит подсказок"));
					

				 })!
				 

				 
				 
				 VAR_ELEMENT_SELECTOR = VAR_HCAPTCHA_PREFIX_SECOND_FRAME + "\u003eCSS\u003e div[class=\u0027description-text\u0027]"
				 

			  })!
			  

		   })!
		   

		   
		   
		   _set_if_expression("W1tJU19FWElTVFNfSENBUFRDSEFfMV1dID09IGZhbHNlICYmIFtbSVNfRVhJU1RTX0hDQVBUQ0hBXzJdXSA9PSBmYWxzZSAmJiBbW0lTX0VYSVNUU19IQ0FQVENIQV8zXV0gPT0gZmFsc2UgJiYgW1tJU19FWElTVFNfSENBUFRDSEFfMl9OT1RBU0tdXSA9PSBmYWxzZQ==");
		   _if(VAR_IS_EXISTS_HCAPTCHA_1 == false && VAR_IS_EXISTS_HCAPTCHA_2 == false && VAR_IS_EXISTS_HCAPTCHA_3 == false && VAR_IS_EXISTS_HCAPTCHA_2_NOTASK == false,function(){
		   
			  
			  
			  /*Browser*/
			  ;_SELECTOR=VAR_HCAPTCHA_PREFIX_SECOND_FRAME + "\u003eCSS\u003e .refresh";
			  get_element_selector(_SELECTOR, false).nowait().exist()!
			  VAR_IS_EXISTS = _result() == 1
			  _if(VAR_IS_EXISTS, function(){
			  get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
			  VAR_IS_EXISTS = _result().indexOf("true")>=0
			  })!
			  

			  
			  
			  _cycle_params().if_else = typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined;
			  _set_if_expression("W1tJU19FWElTVFNdXQ==");
			  _if(_cycle_params().if_else,function(){
			  
				 
				 
				 /*Browser*/
				 cache_data_clear()!
				 

				 
				 
				 VAR_NUMBER_CRUMB = "0"
				 

				 
				 
				 VAR_HCAPTCHA_INVISIBLE = parseInt(VAR_HCAPTCHA_INVISIBLE) + parseInt(2)
				 

				 
				 
				 /*Browser*/
				 _SELECTOR = VAR_HCAPTCHA_PREFIX_SECOND_FRAME + "\u003eCSS\u003e .refresh";
				 wait_element_visible(_SELECTOR)!
				 _call(_random_point, {})!
				 _if(_result().length > 0, function(){
				 move( {} )!
				 get_element_selector(_SELECTOR, false).clarify(X,Y)!
				 _call(_clarify, {} )!
				 mouse(X,Y)!
				 })!
				 

			  })!
			  

			  
			  
			  _if(!_cycle_params().if_else,function(){
			  
				 
				 
				 _next("function")
				 

			  })!
			  delete _cycle_params().if_else;
			  

		   })!
		   

		   
		   
		   _SELECTOR = VAR_ELEMENT_SELECTOR;
		   get_element_selector(_SELECTOR, false).script("(function(){var rect = _BAS_HIDE(BrowserAutomationStudio_GetBoundingClientRect)(self);return (rect.left + positionx) + '|' + (rect.top + positiony) + '|' + (rect.right - rect.left) + '|' + (rect.bottom - rect.top)})();")!
		   var split = _result().split("|");
		   var x = parseInt(split[0]), y = parseInt(split[1]), w = parseInt(split[2]), h = parseInt(split[3]);
		   //Первый тип капчи. 9 квадратов
		   if (VAR_HCAPTCHA_TYPE_1 == true){
		   /// Первый квадрат из 9
		   VAR_SQUARE_BUTTON_X = parseInt(x) + VAR_SCROLL_X;
		   VAR_SQUARE_BUTTON_Y = parseInt(y) + VAR_SCROLL_Y;
		   VAR_SQUARE_WIDTH = parseInt(w);
		   VAR_SQUARE_HEIGHT = parseInt(h);
		   /// Отдельно считаем наш угол, чтобы потом проверить его видимость
		   VAR_START_COORDINATES = parseInt(y);
		   }
		   //Второй тип капчи. Канвас с 3 примерами заданий
		   if (VAR_HCAPTCHA_TYPE_2 == true && VAR_IS_EXISTS_HCAPTCHA_2 == true){
		   /// Вся каптча вместе с канвасом
		   VAR_SQUARE_BUTTON_X = parseInt(x) + VAR_SCROLL_X;
		   VAR_SQUARE_BUTTON_Y = parseInt(y) + VAR_SCROLL_Y;
		   VAR_SQUARE_WIDTH = parseInt(w);
		   VAR_SQUARE_HEIGHT = parseInt(h);
		   /// Отдельно считаем наш угол, чтобы потом проверить его видимость
		   VAR_START_COORDINATES = parseInt(y);
		   }
		   //Третий тип капчи. Выбор правильного ответа справа от картинки
		   if (VAR_HCAPTCHA_TYPE_3 == true){
		   /// Каптча в в большом квадрата слева
		   VAR_SQUARE_BUTTON_X = parseInt(x) + VAR_SCROLL_X;
		   VAR_SQUARE_BUTTON_Y = parseInt(y) + VAR_SCROLL_Y;
		   VAR_SQUARE_WIDTH = parseInt(w);
		   VAR_SQUARE_HEIGHT = parseInt(h);
		   /// Отдельно считаем наш угол, чтобы потом проверить его видимость
		   VAR_START_COORDINATES = parseInt(y);
		   }
		   // Четвертый тип капчи. Канвас без заданий
		   if (VAR_HCAPTCHA_TYPE_4 == true && VAR_IS_EXISTS_HCAPTCHA_2_NOTASK == true){
		   /// Положение капчи в канвасе
		   VAR_SQUARE_BUTTON_X = parseInt(x) + VAR_SCROLL_X;
		   VAR_SQUARE_BUTTON_Y = parseInt(y) + VAR_SCROLL_Y + parseInt(h);
		   VAR_SQUARE_WIDTH = parseInt(w);
		   VAR_SQUARE_HEIGHT = parseInt(w)/1.45;
		   /// Отдельно считаем наш угол, чтобы потом проверить его видимость
		   VAR_START_COORDINATES = parseInt(y) + parseInt(h);
		   }
		   

		   
		   
		   VAR_GET_ALL_COORDINATES = 1
		   

		})!
		

	 },null)!
	 

	 
	 
	 _set_if_expression("W1tXQVNfRVJST1JdXQ==");
	 _if(typeof(VAR_WAS_ERROR) !== "undefined" ? (VAR_WAS_ERROR) : undefined,function(){
	 
		
		
		_set_if_expression("W1tMQVNUX0VSUk9SXV0gPT09ICdBYm9ydGVkIEJ5IFVzZXInIHx8IFtbTEFTVF9FUlJPUl1dICA9PT0gJ9Cf0YDQtdGA0LLQsNC90L4g0J/QvtC70YzQt9C+0LLQsNGC0LXQu9C10Lwn");
		_if(VAR_LAST_ERROR === 'Aborted By User' || VAR_LAST_ERROR  === 'Прервано Пользователем',function(){
		
		   
		   
		   _function_return(false)
		   

		})!
		

		
		
		/*Browser*/
		cache_data_clear()!
		

		
		
		fail(VAR_LAST_ERROR)
		

	 })!
	 

	 
	 
	 _call(function()
	 {
	 _on_fail(function(){
	 VAR_LAST_ERROR = _result()
	 VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
	 VAR_WAS_ERROR = false
	 _break(1,true)
	 })
	 CYCLES.Current().RemoveLabel("function")
	 
		
		
		_set_if_expression("W1tOVU1CRVJfQ1JVTUJdXSA9PSAw");
		_if(VAR_NUMBER_CRUMB == 0,function(){
		
		   
		   
		   _set_if_expression("W1tJU19MT0ddXSA9PSB0cnVl");
		   _if(VAR_IS_LOG == true,function(){
		   
			  
			  
			  _info((_K==="en" ? "Тест": "Получаем текст заданий из кэша запросов *hcaptcha.com/getcaptcha* "));
			  

		   })!
		   

		   
		   
		   /*Browser*/
		   waiter_timeout_next(45000)
		   wait_load("*hcaptcha.com/getcaptcha*")!
		   

		   
		   
		   /*Browser*/
		   _cache_get_all("*hcaptcha.com/getcaptcha*")!
		   VAR_LIST_ELEMENT_BAS_MODULE = JSON.parse(_result())
		   

		   
		   
		   _cycle_params().if_else = VAR_LIST_ELEMENT_BAS_MODULE != '';
		   _set_if_expression("W1tMSVNUX0VMRU1FTlRfQkFTX01PRFVMRV1dICE9ICcn");
		   _if(_cycle_params().if_else,function(){
		   
			  
			  
			  VAR_LIST_ELEMENT_BAS_MODULE_ONE = VAR_LIST_ELEMENT_BAS_MODULE[0].body
			  

			  
			  
			  /// Функция декодирования
			  function decodeBase64Module(base64StringModule) {
			  var decodedStringModule = "";
			  var keyStr = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";
			  var chr1, chr2, chr3;
			  var enc1, enc2, enc3, enc4;
			  var i = 0;
			  base64StringModule = base64StringModule.replace(/[^A-Za-z0-9+/=]/g, "");
			  while (i < base64StringModule.length) {
			  enc1 = keyStr.indexOf(base64StringModule.charAt(i++));
			  enc2 = keyStr.indexOf(base64StringModule.charAt(i++));
			  enc3 = keyStr.indexOf(base64StringModule.charAt(i++));
			  enc4 = keyStr.indexOf(base64StringModule.charAt(i++));
			  chr1 = (enc1 << 2) | (enc2 >> 4);
			  chr2 = ((enc2 & 15) << 4) | (enc3 >> 2);
			  chr3 = ((enc3 & 3) << 6) | enc4;
			  decodedStringModule += String.fromCharCode(chr1);
			  if (enc3 !== 64) {
			  decodedStringModule += String.fromCharCode(chr2);
			  }
			  if (enc4 !== 64) {
			  decodedStringModule += String.fromCharCode(chr3);
			  }
			  }
			  return decodedStringModule;
			  }
			  /// Ищем задание в каждом элементе кэша
			  VAR_SAVED_CACHE_MODULE = decodeBase64Module(VAR_LIST_ELEMENT_BAS_MODULE_ONE);
			  

			  
			  
			  _set_if_expression("W1tTQVZFRF9DQUNIRV9NT0RVTEVdXSA9PSAiIg==");
			  _if(VAR_SAVED_CACHE_MODULE == "",function(){
			  
				 
				 
				 VAR_ERROR_GET_TASK = 1
				 

			  })!
			  

			  
			  
			  _cycle_params().if_else = VAR_SAVED_CACHE_MODULE.indexOf("requester_question") >= 0;
			  _set_if_expression("W1tTQVZFRF9DQUNIRV9NT0RVTEVdXS5pbmRleE9mKCJyZXF1ZXN0ZXJfcXVlc3Rpb24iKSA+PSAw");
			  _if(_cycle_params().if_else,function(){
			  
				 
				 
				 _set_if_expression("W1tJU19MT0ddXSA9PSB0cnVl");
				 _if(VAR_IS_LOG == true,function(){
				 
					
					
					_info((_K==="en" ? "Тест": "Маска кэша не зашифрована *hcaptcha.com/getcaptcha*, парсим задание."));
					

				 })!
				 

				 
				 
				 VAR_SAVED_CACHE_MODULE = JSON.parse(VAR_SAVED_CACHE_MODULE);
				 VAR_SET_TASK = VAR_SAVED_CACHE_MODULE.requester_question.en
				 

			  })!
			  

			  
			  
			  _if(!_cycle_params().if_else,function(){
			  
				 
				 
				 _set_if_expression("W1tJU19MT0ddXSA9PSB0cnVl");
				 _if(VAR_IS_LOG == true,function(){
				 
					
					
					_info((_K==="en" ? "Тест": "Маска кэша зашифрована *hcaptcha.com/getcaptcha*, пытаемся расшифровать."));
					

				 })!
				 

				 
				 
				 _set_if_expression("W1tFUlJPUl9HRVRfVEFTS11dID09IDA=");
				 _if(VAR_ERROR_GET_TASK == 0,function(){
				 
					
					
					_SELECTOR = VAR_HCAPTCHA_PREFIX_SECOND_FRAME;
					wait_element(_SELECTOR)!
					get_element_selector(_SELECTOR, false).script2("!function(t)\u007bif(\u0022object\u0022==typeof exports\u0026\u0026\u0022undefined\u0022!=typeof module)module.exports=t();else if(\u0022function\u0022==typeof define\u0026\u0026define.amd)define([],t);else\u007bvar r;r=\u0022undefined\u0022!=typeof window?window:\u0022undefined\u0022!=typeof global?global:\u0022undefined\u0022!=typeof self?self:this,r.msgpack=t()\u007d\u007d(function()\u007breturn function t(r,e,n)\u007bfunction i(f,u)\u007bif(!e[f])\u007bif(!r[f])\u007bvar a=\u0022function\u0022==typeof require\u0026\u0026require;if(!u\u0026\u0026a)return a(f,!0);if(o)return o(f,!0);var s=new Error(\u0022Cannot find module \u0027\u0022+f+\u0022\u0027\u0022);throw s.code=\u0022MODULE_NOT_FOUND\u0022,s\u007dvar c=e[f]=\u007bexports:\u007b\u007d\u007d;r[f][0].call(c.exports,function(t)\u007bvar e=r[f][1][t];return i(e?e:t)\u007d,c,c.exports,t,r,e,n)\u007dreturn e[f].exports\u007dfor(var o=\u0022function\u0022==typeof require\u0026\u0026require,f=0;f\u003cn.length;f++)i(n[f]);return i\u007d(\u007b1:[function(t,r,e)\u007be.encode=t(\u0022./encode\u0022).encode,e.decode=t(\u0022./decode\u0022).decode,e.Encoder=t(\u0022./encoder\u0022).Encoder,e.Decoder=t(\u0022./decoder\u0022).Decoder,e.createCodec=t(\u0022./ext\u0022).createCodec,e.codec=t(\u0022./codec\u0022).codec\u007d,\u007b\u0022./codec\u0022:10,\u0022./decode\u0022:12,\u0022./decoder\u0022:13,\u0022./encode\u0022:15,\u0022./encoder\u0022:16,\u0022./ext\u0022:20\u007d],2:[function(t,r,e)\u007b(function(Buffer)\u007bfunction t(t)\u007breturn t\u0026\u0026t.isBuffer\u0026\u0026t\u007dr.exports=t(\u0022undefined\u0022!=typeof Buffer\u0026\u0026Buffer)||t(this.Buffer)||t(\u0022undefined\u0022!=typeof window\u0026\u0026window.Buffer)||this.Buffer\u007d).call(this,t(\u0022buffer\u0022).Buffer)\u007d,\u007bbuffer:29\u007d],3:[function(t,r,e)\u007bfunction n(t,r)\u007bfor(var e=this,n=r||(r|=0),i=t.length,o=0,f=0;f\u003ci;)o=t.charCodeAt(f++),o\u003c128?e[n++]=o:o\u003c2048?(e[n++]=192|o\u003e\u003e\u003e6,e[n++]=128|63\u0026o):o\u003c55296||o\u003e57343?(e[n++]=224|o\u003e\u003e\u003e12,e[n++]=128|o\u003e\u003e\u003e6\u002663,e[n++]=128|63\u0026o):(o=(o-55296\u003c\u003c10|t.charCodeAt(f++)-56320)+65536,e[n++]=240|o\u003e\u003e\u003e18,e[n++]=128|o\u003e\u003e\u003e12\u002663,e[n++]=128|o\u003e\u003e\u003e6\u002663,e[n++]=128|63\u0026o);return n-r\u007dfunction i(t,r,e)\u007bvar n=this,i=0|r;e||(e=n.length);for(var o=\u0022\u0022,f=0;i\u003ce;)f=n[i++],f\u003c128?o+=String.fromCharCode(f):(192===(224\u0026f)?f=(31\u0026f)\u003c\u003c6|63\u0026n[i++]:224===(240\u0026f)?f=(15\u0026f)\u003c\u003c12|(63\u0026n[i++])\u003c\u003c6|63\u0026n[i++]:240===(248\u0026f)\u0026\u0026(f=(7\u0026f)\u003c\u003c18|(63\u0026n[i++])\u003c\u003c12|(63\u0026n[i++])\u003c\u003c6|63\u0026n[i++]),f\u003e=65536?(f-=65536,o+=String.fromCharCode((f\u003e\u003e\u003e10)+55296,(1023\u0026f)+56320)):o+=String.fromCharCode(f));return o\u007dfunction o(t,r,e,n)\u007bvar i;e||(e=0),n||0===n||(n=this.length),r||(r=0);var o=n-e;if(t===this\u0026\u0026e\u003cr\u0026\u0026r\u003cn)for(i=o-1;i\u003e=0;i--)t[i+r]=this[i+e];else for(i=0;i\u003co;i++)t[i+r]=this[i+e];return o\u007de.copy=o,e.toString=i,e.write=n\u007d,\u007b\u007d],4:[function(t,r,e)\u007bfunction n(t)\u007breturn new Array(t)\u007dfunction i(t)\u007bif(!o.isBuffer(t)\u0026\u0026o.isView(t))t=o.Uint8Array.from(t);else if(o.isArrayBuffer(t))t=new Uint8Array(t);else\u007bif(\u0022string\u0022==typeof t)return o.from.call(e,t);if(\u0022number\u0022==typeof t)throw new TypeError(\u0027\u0022value\u0022 argument must not be a number\u0027)\u007dreturn Array.prototype.slice.call(t)\u007dvar o=t(\u0022./bufferish\u0022),e=r.exports=n(0);e.alloc=n,e.concat=o.concat,e.from=i\u007d,\u007b\u0022./bufferish\u0022:8\u007d],5:[function(t,r,e)\u007bfunction n(t)\u007breturn new Buffer(t)\u007dfunction i(t)\u007bif(!o.isBuffer(t)\u0026\u0026o.isView(t))t=o.Uint8Array.from(t);else if(o.isArrayBuffer(t))t=new Uint8Array(t);else\u007bif(\u0022string\u0022==typeof t)return o.from.call(e,t);if(\u0022number\u0022==typeof t)throw new TypeError(\u0027\u0022value\u0022 argument must not be a number\u0027)\u007dreturn Buffer.from\u0026\u00261!==Buffer.from.length?Buffer.from(t):new Buffer(t)\u007dvar o=t(\u0022./bufferish\u0022),Buffer=o.global,e=r.exports=o.hasBuffer?n(0):[];e.alloc=o.hasBuffer\u0026\u0026Buffer.alloc||n,e.concat=o.concat,e.from=i\u007d,\u007b\u0022./bufferish\u0022:8\u007d],6:[function(t,r,e)\u007bfunction n(t,r,e,n)\u007bvar o=a.isBuffer(this),f=a.isBuffer(t);if(o\u0026\u0026f)return this.copy(t,r,e,n);if(c||o||f||!a.isView(this)||!a.isView(t))return u.copy.call(this,t,r,e,n);var s=e||null!=n?i.call(this,e,n):this;return t.set(s,r),s.length\u007dfunction i(t,r)\u007bvar e=this.slice||!c\u0026\u0026this.subarray;if(e)return e.call(this,t,r);var i=a.alloc.call(this,r-t);return n.call(this,i,0,t,r),i\u007dfunction o(t,r,e)\u007bvar n=!s\u0026\u0026a.isBuffer(this)?this.toString:u.toString;return n.apply(this,arguments)\u007dfunction f(t)\u007bfunction r()\u007bvar r=this[t]||u[t];return r.apply(this,arguments)\u007dreturn r\u007dvar u=t(\u0022./buffer-lite\u0022);e.copy=n,e.slice=i,e.toString=o,e.write=f(\u0022write\u0022);var a=t(\u0022./bufferish\u0022),Buffer=a.global,s=a.hasBuffer\u0026\u0026\u0022TYPED_ARRAY_SUPPORT\u0022in Buffer,c=s\u0026\u0026!Buffer.TYPED_ARRAY_SUPPORT\u007d,\u007b\u0022./buffer-lite\u0022:3,\u0022./bufferish\u0022:8\u007d],7:[function(t,r,e)\u007bfunction n(t)\u007breturn new Uint8Array(t)\u007dfunction i(t)\u007bif(o.isView(t))\u007bvar r=t.byteOffset,n=t.byteLength;t=t.buffer,t.byteLength!==n\u0026\u0026(t.slice?t=t.slice(r,r+n):(t=new Uint8Array(t),t.byteLength!==n\u0026\u0026(t=Array.prototype.slice.call(t,r,r+n))))\u007delse\u007bif(\u0022string\u0022==typeof t)return o.from.call(e,t);if(\u0022number\u0022==typeof t)throw new TypeError(\u0027\u0022value\u0022 argument must not be a number\u0027)\u007dreturn new Uint8Array(t)\u007dvar o=t(\u0022./bufferish\u0022),e=r.exports=o.hasArrayBuffer?n(0):[];e.alloc=n,e.concat=o.concat,e.from=i\u007d,\u007b\u0022./bufferish\u0022:8\u007d],8:[function(t,r,e)\u007bfunction n(t)\u007breturn\u0022string\u0022==typeof t?u.call(this,t):a(this).from(t)\u007dfunction i(t)\u007breturn a(this).alloc(t)\u007dfunction o(t,r)\u007bfunction n(t)\u007br+=t.length\u007dfunction o(t)\u007ba+=w.copy.call(t,u,a)\u007dr||(r=0,Array.prototype.forEach.call(t,n));var f=this!==e\u0026\u0026this||t[0],u=i.call(f,r),a=0;return Array.prototype.forEach.call(t,o),u\u007dfunction f(t)\u007breturn t instanceof ArrayBuffer||E(t)\u007dfunction u(t)\u007bvar r=3*t.length,e=i.call(this,r),n=w.write.call(e,t);return r!==n\u0026\u0026(e=w.slice.call(e,0,n)),e\u007dfunction a(t)\u007breturn d(t)?g:y(t)?b:p(t)?v:h?g:l?b:v\u007dfunction s()\u007breturn!1\u007dfunction c(t,r)\u007breturn t=\u0022[object \u0022+t+\u0022]\u0022,function(e)\u007breturn null!=e\u0026\u0026\u007b\u007d.toString.call(r?e[r]:e)===t\u007d\u007dvar Buffer=e.global=t(\u0022./buffer-global\u0022),h=e.hasBuffer=Buffer\u0026\u0026!!Buffer.isBuffer,l=e.hasArrayBuffer=\u0022undefined\u0022!=typeof ArrayBuffer,p=e.isArray=t(\u0022isarray\u0022);e.isArrayBuffer=l?f:s;var d=e.isBuffer=h?Buffer.isBuffer:s,y=e.isView=l?ArrayBuffer.isView||c(\u0022ArrayBuffer\u0022,\u0022buffer\u0022):s;e.alloc=i,e.concat=o,e.from=n;var v=e.Array=t(\u0022./bufferish-array\u0022),g=e.Buffer=t(\u0022./bufferish-buffer\u0022),b=e.Uint8Array=t(\u0022./bufferish-uint8array\u0022),w=e.prototype=t(\u0022./bufferish-proto\u0022),E=c(\u0022ArrayBuffer\u0022)\u007d,\u007b\u0022./buffer-global\u0022:2,\u0022./bufferish-array\u0022:4,\u0022./bufferish-buffer\u0022:5,\u0022./bufferish-proto\u0022:6,\u0022./bufferish-uint8array\u0022:7,isarray:34\u007d],9:[function(t,r,e)\u007bfunction n(t)\u007breturn this instanceof n?(this.options=t,void this.init()):new n(t)\u007dfunction i(t)\u007bfor(var r in t)n.prototype[r]=o(n.prototype[r],t[r])\u007dfunction o(t,r)\u007bfunction e()\u007breturn t.apply(this,arguments),r.apply(this,arguments)\u007dreturn t\u0026\u0026r?e:t||r\u007dfunction f(t)\u007bfunction r(t,r)\u007breturn r(t)\u007dreturn t=t.slice(),function(e)\u007breturn t.reduce(r,e)\u007d\u007dfunction u(t)\u007breturn s(t)?f(t):t\u007dfunction a(t)\u007breturn new n(t)\u007dvar s=t(\u0022isarray\u0022);e.createCodec=a,e.install=i,e.filter=u;var c=t(\u0022./bufferish\u0022);n.prototype.init=function()\u007bvar t=this.options;return t\u0026\u0026t.uint8array\u0026\u0026(this.bufferish=c.Uint8Array),this\u007d,e.preset=a(\u007bpreset:!0\u007d)\u007d,\u007b\u0022./bufferish\u0022:8,isarray:34\u007d],10:[function(t,r,e)\u007bt(\u0022./read-core\u0022),t(\u0022./write-core\u0022),e.codec=\u007bpreset:t(\u0022./codec-base\u0022).preset\u007d\u007d,\u007b\u0022./codec-base\u0022:9,\u0022./read-core\u0022:22,\u0022./write-core\u0022:25\u007d],11:[function(t,r,e)\u007bfunction n(t)\u007bif(!(this instanceof n))return new n(t);if(t\u0026\u0026(this.options=t,t.codec))\u007bvar r=this.codec=t.codec;r.bufferish\u0026\u0026(this.bufferish=r.bufferish)\u007d\u007de.DecodeBuffer=n;var i=t(\u0022./read-core\u0022).preset,o=t(\u0022./flex-buffer\u0022).FlexDecoder;o.mixin(n.prototype),n.prototype.codec=i,n.prototype.fetch=function()\u007breturn this.codec.decode(this)\u007d\u007d,\u007b\u0022./flex-buffer\u0022:21,\u0022./read-core\u0022:22\u007d],12:[function(t,r,e)\u007bfunction n(t,r)\u007bvar e=new i(r);return e.write(t),e.read()\u007de.decode=n;var i=t(\u0022./decode-buffer\u0022).DecodeBuffer\u007d,\u007b\u0022./decode-buffer\u0022:11\u007d],13:[function(t,r,e)\u007bfunction n(t)\u007breturn this instanceof n?void o.call(this,t):new n(t)\u007de.Decoder=n;var i=t(\u0022event-lite\u0022),o=t(\u0022./decode-buffer\u0022).DecodeBuffer;n.prototype=new o,i.mixin(n.prototype),n.prototype.decode=function(t)\u007barguments.length\u0026\u0026this.write(t),this.flush()\u007d,n.prototype.push=function(t)\u007bthis.emit(\u0022data\u0022,t)\u007d,n.prototype.end=function(t)\u007bthis.decode(t),this.emit(\u0022end\u0022)\u007d\u007d,\u007b\u0022./decode-buffer\u0022:11,\u0022event-lite\u0022:31\u007d],14:[function(t,r,e)\u007bfunction n(t)\u007bif(!(this instanceof n))return new n(t);if(t\u0026\u0026(this.options=t,t.codec))\u007bvar r=this.codec=t.codec;r.bufferish\u0026\u0026(this.bufferish=r.bufferish)\u007d\u007de.EncodeBuffer=n;var i=t(\u0022./write-core\u0022).preset,o=t(\u0022./flex-buffer\u0022).FlexEncoder;o.mixin(n.prototype),n.prototype.codec=i,n.prototype.write=function(t)\u007bthis.codec.encode(this,t)\u007d\u007d,\u007b\u0022./flex-buffer\u0022:21,\u0022./write-core\u0022:25\u007d],15:[function(t,r,e)\u007bfunction n(t,r)\u007bvar e=new i(r);return e.write(t),e.read()\u007de.encode=n;var i=t(\u0022./encode-buffer\u0022).EncodeBuffer\u007d,\u007b\u0022./encode-buffer\u0022:14\u007d],16:[function(t,r,e)\u007bfunction n(t)\u007breturn this instanceof n?void o.call(this,t):new n(t)\u007de.Encoder=n;var i=t(\u0022event-lite\u0022),o=t(\u0022./encode-buffer\u0022).EncodeBuffer;n.prototype=new o,i.mixin(n.prototype),n.prototype.encode=function(t)\u007bthis.write(t),this.emit(\u0022data\u0022,this.read())\u007d,n.prototype.end=function(t)\u007barguments.length\u0026\u0026this.encode(t),this.flush(),this.emit(\u0022end\u0022)\u007d\u007d,\u007b\u0022./encode-buffer\u0022:14,\u0022event-lite\u0022:31\u007d],17:[function(t,r,e)\u007bfunction n(t,r)\u007breturn this instanceof n?(this.buffer=i.from(t),void(this.type=r)):new n(t,r)\u007de.ExtBuffer=n;var i=t(\u0022./bufferish\u0022)\u007d,\u007b\u0022./bufferish\u0022:8\u007d],18:[function(t,r,e)\u007bfunction n(t)\u007bt.addExtPacker(14,Error,[u,i]),t.addExtPacker(1,EvalError,[u,i]),t.addExtPacker(2,RangeError,[u,i]),t.addExtPacker(3,ReferenceError,[u,i]),t.addExtPacker(4,SyntaxError,[u,i]),t.addExtPacker(5,TypeError,[u,i]),t.addExtPacker(6,URIError,[u,i]),t.addExtPacker(10,RegExp,[f,i]),t.addExtPacker(11,Boolean,[o,i]),t.addExtPacker(12,String,[o,i]),t.addExtPacker(13,Date,[Number,i]),t.addExtPacker(15,Number,[o,i]),\u0022undefined\u0022!=typeof Uint8Array\u0026\u0026(t.addExtPacker(17,Int8Array,c),t.addExtPacker(18,Uint8Array,c),t.addExtPacker(19,Int16Array,c),t.addExtPacker(20,Uint16Array,c),t.addExtPacker(21,Int32Array,c),t.addExtPacker(22,Uint32Array,c),t.addExtPacker(23,Float32Array,c),\u0022undefined\u0022!=typeof Float64Array\u0026\u0026t.addExtPacker(24,Float64Array,c),\u0022undefined\u0022!=typeof Uint8ClampedArray\u0026\u0026t.addExtPacker(25,Uint8ClampedArray,c),t.addExtPacker(26,ArrayBuffer,c),t.addExtPacker(29,DataView,c)),s.hasBuffer\u0026\u0026t.addExtPacker(27,Buffer,s.from)\u007dfunction i(r)\u007breturn a||(a=t(\u0022./encode\u0022).encode),a(r)\u007dfunction o(t)\u007breturn t.valueOf()\u007dfunction f(t)\u007bt=RegExp.prototype.toString.call(t).split(\u0022/\u0022),t.shift();var r=[t.pop()];return r.unshift(t.join(\u0022/\u0022)),r\u007dfunction u(t)\u007bvar r=\u007b\u007d;for(var e in h)r[e]=t[e];return r\u007de.setExtPackers=n;var a,s=t(\u0022./bufferish\u0022),Buffer=s.global,c=s.Uint8Array.from,h=\u007bname:1,message:1,stack:1,columnNumber:1,fileName:1,lineNumber:1\u007d\u007d,\u007b\u0022./bufferish\u0022:8,\u0022./encode\u0022:15\u007d],19:[function(t,r,e)\u007bfunction n(t)\u007bt.addExtUnpacker(14,[i,f(Error)]),t.addExtUnpacker(1,[i,f(EvalError)]),t.addExtUnpacker(2,[i,f(RangeError)]),t.addExtUnpacker(3,[i,f(ReferenceError)]),t.addExtUnpacker(4,[i,f(SyntaxError)]),t.addExtUnpacker(5,[i,f(TypeError)]),t.addExtUnpacker(6,[i,f(URIError)]),t.addExtUnpacker(10,[i,o]),t.addExtUnpacker(11,[i,u(Boolean)]),t.addExtUnpacker(12,[i,u(String)]),t.addExtUnpacker(13,[i,u(Date)]),t.addExtUnpacker(15,[i,u(Number)]),\u0022undefined\u0022!=typeof Uint8Array\u0026\u0026(t.addExtUnpacker(17,u(Int8Array)),t.addExtUnpacker(18,u(Uint8Array)),t.addExtUnpacker(19,[a,u(Int16Array)]),t.addExtUnpacker(20,[a,u(Uint16Array)]),t.addExtUnpacker(21,[a,u(Int32Array)]),t.addExtUnpacker(22,[a,u(Uint32Array)]),t.addExtUnpacker(23,[a,u(Float32Array)]),\u0022undefined\u0022!=typeof Float64Array\u0026\u0026t.addExtUnpacker(24,[a,u(Float64Array)]),\u0022undefined\u0022!=typeof Uint8ClampedArray\u0026\u0026t.addExtUnpacker(25,u(Uint8ClampedArray)),t.addExtUnpacker(26,a),t.addExtUnpacker(29,[a,u(DataView)])),c.hasBuffer\u0026\u0026t.addExtUnpacker(27,u(Buffer))\u007dfunction i(r)\u007breturn s||(s=t(\u0022./decode\u0022).decode),s(r)\u007dfunction o(t)\u007breturn RegExp.apply(null,t)\u007dfunction f(t)\u007breturn function(r)\u007bvar e=new t;for(var n in h)e[n]=r[n];return e\u007d\u007dfunction u(t)\u007breturn function(r)\u007breturn new t(r)\u007d\u007dfunction a(t)\u007breturn new Uint8Array(t).buffer\u007de.setExtUnpackers=n;var s,c=t(\u0022./bufferish\u0022),Buffer=c.global,h=\u007bname:1,message:1,stack:1,columnNumber:1,fileName:1,lineNumber:1\u007d\u007d,\u007b\u0022./bufferish\u0022:8,\u0022./decode\u0022:12\u007d],20:[function(t,r,e)\u007bt(\u0022./read-core\u0022),t(\u0022./write-core\u0022),e.createCodec=t(\u0022./codec-base\u0022).createCodec\u007d,\u007b\u0022./codec-base\u0022:9,\u0022./read-core\u0022:22,\u0022./write-core\u0022:25\u007d],21:[function(t,r,e)\u007bfunction n()\u007bif(!(this instanceof n))return new n\u007dfunction i()\u007bif(!(this instanceof i))return new i\u007dfunction o()\u007bfunction t(t)\u007bvar r=this.offset?p.prototype.slice.call(this.buffer,this.offset):this.buffer;this.buffer=r?t?this.bufferish.concat([r,t]):r:t,this.offset=0\u007dfunction r()\u007bfor(;this.offset\u003cthis.buffer.length;)\u007bvar t,r=this.offset;try\u007bt=this.fetch()\u007dcatch(t)\u007bif(t\u0026\u0026t.message!=v)throw t;this.offset=r;break\u007dthis.push(t)\u007d\u007dfunction e(t)\u007bvar r=this.offset,e=r+t;if(e\u003ethis.buffer.length)throw new Error(v);return this.offset=e,r\u007dreturn\u007bbufferish:p,write:t,fetch:a,flush:r,push:c,pull:h,read:s,reserve:e,offset:0\u007d\u007dfunction f()\u007bfunction t()\u007bvar t=this.start;if(t\u003cthis.offset)\u007bvar r=this.start=this.offset;return p.prototype.slice.call(this.buffer,t,r)\u007d\u007dfunction r()\u007bfor(;this.start\u003cthis.offset;)\u007bvar t=this.fetch();t\u0026\u0026this.push(t)\u007d\u007dfunction e()\u007bvar t=this.buffers||(this.buffers=[]),r=t.length\u003e1?this.bufferish.concat(t):t[0];return t.length=0,r\u007dfunction n(t)\u007bvar r=0|t;if(this.buffer)\u007bvar e=this.buffer.length,n=0|this.offset,i=n+r;if(i\u003ce)return this.offset=i,n;this.flush(),t=Math.max(t,Math.min(2*e,this.maxBufferSize))\u007dreturn t=Math.max(t,this.minBufferSize),this.buffer=this.bufferish.alloc(t),this.start=0,this.offset=r,0\u007dfunction i(t)\u007bvar r=t.length;if(r\u003ethis.minBufferSize)this.flush(),this.push(t);else\u007bvar e=this.reserve(r);p.prototype.copy.call(t,this.buffer,e)\u007d\u007dreturn\u007bbufferish:p,write:u,fetch:t,flush:r,push:c,pull:e,read:s,reserve:n,send:i,maxBufferSize:y,minBufferSize:d,offset:0,start:0\u007d\u007dfunction u()\u007bthrow new Error(\u0022method not implemented: write()\u0022)\u007dfunction a()\u007bthrow new Error(\u0022method not implemented: fetch()\u0022)\u007dfunction s()\u007bvar t=this.buffers\u0026\u0026this.buffers.length;return t?(this.flush(),this.pull()):this.fetch()\u007dfunction c(t)\u007bvar r=this.buffers||(this.buffers=[]);r.push(t)\u007dfunction h()\u007bvar t=this.buffers||(this.buffers=[]);return t.shift()\u007dfunction l(t)\u007bfunction r(r)\u007bfor(var e in t)r[e]=t[e];return r\u007dreturn r\u007de.FlexDecoder=n,e.FlexEncoder=i;var p=t(\u0022./bufferish\u0022),d=2048,y=65536,v=\u0022BUFFER_SHORTAGE\u0022;n.mixin=l(o()),n.mixin(n.prototype),i.mixin=l(f()),i.mixin(i.prototype)\u007d,\u007b\u0022./bufferish\u0022:8\u007d],22:[function(t,r,e)\u007bfunction n(t)\u007bfunction r(t)\u007bvar r=s(t),n=e[r];if(!n)throw new Error(\u0022Invalid type: \u0022+(r?\u00220x\u0022+r.toString(16):r));return n(t)\u007dvar e=c.getReadToken(t);return r\u007dfunction i()\u007bvar t=this.options;return this.decode=n(t),t\u0026\u0026t.preset\u0026\u0026a.setExtUnpackers(this),this\u007dfunction o(t,r)\u007bvar e=this.extUnpackers||(this.extUnpackers=[]);e[t]=h.filter(r)\u007dfunction f(t)\u007bfunction r(r)\u007breturn new u(r,t)\u007dvar e=this.extUnpackers||(this.extUnpackers=[]);return e[t]||r\u007dvar u=t(\u0022./ext-buffer\u0022).ExtBuffer,a=t(\u0022./ext-unpacker\u0022),s=t(\u0022./read-format\u0022).readUint8,c=t(\u0022./read-token\u0022),h=t(\u0022./codec-base\u0022);h.install(\u007baddExtUnpacker:o,getExtUnpacker:f,init:i\u007d),e.preset=i.call(h.preset)\u007d,\u007b\u0022./codec-base\u0022:9,\u0022./ext-buffer\u0022:17,\u0022./ext-unpacker\u0022:19,\u0022./read-format\u0022:23,\u0022./read-token\u0022:24\u007d],23:[function(t,r,e)\u007bfunction n(t)\u007bvar r=k.hasArrayBuffer\u0026\u0026t\u0026\u0026t.binarraybuffer,e=t\u0026\u0026t.int64,n=T\u0026\u0026t\u0026\u0026t.usemap,B=\u007bmap:n?o:i,array:f,str:u,bin:r?s:a,ext:c,uint8:h,uint16:p,uint32:y,uint64:g(8,e?E:b),int8:l,int16:d,int32:v,int64:g(8,e?A:w),float32:g(4,m),float64:g(8,x)\u007d;return B\u007dfunction i(t,r)\u007bvar e,n=\u007b\u007d,i=new Array(r),o=new Array(r),f=t.codec.decode;for(e=0;e\u003cr;e++)i[e]=f(t),o[e]=f(t);for(e=0;e\u003cr;e++)n[i[e]]=o[e];return n\u007dfunction o(t,r)\u007bvar e,n=new Map,i=new Array(r),o=new Array(r),f=t.codec.decode;for(e=0;e\u003cr;e++)i[e]=f(t),o[e]=f(t);for(e=0;e\u003cr;e++)n.set(i[e],o[e]);return n\u007dfunction f(t,r)\u007bfor(var e=new Array(r),n=t.codec.decode,i=0;i\u003cr;i++)e[i]=n(t);return e\u007dfunction u(t,r)\u007bvar e=t.reserve(r),n=e+r;return _.toString.call(t.buffer,\u0022utf-8\u0022,e,n)\u007dfunction a(t,r)\u007bvar e=t.reserve(r),n=e+r,i=_.slice.call(t.buffer,e,n);return k.from(i)\u007dfunction s(t,r)\u007bvar e=t.reserve(r),n=e+r,i=_.slice.call(t.buffer,e,n);return k.Uint8Array.from(i).buffer\u007dfunction c(t,r)\u007bvar e=t.reserve(r+1),n=t.buffer[e++],i=e+r,o=t.codec.getExtUnpacker(n);if(!o)throw new Error(\u0022Invalid ext type: \u0022+(n?\u00220x\u0022+n.toString(16):n));var f=_.slice.call(t.buffer,e,i);return o(f)\u007dfunction h(t)\u007bvar r=t.reserve(1);return t.buffer[r]\u007dfunction l(t)\u007bvar r=t.reserve(1),e=t.buffer[r];return 128\u0026e?e-256:e\u007dfunction p(t)\u007bvar r=t.reserve(2),e=t.buffer;return e[r++]\u003c\u003c8|e[r]\u007dfunction d(t)\u007bvar r=t.reserve(2),e=t.buffer,n=e[r++]\u003c\u003c8|e[r];return 32768\u0026n?n-65536:n\u007dfunction y(t)\u007bvar r=t.reserve(4),e=t.buffer;return 16777216*e[r++]+(e[r++]\u003c\u003c16)+(e[r++]\u003c\u003c8)+e[r]\u007dfunction v(t)\u007bvar r=t.reserve(4),e=t.buffer;return e[r++]\u003c\u003c24|e[r++]\u003c\u003c16|e[r++]\u003c\u003c8|e[r]\u007dfunction g(t,r)\u007breturn function(e)\u007bvar n=e.reserve(t);return r.call(e.buffer,n,S)\u007d\u007dfunction b(t)\u007breturn new P(this,t).toNumber()\u007dfunction w(t)\u007breturn new R(this,t).toNumber()\u007dfunction E(t)\u007breturn new P(this,t)\u007dfunction A(t)\u007breturn new R(this,t)\u007dfunction m(t)\u007breturn B.read(this,t,!1,23,4)\u007dfunction x(t)\u007breturn B.read(this,t,!1,52,8)\u007dvar B=t(\u0022ieee754\u0022),U=t(\u0022int64-buffer\u0022),P=U.Uint64BE,R=U.Int64BE;e.getReadFormat=n,e.readUint8=h;var k=t(\u0022./bufferish\u0022),_=t(\u0022./bufferish-proto\u0022),T=\u0022undefined\u0022!=typeof Map,S=!0\u007d,\u007b\u0022./bufferish\u0022:8,\u0022./bufferish-proto\u0022:6,ieee754:32,\u0022int64-buffer\u0022:33\u007d],24:[function(t,r,e)\u007bfunction n(t)\u007bvar r=s.getReadFormat(t);return t\u0026\u0026t.useraw?o(r):i(r)\u007dfunction i(t)\u007bvar r,e=new Array(256);for(r=0;r\u003c=127;r++)e[r]=f(r);for(r=128;r\u003c=143;r++)e[r]=a(r-128,t.map);for(r=144;r\u003c=159;r++)e[r]=a(r-144,t.array);for(r=160;r\u003c=191;r++)e[r]=a(r-160,t.str);for(e[192]=f(null),e[193]=null,e[194]=f(!1),e[195]=f(!0),e[196]=u(t.uint8,t.bin),e[197]=u(t.uint16,t.bin),e[198]=u(t.uint32,t.bin),e[199]=u(t.uint8,t.ext),e[200]=u(t.uint16,t.ext),e[201]=u(t.uint32,t.ext),e[202]=t.float32,e[203]=t.float64,e[204]=t.uint8,e[205]=t.uint16,e[206]=t.uint32,e[207]=t.uint64,e[208]=t.int8,e[209]=t.int16,e[210]=t.int32,e[211]=t.int64,e[212]=a(1,t.ext),e[213]=a(2,t.ext),e[214]=a(4,t.ext),e[215]=a(8,t.ext),e[216]=a(16,t.ext),e[217]=u(t.uint8,t.str),e[218]=u(t.uint16,t.str),e[219]=u(t.uint32,t.str),e[220]=u(t.uint16,t.array),e[221]=u(t.uint32,t.array),e[222]=u(t.uint16,t.map),e[223]=u(t.uint32,t.map),r=224;r\u003c=255;r++)e[r]=f(r-256);return e\u007dfunction o(t)\u007bvar r,e=i(t).slice();for(e[217]=e[196],e[218]=e[197],e[219]=e[198],r=160;r\u003c=191;r++)e[r]=a(r-160,t.bin);return e\u007dfunction f(t)\u007breturn function()\u007breturn t\u007d\u007dfunction u(t,r)\u007breturn function(e)\u007bvar n=t(e);return r(e,n)\u007d\u007dfunction a(t,r)\u007breturn function(e)\u007breturn r(e,t)\u007d\u007dvar s=t(\u0022./read-format\u0022);e.getReadToken=n\u007d,\u007b\u0022./read-format\u0022:23\u007d],25:[function(t,r,e)\u007bfunction n(t)\u007bfunction r(t,r)\u007bvar n=e[typeof r];if(!n)throw new Error(\u0027Unsupported type \u0022\u0027+typeof r+\u0027\u0022: \u0027+r);n(t,r)\u007dvar e=s.getWriteType(t);return r\u007dfunction i()\u007bvar t=this.options;return this.encode=n(t),t\u0026\u0026t.preset\u0026\u0026a.setExtPackers(this),this\u007dfunction o(t,r,e)\u007bfunction n(r)\u007breturn e\u0026\u0026(r=e(r)),new u(r,t)\u007de=c.filter(e);var i=r.name;if(i\u0026\u0026\u0022Object\u0022!==i)\u007bvar o=this.extPackers||(this.extPackers=\u007b\u007d);o[i]=n\u007delse\u007bvar f=this.extEncoderList||(this.extEncoderList=[]);f.unshift([r,n])\u007d\u007dfunction f(t)\u007bvar r=this.extPackers||(this.extPackers=\u007b\u007d),e=t.constructor,n=e\u0026\u0026e.name\u0026\u0026r[e.name];if(n)return n;for(var i=this.extEncoderList||(this.extEncoderList=[]),o=i.length,f=0;f\u003co;f++)\u007bvar u=i[f];if(e===u[0])return u[1]\u007d\u007dvar u=t(\u0022./ext-buffer\u0022).ExtBuffer,a=t(\u0022./ext-packer\u0022),s=t(\u0022./write-type\u0022),c=t(\u0022./codec-base\u0022);c.install(\u007baddExtPacker:o,getExtPacker:f,init:i\u007d),e.preset=i.call(c.preset)\u007d,\u007b\u0022./codec-base\u0022:9,\u0022./ext-buffer\u0022:17,\u0022./ext-packer\u0022:18,\u0022./write-type\u0022:27\u007d],26:[function(t,r,e)\u007bfunction n(t)\u007breturn t\u0026\u0026t.uint8array?i():m||E.hasBuffer\u0026\u0026t\u0026\u0026t.safe?f():o()\u007dfunction i()\u007bvar t=o();return t[202]=c(202,4,p),t[203]=c(203,8,d),t\u007dfunction o()\u007bvar t=w.slice();return t[196]=u(196),t[197]=a(197),t[198]=s(198),t[199]=u(199),t[200]=a(200),t[201]=s(201),t[202]=c(202,4,x.writeFloatBE||p,!0),t[203]=c(203,8,x.writeDoubleBE||d,!0),t[204]=u(204),t[205]=a(205),t[206]=s(206),t[207]=c(207,8,h),t[208]=u(208),t[209]=a(209),t[210]=s(210),t[211]=c(211,8,l),t[217]=u(217),t[218]=a(218),t[219]=s(219),t[220]=a(220),t[221]=s(221),t[222]=a(222),t[223]=s(223),t\u007dfunction f()\u007bvar t=w.slice();return t[196]=c(196,1,Buffer.prototype.writeUInt8),t[197]=c(197,2,Buffer.prototype.writeUInt16BE),t[198]=c(198,4,Buffer.prototype.writeUInt32BE),t[199]=c(199,1,Buffer.prototype.writeUInt8),t[200]=c(200,2,Buffer.prototype.writeUInt16BE),t[201]=c(201,4,Buffer.prototype.writeUInt32BE),t[202]=c(202,4,Buffer.prototype.writeFloatBE),t[203]=c(203,8,Buffer.prototype.writeDoubleBE),t[204]=c(204,1,Buffer.prototype.writeUInt8),t[205]=c(205,2,Buffer.prototype.writeUInt16BE),t[206]=c(206,4,Buffer.prototype.writeUInt32BE),t[207]=c(207,8,h),t[208]=c(208,1,Buffer.prototype.writeInt8),t[209]=c(209,2,Buffer.prototype.writeInt16BE),t[210]=c(210,4,Buffer.prototype.writeInt32BE),t[211]=c(211,8,l),t[217]=c(217,1,Buffer.prototype.writeUInt8),t[218]=c(218,2,Buffer.prototype.writeUInt16BE),t[219]=c(219,4,Buffer.prototype.writeUInt32BE),t[220]=c(220,2,Buffer.prototype.writeUInt16BE),t[221]=c(221,4,Buffer.prototype.writeUInt32BE),t[222]=c(222,2,Buffer.prototype.writeUInt16BE),t[223]=c(223,4,Buffer.prototype.writeUInt32BE),t\u007dfunction u(t)\u007breturn function(r,e)\u007bvar n=r.reserve(2),i=r.buffer;i[n++]=t,i[n]=e\u007d\u007dfunction a(t)\u007breturn function(r,e)\u007bvar n=r.reserve(3),i=r.buffer;i[n++]=t,i[n++]=e\u003e\u003e\u003e8,i[n]=e\u007d\u007dfunction s(t)\u007breturn function(r,e)\u007bvar n=r.reserve(5),i=r.buffer;i[n++]=t,i[n++]=e\u003e\u003e\u003e24,i[n++]=e\u003e\u003e\u003e16,i[n++]=e\u003e\u003e\u003e8,i[n]=e\u007d\u007dfunction c(t,r,e,n)\u007breturn function(i,o)\u007bvar f=i.reserve(r+1);i.buffer[f++]=t,e.call(i.buffer,o,f,n)\u007d\u007dfunction h(t,r)\u007bnew g(this,r,t)\u007dfunction l(t,r)\u007bnew b(this,r,t)\u007dfunction p(t,r)\u007by.write(this,t,r,!1,23,4)\u007dfunction d(t,r)\u007by.write(this,t,r,!1,52,8)\u007dvar y=t(\u0022ieee754\u0022),v=t(\u0022int64-buffer\u0022),g=v.Uint64BE,b=v.Int64BE,w=t(\u0022./write-uint8\u0022).uint8,E=t(\u0022./bufferish\u0022),Buffer=E.global,A=E.hasBuffer\u0026\u0026\u0022TYPED_ARRAY_SUPPORT\u0022in Buffer,m=A\u0026\u0026!Buffer.TYPED_ARRAY_SUPPORT,x=E.hasBuffer\u0026\u0026Buffer.prototype||\u007b\u007d;e.getWriteToken=n\u007d,\u007b\u0022./bufferish\u0022:8,\u0022./write-uint8\u0022:28,ieee754:32,\u0022int64-buffer\u0022:33\u007d],27:[function(t,r,e)\u007bfunction n(t)\u007bfunction r(t,r)\u007bvar e=r?195:194;_[e](t,r)\u007dfunction e(t,r)\u007bvar e,n=0|r;return r!==n?(e=203,void _[e](t,r)):(e=-32\u003c=n\u0026\u0026n\u003c=127?255\u0026n:0\u003c=n?n\u003c=255?204:n\u003c=65535?205:206:-128\u003c=n?208:-32768\u003c=n?209:210,void _[e](t,n))\u007dfunction n(t,r)\u007bvar e=207;_[e](t,r.toArray())\u007dfunction o(t,r)\u007bvar e=211;_[e](t,r.toArray())\u007dfunction v(t)\u007breturn t\u003c32?1:t\u003c=255?2:t\u003c=65535?3:5\u007dfunction g(t)\u007breturn t\u003c32?1:t\u003c=65535?3:5\u007dfunction b(t)\u007bfunction r(r,e)\u007bvar n=e.length,i=5+3*n;r.offset=r.reserve(i);var o=r.buffer,f=t(n),u=r.offset+f;n=s.write.call(o,e,u);var a=t(n);if(f!==a)\u007bvar c=u+a-f,h=u+n;s.copy.call(o,o,c,u,h)\u007dvar l=1===a?160+n:a\u003c=3?215+a:219;_[l](r,n),r.offset+=n\u007dreturn r\u007dfunction w(t,r)\u007bif(null===r)return A(t,r);if(I(r))return Y(t,r);if(i(r))return m(t,r);if(f.isUint64BE(r))return n(t,r);if(u.isInt64BE(r))return o(t,r);var e=t.codec.getExtPacker(r);return e\u0026\u0026(r=e(r)),r instanceof l?U(t,r):void D(t,r)\u007dfunction E(t,r)\u007breturn I(r)?k(t,r):void w(t,r)\u007dfunction A(t,r)\u007bvar e=192;_[e](t,r)\u007dfunction m(t,r)\u007bvar e=r.length,n=e\u003c16?144+e:e\u003c=65535?220:221;_[n](t,e);for(var i=t.codec.encode,o=0;o\u003ce;o++)i(t,r[o])\u007dfunction x(t,r)\u007bvar e=r.length,n=e\u003c255?196:e\u003c=65535?197:198;_[n](t,e),t.send(r)\u007dfunction B(t,r)\u007bx(t,new Uint8Array(r))\u007dfunction U(t,r)\u007bvar e=r.buffer,n=e.length,i=y[n]||(n\u003c255?199:n\u003c=65535?200:201);_[i](t,n),h[r.type](t),t.send(e)\u007dfunction P(t,r)\u007bvar e=Object.keys(r),n=e.length,i=n\u003c16?128+n:n\u003c=65535?222:223;_[i](t,n);var o=t.codec.encode;e.forEach(function(e)\u007bo(t,e),o(t,r[e])\u007d)\u007dfunction R(t,r)\u007bif(!(r instanceof Map))return P(t,r);var e=r.size,n=e\u003c16?128+e:e\u003c=65535?222:223;_[n](t,e);var i=t.codec.encode;r.forEach(function(r,e,n)\u007bi(t,e),i(t,r)\u007d)\u007dfunction k(t,r)\u007bvar e=r.length,n=e\u003c32?160+e:e\u003c=65535?218:219;_[n](t,e),t.send(r)\u007dvar _=c.getWriteToken(t),T=t\u0026\u0026t.useraw,S=p\u0026\u0026t\u0026\u0026t.binarraybuffer,I=S?a.isArrayBuffer:a.isBuffer,Y=S?B:x,C=d\u0026\u0026t\u0026\u0026t.usemap,D=C?R:P,O=\u007bboolean:r,function:A,number:e,object:T?E:w,string:b(T?g:v),symbol:A,undefined:A\u007d;return O\u007dvar i=t(\u0022isarray\u0022),o=t(\u0022int64-buffer\u0022),f=o.Uint64BE,u=o.Int64BE,a=t(\u0022./bufferish\u0022),s=t(\u0022./bufferish-proto\u0022),c=t(\u0022./write-token\u0022),h=t(\u0022./write-uint8\u0022).uint8,l=t(\u0022./ext-buffer\u0022).ExtBuffer,p=\u0022undefined\u0022!=typeof Uint8Array,d=\u0022undefined\u0022!=typeof Map,y=[];y[1]=212,y[2]=213,y[4]=214,y[8]=215,y[16]=216,e.getWriteType=n\u007d,\u007b\u0022./bufferish\u0022:8,\u0022./bufferish-proto\u0022:6,\u0022./ext-buffer\u0022:17,\u0022./write-token\u0022:26,\u0022./write-uint8\u0022:28,\u0022int64-buffer\u0022:33,isarray:34\u007d],28:[function(t,r,e)\u007bfunction n(t)\u007breturn function(r)\u007bvar e=r.reserve(1);r.buffer[e]=t\u007d\u007dfor(var i=e.uint8=new Array(256),o=0;o\u003c=255;o++)i[o]=n(o)\u007d,\u007b\u007d],29:[function(t,r,e)\u007b(function(r)\u007b\u0022use strict\u0022;function n()\u007btry\u007bvar t=new Uint8Array(1);return t.__proto__=\u007b__proto__:Uint8Array.prototype,foo:function()\u007breturn 42\u007d\u007d,42===t.foo()\u0026\u0026\u0022function\u0022==typeof t.subarray\u0026\u00260===t.subarray(1,1).byteLength\u007dcatch(t)\u007breturn!1\u007d\u007dfunction i()\u007breturn Buffer.TYPED_ARRAY_SUPPORT?2147483647:1073741823\u007dfunction o(t,r)\u007bif(i()\u003cr)throw new RangeError(\u0022Invalid typed array length\u0022);return Buffer.TYPED_ARRAY_SUPPORT?(t=new Uint8Array(r),t.__proto__=Buffer.prototype):(null===t\u0026\u0026(t=new Buffer(r)),t.length=r),t\u007dfunction Buffer(t,r,e)\u007bif(!(Buffer.TYPED_ARRAY_SUPPORT||this instanceof Buffer))return new Buffer(t,r,e);if(\u0022number\u0022==typeof t)\u007bif(\u0022string\u0022==typeof r)throw new Error(\u0022If encoding is specified then the first argument must be a string\u0022);return s(this,t)\u007dreturn f(this,t,r,e)\u007dfunction f(t,r,e,n)\u007bif(\u0022number\u0022==typeof r)throw new TypeError(\u0027\u0022value\u0022 argument must not be a number\u0027);return\u0022undefined\u0022!=typeof ArrayBuffer\u0026\u0026r instanceof ArrayBuffer?l(t,r,e,n):\u0022string\u0022==typeof r?c(t,r,e):p(t,r)\u007dfunction u(t)\u007bif(\u0022number\u0022!=typeof t)throw new TypeError(\u0027\u0022size\u0022 argument must be a number\u0027);if(t\u003c0)throw new RangeError(\u0027\u0022size\u0022 argument must not be negative\u0027)\u007dfunction a(t,r,e,n)\u007breturn u(r),r\u003c=0?o(t,r):void 0!==e?\u0022string\u0022==typeof n?o(t,r).fill(e,n):o(t,r).fill(e):o(t,r)\u007dfunction s(t,r)\u007bif(u(r),t=o(t,r\u003c0?0:0|d(r)),!Buffer.TYPED_ARRAY_SUPPORT)for(var e=0;e\u003cr;++e)t[e]=0;return t\u007dfunction c(t,r,e)\u007bif(\u0022string\u0022==typeof e\u0026\u0026\u0022\u0022!==e||(e=\u0022utf8\u0022),!Buffer.isEncoding(e))throw new TypeError(\u0027\u0022encoding\u0022 must be a valid string encoding\u0027);var n=0|v(r,e);t=o(t,n);var i=t.write(r,e);return i!==n\u0026\u0026(t=t.slice(0,i)),t\u007dfunction h(t,r)\u007bvar e=r.length\u003c0?0:0|d(r.length);t=o(t,e);for(var n=0;n\u003ce;n+=1)t[n]=255\u0026r[n];return t\u007dfunction l(t,r,e,n)\u007bif(r.byteLength,e\u003c0||r.byteLength\u003ce)throw new RangeError(\u0022\u0027offset\u0027 is out of bounds\u0022);if(r.byteLength\u003ce+(n||0))throw new RangeError(\u0022\u0027length\u0027 is out of bounds\u0022);return r=void 0===e\u0026\u0026void 0===n?new Uint8Array(r):void 0===n?new Uint8Array(r,e):new Uint8Array(r,e,n),Buffer.TYPED_ARRAY_SUPPORT?(t=r,t.__proto__=Buffer.prototype):t=h(t,r),t\u007dfunction p(t,r)\u007bif(Buffer.isBuffer(r))\u007bvar e=0|d(r.length);return t=o(t,e),0===t.length?t:(r.copy(t,0,0,e),t)\u007dif(r)\u007bif(\u0022undefined\u0022!=typeof ArrayBuffer\u0026\u0026r.buffer instanceof ArrayBuffer||\u0022length\u0022in r)return\u0022number\u0022!=typeof r.length||H(r.length)?o(t,0):h(t,r);if(\u0022Buffer\u0022===r.type\u0026\u0026Q(r.data))return h(t,r.data)\u007dthrow new TypeError(\u0022First argument must be a string, Buffer, ArrayBuffer, Array, or array-like object.\u0022)\u007dfunction d(t)\u007bif(t\u003e=i())throw new RangeError(\u0022Attempt to allocate Buffer larger than maximum size: 0x\u0022+i().toString(16)+\u0022 bytes\u0022);return 0|t\u007dfunction y(t)\u007breturn+t!=t\u0026\u0026(t=0),Buffer.alloc(+t)\u007dfunction v(t,r)\u007bif(Buffer.isBuffer(t))return t.length;if(\u0022undefined\u0022!=typeof ArrayBuffer\u0026\u0026\u0022function\u0022==typeof ArrayBuffer.isView\u0026\u0026(ArrayBuffer.isView(t)||t instanceof ArrayBuffer))return t.byteLength;\u0022string\u0022!=typeof t\u0026\u0026(t=\u0022\u0022+t);var e=t.length;if(0===e)return 0;for(var n=!1;;)switch(r)\u007bcase\u0022ascii\u0022:case\u0022latin1\u0022:case\u0022binary\u0022:return e;case\u0022utf8\u0022:case\u0022utf-8\u0022:case void 0:return q(t).length;case\u0022ucs2\u0022:case\u0022ucs-2\u0022:case\u0022utf16le\u0022:case\u0022utf-16le\u0022:return 2*e;case\u0022hex\u0022:return e\u003e\u003e\u003e1;case\u0022base64\u0022:return X(t).length;default:if(n)return q(t).length;r=(\u0022\u0022+r).toLowerCase(),n=!0\u007d\u007dfunction g(t,r,e)\u007bvar n=!1;if((void 0===r||r\u003c0)\u0026\u0026(r=0),r\u003ethis.length)return\u0022\u0022;if((void 0===e||e\u003ethis.length)\u0026\u0026(e=this.length),e\u003c=0)return\u0022\u0022;if(e\u003e\u003e\u003e=0,r\u003e\u003e\u003e=0,e\u003c=r)return\u0022\u0022;for(t||(t=\u0022utf8\u0022);;)switch(t)\u007bcase\u0022hex\u0022:return I(this,r,e);case\u0022utf8\u0022:case\u0022utf-8\u0022:return k(this,r,e);case\u0022ascii\u0022:return T(this,r,e);case\u0022latin1\u0022:case\u0022binary\u0022:return S(this,r,e);case\u0022base64\u0022:return R(this,r,e);case\u0022ucs2\u0022:case\u0022ucs-2\u0022:case\u0022utf16le\u0022:case\u0022utf-16le\u0022:return Y(this,r,e);default:if(n)throw new TypeError(\u0022Unknown encoding: \u0022+t);t=(t+\u0022\u0022).toLowerCase(),n=!0\u007d\u007dfunction b(t,r,e)\u007bvar n=t[r];t[r]=t[e],t[e]=n\u007dfunction w(t,r,e,n,i)\u007bif(0===t.length)return-1;if(\u0022string\u0022==typeof e?(n=e,e=0):e\u003e2147483647?e=2147483647:e\u003c-2147483648\u0026\u0026(e=-2147483648),e=+e,isNaN(e)\u0026\u0026(e=i?0:t.length-1),e\u003c0\u0026\u0026(e=t.length+e),e\u003e=t.length)\u007bif(i)return-1;e=t.length-1\u007delse if(e\u003c0)\u007bif(!i)return-1;e=0\u007dif(\u0022string\u0022==typeof r\u0026\u0026(r=Buffer.from(r,n)),Buffer.isBuffer(r))return 0===r.length?-1:E(t,r,e,n,i);if(\u0022number\u0022==typeof r)return r=255\u0026r,Buffer.TYPED_ARRAY_SUPPORT\u0026\u0026\u0022function\u0022==typeof Uint8Array.prototype.indexOf?i?Uint8Array.prototype.indexOf.call(t,r,e):Uint8Array.prototype.lastIndexOf.call(t,r,e):E(t,[r],e,n,i);throw new TypeError(\u0022val must be string, number or Buffer\u0022)\u007dfunction E(t,r,e,n,i)\u007bfunction o(t,r)\u007breturn 1===f?t[r]:t.readUInt16BE(r*f)\u007dvar f=1,u=t.length,a=r.length;if(void 0!==n\u0026\u0026(n=String(n).toLowerCase(),\u0022ucs2\u0022===n||\u0022ucs-2\u0022===n||\u0022utf16le\u0022===n||\u0022utf-16le\u0022===n))\u007bif(t.length\u003c2||r.length\u003c2)return-1;f=2,u/=2,a/=2,e/=2\u007dvar s;if(i)\u007bvar c=-1;for(s=e;s\u003cu;s++)if(o(t,s)===o(r,c===-1?0:s-c))\u007bif(c===-1\u0026\u0026(c=s),s-c+1===a)return c*f\u007delse c!==-1\u0026\u0026(s-=s-c),c=-1\u007delse for(e+a\u003eu\u0026\u0026(e=u-a),s=e;s\u003e=0;s--)\u007bfor(var h=!0,l=0;l\u003ca;l++)if(o(t,s+l\)\!==o(r,l))\u007bh=!1;break\u007dif(h)return s\u007dreturn-1\u007dfunction A(t,r,e,n)\u007be=Number(e)||0;var i=t.length-e;n?(n=Number(n),n\u003ei\u0026\u0026(n=i)):n=i;var o=r.length;if(o%2!==0)throw new TypeError(\u0022Invalid hex string\u0022);n\u003eo/2\u0026\u0026(n=o/2);for(var f=0;f\u003cn;++f)\u007bvar u=parseInt(r.substr(2*f,2),16);if(isNaN(u))return f;t[e+f]=u\u007dreturn f\u007dfunction m(t,r,e,n)\u007breturn G(q(r,t.length-e),t,e,n)\u007dfunction x(t,r,e,n)\u007breturn G(W(r),t,e,n)\u007dfunction B(t,r,e,n)\u007breturn x(t,r,e,n)\u007dfunction U(t,r,e,n)\u007breturn G(X(r),t,e,n)\u007dfunction P(t,r,e,n)\u007breturn G(J(r,t.length-e),t,e,n)\u007dfunction R(t,r,e)\u007breturn 0===r\u0026\u0026e===t.length?Z.fromByteArray(t):Z.fromByteArray(t.slice(r,e))\u007dfunction k(t,r,e)\u007be=Math.min(t.length,e);for(var n=[],i=r;i\u003ce;)\u007bvar o=t[i],f=null,u=o\u003e239?4:o\u003e223?3:o\u003e191?2:1;if(i+u\u003c=e)\u007bvar a,s,c,h;switch(u)\u007bcase 1:o\u003c128\u0026\u0026(f=o);break;case 2:a=t[i+1],128===(192\u0026a)\u0026\u0026(h=(31\u0026o)\u003c\u003c6|63\u0026a,h\u003e127\u0026\u0026(f=h));break;case 3:a=t[i+1],s=t[i+2],128===(192\u0026a)\u0026\u0026128===(192\u0026s)\u0026\u0026(h=(15\u0026o)\u003c\u003c12|(63\u0026a)\u003c\u003c6|63\u0026s,h\u003e2047\u0026\u0026(h\u003c55296||h\u003e57343)\u0026\u0026(f=h));break;case 4:a=t[i+1],s=t[i+2],c=t[i+3],128===(192\u0026a)\u0026\u0026128===(192\u0026s)\u0026\u0026128===(192\u0026c)\u0026\u0026(h=(15\u0026o)\u003c\u003c18|(63\u0026a)\u003c\u003c12|(63\u0026s)\u003c\u003c6|63\u0026c,h\u003e65535\u0026\u0026h\u003c1114112\u0026\u0026(f=h))\u007d\u007dnull===f?(f=65533,u=1):f\u003e65535\u0026\u0026(f-=65536,n.push(f\u003e\u003e\u003e10\u00261023|55296),f=56320|1023\u0026f),n.push(f),i+=u\u007dreturn _(n)\u007dfunction _(t)\u007bvar r=t.length;if(r\u003c=$)return String.fromCharCode.apply(String,t);for(var e=\u0022\u0022,n=0;n\u003cr;)e+=String.fromCharCode.apply(String,t.slice(n,n+=$));return e\u007dfunction T(t,r,e)\u007bvar n=\u0022\u0022;e=Math.min(t.length,e);for(var i=r;i\u003ce;++i)n+=String.fromCharCode(127\u0026t[i]);return n\u007dfunction S(t,r,e)\u007bvar n=\u0022\u0022;e=Math.min(t.length,e);for(var i=r;i\u003ce;++i)n+=String.fromCharCode(t[i]);return n\u007dfunction I(t,r,e)\u007bvar n=t.length;(!r||r\u003c0)\u0026\u0026(r=0),(!e||e\u003c0||e\u003en)\u0026\u0026(e=n);for(var i=\u0022\u0022,o=r;o\u003ce;++o)i+=V(t[o]);return i\u007dfunction Y(t,r,e)\u007bfor(var n=t.slice(r,e),i=\u0022\u0022,o=0;o\u003cn.length;o+=2)i+=String.fromCharCode(n[o]+256*n[o+1]);return i\u007dfunction C(t,r,e)\u007bif(t%1!==0||t\u003c0)throw new RangeError(\u0022offset is not uint\u0022);if(t+r\u003ee)throw new RangeError(\u0022Trying to access beyond buffer length\u0022)\u007dfunction D(t,r,e,n,i,o)\u007bif(!Buffer.isBuffer(t))throw new TypeError(\u0027\u0022buffer\u0022 argument must be a Buffer instance\u0027);if(r\u003ei||r\u003co)throw new RangeError(\u0027\u0022value\u0022 argument is out of bounds\u0027);if(e+n\u003et.length)throw new RangeError(\u0022Index out of range\u0022)\u007dfunction O(t,r,e,n)\u007br\u003c0\u0026\u0026(r=65535+r+1);for(var i=0,o=Math.min(t.length-e,2);i\u003co;++i)t[e+i]=(r\u0026255\u003c\u003c8*(n?i:1-i))\u003e\u003e\u003e8*(n?i:1-i)\u007dfunction L(t,r,e,n)\u007br\u003c0\u0026\u0026(r=4294967295+r+1);for(var i=0,o=Math.min(t.length-e,4);i\u003co;++i)t[e+i]=r\u003e\u003e\u003e8*(n?i:3-i)\u0026255\u007dfunction M(t,r,e,n,i,o)\u007bif(e+n\u003et.length)throw new RangeError(\u0022Index out of range\u0022);if(e\u003c0)throw new RangeError(\u0022Index out of range\u0022)\u007dfunction N(t,r,e,n,i)\u007breturn i||M(t,r,e,4,3.4028234663852886e38,-3.4028234663852886e38),K.write(t,r,e,n,23,4),e+4\u007dfunction F(t,r,e,n,i)\u007breturn i||M(t,r,e,8,1.7976931348623157e308,-1.7976931348623157e308),K.write(t,r,e,n,52,8),e+8\u007dfunction j(t)\u007b\r\nif(t=z(t).replace(tt,\u0022\u0022),t.length\u003c2)return\u0022\u0022;for(;t.length%4!==0;)t+=\u0022=\u0022;return t\u007dfunction z(t)\u007breturn t.trim?t.trim():t.replace(/^\u005cs+|\u005cs+$/g,\u0022\u0022)\u007dfunction V(t)\u007breturn t\u003c16?\u00220\u0022+t.toString(16):t.toString(16)\u007dfunction q(t,r)\u007br=r||1/0;for(var e,n=t.length,i=null,o=[],f=0;f\u003cn;++f)\u007bif(e=t.charCodeAt(f),e\u003e55295\u0026\u0026e\u003c57344)\u007bif(!i)\u007bif(e\u003e56319)\u007b(r-=3)\u003e-1\u0026\u0026o.push(239,191,189);continue\u007dif(f+1===n)\u007b(r-=3)\u003e-1\u0026\u0026o.push(239,191,189);continue\u007di=e;continue\u007dif(e\u003c56320)\u007b(r-=3)\u003e-1\u0026\u0026o.push(239,191,189),i=e;continue\u007de=(i-55296\u003c\u003c10|e-56320)+65536\u007delse i\u0026\u0026(r-=3)\u003e-1\u0026\u0026o.push(239,191,189);if(i=null,e\u003c128)\u007bif((r-=1)\u003c0)break;o.push(e)\u007delse if(e\u003c2048)\u007bif((r-=2)\u003c0)break;o.push(e\u003e\u003e6|192,63\u0026e|128)\u007delse if(e\u003c65536)\u007bif((r-=3)\u003c0)break;o.push(e\u003e\u003e12|224,e\u003e\u003e6\u002663|128,63\u0026e|128)\u007delse\u007bif(!(e\u003c1114112))throw new Error(\u0022Invalid code point\u0022);if((r-=4)\u003c0)break;o.push(e\u003e\u003e18|240,e\u003e\u003e12\u002663|128,e\u003e\u003e6\u002663|128,63\u0026e|128)\u007d\u007dreturn o\u007dfunction W(t)\u007bfor(var r=[],e=0;e\u003ct.length;++e)r.push(255\u0026t.charCodeAt(e));return r\u007dfunction J(t,r)\u007bfor(var e,n,i,o=[],f=0;f\u003ct.length\u0026\u0026!((r-=2)\u003c0);++f)e=t.charCodeAt(f),n=e\u003e\u003e8,i=e%256,o.push(i),o.push(n);return o\u007dfunction X(t)\u007breturn Z.toByteArray(j(t))\u007dfunction G(t,r,e,n)\u007bfor(var i=0;i\u003cn\u0026\u0026!(i+e\u003e=r.length||i\u003e=t.length);++i)r[i+e]=t[i];return i\u007dfunction H(t)\u007breturn t!==t\u007dvar Z=t(\u0022base64-js\u0022),K=t(\u0022ieee754\u0022),Q=t(\u0022isarray\u0022);e.Buffer=Buffer,e.SlowBuffer=y,e.INSPECT_MAX_BYTES=50,Buffer.TYPED_ARRAY_SUPPORT=void 0!==r.TYPED_ARRAY_SUPPORT?r.TYPED_ARRAY_SUPPORT:n(),e.kMaxLength=i(),Buffer.poolSize=8192,Buffer._augment=function(t)\u007breturn t.__proto__=Buffer.prototype,t\u007d,Buffer.from=function(t,r,e)\u007breturn f(null,t,r,e)\u007d,Buffer.TYPED_ARRAY_SUPPORT\u0026\u0026(Buffer.prototype.__proto__=Uint8Array.prototype,Buffer.__proto__=Uint8Array,\u0022undefined\u0022!=typeof Symbol\u0026\u0026Symbol.species\u0026\u0026Buffer[Symbol.species]===Buffer\u0026\u0026Object.defineProperty(Buffer,Symbol.species,\u007bvalue:null,configurable:!0\u007d)),Buffer.alloc=function(t,r,e)\u007breturn a(null,t,r,e)\u007d,Buffer.allocUnsafe=function(t)\u007breturn s(null,t)\u007d,Buffer.allocUnsafeSlow=function(t)\u007breturn s(null,t)\u007d,Buffer.isBuffer=function(t)\u007breturn!(null==t||!t._isBuffer)\u007d,Buffer.compare=function(t,r)\u007bif(!Buffer.isBuffer(t)||!Buffer.isBuffer(r))throw new TypeError(\u0022Arguments must be Buffers\u0022);if(t===r)return 0;for(var e=t.length,n=r.length,i=0,o=Math.min(e,n);i\u003co;++i)if(t[i]!==r[i])\u007be=t[i],n=r[i];break\u007dreturn e\u003cn?-1:n\u003ce?1:0\u007d,Buffer.isEncoding=function(t)\u007bswitch(String(t).toLowerCase())\u007bcase\u0022hex\u0022:case\u0022utf8\u0022:case\u0022utf-8\u0022:case\u0022ascii\u0022:case\u0022latin1\u0022:case\u0022binary\u0022:case\u0022base64\u0022:case\u0022ucs2\u0022:case\u0022ucs-2\u0022:case\u0022utf16le\u0022:case\u0022utf-16le\u0022:return!0;default:return!1\u007d\u007d,Buffer.concat=function(t,r)\u007bif(!Q(t))throw new TypeError(\u0027\u0022list\u0022 argument must be an Array of Buffers\u0027);if(0===t.length)return Buffer.alloc(0);var e;if(void 0===r)for(r=0,e=0;e\u003ct.length;++e)r+=t[e].length;var n=Buffer.allocUnsafe(r),i=0;for(e=0;e\u003ct.length;++e)\u007bvar o=t[e];if(!Buffer.isBuffer(o))throw new TypeError(\u0027\u0022list\u0022 argument must be an Array of Buffers\u0027);o.copy(n,i),i+=o.length\u007dreturn n\u007d,Buffer.byteLength=v,Buffer.prototype._isBuffer=!0,Buffer.prototype.swap16=function()\u007bvar t=this.length;if(t%2!==0)throw new RangeError(\u0022Buffer size must be a multiple of 16-bits\u0022);for(var r=0;r\u003ct;r+=2)b(this,r,r+1);return this\u007d,Buffer.prototype.swap32=function()\u007bvar t=this.length;if(t%4!==0)throw new RangeError(\u0022Buffer size must be a multiple of 32-bits\u0022);for(var r=0;r\u003ct;r+=4)b(this,r,r+3),b(this,r+1,r+2);return this\u007d,Buffer.prototype.swap64=function()\u007bvar t=this.length;if(t%8!==0)throw new RangeError(\u0022Buffer size must be a multiple of 64-bits\u0022);for(var r=0;r\u003ct;r+=8)b(this,r,r+7),b(this,r+1,r+6),b(this,r+2,r+5),b(this,r+3,r+4);return this\u007d,Buffer.prototype.toString=function()\u007bvar t=0|this.length;return 0===t?\u0022\u0022:0===arguments.length?k(this,0,t):g.apply(this,arguments)\u007d,Buffer.prototype.equals=function(t)\u007bif(!Buffer.isBuffer(t))throw new TypeError(\u0022Argument must be a Buffer\u0022);return this===t||0===Buffer.compare(this,t)\u007d,Buffer.prototype.inspect=function()\u007bvar t=\u0022\u0022,r=e.INSPECT_MAX_BYTES;return this.length\u003e0\u0026\u0026(t=this.toString(\u0022hex\u0022,0,r).match(/.\u007b2\u007d/g).join(\u0022 \u0022),this.length\u003er\u0026\u0026(t+=\u0022 ... \u0022)),\u0022\u003cBuffer \u0022+t+\u0022\u003e\u0022\u007d,Buffer.prototype.compare=function(t,r,e,n,i)\u007bif(!Buffer.isBuffer(t))throw new TypeError(\u0022Argument must be a Buffer\u0022);if(void 0===r\u0026\u0026(r=0),void 0===e\u0026\u0026(e=t?t.length:0),void 0===n\u0026\u0026(n=0),void 0===i\u0026\u0026(i=this.length),r\u003c0||e\u003et.length||n\u003c0||i\u003ethis.length)throw new RangeError(\u0022out of range index\u0022);if(n\u003e=i\u0026\u0026r\u003e=e)return 0;if(n\u003e=i)return-1;if(r\u003e=e)return 1;if(r\u003e\u003e\u003e=0,e\u003e\u003e\u003e=0,n\u003e\u003e\u003e=0,i\u003e\u003e\u003e=0,this===t)return 0;for(var o=i-n,f=e-r,u=Math.min(o,f),a=this.slice(n,i),s=t.slice(r,e),c=0;c\u003cu;++c)if(a[c]!==s[c])\u007bo=a[c],f=s[c];break\u007dreturn o\u003cf?-1:f\u003co?1:0\u007d,Buffer.prototype.includes=function(t,r,e)\u007breturn this.indexOf(t,r,e\)\!==-1\u007d,Buffer.prototype.indexOf=function(t,r,e)\u007breturn w(this,t,r,e,!0)\u007d,Buffer.prototype.lastIndexOf=function(t,r,e)\u007breturn w(this,t,r,e,!1)\u007d,Buffer.prototype.write=function(t,r,e,n)\u007bif(void 0===r)n=\u0022utf8\u0022,e=this.length,r=0;else if(void 0===e\u0026\u0026\u0022string\u0022==typeof r)n=r,e=this.length,r=0;else\u007bif(!isFinite(r))throw new Error(\u0022Buffer.write(string, encoding, offset[, length]) is no longer supported\u0022);r=0|r,isFinite(e)?(e=0|e,void 0===n\u0026\u0026(n=\u0022utf8\u0022)):(n=e,e=void 0)\u007dvar i=this.length-r;if((void 0===e||e\u003ei)\u0026\u0026(e=i),t.length\u003e0\u0026\u0026(e\u003c0||r\u003c0)||r\u003ethis.length)throw new RangeError(\u0022Attempt to write outside buffer bounds\u0022);n||(n=\u0022utf8\u0022);for(var o=!1;;)switch(n)\u007bcase\u0022hex\u0022:return A(this,t,r,e);case\u0022utf8\u0022:case\u0022utf-8\u0022:return m(this,t,r,e);case\u0022ascii\u0022:return x(this,t,r,e);case\u0022latin1\u0022:case\u0022binary\u0022:return B(this,t,r,e);case\u0022base64\u0022:return U(this,t,r,e);case\u0022ucs2\u0022:case\u0022ucs-2\u0022:case\u0022utf16le\u0022:case\u0022utf-16le\u0022:return P(this,t,r,e);default:if(o)throw new TypeError(\u0022Unknown encoding: \u0022+n);n=(\u0022\u0022+n).toLowerCase(),o=!0\u007d\u007d,Buffer.prototype.toJSON=function()\u007breturn\u007btype:\u0022Buffer\u0022,data:Array.prototype.slice.call(this._arr||this,0)\u007d\u007d;var $=4096;Buffer.prototype.slice=function(t,r)\u007bvar e=this.length;t=~~t,r=void 0===r?e:~~r,t\u003c0?(t+=e,t\u003c0\u0026\u0026(t=0)):t\u003ee\u0026\u0026(t=e),r\u003c0?(r+=e,r\u003c0\u0026\u0026(r=0)):r\u003ee\u0026\u0026(r=e),r\u003ct\u0026\u0026(r=t);var n;if(Buffer.TYPED_ARRAY_SUPPORT)n=this.subarray(t,r),n.__proto__=Buffer.prototype;else\u007bvar i=r-t;n=new Buffer(i,void 0);for(var o=0;o\u003ci;++o)n[o]=this[o+t]\u007dreturn n\u007d,Buffer.prototype.readUIntLE=function(t,r,e)\u007bt=0|t,r=0|r,e||C(t,r,this.length);for(var n=this[t],i=1,o=0;++o\u003cr\u0026\u0026(i*=256);)n+=this[t+o]*i;return n\u007d,Buffer.prototype.readUIntBE=function(t,r,e)\u007bt=0|t,r=0|r,e||C(t,r,this.length);for(var n=this[t+--r],i=1;r\u003e0\u0026\u0026(i*=256);)n+=this[t+--r]*i;return n\u007d,Buffer.prototype.readUInt8=function(t,r)\u007breturn r||C(t,1,this.length),this[t]\u007d,Buffer.prototype.readUInt16LE=function(t,r)\u007breturn r||C(t,2,this.length),this[t]|this[t+1]\u003c\u003c8\u007d,Buffer.prototype.readUInt16BE=function(t,r)\u007breturn r||C(t,2,this.length),this[t]\u003c\u003c8|this[t+1]\u007d,Buffer.prototype.readUInt32LE=function(t,r)\u007breturn r||C(t,4,this.length),(this[t]|this[t+1]\u003c\u003c8|this[t+2]\u003c\u003c16)+16777216*this[t+3]\u007d,Buffer.prototype.readUInt32BE=function(t,r)\u007breturn r||C(t,4,this.length),16777216*this[t]+(this[t+1]\u003c\u003c16|this[t+2]\u003c\u003c8|this[t+3])\u007d,Buffer.prototype.readIntLE=function(t,r,e)\u007bt=0|t,r=0|r,e||C(t,r,this.length);for(var n=this[t],i=1,o=0;++o\u003cr\u0026\u0026(i*=256);)n+=this[t+o]*i;return i*=128,n\u003e=i\u0026\u0026(n-=Math.pow(2,8*r)),n\u007d,Buffer.prototype.readIntBE=function(t,r,e)\u007bt=0|t,r=0|r,e||C(t,r,this.length);for(var n=r,i=1,o=this[t+--n];n\u003e0\u0026\u0026(i*=256);)o+=this[t+--n]*i;return i*=128,o\u003e=i\u0026\u0026(o-=Math.pow(2,8*r)),o\u007d,Buffer.prototype.readInt8=function(t,r)\u007breturn r||C(t,1,this.length),128\u0026this[t]?(255-this[t]+1)*-1:this[t]\u007d,Buffer.prototype.readInt16LE=function(t,r)\u007br||C(t,2,this.length);var e=this[t]|this[t+1]\u003c\u003c8;return 32768\u0026e?4294901760|e:e\u007d,Buffer.prototype.readInt16BE=function(t,r)\u007br||C(t,2,this.length);var e=this[t+1]|this[t]\u003c\u003c8;return 32768\u0026e?4294901760|e:e\u007d,Buffer.prototype.readInt32LE=function(t,r)\u007breturn r||C(t,4,this.length),this[t]|this[t+1]\u003c\u003c8|this[t+2]\u003c\u003c16|this[t+3]\u003c\u003c24\u007d,Buffer.prototype.readInt32BE=function(t,r)\u007breturn r||C(t,4,this.length),this[t]\u003c\u003c24|this[t+1]\u003c\u003c16|this[t+2]\u003c\u003c8|this[t+3]\u007d,Buffer.prototype.readFloatLE=function(t,r)\u007breturn r||C(t,4,this.length),K.read(this,t,!0,23,4)\u007d,Buffer.prototype.readFloatBE=function(t,r)\u007breturn r||C(t,4,this.length),K.read(this,t,!1,23,4)\u007d,Buffer.prototype.readDoubleLE=function(t,r)\u007breturn r||C(t,8,this.length),K.read(this,t,!0,52,8)\u007d,Buffer.prototype.readDoubleBE=function(t,r)\u007breturn r||C(t,8,this.length),K.read(this,t,!1,52,8)\u007d,Buffer.prototype.writeUIntLE=function(t,r,e,n)\u007bif(t=+t,r=0|r,e=0|e,!n)\u007bvar i=Math.pow(2,8*e)-1;D(this,t,r,e,i,0)\u007dvar o=1,f=0;for(this[r]=255\u0026t;++f\u003ce\u0026\u0026(o*=256);)this[r+f]=t/o\u0026255;return r+e\u007d,Buffer.prototype.writeUIntBE=function(t,r,e,n)\u007bif(t=+t,r=0|r,e=0|e,!n)\u007bvar i=Math.pow(2,8*e)-1;D(this,t,r,e,i,0)\u007dvar o=e-1,f=1;for(this[r+o]=255\u0026t;--o\u003e=0\u0026\u0026(f*=256);)this[r+o]=t/f\u0026255;return r+e\u007d,Buffer.prototype.writeUInt8=function(t,r,e)\u007breturn t=+t,r=0|r,e||D(this,t,r,1,255,0),Buffer.TYPED_ARRAY_SUPPORT||(t=Math.floor(t)),this[r]=255\u0026t,r+1\u007d,Buffer.prototype.writeUInt16LE=function(t,r,e)\u007breturn t=+t,r=0|r,e||D(this,t,r,2,65535,0),Buffer.TYPED_ARRAY_SUPPORT?(this[r]=255\u0026t,this[r+1]=t\u003e\u003e\u003e8):O(this,t,r,!0),r+2\u007d,Buffer.prototype.writeUInt16BE=function(t,r,e)\u007breturn t=+t,r=0|r,e||D(this,t,r,2,65535,0),Buffer.TYPED_ARRAY_SUPPORT?(this[r]=t\u003e\u003e\u003e8,this[r+1]=255\u0026t):O(this,t,r,!1),r+2\u007d,Buffer.prototype.writeUInt32LE=function(t,r,e)\u007breturn t=+t,r=0|r,e||D(this,t,r,4,4294967295,0),Buffer.TYPED_ARRAY_SUPPORT?(this[r+3]=t\u003e\u003e\u003e24,this[r+2]=t\u003e\u003e\u003e16,this[r+1]=t\u003e\u003e\u003e8,this[r]=255\u0026t):L(this,t,r,!0),r+4\u007d,Buffer.prototype.writeUInt32BE=function(t,r,e)\u007breturn t=+t,r=0|r,e||D(this,t,r,4,4294967295,0),Buffer.TYPED_ARRAY_SUPPORT?(this[r]=t\u003e\u003e\u003e24,this[r+1]=t\u003e\u003e\u003e16,this[r+2]=t\u003e\u003e\u003e8,this[r+3]=255\u0026t):L(this,t,r,!1),r+4\u007d,Buffer.prototype.writeIntLE=function(t,r,e,n)\u007bif(t=+t,r=0|r,!n)\u007bvar i=Math.pow(2,8*e-1);D(this,t,r,e,i-1,-i)\u007dvar o=0,f=1,u=0;for(this[r]=255\u0026t;++o\u003ce\u0026\u0026(f*=256);)t\u003c0\u0026\u00260===u\u0026\u00260!==this[r+o-1]\u0026\u0026(u=1),this[r+o]=(t/f\u003e\u003e0)-u\u0026255;return r+e\u007d,Buffer.prototype.writeIntBE=function(t,r,e,n)\u007bif(t=+t,r=0|r,!n)\u007bvar i=Math.pow(2,8*e-1);D(this,t,r,e,i-1,-i)\u007dvar o=e-1,f=1,u=0;for(this[r+o]=255\u0026t;--o\u003e=0\u0026\u0026(f*=256);)t\u003c0\u0026\u00260===u\u0026\u00260!==this[r+o+1]\u0026\u0026(u=1),this[r+o]=(t/f\u003e\u003e0)-u\u0026255;return r+e\u007d,Buffer.prototype.writeInt8=function(t,r,e)\u007breturn t=+t,r=0|r,e||D(this,t,r,1,127,-128),Buffer.TYPED_ARRAY_SUPPORT||(t=Math.floor(t)),t\u003c0\u0026\u0026(t=255+t+1),this[r]=255\u0026t,r+1\u007d,Buffer.prototype.writeInt16LE=function(t,r,e)\u007breturn t=+t,r=0|r,e||D(this,t,r,2,32767,-32768),Buffer.TYPED_ARRAY_SUPPORT?(this[r]=255\u0026t,this[r+1]=t\u003e\u003e\u003e8):O(this,t,r,!0),r+2\u007d,Buffer.prototype.writeInt16BE=function(t,r,e)\u007breturn t=+t,r=0|r,e||D(this,t,r,2,32767,-32768),Buffer.TYPED_ARRAY_SUPPORT?(this[r]=t\u003e\u003e\u003e8,this[r+1]=255\u0026t):O(this,t,r,!1),r+2\u007d,Buffer.prototype.writeInt32LE=function(t,r,e)\u007breturn t=+t,r=0|r,e||D(this,t,r,4,2147483647,-2147483648),Buffer.TYPED_ARRAY_SUPPORT?(this[r]=255\u0026t,this[r+1]=t\u003e\u003e\u003e8,this[r+2]=t\u003e\u003e\u003e16,this[r+3]=t\u003e\u003e\u003e24):L(this,t,r,!0),r+4\u007d,Buffer.prototype.writeInt32BE=function(t,r,e)\u007breturn t=+t,r=0|r,e||D(this,t,r,4,2147483647,-2147483648),t\u003c0\u0026\u0026(t=4294967295+t+1),Buffer.TYPED_ARRAY_SUPPORT?(this[r]=t\u003e\u003e\u003e24,this[r+1]=t\u003e\u003e\u003e16,this[r+2]=t\u003e\u003e\u003e8,this[r+3]=255\u0026t):L(this,t,r,!1),r+4\u007d,Buffer.prototype.writeFloatLE=function(t,r,e)\u007breturn N(this,t,r,!0,e)\u007d,Buffer.prototype.writeFloatBE=function(t,r,e)\u007breturn N(this,t,r,!1,e)\u007d,Buffer.prototype.writeDoubleLE=function(t,r,e)\u007breturn F(this,t,r,!0,e)\u007d,Buffer.prototype.writeDoubleBE=function(t,r,e)\u007breturn F(this,t,r,!1,e)\u007d,Buffer.prototype.copy=function(t,r,e,n)\u007bif(e||(e=0),n||0===n||(n=this.length),r\u003e=t.length\u0026\u0026(r=t.length),r||(r=0),n\u003e0\u0026\u0026n\u003ce\u0026\u0026(n=e),n===e)return 0;if(0===t.length||0===this.length)return 0;if(r\u003c0)throw new RangeError(\u0022targetStart out of bounds\u0022);if(e\u003c0||e\u003e=this.length)throw new RangeError(\u0022sourceStart out of bounds\u0022);if(n\u003c0)throw new RangeError(\u0022sourceEnd out of bounds\u0022);n\u003ethis.length\u0026\u0026(n=this.length),t.length-r\u003cn-e\u0026\u0026(n=t.length-r+e);var i,o=n-e;if(this===t\u0026\u0026e\u003cr\u0026\u0026r\u003cn)for(i=o-1;i\u003e=0;--i)t[i+r]=this[i+e];else if(o\u003c1e3||!Buffer.TYPED_ARRAY_SUPPORT)for(i=0;i\u003co;++i)t[i+r]=this[i+e];else Uint8Array.prototype.set.call(t,this.subarray(e,e+o),r);return o\u007d,Buffer.prototype.fill=function(t,r,e,n)\u007bif(\u0022string\u0022==typeof t)\u007bif(\u0022string\u0022==typeof r?(n=r,r=0,e=this.length):\u0022string\u0022==typeof e\u0026\u0026(n=e,e=this.length),1===t.length)\u007bvar i=t.charCodeAt(0);i\u003c256\u0026\u0026(t=i)\u007dif(void 0!==n\u0026\u0026\u0022string\u0022!=typeof n)throw new TypeError(\u0022encoding must be a string\u0022);if(\u0022string\u0022==typeof n\u0026\u0026!Buffer.isEncoding(n))throw new TypeError(\u0022Unknown encoding: \u0022+n)\u007delse\u0022number\u0022==typeof t\u0026\u0026(t=255\u0026t);if(r\u003c0||this.length\u003cr||this.length\u003ce)throw new RangeError(\u0022Out of range index\u0022);if(e\u003c=r)return this;r\u003e\u003e\u003e=0,e=void 0===e?this.length:e\u003e\u003e\u003e0,t||(t=0);var o;if(\u0022number\u0022==typeof t)for(o=r;o\u003ce;++o)this[o]=t;else\u007bvar f=Buffer.isBuffer(t)?t:q(new Buffer(t,n).toString()),u=f.length;for(o=0;o\u003ce-r;++o)this[o+r]=f[o%u]\u007dreturn this\u007d;var tt=/[^+\u005c/0-9A-Za-z-_]/g\u007d).call(this,\u0022undefined\u0022!=typeof global?global:\u0022undefined\u0022!=typeof self?self:\u0022undefined\u0022!=typeof window?window:\u007b\u007d)\u007d,\u007b\u0022base64-js\u0022:30,ieee754:32,isarray:34\u007d],30:[function(t,r,e)\u007b\u0022use strict\u0022;function n(t)\u007bvar r=t.length;if(r%4\u003e0)throw new Error(\u0022Invalid string. Length must be a multiple of 4\u0022);return\u0022=\u0022===t[r-2]?2:\u0022=\u0022===t[r-1]?1:0\u007dfunction i(t)\u007breturn 3*t.length/4-n(t)\u007dfunction o(t)\u007bvar r,e,i,o,f,u,a=t.length;f=n(t),u=new h(3*a/4-f),i=f\u003e0?a-4:a;var s=0;for(r=0,e=0;r\u003ci;r+=4,e+=3)o=c[t.charCodeAt(r)]\u003c\u003c18|c[t.charCodeAt(r+1)]\u003c\u003c12|c[t.charCodeAt(r+2)]\u003c\u003c6|c[t.charCodeAt(r+3)],u[s++]=o\u003e\u003e16\u0026255,u[s++]=o\u003e\u003e8\u0026255,u[s++]=255\u0026o;return 2===f?(o=c[t.charCodeAt(r)]\u003c\u003c2|c[t.charCodeAt(r+1)]\u003e\u003e4,u[s++]=255\u0026o):1===f\u0026\u0026(o=c[t.charCodeAt(r)]\u003c\u003c10|c[t.charCodeAt(r+1)]\u003c\u003c4|c[t.charCodeAt(r+2)]\u003e\u003e2,u[s++]=o\u003e\u003e8\u0026255,u[s++]=255\u0026o),u\u007dfunction f(t)\u007breturn s[t\u003e\u003e18\u002663]+s[t\u003e\u003e12\u002663]+s[t\u003e\u003e6\u002663]+s[63\u0026t]\u007dfunction u(t,r,e)\u007bfor(var n,i=[],o=r;o\u003ce;o+=3)n=(t[o]\u003c\u003c16)+(t[o+1]\u003c\u003c8)+t[o+2],i.push(f(n));return i.join(\u0022\u0022)\u007dfunction a(t)\u007bfor(var r,e=t.length,n=e%3,i=\u0022\u0022,o=[],f=16383,a=0,c=e-n;a\u003cc;a+=f)o.push(u(t,a,a+f\u003ec?c:a+f));return 1===n?(r=t[e-1],i+=s[r\u003e\u003e2],i+=s[r\u003c\u003c4\u002663],i+=\u0022==\u0022):2===n\u0026\u0026(r=(t[e-2]\u003c\u003c8)+t[e-1],i+=s[r\u003e\u003e10],i+=s[r\u003e\u003e4\u002663],i+=s[r\u003c\u003c2\u002663],i+=\u0022=\u0022),o.push(i),o.join(\u0022\u0022)\u007de.byteLength=i,e.toByteArray=o,e.fromByteArray=a;for(var s=[],c=[],h=\u0022undefined\u0022!=typeof Uint8Array?Uint8Array:Array,l=\u0022ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/\u0022,p=0,d=l.length;p\u003cd;++p)s[p]=l[p],c[l.charCodeAt(p)]=p;c[\u0022-\u0022.charCodeAt(0)]=62,c[\u0022_\u0022.charCodeAt(0)]=63\u007d,\u007b\u007d],31:[function(t,r,e)\u007bfunction n()\u007bif(!(this instanceof n))return new n\u007d!function(t)\u007bfunction e(t)\u007bfor(var r in s)t[r]=s[r];return t\u007dfunction n(t,r)\u007breturn u(this,t).push(r),this\u007dfunction i(t,r)\u007bfunction e()\u007bo.call(n,t,e),r.apply(this,arguments)\u007dvar n=this;return e.originalListener=r,u(n,t).push(e),n\u007dfunction o(t,r)\u007bfunction e(t)\u007breturn t!==r\u0026\u0026t.originalListener!==r\u007dvar n,i=this;if(arguments.length)\u007bif(r)\u007bif(n=u(i,t,!0))\u007bif(n=n.filter(e),!n.length)return o.call(i,t);i[a][t]=n\u007d\u007delse if(n=i[a],n\u0026\u0026(delete n[t],!Object.keys(n).length))return o.call(i)\u007delse delete i[a];return i\u007dfunction f(t,r)\u007bfunction e(t)\u007bt.call(o)\u007dfunction n(t)\u007bt.call(o,r)\u007dfunction i(t)\u007bt.apply(o,s)\u007dvar o=this,f=u(o,t,!0);if(!f)return!1;var a=arguments.length;if(1===a)f.forEach(e);else if(2===a)f.forEach(n);else\u007bvar s=Array.prototype.slice.call(arguments,1);f.forEach(i)\u007dreturn!!f.length\u007dfunction u(t,r,e)\u007bif(!e||t[a])\u007bvar n=t[a]||(t[a]=\u007b\u007d);return n[r]||(n[r]=[])\u007d\u007d\u0022undefined\u0022!=typeof r\u0026\u0026(r.exports=t);var a=\u0022listeners\u0022,s=\u007bon:n,once:i,off:o,emit:f\u007d;e(t.prototype),t.mixin=e\u007d(n)\u007d,\u007b\u007d],32:[function(t,r,e)\u007be.read=function(t,r,e,n,i)\u007bvar o,f,u=8*i-n-1,a=(1\u003c\u003cu)-1,s=a\u003e\u003e1,c=-7,h=e?i-1:0,l=e?-1:1,p=t[r+h];for(h+=l,o=p\u0026(1\u003c\u003c-c)-1,p\u003e\u003e=-c,c+=u;c\u003e0;o=256*o+t[r+h],h+=l,c-=8);for(f=o\u0026(1\u003c\u003c-c)-1,o\u003e\u003e=-c,c+=n;c\u003e0;f=256*f+t[r+h],h+=l,c-=8);if(0===o)o=1-s;else\u007bif(o===a)return f?NaN:(p?-1:1)*(1/0);f+=Math.pow(2,n),o-=s\u007dreturn(p?-1:1)*f*Math.pow(2,o-n)\u007d,e.write=function(t,r,e,n,i,o)\u007bvar f,u,a,s=8*o-i-1,c=(1\u003c\u003cs)-1,h=c\u003e\u003e1,l=23===i?Math.pow(2,-24)-Math.pow(2,-77):0,p=n?0:o-1,d=n?1:-1,y=r\u003c0||0===r\u0026\u00261/r\u003c0?1:0;for(r=Math.abs(r),isNaN(r)||r===1/0?(u=isNaN(r)?1:0,f=c):(f=Math.floor(Math.log(r)/Math.LN2),r*(a=Math.pow(2,-f))\u003c1\u0026\u0026(f--,a*=2),r+=f+h\u003e=1?l/a:l*Math.pow(2,1-h),r*a\u003e=2\u0026\u0026(f++,a/=2),f+h\u003e=c?(u=0,f=c):f+h\u003e=1?(u=(r*a-1)*Math.pow(2,i),f+=h):(u=r*Math.pow(2,h-1)*Math.pow(2,i),f=0));i\u003e=8;t[e+p]=255\u0026u,p+=d,u/=256,i-=8);for(f=f\u003c\u003ci|u,s+=i;s\u003e0;t[e+p]=255\u0026f,p+=d,f/=256,s-=8);t[e+p-d]|=128*y\u007d\u007d,\u007b\u007d],33:[function(t,r,e)\u007b(function(Buffer)\u007bvar t,r,n,i;!function(e)\u007bfunction o(t,r,n)\u007bfunction i(t,r,e,n)\u007breturn this instanceof i?v(this,t,r,e,n):new i(t,r,e,n)\u007dfunction o(t)\u007breturn!(!t||!t[F])\u007dfunction v(t,r,e,n,i)\u007bif(E\u0026\u0026A\u0026\u0026(r instanceof A\u0026\u0026(r=new E(r)),n instanceof A\u0026\u0026(n=new E(n))),!(r||e||n||g))return void(t.buffer=h(m,0));if(!s(r,e))\u007bvar o=g||Array;i=e,n=r,e=0,r=new o(8)\u007dt.buffer=r,t.offset=e|=0,b!==typeof n\u0026\u0026(\u0022string\u0022==typeof n?x(r,e,n,i||10):s(n,i)?c(r,e,n,i):\u0022number\u0022==typeof i?(k(r,e+T,n),k(r,e+S,i)):n\u003e0?O(r,e,n):n\u003c0?L(r,e,n):c(r,e,m,0))\u007dfunction x(t,r,e,n)\u007bvar i=0,o=e.length,f=0,u=0;\u0022-\u0022===e[0]\u0026\u0026i++;for(var a=i;i\u003co;)\u007bvar s=parseInt(e[i++],n);if(!(s\u003e=0))break;u=u*n+s,f=f*n+Math.floor(u/B),u%=B\u007da\u0026\u0026(f=~f,u?u=B-u:f++),k(t,r+T,f),k(t,r+S,u)\u007dfunction P()\u007bvar t=this.buffer,r=this.offset,e=_(t,r+T),i=_(t,r+S);return n||(e|=0),e?e*B+i:i\u007dfunction R(t)\u007bvar r=this.buffer,e=this.offset,i=_(r,e+T),o=_(r,e+S),f=\u0022\u0022,u=!n\u0026\u00262147483648\u0026i;for(u\u0026\u0026(i=~i,o=B-o),t=t||10;;)\u007bvar a=i%t*B+o;if(i=Math.floor(i/t),o=Math.floor(a/t),f=(a%t).toString(t)+f,!i\u0026\u0026!o)break\u007dreturn u\u0026\u0026(f=\u0022-\u0022+f),f\u007dfunction k(t,r,e)\u007bt[r+D]=255\u0026e,e\u003e\u003e=8,t[r+C]=255\u0026e,e\u003e\u003e=8,t[r+Y]=255\u0026e,e\u003e\u003e=8,t[r+I]=255\u0026e\u007dfunction _(t,r)\u007breturn t[r+I]*U+(t[r+Y]\u003c\u003c16)+(t[r+C]\u003c\u003c8)+t[r+D]\u007dvar T=r?0:4,S=r?4:0,I=r?0:3,Y=r?1:2,C=r?2:1,D=r?3:0,O=r?l:d,L=r?p:y,M=i.prototype,N=\u0022is\u0022+t,F=\u0022_\u0022+N;return M.buffer=void 0,M.offset=0,M[F]=!0,M.toNumber=P,M.toString=R,M.toJSON=P,M.toArray=f,w\u0026\u0026(M.toBuffer=u),E\u0026\u0026(M.toArrayBuffer=a),i[N]=o,e[t]=i,i\u007dfunction f(t)\u007bvar r=this.buffer,e=this.offset;return g=null,t!==!1\u0026\u00260===e\u0026\u00268===r.length\u0026\u0026x(r)?r:h(r,e)\u007dfunction u(t)\u007bvar r=this.buffer,e=this.offset;if(g=w,t!==!1\u0026\u00260===e\u0026\u00268===r.length\u0026\u0026Buffer.isBuffer(r))return r;var n=new w(8);return c(n,0,r,e),n\u007dfunction a(t)\u007bvar r=this.buffer,e=this.offset,n=r.buffer;if(g=E,t!==!1\u0026\u00260===e\u0026\u0026n instanceof A\u0026\u00268===n.byteLength)return n;var i=new E(8);return c(i,0,r,e),i.buffer\u007dfunction s(t,r)\u007bvar e=t\u0026\u0026t.length;return r|=0,e\u0026\u0026r+8\u003c=e\u0026\u0026\u0022string\u0022!=typeof t[r]\u007dfunction c(t,r,e,n)\u007br|=0,n|=0;for(var i=0;i\u003c8;i++)t[r++]=255\u0026e[n++]\u007dfunction h(t,r)\u007breturn Array.prototype.slice.call(t,r,r+8)\u007dfunction l(t,r,e)\u007bfor(var n=r+8;n\u003er;)t[--n]=255\u0026e,e/=256\u007dfunction p(t,r,e)\u007bvar n=r+8;for(e++;n\u003er;)t[--n]=255\u0026-e^255,e/=256\u007dfunction d(t,r,e)\u007bfor(var n=r+8;r\u003cn;)t[r++]=255\u0026e,e/=256\u007dfunction y(t,r,e)\u007bvar n=r+8;for(e++;r\u003cn;)t[r++]=255\u0026-e^255,e/=256\u007dfunction v(t)\u007breturn!!t\u0026\u0026\u0022[object Array]\u0022==Object.prototype.toString.call(t)\u007dvar g,b=\u0022undefined\u0022,w=b!==typeof Buffer\u0026\u0026Buffer,E=b!==typeof Uint8Array\u0026\u0026Uint8Array,A=b!==typeof ArrayBuffer\u0026\u0026ArrayBuffer,m=[0,0,0,0,0,0,0,0],x=Array.isArray||v,B=4294967296,U=16777216;t=o(\u0022Uint64BE\u0022,!0,!0),r=o(\u0022Int64BE\u0022,!0,!1),n=o(\u0022Uint64LE\u0022,!1,!0),i=o(\u0022Int64LE\u0022,!1,!1)\u007d(\u0022object\u0022==typeof e\u0026\u0026\u0022string\u0022!=typeof e.nodeName?e:this||\u007b\u007d)\u007d).call(this,t(\u0022buffer\u0022).Buffer)\u007d,\u007bbuffer:29\u007d],34:[function(t,r,e)\u007bvar n=\u007b\u007d.toString;r.exports=Array.isArray||function(t)\u007breturn\u0022[object Array]\u0022==n.call(t)\u007d\u007d,\u007b\u007d]\u007d,\u007b\u007d,[1])(1)\u007d);\r\n\r\nfunction strToBuffer(string) \u007b\r\n  let arrayBuffer = new ArrayBuffer(string.length * 1);\r\n  let newUint = new Uint8Array(arrayBuffer);\r\n  newUint.forEach((_, i) =\u003e \u007b\r\n    newUint[i] = string.charCodeAt(i);\r\n  \u007d);\r\n  return newUint;\r\n\u007d\r\n\r\nconst hsw = this.window.hsw;\r\nconst buffer = await hsw(0,strToBuffer(atob([[LIST_ELEMENT_BAS_MODULE_ONE]])));\r\n[[SAVED_CACHE_MODULE]] = msgpack.decode(buffer);",JSON.stringify(_read_variables(["VAR_LIST_ELEMENT_BAS_MODULE_ONE","VAR_SAVED_CACHE_MODULE"])))!
					var _parse_result = JSON.parse(_result())
					_write_variables(JSON.parse(_parse_result.variables))
					if(!_parse_result.is_success)
					fail(_parse_result.error)
					

				 })!
				 

				 
				 
				 _cycle_params().if_else = VAR_SAVED_CACHE_MODULE.hasOwnProperty('requester_question');
				 _set_if_expression("W1tTQVZFRF9DQUNIRV9NT0RVTEVdXS5oYXNPd25Qcm9wZXJ0eSgncmVxdWVzdGVyX3F1ZXN0aW9uJyk=");
				 _if(_cycle_params().if_else,function(){
				 
					
					
					VAR_SET_TASK = VAR_SAVED_CACHE_MODULE.requester_question.en
					

				 })!
				 

				 
				 
				 _if(!_cycle_params().if_else,function(){
				 
					
					
					_set_if_expression("W1tJU19MT0ddXSA9PSB0cnVl");
					_if(VAR_IS_LOG == true,function(){
					
					   
					   
					   _info((_K==="en" ? "Тест": "Не удалось расшифровать маску кэша *hcaptcha.com/getcaptcha*, берем задание из заголовка каптчи."));
					   

					})!
					

					
					
					/*Browser*/
					_SELECTOR = VAR_HCAPTCHA_PREFIX_SECOND_FRAME + "\u003eCSS\u003eh2[class*=\u0027prompt-text\u0027]";
					wait_element(_SELECTOR)!
					get_element_selector(_SELECTOR, false).text()!
					VAR_SET_TASK = _result()
					

				 })!
				 delete _cycle_params().if_else;
				 

			  })!
			  delete _cycle_params().if_else;
			  

		   })!
		   

		   
		   
		   _if(!_cycle_params().if_else,function(){
		   
			  
			  
			  VAR_ERROR_CACHE_TASK_PARSING = 1
			  

		   })!
		   delete _cycle_params().if_else;
		   

		   
		   
		   VAR_SAVED_CACHE_MODULE = ""
		   

		   
		   
		   VAR_LIST_ELEMENT_BAS_MODULE_ONE = ""
		   

		   
		   
		   VAR_LIST_ELEMENT_BAS_MODULE = ""
		   

		})!
		

		
		
		_set_if_expression("W1tSRUxPQURfQlVUVE9OX1ldXSA+IFtbQlJPV1NFUl9IRUlHSFRdXS8xMDAqOTkgKyBbW1NDUk9MTF9ZXV0gJiYgW1tBTFJFQURZX1NDUk9MTEVEX0lOVE9fUkVMT0FEXV0gPT0gMCAmJiBbW0FMUkVBRFlfU0NST0xMRURfSU5UT19TUVVBUkVdXSA9PSAw");
		_if(VAR_RELOAD_BUTTON_Y > VAR_BROWSER_HEIGHT/100*99 + VAR_SCROLL_Y && VAR_ALREADY_SCROLLED_INTO_RELOAD == 0 && VAR_ALREADY_SCROLLED_INTO_SQUARE == 0,function(){
		
		   
		   
		   _set_if_expression("W1tJU19MT0ddXSA9PSB0cnVl");
		   _if(VAR_IS_LOG == true,function(){
		   
			  
			  
			  _info((_K==="en" ? "Тест": "Каптчу не видно, делаем скролл (Вариант 1)"));
			  

		   })!
		   

		   
		   
		   /*Browser*/
		   _SELECTOR = VAR_HCAPTCHA_PREFIX_SECOND_FRAME + "\u003eXPATH\u003e //div[@class=\u0022interface-challenge\u0022]";
		   wait_element_visible(_SELECTOR)!
		   _call(_random_point, {})!
		   _if(_result().length > 0, function(){
		   move( {} )!
		   get_element_selector(_SELECTOR, false).clarify(X,Y)!
		   _call(_clarify, {} )!
		   })!
		   

		   
		   
		   VAR_GET_ALL_COORDINATES = 0
		   

		   
		   
		   VAR_ALREADY_SCROLLED_INTO_RELOAD = parseInt(VAR_ALREADY_SCROLLED_INTO_RELOAD) + parseInt(1)
		   

		   
		   
		   _next("function")
		   

		})!
		

		
		
		_set_if_expression("W1tTVEFSVF9DT09SRElOQVRFU11dIDwgMCAmJiBbW0FMUkVBRFlfU0NST0xMRURfSU5UT19TUVVBUkVdXSA9PSAw");
		_if(VAR_START_COORDINATES < 0 && VAR_ALREADY_SCROLLED_INTO_SQUARE == 0,function(){
		
		   
		   
		   _set_if_expression("W1tJU19MT0ddXSA9PSB0cnVl");
		   _if(VAR_IS_LOG == true,function(){
		   
			  
			  
			  _info((_K==="en" ? "Тест": "Каптчу не видно, делаем скролл (Вариант 2)"));
			  

		   })!
		   

		   
		   
		   _set_if_expression("W1tIQ0FQVENIQV9UWVBFXzFdXSA9PSB0cnVl");
		   _if(VAR_HCAPTCHA_TYPE_1 == true,function(){
		   
			  
			  
			  /*Browser*/
			  _scroll_to(VAR_SQUARE_BUTTON_Y - 30)!
			  

		   })!
		   

		   
		   
		   _set_if_expression("W1tIQ0FQVENIQV9UWVBFXzJdXSA9PSB0cnVlIHx8IFtbSENBUFRDSEFfVFlQRV80XV0gPT0gdHJ1ZQ==");
		   _if(VAR_HCAPTCHA_TYPE_2 == true || VAR_HCAPTCHA_TYPE_4 == true,function(){
		   
			  
			  
			  /*Browser*/
			  _scroll_to(VAR_SQUARE_BUTTON_Y - 30)!
			  

		   })!
		   

		   
		   
		   _set_if_expression("W1tIQ0FQVENIQV9UWVBFXzNdXSA9PSB0cnVl");
		   _if(VAR_HCAPTCHA_TYPE_3 == true,function(){
		   
			  
			  
			  /*Browser*/
			  _SELECTOR = VAR_HCAPTCHA_PREFIX_SECOND_FRAME + "\u003eCSS\u003e .task-wrapper";
			  wait_element_visible(_SELECTOR)!
			  _call(_random_point, {})!
			  _if(_result().length > 0, function(){
			  move( {} )!
			  get_element_selector(_SELECTOR, false).clarify(X,Y)!
			  _call(_clarify, {} )!
			  })!
			  

		   })!
		   

		   
		   
		   VAR_ALREADY_SCROLLED_INTO_SQUARE = parseInt(VAR_ALREADY_SCROLLED_INTO_SQUARE) + parseInt(1)
		   

		   
		   
		   _next("function")
		   

		})!
		

		
		
		_set_if_expression("W1tJU19NT0JJTEVdXSA9PT0gZmFsc2UgJiYgcmFuZCAoMSwxMCkgPiAz");
		_if(VAR_IS_MOBILE === false && rand (1,10) > 3,function(){
		
		   
		   
		   _get_browser_screen_settings()!
		   ;(function(){
		   var result = JSON.parse(_result())
		   VAR_SCROLL_X = result["ScrollX"]
		   VAR_SCROLL_Y = result["ScrollY"]
		   VAR_CURSOR_X = result["CursorX"]
		   VAR_CURSOR_Y = result["CursorY"]
		   VAR_CURSOR_ABSOLUTE_X = result["CursorX"] + result["ScrollX"]
		   VAR_CURSOR_ABSOLUTE_Y = result["CursorY"] + result["ScrollY"]
		   VAR_BROWSER_WIDTH = result["Width"]
		   VAR_BROWSER_HEIGHT = result["Height"]
		   })();
		   

		   
		   
		   /*Browser*/
		   ;_SELECTOR=VAR_HCAPTCHA_PREFIX_SECOND_FRAME + "\u003eCSS\u003e .challenge-container";
		   get_element_selector(_SELECTOR, false).nowait().exist()!
		   VAR_IS_EXISTS = _result() == 1
		   _if(VAR_IS_EXISTS, function(){
		   get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
		   VAR_IS_EXISTS = _result().indexOf("true")>=0
		   })!
		   

		   
		   
		   _set_if_expression("IVtbSVNfRVhJU1RTXV0=");
		   _if(!VAR_IS_EXISTS,function(){
		   
			  
			  
			  VAR_HCAPTCHA_CLOSED = "1"
			  

		   })!
		   

		   
		   
		   _set_if_expression("W1tIQ0FQVENIQV9DTE9TRURdXSA9PSAw");
		   _if(VAR_HCAPTCHA_CLOSED == 0,function(){
		   
			  
			  
			  /*Browser*/
			  _SELECTOR = VAR_HCAPTCHA_PREFIX_SECOND_FRAME + "\u003eCSS\u003e .challenge-container";
			  wait_element(_SELECTOR)!
			  get_element_selector(_SELECTOR, false).script("(function(){var rect = _BAS_HIDE(BrowserAutomationStudio_GetBoundingClientRect)(self);return (rect.left + positionx) + '|' + (rect.top + positiony) + '|' + (rect.right - rect.left) + '|' + (rect.bottom - rect.top) + '|' + (rect.left + positionx + scrollx) + '|' + (rect.top + positiony + scrolly)})();")!
			  if(_result().length > 0)
			  {
			  var split = _result().split("|")
			  VAR_X = parseInt(split[0])
			  VAR_Y = parseInt(split[1])
			  VAR_CAPTCHA_WIDTH = parseInt(split[2])
			  VAR_CAPTCHA_HEIGHT = parseInt(split[3])
			  VAR_ABSOLUTE_X = parseInt(split[4])
			  VAR_ABSOLUTE_Y = parseInt(split[5])
			  }
			  

			  
			  
			  /*Browser*/
			  move(rand(VAR_X/100*105,(VAR_X+VAR_CAPTCHA_WIDTH)/100*93).toFixed(),rand(VAR_Y + VAR_SCROLL_Y/100*105 + VAR_CAPTCHA_HEIGHT/3,VAR_Y + VAR_SCROLL_Y + VAR_CAPTCHA_HEIGHT/100*90).toFixed(),  {} )!
			  

		   })!
		   

		})!
		

		
		
		/*Browser*/
		;_SELECTOR=VAR_HCAPTCHA_PREFIX_SECOND_FRAME_ELEMENT;
		get_element_selector(_SELECTOR, false).nowait().exist()!
		VAR_IS_EXISTS = _result() == 1
		_if(VAR_IS_EXISTS, function(){
		get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
		VAR_IS_EXISTS = _result().indexOf("true")>=0
		})!
		

		
		
		_set_if_expression("IVtbSVNfRVhJU1RTXV0=");
		_if(!VAR_IS_EXISTS,function(){
		
		   
		   
		   VAR_HCAPTCHA_CLOSED = "1"
		   

		})!
		

		
		
		_set_if_expression("W1tIQ0FQVENIQV9DTE9TRURdXSA9PSAw");
		_if(VAR_HCAPTCHA_CLOSED == 0,function(){
		
		   
		   
		   _set_if_expression("W1tJU19MT0ddXSA9PSB0cnVl");
		   _if(VAR_IS_LOG == true,function(){
		   
			  
			  
			  _info((_K==="en" ? "Тест": "Делаем скриншот каптчи, сохраняем base64"));
			  

		   })!
		   

		   
		   
		   /*Browser*/
		   render(VAR_SQUARE_BUTTON_X,VAR_SQUARE_BUTTON_Y,VAR_SQUARE_WIDTH,VAR_SQUARE_HEIGHT)!
		   VAR_IMAGE_BASE_64 = _result()
		   

		   
		   
		   _set_if_expression("W1tJU19MT0ddXSA9PT0gdHJ1ZQ==");
		   _if(VAR_IS_LOG === true,function(){
		   
			  
			  
			  _set_if_expression("W1tIQ0FQVENIQV9UWVBFXzFdXSA9PSB0cnVl");
			  _if(VAR_HCAPTCHA_TYPE_1 == true,function(){
			  
				 
				 
				 VAR_RAND_PICTURE = rand (1,50000)
				 

				 
				 
				 _set_if_expression("W1tJU19MT0ddXSA9PSB0cnVl");
				 _if(VAR_IS_LOG == true,function(){
				 
					
					
					_info((_K==="en" ? "Тест": "Сохранили картинку в C:/Images/hCaptcha/3x3/" + VAR_RAND_PICTURE));
					

				 })!
				 

				 
				 
				 native("filesystem", "writefile", JSON.stringify({path: "C:/Images/hCaptcha/3x3/" + VAR_SET_TASK + "/" + VAR_RAND_PICTURE + ".jpg",value: (VAR_IMAGE_BASE_64).toString(),base64:true,append:false}))
				 

			  })!
			  

			  
			  
			  _set_if_expression("W1tIQ0FQVENIQV9UWVBFXzJdXSA9PSB0cnVlIHx8IFtbSENBUFRDSEFfVFlQRV80XV0gPT0gdHJ1ZQ==");
			  _if(VAR_HCAPTCHA_TYPE_2 == true || VAR_HCAPTCHA_TYPE_4 == true,function(){
			  
				 
				 
				 VAR_RAND_PICTURE = rand (1,50000)
				 

				 
				 
				 _set_if_expression("W1tJU19MT0ddXSA9PSB0cnVl");
				 _if(VAR_IS_LOG == true,function(){
				 
					
					
					_info((_K==="en" ? "Тест": "Сохранили картинку в C:/Images/hCaptcha/Canvas/" + VAR_RAND_PICTURE));
					

				 })!
				 

				 
				 
				 _set_if_expression("W1tTRVRfVEFTS11dLmluZGV4T2YoIjoiKSA+PSAw");
				 _if(VAR_SET_TASK.indexOf(":") >= 0,function(){
				 
					
					
					VAR_SET_TASK = native("regexp", "replace", JSON.stringify({text: VAR_SET_TASK,regexp:(":").toString(),replace:""}))
					

				 })!
				 

				 
				 
				 native("filesystem", "writefile", JSON.stringify({path: "C:/Images/hCaptcha/Canvas/" + VAR_SET_TASK + "/" + VAR_RAND_PICTURE + ".jpg",value: (VAR_IMAGE_BASE_64).toString(),base64:true,append:false}))
				 

			  })!
			  

			  
			  
			  _set_if_expression("W1tIQ0FQVENIQV9UWVBFXzNdXSA9PSB0cnVl");
			  _if(VAR_HCAPTCHA_TYPE_3 == true,function(){
			  
				 
				 
				 VAR_RAND_PICTURE = rand (1,50000)
				 

				 
				 
				 _set_if_expression("W1tJU19MT0ddXSA9PSB0cnVl");
				 _if(VAR_IS_LOG == true,function(){
				 
					
					
					_info((_K==="en" ? "Тест": "Сохранили картинку в C:/Images/hCaptcha/Check_answer/" + VAR_RAND_PICTURE));
					

				 })!
				 

				 
				 
				 _set_if_expression("W1tTRVRfVEFTS11dLmluZGV4T2YoIjoiKSA+PSAw");
				 _if(VAR_SET_TASK.indexOf(":") >= 0,function(){
				 
					
					
					VAR_SET_TASK = native("regexp", "replace", JSON.stringify({text: VAR_SET_TASK,regexp:(":").toString(),replace:""}))
					

				 })!
				 

				 
				 
				 native("filesystem", "writefile", JSON.stringify({path: "C:/Images/hCaptcha/Check_answer/" + VAR_SET_TASK + "/" + VAR_RAND_PICTURE + ".jpg",value: (VAR_IMAGE_BASE_64).toString(),base64:true,append:false}))
				 

			  })!
			  

		   })!
		   

		})!
		

	 },null)!
	 

	 
	 
	 VAR_ALREADY_SCROLLED_INTO_RELOAD = 0
	 

	 
	 
	 VAR_ALREADY_SCROLLED_INTO_SQUARE = 0
	 

	 
	 
	 _set_if_expression("W1tFUlJPUl9DQUNIRV9UQVNLX1BBUlNJTkddXSA9PSAx");
	 _if(VAR_ERROR_CACHE_TASK_PARSING == 1,function(){
	 
		
		
		fail((_K==="en" ? "Failed to solve hCaptcha. An error occurred while parsing a job from the *hcaptcha.com/getcaptcha* query cache." : "Не удалось решить hCaptcha. При парсинге задания из кэша запроса *hcaptcha.com/getcaptcha* возникла ошибка."));
		

	 })!
	 

	 
	 
	 _set_if_expression("W1tIQ0FQVENIQV9DTE9TRURdXSA9PSAxIHx8IFtbRVJST1JfR0VUX1RBU0tdXSA9PSAx");
	 _if(VAR_HCAPTCHA_CLOSED == 1 || VAR_ERROR_GET_TASK == 1,function(){
	 
		
		
		/*Browser*/
		;_SELECTOR=VAR_HCAPTCHA_PREFIX_SECOND_FRAME + "\u003eCSS\u003e .refresh";
		get_element_selector(_SELECTOR, false).nowait().exist()!
		VAR_IS_EXISTS = _result() == 1
		_if(VAR_IS_EXISTS, function(){
		get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
		VAR_IS_EXISTS = _result().indexOf("true")>=0
		})!
		

		
		
		_set_if_expression("W1tJU19FWElTVFNdXQ==");
		_if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
		
		   
		   
		   VAR_ERROR_GET_TASK = 0
		   

		   
		   
		   VAR_HCAPTCHA_INVISIBLE = parseInt(VAR_HCAPTCHA_INVISIBLE) + parseInt(2)
		   

		   
		   
		   _set_if_expression("W1tJU19MT0ddXSA9PSB0cnVl");
		   _if(VAR_IS_LOG == true,function(){
		   
			  
			  
			  _info((_K==="en" ? "Тест": "Очистили кэшированные данные"));
			  

		   })!
		   

		   
		   
		   /*Browser*/
		   cache_data_clear()!
		   

		   
		   
		   VAR_NUMBER_CRUMB = "0"
		   

		   
		   
		   /*Browser*/
		   _SELECTOR = VAR_HCAPTCHA_PREFIX_SECOND_FRAME + "\u003eCSS\u003e .refresh";
		   wait_element_visible(_SELECTOR)!
		   _call(_random_point, {})!
		   _if(_result().length > 0, function(){
		   move( {} )!
		   get_element_selector(_SELECTOR, false).clarify(X,Y)!
		   _call(_clarify, {} )!
		   mouse(X,Y)!
		   })!
		   

		})!
		

		
		
		_next("function")
		

	 })!
	 

	 
	 
	 _set_if_expression("W1tXQVNfRVJST1JdXQ==");
	 _if(typeof(VAR_WAS_ERROR) !== "undefined" ? (VAR_WAS_ERROR) : undefined,function(){
	 
		
		
		_set_if_expression("W1tMQVNUX0VSUk9SXV0gPT09ICdBYm9ydGVkIEJ5IFVzZXInIHx8IFtbTEFTVF9FUlJPUl1dICA9PT0gJ9Cf0YDQtdGA0LLQsNC90L4g0J/QvtC70YzQt9C+0LLQsNGC0LXQu9C10Lwn");
		_if(VAR_LAST_ERROR === 'Aborted By User' || VAR_LAST_ERROR  === 'Прервано Пользователем',function(){
		
		   
		   
		   _function_return(false)
		   

		})!
		

		
		
		_set_if_expression("W1tMQVNUX0VSUk9SXV0uaW5kZXhPZigiaGNhcHRjaGEuY29tL2dldGNhcHRjaGEiKSA+PSAwICYmIFtbRklSU1RfTE9BRF9DQVBUQ0hBXV0gPT0gdHJ1ZQ==");
		_if(VAR_LAST_ERROR.indexOf("hcaptcha.com/getcaptcha") >= 0 && VAR_FIRST_LOAD_CAPTCHA == true,function(){
		
		   
		   
		   fail((_K==="en" ? "Failed to get task from request cache - *hcaptcha.com/getcaptcha*" : "Не удалось получить задание из кэша запроса - *hcaptcha.com/getcaptcha*."));
		   

		})!
		

		
		
		/*Browser*/
		cache_data_clear()!
		

		
		
		fail(VAR_LAST_ERROR)
		

	 })!
	 

	 
	 
	 VAR_FIRST_LOAD_CAPTCHA = false
	 

	 
	 
	 VAR_CYCLE_INDEX = 0
	 

	 
	 
	 VAR_HCAPTCHA_CLOSED = 0
	 

	 
	 
	 VAR_UNKNOWN_CAPTCHA = 0
	 

	 
	 
	 _call(function()
	 {
	 _on_fail(function(){
	 VAR_LAST_ERROR = _result()
	 VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
	 VAR_WAS_ERROR = false
	 _break(1,true)
	 })
	 CYCLES.Current().RemoveLabel("function")
	 
		
		
		_do(function(){
		_set_action_info({ name: "For" });
		VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
		if(VAR_CYCLE_INDEX > parseInt(20))_break();
		
		   
		   
		   _set_if_expression("W1tJU19MT0ddXSA9PSB0cnVl");
		   _if(VAR_IS_LOG == true,function(){
		   
			  
			  
			  _info((_K==="en" ? "Тест": "Отправляем каптчу на SCTG"));
			  

		   })!
		   

		   
		   
		   ///Чистим
		   solver_properties_clear("capmonster")
		   /// Формирумем основной запрос
		   solver_property("capmonster","serverurl","http://sctg.xyz")
		   solver_property("capmonster","key",VAR_KEY_MODULE)
		   solver_property("capmonster","task",VAR_SET_TASK)
		   solver_property("capmonster","type",VAR_TYPE_TASK)
		   solver_property("capmonster","method","hcaptcha")
		   solver_property("capmonster","body",VAR_IMAGE_BASE_64)
		   //// Отправляем
		   solve_base64_no_fail("capmonster", "")!
		   VAR_SAVED_CONTENT = _result();
		   

		   
		   
		   _set_if_expression("W1tTQVZFRF9DT05URU5UXV0uaW5kZXhPZigiRVJST1JfQ0FQVENIQV9VTlNPTFZBQkxFIikgPj0gMA==");
		   _if(VAR_SAVED_CONTENT.indexOf("ERROR_CAPTCHA_UNSOLVABLE") >= 0 || VAR_SAVED_CONTENT.indexOf("WRONG_RESULT") >= 0 ,function(){
		   
			  
			  
			  _set_if_expression("W1tJU19MT0ddXSA9PSB0cnVl");
			  _if(VAR_IS_LOG == true,function(){
			  
				 
				 
				 _info((_K==="en" ? "Тест": "Получили ответ от SCTG - WRONG_RESULT "));
				 

			  })!
			  

			  
			  
			  /*Browser*/
			  cache_data_clear()!
			  

			  
			  
			  VAR_NUMBER_CRUMB = "0"
			  

			  
			  
			  VAR_HCAPTCHA_INVISIBLE = parseInt(VAR_HCAPTCHA_INVISIBLE) + parseInt(2)
			  

			  
			  
			  _set_if_expression("W1tSRUxPQURfQlVUVE9OX1ldXSA+IFtbQlJPV1NFUl9IRUlHSFRdXQ==");
			  _if(VAR_RELOAD_BUTTON_Y > VAR_BROWSER_HEIGHT,function(){
			  
				 
				 
				 /*Browser*/
				 _scroll_to(VAR_RELOAD_BUTTON_Y + VAR_RELOAD_BUTTON_Y/100*10)!
				 

			  })!
			  

			  
			  
			  _get_browser_screen_settings()!
			  ;(function(){
			  var result = JSON.parse(_result())
			  VAR_SCROLL_X = result["ScrollX"]
			  VAR_SCROLL_Y = result["ScrollY"]
			  VAR_CURSOR_X = result["CursorX"]
			  VAR_CURSOR_Y = result["CursorY"]
			  VAR_CURSOR_ABSOLUTE_X = result["CursorX"] + result["ScrollX"]
			  VAR_CURSOR_ABSOLUTE_Y = result["CursorY"] + result["ScrollY"]
			  VAR_BROWSER_WIDTH = result["Width"]
			  VAR_BROWSER_HEIGHT = result["Height"]
			  })();
			  

			  
			  
			  _cycle_params().if_else = VAR_IS_CHANGED_SCROLL_Y != VAR_SCROLL_Y;
			  _set_if_expression("W1tJU19DSEFOR0VEX1NDUk9MTF9ZXV0gIT0gW1tTQ1JPTExfWV1d");
			  _if(_cycle_params().if_else,function(){
			  
				 
				 
				 VAR_ELEMENT_SELECTOR = VAR_HCAPTCHA_PREFIX_SECOND_FRAME + "\u003eCSS\u003e .refresh"
				 

				 
				 
				 _SELECTOR = VAR_ELEMENT_SELECTOR;
				 get_element_selector(_SELECTOR, false).script("(function(){var rect = _BAS_HIDE(BrowserAutomationStudio_GetBoundingClientRect)(self);return (rect.left + positionx) + '|' + (rect.top + positiony) + '|' + (rect.right - rect.left) + '|' + (rect.bottom - rect.top)})();")!
				 var split = _result().split("|");
				 var x = parseInt(split[0]), y = parseInt(split[1]), w = parseInt(split[2]), h = parseInt(split[3]);
				 _get_browser_screen_settings()!
				 var result_hcaptcha = JSON.parse(_result());
				 var scroll_x = result_hcaptcha["ScrollX"], scroll_y = result_hcaptcha["ScrollY"]
				 var margin_top_bottom = 50; //percent
				 var margin_left_top = 50; // percent
				 div = 1;
				 var x_min = x + w/100*margin_left_top + parseInt(scroll_x), x_max = x+w/div-w/100*margin_left_top + parseInt(scroll_x);
				 var y_min = y + h/100*margin_top_bottom + parseInt(scroll_y), y_max = y+h - h/100*margin_top_bottom + parseInt(scroll_y);
				 x = rand(x_min, x_max);
				 y = rand(y_min, y_max);
				 x = x.toFixed();
				 y = y.toFixed();
				 /// Кнопка Reload
				 VAR_RELOAD_BUTTON_X = parseInt(x);
				 VAR_RELOAD_BUTTON_Y = parseInt(y);
				 

			  })!
			  

			  
			  
			  /*Browser*/
			  ;_SELECTOR=VAR_HCAPTCHA_PREFIX_SECOND_FRAME + "\u003eCSS\u003e .refresh";
			  get_element_selector(_SELECTOR, false).nowait().exist()!
			  VAR_IS_EXISTS = _result() == 1
			  _if(VAR_IS_EXISTS, function(){
			  get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
			  VAR_IS_EXISTS = _result().indexOf("true")>=0
			  })!
			  

			  
			  
			  _cycle_params().if_else = typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined;
			  _set_if_expression("W1tJU19FWElTVFNdXQ==");
			  _if(_cycle_params().if_else,function(){
			  
				 
				 
				 VAR_RELOAD_BUTTON_X_CLICK = 0;
				 VAR_RELOAD_BUTTON_Y_CLICK = 0;
				 VAR_RELOAD_BUTTON_X_CLICK = VAR_RELOAD_BUTTON_X + rand(-6,+6);
				 VAR_RELOAD_BUTTON_Y_CLICK = VAR_RELOAD_BUTTON_Y + rand(-6,+6);
				 

				 
				 
				 /*Browser*/
				 move(VAR_RELOAD_BUTTON_X_CLICK,VAR_RELOAD_BUTTON_Y_CLICK,  {"speed": VAR_SPEED,"gravity": VAR_GRAVITY,"deviation": VAR_DEVIATION} )!
				 mouse(VAR_RELOAD_BUTTON_X_CLICK,VAR_RELOAD_BUTTON_Y_CLICK)!
				 

			  })!
			  

			  
			  
			  _if(!_cycle_params().if_else,function(){
			  
				 
				 
				 VAR_ERROR_CAPTCHA_UNSOLVABLE_MODULE = parseInt(VAR_ERROR_CAPTCHA_UNSOLVABLE_MODULE) + parseInt(2)
				 

			  })!
			  delete _cycle_params().if_else;
			  

			  
			  
			  sleep(1000)!
			  

			  
			  
			  VAR_ERROR_CAPTCHA_UNSOLVABLE_MODULE = parseInt(VAR_ERROR_CAPTCHA_UNSOLVABLE_MODULE) + parseInt(1)
			  

			  
			  
			  _break("function")
			  

		   })!
		   

		   
		   
		   _set_if_expression("W1tTQVZFRF9DT05URU5UXV0uaW5kZXhPZigiRVJST1JfV1JPTkdfVVNFUl9LRVkiKSA+PSAw");
		   _if(VAR_SAVED_CONTENT.indexOf("ERROR_WRONG_USER_KEY") >= 0,function(){
		   
			  
			  
			  VAR_ERROR_KEY = "1"
			  

			  
			  
			  _break("function")
			  

		   })!
		   

		   
		   
		   _set_if_expression("W1tTQVZFRF9DT05URU5UXV0uaW5kZXhPZigiRVJST1JfWkVST19CQUxBTkNFIikgPj0gMA==");
		   _if(VAR_SAVED_CONTENT.indexOf("ERROR_ZERO_BALANCE") >= 0,function(){
		   
			  
			  
			  VAR_ERROR_BALANCE = "1"
			  

			  
			  
			  _break("function")
			  

		   })!
		   

		   
		   
		   _set_if_expression("W1tTQVZFRF9DT05URU5UXV0uaW5kZXhPZigiQ0FQVENIQV9GQUlMIikgPj0gMA==");
		   _if(VAR_SAVED_CONTENT.indexOf("CAPTCHA_FAIL") >= 0,function(){
		   
			  
			  
			  sleep(rand(1000,2000))!
			  

			  
			  
			  VAR_CAPTCHA_FAIL = parseInt(VAR_CAPTCHA_FAIL) + parseInt(1)
			  

			  
			  
			  _break("function")
			  

		   })!
		   
			
		   if (VAR_TYPE_TASK == "grid") {
		   VAR_TEMP_DT = VAR_SAVED_CONTENT.split(",")
		   VAR_SAVED_CONTENT = "coordinates:"
		   VAR_COORDS_TEMP_X = {
			   "1": parseInt((VAR_SQUARE_WIDTH/3)/2),
			   "2": parseInt(VAR_SQUARE_WIDTH/2),
			   "3": parseInt(VAR_SQUARE_WIDTH - ((VAR_SQUARE_WIDTH/3)/2)),
			   "4": parseInt((VAR_SQUARE_WIDTH/3)/2),
			   "5": parseInt(VAR_SQUARE_WIDTH/2),
			   "6": parseInt(VAR_SQUARE_WIDTH - ((VAR_SQUARE_WIDTH/3)/2)),
			   "7": parseInt((VAR_SQUARE_WIDTH/3)/2),
			   "8": parseInt(VAR_SQUARE_WIDTH/2),
			   "9": parseInt(VAR_SQUARE_WIDTH - ((VAR_SQUARE_WIDTH/3)/2))
		   }
		   VAR_COORDS_TEMP_Y = {
			   "1": parseInt(VAR_SQUARE_HEIGHT * 0.3),
			   "2": parseInt(VAR_SQUARE_HEIGHT * 0.3),
			   "3": parseInt(VAR_SQUARE_HEIGHT * 0.3),
			   "4": parseInt(VAR_SQUARE_HEIGHT * 0.55),
			   "5": parseInt(VAR_SQUARE_HEIGHT * 0.55),
			   "6": parseInt(VAR_SQUARE_HEIGHT * 0.55),
			   "7": parseInt(VAR_SQUARE_HEIGHT * 0.8),
			   "8": parseInt(VAR_SQUARE_HEIGHT * 0.8),
			   "9": parseInt(VAR_SQUARE_HEIGHT * 0.8),
		   }
		   VAR_TEMP_DT.forEach(function(element) {
			  VAR_SAVED_CONTENT += "x="
			  VAR_SAVED_CONTENT += VAR_COORDS_TEMP_X[element]
			  VAR_SAVED_CONTENT += ","
			  VAR_SAVED_CONTENT += "y="
			  VAR_SAVED_CONTENT += VAR_COORDS_TEMP_Y[element]
			  VAR_SAVED_CONTENT += ";"
		   });
		   VAR_SAVED_CONTENT = VAR_SAVED_CONTENT.slice(0, -1);
		   }
		   
		   if (VAR_TYPE_TASK == "canvas") {
		   VAR_TEMP_DT = VAR_SAVED_CONTENT.split(":")
		   VAR_SAVED_CONTENT = "coordinates:"
		   VAR_SAVED_CONTENT += "x="
		   VAR_SAVED_CONTENT += VAR_TEMP_DT[0]
		   VAR_SAVED_CONTENT += ","
		   VAR_SAVED_CONTENT += "y="
		   VAR_SAVED_CONTENT += VAR_TEMP_DT[1]
		   }
		   
		   _cycle_params().if_else = VAR_SAVED_CONTENT.match(/[0-9]/) && VAR_SAVED_CONTENT.indexOf("coordinates") >= 0;
		   _set_if_expression("W1tTQVZFRF9DT05URU5UXV0ubWF0Y2goL1swLTldLykgJiYgW1tTQVZFRF9DT05URU5UXV0uaW5kZXhPZigiY29vcmRpbmF0ZXMiKSA+PSAw");
		   _if(_cycle_params().if_else,function(){
		   
			  
			  
			  _set_if_expression("W1tJU19MT0ddXSA9PSB0cnVl");
			  _if(VAR_IS_LOG == true,function(){
			  
				 
				 
				 _info((_K==="en" ? "Тест": "Получили ответ от SCTG валидный, преобразуем координаты, высчитаем место для клика"));
				 

			  })!
			  

			  
			  
			  VAR_ERROR_CAPTCHA_UNSOLVABLE_MODULE = 0
			  

			  
			  
			  VAR_LISTS_COORDINATES = VAR_SAVED_CONTENT
			  VAR_LISTS_COORDINATES = VAR_LISTS_COORDINATES.split("coordinates:")[1];
			  VAR_LISTS_COORDINATES = VAR_LISTS_COORDINATES.split(";");
			  

			  
			  
			  ;(function (a) {var j, x, i;for (i = a.length; i; i--) {j = Math.floor(Math.random() * i);x = a[i - 1]; a[i - 1] = a[j];a[j] = x;}})(VAR_LISTS_COORDINATES)
			  

			  
			  
			  VAR_FOREACH_DATA = 0
			  

			  
			  
			  _do_with_params({"foreach_data":(VAR_LISTS_COORDINATES)},function(){
			  _set_action_info({ name: "Foreach" });
			  VAR_CYCLE_INDEX = _iterator() - 1
			  if(VAR_CYCLE_INDEX > _cycle_param("foreach_data").length - 1)_break();
			  VAR_FOREACH_DATA = _cycle_param("foreach_data")[VAR_CYCLE_INDEX]
			  
				 
				 
				 _set_if_expression("W1tJU19MT0ddXSA9PSB0cnVl");
				 _if(VAR_IS_LOG == true,function(){
				 
					
					
					_info((_K==="en" ? "Тест": "Кликаем на правильные ответы по каптче"));
					

				 })!
				 

				 
				 
				 var csv_parse_result = csv_parse(VAR_FOREACH_DATA)
				 VAR_ANSWER_X = csv_parse_result[0]
				 if(typeof(VAR_ANSWER_X) == 'undefined' || !VAR_ANSWER_X)
				 {
				 VAR_ANSWER_X = ""
				 }
				 VAR_ANSWER_Y = csv_parse_result[1]
				 if(typeof(VAR_ANSWER_Y) == 'undefined' || !VAR_ANSWER_Y)
				 {
				 VAR_ANSWER_Y = ""
				 }
				 

				 
				 
				 VAR_ANSWER_X = VAR_ANSWER_X.replace(/[^0-9]/g, '');
				 VAR_ANSWER_Y = VAR_ANSWER_Y.replace(/[^0-9]/g, '');
				 VAR_ANSWER_X = parseInt(VAR_ANSWER_X)
				 VAR_ANSWER_Y = parseInt(VAR_ANSWER_Y)
				 

				 
				 
				 _set_if_expression("W1tIQ0FQVENIQV9UWVBFXzFdXSA9PSB0cnVl");
				 _if(VAR_HCAPTCHA_TYPE_1 == true,function(){
				 
					
					
					VAR_SQUARE_BUTTON_X_CLICK = 0;
					VAR_SQUARE_BUTTON_Y_CLICK = 0;
					VAR_SQUARE_BUTTON_X_CLICK = VAR_SQUARE_BUTTON_X + VAR_ANSWER_X + rand (-10,+10);
					VAR_SQUARE_BUTTON_Y_CLICK = VAR_SQUARE_BUTTON_Y + VAR_ANSWER_Y + rand (-10,+10);
					

					
					
					/*Browser*/
					move(VAR_SQUARE_BUTTON_X_CLICK,VAR_SQUARE_BUTTON_Y_CLICK,  {"speed": VAR_SPEED,"gravity": VAR_GRAVITY,"deviation": VAR_DEVIATION} )!
					mouse(VAR_SQUARE_BUTTON_X_CLICK,VAR_SQUARE_BUTTON_Y_CLICK)!
					

				 })!
				 

				 
				 
				 _set_if_expression("W1tIQ0FQVENIQV9UWVBFXzJdXSA9PSB0cnVlIHx8IFtbSENBUFRDSEFfVFlQRV80XV0gPT0gdHJ1ZQ==");
				 _if(VAR_HCAPTCHA_TYPE_2 == true || VAR_HCAPTCHA_TYPE_4 == true,function(){
				 
					
					
					_get_browser_screen_settings()!
					;(function(){
					var result = JSON.parse(_result())
					VAR_SCROLL_X = result["ScrollX"]
					VAR_SCROLL_Y = result["ScrollY"]
					VAR_CURSOR_X = result["CursorX"]
					VAR_CURSOR_Y = result["CursorY"]
					VAR_CURSOR_ABSOLUTE_X = result["CursorX"] + result["ScrollX"]
					VAR_CURSOR_ABSOLUTE_Y = result["CursorY"] + result["ScrollY"]
					VAR_BROWSER_WIDTH = result["Width"]
					VAR_BROWSER_HEIGHT = result["Height"]
					})();
					

					
					
					VAR_SQUARE_BUTTON_X_CLICK = 0;
					VAR_SQUARE_BUTTON_Y_CLICK = 0;
					VAR_SQUARE_BUTTON_X_CLICK = VAR_SQUARE_BUTTON_X + VAR_ANSWER_X;
					VAR_SQUARE_BUTTON_Y_CLICK = VAR_SQUARE_BUTTON_Y + VAR_ANSWER_Y;
					

					
					
					/*Browser*/
					move(VAR_SQUARE_BUTTON_X_CLICK,VAR_SQUARE_BUTTON_Y_CLICK,  {"speed": VAR_SPEED,"gravity": VAR_GRAVITY,"deviation": VAR_DEVIATION} )!
					mouse(VAR_SQUARE_BUTTON_X_CLICK,VAR_SQUARE_BUTTON_Y_CLICK)!
					

					
					
					sleep(rand(400,900))!
					

					
					
					_set_if_expression("W1tJU19NT0JJTEVdXSA9PT0gZmFsc2U=");
					_if(VAR_IS_MOBILE === false,function(){
					
					   
					   
					   _set_if_expression("cmFuZCAoMSwxMCkgPiA0");
					   _if(rand (1,10) > 4,function(){
					   
						  
						  
						  _get_browser_screen_settings()!
						  ;(function(){
						  var result = JSON.parse(_result())
						  VAR_SCROLL_X = result["ScrollX"]
						  VAR_SCROLL_Y = result["ScrollY"]
						  VAR_CURSOR_X = result["CursorX"]
						  VAR_CURSOR_Y = result["CursorY"]
						  VAR_CURSOR_ABSOLUTE_X = result["CursorX"] + result["ScrollX"]
						  VAR_CURSOR_ABSOLUTE_Y = result["CursorY"] + result["ScrollY"]
						  VAR_BROWSER_WIDTH = result["Width"]
						  VAR_BROWSER_HEIGHT = result["Height"]
						  })();
						  

						  
						  
						  sleep(rand(100,300))!
						  

						  
						  
						  /*Browser*/
						  _SELECTOR = VAR_HCAPTCHA_PREFIX_SECOND_FRAME + "\u003eCSS\u003e .challenge-container";
						  wait_element(_SELECTOR)!
						  get_element_selector(_SELECTOR, false).script("(function(){var rect = _BAS_HIDE(BrowserAutomationStudio_GetBoundingClientRect)(self);return (rect.left + positionx) + '|' + (rect.top + positiony) + '|' + (rect.right - rect.left) + '|' + (rect.bottom - rect.top) + '|' + (rect.left + positionx + scrollx) + '|' + (rect.top + positiony + scrolly)})();")!
						  if(_result().length > 0)
						  {
						  var split = _result().split("|")
						  VAR_X = parseInt(split[0])
						  VAR_Y = parseInt(split[1])
						  VAR_CAPTCHA_WIDTH = parseInt(split[2])
						  VAR_CAPTCHA_HEIGHT = parseInt(split[3])
						  VAR_ABSOLUTE_X = parseInt(split[4])
						  VAR_ABSOLUTE_Y = parseInt(split[5])
						  }
						  

						  
						  
						  /*Browser*/
						  move(rand(VAR_X/100*105,(VAR_X+VAR_CAPTCHA_WIDTH)/100*93).toFixed(),rand(VAR_Y + VAR_SCROLL_Y/100*105 + VAR_CAPTCHA_HEIGHT/3,VAR_Y + VAR_SCROLL_Y + VAR_CAPTCHA_HEIGHT/100*90).toFixed(),  {} )!
						  

						  
						  
						  sleep(rand(100,300))!
						  

					   })!
					   

					   
					   
					   _set_if_expression("cmFuZCAoMSwxMCkgPiA4");
					   _if(rand (1,10) > 8,function(){
					   
						  
						  
						  /*Browser*/
						  IDDLE_EMULATION_END = Date.now() + 1000 * (rand (1,2))
						  IDDLE_EMULATION_DISTRIBUTION = [3,3]
						  _get_browser_screen_settings()!
						  IDDLE_EMULATION_RESULT = JSON.parse(_result())
						  IDDLE_CURSOR_POSITION_X = IDDLE_EMULATION_RESULT["CursorX"]
						  IDDLE_CURSOR_POSITION_Y = IDDLE_EMULATION_RESULT["CursorY"]
						  IDDLE_CURSOR_POSITION_WIDTH = IDDLE_EMULATION_RESULT["Width"]
						  IDDLE_CURSOR_POSITION_HEIGHT = IDDLE_EMULATION_RESULT["Height"]
						  IDDLE_CURSOR_POSITION_WAS_SCROLL = false
						  _do(function(){
						  if(Date.now() >= IDDLE_EMULATION_END)
						  _break()
						  IDDLE_EMULATION_CURRENT_ITEM = IDDLE_EMULATION_DISTRIBUTION[Math.floor(Math.random()*IDDLE_EMULATION_DISTRIBUTION.length)]
						  if(_iterator() == 1 && IDDLE_EMULATION_DISTRIBUTION.indexOf(2)>=0)
						  IDDLE_EMULATION_CURRENT_ITEM = 2
						  _if(IDDLE_EMULATION_CURRENT_ITEM == 1, function(){
						  //scroll
						  IDDLE_EMULATION_CURRENT_DIRECTION = (rand(1,2) == 2) ? "<MOUSESCROLLUP>" : "<MOUSESCROLLDOWN>"
						  if(!IDDLE_CURSOR_POSITION_WAS_SCROLL)
						  IDDLE_EMULATION_CURRENT_DIRECTION = "<MOUSESCROLLDOWN>"
						  IDDLE_CURSOR_POSITION_WAS_SCROLL = true
						  IDDLE_EMULATION_CURRENT_NUMBER = rand(1,5)
						  _do(function(){
						  if(_iterator() >= IDDLE_EMULATION_CURRENT_NUMBER)
						  _break()
						  _type(IDDLE_EMULATION_CURRENT_DIRECTION,1000)!
						  sleep(rand(300,1000))!
						  })!
						  })!
						  _if(IDDLE_EMULATION_CURRENT_ITEM == 2, function(){
						  //long move
						  page().script("document.documentElement.scrollLeft")!
						  IDDLE_CURSOR_POSITION_SCROLL_X = parseInt(_result())
						  page().script("document.documentElement.scrollTop")!
						  IDDLE_CURSOR_POSITION_SCROLL_Y = parseInt(_result())
						  IDDLE_CURSOR_POSITION_X = rand(1,IDDLE_CURSOR_POSITION_WIDTH)
						  IDDLE_CURSOR_POSITION_Y = rand(1,IDDLE_CURSOR_POSITION_HEIGHT)
						  move(IDDLE_CURSOR_POSITION_SCROLL_X + IDDLE_CURSOR_POSITION_X,IDDLE_CURSOR_POSITION_SCROLL_Y + IDDLE_CURSOR_POSITION_Y)!
						  })!
						  _if(IDDLE_EMULATION_CURRENT_ITEM == 3, function(){
						  //short move
						  if(IDDLE_CURSOR_POSITION_X < 0 || IDDLE_CURSOR_POSITION_Y < 0)
						  _break()
						  page().script("document.documentElement.scrollLeft")!
						  IDDLE_CURSOR_POSITION_SCROLL_X = parseInt(_result())
						  page().script("document.documentElement.scrollTop")!
						  IDDLE_CURSOR_POSITION_SCROLL_Y = parseInt(_result())
						  IDDLE_EMULATION_CURRENT_NUMBER = rand(1,4)
						  _do(function(){
						  if(_iterator() >= IDDLE_EMULATION_CURRENT_NUMBER)
						  _break()
						  IDDLE_CURSOR_POSITION_X += rand(-50,50)
						  IDDLE_CURSOR_POSITION_Y += rand(-50,50)
						  if(IDDLE_CURSOR_POSITION_X > IDDLE_CURSOR_POSITION_WIDTH)
						  IDDLE_CURSOR_POSITION_X = IDDLE_CURSOR_POSITION_WIDTH
						  if(IDDLE_CURSOR_POSITION_Y > IDDLE_CURSOR_POSITION_HEIGHT)
						  IDDLE_CURSOR_POSITION_Y = IDDLE_CURSOR_POSITION_HEIGHT
						  if(IDDLE_CURSOR_POSITION_X < 0)
						  IDDLE_CURSOR_POSITION_X = 0
						  if(IDDLE_CURSOR_POSITION_Y < 0)
						  IDDLE_CURSOR_POSITION_Y = 0
						  move(IDDLE_CURSOR_POSITION_SCROLL_X + IDDLE_CURSOR_POSITION_X,IDDLE_CURSOR_POSITION_SCROLL_Y + IDDLE_CURSOR_POSITION_Y)!
						  _if(rand(1,10) > 3,function(){
						  sleep(rand(10,300))!
						  })!
						  })!
						  })!
						  _if(IDDLE_EMULATION_CURRENT_ITEM == 4, function(){
						  //sleep
						  sleep(rand(500,5000))!
						  })!
						  })!
						  

					   })!
					   

					})!
					

					
					
					sleep(rand(100,400))!
					

				 })!
				 

				 
				 
				 _set_if_expression("W1tIQ0FQVENIQV9UWVBFXzNdXSA9PSB0cnVl");
				 _if(VAR_HCAPTCHA_TYPE_3 == true,function(){
				 
					
					
					VAR_SQUARE_BUTTON_X_CLICK = 0;
					VAR_SQUARE_BUTTON_Y_CLICK = 0;
					VAR_SQUARE_BUTTON_X_CLICK = VAR_SQUARE_BUTTON_X + VAR_ANSWER_X + rand(-8,VAR_ANSWER_SQUARE_WIDTH/1.9);
					VAR_SQUARE_BUTTON_Y_CLICK = VAR_SQUARE_BUTTON_Y + VAR_ANSWER_Y + rand(-VAR_ANSWER_SQUARE_HEIGHT/7,VAR_ANSWER_SQUARE_HEIGHT/7);
					

					
					
					/*Browser*/
					move(VAR_SQUARE_BUTTON_X_CLICK,VAR_SQUARE_BUTTON_Y_CLICK,  {"speed": VAR_SPEED,"gravity": VAR_GRAVITY,"deviation": VAR_DEVIATION} )!
					mouse(VAR_SQUARE_BUTTON_X_CLICK,VAR_SQUARE_BUTTON_Y_CLICK)!
					

					
					
					_set_if_expression("W1tJU19NT0JJTEVdXSA9PT0gZmFsc2U=");
					_if(VAR_IS_MOBILE === false,function(){
					
					   
					   
					   _set_if_expression("cmFuZCAoMSwxMCkgPiA0");
					   _if(rand (1,10) > 4,function(){
					   
						  
						  
						  _get_browser_screen_settings()!
						  ;(function(){
						  var result = JSON.parse(_result())
						  VAR_SCROLL_X = result["ScrollX"]
						  VAR_SCROLL_Y = result["ScrollY"]
						  VAR_CURSOR_X = result["CursorX"]
						  VAR_CURSOR_Y = result["CursorY"]
						  VAR_CURSOR_ABSOLUTE_X = result["CursorX"] + result["ScrollX"]
						  VAR_CURSOR_ABSOLUTE_Y = result["CursorY"] + result["ScrollY"]
						  VAR_BROWSER_WIDTH = result["Width"]
						  VAR_BROWSER_HEIGHT = result["Height"]
						  })();
						  

						  
						  
						  sleep(rand(100,300))!
						  

						  
						  
						  /*Browser*/
						  _SELECTOR = VAR_HCAPTCHA_PREFIX_SECOND_FRAME + "\u003eCSS\u003e .challenge-container";
						  wait_element(_SELECTOR)!
						  get_element_selector(_SELECTOR, false).script("(function(){var rect = _BAS_HIDE(BrowserAutomationStudio_GetBoundingClientRect)(self);return (rect.left + positionx) + '|' + (rect.top + positiony) + '|' + (rect.right - rect.left) + '|' + (rect.bottom - rect.top) + '|' + (rect.left + positionx + scrollx) + '|' + (rect.top + positiony + scrolly)})();")!
						  if(_result().length > 0)
						  {
						  var split = _result().split("|")
						  VAR_X = parseInt(split[0])
						  VAR_Y = parseInt(split[1])
						  VAR_CAPTCHA_WIDTH = parseInt(split[2])
						  VAR_CAPTCHA_HEIGHT = parseInt(split[3])
						  VAR_ABSOLUTE_X = parseInt(split[4])
						  VAR_ABSOLUTE_Y = parseInt(split[5])
						  }
						  

						  
						  
						  /*Browser*/
						  move(rand(VAR_X/100*105,(VAR_X+VAR_CAPTCHA_WIDTH)/100*93).toFixed(),rand(VAR_Y + VAR_SCROLL_Y/100*105 + VAR_CAPTCHA_HEIGHT/3,VAR_Y + VAR_SCROLL_Y + VAR_CAPTCHA_HEIGHT/100*90).toFixed(),  {} )!
						  

						  
						  
						  sleep(rand(100,300))!
						  

					   })!
					   

					   
					   
					   _set_if_expression("cmFuZCAoMSwxMCkgPiA4");
					   _if(rand (1,10) > 8,function(){
					   
						  
						  
						  /*Browser*/
						  IDDLE_EMULATION_END = Date.now() + 1000 * (rand (1,2))
						  IDDLE_EMULATION_DISTRIBUTION = [3,3]
						  _get_browser_screen_settings()!
						  IDDLE_EMULATION_RESULT = JSON.parse(_result())
						  IDDLE_CURSOR_POSITION_X = IDDLE_EMULATION_RESULT["CursorX"]
						  IDDLE_CURSOR_POSITION_Y = IDDLE_EMULATION_RESULT["CursorY"]
						  IDDLE_CURSOR_POSITION_WIDTH = IDDLE_EMULATION_RESULT["Width"]
						  IDDLE_CURSOR_POSITION_HEIGHT = IDDLE_EMULATION_RESULT["Height"]
						  IDDLE_CURSOR_POSITION_WAS_SCROLL = false
						  _do(function(){
						  if(Date.now() >= IDDLE_EMULATION_END)
						  _break()
						  IDDLE_EMULATION_CURRENT_ITEM = IDDLE_EMULATION_DISTRIBUTION[Math.floor(Math.random()*IDDLE_EMULATION_DISTRIBUTION.length)]
						  if(_iterator() == 1 && IDDLE_EMULATION_DISTRIBUTION.indexOf(2)>=0)
						  IDDLE_EMULATION_CURRENT_ITEM = 2
						  _if(IDDLE_EMULATION_CURRENT_ITEM == 1, function(){
						  //scroll
						  IDDLE_EMULATION_CURRENT_DIRECTION = (rand(1,2) == 2) ? "<MOUSESCROLLUP>" : "<MOUSESCROLLDOWN>"
						  if(!IDDLE_CURSOR_POSITION_WAS_SCROLL)
						  IDDLE_EMULATION_CURRENT_DIRECTION = "<MOUSESCROLLDOWN>"
						  IDDLE_CURSOR_POSITION_WAS_SCROLL = true
						  IDDLE_EMULATION_CURRENT_NUMBER = rand(1,5)
						  _do(function(){
						  if(_iterator() >= IDDLE_EMULATION_CURRENT_NUMBER)
						  _break()
						  _type(IDDLE_EMULATION_CURRENT_DIRECTION,1000)!
						  sleep(rand(300,1000))!
						  })!
						  })!
						  _if(IDDLE_EMULATION_CURRENT_ITEM == 2, function(){
						  //long move
						  page().script("document.documentElement.scrollLeft")!
						  IDDLE_CURSOR_POSITION_SCROLL_X = parseInt(_result())
						  page().script("document.documentElement.scrollTop")!
						  IDDLE_CURSOR_POSITION_SCROLL_Y = parseInt(_result())
						  IDDLE_CURSOR_POSITION_X = rand(1,IDDLE_CURSOR_POSITION_WIDTH)
						  IDDLE_CURSOR_POSITION_Y = rand(1,IDDLE_CURSOR_POSITION_HEIGHT)
						  move(IDDLE_CURSOR_POSITION_SCROLL_X + IDDLE_CURSOR_POSITION_X,IDDLE_CURSOR_POSITION_SCROLL_Y + IDDLE_CURSOR_POSITION_Y)!
						  })!
						  _if(IDDLE_EMULATION_CURRENT_ITEM == 3, function(){
						  //short move
						  if(IDDLE_CURSOR_POSITION_X < 0 || IDDLE_CURSOR_POSITION_Y < 0)
						  _break()
						  page().script("document.documentElement.scrollLeft")!
						  IDDLE_CURSOR_POSITION_SCROLL_X = parseInt(_result())
						  page().script("document.documentElement.scrollTop")!
						  IDDLE_CURSOR_POSITION_SCROLL_Y = parseInt(_result())
						  IDDLE_EMULATION_CURRENT_NUMBER = rand(1,4)
						  _do(function(){
						  if(_iterator() >= IDDLE_EMULATION_CURRENT_NUMBER)
						  _break()
						  IDDLE_CURSOR_POSITION_X += rand(-50,50)
						  IDDLE_CURSOR_POSITION_Y += rand(-50,50)
						  if(IDDLE_CURSOR_POSITION_X > IDDLE_CURSOR_POSITION_WIDTH)
						  IDDLE_CURSOR_POSITION_X = IDDLE_CURSOR_POSITION_WIDTH
						  if(IDDLE_CURSOR_POSITION_Y > IDDLE_CURSOR_POSITION_HEIGHT)
						  IDDLE_CURSOR_POSITION_Y = IDDLE_CURSOR_POSITION_HEIGHT
						  if(IDDLE_CURSOR_POSITION_X < 0)
						  IDDLE_CURSOR_POSITION_X = 0
						  if(IDDLE_CURSOR_POSITION_Y < 0)
						  IDDLE_CURSOR_POSITION_Y = 0
						  move(IDDLE_CURSOR_POSITION_SCROLL_X + IDDLE_CURSOR_POSITION_X,IDDLE_CURSOR_POSITION_SCROLL_Y + IDDLE_CURSOR_POSITION_Y)!
						  _if(rand(1,10) > 3,function(){
						  sleep(rand(10,300))!
						  })!
						  })!
						  })!
						  _if(IDDLE_EMULATION_CURRENT_ITEM == 4, function(){
						  //sleep
						  sleep(rand(500,5000))!
						  })!
						  })!
						  

					   })!
					   

					})!
					

				 })!
				 

			  })!
			  

			  
			  
			  /*Browser*/
			  ;_SELECTOR=VAR_HCAPTCHA_PREFIX_SECOND_FRAME + "\u003eXPATH\u003e//div[@class=\u0022crumb-bg\u0022]";
			  get_element_selector(_SELECTOR, false).nowait().exist()!
			  VAR_IS_EXISTS = _result() == 1
			  _if(VAR_IS_EXISTS, function(){
			  get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
			  VAR_IS_EXISTS = _result().indexOf("true")>=0
			  })!
			  

			  
			  
			  _set_if_expression("IVtbSVNfRVhJU1RTXV0=");
			  _if(!VAR_IS_EXISTS,function(){
			  
				 
				 
				 VAR_NUMBER_CRUMB = "0"
				 

				 
				 
				 VAR_HCAPTCHA_INVISIBLE = parseInt(VAR_HCAPTCHA_INVISIBLE) + parseInt(2)
				 

				 
				 
				 _set_if_expression("W1tJU19MT0ddXSA9PSB0cnVl");
				 _if(VAR_IS_LOG == true,function(){
				 
					
					
					_info((_K==="en" ? "Тест": "Очистили кэшированные данные"));
					

				 })!
				 

				 
				 
				 /*Browser*/
				 cache_data_clear()!
				 

			  })!
			  

			  
			  
			  _set_if_expression("W1tJU19FWElTVFNdXQ==");
			  _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
			  
				 
				 
				 _set_if_expression("W1tOVU1CRVJfQ1JVTUJdXSA9PSAw");
				 _if(VAR_NUMBER_CRUMB == 0,function(){
				 
					
					
					/*Browser*/
					;_SELECTOR=VAR_HCAPTCHA_PREFIX_SECOND_FRAME + "\u003eXPATH\u003e//div[@class=\u0022Crumb\u0022]";
					get_element_selector(_SELECTOR, true).length()!
					VAR_ELEMENT_LENGTH = _result()
					

					
					
					_set_if_expression("W1tFTEVNRU5UX0xFTkdUSF1dID4gMA==");
					_if(VAR_ELEMENT_LENGTH > 0,function(){
					
					   
					   
					   VAR_NUMBER_CRUMB = parseInt(VAR_NUMBER_CRUMB) + parseInt(1)
					   

					})!
					

				 })!
				 

				 
				 
				 _set_if_expression("W1tOVU1CRVJfQ1JVTUJdXSA9PSBbW0VMRU1FTlRfTEVOR1RIXV0=");
				 _if(VAR_NUMBER_CRUMB == VAR_ELEMENT_LENGTH,function(){
				 
					
					
					VAR_NUMBER_CRUMB = "0"
					

					
					
					VAR_HCAPTCHA_INVISIBLE = parseInt(VAR_HCAPTCHA_INVISIBLE) + parseInt(2)
					

					
					
					_set_if_expression("W1tJU19MT0ddXSA9PSB0cnVl");
					_if(VAR_IS_LOG == true,function(){
					
					   
					   
					   _info((_K==="en" ? "Тест": "Очистили кэшированные данные"));
					   

					})!
					

					
					
					/*Browser*/
					cache_data_clear()!
					

				 })!
				 

				 
				 
				 _set_if_expression("W1tIQ0FQVENIQV9UWVBFXzJdXSA9PSB0cnVlIHx8IFtbSENBUFRDSEFfVFlQRV8zXV0gPT0gdHJ1ZSB8fCBbW0hDQVBUQ0hBX1RZUEVfNF1dID09IHRydWU=");
				 _if(VAR_HCAPTCHA_TYPE_2 == true || VAR_HCAPTCHA_TYPE_3 == true || VAR_HCAPTCHA_TYPE_4 == true,function(){
				 
					
					
					VAR_HCAPTCHA_INVISIBLE = parseInt(VAR_HCAPTCHA_INVISIBLE) + parseInt(2)
					

					
					
					_set_if_expression("W1tJU19MT0ddXSA9PSB0cnVl");
					_if(VAR_IS_LOG == true,function(){
					
					   
					   
					   _info((_K==="en" ? "Тест": "Очистили кэшированные данные"));
					   

					})!
					

					
					
					/*Browser*/
					cache_data_clear()!
					

				 })!
				 

			  })!
			  

			  
			  
			  _set_if_expression("W1tSRUxPQURfQlVUVE9OX1ldXSA+IFtbQlJPV1NFUl9IRUlHSFRdXS8xMDAqOTkgKyBbW1NDUk9MTF9ZXV0=");
			  _if(VAR_RELOAD_BUTTON_Y > VAR_BROWSER_HEIGHT/100*99 + VAR_SCROLL_Y,function(){
			  
				 
				 
				 /*Browser*/
				 _scroll_to(VAR_SUBMIT_BUTTON_Y + VAR_SUBMIT_BUTTON_Y/100*10)!
				 

			  })!
			  

			  
			  
			  _get_browser_screen_settings()!
			  ;(function(){
			  var result = JSON.parse(_result())
			  VAR_SCROLL_X = result["ScrollX"]
			  VAR_SCROLL_Y = result["ScrollY"]
			  VAR_CURSOR_X = result["CursorX"]
			  VAR_CURSOR_Y = result["CursorY"]
			  VAR_CURSOR_ABSOLUTE_X = result["CursorX"] + result["ScrollX"]
			  VAR_CURSOR_ABSOLUTE_Y = result["CursorY"] + result["ScrollY"]
			  VAR_BROWSER_WIDTH = result["Width"]
			  VAR_BROWSER_HEIGHT = result["Height"]
			  })();
			  

			  
			  
			  _cycle_params().if_else = !(VAR_IS_CHANGED_SCROLL_Y <= VAR_SCROLL_Y + 4 && VAR_IS_CHANGED_SCROLL_Y >= VAR_SCROLL_Y - 4);
			  _set_if_expression("IShbW0lTX0NIQU5HRURfU0NST0xMX1ldXSA8PSBbW1NDUk9MTF9ZXV0gKyA0ICYmIFtbSVNfQ0hBTkdFRF9TQ1JPTExfWV1dID49IFtbU0NST0xMX1ldXSAtIDQp");
			  _if(_cycle_params().if_else,function(){
			  
				 
				 
				 VAR_ELEMENT_SELECTOR = VAR_HCAPTCHA_PREFIX_SECOND_FRAME + "\u003eCSS\u003e .button-submit"
				 

				 
				 
				 _SELECTOR = VAR_ELEMENT_SELECTOR;
				 get_element_selector(_SELECTOR, false).script("(function(){var rect = _BAS_HIDE(BrowserAutomationStudio_GetBoundingClientRect)(self);return (rect.left + positionx) + '|' + (rect.top + positiony) + '|' + (rect.right - rect.left) + '|' + (rect.bottom - rect.top)})();")!
				 var split = _result().split("|");
				 var x = parseInt(split[0]), y = parseInt(split[1]), w = parseInt(split[2]), h = parseInt(split[3]);
				 _get_browser_screen_settings()!
				 var newresult = JSON.parse(_result());
				 var scroll_x = newresult["ScrollX"], scroll_y = newresult["ScrollY"]
				 var margin_top_bottom = 50; //percent
				 var margin_left_top = 50; // percent
				 div = 1;
				 var x_min = x + w/100*margin_left_top + parseInt(scroll_x), x_max = x+w/div-w/100*margin_left_top + parseInt(scroll_x);
				 var y_min = y + h/100*margin_top_bottom + parseInt(scroll_y), y_max = y+h - h/100*margin_top_bottom + parseInt(scroll_y);
				 x = rand(x_min, x_max);
				 y = rand(y_min, y_max);
				 x = x.toFixed();
				 y = y.toFixed();
				 /// Кнопка подтвердить
				 VAR_SUBMIT_BUTTON_X = parseInt(x);
				 VAR_SUBMIT_BUTTON_Y = parseInt(y);
				 

			  })!
			  

			  
			  
			  VAR_SUBMIT_BUTTON_X_CLICK = 0;
			  VAR_SUBMIT_BUTTON_Y_CLICK = 0;
			  VAR_SUBMIT_BUTTON_X_CLICK = VAR_SUBMIT_BUTTON_X + rand(-10,+10);
			  VAR_SUBMIT_BUTTON_Y_CLICK = VAR_SUBMIT_BUTTON_Y + rand(-4,+4);
			  

			  
			  
			  /*Browser*/
			  move(VAR_SUBMIT_BUTTON_X,VAR_SUBMIT_BUTTON_Y,  {"speed": VAR_SPEED,"gravity": VAR_GRAVITY,"deviation": VAR_DEVIATION} )!
			  mouse(VAR_SUBMIT_BUTTON_X,VAR_SUBMIT_BUTTON_Y)!
			  

			  
			  
			  _set_if_expression("W1tOVU1CRVJfQ1JVTUJdXSA9PSAw");
			  _if(VAR_NUMBER_CRUMB == 0,function(){
			  
				 
				 
				 VAR_HCAPTCHA_INVISIBLE = parseInt(VAR_HCAPTCHA_INVISIBLE) + parseInt(2)
				 

				 
				 
				 sleep(rand(100,300))!
				 

			  })!
			  

			  
			  
			  _set_if_expression("W1tOVU1CRVJfQ1JVTUJdXSAhPSAw");
			  _if(VAR_NUMBER_CRUMB != 0,function(){
			  
				 
				 
				 VAR_NUMBER_CRUMB = parseInt(VAR_NUMBER_CRUMB) + parseInt(1)
				 

				 
				 
				 sleep(rand(100,300))!
				 

			  })!
			  

			  
			  
			  _break("function")
			  

		   })!
		   

		   
		   
		   _if(!_cycle_params().if_else,function(){
		   
			  
			  
			  VAR_ERROR_CAPTCHA_UNSOLVABLE_MODULE = parseInt(VAR_ERROR_CAPTCHA_UNSOLVABLE_MODULE) + parseInt(1)
			  

			  
			  
			  /*Browser*/
			  ;_SELECTOR=VAR_HCAPTCHA_PREFIX_SECOND_FRAME + "\u003eCSS\u003e .refresh";
			  get_element_selector(_SELECTOR, false).nowait().exist()!
			  VAR_IS_EXISTS = _result() == 1
			  _if(VAR_IS_EXISTS, function(){
			  get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
			  VAR_IS_EXISTS = _result().indexOf("true")>=0
			  })!
			  

			  
			  
			  _set_if_expression("W1tJU19FWElTVFNdXQ==");
			  _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
			  
				 
				 
				 VAR_HCAPTCHA_INVISIBLE = parseInt(VAR_HCAPTCHA_INVISIBLE) + parseInt(2)
				 

				 
				 
				 _set_if_expression("W1tJU19MT0ddXSA9PSB0cnVl");
				 _if(VAR_IS_LOG == true,function(){
				 
					
					
					_info((_K==="en" ? "Тест": "Очистили кэшированные данные"));
					

				 })!
				 

				 
				 
				 /*Browser*/
				 cache_data_clear()!
				 

				 
				 
				 VAR_NUMBER_CRUMB = "0"
				 

				 
				 
				 /*Browser*/
				 _SELECTOR = VAR_HCAPTCHA_PREFIX_SECOND_FRAME + "\u003eCSS\u003e .refresh";
				 wait_element_visible(_SELECTOR)!
				 _call(_random_point, {})!
				 _if(_result().length > 0, function(){
				 move( {} )!
				 get_element_selector(_SELECTOR, false).clarify(X,Y)!
				 _call(_clarify, {} )!
				 mouse(X,Y)!
				 })!
				 

			  })!
			  

			  
			  
			  sleep(rand(600,950))!
			  

			  
			  
			  _break("function")
			  

		   })!
		   delete _cycle_params().if_else;
		   

		})!
		

	 },null)!
	 

	 
	 
	 _set_if_expression("W1tXQVNfRVJST1JdXQ==");
	 _if(typeof(VAR_WAS_ERROR) !== "undefined" ? (VAR_WAS_ERROR) : undefined,function(){
	 
		
		
		_set_if_expression("W1tMQVNUX0VSUk9SXV0gPT09ICdBYm9ydGVkIEJ5IFVzZXInIHx8IFtbTEFTVF9FUlJPUl1dICA9PT0gJ9Cf0YDQtdGA0LLQsNC90L4g0J/QvtC70YzQt9C+0LLQsNGC0LXQu9C10Lwn");
		_if(VAR_LAST_ERROR === 'Aborted By User' || VAR_LAST_ERROR  === 'Прервано Пользователем',function(){
		
		   
		   
		   _function_return(false)
		   

		})!
		

		
		
		sleep(1000)!
		

	 })!
	 

	 
	 
	 _next("function")
	 

	})!
      

   }
   

function GoodXevilPaySolver_GXP_ReCaptcha_Bypass_No_Exten()
   {
   
      
      
      VAR_APIKEY = _function_argument("apikey")
      

      
      
      VAR_INDEX = _function_argument("index")
      

      
      
      VAR_INVISIBLE = _function_argument("invisible")
      

      
      
      VAR_ENTERPRISE = _function_argument("enterprise")
      

      
      
      VAR_SERVER_URL = "http://127.0.0.1:10000"
      

      
      
      VAR_SERVER_URL = "http://sctg.xyz"
      

      
      
      var regexp_result = native("regexp", "first", JSON.stringify({text: VAR_APIKEY,regexp:("([0-9A-Za-z\u005c|]\u007b20,50\u007d)").toString()}))
      if(regexp_result.length == 0)
      regexp_result = []
      else
      regexp_result = JSON.parse(regexp_result)
      VAR_ALL_MATCH = regexp_result.pop()
      if(typeof(VAR_ALL_MATCH) == 'undefined' || !VAR_ALL_MATCH)
      VAR_ALL_MATCH = ""
      VAR_LIST_WITH_GROUPS = regexp_result
      VAR_APIKEY = regexp_result[0]
      if(typeof(VAR_APIKEY) == 'undefined' || !VAR_APIKEY)
      VAR_APIKEY = ""
      if(regexp_result.length == 0)
      {
      VAR_APIKEY = VAR_ALL_MATCH
      }
      if(VAR_ALL_MATCH != "" && Array.isArray(VAR_ALL_MATCH))
      VAR_LIST_WITH_GROUPS.unshift(VAR_ALL_MATCH)
      

      
      
      VAR_TEMP_DATA2 = 0
      

      
      
      VAR_TEMP_DATA = ""
      

      
      
      _do(function(){
      _set_action_info({ name: "While" });
      VAR_CYCLE_INDEX = _iterator() - 1
      BREAK_CONDITION = VAR_TEMP_DATA2 == 0;
      if(!BREAK_CONDITION)_break();
      
         
         
         _set_if_expression("W1tDWUNMRV9JTkRFWF1dICE9IDA=");
         _if(VAR_CYCLE_INDEX != 0,function(){
         
            
            
            sleep(500)!
            

         })!
         

         
         
         _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gMzA=");
         _if(VAR_CYCLE_INDEX > 30,function(){
         
            
            
            fail((_K==="en" ? "ReCaptcha is not detected on the page" : "ReCaptcha не обнаружена на странице"));
            

         })!
         

         
         
         _call(function()
         {
         _on_fail(function(){
         VAR_LAST_ERROR = _result()
         VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
         VAR_WAS_ERROR = false
         _break(1,true)
         })
         CYCLES.Current().RemoveLabel("function")
         
            
            
            page().script2("function findRecaptchaClients() \u007b\r\n  // eslint-disable-next-line camelcase\r\n  if (typeof (___grecaptcha_cfg) !== \u0027undefined\u0027) \u007b\r\n    // eslint-disable-next-line camelcase, no-undef\r\n    return Object.entries(___grecaptcha_cfg.clients).map(([cid, client]) =\u003e \u007b\r\n      const data = \u007b id: cid, version: cid \u003e= 10000 ? \u0027V3\u0027 : \u0027V2\u0027 \u007d;\r\n      const objects = Object.entries(client).filter(([_, value]) =\u003e value \u0026\u0026 typeof value === \u0027object\u0027);\r\n\r\n      objects.forEach(([toplevelKey, toplevel]) =\u003e \u007b\r\n        const found = Object.entries(toplevel).find(([_, value]) =\u003e (\r\n          value \u0026\u0026 typeof value === \u0027object\u0027 \u0026\u0026 \u0027sitekey\u0027 in value \u0026\u0026 \u0027size\u0027 in value\r\n        ));\r\n     \r\n        if (typeof toplevel === \u0027object\u0027 \u0026\u0026 toplevel instanceof HTMLElement \u0026\u0026 toplevel[\u0027tagName\u0027] === \u0027DIV\u0027)\u007b\r\n            data.pageurl = toplevel.baseURI;\r\n        \u007d\r\n        \r\n        if (found) \u007b\r\n          const [sublevelKey, sublevel] = found;\r\n\r\n          data.sitekey = sublevel.sitekey;\r\n          const callbackKey = data.version === \u0027V2\u0027 ? \u0027callback\u0027 : \u0027promise-callback\u0027;\r\n          const callback = sublevel[callbackKey];\r\n          if (!callback) \u007b\r\n            data.callback = null;\r\n            data.function = null;\r\n          \u007d else \u007b\r\n            data.function = callback;\r\n            const keys = [cid, toplevelKey, sublevelKey, callbackKey].map((key) =\u003e `[\u0027$\u007bkey\u007d\u0027]`).join(\u0027\u0027);\r\n            data.callback = `___grecaptcha_cfg.clients$\u007bkeys\u007d`;\r\n          \u007d\r\n        \u007d\r\n      \u007d);\r\n      return data;\r\n    \u007d);\r\n  \u007d\r\n  return [];\r\n\u007d\r\n\r\nlet res = findRecaptchaClients()\r\n[[TEMP_DATA]] = res;",JSON.stringify(_read_variables(["VAR_TEMP_DATA"])))!
            var _parse_result = JSON.parse(_result())
            _write_variables(JSON.parse(_parse_result.variables))
            if(!_parse_result.is_success)
            fail(_parse_result.error)
            

         },null)!
         

         
         
         _do_with_params({"foreach_data":(VAR_TEMP_DATA)},function(){
         _set_action_info({ name: "Foreach" });
         VAR_CYCLE_INDEX = _iterator() - 1
         if(VAR_CYCLE_INDEX > _cycle_param("foreach_data").length - 1)_break();
         VAR_FOREACH_DATA = _cycle_param("foreach_data")[VAR_CYCLE_INDEX]
         
            
            
            VAR_VERSION_RECAPTCHA = VAR_FOREACH_DATA.version
            

            
            
            _set_if_expression("W1tWRVJTSU9OX1JFQ0FQVENIQV1dID09ICJWMiI=");
            _if(VAR_VERSION_RECAPTCHA == "V2",function(){
            
               
               
               VAR_CAPTCHA_ID = VAR_FOREACH_DATA.id
               

               
               
               _set_if_expression("W1tDQVBUQ0hBX0lEXV0gPT0gW1tJTkRFWF1d");
               _if(VAR_CAPTCHA_ID == VAR_INDEX,function(){
               
                  
                  
                  VAR_TEMP_DATA2 = 1
                  

                  
                  
                  VAR_PAGEURL = VAR_FOREACH_DATA.pageurl
                  

                  
                  
                  _set_if_expression("W1tQQUdFVVJMXV0gPT0gdW5kZWZpbmVk");
                  _if(VAR_PAGEURL == undefined,function(){
                  
                     
                     
                     /*Browser*/
                     url()!
                     VAR_PAGEURL = _result()
                     

                  })!
                  

                  
                  
                  VAR_SITEKEY = VAR_FOREACH_DATA.sitekey
                  

                  
                  
                  VAR_CALLBACK = VAR_FOREACH_DATA.callback
                  

                  
                  
                  VAR_CAPTCHA_ID = VAR_FOREACH_DATA.id
                  

                  
                  
                  VAR_CAPTCHA_ID = parseInt(VAR_CAPTCHA_ID)
                  

                  
                  
                  _break("function")
                  

               })!
               

            })!
            

         })!
         

      })!
      

      
      
      VAR_SAVED_CONTENT = "ERROR"
      

      
      
      _do(function(){
      _set_action_info({ name: "For" });
      VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(0)
      if(VAR_CYCLE_INDEX > parseInt(3))_break();
      
         
         
         _set_if_expression("W1tDWUNMRV9JTkRFWF1dID49IDI=");
         _if(VAR_CYCLE_INDEX >= 2,function(){
         
            
            
            fail((_K==="en" ? "Error solving captcha" : "Ошибка при решении капчи"));
            

         })!
         

         
         
         _call(function()
         {
         _on_fail(function(){
         VAR_LAST_ERROR = _result()
         VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
         VAR_WAS_ERROR = false
         _break(1,true)
         })
         CYCLES.Current().RemoveLabel("function")
         
            
            
            solver_properties_clear("capmonster")
            solver_property("capmonster","serverurl",VAR_SERVER_URL)
            solver_property("capmonster","key",VAR_APIKEY)
            solver_property("capmonster","method","userrecaptcha")
            solver_property("capmonster","pageurl",VAR_PAGEURL)
            solver_property("capmonster","googlekey",VAR_SITEKEY)
            solver_property("capmonster","enterprise",VAR_ENTERPRISE)
            solver_property("capmonster","invisible",VAR_INVISIBLE)
            solve_base64_no_fail("capmonster", "")!
            VAR_SAVED_CONTENT = _result();
            

         },null)!
         

         
         
         VAR_STRING_MATCHES = Boolean(native("regexp", "ismatch", JSON.stringify({text: VAR_SAVED_CONTENT,regexp:("(ERROR)").toString()})) == "true")
         

         
         
         VAR_STRING_MATCHES2 = Boolean(native("regexp", "ismatch", JSON.stringify({text: VAR_SAVED_CONTENT,regexp:("(_FAIL)").toString()})) == "true")
         

         
         
         _set_if_expression("W1tTVFJJTkdfTUFUQ0hFU11dIHx8IFtbU1RSSU5HX01BVENIRVMyXV0=");
         _if(VAR_STRING_MATCHES || VAR_STRING_MATCHES2,function(){
         
            
            
            sleep(1000)!
            

            
            
            _next("function")
            

         })!
         

         
         
         _break("function")
         

      })!
      

      
      
      _call(function()
      {
      _on_fail(function(){
      VAR_LAST_ERROR = _result()
      VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
      VAR_WAS_ERROR = false
      _break(1,true)
      })
      CYCLES.Current().RemoveLabel("function")
      
         
         
         /*Browser*/
         _SELECTOR = " \u003eCSS\u003eiframe[src*=\u0027anchor\u0027]\u003eFRAME\u003e \u003eXPATH\u003e //input[@id=\u0022recaptcha-token\u0022]";
         wait_element(_SELECTOR)!
         get_element_selector(_SELECTOR, false).set_attr("value", VAR_SAVED_CONTENT)!
         

      },null)!
      

      
      
      _call(function()
      {
      _on_fail(function(){
      VAR_LAST_ERROR = _result()
      VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
      VAR_WAS_ERROR = false
      _break(1,true)
      })
      CYCLES.Current().RemoveLabel("function")
      
         
         
         page().script2("var xpath = \u0027//textarea[@name=\u0022g-recaptcha-response\u0022]\u0027;\r\nvar result = document.evaluate(xpath, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null);\r\nvar element = result.singleNodeValue;\r\n\r\nif (element) \u007b\r\n  element.innerText = [[SAVED_CONTENT]];\r\n\u007d\r\n",JSON.stringify(_read_variables(["VAR_SAVED_CONTENT"])))!
         var _parse_result = JSON.parse(_result())
         _write_variables(JSON.parse(_parse_result.variables))
         if(!_parse_result.is_success)
         fail(_parse_result.error)
         

      },null)!
      

      
      
      _call(function()
      {
      _on_fail(function(){
      VAR_LAST_ERROR = _result()
      VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
      VAR_WAS_ERROR = false
      _break(1,true)
      })
      CYCLES.Current().RemoveLabel("function")
      
         
         
         page().script2("function getBindedElements(widget) \u007b\r\n    let elements = \u007b\r\n        button: null,\r\n        textarea: null,\r\n    \u007d;\r\n    if (widget.bindedButtonId) \u007b\r\n        let button = document.querySelector(\u0022#\u0022 + widget.bindedButtonId);\r\n        if (button.length) elements.button = button;\r\n    \u007d else \u007b\r\n        let textarea = document.querySelector(\u0022#\u0022 + widget.containerId + \u0022 textarea[name=g-recaptcha-response]\u0022);\r\n        if (textarea.length) elements.textarea = textarea;\r\n    \u007d\r\n    return elements;\r\n\u007d  \r\n\r\nfunction getForm(widget) \u007b\r\n    let binded = getBindedElements(widget);\r\n    if (binded.textarea) \u007b\r\n        return binded.textarea.closest(\u0022form\u0022);\r\n    \u007d\r\n    return binded.button.closest(\u0022form\u0022);\r\n\u007d\r\n\r\nlet textarea = getBindedElements(window.widgetInfore).textarea;\r\nif (!textarea) \u007b\r\n    textarea = getForm(window.widgetInfore).find(\u0022textarea[name=g-recaptcha-response]\u0022);\r\n\u007d\r\ntextarea.val([[SAVED_CONTENT]]);\r\n\r\nif(window.widgetInfore.callback != null)\u007b\r\n    let func = window.widgetInfore.callback\r\n    let data = [[SAVED_CONTENT]];\r\n    window[func](data);\r\n\u007d",JSON.stringify(_read_variables(["VAR_SAVED_CONTENT"])))!
         var _parse_result = JSON.parse(_result())
         _write_variables(JSON.parse(_parse_result.variables))
         if(!_parse_result.is_success)
         fail(_parse_result.error)
         

      },null)!
      

      
      
      _set_if_expression("W1tDQUxMQkFDS11dICE9IG51bGw=");
      _if(VAR_CALLBACK != null,function(){
      
         
         
         _call(function()
         {
         _on_fail(function(){
         VAR_LAST_ERROR = _result()
         VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
         VAR_WAS_ERROR = false
         _break(1,true)
         })
         CYCLES.Current().RemoveLabel("function")
         
            
            
            VAR_NOW_LTD = VAR_CALLBACK.split("']['")[1].split("'")[0]
            

            
            
            VAR_NOW_LTD = VAR_NOW_LTD.toLowerCase();
            

            
            
            page().script2("function setRecaptchaToken(token, clientIdx = 0, customKey = \u0027k\u0027) \u007b\r\n  var recap = window[\u0022___grecaptcha_cfg\u0022].clients[clientIdx];\r\n  Object.keys(recap).forEach(function(arg) \u007b\r\n      if (recap[arg] != null \u0026\u0026 recap[arg][arg] != null \u0026\u0026 recap[arg][arg][\u0022callback\u0022] != null)  \u007b\r\n           recap[arg][arg].callback(token);\r\n           console.log(\u0027recap token submitted\u0027);\r\n           console.log(\u0027Custom key:\u0027, customKey);\r\n           return;\r\n      \u007d \r\n  \u007d);  \r\n\u007d\r\n\r\nsetRecaptchaToken([[SAVED_CONTENT]], [[CAPTCHA_ID]], [[NOW_LTD]]);",JSON.stringify(_read_variables(["VAR_SAVED_CONTENT","VAR_CAPTCHA_ID","VAR_NOW_LTD"])))!
            var _parse_result = JSON.parse(_result())
            _write_variables(JSON.parse(_parse_result.variables))
            if(!_parse_result.is_success)
            fail(_parse_result.error)
            

         },null)!
         

      })!
      

   }
   

function GoodXevilPaySolver_GXP_IconCaptchaSolver()
   {
   
      
      
      VAR_APIKEY = _function_argument("apikey")
      

      
      
      var regexp_result = native("regexp", "first", JSON.stringify({text: VAR_APIKEY,regexp:("([0-9A-Za-z\u005c|]\u007b20,50\u007d)").toString()}))
      if(regexp_result.length == 0)
      regexp_result = []
      else
      regexp_result = JSON.parse(regexp_result)
      VAR_ALL_MATCH = regexp_result.pop()
      if(typeof(VAR_ALL_MATCH) == 'undefined' || !VAR_ALL_MATCH)
      VAR_ALL_MATCH = ""
      VAR_LIST_WITH_GROUPS = regexp_result
      VAR_APIKEY = regexp_result[0]
      if(typeof(VAR_APIKEY) == 'undefined' || !VAR_APIKEY)
      VAR_APIKEY = ""
      if(regexp_result.length == 0)
      {
      VAR_APIKEY = VAR_ALL_MATCH
      }
      if(VAR_ALL_MATCH != "" && Array.isArray(VAR_ALL_MATCH))
      VAR_LIST_WITH_GROUPS.unshift(VAR_ALL_MATCH)
      

      
      
      /*Browser*/
      ;_SELECTOR=" \u003eCSS\u003e .iconcaptcha-modal";
      get_element_selector(_SELECTOR, false).nowait().exist()!
      VAR_IS_EXISTS = _result() == 1
      _if(VAR_IS_EXISTS, function(){
      get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
      VAR_IS_EXISTS = _result().indexOf("true")>=0
      })!
      

      
      
      /*Browser*/
      ;_SELECTOR=" \u003eCSS\u003e .iconcaptcha-modal__body-icons";
      get_element_selector(_SELECTOR, false).nowait().exist()!
      VAR_IS_EXISTS2 = _result() == 1
      _if(VAR_IS_EXISTS2, function(){
      get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
      VAR_IS_EXISTS2 = _result().indexOf("true")>=0
      })!
      

      
      
      VAR_MAIN_CAPTCHA_ID = " \u003eCSS\u003e .iconcaptcha-modal__body-icons"
      

      
      
      _do(function(){
      _set_action_info({ name: "While" });
      VAR_CYCLE_INDEX = _iterator() - 1
      BREAK_CONDITION = VAR_IS_EXISTS == false && VAR_IS_EXISTS2 == false;
      if(!BREAK_CONDITION)_break();
      
         
         
         _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gMzA=");
         _if(VAR_CYCLE_INDEX > 30,function(){
         
            
            
            fail((_K==="en" ? "Didn't wait for iconcaptcha" : "Не дождался iconcaptcha"));
            

         })!
         

         
         
         sleep(1000)!
         

         
         
         /*Browser*/
         ;_SELECTOR=" \u003eCSS\u003e .iconcaptcha-modal__header";
         get_element_selector(_SELECTOR, false).nowait().exist()!
         VAR_IS_EXISTS2 = _result() == 1
         _if(VAR_IS_EXISTS2, function(){
         get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
         VAR_IS_EXISTS2 = _result().indexOf("true")>=0
         })!
         

         
         
         /*Browser*/
         ;_SELECTOR=" \u003eCSS\u003e .iconcaptcha-modal";
         get_element_selector(_SELECTOR, false).nowait().exist()!
         VAR_IS_EXISTS = _result() == 1
         _if(VAR_IS_EXISTS, function(){
         get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
         VAR_IS_EXISTS = _result().indexOf("true")>=0
         })!
         

         
         
         /*Browser*/
         ;_SELECTOR=" \u003eCSS\u003e #icaptcha-frame\u003eFRAME\u003e \u003eCSS\u003e .captcha-image";
         get_element_selector(_SELECTOR, false).nowait().exist()!
         VAR_IS_EXISTS3 = _result() == 1
         _if(VAR_IS_EXISTS3, function(){
         get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
         VAR_IS_EXISTS3 = _result().indexOf("true")>=0
         })!
         

         
         
         _set_if_expression("W1tJU19FWElTVFMzXV0=");
         _if(typeof(VAR_IS_EXISTS3) !== "undefined" ? (VAR_IS_EXISTS3) : undefined,function(){
         
            
            
            VAR_MAIN_CAPTCHA_ID = " \u003eCSS\u003e #icaptcha-frame\u003eFRAME\u003e \u003eCSS\u003e .captcha-image"
            

            
            
            _break("function")
            

         })!
         

      })!
      

      
      
      _set_if_expression("W1tJU19FWElTVFNdXSAmJiBbW0lTX0VYSVNUUzJdXSA9PSBmYWxzZQ==");
      _if(VAR_IS_EXISTS && VAR_IS_EXISTS2 == false,function(){
      
         
         
         /*Browser*/
         _SELECTOR = " \u003eCSS\u003e .iconcaptcha-modal";
         wait_element_visible(_SELECTOR)!
         _call(_random_point, {})!
         _if(_result().length > 0, function(){
         move( {} )!
         get_element_selector(_SELECTOR, false).clarify(X,Y)!
         _call(_clarify, {} )!
         mouse(X,Y)!
         })!
         

      })!
      

      
      
      /*Browser*/
      scroll(1,1)!
      

      
      
      /*Browser*/
      _SELECTOR = VAR_MAIN_CAPTCHA_ID;
      wait_element(_SELECTOR)!
      get_element_selector(_SELECTOR, false).script("(function(){var rect = _BAS_HIDE(BrowserAutomationStudio_GetBoundingClientRect)(self);return (rect.left + positionx) + '|' + (rect.top + positiony) + '|' + (rect.right - rect.left) + '|' + (rect.bottom - rect.top) + '|' + (rect.left + positionx + scrollx) + '|' + (rect.top + positiony + scrolly)})();")!
      if(_result().length > 0)
      {
      var split = _result().split("|")
      VAR_X = parseInt(split[0])
      VAR_Y = parseInt(split[1])
      VAR_WIDTH = parseInt(split[2])
      VAR_HEIGHT = parseInt(split[3])
      VAR_ABSOLUTE_X = parseInt(split[4])
      VAR_ABSOLUTE_Y = parseInt(split[5])
      }
      

      
      
      /*Browser*/
      move(VAR_X -3,VAR_Y - 20,  {} )!
      

      
      
      /*Browser*/
      _SELECTOR = VAR_MAIN_CAPTCHA_ID;
      wait_element(_SELECTOR)!
      get_element_selector(_SELECTOR, false).exist()!
      _if(_result() == "1", function(){
      get_element_selector(_SELECTOR, false).render_base64()!
      VAR_ICONCAPTCHAMODAL__BODY = _result()
      })!
      

      
      
      /*Browser*/
      _SELECTOR = VAR_MAIN_CAPTCHA_ID;
      wait_element(_SELECTOR)!
      get_element_selector(_SELECTOR, false).script("(function(){var rect = _BAS_HIDE(BrowserAutomationStudio_GetBoundingClientRect)(self);return (rect.left + positionx) + '|' + (rect.top + positiony) + '|' + (rect.right - rect.left) + '|' + (rect.bottom - rect.top) + '|' + (rect.left + positionx + scrollx) + '|' + (rect.top + positiony + scrolly)})();")!
      if(_result().length > 0)
      {
      var split = _result().split("|")
      VAR_X_L = parseInt(split[0])
      VAR_Y_L = parseInt(split[1])
      VAR_1 = parseInt(split[2])
      VAR_1 = parseInt(split[3])
      VAR_ABSOLUTE_X = parseInt(split[4])
      VAR_ABSOLUTE_Y = parseInt(split[5])
      }
      

      
      
      solver_properties_clear("capmonster")
      solver_property("capmonster","serverurl","http://sctg.xyz")
      solver_property("capmonster","key",VAR_APIKEY)
      solver_property("capmonster","method","rscaptcha")
      solver_property("capmonster","body",VAR_ICONCAPTCHAMODAL__BODY)
      solve_base64_no_fail("capmonster", "")!
      VAR_SAVED_CONTENT = _result();
      

      
      
      VAR_STRING_MATCHES = Boolean(native("regexp", "ismatch", JSON.stringify({text: VAR_SAVED_CONTENT,regexp:("(ERROR)").toString()})) == "true")
      

      
      
      VAR_STRING_MATCHES2 = Boolean(native("regexp", "ismatch", JSON.stringify({text: VAR_SAVED_CONTENT,regexp:("(_FAIL)").toString()})) == "true")
      

      
      
      VAR_STRING_MATCHES3 = Boolean(native("regexp", "ismatch", JSON.stringify({text: VAR_SAVED_CONTENT,regexp:("(_)").toString()})) == "true")
      

      
      
      _set_if_expression("W1tTVFJJTkdfTUFUQ0hFU11dIHx8IFtbU1RSSU5HX01BVENIRVMyXV0gfHwgW1tTVFJJTkdfTUFUQ0hFUzNdXQ==");
      _if(VAR_STRING_MATCHES || VAR_STRING_MATCHES2 || VAR_STRING_MATCHES3,function(){
      
         
         
         fail((_K==="en" ? "Captcha is not solved" : "Капча не решена"));
         

      })!
      

      
      
      VAR_SCAN_RESULT_LIST = native("regexp", "scan", JSON.stringify({text: VAR_SAVED_CONTENT,regexp:("\u005cd+").toString()}))
      if(VAR_SCAN_RESULT_LIST.length == 0)
      VAR_SCAN_RESULT_LIST = []
      else
      VAR_SCAN_RESULT_LIST = JSON.parse(VAR_SCAN_RESULT_LIST)
      

      
      
      VAR_LIST_LENGTH = (VAR_SCAN_RESULT_LIST).length
      

      
      
      _set_if_expression("W1tMSVNUX0xFTkdUSF1dICE9IDI=");
      _if(VAR_LIST_LENGTH != 2,function(){
      
         
         
         fail((_K==="en" ? "Unclear response from the server" : "Не понятный ответ от сервера"));
         

      })!
      

      
      
      VAR_X_XEVIL = parseInt(VAR_SCAN_RESULT_LIST[0]);
      VAR_Y_XEVIL = parseInt(VAR_SCAN_RESULT_LIST[1]);
      

      
      
      /*Browser*/
      move(VAR_X + VAR_X_XEVIL,VAR_Y + VAR_Y_XEVIL,  {} )!
      mouse(VAR_X + VAR_X_XEVIL,VAR_Y + VAR_Y_XEVIL)!
      

   }
   

function GoodXevilPaySolver_GXP_reCaptcha_inform()
   {
   
      
      
      page().script2("function findRecaptchaClients() \u007b\r\n  // eslint-disable-next-line camelcase\r\n  if (typeof (___grecaptcha_cfg) !== \u0027undefined\u0027) \u007b\r\n    // eslint-disable-next-line camelcase, no-undef\r\n    return Object.entries(___grecaptcha_cfg.clients).map(([cid, client]) =\u003e \u007b\r\n      const data = \u007b id: cid, version: cid \u003e= 10000 ? \u0027V3\u0027 : \u0027V2\u0027 \u007d;\r\n      const objects = Object.entries(client).filter(([_, value]) =\u003e value \u0026\u0026 typeof value === \u0027object\u0027);\r\n\r\n      objects.forEach(([toplevelKey, toplevel]) =\u003e \u007b\r\n        const found = Object.entries(toplevel).find(([_, value]) =\u003e (\r\n          value \u0026\u0026 typeof value === \u0027object\u0027 \u0026\u0026 \u0027sitekey\u0027 in value \u0026\u0026 \u0027size\u0027 in value\r\n        ));\r\n     \r\n        if (typeof toplevel === \u0027object\u0027 \u0026\u0026 toplevel instanceof HTMLElement \u0026\u0026 toplevel[\u0027tagName\u0027] === \u0027DIV\u0027)\u007b\r\n            data.pageurl = toplevel.baseURI;\r\n        \u007d\r\n        \r\n        if (found) \u007b\r\n          const [sublevelKey, sublevel] = found;\r\n\r\n          data.sitekey = sublevel.sitekey;\r\n          const callbackKey = data.version === \u0027V2\u0027 ? \u0027callback\u0027 : \u0027promise-callback\u0027;\r\n          const callback = sublevel[callbackKey];\r\n          if (!callback) \u007b\r\n            data.callback = null;\r\n            data.function = null;\r\n          \u007d else \u007b\r\n            data.function = callback;\r\n            const keys = [cid, toplevelKey, sublevelKey, callbackKey].map((key) =\u003e `[\u0027$\u007bkey\u007d\u0027]`).join(\u0027\u0027);\r\n            data.callback = `___grecaptcha_cfg.clients$\u007bkeys\u007d`;\r\n          \u007d\r\n        \u007d\r\n      \u007d);\r\n      return data;\r\n    \u007d);\r\n  \u007d\r\n  return [];\r\n\u007d\r\n\r\nlet res = findRecaptchaClients()\r\n[[RECAPTCHA_DATA]] = res;",JSON.stringify(_read_variables(["VAR_RECAPTCHA_DATA"])))!
      var _parse_result = JSON.parse(_result())
      _write_variables(JSON.parse(_parse_result.variables))
      if(!_parse_result.is_success)
      fail(_parse_result.error)
      

      
      
      _function_return(VAR_RECAPTCHA_DATA)
      

   }
   

function GoodXevilPaySolver_GXP_Cwallet()
   {
   
      
      
      VAR_APIKEY = _function_argument("apikey")
      

      
      
      var regexp_result = native("regexp", "first", JSON.stringify({text: VAR_APIKEY,regexp:("([0-9A-Za-z\u005c|]\u007b20,50\u007d)").toString()}))
      if(regexp_result.length == 0)
      regexp_result = []
      else
      regexp_result = JSON.parse(regexp_result)
      VAR_ALL_MATCH = regexp_result.pop()
      if(typeof(VAR_ALL_MATCH) == 'undefined' || !VAR_ALL_MATCH)
      VAR_ALL_MATCH = ""
      VAR_LIST_WITH_GROUPS = regexp_result
      VAR_APIKEY = regexp_result[0]
      if(typeof(VAR_APIKEY) == 'undefined' || !VAR_APIKEY)
      VAR_APIKEY = ""
      if(regexp_result.length == 0)
      {
      VAR_APIKEY = VAR_ALL_MATCH
      }
      if(VAR_ALL_MATCH != "" && Array.isArray(VAR_ALL_MATCH))
      VAR_LIST_WITH_GROUPS.unshift(VAR_ALL_MATCH)
      

      
      
      /*Browser*/
      ;_SELECTOR=" \u003eXPATH\u003e //div[contains(@class, \u0022captcha\u0022) and @style]";
      get_element_selector(_SELECTOR, false).nowait().exist()!
      VAR_IS_EXISTS = _result() == 1
      _if(VAR_IS_EXISTS, function(){
      get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
      VAR_IS_EXISTS = _result().indexOf("true")>=0
      })!
      

      
      
      _set_if_expression("W1tJU19FWElTVFNdXSA9PSBmYWxzZQ==");
      _if(VAR_IS_EXISTS == false,function(){
      
         
         
         _call(function()
         {
         _on_fail(function(){
         VAR_LAST_ERROR = _result()
         VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
         VAR_WAS_ERROR = false
         _break(1,true)
         })
         CYCLES.Current().RemoveLabel("function")
         
            
            
            /*Browser*/
            waiter_timeout_next(15000)
            wait_async_load()!
            

         },null)!
         

         
         
         /*Browser*/
         ;_SELECTOR=" \u003eXPATH\u003e //div[contains(@class, \u0022captcha\u0022) and @style]";
         get_element_selector(_SELECTOR, false).nowait().exist()!
         VAR_IS_EXISTS = _result() == 1
         _if(VAR_IS_EXISTS, function(){
         get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
         VAR_IS_EXISTS = _result().indexOf("true")>=0
         })!
         

         
         
         _set_if_expression("W1tJU19FWElTVFNdXSA9PSBmYWxzZQ==");
         _if(VAR_IS_EXISTS == false,function(){
         
            
            
            fail((_K==="en" ? "No captcha found" : "Капча не найдена"));
            

         })!
         

      })!
      

      
      
      VAR_GOOD_SOLV = false
      

      
      
      _do(function(){
      _set_action_info({ name: "For" });
      VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(0)
      if(VAR_CYCLE_INDEX > parseInt(5))_break();
      
         
         
         _set_if_expression("W1tHT09EX1NPTFZdXQ==");
         _if(typeof(VAR_GOOD_SOLV) !== "undefined" ? (VAR_GOOD_SOLV) : undefined,function(){
         
            
            
            /*Browser*/
            ;_SELECTOR=" \u003eXPATH\u003e //div[contains(@class, \u0022captcha\u0022)]/h5[text()]";
            get_element_selector(_SELECTOR, false).nowait().exist()!
            VAR_IS_EXISTS = _result() == 1
            _if(VAR_IS_EXISTS, function(){
            get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
            VAR_IS_EXISTS = _result().indexOf("true")>=0
            })!
            

            
            
            _cycle_params().if_else = typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined;
            _set_if_expression("W1tJU19FWElTVFNdXQ==");
            _if(_cycle_params().if_else,function(){
            
               
               
               VAR_GOOD_SOLV = false
               

            })!
            

            
            
            _if(!_cycle_params().if_else,function(){
            
               
               
               _break("function")
               

            })!
            delete _cycle_params().if_else;
            

         })!
         

         
         
         _set_if_expression("W1tDWUNMRV9JTkRFWF1dID09IDQ=");
         _if(VAR_CYCLE_INDEX == 4,function(){
         
            
            
            fail((_K==="en" ? "Captcha is not solved" : "Капча не решена"));
            

         })!
         

         
         
         _set_if_expression("W1tDWUNMRV9JTkRFWF1dICE9IDA=");
         _if(VAR_CYCLE_INDEX != 0,function(){
         
            
            
            /*Browser*/
            _SELECTOR = " \u003eXPATH\u003e //div[contains(@class, \u0022captcha\u0022)]/button[contains(@class, \u0022icon-button\u0022)]";
            wait_element_visible(_SELECTOR)!
            _call(_random_point, {})!
            _if(_result().length > 0, function(){
            move( {} )!
            get_element_selector(_SELECTOR, false).clarify(X,Y)!
            _call(_clarify, {} )!
            mouse(X,Y)!
            })!
            

            
            
            _call(function()
            {
            _on_fail(function(){
            VAR_LAST_ERROR = _result()
            VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
            VAR_WAS_ERROR = false
            _break(1,true)
            })
            CYCLES.Current().RemoveLabel("function")
            
               
               
               /*Browser*/
               waiter_timeout_next(15000)
               wait_async_load()!
               

            },null)!
            

         })!
         

         
         
         /*Browser*/
         _SELECTOR = " \u003eXPATH\u003e //div[contains(@class, \u0022captcha\u0022) and @style]";
         wait_element(_SELECTOR)!
         get_element_selector(_SELECTOR, false).exist()!
         _if(_result() == "1", function(){
         get_element_selector(_SELECTOR, false).render_base64()!
         VAR_SCREENSHOT_BASE64 = _result()
         })!
         

         
         
         /*Browser*/
         scroll(1,1)!
         

         
         
         /*Browser*/
         _SELECTOR = " \u003eXPATH\u003e //div[contains(@class, \u0022captcha\u0022) and @style]";
         wait_element(_SELECTOR)!
         get_element_selector(_SELECTOR, false).script("(function(){var rect = _BAS_HIDE(BrowserAutomationStudio_GetBoundingClientRect)(self);return (rect.left + positionx) + '|' + (rect.top + positiony) + '|' + (rect.right - rect.left) + '|' + (rect.bottom - rect.top) + '|' + (rect.left + positionx + scrollx) + '|' + (rect.top + positiony + scrolly)})();")!
         if(_result().length > 0)
         {
         var split = _result().split("|")
         VAR_X = parseInt(split[0])
         VAR_Y = parseInt(split[1])
         VAR_WIDTH = parseInt(split[2])
         VAR_HEIGHT = parseInt(split[3])
         VAR_ABSOLUTE_X = parseInt(split[4])
         VAR_ABSOLUTE_Y = parseInt(split[5])
         }
         

         
         
         solver_properties_clear("capmonster")
         solver_property("capmonster","serverurl","http://sctg.xyz/")
         solver_property("capmonster","key",VAR_APIKEY)
         solver_property("capmonster","method","cwallet")
         solver_property("capmonster","body",VAR_SCREENSHOT_BASE64)
         solve_base64_no_fail("capmonster", "")!
         VAR_SAVED_CONTENT = _result();
         

         
         
         VAR_STRING_MATCHES = Boolean(native("regexp", "ismatch", JSON.stringify({text: VAR_SAVED_CONTENT,regexp:("(ERROR)").toString()})) == "true")
         

         
         
         VAR_STRING_MATCHES2 = Boolean(native("regexp", "ismatch", JSON.stringify({text: VAR_SAVED_CONTENT,regexp:("(_FAIL)").toString()})) == "true")
         

         
         
         VAR_STRING_MATCHES3 = Boolean(native("regexp", "ismatch", JSON.stringify({text: VAR_SAVED_CONTENT,regexp:("(_)").toString()})) == "true")
         

         
         
         _set_if_expression("W1tTVFJJTkdfTUFUQ0hFU11dIHx8IFtbU1RSSU5HX01BVENIRVMyXV0gfHwgW1tTVFJJTkdfTUFUQ0hFUzNdXQ==");
         _if(VAR_STRING_MATCHES || VAR_STRING_MATCHES2 || VAR_STRING_MATCHES3,function(){
         
            
            
            _next("function")
            

         })!
         

         
         
         VAR_PARSED_LIST = (VAR_SAVED_CONTENT).split(";")
         

         
         
         VAR_LIST_LENGTH = (VAR_PARSED_LIST).length
         

         
         
         _set_if_expression("W1tMSVNUX0xFTkdUSF1dIDwgMw==");
         _if(VAR_LIST_LENGTH < 3,function(){
         
            
            
            _next("function")
            

         })!
         

         
         
         /*Browser*/
         scroll(1,1)!
         

         
         
         _do_with_params({"foreach_data":(VAR_PARSED_LIST)},function(){
         _set_action_info({ name: "Foreach" });
         VAR_CYCLE_INDEX = _iterator() - 1
         if(VAR_CYCLE_INDEX > _cycle_param("foreach_data").length - 1)_break();
         VAR_FOREACH_DATA = _cycle_param("foreach_data")[VAR_CYCLE_INDEX]
         
            
            
            VAR_SCAN_RESULT_LIST = native("regexp", "scan", JSON.stringify({text: VAR_FOREACH_DATA,regexp:("\u005cd+").toString()}))
            if(VAR_SCAN_RESULT_LIST.length == 0)
            VAR_SCAN_RESULT_LIST = []
            else
            VAR_SCAN_RESULT_LIST = JSON.parse(VAR_SCAN_RESULT_LIST)
            

            
            
            VAR_LIST_LENGTH = (VAR_SCAN_RESULT_LIST).length
            

            
            
            _set_if_expression("W1tMSVNUX0xFTkdUSF1dICE9IDI=");
            _if(VAR_LIST_LENGTH != 2,function(){
            
               
               
               fail_user("Не понятный ответ от сервера: " + VAR_SAVED_CONTENT,false)
               

            })!
            

            
            
            VAR_X_XEVIL = parseInt(VAR_SCAN_RESULT_LIST[0]);
            VAR_Y_XEVIL = parseInt(VAR_SCAN_RESULT_LIST[1]);
            

            
            
            /*Browser*/
            move(VAR_X + VAR_X_XEVIL,VAR_Y + VAR_Y_XEVIL,  {} )!
            mouse(VAR_X + VAR_X_XEVIL,VAR_Y + VAR_Y_XEVIL)!
            

         })!
         

         
         
         /*Browser*/
         _SELECTOR = " \u003eXPATH\u003e //div[contains(@class, \u0022captcha\u0022)]/button/div[@class=\u0022button-inner\u0022]";
         wait_element_visible(_SELECTOR)!
         _call(_random_point, {})!
         _if(_result().length > 0, function(){
         move( {} )!
         get_element_selector(_SELECTOR, false).clarify(X,Y)!
         _call(_clarify, {} )!
         mouse(X,Y)!
         })!
         

         
         
         VAR_GOOD_SOLV = true
         

         
         
         _call(function()
         {
         _on_fail(function(){
         VAR_LAST_ERROR = _result()
         VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
         VAR_WAS_ERROR = false
         _break(1,true)
         })
         CYCLES.Current().RemoveLabel("function")
         
            
            
            /*Browser*/
            waiter_timeout_next(15000)
            wait_async_load()!
            

         },null)!
         

      })!
      

   }
   

function GoodXevilPaySolver_GXP_RsCaptchaSolver()
   {
   
      
      
      VAR_APIKEY = _function_argument("apikey")
      

      
      
      var regexp_result = native("regexp", "first", JSON.stringify({text: VAR_APIKEY,regexp:("([0-9A-Za-z\u005c|]\u007b20,50\u007d)").toString()}))
      if(regexp_result.length == 0)
      regexp_result = []
      else
      regexp_result = JSON.parse(regexp_result)
      VAR_ALL_MATCH = regexp_result.pop()
      if(typeof(VAR_ALL_MATCH) == 'undefined' || !VAR_ALL_MATCH)
      VAR_ALL_MATCH = ""
      VAR_LIST_WITH_GROUPS = regexp_result
      VAR_APIKEY = regexp_result[0]
      if(typeof(VAR_APIKEY) == 'undefined' || !VAR_APIKEY)
      VAR_APIKEY = ""
      if(regexp_result.length == 0)
      {
      VAR_APIKEY = VAR_ALL_MATCH
      }
      if(VAR_ALL_MATCH != "" && Array.isArray(VAR_ALL_MATCH))
      VAR_LIST_WITH_GROUPS.unshift(VAR_ALL_MATCH)
      

      
      
      /*Browser*/
      _SELECTOR = " \u003eXPATH\u003e //img[@id=\u0022rscaptcha_img\u0022]";
      wait_element(_SELECTOR)!
      get_element_selector(_SELECTOR, false).exist()!
      _if(_result() == "1", function(){
      get_element_selector(_SELECTOR, false).render_base64()!
      VAR_ICONCAPTCHAMODAL__BODY = _result()
      })!
      

      
      
      /*Browser*/
      scroll(1,1)!
      

      
      
      /*Browser*/
      _SELECTOR = " \u003eXPATH\u003e //img[@id=\u0022rscaptcha_img\u0022]";
      wait_element(_SELECTOR)!
      get_element_selector(_SELECTOR, false).script("(function(){var rect = _BAS_HIDE(BrowserAutomationStudio_GetBoundingClientRect)(self);return (rect.left + positionx) + '|' + (rect.top + positiony) + '|' + (rect.right - rect.left) + '|' + (rect.bottom - rect.top) + '|' + (rect.left + positionx + scrollx) + '|' + (rect.top + positiony + scrolly)})();")!
      if(_result().length > 0)
      {
      var split = _result().split("|")
      VAR_X = parseInt(split[0])
      VAR_Y = parseInt(split[1])
      VAR_WITH_DATA = parseInt(split[2])
      VAR_HEIGHT_DATA = parseInt(split[3])
      VAR_ABSOLUTE_X = parseInt(split[4])
      VAR_ABSOLUTE_Y = parseInt(split[5])
      }
      

      
      
      solver_properties_clear("capmonster")
      solver_property("capmonster","serverurl","http://sctg.xyz/")
      solver_property("capmonster","key",VAR_APIKEY)
      solver_property("capmonster","method","rscaptcha")
      solver_property("capmonster","body",VAR_ICONCAPTCHAMODAL__BODY)
      solve_base64_no_fail("capmonster", "")!
      VAR_SAVED_CONTENT = _result();
      

      
      
      VAR_STRING_MATCHES = Boolean(native("regexp", "ismatch", JSON.stringify({text: VAR_SAVED_CONTENT,regexp:("(ERROR)").toString()})) == "true")
      

      
      
      VAR_STRING_MATCHES2 = Boolean(native("regexp", "ismatch", JSON.stringify({text: VAR_SAVED_CONTENT,regexp:("(_FAIL)").toString()})) == "true")
      

      
      
      VAR_STRING_MATCHES3 = Boolean(native("regexp", "ismatch", JSON.stringify({text: VAR_SAVED_CONTENT,regexp:("(_)").toString()})) == "true")
      

      
      
      _set_if_expression("W1tTVFJJTkdfTUFUQ0hFU11dIHx8IFtbU1RSSU5HX01BVENIRVMyXV0gfHwgW1tTVFJJTkdfTUFUQ0hFUzNdXQ==");
      _if(VAR_STRING_MATCHES || VAR_STRING_MATCHES2 || VAR_STRING_MATCHES3,function(){
      
         
         
         fail((_K==="en" ? "Captcha is not solved" : "Капча не решена"));
         

      })!
      

      
      
      VAR_SCAN_RESULT_LIST = native("regexp", "scan", JSON.stringify({text: VAR_SAVED_CONTENT,regexp:("\u005cd+").toString()}))
      if(VAR_SCAN_RESULT_LIST.length == 0)
      VAR_SCAN_RESULT_LIST = []
      else
      VAR_SCAN_RESULT_LIST = JSON.parse(VAR_SCAN_RESULT_LIST)
      

      
      
      VAR_LIST_LENGTH = (VAR_SCAN_RESULT_LIST).length
      

      
      
      _set_if_expression("W1tMSVNUX0xFTkdUSF1dICE9IDI=");
      _if(VAR_LIST_LENGTH != 2,function(){
      
         
         
         fail((_K==="en" ? "Unclear response from the server" : "Не понятный ответ от сервера"));
         

      })!
      

      
      
      VAR_X_XEVIL = parseInt(VAR_SCAN_RESULT_LIST[0]);
      VAR_Y_XEVIL = parseInt(VAR_SCAN_RESULT_LIST[1]);
      

      
      
      /*Browser*/
      move(VAR_X + VAR_X_XEVIL,VAR_Y + VAR_Y_XEVIL,  {} )!
      mouse(VAR_X + VAR_X_XEVIL,VAR_Y + VAR_Y_XEVIL)!
      

   }
   

function GoodXevilPaySolver_GXP_Namars()
   {
   
      
      
      VAR_APIKEY = _function_argument("apikey")
      

      
      
      var regexp_result = native("regexp", "first", JSON.stringify({text: VAR_APIKEY,regexp:("([0-9A-Za-z\u005c|]\u007b20,50\u007d)").toString()}))
      if(regexp_result.length == 0)
      regexp_result = []
      else
      regexp_result = JSON.parse(regexp_result)
      VAR_ALL_MATCH = regexp_result.pop()
      if(typeof(VAR_ALL_MATCH) == 'undefined' || !VAR_ALL_MATCH)
      VAR_ALL_MATCH = ""
      VAR_LIST_WITH_GROUPS = regexp_result
      VAR_APIKEY = regexp_result[0]
      if(typeof(VAR_APIKEY) == 'undefined' || !VAR_APIKEY)
      VAR_APIKEY = ""
      if(regexp_result.length == 0)
      {
      VAR_APIKEY = VAR_ALL_MATCH
      }
      if(VAR_ALL_MATCH != "" && Array.isArray(VAR_ALL_MATCH))
      VAR_LIST_WITH_GROUPS.unshift(VAR_ALL_MATCH)
      

      
      
      VAR_IMAGE_DATA = ""
      

      
      
      _do(function(){
      _set_action_info({ name: "While" });
      VAR_CYCLE_INDEX = _iterator() - 1
      BREAK_CONDITION = true;
      if(!BREAK_CONDITION)_break();
      
         
         
         _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gMTU=");
         _if(VAR_CYCLE_INDEX > 15,function(){
         
            
            
            fail((_K==="en" ? "Couldn't decide to find the captcha" : "Не смог решить найти капчу"));
            

         })!
         

         
         
         sleep(1000)!
         

         
         
         /*Browser*/
         wait_load("*namars.com/captcha/*")!
         cache_get_base64("*namars.com/captcha/*")!
         VAR_IMAGE_DATA = _result()
         

         
         
         _set_if_expression("W1tJTUFHRV9EQVRBXV0gIT0gIiI=");
         _if(VAR_IMAGE_DATA != "",function(){
         
            
            
            _break("function")
            

         })!
         

      })!
      

      
      
      solver_properties_clear("capmonster")
      solver_property("capmonster","serverurl","http://sctg.xyz/")
      solver_property("capmonster","key",VAR_APIKEY)
      solver_property("capmonster","method","base64")
      solver_property("capmonster","body",VAR_IMAGE_DATA)
      solve_base64_no_fail("capmonster", "")!
      VAR_SAVED_CONTENT = _result();
      

      
      
      _function_return(VAR_SAVED_CONTENT)
      

   }
   

function GoodXevilPaySolver_GXP_Namars_CacheAllow()
   {
   
      
      
      /*Browser*/
      cache_allow("*namars.com/captcha/*")!
      

   }
   

function GoodXevilPaySolver_GXP_teaserfast()
   {
   
      
      
      VAR_APIKEY = _function_argument("apikey")
      

      
      
      var regexp_result = native("regexp", "first", JSON.stringify({text: VAR_APIKEY,regexp:("([0-9A-Za-z\u005c|]\u007b20,50\u007d)").toString()}))
      if(regexp_result.length == 0)
      regexp_result = []
      else
      regexp_result = JSON.parse(regexp_result)
      VAR_ALL_MATCH = regexp_result.pop()
      if(typeof(VAR_ALL_MATCH) == 'undefined' || !VAR_ALL_MATCH)
      VAR_ALL_MATCH = ""
      VAR_LIST_WITH_GROUPS = regexp_result
      VAR_APIKEY = regexp_result[0]
      if(typeof(VAR_APIKEY) == 'undefined' || !VAR_APIKEY)
      VAR_APIKEY = ""
      if(regexp_result.length == 0)
      {
      VAR_APIKEY = VAR_ALL_MATCH
      }
      if(VAR_ALL_MATCH != "" && Array.isArray(VAR_ALL_MATCH))
      VAR_LIST_WITH_GROUPS.unshift(VAR_ALL_MATCH)
      

      
      
      VAR_NOW_ID_FRAME = ""
      

      
      
      VAR_GOOD_SOLVE = 0
      

      
      
      VAR_TYPE_DATA = "1"
      

      
      
      _do(function(){
      _set_action_info({ name: "For" });
      VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(0)
      if(VAR_CYCLE_INDEX > parseInt(6))_break();
      
         
         
         _set_if_expression("W1tDWUNMRV9JTkRFWF1dID49IDU=");
         _if(VAR_CYCLE_INDEX >= 5,function(){
         
            
            
            fail((_K==="en" ? "The service was unable to solve the captcha in 3 attempts" : "Сервис не смог решить капчу за 3 попытки"));
            

         })!
         

         
         
         /*Browser*/
         ;_SELECTOR=" \u003eXPATH\u003e //div[@class=\u0022task_captcha\u0022]//div[@id=\u0022tcaptchaimage\u0022]";
         get_element_selector(_SELECTOR, false).nowait().exist()!
         VAR_IS_EXISTS = _result() == 1
         _if(VAR_IS_EXISTS, function(){
         get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
         VAR_IS_EXISTS = _result().indexOf("true")>=0
         })!
         

         
         
         _set_if_expression("W1tJU19FWElTVFNdXQ==");
         _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
         
            
            
            VAR_TYPE_DATA = "1"
            

         })!
         

         
         
         /*Browser*/
         ;_SELECTOR=" \u003eXPATH\u003e //div[@class=\u0022task_captcha\u0022]//div[@id=\u0022t2captchaimage\u0022]";
         get_element_selector(_SELECTOR, false).nowait().exist()!
         VAR_IS_EXISTS2 = _result() == 1
         _if(VAR_IS_EXISTS2, function(){
         get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
         VAR_IS_EXISTS2 = _result().indexOf("true")>=0
         })!
         

         
         
         _set_if_expression("W1tJU19FWElTVFMyXV0=");
         _if(typeof(VAR_IS_EXISTS2) !== "undefined" ? (VAR_IS_EXISTS2) : undefined,function(){
         
            
            
            VAR_TYPE_DATA = "2"
            

         })!
         

         
         
         _set_if_expression("W1tJU19FWElTVFNdXSA9PSBmYWxzZSAmJiBbW0lTX0VYSVNUUzJdXSA9PSBmYWxzZQ==");
         _if(VAR_IS_EXISTS == false && VAR_IS_EXISTS2 == false,function(){
         
            
            
            _set_if_expression("W1tHT09EX1NPTFZFXV0gPT0gMQ==");
            _if(VAR_GOOD_SOLVE == 1,function(){
            
               
               
               _break("function")
               

            })!
            

            
            
            sleep(2000)!
            

            
            
            _next("function")
            

         })!
         

         
         
         /*Browser*/
         page().script("_BAS_HIDE(BrowserAutomationStudio_GetPageContent)()")!
         VAR_SAVED_PAGE_HTML = _result()
         

         
         
         _cycle_params().if_else = VAR_TYPE_DATA == 1;
         _set_if_expression("W1tUWVBFX0RBVEFdXSA9PSAx");
         _if(_cycle_params().if_else,function(){
         
            
            
            html_parser_xpath_parse(VAR_SAVED_PAGE_HTML)
            if((false) && !html_parser_xpath_exist("//div[@class=\u0022task_captcha\u0022]//div[@id=\u0022tcaptchaimage\u0022]/@style"))
            fail("Can't resolve query " + "//div[@class=\u0022task_captcha\u0022]//div[@id=\u0022tcaptchaimage\u0022]/@style");
            VAR_MAIN_IMG = html_parser_xpath_xml("//div[@class=\u0022task_captcha\u0022]//div[@id=\u0022tcaptchaimage\u0022]/@style")
            

         })!
         

         
         
         _if(!_cycle_params().if_else,function(){
         
            
            
            html_parser_xpath_parse(VAR_SAVED_PAGE_HTML)
            if((false) && !html_parser_xpath_exist("//div[@class=\u0022task_captcha\u0022]//div[@id=\u0022t2captchaimage\u0022]/@style"))
            fail("Can't resolve query " + "//div[@class=\u0022task_captcha\u0022]//div[@id=\u0022t2captchaimage\u0022]/@style");
            VAR_MAIN_IMG = html_parser_xpath_xml("//div[@class=\u0022task_captcha\u0022]//div[@id=\u0022t2captchaimage\u0022]/@style")
            

         })!
         delete _cycle_params().if_else;
         

         
         
         html_parser_xpath_parse(VAR_SAVED_PAGE_HTML)
         if((false) && !html_parser_xpath_exist("//div[@class=\u0022task_captcha\u0022]//div[@id=\u0022tcsmallimage\u0022]/@style"))
         fail("Can't resolve query " + "//div[@class=\u0022task_captcha\u0022]//div[@id=\u0022tcsmallimage\u0022]/@style");
         VAR_TASK_IMG = html_parser_xpath_xml("//div[@class=\u0022task_captcha\u0022]//div[@id=\u0022tcsmallimage\u0022]/@style")
         

         
         
         _set_if_expression("W1tUQVNLX0lNR11dID09ICIiIHx8IFtbTUFJTl9JTUddXSA9PSAiIg==");
         _if(VAR_TASK_IMG == "" || VAR_MAIN_IMG == "",function(){
         
            
            
            sleep(1000)!
            

            
            
            _next("function")
            

         })!
         

         
         
         VAR_SCAN_RESULT_LIST = native("regexp", "scan", JSON.stringify({text: VAR_MAIN_IMG,regexp:("([A-Za-z0-9\u005c+/=]+)").toString()}))
         if(VAR_SCAN_RESULT_LIST.length == 0)
         VAR_SCAN_RESULT_LIST = []
         else
         VAR_SCAN_RESULT_LIST = JSON.parse(VAR_SCAN_RESULT_LIST)
         

         
         
         VAR_MAIN_IMG = ""
         

         
         
         VAR_TEMP_INDEX = 0
         

         
         
         _do_with_params({"foreach_data":(VAR_SCAN_RESULT_LIST)},function(){
         _set_action_info({ name: "Foreach" });
         VAR_CYCLE_INDEX = _iterator() - 1
         if(VAR_CYCLE_INDEX > _cycle_param("foreach_data").length - 1)_break();
         VAR_FOREACH_DATA = _cycle_param("foreach_data")[VAR_CYCLE_INDEX]
         
            
            
            _set_if_expression("W1tGT1JFQUNIX0RBVEFdXS5sZW5ndGggPiBbW1RFTVBfSU5ERVhdXQ==");
            _if(VAR_FOREACH_DATA.length > VAR_TEMP_INDEX,function(){
            
               
               
               VAR_TEMP_INDEX = VAR_FOREACH_DATA.length
               

               
               
               VAR_MAIN_IMG = VAR_FOREACH_DATA
               

            })!
            

         })!
         

         
         
         VAR_SCAN_RESULT_LIST = native("regexp", "scan", JSON.stringify({text: VAR_TASK_IMG,regexp:("([A-Za-z0-9\u005c+/=]+)").toString()}))
         if(VAR_SCAN_RESULT_LIST.length == 0)
         VAR_SCAN_RESULT_LIST = []
         else
         VAR_SCAN_RESULT_LIST = JSON.parse(VAR_SCAN_RESULT_LIST)
         

         
         
         VAR_TASK_IMG = ""
         

         
         
         VAR_TEMP_INDEX = 0
         

         
         
         _do_with_params({"foreach_data":(VAR_SCAN_RESULT_LIST)},function(){
         _set_action_info({ name: "Foreach" });
         VAR_CYCLE_INDEX = _iterator() - 1
         if(VAR_CYCLE_INDEX > _cycle_param("foreach_data").length - 1)_break();
         VAR_FOREACH_DATA = _cycle_param("foreach_data")[VAR_CYCLE_INDEX]
         
            
            
            _set_if_expression("W1tGT1JFQUNIX0RBVEFdXS5sZW5ndGggPiBbW1RFTVBfSU5ERVhdXQ==");
            _if(VAR_FOREACH_DATA.length > VAR_TEMP_INDEX,function(){
            
               
               
               VAR_TEMP_INDEX = VAR_FOREACH_DATA.length
               

               
               
               VAR_TASK_IMG = VAR_FOREACH_DATA
               

            })!
            

         })!
         

         
         
         _call(function()
         {
         _on_fail(function(){
         VAR_LAST_ERROR = _result()
         VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
         VAR_WAS_ERROR = false
         _break(1,true)
         })
         CYCLES.Current().RemoveLabel("function")
         
            
            
            solver_properties_clear("capmonster")
            solver_property("capmonster","serverurl","http://sctg.xyz/")
            solver_property("capmonster","key",VAR_APIKEY)
            solver_property("capmonster","method","teaserfast")
            solver_property("capmonster","main_photo",VAR_MAIN_IMG)
            solver_property("capmonster","task",VAR_TASK_IMG)
            solve_base64_no_fail("capmonster", "")!
            VAR_SAVED_CONTENT = _result();
            

         },null)!
         

         
         
         _set_if_expression("W1tXQVNfRVJST1JdXQ==");
         _if(typeof(VAR_WAS_ERROR) !== "undefined" ? (VAR_WAS_ERROR) : undefined,function(){
         
            
            
            /*Browser*/
            _SELECTOR = " \u003eCSS\u003e .tcaptcha_update \u003e a";
            wait_element_visible(_SELECTOR)!
            _call(_random_point, {})!
            _if(_result().length > 0, function(){
            move( {} )!
            get_element_selector(_SELECTOR, false).clarify(X,Y)!
            _call(_clarify, {} )!
            mouse(X,Y)!
            })!
            

            
            
            sleep(500)!
            

            
            
            _next("function")
            

         })!
         

         
         
         VAR_STRING_MATCHES = Boolean(native("regexp", "ismatch", JSON.stringify({text: VAR_SAVED_CONTENT,regexp:("(ERROR)").toString()})) == "true")
         

         
         
         VAR_STRING_MATCHES2 = Boolean(native("regexp", "ismatch", JSON.stringify({text: VAR_SAVED_CONTENT,regexp:("(_FAIL)").toString()})) == "true")
         

         
         
         _set_if_expression("W1tTVFJJTkdfTUFUQ0hFU11dIHx8IFtbU1RSSU5HX01BVENIRVMyXV0=");
         _if(VAR_STRING_MATCHES || VAR_STRING_MATCHES2,function(){
         
            
            
            /*Browser*/
            _SELECTOR = " \u003eCSS\u003e .tcaptcha_update \u003e a";
            wait_element_visible(_SELECTOR)!
            _call(_random_point, {})!
            _if(_result().length > 0, function(){
            move( {} )!
            get_element_selector(_SELECTOR, false).clarify(X,Y)!
            _call(_clarify, {} )!
            mouse(X,Y)!
            })!
            

            
            
            sleep(500)!
            

            
            
            _next("function")
            

         })!
         

         
         
         VAR_SCAN_RESULT_LIST = native("regexp", "scan", JSON.stringify({text: VAR_SAVED_CONTENT,regexp:("\u005cd+").toString()}))
         if(VAR_SCAN_RESULT_LIST.length == 0)
         VAR_SCAN_RESULT_LIST = []
         else
         VAR_SCAN_RESULT_LIST = JSON.parse(VAR_SCAN_RESULT_LIST)
         

         
         
         VAR_LIST_LENGTH = (VAR_SCAN_RESULT_LIST).length
         

         
         
         _set_if_expression("W1tMSVNUX0xFTkdUSF1dICE9IDI=");
         _if(VAR_LIST_LENGTH != 2,function(){
         
            
            
            fail((_K==="en" ? "Unclear response from the server: " + VAR_SAVED_CONTENT : "Не понятный ответ от сервера: " + VAR_SAVED_CONTENT));
            

         })!
         

         
         
         /*Browser*/
         scroll(1,1)!
         

         
         
         _cycle_params().if_else = VAR_TYPE_DATA == 1;
         _set_if_expression("W1tUWVBFX0RBVEFdXSA9PSAx");
         _if(_cycle_params().if_else,function(){
         
            
            
            /*Browser*/
            _SELECTOR = " \u003eXPATH\u003e //div[@class=\u0022task_captcha\u0022]//div[@id=\u0022tcaptchaimage\u0022]";waiter_timeout_next(1000)
            waiter_nofail_next();
            wait_element(_SELECTOR)!
            get_element_selector(_SELECTOR, false).nowait().script("(function(){var rect = _BAS_HIDE(BrowserAutomationStudio_GetBoundingClientRect)(self);return (rect.left + positionx) + '|' + (rect.top + positiony) + '|' + (rect.right - rect.left) + '|' + (rect.bottom - rect.top) + '|' + (rect.left + positionx + scrollx) + '|' + (rect.top + positiony + scrolly)})();")!
            if(_result().length > 0)
            {
            var split = _result().split("|")
            VAR_X = parseInt(split[0])
            VAR_Y = parseInt(split[1])
            VAR_WIDTH = parseInt(split[2])
            VAR_HEIGHT = parseInt(split[3])
            VAR_ABSOLUTE_X = parseInt(split[4])
            VAR_ABSOLUTE_Y = parseInt(split[5])
            }
            

         })!
         

         
         
         _if(!_cycle_params().if_else,function(){
         
            
            
            /*Browser*/
            _SELECTOR = " \u003eXPATH\u003e //div[@class=\u0022task_captcha\u0022]//div[@id=\u0022t2captchaimage\u0022]";waiter_timeout_next(1000)
            waiter_nofail_next();
            wait_element(_SELECTOR)!
            get_element_selector(_SELECTOR, false).nowait().script("(function(){var rect = _BAS_HIDE(BrowserAutomationStudio_GetBoundingClientRect)(self);return (rect.left + positionx) + '|' + (rect.top + positiony) + '|' + (rect.right - rect.left) + '|' + (rect.bottom - rect.top) + '|' + (rect.left + positionx + scrollx) + '|' + (rect.top + positiony + scrolly)})();")!
            if(_result().length > 0)
            {
            var split = _result().split("|")
            VAR_X = parseInt(split[0])
            VAR_Y = parseInt(split[1])
            VAR_WIDTH = parseInt(split[2])
            VAR_HEIGHT = parseInt(split[3])
            VAR_ABSOLUTE_X = parseInt(split[4])
            VAR_ABSOLUTE_Y = parseInt(split[5])
            }
            

         })!
         delete _cycle_params().if_else;
         

         
         
         VAR_X_XEVIL = parseInt(VAR_SCAN_RESULT_LIST[0]);
         VAR_Y_XEVIL = parseInt(VAR_SCAN_RESULT_LIST[1]);
         

         
         
         /*Browser*/
         move(VAR_X + VAR_X_XEVIL - 2,VAR_Y + VAR_Y_XEVIL - 2,  {} )!
         mouse(VAR_X + VAR_X_XEVIL - 2,VAR_Y + VAR_Y_XEVIL - 2)!
         

         
         
         /*Browser*/
         _SELECTOR = " \u003eXPATH\u003e //a[contains(@onclick, \u0022submit_captha\u0022)]";waiter_timeout_next(1000)
         waiter_nofail_next();
         wait_element_visible(_SELECTOR)!
         _call(_random_point, {})!
         _if(_result().length > 0, function(){
         move( {} )!
         get_element_selector(_SELECTOR, false).nowait().clarify(X,Y)!
         _call(_clarify, {} )!
         mouse(X,Y)!
         })!
         

         
         
         VAR_GOOD_SOLVE = 1
         

         
         
         sleep(1000)!
         

      })!
      

   }
   

function GoodXevilPaySolver_GXP_WorkCash()
   {
   
      
      
      VAR_APIKEY = _function_argument("apikey")
      

      
      
      var regexp_result = native("regexp", "first", JSON.stringify({text: VAR_APIKEY,regexp:("([0-9A-Za-z\u005c|]\u007b20,50\u007d)").toString()}))
      if(regexp_result.length == 0)
      regexp_result = []
      else
      regexp_result = JSON.parse(regexp_result)
      VAR_ALL_MATCH = regexp_result.pop()
      if(typeof(VAR_ALL_MATCH) == 'undefined' || !VAR_ALL_MATCH)
      VAR_ALL_MATCH = ""
      VAR_LIST_WITH_GROUPS = regexp_result
      VAR_APIKEY = regexp_result[0]
      if(typeof(VAR_APIKEY) == 'undefined' || !VAR_APIKEY)
      VAR_APIKEY = ""
      if(regexp_result.length == 0)
      {
      VAR_APIKEY = VAR_ALL_MATCH
      }
      if(VAR_ALL_MATCH != "" && Array.isArray(VAR_ALL_MATCH))
      VAR_LIST_WITH_GROUPS.unshift(VAR_ALL_MATCH)
      

      
      
      /*Browser*/
      ;_SELECTOR=" \u003eXPATH\u003e //div[contains(@class, \u0022captcha\u0022)]/div[@class=\u0022wrapper\u0022]/div\u003eAT\u003e0";
      get_element_selector(_SELECTOR, false).nowait().exist()!
      VAR_IS_EXISTS = _result() == 1
      _if(VAR_IS_EXISTS, function(){
      get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
      VAR_IS_EXISTS = _result().indexOf("true")>=0
      })!
      

      
      
      _set_if_expression("W1tJU19FWElTVFNdXSA9PSBmYWxzZQ==");
      _if(VAR_IS_EXISTS == false,function(){
      
         
         
         _call(function()
         {
         _on_fail(function(){
         VAR_LAST_ERROR = _result()
         VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
         VAR_WAS_ERROR = false
         _break(1,true)
         })
         CYCLES.Current().RemoveLabel("function")
         
            
            
            /*Browser*/
            waiter_timeout_next(15000)
            wait_async_load()!
            

         },null)!
         

         
         
         /*Browser*/
         ;_SELECTOR=" \u003eXPATH\u003e //div[contains(@class, \u0022captcha\u0022)]/div[@class=\u0022wrapper\u0022]/div\u003eAT\u003e0";
         get_element_selector(_SELECTOR, false).nowait().exist()!
         VAR_IS_EXISTS = _result() == 1
         _if(VAR_IS_EXISTS, function(){
         get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
         VAR_IS_EXISTS = _result().indexOf("true")>=0
         })!
         

         
         
         _set_if_expression("W1tJU19FWElTVFNdXSA9PSBmYWxzZQ==");
         _if(VAR_IS_EXISTS == false,function(){
         
            
            
            fail((_K==="en" ? "Captcha was not found" : "Капча не найдена"));
            

         })!
         

      })!
      

      
      
      /*Browser*/
      ;_SELECTOR=" \u003eCSS\u003e #captcha-alert";
      get_element_selector(_SELECTOR, false).nowait().exist()!
      VAR_IS_EXISTS = _result() == 1
      _if(VAR_IS_EXISTS, function(){
      get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
      VAR_IS_EXISTS = _result().indexOf("true")>=0
      })!
      

      
      
      _set_if_expression("W1tJU19FWElTVFNdXQ==");
      _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
      
         
         
         fail((_K==="en" ? "Website error" : "Ошибка на сайте"));
         

      })!
      

      
      
      /*Browser*/
      scroll(1,1)!
      

      
      
      /*Browser*/
      _SELECTOR = " \u003eXPATH\u003e //div[contains(@class, \u0022captcha\u0022)]/div[@class=\u0022wrapper\u0022]/div\u003eAT\u003e0";
      wait_element(_SELECTOR)!
      get_element_selector(_SELECTOR, false).exist()!
      _if(_result() == "1", function(){
      get_element_selector(_SELECTOR, false).render_base64()!
      VAR_SCREENSHOT_BASE64 = _result()
      })!
      

      
      
      /*Browser*/
      _SELECTOR = " \u003eXPATH\u003e //div[contains(@class, \u0022captcha\u0022)]/div[@class=\u0022wrapper\u0022]/div\u003eAT\u003e0";
      wait_element(_SELECTOR)!
      get_element_selector(_SELECTOR, false).script("(function(){var rect = _BAS_HIDE(BrowserAutomationStudio_GetBoundingClientRect)(self);return (rect.left + positionx) + '|' + (rect.top + positiony) + '|' + (rect.right - rect.left) + '|' + (rect.bottom - rect.top) + '|' + (rect.left + positionx + scrollx) + '|' + (rect.top + positiony + scrolly)})();")!
      if(_result().length > 0)
      {
      var split = _result().split("|")
      VAR_X = parseInt(split[0])
      VAR_Y = parseInt(split[1])
      VAR_WIDTH = parseInt(split[2])
      VAR_HEIGHT = parseInt(split[3])
      VAR_ABSOLUTE_X = parseInt(split[4])
      VAR_ABSOLUTE_Y = parseInt(split[5])
      }
      

      
      
      solver_properties_clear("capmonster")
      solver_property("capmonster","serverurl","http://sctg.xyz/")
      solver_property("capmonster","key",VAR_APIKEY)
      solver_property("capmonster","method","workcash")
      solver_property("capmonster","body",VAR_SCREENSHOT_BASE64)
      solve_base64_no_fail("capmonster", "")!
      VAR_SAVED_CONTENT = _result();
      

      
      
      VAR_STRING_MATCHES = Boolean(native("regexp", "ismatch", JSON.stringify({text: VAR_SAVED_CONTENT,regexp:("(ERROR)").toString()})) == "true")
      

      
      
      VAR_STRING_MATCHES2 = Boolean(native("regexp", "ismatch", JSON.stringify({text: VAR_SAVED_CONTENT,regexp:("(_FAIL)").toString()})) == "true")
      

      
      
      VAR_STRING_MATCHES3 = Boolean(native("regexp", "ismatch", JSON.stringify({text: VAR_SAVED_CONTENT,regexp:("(_)").toString()})) == "true")
      

      
      
      _set_if_expression("W1tTVFJJTkdfTUFUQ0hFU11dIHx8IFtbU1RSSU5HX01BVENIRVMyXV0gfHwgW1tTVFJJTkdfTUFUQ0hFUzNdXQ==");
      _if(VAR_STRING_MATCHES || VAR_STRING_MATCHES2 || VAR_STRING_MATCHES3,function(){
      
         
         
         fail_user("Капча не решена",false)
         

      })!
      

      
      
      VAR_PARSED_LIST = (VAR_SAVED_CONTENT).split(";")
      

      
      
      VAR_LIST_LENGTH = (VAR_PARSED_LIST).length
      

      
      
      _set_if_expression("W1tMSVNUX0xFTkdUSF1dIDwgMw==");
      _if(VAR_LIST_LENGTH < 3,function(){
      
         
         
         fail((_K==="en" ? "Unclear response from the server: " + VAR_SAVED_CONTENT : "Не понятный ответ от сервера: " + VAR_SAVED_CONTENT));
         

      })!
      

      
      
      /*Browser*/
      scroll(1,1)!
      

      
      
      _do_with_params({"foreach_data":(VAR_PARSED_LIST)},function(){
      _set_action_info({ name: "Foreach" });
      VAR_CYCLE_INDEX = _iterator() - 1
      if(VAR_CYCLE_INDEX > _cycle_param("foreach_data").length - 1)_break();
      VAR_FOREACH_DATA = _cycle_param("foreach_data")[VAR_CYCLE_INDEX]
      
         
         
         VAR_SCAN_RESULT_LIST = native("regexp", "scan", JSON.stringify({text: VAR_FOREACH_DATA,regexp:("\u005cd+").toString()}))
         if(VAR_SCAN_RESULT_LIST.length == 0)
         VAR_SCAN_RESULT_LIST = []
         else
         VAR_SCAN_RESULT_LIST = JSON.parse(VAR_SCAN_RESULT_LIST)
         

         
         
         VAR_LIST_LENGTH = (VAR_SCAN_RESULT_LIST).length
         

         
         
         _set_if_expression("W1tMSVNUX0xFTkdUSF1dICE9IDI=");
         _if(VAR_LIST_LENGTH != 2,function(){
         
            
            
            fail((_K==="en" ? "Unclear response from the server" : "Не понятный ответ от сервера"));
            

         })!
         

         
         
         VAR_X_XEVIL = parseInt(VAR_SCAN_RESULT_LIST[0]);
         VAR_Y_XEVIL = parseInt(VAR_SCAN_RESULT_LIST[1]);
         

         
         
         /*Browser*/
         move(VAR_X + VAR_X_XEVIL,VAR_Y + VAR_Y_XEVIL,  {} )!
         mouse(VAR_X + VAR_X_XEVIL,VAR_Y + VAR_Y_XEVIL)!
         

      })!
      

   }
   

function GoodXevilPaySolver_GXP_RsCaptchaFreeSolver()
   {
   
      
      
      /*Browser*/
      _SELECTOR = " \u003eXPATH\u003e //img[@id=\u0022rscaptcha_img\u0022]";
      wait_element(_SELECTOR)!
      get_element_selector(_SELECTOR, false).script("(function(){var rect = _BAS_HIDE(BrowserAutomationStudio_GetBoundingClientRect)(self);return (rect.left + positionx) + '|' + (rect.top + positiony) + '|' + (rect.right - rect.left) + '|' + (rect.bottom - rect.top) + '|' + (rect.left + positionx + scrollx) + '|' + (rect.top + positiony + scrolly)})();")!
      if(_result().length > 0)
      {
      var split = _result().split("|")
      VAR_X = parseInt(split[0])
      VAR_Y = parseInt(split[1])
      VAR_WIDTH = parseInt(split[2])
      VAR_HEIGHT = parseInt(split[3])
      VAR_ABSOLUTE_X = parseInt(split[4])
      VAR_ABSOLUTE_Y = parseInt(split[5])
      }
      

      
      
      /*Browser*/
      _SELECTOR = " \u003eXPATH\u003e //img[@id=\u0022rscaptcha_img\u0022]";
      wait_element(_SELECTOR)!
      get_element_selector(_SELECTOR, false).exist()!
      _if(_result() == "1", function(){
      get_element_selector(_SELECTOR, false).render_base64()!
      VAR_ICONCAPTCHAMODAL__BODY = _result()
      })!
      

      
      
      /*Browser*/
      scroll(1,1)!
      

      
      
      /*Browser*/
      _SELECTOR = " \u003eXPATH\u003e //img[@id=\u0022rscaptcha_img\u0022]";
      wait_element(_SELECTOR)!
      get_element_selector(_SELECTOR, false).script("(function(){var rect = _BAS_HIDE(BrowserAutomationStudio_GetBoundingClientRect)(self);return (rect.left + positionx) + '|' + (rect.top + positiony) + '|' + (rect.right - rect.left) + '|' + (rect.bottom - rect.top) + '|' + (rect.left + positionx + scrollx) + '|' + (rect.top + positiony + scrolly)})();")!
      if(_result().length > 0)
      {
      var split = _result().split("|")
      VAR_X_L = parseInt(split[0])
      VAR_Y_L = parseInt(split[1])
      VAR_WITH_DATA = parseInt(split[2])
      VAR_HEIGHT_DATA = parseInt(split[3])
      VAR_ABSOLUTE_X = parseInt(split[4])
      VAR_ABSOLUTE_Y = parseInt(split[5])
      }
      

      
      
      VAR_LOADED_IMAGE_ID = native("imageprocessing", "load", VAR_ICONCAPTCHAMODAL__BODY)
      

      
      
      {
      var split = native("imageprocessing", "getsize", VAR_LOADED_IMAGE_ID).split(",")
      VAR_IMAGE_WIDTH = parseInt(split[0])
      VAR_IMAGE_HEIGHT = parseInt(split[1])
      }
      

      
      
      VAR_POINT_X = VAR_IMAGE_HEIGHT/2
      

      
      
      VAR_POINT_X = VAR_POINT_X.toString()
      

      
      
      var regexp_result = native("regexp", "first", JSON.stringify({text: VAR_POINT_X,regexp:("\u005cd+").toString()}))
      if(regexp_result.length == 0)
      regexp_result = []
      else
      regexp_result = JSON.parse(regexp_result)
      VAR_ALL_MATCH = regexp_result.pop()
      if(typeof(VAR_ALL_MATCH) == 'undefined' || !VAR_ALL_MATCH)
      VAR_ALL_MATCH = ""
      VAR_LIST_WITH_GROUPS = regexp_result
      VAR_POINT_X = regexp_result[0]
      if(typeof(VAR_POINT_X) == 'undefined' || !VAR_POINT_X)
      VAR_POINT_X = ""
      if(regexp_result.length == 0)
      {
      VAR_POINT_X = VAR_ALL_MATCH
      }
      if(VAR_ALL_MATCH != "" && Array.isArray(VAR_ALL_MATCH))
      VAR_LIST_WITH_GROUPS.unshift(VAR_ALL_MATCH)
      

      
      
      VAR_POINT_X = parseInt(VAR_POINT_X);
      

      
      
      VAR_TEMP_LIST = []
      

      
      
      VAR_POINT_X = VAR_POINT_X
      

      
      
      VAR_PIXEL_WHITE_MAX = 0
      

      
      
      VAR_PIXEL_WHITE_NOW = 0
      

      
      
      VAR_PIXEL_WHITE_STOP = 0
      

      
      
      {
      var split = native("imageprocessing", "getpixel", (VAR_LOADED_IMAGE_ID) + "," + (2) + "," + (2)).split(",")
      VAR_PIXEL_R = parseInt(split[0])
      VAR_PIXEL_G = parseInt(split[1])
      VAR_PIXEL_B = parseInt(split[2])
      VAR_PIXEL_A = parseInt(split[3])
      }
      

      
      
      _cycle_params().if_else = VAR_PIXEL_B > 200;
      _set_if_expression("W1tQSVhFTF9CXV0gPiAyMDA=");
      _if(_cycle_params().if_else,function(){
      
         
         
         _do(function(){
         _set_action_info({ name: "For" });
         VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(0)
         if(VAR_CYCLE_INDEX > parseInt(VAR_IMAGE_WIDTH - 1))_break();
         
            
            
            VAR_CYCLE_INDEX_X = VAR_CYCLE_INDEX
            

            
            
            VAR_NO_WHITE_PIXEL = 0
            

            
            
            VAR_NO_WHITE_PIXEL_DATA = 0
            

            
            
            _do(function(){
            _set_action_info({ name: "For" });
            VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(0)
            if(VAR_CYCLE_INDEX > parseInt(VAR_IMAGE_HEIGHT - 1))_break();
            
               
               
               {
               var split = native("imageprocessing", "getpixel", (VAR_LOADED_IMAGE_ID) + "," + (VAR_CYCLE_INDEX_X) + "," + (VAR_CYCLE_INDEX)).split(",")
               VAR_PIXEL_R = parseInt(split[0])
               VAR_PIXEL_G = parseInt(split[1])
               VAR_PIXEL_B = parseInt(split[2])
               VAR_PIXEL_A = parseInt(split[3])
               }
               

               
               
               _cycle_params().if_else = VAR_PIXEL_B <= 245;
               _set_if_expression("W1tQSVhFTF9CXV0gPD0gMjQ1");
               _if(_cycle_params().if_else,function(){
               
                  
                  
                  VAR_PIXEL_WHITE_NOW = 1
                  

                  
                  
                  VAR_PIXEL_WHITE_MAX = parseInt(VAR_PIXEL_WHITE_MAX) + parseInt(1)
                  

               })!
               

               
               
               _if(!_cycle_params().if_else,function(){
               
                  
                  
                  VAR_NO_WHITE_PIXEL_DATA = parseInt(VAR_NO_WHITE_PIXEL_DATA) + parseInt(1)
                  

               })!
               delete _cycle_params().if_else;
               

            })!
            

            
            
            _set_if_expression("W1tOT19XSElURV9QSVhFTF9EQVRBXV0gKyA1ID49IFtbSU1BR0VfSEVJR0hUXV0=");
            _if(VAR_NO_WHITE_PIXEL_DATA + 5 >= VAR_IMAGE_HEIGHT,function(){
            
               
               
               VAR_NO_WHITE_PIXEL = parseInt(VAR_NO_WHITE_PIXEL) + parseInt(1)
               

            })!
            

            
            
            _set_if_expression("W1tOT19XSElURV9QSVhFTF1dID09IDE=");
            _if(VAR_NO_WHITE_PIXEL == 1,function(){
            
               
               
               _set_if_expression("W1tQSVhFTF9XSElURV9OT1ddXSA9PSAx");
               _if(VAR_PIXEL_WHITE_NOW == 1,function(){
               
                  
                  
                  VAR_PIXEL_WHITE_STOP = parseInt(VAR_PIXEL_WHITE_STOP) + parseInt(1)
                  

                  
                  
                  _set_if_expression("W1tQSVhFTF9XSElURV9TVE9QXV0gPiA4");
                  _if(VAR_PIXEL_WHITE_STOP > 8,function(){
                  
                     
                     
                     VAR_PIXEL_WHITE_STOP = 0
                     

                     
                     
                     VAR_PIXEL_WHITE_NOW = 0
                     

                     
                     
                     VAR_TEMP_LIST.push(VAR_PIXEL_WHITE_MAX)
                     

                     
                     
                     VAR_PIXEL_WHITE_MAX = 0
                     

                  })!
                  

               })!
               

            })!
            

         })!
         

      })!
      

      
      
      _if(!_cycle_params().if_else,function(){
      
         
         
         _do(function(){
         _set_action_info({ name: "For" });
         VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(0)
         if(VAR_CYCLE_INDEX > parseInt(VAR_IMAGE_WIDTH - 1))_break();
         
            
            
            VAR_CYCLE_INDEX_X = VAR_CYCLE_INDEX
            

            
            
            VAR_NO_WHITE_PIXEL = 0
            

            
            
            VAR_NO_WHITE_PIXEL_DATA = 0
            

            
            
            _do(function(){
            _set_action_info({ name: "For" });
            VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(0)
            if(VAR_CYCLE_INDEX > parseInt(VAR_IMAGE_HEIGHT - 1))_break();
            
               
               
               {
               var split = native("imageprocessing", "getpixel", (VAR_LOADED_IMAGE_ID) + "," + (VAR_CYCLE_INDEX_X) + "," + (VAR_CYCLE_INDEX)).split(",")
               VAR_PIXEL_R = parseInt(split[0])
               VAR_PIXEL_G = parseInt(split[1])
               VAR_PIXEL_B = parseInt(split[2])
               VAR_PIXEL_A = parseInt(split[3])
               }
               

               
               
               _cycle_params().if_else = VAR_PIXEL_B >= 78;
               _set_if_expression("W1tQSVhFTF9CXV0gPj0gNzg=");
               _if(_cycle_params().if_else,function(){
               
                  
                  
                  VAR_PIXEL_WHITE_NOW = 1
                  

                  
                  
                  VAR_PIXEL_WHITE_MAX = parseInt(VAR_PIXEL_WHITE_MAX) + parseInt(1)
                  

               })!
               

               
               
               _if(!_cycle_params().if_else,function(){
               
                  
                  
                  VAR_NO_WHITE_PIXEL_DATA = parseInt(VAR_NO_WHITE_PIXEL_DATA) + parseInt(1)
                  

               })!
               delete _cycle_params().if_else;
               

            })!
            

            
            
            _set_if_expression("W1tOT19XSElURV9QSVhFTF9EQVRBXV0gKyA1ID49IFtbSU1BR0VfSEVJR0hUXV0=");
            _if(VAR_NO_WHITE_PIXEL_DATA + 5 >= VAR_IMAGE_HEIGHT,function(){
            
               
               
               VAR_NO_WHITE_PIXEL = parseInt(VAR_NO_WHITE_PIXEL) + parseInt(1)
               

            })!
            

            
            
            _set_if_expression("W1tOT19XSElURV9QSVhFTF1dID09IDE=");
            _if(VAR_NO_WHITE_PIXEL == 1,function(){
            
               
               
               _set_if_expression("W1tQSVhFTF9XSElURV9OT1ddXSA9PSAx");
               _if(VAR_PIXEL_WHITE_NOW == 1,function(){
               
                  
                  
                  VAR_PIXEL_WHITE_STOP = parseInt(VAR_PIXEL_WHITE_STOP) + parseInt(1)
                  

                  
                  
                  _set_if_expression("W1tQSVhFTF9XSElURV9TVE9QXV0gPiA4");
                  _if(VAR_PIXEL_WHITE_STOP > 8,function(){
                  
                     
                     
                     VAR_PIXEL_WHITE_STOP = 0
                     

                     
                     
                     VAR_PIXEL_WHITE_NOW = 0
                     

                     
                     
                     VAR_TEMP_LIST.push(VAR_PIXEL_WHITE_MAX)
                     

                     
                     
                     VAR_PIXEL_WHITE_MAX = 0
                     

                  })!
                  

               })!
               

            })!
            

         })!
         

      })!
      delete _cycle_params().if_else;
      

      
      
      _do(function(){
      _set_action_info({ name: "For" });
      VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
      if(VAR_CYCLE_INDEX > parseInt(99))_break();
      
         
         
         VAR_TEMP_LIST = VAR_TEMP_LIST.filter(function(e){return e!== VAR_CYCLE_INDEX })
         

      })!
      

      
      
      VAR_COUNT_TEMP_INDEX = [
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
      ]
      

      
      
      _do(function(){
      _set_action_info({ name: "For" });
      VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
      if(VAR_CYCLE_INDEX > parseInt(100))_break();
      
         
         
         var numbers = VAR_TEMP_LIST
         var count = {};
         var leastFrequentNumber;
         var leastFrequentIndex;
         var minmaxdif = VAR_CYCLE_INDEX;
         // Підрахунок кількості входжень кожного числа
         for (var i = 0; i < numbers.length; i++) {
         var number = numbers[i];
         // Враховуємо різницю в 2 як одне число
         var adjustedNumber = Math.floor(number / minmaxdif) * minmaxdif;
         if (count[adjustedNumber] === undefined) {
         count[adjustedNumber] = 1;
         } else {
         count[adjustedNumber]++;
         }
         }
         // Пошук найрідше зустрічаються числа та їх індексу
         var minFrequency = Infinity;
         for (var j = 0; j < numbers.length; j++) {
         var currentNumber = numbers[j];
         var adjustedCurrentNumber = Math.floor(currentNumber / minmaxdif) * minmaxdif;
         if (count[adjustedCurrentNumber] < minFrequency) {
         minFrequency = count[adjustedCurrentNumber];
         leastFrequentNumber = currentNumber;
         leastFrequentIndex = j;
         }
         }
         totalCount = Object.keys(count).length;
         VAR_DEBUG_TEMP = totalCount
         VAR_LOW_INDEX = leastFrequentIndex;
         VAR_LOW_INDEX = VAR_LOW_INDEX + 1
         

         
         
         _set_if_expression("W1tERUJVR19URU1QXV0gPiAx");
         _if(VAR_DEBUG_TEMP > 1,function(){
         
            
            
            VAR_LIST_ELEMENT = (VAR_COUNT_TEMP_INDEX)[VAR_LOW_INDEX];
            

            
            
            VAR_LIST_ELEMENT = parseInt(VAR_LIST_ELEMENT) + parseInt(1)
            

            
            
            VAR_COUNT_TEMP_INDEX[(VAR_LOW_INDEX < 0) ? (VAR_COUNT_TEMP_INDEX.length + VAR_LOW_INDEX) : VAR_LOW_INDEX] = VAR_LIST_ELEMENT;
            

         })!
         

      })!
      

      
      
      _do(function(){
      _set_action_info({ name: "For" });
      VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(0)
      if(VAR_CYCLE_INDEX > parseInt(100))_break();
      
         
         
         VAR_TEMP_VARIABLE = 100 - VAR_CYCLE_INDEX
         

         
         
         VAR_VALUE_INDEX = (VAR_COUNT_TEMP_INDEX).indexOf(VAR_TEMP_VARIABLE)
         

         
         
         _set_if_expression("W1tWQUxVRV9JTkRFWF1dICE9IC0x");
         _if(VAR_VALUE_INDEX != -1,function(){
         
            
            
            _break("function")
            

         })!
         

      })!
      

      
      
      VAR_LOW_INDEX = VAR_VALUE_INDEX
      

      
      
      VAR_LIST_LENGTH = (VAR_TEMP_LIST).length
      

      
      
      native("imageprocessing", "delete", VAR_LOADED_IMAGE_ID)
      

      
      
      VAR_TEMP_INDEX = parseInt((((VAR_WITH_DATA/VAR_LIST_LENGTH) * VAR_LOW_INDEX) - VAR_WITH_DATA/VAR_LIST_LENGTH/2) - 5)
      

      
      
      _set_if_expression("ZmFsc2U=");
      _if(false,function(){
      
         
         
         VAR_TEMP_INDEX = parseInt((((100/VAR_LIST_LENGTH) * VAR_LOW_INDEX) - 100/VAR_LIST_LENGTH/2) - 2)
         

         
         
         /*Browser*/
         _SELECTOR = " \u003eXPATH\u003e //div[@id=\u0022captcha-solve\u0022]/div[@class=\u0022dot\u0022]";
         wait_element(_SELECTOR)!
         get_element_selector(_SELECTOR, false).set_attr("style", "top: 40%; left: " + VAR_TEMP_INDEX + "%;")!
         

         
         
         /*Browser*/
         _SELECTOR = " \u003eXPATH\u003e //div[@id=\u0022captcha-solve\u0022]/div[@class=\u0022dot\u0022]";
         wait_element_visible(_SELECTOR)!
         _call(_random_point, {})!
         _if(_result().length > 0, function(){
         move( {} )!
         get_element_selector(_SELECTOR, false).clarify(X,Y)!
         _call(_clarify, {} )!
         })!
         

         
         
         /*Browser*/
         _SELECTOR = " \u003eXPATH\u003e //div[@id=\u0022captcha-solve\u0022]/div[@class=\u0022dot\u0022]";
         wait_element(_SELECTOR)!
         get_element_selector(_SELECTOR, false).set_attr("style", "display:none;")!
         

         
         
         _get_browser_screen_settings()!
         ;(function(){
         var result = JSON.parse(_result())
         VAR_SCROLL_X = result["ScrollX"]
         VAR_SCROLL_Y = result["ScrollY"]
         VAR_CURSOR_X = result["CursorX"]
         VAR_CURSOR_Y = result["CursorY"]
         VAR_CURSOR_ABSOLUTE_X = result["CursorX"] + result["ScrollX"]
         VAR_CURSOR_ABSOLUTE_Y = result["CursorY"] + result["ScrollY"]
         VAR_BROWSER_WIDTH = result["Width"]
         VAR_BROWSER_HEIGHT = result["Height"]
         })();
         

         
         
         /*Browser*/
         mouse(VAR_CURSOR_X,VAR_CURSOR_Y)!
         

      })!
      

      
      
      /*Browser*/
      move(VAR_X_L + VAR_TEMP_INDEX,VAR_Y_L + (VAR_HEIGHT_DATA/2) - 5,  {} )!
      mouse(VAR_X_L + VAR_TEMP_INDEX,VAR_Y_L + (VAR_HEIGHT_DATA/2) - 5)!
      

   }
   

function GoodXevilPaySolver_GXP_CleanProfPath()
   {
   
      
      
      _L["Path"] = {"ru":"Путь"};
      _L["To path"] = {"ru":"До пути"};
      _L["From path"] = {"ru":"От пути"};
      _L["Path object"] = {"ru":"Объект пути"};
      _L["File extension to remove"] = {"ru":"Удаляемое расширение файла"};
      _path = {
      sep: '/',
      delimiter: ';',
      isPathSeparator: function(code){
      return code===47 || code===92;
      },
      isDeviceRoot: function(code){
      return code >= 65 && code <= 90 || code >= 97 && code <= 122;
      },
      normalizeString: function(path, allowAboveRoot){
      var res = '';
      var lastSegmentLength = 0;
      var lastSlash = -1;
      var dots = 0;
      var code = 0;
      for(var i = 0; i <= path.length; ++i){
      if(i < path.length){
      code = path.charCodeAt(i);
      }else if(this.isPathSeparator(code)){
      break;
      }else{
      code = 47;
      };
      if(this.isPathSeparator(code)){
      if(lastSlash===i-1 || dots===1){
      }else if(dots === 2){
      if(res.length < 2 || !(lastSegmentLength===2) || !(res.charCodeAt(res.length-1)===46) || !(res.charCodeAt(res.length-2)===46)){
      if(res.length > 2){
      const lastSlashIndex = res.lastIndexOf(this.sep);
      if(lastSlashIndex===-1){
      res = '';
      lastSegmentLength = 0;
      }else{
      res = res.slice(0, lastSlashIndex);
      lastSegmentLength = res.length - 1 - res.lastIndexOf(this.sep);
      };
      lastSlash = i;
      dots = 0;
      continue;
      }else if(!(res.length===0)){
      res = '';
      lastSegmentLength = 0;
      lastSlash = i;
      dots = 0;
      continue;
      };
      };
      if(allowAboveRoot){
      res += res.length > 0 ? (this.sep + '..') : '..';
      lastSegmentLength = 2;
      };
      }else{
      if (res.length > 0){
      res += this.sep + path.slice(lastSlash + 1, i);
      }else{
      res = path.slice(lastSlash + 1, i);
      };
      lastSegmentLength = i - lastSlash - 1;
      };
      lastSlash = i;
      dots = 0;
      }else if(code===46 && !(dots===-1)){
      ++dots;
      }else{
      dots = -1;
      };
      };
      return res;
      },
      resolve: function(args){
      if(!Array.isArray(args)){
      args = Array.prototype.slice.call(arguments);
      };
      var resolvedDevice = '';
      var resolvedTail = '';
      var resolvedAbsolute = false;
      for(var i = args.length - 1; i > -1; i--){
      var path = args[i];
      _validate_argument_type(path, 'string', 'Path', '_path.resolve');
      if(path.length===0){
      continue;
      };
      const len = path.length;
      var rootEnd = 0;
      var device = '';
      var isAbsolute = false;
      const code = path.charCodeAt(0);
      if(len===1){
      if(this.isPathSeparator(code)){
      rootEnd = 1;
      isAbsolute = true;
      };
      }else if(this.isPathSeparator(code)){
      isAbsolute = true;
      if(this.isPathSeparator(path.charCodeAt(1))){
      var j = 2;
      var last = j;
      while(j < len && !this.isPathSeparator(path.charCodeAt(j))){
      j++;
      };
      if(j < len && !(j===last)){
      const firstPart = path.slice(last, j);
      last = j;
      while(j < len && this.isPathSeparator(path.charCodeAt(j))){
      j++;
      };
      if(j < len && !(j===last)){
      last = j;
      while(j < len && !this.isPathSeparator(path.charCodeAt(j))){
      j++;
      };
      if(j===len || !(j===last)){
      device = this.sep + this.sep + firstPart + this.sep + path.slice(last, j);
      rootEnd = j;
      };
      };
      };
      }else{
      rootEnd = 1;
      };
      }else if(this.isDeviceRoot(code) && path.charCodeAt(1)===58){
      device = path.slice(0, 2);
      rootEnd = 2;
      if(len > 2 && this.isPathSeparator(path.charCodeAt(2))){
      isAbsolute = true;
      rootEnd = 3;
      };
      };
      if(device.length > 0){
      if(resolvedDevice.length > 0){
      if(!(device.toLowerCase()===resolvedDevice.toLowerCase())){
      continue;
      };
      }else{
      resolvedDevice = device;
      };
      };
      if(resolvedAbsolute){
      if(resolvedDevice.length > 0){
      break;
      };
      }else{
      resolvedTail = path.slice(rootEnd) + this.sep + resolvedTail;
      resolvedAbsolute = isAbsolute;
      if(isAbsolute && resolvedDevice.length > 0){
      break;
      };
      };
      };
      resolvedTail = this.normalizeString(resolvedTail, !resolvedAbsolute);
      return resolvedAbsolute ? resolvedDevice + this.sep + resolvedTail : (resolvedDevice + resolvedTail) || '.';
      },
      normalize: function(path, removeTrailingSlash){
      _validate_argument_type(path, 'string', 'Path', '_path.normalize');
      removeTrailingSlash = _avoid_nilb(removeTrailingSlash, true);
      _validate_argument_type(removeTrailingSlash, ['boolean', 'number'], 'Remove trailing slashes', '_path.normalize');
      const len = path.length;
      if(len===0){
      return '';
      };
      var rootEnd = 0;
      var device = undefined;
      var isAbsolute = false;
      const code = path.charCodeAt(0);
      if(len===1){
      return this.isPathSeparator(code) ? (removeTrailingSlash ? '' : this.sep) : path;
      };
      if(this.isPathSeparator(code)){
      isAbsolute = true;
      if(this.isPathSeparator(path.charCodeAt(1))){
      var j = 2;
      var last = j;
      while (j < len && !this.isPathSeparator(path.charCodeAt(j))){
      j++;
      };
      if(j < len && !(j===last)){
      const firstPart = path.slice(last, j);
      last = j;
      while (j < len && this.isPathSeparator(path.charCodeAt(j))){
      j++;
      };
      if(j < len && !(j===last)){
      last = j;
      while (j < len && !this.isPathSeparator(path.charCodeAt(j))){
      j++;
      };
      if(j===len){
      return (this.sep + this.sep + firstPart + this.sep + path.slice(last) + (removeTrailingSlash ? '' : this.sep));
      };
      if(!(j===last)){
      device = this.sep + this.sep + firstPart + this.sep + path.slice(last, j);
      rootEnd = j;
      };
      };
      };
      }else{
      rootEnd = 1;
      };
      }else if(this.isDeviceRoot(code) && path.charCodeAt(1)===58){
      device = path.slice(0, 2);
      rootEnd = 2;
      if(len > 2 && this.isPathSeparator(path.charCodeAt(2))){
      isAbsolute = true;
      rootEnd = 3;
      };
      };
      var tail = rootEnd < len ? this.normalizeString(path.slice(rootEnd), !isAbsolute) : '';
      if(tail.length > 0 && this.isPathSeparator(path.charCodeAt(len - 1)) && !removeTrailingSlash){
      tail += this.sep;
      };
      if(device===undefined){
      return isAbsolute ? ((tail.length===0 && removeTrailingSlash ? '' : this.sep) + tail) : tail;
      };
      return isAbsolute ? (device + (tail.length===0 && removeTrailingSlash ? '' : this.sep) + tail) : (device + tail);
      },
      isAbsolute: function(path){
      _validate_argument_type(path, 'string', 'Path', '_path.isAbsolute');
      const len = path.length;
      if(len===0){
      return false;
      };
      const code = path.charCodeAt(0);
      return this.isPathSeparator(code) || len > 2 && this.isDeviceRoot(code) && path.charCodeAt(1) === 58 && this.isPathSeparator(path.charCodeAt(2));
      },
      join: function(args){
      if(!Array.isArray(args)){
      args = Array.prototype.slice.call(arguments);
      };
      if(args.length===0){
      return '.';
      };
      var joined = undefined;
      var firstPart = undefined;
      for(var i = 0; i < args.length; ++i){
      const arg = args[i];
      _validate_argument_type(arg, 'string', 'Path', '_path.join');
      if(arg.length > 0){
      if(joined === undefined){
      joined = firstPart = arg;
      }else{
      joined += (this.sep + arg);
      };
      };
      };
      if(joined === undefined){
      return '.';
      };
      var needsReplace = true;
      var slashCount = 0;
      if(this.isPathSeparator(firstPart.charCodeAt(0))){
      ++slashCount;
      const firstLen = firstPart.length;
      if(firstLen > 1 && this.isPathSeparator(firstPart.charCodeAt(1))){
      ++slashCount;
      if(firstLen > 2){
      if(this.isPathSeparator(firstPart.charCodeAt(2))){
      ++slashCount;
      }else{
      needsReplace = false;
      };
      };
      };
      };
      if(needsReplace){
      while(slashCount < joined.length && this.isPathSeparator(joined.charCodeAt(slashCount))){
      slashCount++;
      };
      if(slashCount >= 2){
      joined = this.sep + joined.slice(slashCount);
      };
      };
      return this.normalize(joined);
      },
      relative: function(from, to){
      _validate_argument_type(from, 'string', 'From path', '_path.relative');
      _validate_argument_type(to, 'string', 'To path', '_path.relative');
      if(from===to){
      return '';
      };
      const fromOrig = this.resolve(from);
      const toOrig = this.resolve(to);
      if(fromOrig===toOrig){
      return '';
      };
      from = fromOrig.toLowerCase();
      to = toOrig.toLowerCase();
      if(from===to){
      return '';
      };
      var fromStart = 0;
      while(fromStart < from.length && from.charCodeAt(fromStart)===this.sep.charCodeAt(0)){
      fromStart++;
      };
      var fromEnd = from.length;
      while(fromEnd - 1 > fromStart && from.charCodeAt(fromEnd - 1)===this.sep.charCodeAt(0)){
      fromEnd--;
      };
      const fromLen = fromEnd - fromStart;
      var toStart = 0;
      while(toStart < to.length && to.charCodeAt(toStart)===this.sep.charCodeAt(0)){
      toStart++;
      };
      var toEnd = to.length;
      while(toEnd - 1 > toStart && to.charCodeAt(toEnd - 1)===this.sep.charCodeAt(0)){
      toEnd--;
      };
      const toLen = toEnd - toStart;
      const length = fromLen < toLen ? fromLen : toLen;
      var lastCommonSep = -1;
      var i = 0;
      for(; i < length; i++){
      const fromCode = from.charCodeAt(fromStart + i);
      if(!(fromCode===to.charCodeAt(toStart + i))){
      break;
      }else if(fromCode===this.sep.charCodeAt(0)){
      lastCommonSep = i;
      };
      };
      if(!(i===length)){
      if(lastCommonSep===-1){
      return toOrig;
      };
      }else{
      if(toLen > length){
      if(to.charCodeAt(toStart + i)===this.sep.charCodeAt(0)){
      return toOrig.slice(toStart + i + 1);
      };
      if(i===2){
      return toOrig.slice(toStart + i);
      };
      };
      if(fromLen > length){
      if(from.charCodeAt(fromStart + i)===this.sep.charCodeAt(0)){
      lastCommonSep = i;
      }else if(i===2){
      lastCommonSep = 3;
      };
      };
      if(lastCommonSep===-1){
      lastCommonSep = 0;
      };
      };
      var out = '';
      for(i = fromStart + lastCommonSep + 1; i <= fromEnd; ++i){
      if(i===fromEnd || from.charCodeAt(i)===this.sep.charCodeAt(0)){
      out += out.length===0 ? '..' : this.sep + '..';
      };
      };
      toStart += lastCommonSep;
      if(out.length > 0){
      return out + toOrig.slice(toStart, toEnd);
      };
      if(toOrig.charCodeAt(toStart)===this.sep.charCodeAt(0)){
      ++toStart;
      };
      return toOrig.slice(toStart, toEnd);
      },
      toNamespacedPath: function(path){
      if(typeof path!='string'){
      return path;
      };
      if(path.length===0){
      return '';
      };
      const resolvedPath = this.resolve(path);
      if(resolvedPath.length <= 2){
      return path;
      };
      if(resolvedPath.charCodeAt(0)===this.sep.charCodeAt(0)){
      if(resolvedPath.charCodeAt(1)===this.sep.charCodeAt(0)){
      const code = resolvedPath.charCodeAt(2);
      if(!(code===63) && !(code===46)){
      return (this.sep + this.sep + '?' + this.sep + 'UNC' + this.sep + resolvedPath.slice(2));
      };
      };
      }else if(this.isDeviceRoot(resolvedPath.charCodeAt(0)) && resolvedPath.charCodeAt(1)===58 && resolvedPath.charCodeAt(2)===this.sep.charCodeAt(0)){
      return (this.sep + this.sep + '?' + this.sep + resolvedPath);
      };
      return path;
      },
      dirname: function(path){
      _validate_argument_type(path, 'string', 'Path', '_path.dirname');
      const len = path.length;
      if(len===0){
      return '.';
      };
      var rootEnd = -1;
      var offset = 0;
      const code = path.charCodeAt(0);
      if(len===1){
      return this.isPathSeparator(code) ? path : '.';
      };
      if(this.isPathSeparator(code)){
      rootEnd = offset = 1;
      if(this.isPathSeparator(path.charCodeAt(1))){
      var j = 2;
      var last = j;
      while(j < len && !this.isPathSeparator(path.charCodeAt(j))){
      j++;
      };
      if(j < len && !(j===last)){
      last = j;
      while(j < len && this.isPathSeparator(path.charCodeAt(j))){
      j++;
      };
      if(j < len && !(j===last)){
      last = j;
      while (j < len && !this.isPathSeparator(path.charCodeAt(j))){
      j++;
      };
      if(j===len){
      return path;
      };
      if(!(j===last)){
      rootEnd = offset = j + 1;
      };
      };
      };
      };
      }else if(this.isDeviceRoot(code) && path.charCodeAt(1)===58){
      rootEnd = len > 2 && this.isPathSeparator(path.charCodeAt(2)) ? 3 : 2;
      offset = rootEnd;
      };
      var end = -1;
      var matchedSlash = true;
      for(var i = len - 1; i >= offset; --i){
      if(this.isPathSeparator(path.charCodeAt(i))){
      if(!matchedSlash){
      end = i;
      break;
      };
      }else{
      matchedSlash = false;
      };
      };
      if(end===-1){
      if(rootEnd===-1){
      return '.';
      };
      end = rootEnd;
      };
      return path.slice(0, end);
      },
      basename: function(path, ext){
      _validate_argument_type(path, 'string', 'Path', '_path.basename');
      _validate_argument_type(ext, ['string','undefined','null'], 'File extension to remove', '_path.basename');
      var start = 0;
      var end = -1;
      var matchedSlash = true;
      var i = 0;
      if(path.length >= 2 && this.isDeviceRoot(path.charCodeAt(0)) && path.charCodeAt(1)===58){
      start = 2;
      };
      if(!(_is_nilb(ext)) && ext.length > 0 && ext.length <= path.length){
      if(ext===path){
      return '';
      };
      var extIdx = ext.length - 1;
      var firstNonSlashEnd = -1;
      for(i = path.length - 1; i >= start; --i){
      const code = path.charCodeAt(i);
      if(this.isPathSeparator(code)){
      if(!matchedSlash){
      start = i + 1;
      break;
      };
      }else{
      if(firstNonSlashEnd===-1){
      matchedSlash = false;
      firstNonSlashEnd = i + 1;
      };
      if(ext==='*'){
      if(code===46 && end===-1){
      end = i;
      };
      }else{
      if(extIdx >= 0){
      if(code===ext.charCodeAt(extIdx)){
      if(--extIdx===-1){
      end = i;
      };
      }else{
      extIdx = -1;
      end = firstNonSlashEnd;
      };
      };
      };
      };
      };
      if(start===end){
      end = firstNonSlashEnd;
      }else if(end === -1){
      end = path.length;
      };
      return path.slice(start, end);
      };
      for(i = path.length - 1; i >= start; --i){
      if(this.isPathSeparator(path.charCodeAt(i))){
      if(!matchedSlash){
      start = i + 1;
      break;
      };
      }else if(end===-1){
      matchedSlash = false;
      end = i + 1;
      };
      };
      if(end===-1){
      return '';
      };
      return path.slice(start, end);
      },
      extname: function(path){
      _validate_argument_type(path, 'string', 'Path', '_path.extname');
      var start = 0;
      var startDot = -1;
      var startPart = 0;
      var end = -1;
      var matchedSlash = true;
      var preDotState = 0;
      if(path.length >= 2 && path.charCodeAt(1)===58 && this.isDeviceRoot(path.charCodeAt(0))){
      start = startPart = 2;
      };
      for(var i = path.length - 1; i >= start; --i){
      const code = path.charCodeAt(i);
      if(this.isPathSeparator(code)){
      if(!matchedSlash){
      startPart = i + 1;
      break;
      };
      continue;
      };
      if(end===-1){
      matchedSlash = false;
      end = i + 1;
      };
      if(code===46){
      if(startDot===-1){
      startDot = i;
      }else if(!(preDotState===1)){
      preDotState = 1;
      };
      }else if(!(startDot===-1)){
      preDotState = -1;
      };
      };
      if(startDot===-1 || end===-1 || preDotState===0 || (preDotState===1 && startDot===end - 1 && startDot===startPart + 1)){
      return '';
      };
      return path.slice(startDot, end);
      },
      format: function(pathObject){
      _validate_argument_type(pathObject, 'object', 'Path object', '_path.format');
      var dir = pathObject.dir || pathObject.root;
      var base = pathObject.base || (pathObject.name || '' + pathObject.ext || '');
      if(!dir){
      return base;
      };
      return dir===pathObject.root ? (dir + base) : (dir + this.sep + base);
      },
      parse: function(path){
      _validate_argument_type(path, 'string', 'Path', '_path.parse');
      const ret = { root: '', dir: '', base: '', ext: '', name: '', items: [] };
      if(path.length===0){
      return ret;
      };
      const len = path.length;
      var rootEnd = 0;
      var code = path.charCodeAt(0);
      if(len===1){
      if(this.isPathSeparator(code)){
      ret.root = ret.dir = path;
      return ret;
      };
      ret.base = ret.name = ret.items[0] = path;
      return ret;
      };
      ret.items = path.split(/[\\/]+/).filter(function(el){return el.length > 0});
      if(this.isPathSeparator(code)){
      rootEnd = 1;
      if(this.isPathSeparator(path.charCodeAt(1))){
      var j = 2;
      var last = j;
      while(j < len && !this.isPathSeparator(path.charCodeAt(j))){
      j++;
      };
      if(j < len && !(j===last)){
      last = j;
      while (j < len && this.isPathSeparator(path.charCodeAt(j))){
      j++;
      };
      if(j < len && !(j===last)){
      last = j;
      while (j < len && !this.isPathSeparator(path.charCodeAt(j))){
      j++;
      };
      if(j===len){
      rootEnd = j;
      }else if(!(j===last)){
      rootEnd = j + 1;
      };
      };
      };
      };
      }else if(this.isDeviceRoot(code) && path.charCodeAt(1)===58){
      if(len <= 2){
      ret.root = ret.dir = path;
      return ret;
      };
      rootEnd = 2;
      if(this.isPathSeparator(path.charCodeAt(2))){
      if (len===3){
      ret.root = ret.dir = path;
      return ret;
      };
      rootEnd = 3;
      };
      };
      if(rootEnd > 0){
      ret.root = path.slice(0, rootEnd);
      };
      var startDot = -1;
      var startPart = rootEnd;
      var end = -1;
      var matchedSlash = true;
      var i = path.length - 1;
      var preDotState = 0;
      for(; i >= rootEnd; --i){
      code = path.charCodeAt(i);
      if(this.isPathSeparator(code)){
      if(!matchedSlash){
      startPart = i + 1;
      break;
      };
      continue;
      };
      if(end===-1){
      matchedSlash = false;
      end = i + 1;
      };
      if(code===46){
      if(startDot===-1){
      startDot = i;
      }else if(!(preDotState===1)){
      preDotState = 1;
      };
      }else if(!(startDot===-1)){
      preDotState = -1;
      };
      };
      if(!(end===-1)){
      if(startDot===-1 || preDotState === 0 || (preDotState===1 && startDot===end-1 && startDot===startPart+1)){
      ret.base = ret.name = path.slice(startPart, end);
      }else{
      ret.name = path.slice(startPart, startDot);
      ret.base = path.slice(startPart, end);
      ret.ext = path.slice(startDot, end);
      };
      };
      if(startPart > 0 && !(startPart===rootEnd)){
      ret.dir = path.slice(0, startPart - 1);
      }else{
      ret.dir = ret.root;
      };
      return ret;
      }
      };
      function project_directory(){
      var path = project_path();
      var c = '';
      var s = 0;
      var end = -1;
      for(var i = path.length - 1; i > -1; i--){
      if(_path.isPathSeparator(path.charCodeAt(i))){
      s++;
      if(c==='appsremote' || c==='appslocal'){
      end = i;
      break;
      }else{
      if(s===1){
      end = i;
      if(!(c==='project.xml')){
      break;
      };
      };
      if(s===2 && !(c==='engine')){
      break;
      };
      c = '';
      };
      }else{
      c = path.charAt(i) + c;
      };
      };
      return end===-1 ? _path.dirname(path) : path.slice(0, end);
      };
      function installation_path(){
      return JSON.parse(native("filesystem", "fileinfo", "settings.ini")).directory;
      };
      function _get_system_data(){
      RANDOM_FILE = "temp_" + rand() + ".bat";
      native("filesystem","writefile",JSON.stringify({path:RANDOM_FILE,value:"chcp 65001\r\nSET",base64:false,append:false}));
      native_async("processmanager","start",JSON.stringify({location:RANDOM_FILE,working_folder:"",waitfinish:true,arguments:"",version:2}))!
      var data_list = base64_decode(_result().split(",")[0]).split('\r\n').slice(2,-1);
      sleep(1000)!
      native("filesystem","removefile",RANDOM_FILE);
      SYSTEM_ENV_DATA = {};
      for(var i = 0; i < data_list.length; i++){
      if(data_list[i].indexOf('=') > -1){
      var data = data_list[i].split('=');
      var name = data[0];
      var value = data[1];
      SYSTEM_ENV_DATA[name] = value.indexOf("\\") > -1 ? _path.normalize(value) : value;
      };
      };
      if(SYSTEM_ENV_DATA["USERPROFILE"]){
      ["Desktop","Downloads","Documents","Pictures","Videos","Music","Favorites"].forEach(function(e){SYSTEM_ENV_DATA[e] = _path.join(SYSTEM_ENV_DATA["USERPROFILE"], e)});
      };
      };
      function _get_system_path(){
      var name = _function_argument("name");
      _if(typeof SYSTEM_ENV_DATA=="undefined",function(){
      _call_function(_get_system_data,{})!
      _result_function();
      })!
      var labels = {
      "App Data":"APPDATA",
      "Local App Data": "LOCALAPPDATA",
      "Program Files":"ProgramFiles",
      "Program Files (x86)":"ProgramFiles(x86)",
      "Program Data":"ProgramData",
      "Public":"PUBLIC",
      "System Drive":"SystemDrive",
      "System Root":"SystemRoot",
      "Windows Directory":"windir",
      "Temp":"TEMP",
      "User Name":"USERNAME",
      "User Profile":"USERPROFILE",
      "Computer Name":"COMPUTERNAME"
      };
      var label = _avoid_nilb(labels[name], name);
      if(_is_nilb(SYSTEM_ENV_DATA[label])){
      fail(_K=="ru" ? 'Не удалось найти путь "' + name + '" в системных данных.' : 'Could not find path "' + name + '" in system data.');
      };
      _function_return(SYSTEM_ENV_DATA[label]);
      };
      

      
      
      VAR_INSTALLATION_PATH = installation_path();
      

      
      
      native_async("filesystem", "search", JSON.stringify({folder: VAR_INSTALLATION_PATH + "/prof",mask: "*",contains:"",include_folders:true,include_files:false,recursive:false}))!
      VAR_FILE_SEARCH_RESULT = JSON.parse(_result())["d"]
      

      
      
      _do_with_params({"foreach_data":(VAR_FILE_SEARCH_RESULT)},function(){
      _set_action_info({ name: "Foreach" });
      VAR_CYCLE_INDEX = _iterator() - 1
      if(VAR_CYCLE_INDEX > _cycle_param("foreach_data").length - 1)_break();
      VAR_FOREACH_DATA = _cycle_param("foreach_data")[VAR_CYCLE_INDEX]
      
         
         
         _call(function()
         {
         _on_fail(function(){
         VAR_LAST_ERROR = _result()
         VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
         VAR_WAS_ERROR = false
         _break(1,true)
         })
         CYCLES.Current().RemoveLabel("function")
         
            
            
            native("filesystem", "removefile", VAR_FOREACH_DATA)
            

         },null)!
         

      })!
      

   }
   

function GoodXevilPaySolver_GXP_AutoConfirmCallback_ReCaptcha()
   {
   
      
      
      VAR_SAVED_CONTENT = _function_argument("token")
      

      
      
      VAR_TEMP_DATA2 = ""
      

      
      
      VAR_TEMP_DATA = ""
      

      
      
      _do(function(){
      _set_action_info({ name: "While" });
      VAR_CYCLE_INDEX = _iterator() - 1
      BREAK_CONDITION = VAR_TEMP_DATA == "";
      if(!BREAK_CONDITION)_break();
      
         
         
         _set_if_expression("W1tDWUNMRV9JTkRFWF1dICE9IDA=");
         _if(VAR_CYCLE_INDEX != 0,function(){
         
            
            
            sleep(500)!
            

         })!
         

         
         
         _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gMzA=");
         _if(VAR_CYCLE_INDEX > 30,function(){
         
            
            
            fail((_K==="en" ? "ReCaptcha is not detected on the page" : "ReCaptcha не обнаружена на странице"));
            

         })!
         

         
         
         _call(function()
         {
         _on_fail(function(){
         VAR_LAST_ERROR = _result()
         VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
         VAR_WAS_ERROR = false
         _break(1,true)
         })
         CYCLES.Current().RemoveLabel("function")
         
            
            
            page().script2("[[TEMP_DATA]] = window.widgetInfore;",JSON.stringify(_read_variables(["VAR_TEMP_DATA"])))!
            var _parse_result = JSON.parse(_result())
            _write_variables(JSON.parse(_parse_result.variables))
            if(!_parse_result.is_success)
            fail(_parse_result.error)
            

         },null)!
         

      })!
      

      
      
      _call(function()
      {
      _on_fail(function(){
      VAR_LAST_ERROR = _result()
      VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
      VAR_WAS_ERROR = false
      _break(1,true)
      })
      CYCLES.Current().RemoveLabel("function")
      
         
         
         /*Browser*/
         _SELECTOR = " \u003eCSS\u003eiframe[src*=\u0027anchor\u0027]\u003eFRAME\u003e \u003eXPATH\u003e //input[@id=\u0022recaptcha-token\u0022]";
         wait_element(_SELECTOR)!
         get_element_selector(_SELECTOR, false).set_attr("value", VAR_SAVED_CONTENT)!
         

      },null)!
      

      
      
      _call(function()
      {
      _on_fail(function(){
      VAR_LAST_ERROR = _result()
      VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
      VAR_WAS_ERROR = false
      _break(1,true)
      })
      CYCLES.Current().RemoveLabel("function")
      
         
         
         page().script2("var xpath = \u0027//textarea[@name=\u0022g-recaptcha-response\u0022]\u0027;\r\nvar result = document.evaluate(xpath, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null);\r\nvar element = result.singleNodeValue;\r\n\r\nif (element) \u007b\r\n  element.innerText = [[SAVED_CONTENT]];\r\n\u007d\r\n",JSON.stringify(_read_variables(["VAR_SAVED_CONTENT"])))!
         var _parse_result = JSON.parse(_result())
         _write_variables(JSON.parse(_parse_result.variables))
         if(!_parse_result.is_success)
         fail(_parse_result.error)
         

      },null)!
      

      
      
      _call(function()
      {
      _on_fail(function(){
      VAR_LAST_ERROR = _result()
      VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
      VAR_WAS_ERROR = false
      _break(1,true)
      })
      CYCLES.Current().RemoveLabel("function")
      
         
         
         page().script2("if(window.widgetInfore.callback != null)\u007b\r\n    let func = window.widgetInfore.callback\r\n    let data = [[SAVED_CONTENT]];\r\n    window[func](data);\r\n\u007d\r\n",JSON.stringify(_read_variables(["VAR_SAVED_CONTENT"])))!
         var _parse_result = JSON.parse(_result())
         _write_variables(JSON.parse(_parse_result.variables))
         if(!_parse_result.is_success)
         fail(_parse_result.error)
         

      },null)!
      

      
      
      _call(function()
      {
      _on_fail(function(){
      VAR_LAST_ERROR = _result()
      VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
      VAR_WAS_ERROR = false
      _break(1,true)
      })
      CYCLES.Current().RemoveLabel("function")
      
         
         
         page().script2("function getBindedElements(widget) \u007b\r\n    let elements = \u007b\r\n        button: null,\r\n        textarea: null,\r\n    \u007d;\r\n    if (widget.bindedButtonId) \u007b\r\n        let button = document.querySelector(\u0022#\u0022 + widget.bindedButtonId);\r\n        if (button.length) elements.button = button;\r\n    \u007d else \u007b\r\n        let textarea = document.querySelector(\u0022#\u0022 + widget.containerId + \u0022 textarea[name=g-recaptcha-response]\u0022);\r\n        if (textarea.length) elements.textarea = textarea;\r\n    \u007d\r\n    return elements;\r\n\u007d  \r\n\r\nfunction getForm(widget) \u007b\r\n    let binded = getBindedElements(widget);\r\n    if (binded.textarea) \u007b\r\n        return binded.textarea.closest(\u0022form\u0022);\r\n    \u007d\r\n    return binded.button.closest(\u0022form\u0022);\r\n\u007d\r\n\r\nlet textarea = getBindedElements(window.widgetInfore).textarea;\r\nif (!textarea) \u007b\r\n    textarea = getForm(window.widgetInfore).find(\u0022textarea[name=g-recaptcha-response]\u0022);\r\n\u007d\r\ntextarea.val([[SAVED_CONTENT]]);\r\n\r\nif(window.widgetInfore.callback != null)\u007b\r\n    let func = window.widgetInfore.callback\r\n    let data = [[SAVED_CONTENT]];\r\n    window[func](data);\r\n\u007d",JSON.stringify(_read_variables(["VAR_SAVED_CONTENT"])))!
         var _parse_result = JSON.parse(_result())
         _write_variables(JSON.parse(_parse_result.variables))
         if(!_parse_result.is_success)
         fail(_parse_result.error)
         

      },null)!
      

      
      
      _call(function()
      {
      _on_fail(function(){
      VAR_LAST_ERROR = _result()
      VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
      VAR_WAS_ERROR = false
      _break(1,true)
      })
      CYCLES.Current().RemoveLabel("function")
      
         
         
         page().script2("function setRecaptchaToken(token, clientIdx = 0) \u007b\r\n  var recap = window[\u0022___grecaptcha_cfg\u0022].clients[clientIdx];\r\n  Object.keys(recap).forEach(function(k) \u007b\r\n      if (recap[k] != null \u0026\u0026 recap[k][k] != null \u0026\u0026 recap[k][k][\u0022callback\u0022] != null)  \u007b\r\n           recap[k][k].callback(token);\r\n           console.log(\u0027recap token sumbited\u0027)\r\n           return;\r\n      \u007d \r\n  \u007d);  \r\n\u007d\r\n\r\nsetRecaptchaToken([[SAVED_CONTENT]])",JSON.stringify(_read_variables(["VAR_SAVED_CONTENT"])))!
         var _parse_result = JSON.parse(_result())
         _write_variables(JSON.parse(_parse_result.variables))
         if(!_parse_result.is_success)
         fail(_parse_result.error)
         

      },null)!
      

   }
   

function GoodXevilPaySolver_GXP_AutoConfirmCallback_Hcaptcha()
   {
   
      
      
      VAR_SAVED_CONTENT = _function_argument("token")
      

      
      
      VAR_TEMP_DATA2 = ""
      

      
      
      VAR_TEMP_DATA = ""
      

      
      
      _do(function(){
      _set_action_info({ name: "While" });
      VAR_CYCLE_INDEX = _iterator() - 1
      BREAK_CONDITION = VAR_TEMP_DATA == "";
      if(!BREAK_CONDITION)_break();
      
         
         
         _set_if_expression("W1tDWUNMRV9JTkRFWF1dICE9IDA=");
         _if(VAR_CYCLE_INDEX != 0,function(){
         
            
            
            sleep(500)!
            

         })!
         

         
         
         _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gMzA=");
         _if(VAR_CYCLE_INDEX > 30,function(){
         
            
            
            fail((_K==="en" ? "Hcaptcha is not detected on the page" : "Hcaptcha не обнаружена на странице"));
            

         })!
         

         
         
         _call(function()
         {
         _on_fail(function(){
         VAR_LAST_ERROR = _result()
         VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
         VAR_WAS_ERROR = false
         _break(1,true)
         })
         CYCLES.Current().RemoveLabel("function")
         
            
            
            page().script2("[[TEMP_DATA]] = window.captchaInfoh;",JSON.stringify(_read_variables(["VAR_TEMP_DATA"])))!
            var _parse_result = JSON.parse(_result())
            _write_variables(JSON.parse(_parse_result.variables))
            if(!_parse_result.is_success)
            fail(_parse_result.error)
            

         },null)!
         

         
         
         _set_if_expression("W1tURU1QX0RBVEFdXSA9PSAiIg==");
         _if(VAR_TEMP_DATA == "",function(){
         
            
            
            _call(function()
            {
            _on_fail(function(){
            VAR_LAST_ERROR = _result()
            VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
            VAR_WAS_ERROR = false
            _break(1,true)
            })
            CYCLES.Current().RemoveLabel("function")
            
               
               
               page().script2("[[TEMP_DATA2]] = window.captchaInfohtwo;",JSON.stringify(_read_variables(["VAR_TEMP_DATA2"])))!
               var _parse_result = JSON.parse(_result())
               _write_variables(JSON.parse(_parse_result.variables))
               if(!_parse_result.is_success)
               fail(_parse_result.error)
               

            },null)!
            

            
            
            _set_if_expression("W1tURU1QX0RBVEEyXV0gIT0gIiI=");
            _if(VAR_TEMP_DATA2 != "",function(){
            
               
               
               _call(function()
               {
               _on_fail(function(){
               VAR_LAST_ERROR = _result()
               VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
               VAR_WAS_ERROR = false
               _break(1,true)
               })
               CYCLES.Current().RemoveLabel("function")
               
                  
                  
                  page().script2("[[TEMP_DATA]] = window.captchaInfoh;",JSON.stringify(_read_variables(["VAR_TEMP_DATA"])))!
                  var _parse_result = JSON.parse(_result())
                  _write_variables(JSON.parse(_parse_result.variables))
                  if(!_parse_result.is_success)
                  fail(_parse_result.error)
                  

               },null)!
               

               
               
               _set_if_expression("W1tURU1QX0RBVEFdXSA9PSAiIg==");
               _if(VAR_TEMP_DATA == "",function(){
               
                  
                  
                  VAR_TEMP_DATA = VAR_TEMP_DATA2
                  

               })!
               

            })!
            

         })!
         

      })!
      

      
      
      _call(function()
      {
      _on_fail(function(){
      VAR_LAST_ERROR = _result()
      VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
      VAR_WAS_ERROR = false
      _break(1,true)
      })
      CYCLES.Current().RemoveLabel("function")
      
         
         
         page().script2("let container = document.querySelector(\u0027#\u0027+window.captchaInfohtwo.containerId);\r\n  for(let area of container.querySelectorAll(\u0022textarea\u0022))\u007b\r\n    area.value = [[SAVED_CONTENT]];\r\n  \u007d\r\n  for(let frame of container.querySelectorAll(\u0022iframe\u0022))\u007b\r\n    frame.setAttribute(\u0022data-hcaptcha-response\u0022, [[SAVED_CONTENT]]);\r\n  \u007d\r\n  if(window.captchaInfohtwo.callback != null)\u007b\r\n    let textarea = document.createElement(\u0027textarea\u0027);\r\n    textarea.id = \u0027callback-trigger\u0027;\r\n    textarea.setAttribute(\u0027data-function\u0027, window.captchaInfohtwo.callback);\r\n    textarea.value = [[SAVED_CONTENT]];\r\n    document.body.appendChild(textarea);\r\n    textarea = document.querySelector(\u0027textarea[id=callback-trigger]\u0027);\r\n    let func = textarea.getAttribute(\u0027data-function\u0027);\r\n    let data = textarea.value;\r\n    textarea.remove();\r\n    window[func](data);\r\n  \u007d",JSON.stringify(_read_variables(["VAR_SAVED_CONTENT"])))!
         var _parse_result = JSON.parse(_result())
         _write_variables(JSON.parse(_parse_result.variables))
         if(!_parse_result.is_success)
         fail(_parse_result.error)
         

      },null)!
      

      
      
      _set_if_expression("W1tXQVNfRVJST1JdXQ==");
      _if(typeof(VAR_WAS_ERROR) !== "undefined" ? (VAR_WAS_ERROR) : undefined,function(){
      
         
         
         VAR_ERROR_ID = parseInt(VAR_ERROR_ID) + parseInt(1)
         

      })!
      

      
      
      _call(function()
      {
      _on_fail(function(){
      VAR_LAST_ERROR = _result()
      VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
      VAR_WAS_ERROR = false
      _break(1,true)
      })
      CYCLES.Current().RemoveLabel("function")
      
         
         
         page().script2("let container = document.querySelector(\u0027#\u0027+window.captchaInfoh.containerId);\r\n  for(let area of container.querySelectorAll(\u0022textarea\u0022))\u007b\r\n    area.value = [[SAVED_CONTENT]];\r\n  \u007d\r\n  for(let frame of container.querySelectorAll(\u0022iframe\u0022))\u007b\r\n    frame.setAttribute(\u0022data-hcaptcha-response\u0022, [[SAVED_CONTENT]]);\r\n  \u007d\r\n  if(window.captchaInfoh.callback != null)\u007b\r\n    let textarea = document.createElement(\u0027textarea\u0027);\r\n    textarea.id = \u0027callback-trigger\u0027;\r\n    textarea.setAttribute(\u0027data-function\u0027, window.captchaInfoh.callback);\r\n    textarea.value = [[SAVED_CONTENT]];\r\n    document.body.appendChild(textarea);\r\n    textarea = document.querySelector(\u0027textarea[id=callback-trigger]\u0027);\r\n    let func = textarea.getAttribute(\u0027data-function\u0027);\r\n    let data = textarea.value;\r\n    textarea.remove();\r\n    window[func](data);\r\n  \u007d",JSON.stringify(_read_variables(["VAR_SAVED_CONTENT"])))!
         var _parse_result = JSON.parse(_result())
         _write_variables(JSON.parse(_parse_result.variables))
         if(!_parse_result.is_success)
         fail(_parse_result.error)
         

      },null)!
      

      
      
      _call(function()
      {
      _on_fail(function(){
      VAR_LAST_ERROR = _result()
      VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
      VAR_WAS_ERROR = false
      _break(1,true)
      })
      CYCLES.Current().RemoveLabel("function")
      
         
         
         _set_if_expression("ZmFsc2U=");
         _if(false,function(){
         
            
            
            page().script2("var xpath = \u0027//textarea[@name=\u0022g-recaptcha-response\u0022]\u0027;\r\nvar result = document.evaluate(xpath, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null);\r\nvar element = result.singleNodeValue;\r\n\r\nif (element) \u007b\r\n  element.innerText = [[SAVED_CONTENT]];\r\n\u007d\r\n\r\nvar xpath = \u0027//textarea[@name=\u0022h-captcha-response\u0022]\u0027;\r\nvar result = document.evaluate(xpath, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null);\r\nvar element = result.singleNodeValue;\r\n\r\nif (element) \u007b\r\n  element.innerText = [[SAVED_CONTENT]];\r\n\u007d\r\n",JSON.stringify(_read_variables(["VAR_SAVED_CONTENT"])))!
            var _parse_result = JSON.parse(_result())
            _write_variables(JSON.parse(_parse_result.variables))
            if(!_parse_result.is_success)
            fail(_parse_result.error)
            

         })!
         

      },null)!
      

      
      
      _set_if_expression("W1tXQVNfRVJST1JdXQ==");
      _if(typeof(VAR_WAS_ERROR) !== "undefined" ? (VAR_WAS_ERROR) : undefined,function(){
      
         
         
         VAR_ERROR_ID = parseInt(VAR_ERROR_ID) + parseInt(1)
         

      })!
      

      
      
      _set_if_expression("W1tFUlJPUl9JRF1dID09IDI=");
      _if(VAR_ERROR_ID == 2,function(){
      
         
         
         fail((_K==="en" ? "Hcaptcha is not solved" : "Hcaptcha не решена"));
         

      })!
      

   }
   

function GoodXevilPaySolver_GXP_Viefaucet()
   {
   
      
      
      VAR_APIKEY = _function_argument("apikey")
      

      
      
      var regexp_result = native("regexp", "first", JSON.stringify({text: VAR_APIKEY,regexp:("([0-9A-Za-z\u005c|]\u007b20,50\u007d)").toString()}))
      if(regexp_result.length == 0)
      regexp_result = []
      else
      regexp_result = JSON.parse(regexp_result)
      VAR_ALL_MATCH = regexp_result.pop()
      if(typeof(VAR_ALL_MATCH) == 'undefined' || !VAR_ALL_MATCH)
      VAR_ALL_MATCH = ""
      VAR_LIST_WITH_GROUPS = regexp_result
      VAR_APIKEY = regexp_result[0]
      if(typeof(VAR_APIKEY) == 'undefined' || !VAR_APIKEY)
      VAR_APIKEY = ""
      if(regexp_result.length == 0)
      {
      VAR_APIKEY = VAR_ALL_MATCH
      }
      if(VAR_ALL_MATCH != "" && Array.isArray(VAR_ALL_MATCH))
      VAR_LIST_WITH_GROUPS.unshift(VAR_ALL_MATCH)
      

      
      
      VAR_NOW_TYPE = 0
      

      
      
      /*Browser*/
      ;_SELECTOR=" \u003eXPATH\u003e //div[@class=\u0022captcha-solve\u0022]/img[@class=\u0022captcha-image\u0022]";
      get_element_selector(_SELECTOR, false).nowait().exist()!
      VAR_IS_EXISTS = _result() == 1
      _if(VAR_IS_EXISTS, function(){
      get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
      VAR_IS_EXISTS = _result().indexOf("true")>=0
      })!
      

      
      
      _do(function(){
      _set_action_info({ name: "While" });
      VAR_CYCLE_INDEX = _iterator() - 1
      BREAK_CONDITION = VAR_IS_EXISTS == false;
      if(!BREAK_CONDITION)_break();
      
         
         
         _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gMzA=");
         _if(VAR_CYCLE_INDEX > 30,function(){
         
            
            
            fail((_K==="en" ? "Didn't wait for the captcha image" : "Не дождался изображение капчи"));
            

         })!
         

         
         
         sleep(1000)!
         

         
         
         /*Browser*/
         ;_SELECTOR=" \u003eXPATH\u003e //div[@class=\u0022captcha\u0022]/img[@id=\u0022captchaImage\u0022]";
         get_element_selector(_SELECTOR, false).nowait().exist()!
         VAR_IS_EXISTS = _result() == 1
         _if(VAR_IS_EXISTS, function(){
         get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
         VAR_IS_EXISTS = _result().indexOf("true")>=0
         })!
         

         
         
         _set_if_expression("W1tJU19FWElTVFNdXQ==");
         _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
         
            
            
            VAR_NOW_TYPE = 1
            

            
            
            _break("function")
            

         })!
         

         
         
         /*Browser*/
         ;_SELECTOR=" \u003eXPATH\u003e //div[@class=\u0022captcha-solve\u0022]/img[@class=\u0022captcha-image\u0022]";
         get_element_selector(_SELECTOR, false).nowait().exist()!
         VAR_IS_EXISTS = _result() == 1
         _if(VAR_IS_EXISTS, function(){
         get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
         VAR_IS_EXISTS = _result().indexOf("true")>=0
         })!
         

      })!
      

      
      
      /*Browser*/
      scroll(1,1)!
      

      
      
      _set_if_expression("W1tOT1dfVFlQRV1dID09IDA=");
      _if(VAR_NOW_TYPE == 0,function(){
      
         
         
         /*Browser*/
         _SELECTOR = " \u003eXPATH\u003e //div[@class=\u0022captcha-solve\u0022]/img[@class=\u0022captcha-image\u0022]";
         wait_element(_SELECTOR)!
         get_element_selector(_SELECTOR, false).script("(function(){var rect = _BAS_HIDE(BrowserAutomationStudio_GetBoundingClientRect)(self);return (rect.left + positionx) + '|' + (rect.top + positiony) + '|' + (rect.right - rect.left) + '|' + (rect.bottom - rect.top) + '|' + (rect.left + positionx + scrollx) + '|' + (rect.top + positiony + scrolly)})();")!
         if(_result().length > 0)
         {
         var split = _result().split("|")
         VAR_X = parseInt(split[0])
         VAR_Y = parseInt(split[1])
         VAR_WIDTH = parseInt(split[2])
         VAR_HEIGHT = parseInt(split[3])
         VAR_ABSOLUTE_X = parseInt(split[4])
         VAR_ABSOLUTE_Y = parseInt(split[5])
         }
         

         
         
         /*Browser*/
         page().script("_BAS_HIDE(BrowserAutomationStudio_GetPageContent)()")!
         VAR_SAVED_PAGE_HTML = _result()
         

         
         
         html_parser_xpath_parse(VAR_SAVED_PAGE_HTML)
         if((true) && !html_parser_xpath_exist("//div[@class=\u0022captcha-solve\u0022]/img[@class=\u0022captcha-image\u0022]/@src"))
         fail("Can't resolve query " + "//div[@class=\u0022captcha-solve\u0022]/img[@class=\u0022captcha-image\u0022]/@src");
         VAR_XPATH_XML = html_parser_xpath_xml("//div[@class=\u0022captcha-solve\u0022]/img[@class=\u0022captcha-image\u0022]/@src")
         

      })!
      

      
      
      _set_if_expression("W1tOT1dfVFlQRV1dID09IDE=");
      _if(VAR_NOW_TYPE == 1,function(){
      
         
         
         /*Browser*/
         _SELECTOR = " \u003eXPATH\u003e //div[@class=\u0022captcha\u0022]/img[@id=\u0022captchaImage\u0022]";
         wait_element(_SELECTOR)!
         get_element_selector(_SELECTOR, false).script("(function(){var rect = _BAS_HIDE(BrowserAutomationStudio_GetBoundingClientRect)(self);return (rect.left + positionx) + '|' + (rect.top + positiony) + '|' + (rect.right - rect.left) + '|' + (rect.bottom - rect.top) + '|' + (rect.left + positionx + scrollx) + '|' + (rect.top + positiony + scrolly)})();")!
         if(_result().length > 0)
         {
         var split = _result().split("|")
         VAR_X = parseInt(split[0])
         VAR_Y = parseInt(split[1])
         VAR_WIDTH = parseInt(split[2])
         VAR_HEIGHT = parseInt(split[3])
         VAR_ABSOLUTE_X = parseInt(split[4])
         VAR_ABSOLUTE_Y = parseInt(split[5])
         }
         

         
         
         /*Browser*/
         page().script("_BAS_HIDE(BrowserAutomationStudio_GetPageContent)()")!
         VAR_SAVED_PAGE_HTML = _result()
         

         
         
         html_parser_xpath_parse(VAR_SAVED_PAGE_HTML)
         if((true) && !html_parser_xpath_exist("//div[@class=\u0022captcha\u0022]/img[@id=\u0022captchaImage\u0022]/@src"))
         fail("Can't resolve query " + "//div[@class=\u0022captcha\u0022]/img[@id=\u0022captchaImage\u0022]/@src");
         VAR_XPATH_XML = html_parser_xpath_xml("//div[@class=\u0022captcha\u0022]/img[@id=\u0022captchaImage\u0022]/@src")
         

      })!
      

      
      
      VAR_SCAN_RESULT_LIST = native("regexp", "scan", JSON.stringify({text: VAR_XPATH_XML,regexp:("([A-Za-z0-9\u005c+/=]+)").toString()}))
      if(VAR_SCAN_RESULT_LIST.length == 0)
      VAR_SCAN_RESULT_LIST = []
      else
      VAR_SCAN_RESULT_LIST = JSON.parse(VAR_SCAN_RESULT_LIST)
      

      
      
      VAR_IMAGE_DATA = ""
      

      
      
      VAR_TEMP_INDEX = 0
      

      
      
      _do_with_params({"foreach_data":(VAR_SCAN_RESULT_LIST)},function(){
      _set_action_info({ name: "Foreach" });
      VAR_CYCLE_INDEX = _iterator() - 1
      if(VAR_CYCLE_INDEX > _cycle_param("foreach_data").length - 1)_break();
      VAR_FOREACH_DATA = _cycle_param("foreach_data")[VAR_CYCLE_INDEX]
      
         
         
         _set_if_expression("W1tGT1JFQUNIX0RBVEFdXS5sZW5ndGggPiBbW1RFTVBfSU5ERVhdXQ==");
         _if(VAR_FOREACH_DATA.length > VAR_TEMP_INDEX,function(){
         
            
            
            VAR_TEMP_INDEX = VAR_FOREACH_DATA.length
            

            
            
            VAR_IMAGE_DATA = VAR_FOREACH_DATA
            

         })!
         

      })!
      

      
      
      _set_if_expression("W1tURU1QX0lOREVYXV0gPCA1MA==");
      _if(VAR_TEMP_INDEX < 50,function(){
      
         
         
         fail((_K==="en" ? "The image is too small" : "Слишком маленькое изображение"));
         

      })!
      

      
      
      _call(function()
      {
      _on_fail(function(){
      VAR_LAST_ERROR = _result()
      VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
      VAR_WAS_ERROR = false
      _break(1,true)
      })
      CYCLES.Current().RemoveLabel("function")
      
         
         
         solver_properties_clear("capmonster")
         solver_property("capmonster","serverurl","http://sctg.xyz/")
         solver_property("capmonster","key",VAR_APIKEY)
         solver_property("capmonster","method","viefaucet")
         solver_property("capmonster","body",VAR_IMAGE_DATA)
         solve_base64_no_fail("capmonster", "")!
         VAR_SAVED_CONTENT = _result();
         

      },null)!
      

      
      
      _set_if_expression("W1tXQVNfRVJST1JdXQ==");
      _if(typeof(VAR_WAS_ERROR) !== "undefined" ? (VAR_WAS_ERROR) : undefined,function(){
      
         
         
         fail((_K==="en" ? "The captcha is not solved" : "Капча не решена"));
         

      })!
      

      
      
      VAR_STRING_MATCHES = Boolean(native("regexp", "ismatch", JSON.stringify({text: VAR_SAVED_CONTENT,regexp:("(ERROR)").toString()})) == "true")
      

      
      
      VAR_STRING_MATCHES2 = Boolean(native("regexp", "ismatch", JSON.stringify({text: VAR_SAVED_CONTENT,regexp:("(_FAIL)").toString()})) == "true")
      

      
      
      VAR_STRING_MATCHES3 = Boolean(native("regexp", "ismatch", JSON.stringify({text: VAR_SAVED_CONTENT,regexp:("(_)").toString()})) == "true")
      

      
      
      _set_if_expression("W1tTVFJJTkdfTUFUQ0hFU11dIHx8IFtbU1RSSU5HX01BVENIRVMyXV0gfHwgW1tTVFJJTkdfTUFUQ0hFUzNdXQ==");
      _if(VAR_STRING_MATCHES || VAR_STRING_MATCHES2 || VAR_STRING_MATCHES3,function(){
      
         
         
         fail((_K==="en" ? "The captcha is not solved" : "Капча не решена"));
         

      })!
      

      
      
      VAR_SCAN_RESULT_LIST = native("regexp", "scan", JSON.stringify({text: VAR_SAVED_CONTENT,regexp:("\u005cd+").toString()}))
      if(VAR_SCAN_RESULT_LIST.length == 0)
      VAR_SCAN_RESULT_LIST = []
      else
      VAR_SCAN_RESULT_LIST = JSON.parse(VAR_SCAN_RESULT_LIST)
      

      
      
      VAR_LIST_LENGTH = (VAR_SCAN_RESULT_LIST).length
      

      
      
      _set_if_expression("W1tMSVNUX0xFTkdUSF1dICE9IDI=");
      _if(VAR_LIST_LENGTH != 2,function(){
      
         
         
         fail((_K==="en" ? "Unclear response from the server" : "Не понятный ответ от сервера"));
         

      })!
      

      
      
      VAR_X_XEVIL = parseInt(VAR_SCAN_RESULT_LIST[0]);
      VAR_Y_XEVIL = parseInt(VAR_SCAN_RESULT_LIST[1]);
      

      
      
      /*Browser*/
      move(VAR_X + VAR_X_XEVIL,VAR_Y + VAR_Y_XEVIL,  {} )!
      mouse(VAR_X + VAR_X_XEVIL,VAR_Y + VAR_Y_XEVIL)!
      

   }
   

function GoodXevilPaySolver_GXP_IMAGE_BASE64()
   {
   
      
      
      VAR_APIKEY = _function_argument("APIKEY")
      

      
      
      VAR_IMAGE_BASE64 = _function_argument("IMAGE_BASE64")
      

      
      
      var regexp_result = native("regexp", "first", JSON.stringify({text: VAR_APIKEY,regexp:("([0-9A-Za-z\u005c|]\u007b20,50\u007d)").toString()}))
      if(regexp_result.length == 0)
      regexp_result = []
      else
      regexp_result = JSON.parse(regexp_result)
      VAR_ALL_MATCH = regexp_result.pop()
      if(typeof(VAR_ALL_MATCH) == 'undefined' || !VAR_ALL_MATCH)
      VAR_ALL_MATCH = ""
      VAR_LIST_WITH_GROUPS = regexp_result
      VAR_APIKEY = regexp_result[0]
      if(typeof(VAR_APIKEY) == 'undefined' || !VAR_APIKEY)
      VAR_APIKEY = ""
      if(regexp_result.length == 0)
      {
      VAR_APIKEY = VAR_ALL_MATCH
      }
      if(VAR_ALL_MATCH != "" && Array.isArray(VAR_ALL_MATCH))
      VAR_LIST_WITH_GROUPS.unshift(VAR_ALL_MATCH)
      

      
      
      VAR_SCAN_RESULT_LIST = native("regexp", "scan", JSON.stringify({text: VAR_IMAGE_BASE64,regexp:("([A-Za-z0-9\u005c+/=]+)").toString()}))
      if(VAR_SCAN_RESULT_LIST.length == 0)
      VAR_SCAN_RESULT_LIST = []
      else
      VAR_SCAN_RESULT_LIST = JSON.parse(VAR_SCAN_RESULT_LIST)
      

      
      
      VAR_IMAGE_DATA = ""
      

      
      
      VAR_TEMP_INDEX = 0
      

      
      
      _do_with_params({"foreach_data":(VAR_SCAN_RESULT_LIST)},function(){
      _set_action_info({ name: "Foreach" });
      VAR_CYCLE_INDEX = _iterator() - 1
      if(VAR_CYCLE_INDEX > _cycle_param("foreach_data").length - 1)_break();
      VAR_FOREACH_DATA = _cycle_param("foreach_data")[VAR_CYCLE_INDEX]
      
         
         
         _set_if_expression("W1tGT1JFQUNIX0RBVEFdXS5sZW5ndGggPiBbW1RFTVBfSU5ERVhdXQ==");
         _if(VAR_FOREACH_DATA.length > VAR_TEMP_INDEX,function(){
         
            
            
            VAR_TEMP_INDEX = VAR_FOREACH_DATA.length
            

            
            
            VAR_IMAGE_DATA = VAR_FOREACH_DATA
            

         })!
         

      })!
      

      
      
      _set_if_expression("W1tURU1QX0lOREVYXV0gPCA1MA==");
      _if(VAR_TEMP_INDEX < 50,function(){
      
         
         
         fail((_K==="en" ? "The image is too small" : "Слишком маленькое изображение"));
         

      })!
      

      
      
      solver_properties_clear("capmonster")
      solver_property("capmonster","serverurl","http://sctg.xyz/")
      solver_property("capmonster","key",VAR_APIKEY)
      solver_property("capmonster","method","base64")
      solver_property("capmonster","body",VAR_IMAGE_DATA)
      solve_base64_no_fail("capmonster", "")!
      VAR_SAVED_CONTENT = _result();
      

      
      
      _function_return(VAR_SAVED_CONTENT)
      

   }
   

function GoodXevilPaySolver_GXP_ProtonMail()
   {
   
      
      
      VAR_APIKEY = _function_argument("APIKEY")
      

      
      
      var regexp_result = native("regexp", "first", JSON.stringify({text: VAR_APIKEY,regexp:("([0-9A-Za-z\u005c|]\u007b20,50\u007d)").toString()}))
      if(regexp_result.length == 0)
      regexp_result = []
      else
      regexp_result = JSON.parse(regexp_result)
      VAR_ALL_MATCH = regexp_result.pop()
      if(typeof(VAR_ALL_MATCH) == 'undefined' || !VAR_ALL_MATCH)
      VAR_ALL_MATCH = ""
      VAR_LIST_WITH_GROUPS = regexp_result
      VAR_APIKEY = regexp_result[0]
      if(typeof(VAR_APIKEY) == 'undefined' || !VAR_APIKEY)
      VAR_APIKEY = ""
      if(regexp_result.length == 0)
      {
      VAR_APIKEY = VAR_ALL_MATCH
      }
      if(VAR_ALL_MATCH != "" && Array.isArray(VAR_ALL_MATCH))
      VAR_LIST_WITH_GROUPS.unshift(VAR_ALL_MATCH)
      

      
      
      /*Browser*/
      ;_SELECTOR="\u003eCSS\u003e iframe[src*=\u0027/captcha\u0027]\u003eFRAME\u003e \u003eCSS\u003e iframe[src*=\u0027/captcha\u0027]\u003eFRAME\u003e \u003eCSS\u003e canvas";
      get_element_selector(_SELECTOR, false).nowait().exist()!
      VAR_IS_EXISTS = _result() == 1
      _if(VAR_IS_EXISTS, function(){
      get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
      VAR_IS_EXISTS = _result().indexOf("true")>=0
      })!
      

      
      
      _set_if_expression("W1tJU19FWElTVFNdXSA9PSBmYWxzZQ==");
      _if(VAR_IS_EXISTS == false,function(){
      
         
         
         _call(function()
         {
         _on_fail(function(){
         VAR_LAST_ERROR = _result()
         VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
         VAR_WAS_ERROR = false
         _break(1,true)
         })
         CYCLES.Current().RemoveLabel("function")
         
            
            
            /*Browser*/
            waiter_timeout_next(15000)
            wait_async_load()!
            

         },null)!
         

         
         
         /*Browser*/
         ;_SELECTOR="\u003eCSS\u003e iframe[src*=\u0027/captcha\u0027]\u003eFRAME\u003e \u003eCSS\u003e iframe[src*=\u0027/captcha\u0027]\u003eFRAME\u003e \u003eCSS\u003e canvas";
         get_element_selector(_SELECTOR, false).nowait().exist()!
         VAR_IS_EXISTS = _result() == 1
         _if(VAR_IS_EXISTS, function(){
         get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
         VAR_IS_EXISTS = _result().indexOf("true")>=0
         })!
         

         
         
         _set_if_expression("W1tJU19FWElTVFNdXSA9PSBmYWxzZQ==");
         _if(VAR_IS_EXISTS == false,function(){
         
            
            
            fail((_K==="en" ? "No captcha found" : "Капча не найдена"));
            

         })!
         

      })!
      

      
      
      /*Browser*/
      _SELECTOR = "\u003eCSS\u003e iframe[src*=\u0027/captcha\u0027]\u003eFRAME\u003e \u003eCSS\u003e iframe[src*=\u0027/captcha\u0027]\u003eFRAME\u003e \u003eCSS\u003e canvas";
      wait_element(_SELECTOR)!
      get_element_selector(_SELECTOR, false).exist()!
      _if(_result() == "1", function(){
      get_element_selector(_SELECTOR, false).render_base64()!
      VAR_SCREENSHOT_BASE64 = _result()
      })!
      

      
      
      /*Browser*/
      _SELECTOR = "\u003eCSS\u003e iframe[src*=\u0027/captcha\u0027]\u003eFRAME\u003e \u003eCSS\u003e iframe[src*=\u0027/captcha\u0027]\u003eFRAME\u003e \u003eCSS\u003e canvas";
      wait_element(_SELECTOR)!
      get_element_selector(_SELECTOR, false).script("(function(){var rect = _BAS_HIDE(BrowserAutomationStudio_GetBoundingClientRect)(self);return (rect.left + positionx) + '|' + (rect.top + positiony) + '|' + (rect.right - rect.left) + '|' + (rect.bottom - rect.top) + '|' + (rect.left + positionx + scrollx) + '|' + (rect.top + positiony + scrolly)})();")!
      if(_result().length > 0)
      {
      var split = _result().split("|")
      VAR_X = parseInt(split[0])
      VAR_Y = parseInt(split[1])
      VAR_WIDTH = parseInt(split[2])
      VAR_HEIGHT = parseInt(split[3])
      VAR_ABSOLUTE_X = parseInt(split[4])
      VAR_ABSOLUTE_Y = parseInt(split[5])
      }
      

      
      
      VAR_LOADED_IMAGE_ID = native("imageprocessing", "load", VAR_SCREENSHOT_BASE64)
      

      
      
      VAR_CROPPED_IMAGE_ID = native("imageprocessing", "sub", (VAR_LOADED_IMAGE_ID) + "," + (0) + "," + (60) + "," + (VAR_WIDTH) + "," + (VAR_HEIGHT - 60))
      

      
      
      VAR_IMAGE_DATA = native("imageprocessing", "getdata", VAR_CROPPED_IMAGE_ID)
      

      
      
      native("imageprocessing", "delete", VAR_CROPPED_IMAGE_ID)
      

      
      
      native("imageprocessing", "delete", VAR_LOADED_IMAGE_ID)
      

      
      
      solver_properties_clear("capmonster")
      solver_property("capmonster","serverurl","http://sctg.xyz/")
      solver_property("capmonster","key",VAR_APIKEY)
      solver_property("capmonster","method","protonmail")
      solver_property("capmonster","body",VAR_IMAGE_DATA)
      solve_base64_no_fail("capmonster", "")!
      VAR_SAVED_CONTENT = _result();
      

      
      
      VAR_SCAN_RESULT_LIST = native("regexp", "scan", JSON.stringify({text: VAR_SAVED_CONTENT,regexp:("\u005cd+").toString()}))
      if(VAR_SCAN_RESULT_LIST.length == 0)
      VAR_SCAN_RESULT_LIST = []
      else
      VAR_SCAN_RESULT_LIST = JSON.parse(VAR_SCAN_RESULT_LIST)
      

      
      
      VAR_LIST_LENGTH = (VAR_SCAN_RESULT_LIST).length
      

      
      
      _set_if_expression("W1tMSVNUX0xFTkdUSF1dICE9IDI=");
      _if(VAR_LIST_LENGTH != 2,function(){
      
         
         
         fail((_K==="en" ? "Unclear response from the server" : "Не понятный ответ от сервера"));
         

      })!
      

      
      
      VAR_X_XEVIL = parseInt(VAR_SCAN_RESULT_LIST[0]);
      VAR_Y_XEVIL = parseInt(VAR_SCAN_RESULT_LIST[1]);
      

      
      
      /*Browser*/
      move(VAR_X + 32,VAR_Y + 32,  {} )!
      mouse_down(VAR_X + 32,VAR_Y + 32)!
      

      
      
      /*Browser*/
      var move_settings =  {"speed": 50,"gravity": 4,"deviation": 5} ;
      move_settings["do_mouse_up"] = "true"
      move(VAR_X + VAR_X_XEVIL,VAR_Y + VAR_Y_XEVIL + 60, move_settings)!
      

      
      
      /*Browser*/
      _SELECTOR = "\u003eCSS\u003e iframe[src*=\u0027/captcha\u0027]\u003eFRAME\u003e \u003eCSS\u003e iframe[src*=\u0027/captcha\u0027]\u003eFRAME\u003e \u003eCSS\u003e button\u003eAT\u003e0";
      wait_element_visible(_SELECTOR)!
      _call(_random_point, {})!
      _if(_result().length > 0, function(){
      move( {} )!
      get_element_selector(_SELECTOR, false).clarify(X,Y)!
      _call(_clarify, {} )!
      mouse(X,Y)!
      })!
      

   }
   

function GoodXevilPaySolver_GXP_SurfEarner_AllowCache()
   {
   
      
      
      /*Browser*/
      cache_allow("*captcha.surfearner.com/collage/preview.php?*")!
      

   }
   

function GoodXevilPaySolver_GXP_SurfEarner()
   {
   
      
      
      VAR_APIKEY = _function_argument("apikey")
      

      
      
      var regexp_result = native("regexp", "first", JSON.stringify({text: VAR_APIKEY,regexp:("([0-9A-Za-z\u005c|]\u007b20,50\u007d)").toString()}))
      if(regexp_result.length == 0)
      regexp_result = []
      else
      regexp_result = JSON.parse(regexp_result)
      VAR_ALL_MATCH = regexp_result.pop()
      if(typeof(VAR_ALL_MATCH) == 'undefined' || !VAR_ALL_MATCH)
      VAR_ALL_MATCH = ""
      VAR_LIST_WITH_GROUPS = regexp_result
      VAR_APIKEY = regexp_result[0]
      if(typeof(VAR_APIKEY) == 'undefined' || !VAR_APIKEY)
      VAR_APIKEY = ""
      if(regexp_result.length == 0)
      {
      VAR_APIKEY = VAR_ALL_MATCH
      }
      if(VAR_ALL_MATCH != "" && Array.isArray(VAR_ALL_MATCH))
      VAR_LIST_WITH_GROUPS.unshift(VAR_ALL_MATCH)
      

      
      
      /*Browser*/
      cache_allow("*captcha.surfearner.com/collage/preview.php?*")!
      

      
      
      VAR_NOW_ID_FRAME = ""
      

      
      
      _do(function(){
      _set_action_info({ name: "For" });
      VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(0)
      if(VAR_CYCLE_INDEX > parseInt(4))_break();
      
         
         
         _set_if_expression("W1tDWUNMRV9JTkRFWF1dID49IDM=");
         _if(VAR_CYCLE_INDEX >= 3,function(){
         
            
            
            fail((_K==="en" ? "The service was unable to solve the captcha in 3 attempts" : "Сервис не смог решить капчу за 3 попытки"));
            

         })!
         

         
         
         _set_if_expression("W1tDWUNMRV9JTkRFWF1dICE9IDA=");
         _if(VAR_CYCLE_INDEX != 0,function(){
         
            
            
            /*Browser*/
            ;_SELECTOR=VAR_NOW_ID_FRAME + " \u003eXPATH\u003e id(\u0022secaptcha-refresh\u0022)";
            get_element_selector(_SELECTOR, false).nowait().exist()!
            VAR_IS_EXISTS = _result() == 1
            _if(VAR_IS_EXISTS, function(){
            get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
            VAR_IS_EXISTS = _result().indexOf("true")>=0
            })!
            

            
            
            _cycle_params().if_else = typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined;
            _set_if_expression("W1tJU19FWElTVFNdXQ==");
            _if(_cycle_params().if_else,function(){
            
               
               
               /*Browser*/
               _SELECTOR = VAR_NOW_ID_FRAME + " \u003eXPATH\u003e id(\u0022secaptcha-refresh\u0022)";
               wait_element_visible(_SELECTOR)!
               _call(_random_point, {})!
               _if(_result().length > 0, function(){
               move( {} )!
               get_element_selector(_SELECTOR, false).clarify(X,Y)!
               _call(_clarify, {} )!
               mouse(X,Y)!
               })!
               

               
               
               sleep(1000)!
               

            })!
            

            
            
            _if(!_cycle_params().if_else,function(){
            
               
               
               fail((_K==="en" ? "Captcha was not found" : "Капча не найдена"));
               

            })!
            delete _cycle_params().if_else;
            

         })!
         

         
         
         /*Browser*/
         ;_SELECTOR=VAR_NOW_ID_FRAME + " \u003eXPATH\u003e id(\u0022secaptcha-wrap\u0022)";
         get_element_selector(_SELECTOR, false).nowait().exist()!
         VAR_IS_EXISTS = _result() == 1
         _if(VAR_IS_EXISTS, function(){
         get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
         VAR_IS_EXISTS = _result().indexOf("true")>=0
         })!
         

         
         
         _set_if_expression("W1tJU19FWElTVFNdXSA9PSBmYWxzZQ==");
         _if(VAR_IS_EXISTS == false,function(){
         
            
            
            VAR_NOW_ID_FRAME = "\u003eXPATH\u003e id(\u0022_se_visit_frame\u0022)\u003eFRAME\u003e"
            

            
            
            /*Browser*/
            ;_SELECTOR=VAR_NOW_ID_FRAME + " \u003eXPATH\u003e id(\u0022secaptcha-wrap\u0022)";
            get_element_selector(_SELECTOR, false).nowait().exist()!
            VAR_IS_EXISTS = _result() == 1
            _if(VAR_IS_EXISTS, function(){
            get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
            VAR_IS_EXISTS = _result().indexOf("true")>=0
            })!
            

            
            
            _set_if_expression("W1tJU19FWElTVFNdXSA9PSBmYWxzZQ==");
            _if(VAR_IS_EXISTS == false,function(){
            
               
               
               fail((_K==="en" ? "No captcha image found" : "Не найдено изображение капчи"));
               

            })!
            

         })!
         

         
         
         /*Browser*/
         wait_load("*captcha.surfearner.com/collage/preview.php?*")!
         cache_get_base64("*captcha.surfearner.com/collage/preview.php?*")!
         VAR_SAVED_CACHE = _result()
         

         
         
         _do(function(){
         _set_action_info({ name: "While" });
         VAR_CYCLE_INDEX = _iterator() - 1
         BREAK_CONDITION = VAR_SAVED_CACHE == "";
         if(!BREAK_CONDITION)_break();
         
            
            
            sleep(1000)!
            

            
            
            _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gMjA=");
            _if(VAR_CYCLE_INDEX > 20,function(){
            
               
               
               fail((_K==="en" ? "Captcha was not found" : "Капча не найдена"));
               

            })!
            

            
            
            _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gMTA=");
            _if(VAR_CYCLE_INDEX > 10,function(){
            
               
               
               /*Browser*/
               ;_SELECTOR=VAR_NOW_ID_FRAME + " \u003eXPATH\u003e id(\u0022secaptcha-refresh\u0022)";
               get_element_selector(_SELECTOR, false).nowait().exist()!
               VAR_IS_EXISTS = _result() == 1
               _if(VAR_IS_EXISTS, function(){
               get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
               VAR_IS_EXISTS = _result().indexOf("true")>=0
               })!
               

               
               
               _cycle_params().if_else = typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined;
               _set_if_expression("W1tJU19FWElTVFNdXQ==");
               _if(_cycle_params().if_else,function(){
               
                  
                  
                  /*Browser*/
                  _SELECTOR = VAR_NOW_ID_FRAME + " \u003eXPATH\u003e id(\u0022secaptcha-refresh\u0022)";
                  wait_element_visible(_SELECTOR)!
                  _call(_random_point, {})!
                  _if(_result().length > 0, function(){
                  move( {} )!
                  get_element_selector(_SELECTOR, false).clarify(X,Y)!
                  _call(_clarify, {} )!
                  mouse(X,Y)!
                  })!
                  

                  
                  
                  sleep(1000)!
                  

               })!
               

               
               
               _if(!_cycle_params().if_else,function(){
               
                  
                  
                  fail((_K==="en" ? "Captcha was not found" : "Капча не найдена"));
                  

               })!
               delete _cycle_params().if_else;
               

            })!
            

            
            
            /*Browser*/
            wait_load("*captcha.surfearner.com/collage/preview.php?*")!
            cache_get_base64("*captcha.surfearner.com/collage/preview.php?*")!
            VAR_SAVED_CACHE = _result()
            

         })!
         

         
         
         /*Browser*/
         cache_data_clear()!
         

         
         
         _call(function()
         {
         _on_fail(function(){
         VAR_LAST_ERROR = _result()
         VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
         VAR_WAS_ERROR = false
         _break(1,true)
         })
         CYCLES.Current().RemoveLabel("function")
         
            
            
            solver_properties_clear("capmonster")
            solver_property("capmonster","serverurl","http://sctg.xyz/")
            solver_property("capmonster","key",VAR_APIKEY)
            solver_property("capmonster","method","surfearner")
            solver_property("capmonster","body",VAR_SAVED_CACHE)
            solve_base64_no_fail("capmonster", "")!
            VAR_SAVED_CONTENT = _result();
            

         },null)!
         

         
         
         _set_if_expression("W1tXQVNfRVJST1JdXQ==");
         _if(typeof(VAR_WAS_ERROR) !== "undefined" ? (VAR_WAS_ERROR) : undefined,function(){
         
            
            
            _next("function")
            

         })!
         

         
         
         VAR_STRING_MATCHES = Boolean(native("regexp", "ismatch", JSON.stringify({text: VAR_SAVED_CONTENT,regexp:("(ERROR)").toString()})) == "true")
         

         
         
         VAR_STRING_MATCHES2 = Boolean(native("regexp", "ismatch", JSON.stringify({text: VAR_SAVED_CONTENT,regexp:("(_FAIL)").toString()})) == "true")
         

         
         
         _set_if_expression("W1tTVFJJTkdfTUFUQ0hFU11dIHx8IFtbU1RSSU5HX01BVENIRVMyXV0=");
         _if(VAR_STRING_MATCHES || VAR_STRING_MATCHES2,function(){
         
            
            
            _next("function")
            

         })!
         

         
         
         VAR_SCAN_RESULT_LIST = native("regexp", "scan", JSON.stringify({text: VAR_SAVED_CONTENT,regexp:("\u005cd+").toString()}))
         if(VAR_SCAN_RESULT_LIST.length == 0)
         VAR_SCAN_RESULT_LIST = []
         else
         VAR_SCAN_RESULT_LIST = JSON.parse(VAR_SCAN_RESULT_LIST)
         

         
         
         VAR_LIST_LENGTH = (VAR_SCAN_RESULT_LIST).length
         

         
         
         _set_if_expression("W1tMSVNUX0xFTkdUSF1dICE9IDI=");
         _if(VAR_LIST_LENGTH != 2,function(){
         
            
            
            fail((_K==="en" ? "Unclear response from the server" : "Не понятный ответ от сервера"));
            

         })!
         

         
         
         /*Browser*/
         scroll(1,1)!
         

         
         
         /*Browser*/
         _SELECTOR = VAR_NOW_ID_FRAME + " \u003eXPATH\u003e id(\u0022secaptcha-wrap\u0022)";
         wait_element(_SELECTOR)!
         get_element_selector(_SELECTOR, false).script("(function(){var rect = _BAS_HIDE(BrowserAutomationStudio_GetBoundingClientRect)(self);return (rect.left + positionx) + '|' + (rect.top + positiony) + '|' + (rect.right - rect.left) + '|' + (rect.bottom - rect.top) + '|' + (rect.left + positionx + scrollx) + '|' + (rect.top + positiony + scrolly)})();")!
         if(_result().length > 0)
         {
         var split = _result().split("|")
         VAR_X = parseInt(split[0])
         VAR_Y = parseInt(split[1])
         VAR_WIDTH = parseInt(split[2])
         VAR_HEIGHT = parseInt(split[3])
         VAR_ABSOLUTE_X = parseInt(split[4])
         VAR_ABSOLUTE_Y = parseInt(split[5])
         }
         

         
         
         VAR_X_XEVIL = parseInt(VAR_SCAN_RESULT_LIST[0]);
         VAR_Y_XEVIL = parseInt(VAR_SCAN_RESULT_LIST[1]);
         

         
         
         /*Browser*/
         move(VAR_X + VAR_X_XEVIL,VAR_Y + VAR_Y_XEVIL,  {} )!
         mouse(VAR_X + VAR_X_XEVIL,VAR_Y + VAR_Y_XEVIL)!
         

         
         
         _break("function")
         

      })!
      

   }
   

function GoodXevilPaySolver_GXP_BuxMoney_PayupVideo()
   {
   
      
      
      VAR_TIMER = _function_argument("timer")
      

      
      
      VAR_APIKEY = _function_argument("apikey")
      

      
      
      var regexp_result = native("regexp", "first", JSON.stringify({text: VAR_APIKEY,regexp:("([0-9A-Za-z\u005c|]\u007b20,50\u007d)").toString()}))
      if(regexp_result.length == 0)
      regexp_result = []
      else
      regexp_result = JSON.parse(regexp_result)
      VAR_ALL_MATCH = regexp_result.pop()
      if(typeof(VAR_ALL_MATCH) == 'undefined' || !VAR_ALL_MATCH)
      VAR_ALL_MATCH = ""
      VAR_LIST_WITH_GROUPS = regexp_result
      VAR_APIKEY = regexp_result[0]
      if(typeof(VAR_APIKEY) == 'undefined' || !VAR_APIKEY)
      VAR_APIKEY = ""
      if(regexp_result.length == 0)
      {
      VAR_APIKEY = VAR_ALL_MATCH
      }
      if(VAR_ALL_MATCH != "" && Array.isArray(VAR_ALL_MATCH))
      VAR_LIST_WITH_GROUPS.unshift(VAR_ALL_MATCH)
      

      
      
      VAR_URL = "sctg.xyz"
      

      
      
      /*Browser*/
      ;_SELECTOR=" \u003eXPATH\u003e //div[contains(@class, \u0022captcha\u0022) and contains(@class, \u0022task\u0022)]//*[contains(@style, \u0022base64\u0022)]";
      get_element_selector(_SELECTOR, false).nowait().exist()!
      VAR_IS_EXISTS = _result() == 1
      _if(VAR_IS_EXISTS, function(){
      get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
      VAR_IS_EXISTS = _result().indexOf("true")>=0
      })!
      

      
      
      VAR_GOOD_SOLVE = "0"
      

      
      
      VAR_NOW_CAPTCHA_UID = ""
      

      
      
      VAR_NEW_TYPE_IS = false
      

      
      
      _do(function(){
      _set_action_info({ name: "While" });
      VAR_CYCLE_INDEX = _iterator() - 1
      BREAK_CONDITION = VAR_IS_EXISTS == false;
      if(!BREAK_CONDITION)_break();
      
         
         
         _set_if_expression("W1tDWUNMRV9JTkRFWF1dID49IFtbVElNRVJdXQ==");
         _if(VAR_CYCLE_INDEX >= VAR_TIMER,function(){
         
            
            
            fail((_K==="en" ? "Captcha was not found" : "Капча не найдена"));
            

         })!
         

         
         
         sleep(1000)!
         

         
         
         /*Browser*/
         ;_SELECTOR=" \u003eXPATH\u003e //div[contains(@class, \u0022captcha\u0022) and contains(@class, \u0022task\u0022)]//*[contains(@style, \u0022base64\u0022)]";
         get_element_selector(_SELECTOR, false).nowait().exist()!
         VAR_IS_EXISTS = _result() == 1
         _if(VAR_IS_EXISTS, function(){
         get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
         VAR_IS_EXISTS = _result().indexOf("true")>=0
         })!
         

         
         
         _cycle_params().if_else = VAR_IS_EXISTS == false;
         _set_if_expression("W1tJU19FWElTVFNdXSA9PSBmYWxzZQ==");
         _if(_cycle_params().if_else,function(){
         
            
            
            _do(function(){
            _set_action_info({ name: "For" });
            VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(0)
            if(VAR_CYCLE_INDEX > parseInt(10))_break();
            
               
               
               /*Browser*/
               ;_SELECTOR=" \u003eXPATH\u003e //button[@id]/..//*[@class and contains(@style, \u0022background\u0022)]\u003eAT\u003e" + VAR_CYCLE_INDEX;
               get_element_selector(_SELECTOR, false).nowait().exist()!
               VAR_IS_EXISTS = _result() == 1
               _if(VAR_IS_EXISTS, function(){
               get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
               VAR_IS_EXISTS = _result().indexOf("true")>=0
               })!
               

               
               
               _set_if_expression("W1tJU19FWElTVFNdXQ==");
               _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
               
                  
                  
                  VAR_NOW_CAPTCHA_UID = " \u003eXPATH\u003e //button[@id]/..//*[@class and contains(@style, \u0022background\u0022)]\u003eAT\u003e" + VAR_CYCLE_INDEX
                  

                  
                  
                  VAR_NEW_TYPE_IS = true
                  

                  
                  
                  _break("function")
                  

               })!
               

            })!
            

         })!
         

         
         
         _if(!_cycle_params().if_else,function(){
         
            
            
            VAR_NOW_CAPTCHA_UID = " \u003eXPATH\u003e //div[contains(@class, \u0022captcha\u0022) and contains(@class, \u0022task\u0022)]//*[contains(@style, \u0022base64\u0022)]"
            

         })!
         delete _cycle_params().if_else;
         

      })!
      

      
      
      _do(function(){
      _set_action_info({ name: "While" });
      VAR_CYCLE_INDEX = _iterator() - 1
      BREAK_CONDITION = true;
      if(!BREAK_CONDITION)_break();
      
         
         
         /*Browser*/
         ;_SELECTOR=" \u003eCSS\u003e #captcha-alert";
         get_element_selector(_SELECTOR, false).nowait().exist()!
         VAR_IS_EXISTS = _result() == 1
         _if(VAR_IS_EXISTS, function(){
         get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
         VAR_IS_EXISTS = _result().indexOf("true")>=0
         })!
         

         
         
         _set_if_expression("W1tJU19FWElTVFNdXQ==");
         _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
         
            
            
            /*Browser*/
            ;_SELECTOR=" \u003eXPATH\u003e //div[@id=\u0022captcha-alert\u0022 and contains(@class, \u0022success\u0022)]";
            get_element_selector(_SELECTOR, false).nowait().exist()!
            VAR_IS_EXISTS = _result() == 1
            _if(VAR_IS_EXISTS, function(){
            get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
            VAR_IS_EXISTS = _result().indexOf("true")>=0
            })!
            

            
            
            _cycle_params().if_else = typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined;
            _set_if_expression("W1tJU19FWElTVFNdXQ==");
            _if(_cycle_params().if_else,function(){
            
               
               
               _break("function")
               

            })!
            

            
            
            _if(!_cycle_params().if_else,function(){
            
               
               
               fail((_K==="en" ? "Captcha is not solved, the solution time has expired" : "Капча не решена, время решения истекло"));
               

            })!
            delete _cycle_params().if_else;
            

         })!
         

         
         
         _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gNCAmJiBbW0dPT0RfU09MVkVdXSAhPSAiMSI=");
         _if(VAR_CYCLE_INDEX > 4 && VAR_GOOD_SOLVE != "1",function(){
         
            
            
            fail((_K==="en" ? "Captcha has not been solved in 4 tries" : "Капча не решена за 4 попытки"));
            

         })!
         

         
         
         _set_if_expression("W1tDWUNMRV9JTkRFWF1dICE9IDA=");
         _if(VAR_CYCLE_INDEX != 0,function(){
         
            
            
            sleep(3000)!
            

         })!
         

         
         
         /*Browser*/
         ;_SELECTOR=VAR_NOW_CAPTCHA_UID;
         get_element_selector(_SELECTOR, false).nowait().exist()!
         VAR_IS_EXISTS = _result() == 1
         _if(VAR_IS_EXISTS, function(){
         get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
         VAR_IS_EXISTS = _result().indexOf("true")>=0
         })!
         

         
         
         _set_if_expression("W1tJU19FWElTVFNdXSA9PSBmYWxzZSAmJiBbW05FV19UWVBFX0lTXV0=");
         _if(VAR_IS_EXISTS == false && VAR_NEW_TYPE_IS,function(){
         
            
            
            sleep(2000)!
            

            
            
            _do(function(){
            _set_action_info({ name: "For" });
            VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(0)
            if(VAR_CYCLE_INDEX > parseInt(10))_break();
            
               
               
               /*Browser*/
               ;_SELECTOR=" \u003eXPATH\u003e //button[@id=\u0022nextTask\u0022]/..//*[@class and contains(@style, \u0022background\u0022)]\u003eAT\u003e" + VAR_CYCLE_INDEX;
               get_element_selector(_SELECTOR, false).nowait().exist()!
               VAR_IS_EXISTS = _result() == 1
               _if(VAR_IS_EXISTS, function(){
               get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
               VAR_IS_EXISTS = _result().indexOf("true")>=0
               })!
               

               
               
               _set_if_expression("W1tJU19FWElTVFNdXQ==");
               _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
               
                  
                  
                  VAR_NOW_CAPTCHA_UID = " \u003eXPATH\u003e //button[@id=\u0022nextTask\u0022]/..//*[@class and contains(@style, \u0022background\u0022)]\u003eAT\u003e" + VAR_CYCLE_INDEX
                  

                  
                  
                  _break("function")
                  

               })!
               

            })!
            

         })!
         

         
         
         _set_if_expression("W1tJU19FWElTVFNdXSA9PSBmYWxzZQ==");
         _if(VAR_IS_EXISTS == false,function(){
         
            
            
            _set_if_expression("W1tHT09EX1NPTFZFXV0gPT0gIjEi");
            _if(VAR_GOOD_SOLVE == "1",function(){
            
               
               
               _break("function")
               

            })!
            

            
            
            sleep(4000)!
            

            
            
            _next("function")
            

         })!
         

         
         
         /*Browser*/
         ;_SELECTOR=VAR_NOW_CAPTCHA_UID;
         get_element_selector(_SELECTOR, false).nowait().exist()!
         VAR_IS_EXISTS = _result() == 1
         _if(VAR_IS_EXISTS, function(){
         get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
         VAR_IS_EXISTS = _result().indexOf("true")>=0
         })!
         

         
         
         _set_if_expression("W1tJU19FWElTVFNdXSA9PSBmYWxzZQ==");
         _if(VAR_IS_EXISTS == false,function(){
         
            
            
            _next("function")
            

         })!
         

         
         
         /*Browser*/
         page().script("_BAS_HIDE(BrowserAutomationStudio_GetPageContent)()")!
         VAR_SAVED_PAGE_HTML = _result()
         

         
         
         _cycle_params().if_else = VAR_NEW_TYPE_IS == false;
         _set_if_expression("W1tORVdfVFlQRV9JU11dID09IGZhbHNl");
         _if(_cycle_params().if_else,function(){
         
            
            
            html_parser_xpath_parse(VAR_SAVED_PAGE_HTML)
            if((false) && !html_parser_xpath_exist("//div[contains(@class, \u0022captcha\u0022) and contains(@class, \u0022task\u0022)]//*[contains(@style, \u0022base64\u0022)]"))
            fail("Can't resolve query " + "//div[contains(@class, \u0022captcha\u0022) and contains(@class, \u0022task\u0022)]//*[contains(@style, \u0022base64\u0022)]");
            VAR_SCREENSHOT_BASE64 = html_parser_xpath_xml("//div[contains(@class, \u0022captcha\u0022) and contains(@class, \u0022task\u0022)]//*[contains(@style, \u0022base64\u0022)]")
            

         })!
         

         
         
         _if(!_cycle_params().if_else,function(){
         
            
            
            /*Browser*/
            _SELECTOR = VAR_NOW_CAPTCHA_UID;
            wait_element(_SELECTOR)!
            get_element_selector(_SELECTOR, false).xml()!
            VAR_SCREENSHOT_BASE64 = _result()
            

         })!
         delete _cycle_params().if_else;
         

         
         
         VAR_SCAN_RESULT_LIST = native("regexp", "scan", JSON.stringify({text: VAR_SCREENSHOT_BASE64,regexp:("\u0026quot;data:image/png;base64\u005c,([\u005cs\u005cS]+?)\u0026quot;").toString()}))
         if(VAR_SCAN_RESULT_LIST.length == 0)
         VAR_SCAN_RESULT_LIST = []
         else
         VAR_SCAN_RESULT_LIST = JSON.parse(VAR_SCAN_RESULT_LIST)
         

         
         
         VAR_LIST_LENGTH = (VAR_SCAN_RESULT_LIST).length
         

         
         
         var regexp_result = native("regexp", "first", JSON.stringify({text: VAR_SCREENSHOT_BASE64,regexp:("\u0026quot;data:image/png;base64\u005c,([\u005cs\u005cS]+?)\u0026quot;").toString()}))
         if(regexp_result.length == 0)
         regexp_result = []
         else
         regexp_result = JSON.parse(regexp_result)
         VAR_ALL_MATCH = regexp_result.pop()
         if(typeof(VAR_ALL_MATCH) == 'undefined' || !VAR_ALL_MATCH)
         VAR_ALL_MATCH = ""
         VAR_LIST_WITH_GROUPS = regexp_result
         VAR_SCREENSHOT_BASE64 = regexp_result[0]
         if(typeof(VAR_SCREENSHOT_BASE64) == 'undefined' || !VAR_SCREENSHOT_BASE64)
         VAR_SCREENSHOT_BASE64 = ""
         if(regexp_result.length == 0)
         {
         VAR_SCREENSHOT_BASE64 = VAR_ALL_MATCH
         }
         if(VAR_ALL_MATCH != "" && Array.isArray(VAR_ALL_MATCH))
         VAR_LIST_WITH_GROUPS.unshift(VAR_ALL_MATCH)
         

         
         
         VAR_IMAGE_FIND_DATA = VAR_SCREENSHOT_BASE64
         

         
         
         _set_if_expression("W1tMSVNUX0xFTkdUSF1dICE9IDE=");
         _if(VAR_LIST_LENGTH != 1,function(){
         
            
            
            VAR_IMAGE_ID_LIST = []
            

            
            
            VAR_X_IMG_IS = []
            

            
            
            VAR_Y_IMG_IS = 0
            

            
            
            VAR_X_IMG_SUMM = 0
            

            
            
            _do_with_params({"foreach_data":(VAR_SCAN_RESULT_LIST)},function(){
            _set_action_info({ name: "Foreach" });
            VAR_CYCLE_INDEX = _iterator() - 1
            if(VAR_CYCLE_INDEX > _cycle_param("foreach_data").length - 1)_break();
            VAR_FOREACH_DATA = _cycle_param("foreach_data")[VAR_CYCLE_INDEX]
            
               
               
               VAR_LOADED_IMAGE_ID = native("imageprocessing", "load", VAR_FOREACH_DATA)
               

               
               
               VAR_IMAGE_ID_LIST.push(VAR_LOADED_IMAGE_ID)
               

               
               
               {
               var split = native("imageprocessing", "getsize", VAR_LOADED_IMAGE_ID).split(",")
               VAR_IMAGE_WIDTH = parseInt(split[0])
               VAR_IMAGE_HEIGHT = parseInt(split[1])
               }
               

               
               
               _set_if_expression("W1tZX0lNR19JU11dIDwgW1tJTUFHRV9IRUlHSFRdXQ==");
               _if(VAR_Y_IMG_IS < VAR_IMAGE_HEIGHT,function(){
               
                  
                  
                  VAR_Y_IMG_IS = VAR_IMAGE_HEIGHT
                  

               })!
               

               
               
               VAR_X_IMG_IS.push(VAR_IMAGE_WIDTH)
               

               
               
               VAR_X_IMG_SUMM = parseInt(VAR_X_IMG_SUMM) + parseInt(VAR_IMAGE_WIDTH)
               

            })!
            

            
            
            VAR_CREATED_IMAGE_ID = native("imageprocessing", "create", (VAR_X_IMG_SUMM) + "," + (VAR_Y_IMG_IS) + "," + (255) + "," + (255) + "," + (255) + "," + (255))
            

            
            
            VAR_Y = 0
            

            
            
            VAR_X = 0
            

            
            
            _do_with_params({"foreach_data":(VAR_IMAGE_ID_LIST)},function(){
            _set_action_info({ name: "Foreach" });
            VAR_CYCLE_INDEX = _iterator() - 1
            if(VAR_CYCLE_INDEX > _cycle_param("foreach_data").length - 1)_break();
            VAR_FOREACH_DATA = _cycle_param("foreach_data")[VAR_CYCLE_INDEX]
            
               
               
               _set_if_expression("W1tDWUNMRV9JTkRFWF1dICE9IDA=");
               _if(VAR_CYCLE_INDEX != 0,function(){
               
                  
                  
                  VAR_X = parseInt(VAR_X) + parseInt(VAR_X_IMG_IS[VAR_CYCLE_INDEX - 1])
                  

               })!
               

               
               
               native("imageprocessing", "insert", (VAR_CREATED_IMAGE_ID) + "," + (VAR_FOREACH_DATA) + ","  + (VAR_X) + "," + (VAR_Y))
               

               
               
               native("imageprocessing", "delete", VAR_FOREACH_DATA)
               

            })!
            

            
            
            VAR_SCREENSHOT_BASE64 = native("imageprocessing", "getdata", VAR_CREATED_IMAGE_ID)
            

            
            
            native("imageprocessing", "delete", VAR_CREATED_IMAGE_ID)
            

         })!
         

         
         
         _set_if_expression("W1tTQ1JFRU5TSE9UX0JBU0U2NF1dID09ICIi");
         _if(VAR_SCREENSHOT_BASE64 == "",function(){
         
            
            
            _set_if_expression("W1tHT09EX1NPTFZFXV0gPT0gIjEi");
            _if(VAR_GOOD_SOLVE == "1",function(){
            
               
               
               _break("function")
               

            })!
            

            
            
            sleep(4000)!
            

            
            
            _next("function")
            

         })!
         

         
         
         VAR_GOOD_SOLVE = "0"
         

         
         
         _cycle_params().if_else = true;
         _set_if_expression("dHJ1ZQ==");
         _if(_cycle_params().if_else,function(){
         
            
            
            _call(function()
            {
            _on_fail(function(){
            VAR_LAST_ERROR = _result()
            VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
            VAR_WAS_ERROR = false
            _break(1,true)
            })
            CYCLES.Current().RemoveLabel("function")
            
               
               
               _switch_http_client_main()
               http_client_post("http://" + VAR_URL + "/in.php", ["key",VAR_APIKEY,"method","buxmoney","body",VAR_SCREENSHOT_BASE64], {"content-type":("multipart"), "encoding":("UTF-8"), "method":("POST"),headers:("")})!
               

            },null)!
            

            
            
            _set_if_expression("W1tXQVNfRVJST1JdXQ==");
            _if(typeof(VAR_WAS_ERROR) !== "undefined" ? (VAR_WAS_ERROR) : undefined,function(){
            
               
               
               _next("function")
               

            })!
            

            
            
            /*Browser*/
            scroll(1,1)!
            

            
            
            /*Browser*/
            _SELECTOR = " \u003eXPATH\u003e //*[contains(@style, \u0022" + VAR_IMAGE_FIND_DATA + "\u0022)]";
            wait_element(_SELECTOR)!
            get_element_selector(_SELECTOR, false).script("(function(){var rect = _BAS_HIDE(BrowserAutomationStudio_GetBoundingClientRect)(self);return (rect.left + positionx) + '|' + (rect.top + positiony) + '|' + (rect.right - rect.left) + '|' + (rect.bottom - rect.top) + '|' + (rect.left + positionx + scrollx) + '|' + (rect.top + positiony + scrolly)})();")!
            if(_result().length > 0)
            {
            var split = _result().split("|")
            VAR_X = parseInt(split[0])
            VAR_Y = parseInt(split[1])
            VAR_WIDTH = parseInt(split[2])
            VAR_HEIGHT = parseInt(split[3])
            VAR_ABSOLUTE_X = parseInt(split[4])
            VAR_ABSOLUTE_Y = parseInt(split[5])
            }
            

            
            
            _switch_http_client_main()
            VAR_SAVED_CONTENT = http_client_encoded_content("auto")
            

            
            
            sleep(1000)!
            

            
            
            VAR_ID = VAR_SAVED_CONTENT.split("|")[1]
            

            
            
            _switch_http_client_main()
            http_client_get2("http://" + VAR_URL + "/res.php?key=" + VAR_APIKEY + "\u0026id=" + VAR_ID,{method:("GET"),headers:("")})!
            

            
            
            _switch_http_client_main()
            VAR_SAVED_CONTENT = http_client_encoded_content("auto")
            

            
            
            _do(function(){
            _set_action_info({ name: "While" });
            VAR_CYCLE_INDEX = _iterator() - 1
            BREAK_CONDITION = VAR_SAVED_CONTENT == "CAPCHA_NOT_READY";
            if(!BREAK_CONDITION)_break();
            
               
               
               _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gMTU=");
               _if(VAR_CYCLE_INDEX > 15,function(){
               
                  
                  
                  fail((_K==="en" ? "Service didn't solve captcha in 15 seconds" : "Сервис не решил капчу за 15 секунд"));
                  

               })!
               

               
               
               sleep(1000)!
               

               
               
               _call(function()
               {
               _on_fail(function(){
               VAR_LAST_ERROR = _result()
               VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
               VAR_WAS_ERROR = false
               _break(1,true)
               })
               CYCLES.Current().RemoveLabel("function")
               
                  
                  
                  _switch_http_client_main()
                  http_client_get2("http://" + VAR_URL + "/res.php?key=" + VAR_APIKEY + "\u0026id=" + VAR_ID,{method:("GET"),headers:("")})!
                  

               },null)!
               

               
               
               _switch_http_client_main()
               VAR_SAVED_CONTENT = http_client_encoded_content("auto")
               

            })!
            

            
            
            VAR_STRING_CONTAINS = Boolean(native("regexp", "ismatch", JSON.stringify({text: VAR_SAVED_CONTENT,regexp:("(\u005c|)").toString()})) == "true")
            

            
            
            _cycle_params().if_else = typeof(VAR_STRING_CONTAINS) !== "undefined" ? (VAR_STRING_CONTAINS) : undefined;
            _set_if_expression("W1tTVFJJTkdfQ09OVEFJTlNdXQ==");
            _if(_cycle_params().if_else,function(){
            
               
               
               VAR_SCAN_RESULT_LIST = native("regexp", "scan", JSON.stringify({text: VAR_SAVED_CONTENT,regexp:("(\u005cd+)").toString()}))
               if(VAR_SCAN_RESULT_LIST.length == 0)
               VAR_SCAN_RESULT_LIST = []
               else
               VAR_SCAN_RESULT_LIST = JSON.parse(VAR_SCAN_RESULT_LIST)
               

               
               
               VAR_LIST_LENGTH = (VAR_SCAN_RESULT_LIST).length
               

               
               
               _set_if_expression("W1tMSVNUX0xFTkdUSF1dICE9IDI=");
               _if(VAR_LIST_LENGTH != 2,function(){
               
                  
                  
                  _next("function")
                  

               })!
               

               
               
               VAR_XIMG = parseInt(VAR_SCAN_RESULT_LIST[0]);
               VAR_YIMG = parseInt(VAR_SCAN_RESULT_LIST[1]);
               

               
               
               /*Browser*/
               ;_SELECTOR=" \u003eCSS\u003e #captcha-alert";
               get_element_selector(_SELECTOR, false).nowait().exist()!
               VAR_IS_EXISTS = _result() == 1
               _if(VAR_IS_EXISTS, function(){
               get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
               VAR_IS_EXISTS = _result().indexOf("true")>=0
               })!
               

               
               
               _set_if_expression("W1tJU19FWElTVFNdXQ==");
               _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
               
                  
                  
                  fail((_K==="en" ? "Captcha is not solved, the solution time has expired" : "Капча не решена, время решения истекло"));
                  

               })!
               

               
               
               /*Browser*/
               move(VAR_X+VAR_XIMG,VAR_Y+VAR_YIMG,  {} )!
               mouse(VAR_X+VAR_XIMG,VAR_Y+VAR_YIMG)!
               

               
               
               VAR_GOOD_SOLVE = "1"
               

               
               
               sleep(4000)!
               

            })!
            

            
            
            _if(!_cycle_params().if_else,function(){
            
               
               
               /*Browser*/
               _SELECTOR = " \u003eCSS\u003e #reload \u003e svg";waiter_timeout_next(1000)
               waiter_nofail_next();
               wait_element_visible(_SELECTOR)!
               _call(_random_point, {})!
               _if(_result().length > 0, function(){
               X = parseInt(_result().split(",")[0])
               Y = parseInt(_result().split(",")[1])
               mouse(X,Y)!
               })!
               

            })!
            delete _cycle_params().if_else;
            

         })!
         

         
         
         _if(!_cycle_params().if_else,function(){
         
            
            
            VAR_PROJECT_DIRECTORY = project_directory();
            

            
            
            VAR_RANDOM_STRING = _random_string(12,"abcdefghijklmnopqrstuvwxyz0123456789");
            

            
            
            native("filesystem", "writefile", JSON.stringify({path: VAR_PROJECT_DIRECTORY + "/buxmoney/" + VAR_RANDOM_STRING + ".png",value: (VAR_SCREENSHOT_BASE64).toString(),base64:true,append:false}))
            

            
            
            /*Browser*/
            _SELECTOR = " \u003eCSS\u003e #reload \u003e svg";waiter_timeout_next(5000)
            waiter_nofail_next();
            wait_element_visible(_SELECTOR)!
            _call(_random_point, {})!
            _if(_result().length > 0, function(){
            X = parseInt(_result().split(",")[0])
            Y = parseInt(_result().split(",")[1])
            mouse(X,Y)!
            })!
            

         })!
         delete _cycle_params().if_else;
         

      })!
      

   }
   

function GoodXevilPaySolver_GXP_Seo_SeoTime()
   {
   
      
      
      VAR_APIKEY = _function_argument("apikey")
      

      
      
      var regexp_result = native("regexp", "first", JSON.stringify({text: VAR_APIKEY,regexp:("([0-9A-Za-z\u005c|]\u007b20,50\u007d)").toString()}))
      if(regexp_result.length == 0)
      regexp_result = []
      else
      regexp_result = JSON.parse(regexp_result)
      VAR_ALL_MATCH = regexp_result.pop()
      if(typeof(VAR_ALL_MATCH) == 'undefined' || !VAR_ALL_MATCH)
      VAR_ALL_MATCH = ""
      VAR_LIST_WITH_GROUPS = regexp_result
      VAR_APIKEY = regexp_result[0]
      if(typeof(VAR_APIKEY) == 'undefined' || !VAR_APIKEY)
      VAR_APIKEY = ""
      if(regexp_result.length == 0)
      {
      VAR_APIKEY = VAR_ALL_MATCH
      }
      if(VAR_ALL_MATCH != "" && Array.isArray(VAR_ALL_MATCH))
      VAR_LIST_WITH_GROUPS.unshift(VAR_ALL_MATCH)
      

      
      
      VAR_URL_ADRESS_SOLVER = "http://sctg.xyz"
      

      
      
      VAR_ERROR_FATAL = 0
      

      
      
      _do(function(){
      _set_action_info({ name: "For" });
      VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
      if(VAR_CYCLE_INDEX > parseInt(6))_break();
      
         
         
         _set_if_expression("W1tDWUNMRV9JTkRFWF1dID49IDY=");
         _if(VAR_CYCLE_INDEX >= 6,function(){
         
            
            
            fail((_K==="en" ? "Couldn't solve the captcha in 6 times" : "Не получилось решить капчу за 6 раз"));
            

         })!
         

         
         
         _call(function()
         {
         _on_fail(function(){
         VAR_LAST_ERROR = _result()
         VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
         VAR_WAS_ERROR = false
         _break(1,true)
         })
         CYCLES.Current().RemoveLabel("function")
         
            
            
            VAR_LIST_SCREENSHOTS = []
            

            
            
            /*Browser*/
            page().script("_BAS_HIDE(BrowserAutomationStudio_GetPageContent)()")!
            VAR_SAVED_PAGE_HTML = _result()
            

            
            
            html_parser_xpath_parse(VAR_SAVED_PAGE_HTML)
            VAR_XPATH_XML_LIST = html_parser_xpath_xml_list("//*[contains(@class,\u0027out-capcha-lab\u0027)]")
            

            
            
            VAR_LIST_LENGTH = (VAR_XPATH_XML_LIST).length
            

            
            
            _do(function(){
            _set_action_info({ name: "While" });
            VAR_CYCLE_INDEX = _iterator() - 1
            BREAK_CONDITION = VAR_LIST_LENGTH == 0;
            if(!BREAK_CONDITION)_break();
            
               
               
               _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gMzA=");
               _if(VAR_CYCLE_INDEX > 30,function(){
               
                  
                  
                  fail((_K==="en" ? "Didn't wait for the captcha in 30 seconds" : "Не дождался капчи за 30 секунд"));
                  

               })!
               

               
               
               sleep(1000)!
               

               
               
               /*Browser*/
               page().script("_BAS_HIDE(BrowserAutomationStudio_GetPageContent)()")!
               VAR_SAVED_PAGE_HTML = _result()
               

               
               
               html_parser_xpath_parse(VAR_SAVED_PAGE_HTML)
               VAR_XPATH_XML_LIST = html_parser_xpath_xml_list("//*[contains(@class,\u0027out-capcha-lab\u0027)]")
               

               
               
               VAR_LIST_LENGTH = (VAR_XPATH_XML_LIST).length
               

            })!
            

            
            
            VAR_XPATH_XML_LIST = (function(){var seen = {}; return (VAR_XPATH_XML_LIST).filter(function(item) { return seen.hasOwnProperty(item) ? false : (seen[item] = true); });})();
            

            
            
            _do_with_params({"foreach_data":(VAR_XPATH_XML_LIST)},function(){
            _set_action_info({ name: "Foreach" });
            VAR_CYCLE_INDEX = _iterator() - 1
            if(VAR_CYCLE_INDEX > _cycle_param("foreach_data").length - 1)_break();
            VAR_FOREACH_DATA = _cycle_param("foreach_data")[VAR_CYCLE_INDEX]
            
               
               
               VAR_SCREENSHOT_BASE64 = VAR_FOREACH_DATA.split("base64,")[1].split(")")[0]
               

               
               
               VAR_LIST_SCREENSHOTS.push(VAR_SCREENSHOT_BASE64)
               

            })!
            

            
            
            html_parser_xpath_parse(VAR_SAVED_PAGE_HTML)
            if((true) && !html_parser_xpath_exist("//*[contains(@class,\u0027out-capcha-title\u0027)]"))
            fail("Can't resolve query " + "//*[contains(@class,\u0027out-capcha-title\u0027)]");
            VAR_CAPTCHA_TEXT = html_parser_xpath_text("//*[contains(@class,\u0027out-capcha-title\u0027)]")
            

            
            
            VAR_CAPTCHA_TEXT = native("regexp", "replace", JSON.stringify({text: VAR_CAPTCHA_TEXT,regexp:("(\u005c \u005c )").toString(),replace:""}))
            

            
            
            _switch_http_client_main()
            general_timeout_next(15000)
            http_client_post(VAR_URL_ADRESS_SOLVER + "/in.php", ["method","seotime","body_1",VAR_LIST_SCREENSHOTS[0],"body_2",VAR_LIST_SCREENSHOTS[1],"body_3",VAR_LIST_SCREENSHOTS[2],"body_4",VAR_LIST_SCREENSHOTS[3],"body_5",VAR_LIST_SCREENSHOTS[4],"textinstructions",VAR_CAPTCHA_TEXT,"key",VAR_APIKEY], {"content-type":("multipart"), "encoding":("UTF-8"), "method":("POST"),headers:("")})!
            

            
            
            _switch_http_client_main()
            VAR_SAVED_CONTENT = http_client_encoded_content("utf-8")
            

            
            
            VAR_STRING_CONTAINS = Boolean(native("regexp", "ismatch", JSON.stringify({text: VAR_SAVED_CONTENT,regexp:("(ERROR)").toString()})) == "true")
            

            
            
            _set_if_expression("W1tTVFJJTkdfQ09OVEFJTlNdXQ==");
            _if(typeof(VAR_STRING_CONTAINS) !== "undefined" ? (VAR_STRING_CONTAINS) : undefined,function(){
            
               
               
               fail((_K==="en" ? "There was an error when recognizing captcha" : "Произошла ошибка при распознавании капчи"));
               

            })!
            

            
            
            VAR_ID = VAR_SAVED_CONTENT.split("|")[1]
            

            
            
            _do(function(){
            _set_action_info({ name: "While" });
            VAR_CYCLE_INDEX = _iterator() - 1
            BREAK_CONDITION = true;
            if(!BREAK_CONDITION)_break();
            
               
               
               _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gMzA=");
               _if(VAR_CYCLE_INDEX > 30,function(){
               
                  
                  
                  fail((_K==="en" ? "The service failed to recognize the captcha in 30 seconds" : "Сервис не распознал капчу за 30 секунд"));
                  

               })!
               

               
               
               sleep(1000)!
               

               
               
               _switch_http_client_main()
               http_client_get2(VAR_URL_ADRESS_SOLVER + "/res.php?key=" + VAR_APIKEY + "\u0026id=" + VAR_ID,{method:("GET"),headers:("")})!
               

               
               
               _switch_http_client_main()
               VAR_SAVED_CONTENT = http_client_encoded_content("utf-8")
               

               
               
               _set_if_expression("W1tTQVZFRF9DT05URU5UXV0gIT0gIkNBUENIQV9OT1RfUkVBRFki");
               _if(VAR_SAVED_CONTENT != "CAPCHA_NOT_READY",function(){
               
                  
                  
                  _break("function")
                  

               })!
               

            })!
            

            
            
            VAR_STRING_CONTAINS = Boolean(native("regexp", "ismatch", JSON.stringify({text: VAR_SAVED_CONTENT,regexp:("(ERROR)").toString()})) == "true")
            

            
            
            _set_if_expression("W1tTVFJJTkdfQ09OVEFJTlNdXQ==");
            _if(typeof(VAR_STRING_CONTAINS) !== "undefined" ? (VAR_STRING_CONTAINS) : undefined,function(){
            
               
               
               fail((_K==="en" ? "There was an error when recognizing captcha" : "Произошла ошибка при распознавании капчи"));
               

            })!
            

            
            
            VAR_IMAGES = VAR_SAVED_CONTENT.split("|")[1]
            

            
            
            VAR_IMAGES = VAR_IMAGES.split(",")
            

            
            
            _do_with_params({"foreach_data":(VAR_IMAGES)},function(){
            _set_action_info({ name: "Foreach" });
            VAR_CYCLE_INDEX = _iterator() - 1
            if(VAR_CYCLE_INDEX > _cycle_param("foreach_data").length - 1)_break();
            VAR_FOREACH_DATA = _cycle_param("foreach_data")[VAR_CYCLE_INDEX]
            
               
               
               VAR_ID = VAR_FOREACH_DATA - 1
               

               
               
               /*Browser*/
               _SELECTOR = " \u003eXPATH\u003e //label[@class=\u0022out-capcha-lab\u0022]\u003eAT\u003e" + VAR_ID;
               wait_element_visible(_SELECTOR)!
               _call(_random_point, {})!
               _if(_result().length > 0, function(){
               X = parseInt(_result().split(",")[0])
               Y = parseInt(_result().split(",")[1])
               mouse(X,Y)!
               })!
               

            })!
            

            
            
            _break("function")
            

         },null)!
         

         
         
         _set_if_expression("W1tXQVNfRVJST1JdXQ==");
         _if(typeof(VAR_WAS_ERROR) !== "undefined" ? (VAR_WAS_ERROR) : undefined,function(){
         
            
            
            page().script2("re_load_capcha();",JSON.stringify(_read_variables([])))!
            var _parse_result = JSON.parse(_result())
            _write_variables(JSON.parse(_parse_result.variables))
            if(!_parse_result.is_success)
            fail(_parse_result.error)
            

            
            
            sleep(1000)!
            

         })!
         

      })!
      

   }
   

function GoodXevilPaySolver_GXP_Seo_SeoFast()
   {
   
      
      
      VAR_APIKEY = _function_argument("apikey")
      

      
      
      VAR_SOLVER_URL = "http://127.0.0.1:10000"
      

      
      
      VAR_SOLVER_URL = "http://sctg.xyz"
      

      
      
      var regexp_result = native("regexp", "first", JSON.stringify({text: VAR_APIKEY,regexp:("([0-9A-Za-z\u005c|]\u007b20,50\u007d)").toString()}))
      if(regexp_result.length == 0)
      regexp_result = []
      else
      regexp_result = JSON.parse(regexp_result)
      VAR_ALL_MATCH = regexp_result.pop()
      if(typeof(VAR_ALL_MATCH) == 'undefined' || !VAR_ALL_MATCH)
      VAR_ALL_MATCH = ""
      VAR_LIST_WITH_GROUPS = regexp_result
      VAR_APIKEY = regexp_result[0]
      if(typeof(VAR_APIKEY) == 'undefined' || !VAR_APIKEY)
      VAR_APIKEY = ""
      if(regexp_result.length == 0)
      {
      VAR_APIKEY = VAR_ALL_MATCH
      }
      if(VAR_ALL_MATCH != "" && Array.isArray(VAR_ALL_MATCH))
      VAR_LIST_WITH_GROUPS.unshift(VAR_ALL_MATCH)
      

      
      
      VAR_ERROR_FATAL = 0
      

      
      
      _do(function(){
      _set_action_info({ name: "For" });
      VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
      if(VAR_CYCLE_INDEX > parseInt(6))_break();
      
         
         
         _set_if_expression("W1tDWUNMRV9JTkRFWF1dID49IDY=");
         _if(VAR_CYCLE_INDEX >= 6,function(){
         
            
            
            fail((_K==="en" ? "Couldn't solve the captcha in 6 times" : "Не получилось решить капчу за 6 раз"));
            

         })!
         

         
         
         _call(function()
         {
         _on_fail(function(){
         VAR_LAST_ERROR = _result()
         VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
         VAR_WAS_ERROR = false
         _break(1,true)
         })
         CYCLES.Current().RemoveLabel("function")
         
            
            
            VAR_LIST_SCREENSHOTS = []
            

            
            
            /*Browser*/
            page().script("_BAS_HIDE(BrowserAutomationStudio_GetPageContent)()")!
            VAR_SAVED_PAGE_HTML = _result()
            

            
            
            html_parser_xpath_parse(VAR_SAVED_PAGE_HTML)
            VAR_XPATH_XML_LIST = html_parser_xpath_xml_list("//*[contains(@class,\u0027out-capcha-lab\u0027)]")
            

            
            
            VAR_LIST_LENGTH = (VAR_XPATH_XML_LIST).length
            

            
            
            _do(function(){
            _set_action_info({ name: "While" });
            VAR_CYCLE_INDEX = _iterator() - 1
            BREAK_CONDITION = VAR_LIST_LENGTH == 0;
            if(!BREAK_CONDITION)_break();
            
               
               
               _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gMzA=");
               _if(VAR_CYCLE_INDEX > 30,function(){
               
                  
                  
                  fail((_K==="en" ? "Didn't wait for the captcha in 30 seconds" : "Не дождался капчи за 30 секунд"));
                  

               })!
               

               
               
               sleep(1000)!
               

               
               
               /*Browser*/
               page().script("_BAS_HIDE(BrowserAutomationStudio_GetPageContent)()")!
               VAR_SAVED_PAGE_HTML = _result()
               

               
               
               html_parser_xpath_parse(VAR_SAVED_PAGE_HTML)
               VAR_XPATH_XML_LIST = html_parser_xpath_xml_list("//*[contains(@class,\u0027out-capcha-lab\u0027)]")
               

               
               
               VAR_LIST_LENGTH = (VAR_XPATH_XML_LIST).length
               

            })!
            

            
            
            VAR_XPATH_XML_LIST = (function(){var seen = {}; return (VAR_XPATH_XML_LIST).filter(function(item) { return seen.hasOwnProperty(item) ? false : (seen[item] = true); });})();
            

            
            
            _do_with_params({"foreach_data":(VAR_XPATH_XML_LIST)},function(){
            _set_action_info({ name: "Foreach" });
            VAR_CYCLE_INDEX = _iterator() - 1
            if(VAR_CYCLE_INDEX > _cycle_param("foreach_data").length - 1)_break();
            VAR_FOREACH_DATA = _cycle_param("foreach_data")[VAR_CYCLE_INDEX]
            
               
               
               VAR_SCREENSHOT_BASE64 = VAR_FOREACH_DATA.split("base64,")[1].split(")")[0]
               

               
               
               VAR_LIST_SCREENSHOTS.push(VAR_SCREENSHOT_BASE64)
               

            })!
            

            
            
            html_parser_xpath_parse(VAR_SAVED_PAGE_HTML)
            if((true) && !html_parser_xpath_exist("//*[contains(@class,\u0027out-capcha-title\u0027)]"))
            fail("Can't resolve query " + "//*[contains(@class,\u0027out-capcha-title\u0027)]");
            VAR_CAPTCHA_TEXT = html_parser_xpath_text("//*[contains(@class,\u0027out-capcha-title\u0027)]")
            

            
            
            VAR_CAPTCHA_TEXT = native("regexp", "replace", JSON.stringify({text: VAR_CAPTCHA_TEXT.split("<a")[0],regexp:("([^\u005cp\u007bL\u007d])").toString(),replace:""}))
            

            
            
            _switch_http_client_main()
            general_timeout_next(15000)
            http_client_post(VAR_SOLVER_URL + "/in.php", ["method","seofast","body_1",VAR_LIST_SCREENSHOTS[0],"body_2",VAR_LIST_SCREENSHOTS[1],"body_3",VAR_LIST_SCREENSHOTS[2],"body_4",VAR_LIST_SCREENSHOTS[3],"body_5",VAR_LIST_SCREENSHOTS[4],"textinstructions",VAR_CAPTCHA_TEXT,"key",VAR_APIKEY], {"content-type":("multipart"), "encoding":("UTF-8"), "method":("POST"),headers:("")})!
            

            
            
            _switch_http_client_main()
            VAR_SAVED_CONTENT = http_client_encoded_content("utf-8")
            

            
            
            VAR_STRING_CONTAINS = Boolean(native("regexp", "ismatch", JSON.stringify({text: VAR_SAVED_CONTENT,regexp:("(ERROR)").toString()})) == "true")
            

            
            
            _set_if_expression("W1tTVFJJTkdfQ09OVEFJTlNdXQ==");
            _if(typeof(VAR_STRING_CONTAINS) !== "undefined" ? (VAR_STRING_CONTAINS) : undefined,function(){
            
               
               
               fail((_K==="en" ? "There was an error when recognizing captcha" : "Произошла ошибка при распознавании капчи"));
               

            })!
            

            
            
            VAR_ID = VAR_SAVED_CONTENT.split("|")[1]
            

            
            
            _do(function(){
            _set_action_info({ name: "While" });
            VAR_CYCLE_INDEX = _iterator() - 1
            BREAK_CONDITION = true;
            if(!BREAK_CONDITION)_break();
            
               
               
               _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gMzA=");
               _if(VAR_CYCLE_INDEX > 30,function(){
               
                  
                  
                  fail((_K==="en" ? "The service failed to recognize the captcha in 30 seconds" : "Сервис не распознал капчу за 30 секунд"));
                  

               })!
               

               
               
               sleep(1000)!
               

               
               
               _switch_http_client_main()
               http_client_get2(VAR_SOLVER_URL + "/res.php?key=" + VAR_APIKEY + "\u0026id=" + VAR_ID,{method:("GET"),headers:("")})!
               

               
               
               _switch_http_client_main()
               VAR_SAVED_CONTENT = http_client_encoded_content("utf-8")
               

               
               
               _set_if_expression("W1tTQVZFRF9DT05URU5UXV0gIT0gIkNBUENIQV9OT1RfUkVBRFki");
               _if(VAR_SAVED_CONTENT != "CAPCHA_NOT_READY",function(){
               
                  
                  
                  _break("function")
                  

               })!
               

            })!
            

            
            
            VAR_STRING_CONTAINS = Boolean(native("regexp", "ismatch", JSON.stringify({text: VAR_SAVED_CONTENT,regexp:("(ERROR)").toString()})) == "true")
            

            
            
            _set_if_expression("W1tTVFJJTkdfQ09OVEFJTlNdXQ==");
            _if(typeof(VAR_STRING_CONTAINS) !== "undefined" ? (VAR_STRING_CONTAINS) : undefined,function(){
            
               
               
               fail((_K==="en" ? "There was an error when recognizing captcha" : "Произошла ошибка при распознавании капчи"));
               

            })!
            

            
            
            VAR_IMAGES = VAR_SAVED_CONTENT.split("|")[1]
            

            
            
            VAR_IMAGES = VAR_IMAGES.split(",")
            

            
            
            _do_with_params({"foreach_data":(VAR_IMAGES)},function(){
            _set_action_info({ name: "Foreach" });
            VAR_CYCLE_INDEX = _iterator() - 1
            if(VAR_CYCLE_INDEX > _cycle_param("foreach_data").length - 1)_break();
            VAR_FOREACH_DATA = _cycle_param("foreach_data")[VAR_CYCLE_INDEX]
            
               
               
               VAR_ID = VAR_FOREACH_DATA - 1
               

               
               
               /*Browser*/
               _SELECTOR = " \u003eXPATH\u003e //label[@class=\u0022out-capcha-lab\u0022]\u003eAT\u003e" + VAR_ID;
               wait_element_visible(_SELECTOR)!
               _call(_random_point, {})!
               _if(_result().length > 0, function(){
               X = parseInt(_result().split(",")[0])
               Y = parseInt(_result().split(",")[1])
               mouse(X,Y)!
               })!
               

            })!
            

            
            
            _break("function")
            

         },null)!
         

         
         
         _set_if_expression("W1tXQVNfRVJST1JdXQ==");
         _if(typeof(VAR_WAS_ERROR) !== "undefined" ? (VAR_WAS_ERROR) : undefined,function(){
         
            
            
            page().script2("reload_capcha();",JSON.stringify(_read_variables([])))!
            var _parse_result = JSON.parse(_result())
            _write_variables(JSON.parse(_parse_result.variables))
            if(!_parse_result.is_success)
            fail(_parse_result.error)
            

            
            
            sleep(1000)!
            

         })!
         

      })!
      

   }
   

function GoodXevilPaySolver_GXP_Seo_Profitcentr()
   {
   
      
      
      VAR_APIKEY = _function_argument("apikey")
      

      
      
      var regexp_result = native("regexp", "first", JSON.stringify({text: VAR_APIKEY,regexp:("([0-9A-Za-z\u005c|]\u007b20,50\u007d)").toString()}))
      if(regexp_result.length == 0)
      regexp_result = []
      else
      regexp_result = JSON.parse(regexp_result)
      VAR_ALL_MATCH = regexp_result.pop()
      if(typeof(VAR_ALL_MATCH) == 'undefined' || !VAR_ALL_MATCH)
      VAR_ALL_MATCH = ""
      VAR_LIST_WITH_GROUPS = regexp_result
      VAR_APIKEY = regexp_result[0]
      if(typeof(VAR_APIKEY) == 'undefined' || !VAR_APIKEY)
      VAR_APIKEY = ""
      if(regexp_result.length == 0)
      {
      VAR_APIKEY = VAR_ALL_MATCH
      }
      if(VAR_ALL_MATCH != "" && Array.isArray(VAR_ALL_MATCH))
      VAR_LIST_WITH_GROUPS.unshift(VAR_ALL_MATCH)
      

      
      
      VAR_ERROR_FATAL = 0
      

      
      
      _do(function(){
      _set_action_info({ name: "For" });
      VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
      if(VAR_CYCLE_INDEX > parseInt(6))_break();
      
         
         
         _set_if_expression("W1tDWUNMRV9JTkRFWF1dID49IDY=");
         _if(VAR_CYCLE_INDEX >= 6,function(){
         
            
            
            fail((_K==="en" ? "Couldn't solve the captcha in 6 times" : "Не получилось решить капчу за 6 раз"));
            

         })!
         

         
         
         _call(function()
         {
         _on_fail(function(){
         VAR_LAST_ERROR = _result()
         VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
         VAR_WAS_ERROR = false
         _break(1,true)
         })
         CYCLES.Current().RemoveLabel("function")
         
            
            
            VAR_LIST_SCREENSHOTS = []
            

            
            
            /*Browser*/
            page().script("_BAS_HIDE(BrowserAutomationStudio_GetPageContent)()")!
            VAR_SAVED_PAGE_HTML = _result()
            

            
            
            html_parser_xpath_parse(VAR_SAVED_PAGE_HTML)
            VAR_XPATH_XML_LIST = html_parser_xpath_xml_list("//*[contains(@class,\u0027out-capcha-lab\u0027)]")
            

            
            
            VAR_LIST_LENGTH = (VAR_XPATH_XML_LIST).length
            

            
            
            _do(function(){
            _set_action_info({ name: "While" });
            VAR_CYCLE_INDEX = _iterator() - 1
            BREAK_CONDITION = VAR_LIST_LENGTH == 0;
            if(!BREAK_CONDITION)_break();
            
               
               
               _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gMzA=");
               _if(VAR_CYCLE_INDEX > 30,function(){
               
                  
                  
                  fail((_K==="en" ? "Didn't wait for the captcha in 30 seconds" : "Не дождался капчи за 30 секунд"));
                  

               })!
               

               
               
               sleep(1000)!
               

               
               
               /*Browser*/
               page().script("_BAS_HIDE(BrowserAutomationStudio_GetPageContent)()")!
               VAR_SAVED_PAGE_HTML = _result()
               

               
               
               html_parser_xpath_parse(VAR_SAVED_PAGE_HTML)
               VAR_XPATH_XML_LIST = html_parser_xpath_xml_list("//*[contains(@class,\u0027out-capcha-lab\u0027)]")
               

               
               
               VAR_LIST_LENGTH = (VAR_XPATH_XML_LIST).length
               

            })!
            

            
            
            VAR_XPATH_XML_LIST = (function(){var seen = {}; return (VAR_XPATH_XML_LIST).filter(function(item) { return seen.hasOwnProperty(item) ? false : (seen[item] = true); });})();
            

            
            
            _do_with_params({"foreach_data":(VAR_XPATH_XML_LIST)},function(){
            _set_action_info({ name: "Foreach" });
            VAR_CYCLE_INDEX = _iterator() - 1
            if(VAR_CYCLE_INDEX > _cycle_param("foreach_data").length - 1)_break();
            VAR_FOREACH_DATA = _cycle_param("foreach_data")[VAR_CYCLE_INDEX]
            
               
               
               VAR_SCREENSHOT_BASE64 = VAR_FOREACH_DATA.split("base64,")[1].split(")")[0]
               

               
               
               VAR_LIST_SCREENSHOTS.push(VAR_SCREENSHOT_BASE64)
               

            })!
            

            
            
            html_parser_xpath_parse(VAR_SAVED_PAGE_HTML)
            if((true) && !html_parser_xpath_exist("//*[contains(@class,\u0027out-capcha-title\u0027)]"))
            fail("Can't resolve query " + "//*[contains(@class,\u0027out-capcha-title\u0027)]");
            VAR_CAPTCHA_TEXT = html_parser_xpath_text("//*[contains(@class,\u0027out-capcha-title\u0027)]")
            

            
            
            VAR_CAPTCHA_TEXT = native("regexp", "replace", JSON.stringify({text: VAR_CAPTCHA_TEXT,regexp:("(\u005c \u005c )").toString(),replace:""}))
            

            
            
            _switch_http_client_main()
            general_timeout_next(15000)
            http_client_post("http://sctg.xyz/in.php", ["method","profit","body_1",VAR_LIST_SCREENSHOTS[0],"body_2",VAR_LIST_SCREENSHOTS[1],"body_3",VAR_LIST_SCREENSHOTS[2],"body_4",VAR_LIST_SCREENSHOTS[3],"body_5",VAR_LIST_SCREENSHOTS[4],"body_6",VAR_LIST_SCREENSHOTS[5],"textinstructions",VAR_CAPTCHA_TEXT,"key",VAR_APIKEY], {"content-type":("multipart"), "encoding":("UTF-8"), "method":("POST"),headers:("")})!
            

            
            
            _switch_http_client_main()
            VAR_SAVED_CONTENT = http_client_encoded_content("utf-8")
            

            
            
            VAR_STRING_CONTAINS = Boolean(native("regexp", "ismatch", JSON.stringify({text: VAR_SAVED_CONTENT,regexp:("(ERROR)").toString()})) == "true")
            

            
            
            _set_if_expression("W1tTVFJJTkdfQ09OVEFJTlNdXQ==");
            _if(typeof(VAR_STRING_CONTAINS) !== "undefined" ? (VAR_STRING_CONTAINS) : undefined,function(){
            
               
               
               fail((_K==="en" ? "There was an error when recognizing captcha" : "Произошла ошибка при распознавании капчи"));
               

            })!
            

            
            
            VAR_ID = VAR_SAVED_CONTENT.split("|")[1]
            

            
            
            _do(function(){
            _set_action_info({ name: "While" });
            VAR_CYCLE_INDEX = _iterator() - 1
            BREAK_CONDITION = true;
            if(!BREAK_CONDITION)_break();
            
               
               
               _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gMzA=");
               _if(VAR_CYCLE_INDEX > 30,function(){
               
                  
                  
                  fail((_K==="en" ? "The service failed to recognize the captcha in 30 seconds" : "Сервис не распознал капчу за 30 секунд"));
                  

               })!
               

               
               
               sleep(1000)!
               

               
               
               _switch_http_client_main()
               http_client_get2("http://sctg.xyz/res.php?key=" + VAR_APIKEY + "\u0026id=" + VAR_ID,{method:("GET"),headers:("")})!
               

               
               
               _switch_http_client_main()
               VAR_SAVED_CONTENT = http_client_encoded_content("utf-8")
               

               
               
               _set_if_expression("W1tTQVZFRF9DT05URU5UXV0gIT0gIkNBUENIQV9OT1RfUkVBRFki");
               _if(VAR_SAVED_CONTENT != "CAPCHA_NOT_READY",function(){
               
                  
                  
                  _break("function")
                  

               })!
               

            })!
            

            
            
            VAR_STRING_CONTAINS = Boolean(native("regexp", "ismatch", JSON.stringify({text: VAR_SAVED_CONTENT,regexp:("(ERROR)").toString()})) == "true")
            

            
            
            _set_if_expression("W1tTVFJJTkdfQ09OVEFJTlNdXQ==");
            _if(typeof(VAR_STRING_CONTAINS) !== "undefined" ? (VAR_STRING_CONTAINS) : undefined,function(){
            
               
               
               fail((_K==="en" ? "There was an error when recognizing captcha" : "Произошла ошибка при распознавании капчи"));
               

            })!
            

            
            
            VAR_IMAGES = VAR_SAVED_CONTENT.split("|")[1]
            

            
            
            VAR_IMAGES = VAR_IMAGES.split(",")
            

            
            
            _do_with_params({"foreach_data":(VAR_IMAGES)},function(){
            _set_action_info({ name: "Foreach" });
            VAR_CYCLE_INDEX = _iterator() - 1
            if(VAR_CYCLE_INDEX > _cycle_param("foreach_data").length - 1)_break();
            VAR_FOREACH_DATA = _cycle_param("foreach_data")[VAR_CYCLE_INDEX]
            
               
               
               VAR_ID = VAR_FOREACH_DATA - 1
               

               
               
               /*Browser*/
               _SELECTOR = " \u003eXPATH\u003e //label[@class=\u0022out-capcha-lab\u0022]\u003eAT\u003e" + VAR_ID;
               wait_element_visible(_SELECTOR)!
               _call(_random_point, {})!
               _if(_result().length > 0, function(){
               X = parseInt(_result().split(",")[0])
               Y = parseInt(_result().split(",")[1])
               mouse(X,Y)!
               })!
               

            })!
            

            
            
            _break("function")
            

         },null)!
         

         
         
         _set_if_expression("W1tXQVNfRVJST1JdXQ==");
         _if(typeof(VAR_WAS_ERROR) !== "undefined" ? (VAR_WAS_ERROR) : undefined,function(){
         
            
            
            page().script2("re_load_capcha();",JSON.stringify(_read_variables([])))!
            var _parse_result = JSON.parse(_result())
            _write_variables(JSON.parse(_parse_result.variables))
            if(!_parse_result.is_success)
            fail(_parse_result.error)
            

            
            
            sleep(1000)!
            

         })!
         

      })!
      

   }
   

function GoodXevilPaySolver_GXP_SliderSolver()
   {
   
      
      
      VAR_ARROW_ID = _function_argument("arrow_id")
      

      
      
      VAR_BUTTON_ID = _function_argument("button_id")
      

      
      
      VAR_TYPE_SLIDE = _function_argument("type_slide")
      

      
      
      VAR_COEF = _function_argument("coef")
      

      
      
      VAR_IMAGE_ID = _function_argument("image id")
      

      
      
      VAR_RELOAD_ID = _function_argument("reload_id")
      

      
      
      VAR_SLIDER_TYPE = _function_argument("slider_type")
      

      
      
      VAR_ATTEMPTS = _function_argument("Attempts")
      

      
      
      VAR_PIXEL_KOEF = _function_argument("pixel_koef")
      

      
      
      VAR_AVTOUPDATE = _function_argument("avtoupdate")
      

      
      
      VAR_KEY = _function_argument("key")
      

      
      
      VAR_SPEED = _function_argument("speed")
      

      
      
      VAR_ATTEMPTS = VAR_ATTEMPTS - 1
      

      
      
      VAR_CAPTCHA_ID = 0
      

      
      
      var regexp_result = native("regexp", "first", JSON.stringify({text: VAR_KEY,regexp:("([0-9A-Za-z\u005c|]\u007b20,50\u007d)").toString()}))
      if(regexp_result.length == 0)
      regexp_result = []
      else
      regexp_result = JSON.parse(regexp_result)
      VAR_ALL_MATCH = regexp_result.pop()
      if(typeof(VAR_ALL_MATCH) == 'undefined' || !VAR_ALL_MATCH)
      VAR_ALL_MATCH = ""
      VAR_LIST_WITH_GROUPS = regexp_result
      VAR_KEY = regexp_result[0]
      if(typeof(VAR_KEY) == 'undefined' || !VAR_KEY)
      VAR_KEY = ""
      if(regexp_result.length == 0)
      {
      VAR_KEY = VAR_ALL_MATCH
      }
      if(VAR_ALL_MATCH != "" && Array.isArray(VAR_ALL_MATCH))
      VAR_LIST_WITH_GROUPS.unshift(VAR_ALL_MATCH)
      

      
      
      VAR_TYPE_SWIPE = _function_argument("type_swipe")
      

      
      
      _call(function()
      {
      _on_fail(function(){
      VAR_LAST_ERROR = _result()
      VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
      VAR_WAS_ERROR = false
      _break(1,true)
      })
      CYCLES.Current().RemoveLabel("function")
      
         
         
         /*Browser*/
         waiter_timeout_next(5000)
         wait_async_load()!
         

      },null)!
      

      
      
      /*Browser*/
      ;_SELECTOR=VAR_IMAGE_ID + "\u003eAT\u003e" + VAR_CAPTCHA_ID;
      get_element_selector(_SELECTOR, false).nowait().exist()!
      VAR_IS_EXISTS = _result() == 1
      _if(VAR_IS_EXISTS, function(){
      get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
      VAR_IS_EXISTS = _result().indexOf("true")>=0
      })!
      

      
      
      _do(function(){
      _set_action_info({ name: "While" });
      VAR_CYCLE_INDEX = _iterator() - 1
      BREAK_CONDITION = VAR_IS_EXISTS == false;
      if(!BREAK_CONDITION)_break();
      
         
         
         _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gNQ==");
         _if(VAR_CYCLE_INDEX > 5,function(){
         
            
            
            fail((_K==="en" ? "Captcha not found, reload the page" : "Капча не найдена, перезагрузите страницу"));
            

         })!
         

         
         
         _set_if_expression("W1tCVVRUT05fSURdXSAhPSAiTk9ORSI=");
         _if(VAR_BUTTON_ID != "NONE",function(){
         
            
            
            /*Browser*/
            ;_SELECTOR=VAR_BUTTON_ID;
            get_element_selector(_SELECTOR, false).nowait().exist()!
            VAR_IS_EXISTS = _result() == 1
            _if(VAR_IS_EXISTS, function(){
            get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
            VAR_IS_EXISTS = _result().indexOf("true")>=0
            })!
            

            
            
            _cycle_params().if_else = VAR_IS_EXISTS == false;
            _set_if_expression("W1tJU19FWElTVFNdXSA9PSBmYWxzZQ==");
            _if(_cycle_params().if_else,function(){
            
               
               
               fail((_K==="en" ? "Captcha not found, reload the page" : "Капча не найдена, перезагрузите страницу"));
               

            })!
            

            
            
            _if(!_cycle_params().if_else,function(){
            
               
               
               /*Browser*/
               _SELECTOR = VAR_BUTTON_ID;
               wait_element_visible(_SELECTOR)!
               _call(_random_point, {})!
               _if(_result().length > 0, function(){
               move( {} )!
               get_element_selector(_SELECTOR, false).clarify(X,Y)!
               _call(_clarify, {} )!
               mouse(X,Y)!
               })!
               

               
               
               _call(function()
               {
               _on_fail(function(){
               VAR_LAST_ERROR = _result()
               VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
               VAR_WAS_ERROR = false
               _break(1,true)
               })
               CYCLES.Current().RemoveLabel("function")
               
                  
                  
                  /*Browser*/
                  IDDLE_EMULATION_END = Date.now() + 1000 * (4)
                  IDDLE_EMULATION_DISTRIBUTION = [2,3,3,3,4,4]
                  _get_browser_screen_settings()!
                  IDDLE_EMULATION_RESULT = JSON.parse(_result())
                  IDDLE_CURSOR_POSITION_X = IDDLE_EMULATION_RESULT["CursorX"]
                  IDDLE_CURSOR_POSITION_Y = IDDLE_EMULATION_RESULT["CursorY"]
                  IDDLE_CURSOR_POSITION_WIDTH = IDDLE_EMULATION_RESULT["Width"]
                  IDDLE_CURSOR_POSITION_HEIGHT = IDDLE_EMULATION_RESULT["Height"]
                  IDDLE_CURSOR_POSITION_WAS_SCROLL = false
                  _do(function(){
                  if(Date.now() >= IDDLE_EMULATION_END)
                  _break()
                  IDDLE_EMULATION_CURRENT_ITEM = IDDLE_EMULATION_DISTRIBUTION[Math.floor(Math.random()*IDDLE_EMULATION_DISTRIBUTION.length)]
                  if(_iterator() == 1 && IDDLE_EMULATION_DISTRIBUTION.indexOf(2)>=0)
                  IDDLE_EMULATION_CURRENT_ITEM = 2
                  _if(IDDLE_EMULATION_CURRENT_ITEM == 1, function(){
                  //scroll
                  IDDLE_EMULATION_CURRENT_DIRECTION = (rand(1,2) == 2) ? "<MOUSESCROLLUP>" : "<MOUSESCROLLDOWN>"
                  if(!IDDLE_CURSOR_POSITION_WAS_SCROLL)
                  IDDLE_EMULATION_CURRENT_DIRECTION = "<MOUSESCROLLDOWN>"
                  IDDLE_CURSOR_POSITION_WAS_SCROLL = true
                  IDDLE_EMULATION_CURRENT_NUMBER = rand(1,5)
                  _do(function(){
                  if(_iterator() >= IDDLE_EMULATION_CURRENT_NUMBER)
                  _break()
                  _type(IDDLE_EMULATION_CURRENT_DIRECTION,1000)!
                  sleep(rand(300,1000))!
                  })!
                  })!
                  _if(IDDLE_EMULATION_CURRENT_ITEM == 2, function(){
                  //long move
                  page().script("document.documentElement.scrollLeft")!
                  IDDLE_CURSOR_POSITION_SCROLL_X = parseInt(_result())
                  page().script("document.documentElement.scrollTop")!
                  IDDLE_CURSOR_POSITION_SCROLL_Y = parseInt(_result())
                  IDDLE_CURSOR_POSITION_X = rand(1,IDDLE_CURSOR_POSITION_WIDTH)
                  IDDLE_CURSOR_POSITION_Y = rand(1,IDDLE_CURSOR_POSITION_HEIGHT)
                  move(IDDLE_CURSOR_POSITION_SCROLL_X + IDDLE_CURSOR_POSITION_X,IDDLE_CURSOR_POSITION_SCROLL_Y + IDDLE_CURSOR_POSITION_Y)!
                  })!
                  _if(IDDLE_EMULATION_CURRENT_ITEM == 3, function(){
                  //short move
                  if(IDDLE_CURSOR_POSITION_X < 0 || IDDLE_CURSOR_POSITION_Y < 0)
                  _break()
                  page().script("document.documentElement.scrollLeft")!
                  IDDLE_CURSOR_POSITION_SCROLL_X = parseInt(_result())
                  page().script("document.documentElement.scrollTop")!
                  IDDLE_CURSOR_POSITION_SCROLL_Y = parseInt(_result())
                  IDDLE_EMULATION_CURRENT_NUMBER = rand(1,4)
                  _do(function(){
                  if(_iterator() >= IDDLE_EMULATION_CURRENT_NUMBER)
                  _break()
                  IDDLE_CURSOR_POSITION_X += rand(-50,50)
                  IDDLE_CURSOR_POSITION_Y += rand(-50,50)
                  if(IDDLE_CURSOR_POSITION_X > IDDLE_CURSOR_POSITION_WIDTH)
                  IDDLE_CURSOR_POSITION_X = IDDLE_CURSOR_POSITION_WIDTH
                  if(IDDLE_CURSOR_POSITION_Y > IDDLE_CURSOR_POSITION_HEIGHT)
                  IDDLE_CURSOR_POSITION_Y = IDDLE_CURSOR_POSITION_HEIGHT
                  if(IDDLE_CURSOR_POSITION_X < 0)
                  IDDLE_CURSOR_POSITION_X = 0
                  if(IDDLE_CURSOR_POSITION_Y < 0)
                  IDDLE_CURSOR_POSITION_Y = 0
                  move(IDDLE_CURSOR_POSITION_SCROLL_X + IDDLE_CURSOR_POSITION_X,IDDLE_CURSOR_POSITION_SCROLL_Y + IDDLE_CURSOR_POSITION_Y)!
                  _if(rand(1,10) > 3,function(){
                  sleep(rand(10,300))!
                  })!
                  })!
                  })!
                  _if(IDDLE_EMULATION_CURRENT_ITEM == 4, function(){
                  //sleep
                  sleep(rand(500,5000))!
                  })!
                  })!
                  

               },null)!
               

            })!
            delete _cycle_params().if_else;
            

         })!
         

         
         
         /*Browser*/
         ;_SELECTOR=VAR_IMAGE_ID;
         get_element_selector(_SELECTOR, true).length()!
         VAR_ELEMENT_LENGTH = _result()
         

         
         
         _cycle_params().if_else = VAR_ELEMENT_LENGTH > 1;
         _set_if_expression("W1tFTEVNRU5UX0xFTkdUSF1dID4gMQ==");
         _if(_cycle_params().if_else,function(){
         
            
            
            _do(function(){
            _set_action_info({ name: "For" });
            VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(0)
            if(VAR_CYCLE_INDEX > parseInt(VAR_ELEMENT_LENGTH - 1))_break();
            
               
               
               /*Browser*/
               ;_SELECTOR=VAR_IMAGE_ID + "\u003eAT\u003e" + VAR_CYCLE_INDEX;
               get_element_selector(_SELECTOR, false).nowait().exist()!
               VAR_IS_EXISTS = _result() == 1
               _if(VAR_IS_EXISTS, function(){
               get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
               VAR_IS_EXISTS = _result().indexOf("true")>=0
               })!
               

               
               
               _set_if_expression("W1tJU19FWElTVFNdXQ==");
               _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
               
                  
                  
                  VAR_CAPTCHA_ID = VAR_CYCLE_INDEX
                  

                  
                  
                  _break("function")
                  

               })!
               

            })!
            

         })!
         

         
         
         _if(!_cycle_params().if_else,function(){
         
            
            
            /*Browser*/
            ;_SELECTOR=VAR_IMAGE_ID + "\u003eAT\u003e" + VAR_CAPTCHA_ID;
            get_element_selector(_SELECTOR, false).nowait().exist()!
            VAR_IS_EXISTS = _result() == 1
            _if(VAR_IS_EXISTS, function(){
            get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
            VAR_IS_EXISTS = _result().indexOf("true")>=0
            })!
            

         })!
         delete _cycle_params().if_else;
         

      })!
      

      
      
      /*Browser*/
      ;_SELECTOR=VAR_IMAGE_ID + "\u003eAT\u003e" + VAR_CAPTCHA_ID;
      get_element_selector(_SELECTOR, false).nowait().exist()!
      VAR_IS_EXISTS = _result() == 1
      _if(VAR_IS_EXISTS, function(){
      get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
      VAR_IS_EXISTS = _result().indexOf("true")>=0
      })!
      

      
      
      _do(function(){
      _set_action_info({ name: "While" });
      VAR_CYCLE_INDEX = _iterator() - 1
      BREAK_CONDITION = VAR_IS_EXISTS;
      if(!BREAK_CONDITION)_break();
      
         
         
         _set_if_expression("W1tDWUNMRV9JTkRFWF1dID49IFtbQVRURU1QVFNdXQ==");
         _if(VAR_CYCLE_INDEX >= VAR_ATTEMPTS,function(){
         
            
            
            fail((_K==="en" ? "The captcha has not been solved in 10 tries" : "Капча не решена за 10 попыток"));
            

         })!
         

         
         
         /*Browser*/
         _SELECTOR = VAR_IMAGE_ID + "\u003eAT\u003e" + VAR_CAPTCHA_ID;
         wait_element(_SELECTOR)!
         get_element_selector(_SELECTOR, false).exist()!
         _if(_result() == "1", function(){
         get_element_selector(_SELECTOR, false).render_base64()!
         VAR_SCREENSHOT_BASE64 = _result()
         })!
         

         
         
         VAR_STRING_LENGTH = VAR_SCREENSHOT_BASE64.length
         

         
         
         _set_if_expression("W1tTVFJJTkdfTEVOR1RIXV0gPCAxMDAwICYmIFtbQ1lDTEVfSU5ERVhdXSA9PSAw");
         _if(VAR_STRING_LENGTH < 1000 && VAR_CYCLE_INDEX == 0,function(){
         
            
            
            fail((_K==="en" ? "The image is too small, you obviously set the wrong image ID" : "Слишком маленькая картинка, вы явно задали не тот идентификатор изображения"));
            

         })!
         

         
         
         _set_if_expression("W1tTVFJJTkdfTEVOR1RIXV0gPCAxMDAwICYmIFtbQ1lDTEVfSU5ERVhdXSAhPSAw");
         _if(VAR_STRING_LENGTH < 1000 && VAR_CYCLE_INDEX != 0,function(){
         
            
            
            _function_return("good")
            

         })!
         

         
         
         _do(function(){
         _set_action_info({ name: "For" });
         VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
         if(VAR_CYCLE_INDEX > parseInt(3))_break();
         
            
            
            _set_if_expression("W1tDWUNMRV9JTkRFWF1dID49IDM=");
            _if(VAR_CYCLE_INDEX >= 3,function(){
            
               
               
               fail_user(VAR_LAST_ERROR,false)
               

            })!
            

            
            
            _call(function()
            {
            _on_fail(function(){
            VAR_LAST_ERROR = _result()
            VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
            VAR_WAS_ERROR = false
            _break(1,true)
            })
            CYCLES.Current().RemoveLabel("function")
            
               
               
               _cycle_params().if_else = VAR_SLIDER_TYPE == 2;
               _set_if_expression("W1tTTElERVJfVFlQRV1dID09IDI=");
               _if(_cycle_params().if_else,function(){
               
                  
                  
                  _switch_http_client_main()
                  http_client_post("http://sctg.xyz/in.php", ["method","slidermany","key",VAR_KEY,"body",VAR_SCREENSHOT_BASE64], {"content-type":("multipart"), "encoding":("UTF-8"), "method":("POST"),headers:("")})!
                  

               })!
               

               
               
               _if(!_cycle_params().if_else,function(){
               
                  
                  
                  _switch_http_client_main()
                  http_client_post("http://sctg.xyz/in.php", ["method","geetest","key",VAR_KEY,"body",VAR_SCREENSHOT_BASE64], {"content-type":("multipart"), "encoding":("UTF-8"), "method":("POST"),headers:("")})!
                  

               })!
               delete _cycle_params().if_else;
               

               
               
               _switch_http_client_main()
               VAR_SAVED_CONTENT = http_client_encoded_content("utf-8")
               

               
               
               _break("function")
               

            },null)!
            

         })!
         

         
         
         VAR_STRING_CONTAINS = Boolean(native("regexp", "ismatch", JSON.stringify({text: VAR_SAVED_CONTENT,regexp:("(\u005c|)").toString()})) == "true")
         

         
         
         _set_if_expression("W1tTVFJJTkdfQ09OVEFJTlNdXSA9PSBmYWxzZQ==");
         _if(VAR_STRING_CONTAINS == false,function(){
         
            
            
            fail_user(VAR_SAVED_CONTENT,false)
            

         })!
         

         
         
         sleep(1000)!
         

         
         
         VAR_ID = VAR_SAVED_CONTENT.split("|")[1]
         

         
         
         _do(function(){
         _set_action_info({ name: "For" });
         VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
         if(VAR_CYCLE_INDEX > parseInt(3))_break();
         
            
            
            _set_if_expression("W1tDWUNMRV9JTkRFWF1dID49IDM=");
            _if(VAR_CYCLE_INDEX >= 3,function(){
            
               
               
               fail_user(VAR_LAST_ERROR,false)
               

            })!
            

            
            
            _call(function()
            {
            _on_fail(function(){
            VAR_LAST_ERROR = _result()
            VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
            VAR_WAS_ERROR = false
            _break(1,true)
            })
            CYCLES.Current().RemoveLabel("function")
            
               
               
               _switch_http_client_main()
               http_client_get2("http://sctg.xyz/res.php?key=" + VAR_KEY + "\u0026id=" + VAR_ID,{method:("GET"),headers:("")})!
               

               
               
               _switch_http_client_main()
               VAR_SAVED_CONTENT = http_client_encoded_content("utf-8")
               

               
               
               _do(function(){
               _set_action_info({ name: "While" });
               VAR_CYCLE_INDEX = _iterator() - 1
               BREAK_CONDITION = VAR_SAVED_CONTENT == "CAPCHA_NOT_READY";
               if(!BREAK_CONDITION)_break();
               
                  
                  
                  sleep(1000)!
                  

                  
                  
                  _switch_http_client_main()
                  http_client_get2("http://sctg.xyz/res.php?key=" + VAR_KEY + "\u0026id=" + VAR_ID,{method:("GET"),headers:("")})!
                  

                  
                  
                  _switch_http_client_main()
                  VAR_SAVED_CONTENT = http_client_encoded_content("utf-8")
                  

               })!
               

               
               
               _break("function")
               

            },null)!
            

         })!
         

         
         
         VAR_STRING_CONTAINS = Boolean(native("regexp", "ismatch", JSON.stringify({text: VAR_SAVED_CONTENT,regexp:("(\u005c|)").toString()})) == "true")
         

         
         
         _set_if_expression("W1tTVFJJTkdfQ09OVEFJTlNdXSA9PSBmYWxzZQ==");
         _if(VAR_STRING_CONTAINS == false,function(){
         
            
            
            /*Browser*/
            _SELECTOR = VAR_RELOAD_ID + "\u003eAT\u003e" + VAR_CAPTCHA_ID;waiter_timeout_next(1000)
            waiter_nofail_next();
            wait_element_visible(_SELECTOR)!
            _call(_random_point, {})!
            _if(_result().length > 0, function(){
            move( {} )!
            get_element_selector(_SELECTOR, false).nowait().clarify(X,Y)!
            _call(_clarify, {} )!
            mouse(X,Y)!
            })!
            

            
            
            _call(function()
            {
            _on_fail(function(){
            VAR_LAST_ERROR = _result()
            VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
            VAR_WAS_ERROR = false
            _break(1,true)
            })
            CYCLES.Current().RemoveLabel("function")
            
               
               
               /*Browser*/
               waiter_timeout_next(15000)
               wait_async_load()!
               

            },null)!
            

            
            
            _next("function")
            

         })!
         

         
         
         VAR_SCAN_RESULT_LIST = native("regexp", "scan", JSON.stringify({text: VAR_SAVED_CONTENT,regexp:("\u005cd+").toString()}))
         if(VAR_SCAN_RESULT_LIST.length == 0)
         VAR_SCAN_RESULT_LIST = []
         else
         VAR_SCAN_RESULT_LIST = JSON.parse(VAR_SCAN_RESULT_LIST)
         

         
         
         VAR_LIST_LENGTH = (VAR_SCAN_RESULT_LIST).length
         

         
         
         _set_if_expression("W1tMSVNUX0xFTkdUSF1dICE9IDM=");
         _if(VAR_LIST_LENGTH != 3,function(){
         
            
            
            fail((_K==="en" ? "Unclear response from the server" : "Не понятный ответ от сервера"));
            

         })!
         

         
         
         VAR_X_XEVIL = (parseInt(VAR_SCAN_RESULT_LIST[0]) * VAR_COEF) + VAR_PIXEL_KOEF;
         VAR_Y_XEVIL = parseInt(VAR_SCAN_RESULT_LIST[1]);
         VAR_W_XEVIL = parseInt(VAR_SCAN_RESULT_LIST[2]);
         

         
         
         /*Browser*/
         scroll(1,1)!
         

         
         
         /*Browser*/
         _SELECTOR = VAR_ARROW_ID + "\u003eAT\u003e" + VAR_CAPTCHA_ID;
         wait_element(_SELECTOR)!
         get_element_selector(_SELECTOR, false).script("(function(){var rect = _BAS_HIDE(BrowserAutomationStudio_GetBoundingClientRect)(self);return (rect.left + positionx) + '|' + (rect.top + positiony) + '|' + (rect.right - rect.left) + '|' + (rect.bottom - rect.top) + '|' + (rect.left + positionx + scrollx) + '|' + (rect.top + positiony + scrolly)})();")!
         if(_result().length > 0)
         {
         var split = _result().split("|")
         VAR_X = parseInt(split[0])
         VAR_Y = parseInt(split[1])
         VAR_WIDTH = parseInt(split[2])
         VAR_HEIGHT = parseInt(split[3])
         VAR_ABSOLUTE_X = parseInt(split[4])
         VAR_ABSOLUTE_Y = parseInt(split[5])
         }
         

         
         
         _cycle_params().if_else = VAR_TYPE_SLIDE == true;
         _set_if_expression("W1tUWVBFX1NMSURFXV0gPT0gdHJ1ZQ==");
         _if(_cycle_params().if_else,function(){
         
            
            
            /*Browser*/
            move(VAR_X + (VAR_WIDTH/2),VAR_Y + (VAR_HEIGHT/2),  {"speed": 100*VAR_SPEED,"gravity": 6,"deviation": 2.5} )!
            mouse_down(VAR_X + (VAR_WIDTH/2),VAR_Y + (VAR_HEIGHT/2))!
            

         })!
         

         
         
         _if(!_cycle_params().if_else,function(){
         
            
            
            /*Browser*/
            _SELECTOR = VAR_ARROW_ID + "\u003eAT\u003e" + VAR_CAPTCHA_ID;
            wait_element_visible(_SELECTOR)!
            _call(_random_point, {})!
            _if(_result().length > 0, function(){
            move( {} )!
            get_element_selector(_SELECTOR, false).clarify(X,Y)!
            _call(_clarify, {} )!
            mouse_down(X,Y)!
            })!
            

         })!
         delete _cycle_params().if_else;
         

         
         
         _set_if_expression("W1tUWVBFX1NXSVBFXV0gPT0gMQ==");
         _if(VAR_TYPE_SWIPE == 1,function(){
         
            
            
            VAR_RANDOM_SPEED = Math.floor(Math.random() * (parseInt(200) - parseInt(100) + 1)) + parseInt(100)
            

            
            
            VAR_RANDOM_PR = Math.floor(Math.random() * (parseInt(9) - parseInt(5) + 1)) + parseInt(5)
            

            
            
            /*Browser*/
            move(VAR_X+ (VAR_X_XEVIL/1.2),VAR_Y,  {"speed": VAR_RANDOM_SPEED*VAR_SPEED,"gravity": VAR_RANDOM_PR,"deviation": 4} )!
            

            
            
            VAR_RANDOM_SPEED = Math.floor(Math.random() * (parseInt(60) - parseInt(10) + 1)) + parseInt(10)
            

            
            
            VAR_RANDOM_PR = Math.floor(Math.random() * (parseInt(10) - parseInt(7) + 1)) + parseInt(7)
            

            
            
            /*Browser*/
            move(VAR_X+VAR_X_XEVIL + VAR_W_XEVIL/2,VAR_Y,  {"speed": VAR_RANDOM_SPEED*VAR_SPEED,"gravity": VAR_RANDOM_PR,"deviation": 0} )!
            

            
            
            VAR_RANDOM_Y = Math.floor(Math.random() * (parseInt(15) - parseInt(-15) + 1)) + parseInt(-15)
            

            
            
            /*Browser*/
            var move_settings =  {"speed": 50*VAR_SPEED,"gravity": 9,"deviation": 0} ;
            move_settings["do_mouse_up"] = "true"
            move(VAR_X+VAR_X_XEVIL + VAR_W_XEVIL/2,VAR_Y + VAR_RANDOM_Y, move_settings)!
            

         })!
         

         
         
         _set_if_expression("W1tUWVBFX1NXSVBFXV0gPT0gMg==");
         _if(VAR_TYPE_SWIPE == 2,function(){
         
            
            
            VAR_RANDOM_SPEED = Math.floor(Math.random() * (parseInt(40) - parseInt(20) + 1)) + parseInt(20)
            

            
            
            VAR_RANDOM_PR = Math.floor(Math.random() * (parseInt(4) - parseInt(3) + 1)) + parseInt(3)
            

            
            
            VAR_RANDOM_RT = Math.floor(Math.random() * (parseInt(2) - parseInt(1) + 1)) + parseInt(1)
            

            
            
            VAR_RANDOM_Y = Math.floor(Math.random() * (parseInt(5) - parseInt(-5) + 1)) + parseInt(-5)
            

            
            
            /*Browser*/
            var move_settings =  {"speed": VAR_RANDOM_SPEED*VAR_SPEED,"gravity": VAR_RANDOM_PR,"deviation": VAR_RANDOM_RT} ;
            move_settings["do_mouse_up"] = "true"
            move(VAR_WIDTH/2 + VAR_X+VAR_X_XEVIL + VAR_W_XEVIL/2,VAR_Y + VAR_RANDOM_Y, move_settings)!
            

         })!
         

         
         
         _set_if_expression("W1tUWVBFX1NXSVBFXV0gPT0gMw==");
         _if(VAR_TYPE_SWIPE == 3,function(){
         
            
            
            VAR_RANDOM_SPEED = Math.floor(Math.random() * (parseInt(200) - parseInt(150) + 1)) + parseInt(150)
            

            
            
            VAR_RANDOM_PR = Math.floor(Math.random() * (parseInt(4) - parseInt(3) + 1)) + parseInt(3)
            

            
            
            VAR_RANDOM_RT = Math.floor(Math.random() * (parseInt(3) - parseInt(2) + 1)) + parseInt(2)
            

            
            
            VAR_RANDOM_Y = Math.floor(Math.random() * (parseInt(5) - parseInt(-5) + 1)) + parseInt(-5)
            

            
            
            /*Browser*/
            var move_settings =  {"speed": VAR_RANDOM_SPEED*VAR_SPEED,"gravity": VAR_RANDOM_PR,"deviation": VAR_RANDOM_RT} ;
            move_settings["do_mouse_up"] = "true"
            move(VAR_WIDTH/2 + VAR_X+VAR_X_XEVIL + VAR_W_XEVIL/2,VAR_Y + VAR_RANDOM_Y, move_settings)!
            

         })!
         

         
         
         _set_if_expression("W1tUWVBFX1NXSVBFXV0gPT0gNA==");
         _if(VAR_TYPE_SWIPE == 4,function(){
         
            
            
            VAR_RANDOM_SPEED = Math.floor(Math.random() * (parseInt(200) - parseInt(150) + 1)) + parseInt(150)
            

            
            
            VAR_RANDOM_PR = Math.floor(Math.random() * (parseInt(9) - parseInt(7) + 1)) + parseInt(7)
            

            
            
            VAR_RANDOM_RT = Math.floor(Math.random() * (parseInt(1) - parseInt(0) + 1)) + parseInt(0)
            

            
            
            VAR_RANDOM_Y = Math.floor(Math.random() * (parseInt(5) - parseInt(-5) + 1)) + parseInt(-5)
            

            
            
            /*Browser*/
            var move_settings =  {"speed": VAR_RANDOM_SPEED*VAR_SPEED,"gravity": VAR_RANDOM_PR,"deviation": VAR_RANDOM_RT} ;
            move_settings["do_mouse_up"] = "true"
            move(VAR_WIDTH/2 + VAR_X+VAR_X_XEVIL + VAR_W_XEVIL/2,VAR_Y + VAR_RANDOM_Y, move_settings)!
            

         })!
         

         
         
         _call(function()
         {
         _on_fail(function(){
         VAR_LAST_ERROR = _result()
         VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
         VAR_WAS_ERROR = false
         _break(1,true)
         })
         CYCLES.Current().RemoveLabel("function")
         
            
            
            /*Browser*/
            waiter_timeout_next(5000)
            wait_async_load()!
            

         },null)!
         

         
         
         /*Browser*/
         ;_SELECTOR=VAR_IMAGE_ID + "\u003eAT\u003e" + VAR_CAPTCHA_ID;
         get_element_selector(_SELECTOR, false).nowait().exist()!
         VAR_IS_EXISTS = _result() == 1
         _if(VAR_IS_EXISTS, function(){
         get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
         VAR_IS_EXISTS = _result().indexOf("true")>=0
         })!
         

         
         
         /*Browser*/
         ;_SELECTOR=VAR_ARROW_ID + "\u003eAT\u003e" + VAR_CAPTCHA_ID;
         get_element_selector(_SELECTOR, false).nowait().exist()!
         VAR_IS_EXISTS2 = _result() == 1
         _if(VAR_IS_EXISTS2, function(){
         get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
         VAR_IS_EXISTS2 = _result().indexOf("true")>=0
         })!
         

         
         
         /*Browser*/
         ;_SELECTOR=VAR_RELOAD_ID + "\u003eAT\u003e" + VAR_CAPTCHA_ID;
         get_element_selector(_SELECTOR, false).nowait().exist()!
         VAR_IS_EXISTS3 = _result() == 1
         _if(VAR_IS_EXISTS3, function(){
         get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
         VAR_IS_EXISTS3 = _result().indexOf("true")>=0
         })!
         

         
         
         _set_if_expression("W1tBVlRPVVBEQVRFXV0gPT0gZmFsc2U=");
         _if(VAR_AVTOUPDATE == false,function(){
         
            
            
            _set_if_expression("W1tJU19FWElTVFNdXSAmJiBbW0lTX0VYSVNUUzJdXSAmJiBbW0lTX0VYSVNUUzNdXQ==");
            _if(VAR_IS_EXISTS && VAR_IS_EXISTS2 && VAR_IS_EXISTS3,function(){
            
               
               
               /*Browser*/
               _SELECTOR = VAR_RELOAD_ID + "\u003eAT\u003e" + VAR_CAPTCHA_ID;waiter_timeout_next(1000)
               waiter_nofail_next();
               wait_element_visible(_SELECTOR)!
               _call(_random_point, {})!
               _if(_result().length > 0, function(){
               move( {} )!
               get_element_selector(_SELECTOR, false).nowait().clarify(X,Y)!
               _call(_clarify, {} )!
               mouse(X,Y)!
               })!
               

               
               
               _call(function()
               {
               _on_fail(function(){
               VAR_LAST_ERROR = _result()
               VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
               VAR_WAS_ERROR = false
               _break(1,true)
               })
               CYCLES.Current().RemoveLabel("function")
               
                  
                  
                  /*Browser*/
                  waiter_timeout_next(15000)
                  wait_async_load()!
                  

               },null)!
               

            })!
            

         })!
         

      })!
      

   }
   

function GoodXevilPaySolver_GXP_SolverGeetestIcon()
   {
   
      
      
      VAR_PIXEL_COEF = _function_argument("pixel_coef")
      

      
      
      VAR_FOTO_CAPTCHA = _function_argument("foto_captcha")
      

      
      
      VAR_RELOAD_CAPTCHA = _function_argument("reload_captcha")
      

      
      
      VAR_APIKEY = _function_argument("apikey")
      

      
      
      VAR_CAPTCHA_SUBMIT = _function_argument("captcha_submit")
      

      
      
      VAR_TYPE_DATA = _function_argument("type_data")
      

      
      
      VAR_ARAB_FIX = _function_argument("arab_fix")
      

      
      
      _cycle_params().if_else = VAR_TYPE_DATA == 0;
      _set_if_expression("W1tUWVBFX0RBVEFdXSA9PSAw");
      _if(_cycle_params().if_else,function(){
      
         
         
         VAR_TYPEAISOLVER = "geetest_icon"
         

      })!
      

      
      
      _if(!_cycle_params().if_else,function(){
      
         
         
         VAR_TYPEAISOLVER = "geetesticonhard"
         

      })!
      delete _cycle_params().if_else;
      

      
      
      VAR_CAPTCHA_ID = 0
      

      
      
      var regexp_result = native("regexp", "first", JSON.stringify({text: VAR_APIKEY,regexp:("([A-Za-z0-9]+)").toString()}))
      if(regexp_result.length == 0)
      regexp_result = []
      else
      regexp_result = JSON.parse(regexp_result)
      VAR_ALL_MATCH = regexp_result.pop()
      if(typeof(VAR_ALL_MATCH) == 'undefined' || !VAR_ALL_MATCH)
      VAR_ALL_MATCH = ""
      VAR_LIST_WITH_GROUPS = regexp_result
      VAR_APIKEY = regexp_result[0]
      if(typeof(VAR_APIKEY) == 'undefined' || !VAR_APIKEY)
      VAR_APIKEY = ""
      if(regexp_result.length == 0)
      {
      VAR_APIKEY = VAR_ALL_MATCH
      }
      if(VAR_ALL_MATCH != "" && Array.isArray(VAR_ALL_MATCH))
      VAR_LIST_WITH_GROUPS.unshift(VAR_ALL_MATCH)
      

      
      
      _set_if_expression("W1tBUElLRVldXSA9PSAiIg==");
      _if(VAR_APIKEY == "",function(){
      
         
         
         fail((_K==="en" ? "Bad API key" : "Не верный API ключ"));
         

      })!
      

      
      
      VAR_TRY_SOLVE = 0
      

      
      
      VAR_CAPTCHA_FIND = false
      

      
      
      _do(function(){
      _set_action_info({ name: "While" });
      VAR_CYCLE_INDEX = _iterator() - 1
      BREAK_CONDITION = true;
      if(!BREAK_CONDITION)_break();
      
         
         
         _set_if_expression("W1tUUllfU09MVkVdXSA+PSAxMA==");
         _if(VAR_TRY_SOLVE >= 10,function(){
         
            
            
            fail((_K==="en" ? "Fail solve captcha" : "Ошибка при решении капчи"));
            

         })!
         

         
         
         VAR_FIND_FOTO = 0
         

         
         
         _do(function(){
         _set_action_info({ name: "While" });
         VAR_CYCLE_INDEX = _iterator() - 1
         BREAK_CONDITION = true;
         if(!BREAK_CONDITION)_break();
         
            
            
            _set_if_expression("W1tDQVBUQ0hBX0ZJTkRdXSA9PSBmYWxzZQ==");
            _if(VAR_CAPTCHA_FIND == false,function(){
            
               
               
               _do(function(){
               _set_action_info({ name: "For" });
               VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(0)
               if(VAR_CYCLE_INDEX > parseInt(10))_break();
               
                  
                  
                  VAR_CAPTCHA_ID = VAR_CYCLE_INDEX
                  

                  
                  
                  /*Browser*/
                  ;_SELECTOR=VAR_RELOAD_CAPTCHA + "\u003eAT\u003e" + VAR_CAPTCHA_ID;
                  get_element_selector(_SELECTOR, false).nowait().exist()!
                  VAR_IS_EXISTS = _result() == 1
                  _if(VAR_IS_EXISTS, function(){
                  get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
                  VAR_IS_EXISTS = _result().indexOf("true")>=0
                  })!
                  

                  
                  
                  _set_if_expression("W1tJU19FWElTVFNdXQ==");
                  _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
                  
                     
                     
                     VAR_CAPTCHA_FIND = true
                     

                     
                     
                     _break("function")
                     

                  })!
                  

               })!
               

            })!
            

            
            
            _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gNQ==");
            _if(VAR_CYCLE_INDEX > 5,function(){
            
               
               
               VAR_FIND_FOTO = 0
               

               
               
               VAR_TRY_SOLVE = parseInt(VAR_TRY_SOLVE) + parseInt(1)
               

               
               
               _break("function")
               

            })!
            

            
            
            _set_if_expression("W1tUUllfU09MVkVdXSAhPSAw");
            _if(VAR_TRY_SOLVE != 0,function(){
            
               
               
               _do(function(){
               _set_action_info({ name: "While" });
               VAR_CYCLE_INDEX = _iterator() - 1
               BREAK_CONDITION = true;
               if(!BREAK_CONDITION)_break();
               
                  
                  
                  sleep(500)!
                  

                  
                  
                  _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gNQ==");
                  _if(VAR_CYCLE_INDEX > 5,function(){
                  
                     
                     
                     _function_return("GoodSolver")
                     

                  })!
                  

                  
                  
                  /*Browser*/
                  ;_SELECTOR=VAR_RELOAD_CAPTCHA + "\u003eAT\u003e" + VAR_CAPTCHA_ID;
                  get_element_selector(_SELECTOR, false).nowait().exist()!
                  VAR_IS_EXISTS = _result() == 1
                  _if(VAR_IS_EXISTS, function(){
                  get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
                  VAR_IS_EXISTS = _result().indexOf("true")>=0
                  })!
                  

                  
                  
                  _set_if_expression("W1tJU19FWElTVFNdXQ==");
                  _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
                  
                     
                     
                     _break("function")
                     

                  })!
                  

               })!
               

            })!
            

         })!
         

         
         
         /*Browser*/
         _SELECTOR = VAR_FOTO_CAPTCHA + "\u003eAT\u003e" + VAR_CAPTCHA_ID;
         wait_element(_SELECTOR)!
         get_element_selector(_SELECTOR, false).exist()!
         _if(_result() == "1", function(){
         get_element_selector(_SELECTOR, false).render_base64()!
         VAR_SCREENSHOT_BASE64 = _result()
         })!
         

         
         
         _call(function()
         {
         _on_fail(function(){
         VAR_LAST_ERROR = _result()
         VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
         VAR_WAS_ERROR = false
         _break(1,true)
         })
         CYCLES.Current().RemoveLabel("function")
         
            
            
            solver_properties_clear("capmonster")
            solver_property("capmonster","serverurl","http://sctg.xyz")
            solver_property("capmonster","key",VAR_APIKEY)
            solver_property("capmonster","method",VAR_TYPEAISOLVER)
            solver_property("capmonster","body",VAR_SCREENSHOT_BASE64)
            solve_base64_no_fail("capmonster", "")!
            VAR_SAVED_CONTENT = _result();
            

         },null)!
         

         
         
         _set_if_expression("W1tXQVNfRVJST1JdXQ==");
         _if(typeof(VAR_WAS_ERROR) !== "undefined" ? (VAR_WAS_ERROR) : undefined,function(){
         
            
            
            /*Browser*/
            ;_SELECTOR=VAR_RELOAD_CAPTCHA + "\u003eAT\u003e" + VAR_CAPTCHA_ID;
            get_element_selector(_SELECTOR, false).nowait().exist()!
            VAR_IS_EXISTS = _result() == 1
            _if(VAR_IS_EXISTS, function(){
            get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
            VAR_IS_EXISTS = _result().indexOf("true")>=0
            })!
            

            
            
            _cycle_params().if_else = typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined;
            _set_if_expression("W1tJU19FWElTVFNdXQ==");
            _if(_cycle_params().if_else,function(){
            
               
               
               /*Browser*/
               _SELECTOR = VAR_RELOAD_CAPTCHA + "\u003eAT\u003e" + VAR_CAPTCHA_ID;
               wait_element_visible(_SELECTOR)!
               _call(_random_point, {})!
               _if(_result().length > 0, function(){
               move( {} )!
               get_element_selector(_SELECTOR, false).clarify(X,Y)!
               _call(_clarify, {} )!
               mouse(X,Y)!
               })!
               

            })!
            

            
            
            _if(!_cycle_params().if_else,function(){
            
               
               
               fail((_K==="en" ? "Fail solve captcha" : "Ошибка при решении капчи"));
               

            })!
            delete _cycle_params().if_else;
            

            
            
            VAR_TRY_SOLVE = parseInt(VAR_TRY_SOLVE) + parseInt(1)
            

            
            
            _next("function")
            

         })!
         

         
         
         VAR_STRING_MATCHES = Boolean(native("regexp", "ismatch", JSON.stringify({text: VAR_SAVED_CONTENT,regexp:("(_)").toString()})) == "true")
         

         
         
         _set_if_expression("W1tTVFJJTkdfTUFUQ0hFU11d");
         _if(typeof(VAR_STRING_MATCHES) !== "undefined" ? (VAR_STRING_MATCHES) : undefined,function(){
         
            
            
            /*Browser*/
            ;_SELECTOR=VAR_RELOAD_CAPTCHA + "\u003eAT\u003e" + VAR_CAPTCHA_ID;
            get_element_selector(_SELECTOR, false).nowait().exist()!
            VAR_IS_EXISTS = _result() == 1
            _if(VAR_IS_EXISTS, function(){
            get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
            VAR_IS_EXISTS = _result().indexOf("true")>=0
            })!
            

            
            
            _cycle_params().if_else = typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined;
            _set_if_expression("W1tJU19FWElTVFNdXQ==");
            _if(_cycle_params().if_else,function(){
            
               
               
               /*Browser*/
               _SELECTOR = VAR_RELOAD_CAPTCHA + "\u003eAT\u003e" + VAR_CAPTCHA_ID;
               wait_element_visible(_SELECTOR)!
               _call(_random_point, {})!
               _if(_result().length > 0, function(){
               move( {} )!
               get_element_selector(_SELECTOR, false).clarify(X,Y)!
               _call(_clarify, {} )!
               mouse(X,Y)!
               })!
               

            })!
            

            
            
            _if(!_cycle_params().if_else,function(){
            
               
               
               fail((_K==="en" ? "Fail solve captcha" : "Ошибка при решении капчи"));
               

            })!
            delete _cycle_params().if_else;
            

            
            
            VAR_TRY_SOLVE = parseInt(VAR_TRY_SOLVE) + parseInt(1)
            

            
            
            _next("function")
            

         })!
         

         
         
         VAR_DATA = VAR_SAVED_CONTENT.split(":")[1].replace(/x/g, "").replace(/=/g, "").replace(/y/g, "").replace(/y/g, "").split(";")
         

         
         
         /*Browser*/
         scroll(1,1)!
         

         
         
         /*Browser*/
         _SELECTOR = VAR_FOTO_CAPTCHA + "\u003eAT\u003e" + VAR_CAPTCHA_ID;
         wait_element(_SELECTOR)!
         get_element_selector(_SELECTOR, false).script("(function(){var rect = _BAS_HIDE(BrowserAutomationStudio_GetBoundingClientRect)(self);return (rect.left + positionx) + '|' + (rect.top + positiony) + '|' + (rect.right - rect.left) + '|' + (rect.bottom - rect.top) + '|' + (rect.left + positionx + scrollx) + '|' + (rect.top + positiony + scrolly)})();")!
         if(_result().length > 0)
         {
         var split = _result().split("|")
         VAR_X = parseInt(split[0])
         VAR_Y = parseInt(split[1])
         VAR_WIDTH = parseInt(split[2])
         VAR_HEIGHT = parseInt(split[3])
         VAR_ABSOLUTE_X = parseInt(split[4])
         VAR_ABSOLUTE_Y = parseInt(split[5])
         }
         

         
         
         _set_if_expression("W1tBUkFCX0ZJWF1dID09IDE=");
         _if(VAR_ARAB_FIX == 1,function(){
         
            
            
            VAR_DATA = VAR_DATA.reverse();
            

         })!
         

         
         
         _do_with_params({"foreach_data":(VAR_DATA)},function(){
         _set_action_info({ name: "Foreach" });
         VAR_CYCLE_INDEX = _iterator() - 1
         if(VAR_CYCLE_INDEX > _cycle_param("foreach_data").length - 1)_break();
         VAR_FOREACH_DATA = _cycle_param("foreach_data")[VAR_CYCLE_INDEX]
         
            
            
            VAR_X_TMP = parseInt(VAR_FOREACH_DATA.split(",")[0]);
            VAR_Y_TMP = parseInt(VAR_FOREACH_DATA.split(",")[1]);
            

            
            
            VAR_RANDOM_NUMBER = Math.floor(Math.random() * (parseInt(300) - parseInt(100) + 1)) + parseInt(100)
            

            
            
            sleep(VAR_RANDOM_NUMBER)!
            

            
            
            /*Browser*/
            move(VAR_X + VAR_X_TMP + VAR_PIXEL_COEF,VAR_Y + VAR_Y_TMP + VAR_PIXEL_COEF,  {} )!
            mouse(VAR_X + VAR_X_TMP + VAR_PIXEL_COEF,VAR_Y + VAR_Y_TMP + VAR_PIXEL_COEF)!
            

         })!
         

         
         
         /*Browser*/
         _SELECTOR = VAR_CAPTCHA_SUBMIT + "\u003eAT\u003e" + VAR_CAPTCHA_ID;
         wait_element_visible(_SELECTOR)!
         _call(_random_point, {})!
         _if(_result().length > 0, function(){
         move( {} )!
         get_element_selector(_SELECTOR, false).clarify(X,Y)!
         _call(_clarify, {} )!
         mouse(X,Y)!
         })!
         

         
         
         VAR_TRY_SOLVE = parseInt(VAR_TRY_SOLVE) + parseInt(1)
         

      })!
      

   }
   

function GoodXevilPaySolver_GXP_Antibot()
   {
   
      
      
      VAR_APIKEY = _function_argument("apikey")
      

      
      
      VAR_MOUSE = _function_argument("mouse")
      

      
      
      var regexp_result = native("regexp", "first", JSON.stringify({text: VAR_APIKEY,regexp:("([0-9A-Za-z\u005c|]\u007b20,50\u007d)").toString()}))
      if(regexp_result.length == 0)
      regexp_result = []
      else
      regexp_result = JSON.parse(regexp_result)
      VAR_ALL_MATCH = regexp_result.pop()
      if(typeof(VAR_ALL_MATCH) == 'undefined' || !VAR_ALL_MATCH)
      VAR_ALL_MATCH = ""
      VAR_LIST_WITH_GROUPS = regexp_result
      VAR_APIKEY = regexp_result[0]
      if(typeof(VAR_APIKEY) == 'undefined' || !VAR_APIKEY)
      VAR_APIKEY = ""
      if(regexp_result.length == 0)
      {
      VAR_APIKEY = VAR_ALL_MATCH
      }
      if(VAR_ALL_MATCH != "" && Array.isArray(VAR_ALL_MATCH))
      VAR_LIST_WITH_GROUPS.unshift(VAR_ALL_MATCH)
      

      
      
      _do(function(){
      _set_action_info({ name: "While" });
      VAR_CYCLE_INDEX = _iterator() - 1
      BREAK_CONDITION = true;
      if(!BREAK_CONDITION)_break();
      
         
         
         _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gMTU=");
         _if(VAR_CYCLE_INDEX > 15,function(){
         
            
            
            fail((_K==="en" ? "Didn't wait for antibot captcha" : "Не дождался antibot капчи"));
            

         })!
         

         
         
         /*Browser*/
         page().script("_BAS_HIDE(BrowserAutomationStudio_GetPageContent)()")!
         VAR_SAVED_PAGE_HTML = _result()
         

         
         
         html_parser_xpath_parse(VAR_SAVED_PAGE_HTML)
         VAR_XPATH_XML_LIST = html_parser_xpath_xml_list("//img[contains(@src, \u0027data:image/png;base64\u0027)]/..")
         

         
         
         VAR_XPATH_XML_LIST = (function(){var seen = {}; return (VAR_XPATH_XML_LIST).filter(function(item) { return seen.hasOwnProperty(item) ? false : (seen[item] = true); });})();
         

         
         
         _set_if_expression("W1tYUEFUSF9YTUxfTElTVF1dLmxlbmd0aCA+IDM=");
         _if(VAR_XPATH_XML_LIST.length > 3,function(){
         
            
            
            _break("function")
            

         })!
         

         
         
         html_parser_xpath_parse(VAR_SAVED_PAGE_HTML)
         VAR_XPATH_XML_LIST = html_parser_xpath_xml_list("//img[contains(@src, \u0027data:image/jpeg;base64\u0027)]/..")
         

         
         
         VAR_XPATH_XML_LIST = (function(){var seen = {}; return (VAR_XPATH_XML_LIST).filter(function(item) { return seen.hasOwnProperty(item) ? false : (seen[item] = true); });})();
         

         
         
         _set_if_expression("W1tYUEFUSF9YTUxfTElTVF1dLmxlbmd0aCA+IDM=");
         _if(VAR_XPATH_XML_LIST.length > 3,function(){
         
            
            
            _break("function")
            

         })!
         

         
         
         sleep(1000)!
         

      })!
      

      
      
      VAR_NORM_SOLVER = 2
      

      
      
      VAR_DATA_WORLD_IMG = {}
      

      
      
      VAR_MAIN_FOTO = ""
      

      
      
      VAR_MAIN_ID = 0
      

      
      
      VAR_REL_ID = 0
      

      
      
      VAR_REL_LIST = []
      

      
      
      _do_with_params({"foreach_data":(VAR_XPATH_XML_LIST)},function(){
      _set_action_info({ name: "Foreach" });
      VAR_CYCLE_INDEX = _iterator() - 1
      if(VAR_CYCLE_INDEX > _cycle_param("foreach_data").length - 1)_break();
      VAR_FOREACH_DATA = _cycle_param("foreach_data")[VAR_CYCLE_INDEX]
      
         
         
         _set_if_expression("W1tNQUlOX0lEXV0gPT0gMA==");
         _if(VAR_MAIN_ID == 0,function(){
         
            
            
            html_parser_xpath_parse(VAR_FOREACH_DATA)
            VAR_XPATH_EXISTS = html_parser_xpath_exist("//*[@id=\u0027antibotlinks_reset\u0027 and not(@rel)]")
            

            
            
            html_parser_xpath_parse(VAR_FOREACH_DATA)
            VAR_XPATH_EXISTS2 = html_parser_xpath_exist("//*[contains(@xmlns, \u0022www.w3.org\u0022) and not(@rel)]")
            

            
            
            html_parser_xpath_parse(VAR_FOREACH_DATA)
            VAR_XPATH_EXISTS3 = html_parser_xpath_exist("//center/img[not(@xmlns) and not(@rel)]")
            

            
            
            _set_if_expression("W1tYUEFUSF9FWElTVFNdXSB8fCBbW1hQQVRIX0VYSVNUUzJdXSB8fCBbW1hQQVRIX0VYSVNUUzNdXQ==");
            _if(VAR_XPATH_EXISTS || VAR_XPATH_EXISTS2 || VAR_XPATH_EXISTS3,function(){
            
               
               
               html_parser_xpath_parse(VAR_FOREACH_DATA)
               if((true) && !html_parser_xpath_exist("//@src"))
               fail("Can't resolve query " + "//@src");
               VAR_XPATH_XML = html_parser_xpath_xml("//@src")
               

               
               
               VAR_MAIN_FOTO = VAR_XPATH_XML.split("base64,")[1]
               

               
               
               VAR_MAIN_ID = 1
               

               
               
               _next("function")
               

            })!
            

         })!
         

         
         
         html_parser_xpath_parse(VAR_FOREACH_DATA)
         VAR_XPATH_EXISTS = html_parser_xpath_exist("//@rel")
         

         
         
         _cycle_params().if_else = VAR_XPATH_EXISTS && VAR_NORM_SOLVER != 0;
         _set_if_expression("W1tYUEFUSF9FWElTVFNdXSAmJiBbW05PUk1fU09MVkVSXV0gIT0gMA==");
         _if(_cycle_params().if_else,function(){
         
            
            
            VAR_NORM_SOLVER = 1
            

            
            
            html_parser_xpath_parse(VAR_FOREACH_DATA)
            if((true) && !html_parser_xpath_exist("//@src"))
            fail("Can't resolve query " + "//@src");
            VAR_XPATH_XML = html_parser_xpath_xml("//@src")
            

            
            
            html_parser_xpath_parse(VAR_FOREACH_DATA)
            if((true) && !html_parser_xpath_exist("//@rel"))
            fail("Can't resolve query " + "//@rel");
            VAR_XPATH_XML_REL = html_parser_xpath_xml("//@rel")
            

            
            
            VAR_REL_FOTO = VAR_XPATH_XML.split("base64,")[1]
            

            
            
            VAR_REL_LIST.push(VAR_XPATH_XML_REL + ";" + VAR_REL_FOTO)
            

            
            
            VAR_REL_ID = parseInt(VAR_REL_ID) + parseInt(1)
            

         })!
         

         
         
         _if(!_cycle_params().if_else,function(){
         
            
            
            html_parser_xpath_parse(VAR_FOREACH_DATA)
            VAR_XPATH_EXISTS = html_parser_xpath_exist("//*[@class=\u0022atblink\u0022]")
            

            
            
            _set_if_expression("W1tYUEFUSF9FWElTVFNdXSAmJiBbW05PUk1fU09MVkVSXV0gIT0gMQ==");
            _if(VAR_XPATH_EXISTS && VAR_NORM_SOLVER != 1,function(){
            
               
               
               VAR_NORM_SOLVER = 0
               

               
               
               html_parser_xpath_parse(VAR_FOREACH_DATA)
               if((true) && !html_parser_xpath_exist("//@src"))
               fail("Can't resolve query " + "//@src");
               VAR_XPATH_XML = html_parser_xpath_xml("//@src")
               

               
               
               VAR_REL_FOTO = VAR_XPATH_XML.split("base64,")[1]
               

               
               
               VAR_XPATH_XML_REL = VAR_REL_FOTO.length
               

               
               
               VAR_DATA_WORLD_IMG[VAR_XPATH_XML_REL] = VAR_XPATH_XML
               

               
               
               VAR_REL_LIST.push(VAR_XPATH_XML_REL + ";" + VAR_REL_FOTO)
               

               
               
               VAR_REL_ID = parseInt(VAR_REL_ID) + parseInt(1)
               

            })!
            

         })!
         delete _cycle_params().if_else;
         

      })!
      

      
      
      _set_if_expression("W1tNQUlOX0lEXV0gPT0gMA==");
      _if(VAR_MAIN_ID == 0,function(){
      
         
         
         fail((_K==="en" ? "Main captcha image not found" : "Не найдено основное изображение капчи"));
         

      })!
      

      
      
      _set_if_expression("W1tSRUxfSURdXSA8IDMgfHwgW1tSRUxfSURdXSA+IDQ=");
      _if(VAR_REL_ID < 3 || VAR_REL_ID > 4,function(){
      
         
         
         fail((_K==="en" ? "Found (" + VAR_REL_ID + ") antibot images with rel value" : "Найдено (" + VAR_REL_ID + ") изображений antibot с значением rel"));
         

      })!
      

      
      
      solver_properties_clear("capmonster")
      solver_property("capmonster","serverurl","http://sctg.xyz")
      solver_property("capmonster","key",VAR_APIKEY)
      solver_property("capmonster","method","antibot")
      solver_property("capmonster","main",VAR_MAIN_FOTO)
      VAR_REL_LIST.forEach(function(item) {
      VAR_REL_ID = item.split(";")[0]
      VAR_BASE64 = item.split(";")[1]
      solver_property("capmonster",VAR_REL_ID,VAR_BASE64)
      });
      solve_base64_no_fail("capmonster", "")!
      VAR_SAVED_CONTENT = _result();
      

      
      
      VAR_STRING_MATCHES = Boolean(native("regexp", "ismatch", JSON.stringify({text: VAR_SAVED_CONTENT,regexp:("(_)").toString()})) == "true")
      

      
      
      _set_if_expression("W1tTVFJJTkdfTUFUQ0hFU11d");
      _if(typeof(VAR_STRING_MATCHES) !== "undefined" ? (VAR_STRING_MATCHES) : undefined,function(){
      
         
         
         fail((_K==="en" ? "Error when solving captcha" : "Ошибка при решении капчи"));
         

      })!
      

      
      
      VAR_SCAN_RESULT_LIST = native("regexp", "scan", JSON.stringify({text: VAR_SAVED_CONTENT,regexp:("\u005cd+").toString()}))
      if(VAR_SCAN_RESULT_LIST.length == 0)
      VAR_SCAN_RESULT_LIST = []
      else
      VAR_SCAN_RESULT_LIST = JSON.parse(VAR_SCAN_RESULT_LIST)
      

      
      
      _set_if_expression("W1tTQ0FOX1JFU1VMVF9MSVNUXV0ubGVuZ3RoICE9IFtbUkVMX0xJU1RdXS5sZW5ndGg=");
      _if(VAR_SCAN_RESULT_LIST.length != VAR_REL_LIST.length,function(){
      
         
         
         fail((_K==="en" ? "The captcha solved by the service is not correct" : "Капча решена сервисом не верно"));
         

      })!
      

      
      
      _do_with_params({"foreach_data":(VAR_SCAN_RESULT_LIST)},function(){
      _set_action_info({ name: "Foreach" });
      VAR_CYCLE_INDEX = _iterator() - 1
      if(VAR_CYCLE_INDEX > _cycle_param("foreach_data").length - 1)_break();
      VAR_FOREACH_DATA = _cycle_param("foreach_data")[VAR_CYCLE_INDEX]
      
         
         
         _cycle_params().if_else = VAR_NORM_SOLVER == 1;
         _set_if_expression("W1tOT1JNX1NPTFZFUl1dID09IDE=");
         _if(_cycle_params().if_else,function(){
         
            
            
            _cycle_params().if_else = VAR_MOUSE == "true";
            _set_if_expression("W1tNT1VTRV1dID09ICJ0cnVlIg==");
            _if(_cycle_params().if_else,function(){
            
               
               
               /*Browser*/
               _SELECTOR = " \u003eXPATH\u003e //*[@rel=" + VAR_FOREACH_DATA + "]";
               wait_element_visible(_SELECTOR)!
               _call(_random_point, {})!
               _if(_result().length > 0, function(){
               move( {} )!
               get_element_selector(_SELECTOR, false).clarify(X,Y)!
               _call(_clarify, {} )!
               mouse(X,Y)!
               })!
               

            })!
            

            
            
            _if(!_cycle_params().if_else,function(){
            
               
               
               /*Browser*/
               _SELECTOR = " \u003eXPATH\u003e //*[@rel=" + VAR_FOREACH_DATA + "]";
               wait_element_visible(_SELECTOR)!
               _call(_random_point, {})!
               _if(_result().length > 0, function(){
               X = parseInt(_result().split(",")[0])
               Y = parseInt(_result().split(",")[1])
               mouse(X,Y)!
               })!
               

            })!
            delete _cycle_params().if_else;
            

         })!
         

         
         
         _if(!_cycle_params().if_else,function(){
         
            
            
            VAR_TEMP_SRC = VAR_DATA_WORLD_IMG[VAR_FOREACH_DATA]
            

            
            
            _cycle_params().if_else = VAR_MOUSE == "true";
            _set_if_expression("W1tNT1VTRV1dID09ICJ0cnVlIg==");
            _if(_cycle_params().if_else,function(){
            
               
               
               /*Browser*/
               _SELECTOR = " \u003eXPATH\u003e //img[contains(@src, \u0022" + VAR_TEMP_SRC + "\u0022)]";
               wait_element_visible(_SELECTOR)!
               _call(_random_point, {})!
               _if(_result().length > 0, function(){
               move( {} )!
               get_element_selector(_SELECTOR, false).clarify(X,Y)!
               _call(_clarify, {} )!
               mouse(X,Y)!
               })!
               

            })!
            

            
            
            _if(!_cycle_params().if_else,function(){
            
               
               
               /*Browser*/
               _SELECTOR = " \u003eXPATH\u003e //img[contains(@src, \u0022" + VAR_TEMP_SRC + "\u0022)]";
               wait_element_visible(_SELECTOR)!
               _call(_random_point, {})!
               _if(_result().length > 0, function(){
               X = parseInt(_result().split(",")[0])
               Y = parseInt(_result().split(",")[1])
               mouse(X,Y)!
               })!
               

            })!
            delete _cycle_params().if_else;
            

         })!
         delete _cycle_params().if_else;
         

      })!
      

   }
   

function GoodXevilPaySolver_GXP_ReCaptchaAutoSolver()
   {
   
      
      
      VAR_APIKEY = _function_argument("apikey")
      

      
      
      VAR_SERVER_URL = "http://127.0.0.1:10000"
      

      
      
      VAR_SERVER_URL = "http://sctg.xyz"
      

      
      
      var regexp_result = native("regexp", "first", JSON.stringify({text: VAR_APIKEY,regexp:("([0-9A-Za-z\u005c|]\u007b20,50\u007d)").toString()}))
      if(regexp_result.length == 0)
      regexp_result = []
      else
      regexp_result = JSON.parse(regexp_result)
      VAR_ALL_MATCH = regexp_result.pop()
      if(typeof(VAR_ALL_MATCH) == 'undefined' || !VAR_ALL_MATCH)
      VAR_ALL_MATCH = ""
      VAR_LIST_WITH_GROUPS = regexp_result
      VAR_APIKEY = regexp_result[0]
      if(typeof(VAR_APIKEY) == 'undefined' || !VAR_APIKEY)
      VAR_APIKEY = ""
      if(regexp_result.length == 0)
      {
      VAR_APIKEY = VAR_ALL_MATCH
      }
      if(VAR_ALL_MATCH != "" && Array.isArray(VAR_ALL_MATCH))
      VAR_LIST_WITH_GROUPS.unshift(VAR_ALL_MATCH)
      

      
      
      VAR_TEMP_DATA2 = ""
      

      
      
      VAR_TEMP_DATA = ""
      

      
      
      _do(function(){
      _set_action_info({ name: "While" });
      VAR_CYCLE_INDEX = _iterator() - 1
      BREAK_CONDITION = VAR_TEMP_DATA == "";
      if(!BREAK_CONDITION)_break();
      
         
         
         _set_if_expression("W1tDWUNMRV9JTkRFWF1dICE9IDA=");
         _if(VAR_CYCLE_INDEX != 0,function(){
         
            
            
            sleep(500)!
            

         })!
         

         
         
         _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gMzA=");
         _if(VAR_CYCLE_INDEX > 30,function(){
         
            
            
            fail((_K==="en" ? "ReCaptcha is not detected on the page" : "ReCaptcha не обнаружена на странице"));
            

         })!
         

         
         
         _call(function()
         {
         _on_fail(function(){
         VAR_LAST_ERROR = _result()
         VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
         VAR_WAS_ERROR = false
         _break(1,true)
         })
         CYCLES.Current().RemoveLabel("function")
         
            
            
            page().script2("[[TEMP_DATA]] = window.widgetInfore;",JSON.stringify(_read_variables(["VAR_TEMP_DATA"])))!
            var _parse_result = JSON.parse(_result())
            _write_variables(JSON.parse(_parse_result.variables))
            if(!_parse_result.is_success)
            fail(_parse_result.error)
            

         },null)!
         

      })!
      

      
      
      /*Browser*/
      url()!
      VAR_SITE_URL = _result()
      

      
      
      VAR_SAVED_CONTENT = "ERROR"
      

      
      
      _do(function(){
      _set_action_info({ name: "For" });
      VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(0)
      if(VAR_CYCLE_INDEX > parseInt(3))_break();
      
         
         
         _set_if_expression("W1tDWUNMRV9JTkRFWF1dID49IDI=");
         _if(VAR_CYCLE_INDEX >= 2,function(){
         
            
            
            fail((_K==="en" ? "Error solving captcha" : "Ошибка при решении капчи"));
            

         })!
         

         
         
         _call(function()
         {
         _on_fail(function(){
         VAR_LAST_ERROR = _result()
         VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
         VAR_WAS_ERROR = false
         _break(1,true)
         })
         CYCLES.Current().RemoveLabel("function")
         
            
            
            solver_properties_clear("capmonster")
            solver_property("capmonster","serverurl",VAR_SERVER_URL)
            solver_property("capmonster","key",VAR_APIKEY)
            solver_property("capmonster","method","userrecaptcha")
            solver_property("capmonster","pageurl",VAR_SITE_URL)
            solver_property("capmonster","googlekey",VAR_TEMP_DATA["sitekey"])
            solve_base64_no_fail("capmonster", "")!
            VAR_SAVED_CONTENT = _result();
            

         },null)!
         

         
         
         VAR_STRING_MATCHES = Boolean(native("regexp", "ismatch", JSON.stringify({text: VAR_SAVED_CONTENT,regexp:("(ERROR)").toString()})) == "true")
         

         
         
         VAR_STRING_MATCHES2 = Boolean(native("regexp", "ismatch", JSON.stringify({text: VAR_SAVED_CONTENT,regexp:("(_FAIL)").toString()})) == "true")
         

         
         
         _set_if_expression("W1tTVFJJTkdfTUFUQ0hFU11dIHx8IFtbU1RSSU5HX01BVENIRVMyXV0=");
         _if(VAR_STRING_MATCHES || VAR_STRING_MATCHES2,function(){
         
            
            
            sleep(1000)!
            

            
            
            _next("function")
            

         })!
         

         
         
         _break("function")
         

      })!
      

      
      
      _call(function()
      {
      _on_fail(function(){
      VAR_LAST_ERROR = _result()
      VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
      VAR_WAS_ERROR = false
      _break(1,true)
      })
      CYCLES.Current().RemoveLabel("function")
      
         
         
         /*Browser*/
         _SELECTOR = " \u003eCSS\u003eiframe[src*=\u0027anchor\u0027]\u003eFRAME\u003e \u003eXPATH\u003e //input[@id=\u0022recaptcha-token\u0022]";
         wait_element(_SELECTOR)!
         get_element_selector(_SELECTOR, false).set_attr("value", VAR_SAVED_CONTENT)!
         

      },null)!
      

      
      
      _call(function()
      {
      _on_fail(function(){
      VAR_LAST_ERROR = _result()
      VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
      VAR_WAS_ERROR = false
      _break(1,true)
      })
      CYCLES.Current().RemoveLabel("function")
      
         
         
         page().script2("var xpath = \u0027//textarea[@name=\u0022g-recaptcha-response\u0022]\u0027;\r\nvar result = document.evaluate(xpath, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null);\r\nvar element = result.singleNodeValue;\r\n\r\nif (element) \u007b\r\n  element.innerText = [[SAVED_CONTENT]];\r\n\u007d\r\n",JSON.stringify(_read_variables(["VAR_SAVED_CONTENT"])))!
         var _parse_result = JSON.parse(_result())
         _write_variables(JSON.parse(_parse_result.variables))
         if(!_parse_result.is_success)
         fail(_parse_result.error)
         

      },null)!
      

      
      
      _call(function()
      {
      _on_fail(function(){
      VAR_LAST_ERROR = _result()
      VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
      VAR_WAS_ERROR = false
      _break(1,true)
      })
      CYCLES.Current().RemoveLabel("function")
      
         
         
         page().script2("if(window.widgetInfore.callback != null)\u007b\r\n    let func = window.widgetInfore.callback\r\n    let data = [[SAVED_CONTENT]];\r\n    window[func](data);\r\n\u007d\r\n",JSON.stringify(_read_variables(["VAR_SAVED_CONTENT"])))!
         var _parse_result = JSON.parse(_result())
         _write_variables(JSON.parse(_parse_result.variables))
         if(!_parse_result.is_success)
         fail(_parse_result.error)
         

      },null)!
      

      
      
      _call(function()
      {
      _on_fail(function(){
      VAR_LAST_ERROR = _result()
      VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
      VAR_WAS_ERROR = false
      _break(1,true)
      })
      CYCLES.Current().RemoveLabel("function")
      
         
         
         page().script2("function getBindedElements(widget) \u007b\r\n    let elements = \u007b\r\n        button: null,\r\n        textarea: null,\r\n    \u007d;\r\n    if (widget.bindedButtonId) \u007b\r\n        let button = document.querySelector(\u0022#\u0022 + widget.bindedButtonId);\r\n        if (button.length) elements.button = button;\r\n    \u007d else \u007b\r\n        let textarea = document.querySelector(\u0022#\u0022 + widget.containerId + \u0022 textarea[name=g-recaptcha-response]\u0022);\r\n        if (textarea.length) elements.textarea = textarea;\r\n    \u007d\r\n    return elements;\r\n\u007d  \r\n\r\nfunction getForm(widget) \u007b\r\n    let binded = getBindedElements(widget);\r\n    if (binded.textarea) \u007b\r\n        return binded.textarea.closest(\u0022form\u0022);\r\n    \u007d\r\n    return binded.button.closest(\u0022form\u0022);\r\n\u007d\r\n\r\nlet textarea = getBindedElements(window.widgetInfore).textarea;\r\nif (!textarea) \u007b\r\n    textarea = getForm(window.widgetInfore).find(\u0022textarea[name=g-recaptcha-response]\u0022);\r\n\u007d\r\ntextarea.val([[SAVED_CONTENT]]);\r\n\r\nif(window.widgetInfore.callback != null)\u007b\r\n    let func = window.widgetInfore.callback\r\n    let data = [[SAVED_CONTENT]];\r\n    window[func](data);\r\n\u007d",JSON.stringify(_read_variables(["VAR_SAVED_CONTENT"])))!
         var _parse_result = JSON.parse(_result())
         _write_variables(JSON.parse(_parse_result.variables))
         if(!_parse_result.is_success)
         fail(_parse_result.error)
         

      },null)!
      

      
      
      _call(function()
      {
      _on_fail(function(){
      VAR_LAST_ERROR = _result()
      VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
      VAR_WAS_ERROR = false
      _break(1,true)
      })
      CYCLES.Current().RemoveLabel("function")
      
         
         
         page().script2("function setRecaptchaToken(token, clientIdx = 0) \u007b\r\n  var recap = window[\u0022___grecaptcha_cfg\u0022].clients[clientIdx];\r\n  Object.keys(recap).forEach(function(k) \u007b\r\n      if (recap[k] != null \u0026\u0026 recap[k][k] != null \u0026\u0026 recap[k][k][\u0022callback\u0022] != null)  \u007b\r\n           recap[k][k].callback(token);\r\n           console.log(\u0027recap token sumbited\u0027)\r\n           return;\r\n      \u007d \r\n  \u007d);  \r\n\u007d\r\n\r\nsetRecaptchaToken([[SAVED_CONTENT]])",JSON.stringify(_read_variables(["VAR_SAVED_CONTENT"])))!
         var _parse_result = JSON.parse(_result())
         _write_variables(JSON.parse(_parse_result.variables))
         if(!_parse_result.is_success)
         fail(_parse_result.error)
         

      },null)!
      

      
      
      _set_if_expression("ZmFsc2U=");
      _if(false,function(){
      
         
         
         page().script2("function findRecaptchaClients() \u007b\r\n  // eslint-disable-next-line camelcase\r\n  if (typeof (___grecaptcha_cfg) !== \u0027undefined\u0027) \u007b\r\n    // eslint-disable-next-line camelcase, no-undef\r\n    return Object.entries(___grecaptcha_cfg.clients).map(([cid, client]) =\u003e \u007b\r\n      const data = \u007b id: cid, version: cid \u003e= 10000 ? \u0027V3\u0027 : \u0027V2\u0027 \u007d;\r\n      const objects = Object.entries(client).filter(([_, value]) =\u003e value \u0026\u0026 typeof value === \u0027object\u0027);\r\n\r\n      objects.forEach(([toplevelKey, toplevel]) =\u003e \u007b\r\n        const found = Object.entries(toplevel).find(([_, value]) =\u003e (\r\n          value \u0026\u0026 typeof value === \u0027object\u0027 \u0026\u0026 \u0027sitekey\u0027 in value \u0026\u0026 \u0027size\u0027 in value\r\n        ));\r\n     \r\n        if (typeof toplevel === \u0027object\u0027 \u0026\u0026 toplevel instanceof HTMLElement \u0026\u0026 toplevel[\u0027tagName\u0027] === \u0027DIV\u0027)\u007b\r\n            data.pageurl = toplevel.baseURI;\r\n        \u007d\r\n        \r\n        if (found) \u007b\r\n          const [sublevelKey, sublevel] = found;\r\n\r\n          data.sitekey = sublevel.sitekey;\r\n          const callbackKey = data.version === \u0027V2\u0027 ? \u0027callback\u0027 : \u0027promise-callback\u0027;\r\n          const callback = sublevel[callbackKey];\r\n          if (!callback) \u007b\r\n            data.callback = null;\r\n            data.function = null;\r\n          \u007d else \u007b\r\n            data.function = callback;\r\n            const keys = [cid, toplevelKey, sublevelKey, callbackKey].map((key) =\u003e `[\u0027$\u007bkey\u007d\u0027]`).join(\u0027\u0027);\r\n            data.callback = `___grecaptcha_cfg.clients$\u007bkeys\u007d`;\r\n          \u007d\r\n        \u007d\r\n      \u007d);\r\n      return data;\r\n    \u007d);\r\n  \u007d\r\n  return [];\r\n\u007d\r\n\r\nlet res = findRecaptchaClients()\r\n[[TEMP_DATA]] = res",JSON.stringify(_read_variables(["VAR_TEMP_DATA"])))!
         var _parse_result = JSON.parse(_result())
         _write_variables(JSON.parse(_parse_result.variables))
         if(!_parse_result.is_success)
         fail(_parse_result.error)
         

      })!
      

   }
   

function GoodXevilPaySolver_GXP_AutoBypassCloudFlare()
   {
   
      
      
      VAR_CUSTOM_BUTTON = _function_argument("custom_button")
      

      
      
      VAR_MAX_TIME = _function_argument("max_time")
      

      
      
      VAR_WHAIT_ELEMENT = _function_argument("whait_element")
      

      
      
      VAR_FIND_ELEM = false
      

      
      
      _do(function(){
      _set_action_info({ name: "While" });
      VAR_CYCLE_INDEX = _iterator() - 1
      BREAK_CONDITION = true;
      if(!BREAK_CONDITION)_break();
      
         
         
         _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gNQ==");
         _if(VAR_CYCLE_INDEX > 5,function(){
         
            
            
            fail((_K==="en" ? "Cloudflare didn't allow access to the site" : "Cloudflare не пустил на сайт"));
            

         })!
         

         
         
         _call(function()
         {
         _on_fail(function(){
         VAR_LAST_ERROR = _result()
         VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
         VAR_WAS_ERROR = false
         _break(1,true)
         })
         CYCLES.Current().RemoveLabel("function")
         
            
            
            /*Browser*/
            waiter_timeout_next(15000)
            wait_async_load()!
            

         },null)!
         

         
         
         _do(function(){
         _set_action_info({ name: "For" });
         VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
         if(VAR_CYCLE_INDEX > parseInt(VAR_MAX_TIME))_break();
         
            
            
            _call(function()
            {
            _on_fail(function(){
            VAR_LAST_ERROR = _result()
            VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
            VAR_WAS_ERROR = false
            _break(1,true)
            })
            CYCLES.Current().RemoveLabel("function")
            
               
               
               /*Browser*/
               ;_SELECTOR=" \u003eCSS\u003e .font-red";
               get_element_selector(_SELECTOR, false).nowait().exist()!
               VAR_IS_EXISTS = _result() == 1
               _if(VAR_IS_EXISTS, function(){
               get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
               VAR_IS_EXISTS = _result().indexOf("true")>=0
               })!
               

               
               
               _set_if_expression("W1tJU19FWElTVFNdXQ==");
               _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
               
                  
                  
                  page().script2("location.reload()",JSON.stringify(_read_variables([])))!
                  var _parse_result = JSON.parse(_result())
                  _write_variables(JSON.parse(_parse_result.variables))
                  if(!_parse_result.is_success)
                  fail(_parse_result.error)
                  

                  
                  
                  _call(function()
                  {
                  _on_fail(function(){
                  VAR_LAST_ERROR = _result()
                  VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
                  VAR_WAS_ERROR = false
                  _break(1,true)
                  })
                  CYCLES.Current().RemoveLabel("function")
                  
                     
                     
                     /*Browser*/
                     waiter_timeout_next(25000)
                     wait_async_load()!
                     

                     
                     
                     sleep(10000)!
                     

                  },null)!
                  

                  
                  
                  _next("function")
                  

               })!
               

            },null)!
            

            
            
            _call(function()
            {
            _on_fail(function(){
            VAR_LAST_ERROR = _result()
            VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
            VAR_WAS_ERROR = false
            _break(1,true)
            })
            CYCLES.Current().RemoveLabel("function")
            
               
               
               /*Browser*/
               ;_SELECTOR="\u003eMATCH\u003e\u003ch1\u003e403 Forbidden\u003c/h1\u003e";
               get_element_selector(_SELECTOR, false).nowait().exist()!
               VAR_IS_EXISTS = _result() == 1
               

               
               
               _set_if_expression("W1tJU19FWElTVFNdXQ==");
               _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
               
                  
                  
                  page().script2("location.reload()",JSON.stringify(_read_variables([])))!
                  var _parse_result = JSON.parse(_result())
                  _write_variables(JSON.parse(_parse_result.variables))
                  if(!_parse_result.is_success)
                  fail(_parse_result.error)
                  

                  
                  
                  _call(function()
                  {
                  _on_fail(function(){
                  VAR_LAST_ERROR = _result()
                  VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
                  VAR_WAS_ERROR = false
                  _break(1,true)
                  })
                  CYCLES.Current().RemoveLabel("function")
                  
                     
                     
                     /*Browser*/
                     waiter_timeout_next(25000)
                     wait_async_load()!
                     

                     
                     
                     sleep(10000)!
                     

                  },null)!
                  

                  
                  
                  _next("function")
                  

               })!
               

            },null)!
            

            
            
            _call(function()
            {
            _on_fail(function(){
            VAR_LAST_ERROR = _result()
            VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
            VAR_WAS_ERROR = false
            _break(1,true)
            })
            CYCLES.Current().RemoveLabel("function")
            
               
               
               /*Browser*/
               ;_SELECTOR=" \u003eCSS\u003e #challenge-body-text";
               get_element_selector(_SELECTOR, false).nowait().exist()!
               VAR_IS_EXISTS = _result() == 1
               _if(VAR_IS_EXISTS, function(){
               get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
               VAR_IS_EXISTS = _result().indexOf("true")>=0
               })!
               

               
               
               _set_if_expression("W1tJU19FWElTVFNdXSAmJiBbW0NZQ0xFX0lOREVYXV0gPT0gMTAw");
               _if(VAR_IS_EXISTS && VAR_CYCLE_INDEX == 100,function(){
               
                  
                  
                  page().script2("location.reload()",JSON.stringify(_read_variables([])))!
                  var _parse_result = JSON.parse(_result())
                  _write_variables(JSON.parse(_parse_result.variables))
                  if(!_parse_result.is_success)
                  fail(_parse_result.error)
                  

                  
                  
                  _call(function()
                  {
                  _on_fail(function(){
                  VAR_LAST_ERROR = _result()
                  VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
                  VAR_WAS_ERROR = false
                  _break(1,true)
                  })
                  CYCLES.Current().RemoveLabel("function")
                  
                     
                     
                     /*Browser*/
                     waiter_timeout_next(25000)
                     wait_async_load()!
                     

                     
                     
                     sleep(10000)!
                     

                  },null)!
                  

                  
                  
                  _next("function")
                  

               })!
               

               
               
               _set_if_expression("W1tJU19FWElTVFNdXSAmJiBbW0NZQ0xFX0lOREVYXV0gPT0gMjAw");
               _if(VAR_IS_EXISTS && VAR_CYCLE_INDEX == 200,function(){
               
                  
                  
                  page().script2("location.reload()",JSON.stringify(_read_variables([])))!
                  var _parse_result = JSON.parse(_result())
                  _write_variables(JSON.parse(_parse_result.variables))
                  if(!_parse_result.is_success)
                  fail(_parse_result.error)
                  

                  
                  
                  _call(function()
                  {
                  _on_fail(function(){
                  VAR_LAST_ERROR = _result()
                  VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
                  VAR_WAS_ERROR = false
                  _break(1,true)
                  })
                  CYCLES.Current().RemoveLabel("function")
                  
                     
                     
                     /*Browser*/
                     waiter_timeout_next(25000)
                     wait_async_load()!
                     

                     
                     
                     sleep(10000)!
                     

                  },null)!
                  

                  
                  
                  _next("function")
                  

               })!
               

            },null)!
            

            
            
            sleep(1000)!
            

            
            
            /*Browser*/
            ;_SELECTOR=" \u003eCSS\u003e #challenge-running";
            get_element_selector(_SELECTOR, false).nowait().exist()!
            VAR_IS_EXISTS = _result() == 1
            _if(VAR_IS_EXISTS, function(){
            get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
            VAR_IS_EXISTS = _result().indexOf("true")>=0
            })!
            

            
            
            _set_if_expression("W1tJU19FWElTVFNdXSA9PSBmYWxzZQ==");
            _if(VAR_IS_EXISTS == false,function(){
            
               
               
               _break("function")
               

            })!
            

            
            
            /*Browser*/
            ;_SELECTOR=" \u003eCSS\u003e iframe\u003eFRAME\u003e \u003eCSS\u003e img";
            get_element_selector(_SELECTOR, false).nowait().exist()!
            VAR_IS_EXISTS = _result() == 1
            _if(VAR_IS_EXISTS, function(){
            get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
            VAR_IS_EXISTS = _result().indexOf("true")>=0
            })!
            

            
            
            _set_if_expression("W1tJU19FWElTVFNdXQ==");
            _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
            
               
               
               /*Browser*/
               _SELECTOR = " \u003eCSS\u003e iframe\u003eFRAME\u003e \u003eCSS\u003e img";waiter_timeout_next(1000)
               waiter_nofail_next();
               wait_element_visible(_SELECTOR)!
               _call(_random_point, {})!
               _if(_result().length > 0, function(){
               move( {} )!
               get_element_selector(_SELECTOR, false).nowait().clarify(X,Y)!
               _call(_clarify, {} )!
               mouse(X,Y)!
               })!
               

               
               
               sleep(1000)!
               

            })!
            

            
            
            /*Browser*/
            ;_SELECTOR="\u003eMATCH\u003e\u003ciframe id=\u0022externalChallenge\u0022\u003eFRAME\u003e\u003eMATCH\u003e\u003ciframe src=\u0022https://challenges.cloudfla\u003eFRAME\u003e\u003eMATCH\u003e\u003cinput type=\u0022checkbox\u0022\u003e";
            get_element_selector(_SELECTOR, false).nowait().exist()!
            VAR_IS_EXISTS = _result() == 1
            _if(VAR_IS_EXISTS, function(){
            get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
            VAR_IS_EXISTS = _result().indexOf("true")>=0
            })!
            

            
            
            _set_if_expression("W1tJU19FWElTVFNdXQ==");
            _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
            
               
               
               /*Browser*/
               _SELECTOR = "\u003eMATCH\u003e\u003ciframe id=\u0022externalChallenge\u0022\u003eFRAME\u003e\u003eMATCH\u003e\u003ciframe src=\u0022https://challenges.cloudfla\u003eFRAME\u003e\u003eMATCH\u003e\u003cinput type=\u0022checkbox\u0022\u003e";waiter_timeout_next(1000)
               waiter_nofail_next();
               wait_element_visible(_SELECTOR)!
               _call(_random_point, {})!
               _if(_result().length > 0, function(){
               move( {} )!
               get_element_selector(_SELECTOR, false).nowait().clarify(X,Y)!
               _call(_clarify, {} )!
               mouse(X,Y)!
               })!
               

               
               
               sleep(1000)!
               

            })!
            

            
            
            /*Browser*/
            ;_SELECTOR="\u003eMATCH\u003e\u003ciframe src=\u0022https://challenges.cloudfla\u003eFRAME\u003e\u003eMATCH\u003e\u003cinput type=\u0022checkbox\u0022\u003e";
            get_element_selector(_SELECTOR, false).nowait().exist()!
            VAR_IS_EXISTS = _result() == 1
            _if(VAR_IS_EXISTS, function(){
            get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
            VAR_IS_EXISTS = _result().indexOf("true")>=0
            })!
            

            
            
            _set_if_expression("W1tJU19FWElTVFNdXQ==");
            _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
            
               
               
               /*Browser*/
               _SELECTOR = "\u003eMATCH\u003e\u003ciframe src=\u0022https://challenges.cloudfla\u003eFRAME\u003e\u003eMATCH\u003e\u003cinput type=\u0022checkbox\u0022\u003e";waiter_timeout_next(1000)
               waiter_nofail_next();
               wait_element_visible(_SELECTOR)!
               _call(_random_point, {})!
               _if(_result().length > 0, function(){
               move( {} )!
               get_element_selector(_SELECTOR, false).nowait().clarify(X,Y)!
               _call(_clarify, {} )!
               mouse(X,Y)!
               })!
               

               
               
               sleep(1000)!
               

            })!
            

            
            
            _set_if_expression("W1tDVVNUT01fQlVUVE9OXV0gIT0gZmFsc2U=");
            _if(VAR_CUSTOM_BUTTON != false,function(){
            
               
               
               /*Browser*/
               ;_SELECTOR=VAR_CUSTOM_BUTTON;
               get_element_selector(_SELECTOR, false).nowait().exist()!
               VAR_IS_EXISTS = _result() == 1
               _if(VAR_IS_EXISTS, function(){
               get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
               VAR_IS_EXISTS = _result().indexOf("true")>=0
               })!
               

               
               
               _set_if_expression("W1tJU19FWElTVFNdXQ==");
               _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
               
                  
                  
                  /*Browser*/
                  _SELECTOR = VAR_CUSTOM_BUTTON;waiter_timeout_next(1000)
                  waiter_nofail_next();
                  wait_element_visible(_SELECTOR)!
                  _call(_random_point, {})!
                  _if(_result().length > 0, function(){
                  move( {} )!
                  get_element_selector(_SELECTOR, false).nowait().clarify(X,Y)!
                  _call(_clarify, {} )!
                  mouse(X,Y)!
                  })!
                  

                  
                  
                  sleep(1000)!
                  

               })!
               

            })!
            

            
            
            /*Browser*/
            ;_SELECTOR="\u003eMATCH\u003e\u003ch1\u003eAccess denied\u003c/h1\u003e";
            get_element_selector(_SELECTOR, false).nowait().exist()!
            VAR_IS_EXISTS = _result() == 1
            _if(VAR_IS_EXISTS, function(){
            get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
            VAR_IS_EXISTS = _result().indexOf("true")>=0
            })!
            

            
            
            _set_if_expression("W1tJU19FWElTVFNdXQ==");
            _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
            
               
               
               fail((_K==="en" ? "Cloudflare banned the IP" : "Cloudflare забанила ип"));
               

            })!
            

            
            
            _set_if_expression("W1tXSEFJVF9FTEVNRU5UXV0gIT0gZmFsc2U=");
            _if(VAR_WHAIT_ELEMENT != false,function(){
            
               
               
               /*Browser*/
               ;_SELECTOR=VAR_WHAIT_ELEMENT;
               get_element_selector(_SELECTOR, false).nowait().exist()!
               VAR_IS_EXISTS = _result() == 1
               _if(VAR_IS_EXISTS, function(){
               get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
               VAR_IS_EXISTS = _result().indexOf("true")>=0
               })!
               

               
               
               _set_if_expression("W1tJU19FWElTVFNdXQ==");
               _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
               
                  
                  
                  VAR_FIND_ELEM = true
                  

                  
                  
                  _break("function")
                  

               })!
               

            })!
            

         })!
         

         
         
         _set_if_expression("W1tGSU5EX0VMRU1dXQ==");
         _if(typeof(VAR_FIND_ELEM) !== "undefined" ? (VAR_FIND_ELEM) : undefined,function(){
         
            
            
            _break("function")
            

         })!
         

         
         
         _break("function")
         

      })!
      

   }
   

function GoodXevilPaySolver_GXP_IconCaptchaFreeSolver()
   {
   
      
      
      /*Browser*/
      ;_SELECTOR=" \u003eCSS\u003e .iconcaptcha-modal";
      get_element_selector(_SELECTOR, false).nowait().exist()!
      VAR_IS_EXISTS = _result() == 1
      _if(VAR_IS_EXISTS, function(){
      get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
      VAR_IS_EXISTS = _result().indexOf("true")>=0
      })!
      

      
      
      /*Browser*/
      ;_SELECTOR=" \u003eCSS\u003e .iconcaptcha-modal__body-icons";
      get_element_selector(_SELECTOR, false).nowait().exist()!
      VAR_IS_EXISTS2 = _result() == 1
      _if(VAR_IS_EXISTS2, function(){
      get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
      VAR_IS_EXISTS2 = _result().indexOf("true")>=0
      })!
      

      
      
      VAR_MAIN_CAPTCHA_ID = " \u003eCSS\u003e .iconcaptcha-modal__body-icons"
      

      
      
      _do(function(){
      _set_action_info({ name: "While" });
      VAR_CYCLE_INDEX = _iterator() - 1
      BREAK_CONDITION = VAR_IS_EXISTS == false && VAR_IS_EXISTS2 == false;
      if(!BREAK_CONDITION)_break();
      
         
         
         _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gMzA=");
         _if(VAR_CYCLE_INDEX > 30,function(){
         
            
            
            fail((_K==="en" ? "Didn't wait for iconcaptcha" : "Не дождался iconcaptcha"));
            

         })!
         

         
         
         sleep(1000)!
         

         
         
         /*Browser*/
         ;_SELECTOR=" \u003eCSS\u003e .iconcaptcha-modal__header";
         get_element_selector(_SELECTOR, false).nowait().exist()!
         VAR_IS_EXISTS2 = _result() == 1
         _if(VAR_IS_EXISTS2, function(){
         get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
         VAR_IS_EXISTS2 = _result().indexOf("true")>=0
         })!
         

         
         
         /*Browser*/
         ;_SELECTOR=" \u003eCSS\u003e .iconcaptcha-modal";
         get_element_selector(_SELECTOR, false).nowait().exist()!
         VAR_IS_EXISTS = _result() == 1
         _if(VAR_IS_EXISTS, function(){
         get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
         VAR_IS_EXISTS = _result().indexOf("true")>=0
         })!
         

         
         
         /*Browser*/
         ;_SELECTOR=" \u003eCSS\u003e #icaptcha-frame\u003eFRAME\u003e \u003eCSS\u003e .captcha-image";
         get_element_selector(_SELECTOR, false).nowait().exist()!
         VAR_IS_EXISTS3 = _result() == 1
         _if(VAR_IS_EXISTS3, function(){
         get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
         VAR_IS_EXISTS3 = _result().indexOf("true")>=0
         })!
         

         
         
         _set_if_expression("W1tJU19FWElTVFMzXV0=");
         _if(typeof(VAR_IS_EXISTS3) !== "undefined" ? (VAR_IS_EXISTS3) : undefined,function(){
         
            
            
            VAR_MAIN_CAPTCHA_ID = " \u003eCSS\u003e #icaptcha-frame\u003eFRAME\u003e \u003eCSS\u003e .captcha-image"
            

            
            
            _break("function")
            

         })!
         

      })!
      

      
      
      _set_if_expression("W1tJU19FWElTVFNdXSAmJiBbW0lTX0VYSVNUUzJdXSA9PSBmYWxzZQ==");
      _if(VAR_IS_EXISTS && VAR_IS_EXISTS2 == false,function(){
      
         
         
         /*Browser*/
         _SELECTOR = " \u003eCSS\u003e .iconcaptcha-modal";
         wait_element_visible(_SELECTOR)!
         _call(_random_point, {})!
         _if(_result().length > 0, function(){
         move( {} )!
         get_element_selector(_SELECTOR, false).clarify(X,Y)!
         _call(_clarify, {} )!
         mouse(X,Y)!
         })!
         

      })!
      

      
      
      /*Browser*/
      scroll(1,1)!
      

      
      
      /*Browser*/
      _SELECTOR = VAR_MAIN_CAPTCHA_ID;
      wait_element(_SELECTOR)!
      get_element_selector(_SELECTOR, false).script("(function(){var rect = _BAS_HIDE(BrowserAutomationStudio_GetBoundingClientRect)(self);return (rect.left + positionx) + '|' + (rect.top + positiony) + '|' + (rect.right - rect.left) + '|' + (rect.bottom - rect.top) + '|' + (rect.left + positionx + scrollx) + '|' + (rect.top + positiony + scrolly)})();")!
      if(_result().length > 0)
      {
      var split = _result().split("|")
      VAR_X = parseInt(split[0])
      VAR_Y = parseInt(split[1])
      VAR_WIDTH = parseInt(split[2])
      VAR_HEIGHT = parseInt(split[3])
      VAR_ABSOLUTE_X = parseInt(split[4])
      VAR_ABSOLUTE_Y = parseInt(split[5])
      }
      

      
      
      /*Browser*/
      move(VAR_X -3,VAR_Y - 20,  {} )!
      

      
      
      /*Browser*/
      _SELECTOR = VAR_MAIN_CAPTCHA_ID;
      wait_element(_SELECTOR)!
      get_element_selector(_SELECTOR, false).exist()!
      _if(_result() == "1", function(){
      get_element_selector(_SELECTOR, false).render_base64()!
      VAR_ICONCAPTCHAMODAL__BODY = _result()
      })!
      

      
      
      /*Browser*/
      _SELECTOR = VAR_MAIN_CAPTCHA_ID;
      wait_element(_SELECTOR)!
      get_element_selector(_SELECTOR, false).script("(function(){var rect = _BAS_HIDE(BrowserAutomationStudio_GetBoundingClientRect)(self);return (rect.left + positionx) + '|' + (rect.top + positiony) + '|' + (rect.right - rect.left) + '|' + (rect.bottom - rect.top) + '|' + (rect.left + positionx + scrollx) + '|' + (rect.top + positiony + scrolly)})();")!
      if(_result().length > 0)
      {
      var split = _result().split("|")
      VAR_X_L = parseInt(split[0])
      VAR_Y_L = parseInt(split[1])
      VAR_WITH_DATA = parseInt(split[2])
      VAR_HEIGHT_DATA = parseInt(split[3])
      VAR_ABSOLUTE_X = parseInt(split[4])
      VAR_ABSOLUTE_Y = parseInt(split[5])
      }
      

      
      
      VAR_LOADED_IMAGE_ID = native("imageprocessing", "load", VAR_ICONCAPTCHAMODAL__BODY)
      

      
      
      {
      var split = native("imageprocessing", "getsize", VAR_LOADED_IMAGE_ID).split(",")
      VAR_IMAGE_WIDTH = parseInt(split[0])
      VAR_IMAGE_HEIGHT = parseInt(split[1])
      }
      

      
      
      VAR_POINT_X = VAR_IMAGE_HEIGHT/2
      

      
      
      VAR_POINT_X = VAR_POINT_X.toString()
      

      
      
      var regexp_result = native("regexp", "first", JSON.stringify({text: VAR_POINT_X,regexp:("\u005cd+").toString()}))
      if(regexp_result.length == 0)
      regexp_result = []
      else
      regexp_result = JSON.parse(regexp_result)
      VAR_ALL_MATCH = regexp_result.pop()
      if(typeof(VAR_ALL_MATCH) == 'undefined' || !VAR_ALL_MATCH)
      VAR_ALL_MATCH = ""
      VAR_LIST_WITH_GROUPS = regexp_result
      VAR_POINT_X = regexp_result[0]
      if(typeof(VAR_POINT_X) == 'undefined' || !VAR_POINT_X)
      VAR_POINT_X = ""
      if(regexp_result.length == 0)
      {
      VAR_POINT_X = VAR_ALL_MATCH
      }
      if(VAR_ALL_MATCH != "" && Array.isArray(VAR_ALL_MATCH))
      VAR_LIST_WITH_GROUPS.unshift(VAR_ALL_MATCH)
      

      
      
      VAR_POINT_X = parseInt(VAR_POINT_X);
      

      
      
      VAR_TEMP_LIST = []
      

      
      
      VAR_POINT_X = VAR_POINT_X
      

      
      
      VAR_PIXEL_WHITE_MAX = 0
      

      
      
      VAR_PIXEL_WHITE_NOW = 0
      

      
      
      VAR_PIXEL_WHITE_STOP = 0
      

      
      
      {
      var split = native("imageprocessing", "getpixel", (VAR_LOADED_IMAGE_ID) + "," + (2) + "," + (2)).split(",")
      VAR_PIXEL_R = parseInt(split[0])
      VAR_PIXEL_G = parseInt(split[1])
      VAR_PIXEL_B = parseInt(split[2])
      VAR_PIXEL_A = parseInt(split[3])
      }
      

      
      
      _cycle_params().if_else = VAR_PIXEL_B > 200;
      _set_if_expression("W1tQSVhFTF9CXV0gPiAyMDA=");
      _if(_cycle_params().if_else,function(){
      
         
         
         _do(function(){
         _set_action_info({ name: "For" });
         VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(0)
         if(VAR_CYCLE_INDEX > parseInt(VAR_IMAGE_WIDTH - 1))_break();
         
            
            
            VAR_CYCLE_INDEX_X = VAR_CYCLE_INDEX
            

            
            
            VAR_NO_WHITE_PIXEL = 0
            

            
            
            VAR_NO_WHITE_PIXEL_DATA = 0
            

            
            
            _do(function(){
            _set_action_info({ name: "For" });
            VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(0)
            if(VAR_CYCLE_INDEX > parseInt(VAR_IMAGE_HEIGHT - 1))_break();
            
               
               
               {
               var split = native("imageprocessing", "getpixel", (VAR_LOADED_IMAGE_ID) + "," + (VAR_CYCLE_INDEX_X) + "," + (VAR_CYCLE_INDEX)).split(",")
               VAR_PIXEL_R = parseInt(split[0])
               VAR_PIXEL_G = parseInt(split[1])
               VAR_PIXEL_B = parseInt(split[2])
               VAR_PIXEL_A = parseInt(split[3])
               }
               

               
               
               _cycle_params().if_else = VAR_PIXEL_B <= 240;
               _set_if_expression("W1tQSVhFTF9CXV0gPD0gMjQw");
               _if(_cycle_params().if_else,function(){
               
                  
                  
                  VAR_PIXEL_WHITE_NOW = 1
                  

                  
                  
                  VAR_PIXEL_WHITE_MAX = parseInt(VAR_PIXEL_WHITE_MAX) + parseInt(1)
                  

               })!
               

               
               
               _if(!_cycle_params().if_else,function(){
               
                  
                  
                  VAR_NO_WHITE_PIXEL_DATA = parseInt(VAR_NO_WHITE_PIXEL_DATA) + parseInt(1)
                  

               })!
               delete _cycle_params().if_else;
               

            })!
            

            
            
            _set_if_expression("W1tOT19XSElURV9QSVhFTF9EQVRBXV0gKyA1ID49IFtbSU1BR0VfSEVJR0hUXV0=");
            _if(VAR_NO_WHITE_PIXEL_DATA + 5 >= VAR_IMAGE_HEIGHT,function(){
            
               
               
               VAR_NO_WHITE_PIXEL = parseInt(VAR_NO_WHITE_PIXEL) + parseInt(1)
               

            })!
            

            
            
            _set_if_expression("W1tOT19XSElURV9QSVhFTF1dID09IDE=");
            _if(VAR_NO_WHITE_PIXEL == 1,function(){
            
               
               
               _set_if_expression("W1tQSVhFTF9XSElURV9OT1ddXSA9PSAx");
               _if(VAR_PIXEL_WHITE_NOW == 1,function(){
               
                  
                  
                  VAR_PIXEL_WHITE_STOP = parseInt(VAR_PIXEL_WHITE_STOP) + parseInt(1)
                  

                  
                  
                  _set_if_expression("W1tQSVhFTF9XSElURV9TVE9QXV0gPiA4");
                  _if(VAR_PIXEL_WHITE_STOP > 8,function(){
                  
                     
                     
                     VAR_PIXEL_WHITE_STOP = 0
                     

                     
                     
                     VAR_PIXEL_WHITE_NOW = 0
                     

                     
                     
                     VAR_TEMP_LIST.push(VAR_PIXEL_WHITE_MAX)
                     

                     
                     
                     VAR_PIXEL_WHITE_MAX = 0
                     

                  })!
                  

               })!
               

            })!
            

         })!
         

      })!
      

      
      
      _if(!_cycle_params().if_else,function(){
      
         
         
         _do(function(){
         _set_action_info({ name: "For" });
         VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(0)
         if(VAR_CYCLE_INDEX > parseInt(VAR_IMAGE_WIDTH - 1))_break();
         
            
            
            VAR_CYCLE_INDEX_X = VAR_CYCLE_INDEX
            

            
            
            VAR_NO_WHITE_PIXEL = 0
            

            
            
            VAR_NO_WHITE_PIXEL_DATA = 0
            

            
            
            _do(function(){
            _set_action_info({ name: "For" });
            VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(0)
            if(VAR_CYCLE_INDEX > parseInt(VAR_IMAGE_HEIGHT - 1))_break();
            
               
               
               {
               var split = native("imageprocessing", "getpixel", (VAR_LOADED_IMAGE_ID) + "," + (VAR_CYCLE_INDEX_X) + "," + (VAR_CYCLE_INDEX)).split(",")
               VAR_PIXEL_R = parseInt(split[0])
               VAR_PIXEL_G = parseInt(split[1])
               VAR_PIXEL_B = parseInt(split[2])
               VAR_PIXEL_A = parseInt(split[3])
               }
               

               
               
               _cycle_params().if_else = VAR_PIXEL_B >= 78;
               _set_if_expression("W1tQSVhFTF9CXV0gPj0gNzg=");
               _if(_cycle_params().if_else,function(){
               
                  
                  
                  VAR_PIXEL_WHITE_NOW = 1
                  

                  
                  
                  VAR_PIXEL_WHITE_MAX = parseInt(VAR_PIXEL_WHITE_MAX) + parseInt(1)
                  

               })!
               

               
               
               _if(!_cycle_params().if_else,function(){
               
                  
                  
                  VAR_NO_WHITE_PIXEL_DATA = parseInt(VAR_NO_WHITE_PIXEL_DATA) + parseInt(1)
                  

               })!
               delete _cycle_params().if_else;
               

            })!
            

            
            
            _set_if_expression("W1tOT19XSElURV9QSVhFTF9EQVRBXV0gKyA1ID49IFtbSU1BR0VfSEVJR0hUXV0=");
            _if(VAR_NO_WHITE_PIXEL_DATA + 5 >= VAR_IMAGE_HEIGHT,function(){
            
               
               
               VAR_NO_WHITE_PIXEL = parseInt(VAR_NO_WHITE_PIXEL) + parseInt(1)
               

            })!
            

            
            
            _set_if_expression("W1tOT19XSElURV9QSVhFTF1dID09IDE=");
            _if(VAR_NO_WHITE_PIXEL == 1,function(){
            
               
               
               _set_if_expression("W1tQSVhFTF9XSElURV9OT1ddXSA9PSAx");
               _if(VAR_PIXEL_WHITE_NOW == 1,function(){
               
                  
                  
                  VAR_PIXEL_WHITE_STOP = parseInt(VAR_PIXEL_WHITE_STOP) + parseInt(1)
                  

                  
                  
                  _set_if_expression("W1tQSVhFTF9XSElURV9TVE9QXV0gPiA4");
                  _if(VAR_PIXEL_WHITE_STOP > 8,function(){
                  
                     
                     
                     VAR_PIXEL_WHITE_STOP = 0
                     

                     
                     
                     VAR_PIXEL_WHITE_NOW = 0
                     

                     
                     
                     VAR_TEMP_LIST.push(VAR_PIXEL_WHITE_MAX)
                     

                     
                     
                     VAR_PIXEL_WHITE_MAX = 0
                     

                  })!
                  

               })!
               

            })!
            

         })!
         

      })!
      delete _cycle_params().if_else;
      

      
      
      _do(function(){
      _set_action_info({ name: "For" });
      VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
      if(VAR_CYCLE_INDEX > parseInt(99))_break();
      
         
         
         VAR_TEMP_LIST = VAR_TEMP_LIST.filter(function(e){return e!== VAR_CYCLE_INDEX })
         

      })!
      

      
      
      VAR_COUNT_TEMP_INDEX = [
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
      ]
      

      
      
      _do(function(){
      _set_action_info({ name: "For" });
      VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
      if(VAR_CYCLE_INDEX > parseInt(100))_break();
      
         
         
         var numbers = VAR_TEMP_LIST
         var count = {};
         var leastFrequentNumber;
         var leastFrequentIndex;
         var minmaxdif = VAR_CYCLE_INDEX;
         // Підрахунок кількості входжень кожного числа
         for (var i = 0; i < numbers.length; i++) {
         var number = numbers[i];
         // Враховуємо різницю в 2 як одне число
         var adjustedNumber = Math.floor(number / minmaxdif) * minmaxdif;
         if (count[adjustedNumber] === undefined) {
         count[adjustedNumber] = 1;
         } else {
         count[adjustedNumber]++;
         }
         }
         // Пошук найрідше зустрічаються числа та їх індексу
         var minFrequency = Infinity;
         for (var j = 0; j < numbers.length; j++) {
         var currentNumber = numbers[j];
         var adjustedCurrentNumber = Math.floor(currentNumber / minmaxdif) * minmaxdif;
         if (count[adjustedCurrentNumber] < minFrequency) {
         minFrequency = count[adjustedCurrentNumber];
         leastFrequentNumber = currentNumber;
         leastFrequentIndex = j;
         }
         }
         totalCount = Object.keys(count).length;
         VAR_DEBUG_TEMP = totalCount
         VAR_LOW_INDEX = leastFrequentIndex;
         VAR_LOW_INDEX = VAR_LOW_INDEX + 1
         

         
         
         _set_if_expression("W1tERUJVR19URU1QXV0gPiAx");
         _if(VAR_DEBUG_TEMP > 1,function(){
         
            
            
            VAR_LIST_ELEMENT = (VAR_COUNT_TEMP_INDEX)[VAR_LOW_INDEX];
            

            
            
            VAR_LIST_ELEMENT = parseInt(VAR_LIST_ELEMENT) + parseInt(1)
            

            
            
            VAR_COUNT_TEMP_INDEX[(VAR_LOW_INDEX < 0) ? (VAR_COUNT_TEMP_INDEX.length + VAR_LOW_INDEX) : VAR_LOW_INDEX] = VAR_LIST_ELEMENT;
            

         })!
         

      })!
      

      
      
      _do(function(){
      _set_action_info({ name: "For" });
      VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(0)
      if(VAR_CYCLE_INDEX > parseInt(100))_break();
      
         
         
         VAR_TEMP_VARIABLE = 100 - VAR_CYCLE_INDEX
         

         
         
         VAR_VALUE_INDEX = (VAR_COUNT_TEMP_INDEX).indexOf(VAR_TEMP_VARIABLE)
         

         
         
         _set_if_expression("W1tWQUxVRV9JTkRFWF1dICE9IC0x");
         _if(VAR_VALUE_INDEX != -1,function(){
         
            
            
            _break("function")
            

         })!
         

      })!
      

      
      
      VAR_LOW_INDEX = VAR_VALUE_INDEX
      

      
      
      VAR_LIST_LENGTH = (VAR_TEMP_LIST).length
      

      
      
      native("imageprocessing", "delete", VAR_LOADED_IMAGE_ID)
      

      
      
      VAR_TEMP_INDEX = parseInt((((100/VAR_LIST_LENGTH) * VAR_LOW_INDEX) - 100/VAR_LIST_LENGTH/2) - 2)
      

      
      
      /*Browser*/
      move(VAR_X_L + (VAR_WITH_DATA * (VAR_TEMP_INDEX/100)),VAR_Y_L + (VAR_HEIGHT_DATA/2),  {} )!
      mouse(VAR_X_L + (VAR_WITH_DATA * (VAR_TEMP_INDEX/100)),VAR_Y_L + (VAR_HEIGHT_DATA/2))!
      

      
      
      _set_if_expression("ZmFsc2U=");
      _if(false,function(){
      
         
         
         /*Browser*/
         _SELECTOR = " \u003eCSS\u003e .iconcaptcha-modal__body-selection \u003ei";
         wait_element(_SELECTOR)!
         get_element_selector(_SELECTOR, false).set_attr("style", "display: inline; top: 40%; left: " + VAR_TEMP_INDEX + "%;")!
         

         
         
         /*Browser*/
         _SELECTOR = " \u003eCSS\u003e .iconcaptcha-modal__body-selection \u003ei";
         wait_element_visible(_SELECTOR)!
         _call(_random_point, {})!
         _if(_result().length > 0, function(){
         move( {} )!
         get_element_selector(_SELECTOR, false).clarify(X,Y)!
         _call(_clarify, {} )!
         mouse(X,Y)!
         })!
         

      })!
      

   }
   

function GoodXevilPaySolver_GXP_ForAutosolveReHCaptcha()
   {
   
      
      
      VAR_HCAPTCHA_USE = _function_argument("hCaptcha_USE")
      

      
      
      VAR_RECAPTCHA_USE = _function_argument("ReCaptcha_USE")
      

      
      
      VAR_RECAPTCHA_USE = parseInt(VAR_RECAPTCHA_USE)
      

      
      
      VAR_HCAPTCHA_USE = parseInt(VAR_HCAPTCHA_USE)
      

      
      
      _set_if_expression("W1tIQ0FQVENIQV9VU0VdXSAhPSAwICYmIFtbSENBUFRDSEFfVVNFXV0gIT0gMQ==");
      _if(VAR_HCAPTCHA_USE != 0 && VAR_HCAPTCHA_USE != 1,function(){
      
         
         
         VAR_HCAPTCHA_USE = 1
         

      })!
      

      
      
      _set_if_expression("W1tSRUNBUFRDSEFfVVNFXV0gIT0gMCAmJiBbW1JFQ0FQVENIQV9VU0VdXSAhPSAx");
      _if(VAR_RECAPTCHA_USE != 0 && VAR_RECAPTCHA_USE != 1,function(){
      
         
         
         VAR_RECAPTCHA_USE = 1
         

      })!
      

      
      
      _L["Path"] = {"ru":"Путь"};
      _L["To path"] = {"ru":"До пути"};
      _L["From path"] = {"ru":"От пути"};
      _L["Path object"] = {"ru":"Объект пути"};
      _L["File extension to remove"] = {"ru":"Удаляемое расширение файла"};
      _path = {
      sep: '/',
      delimiter: ';',
      isPathSeparator: function(code){
      return code===47 || code===92;
      },
      isDeviceRoot: function(code){
      return code >= 65 && code <= 90 || code >= 97 && code <= 122;
      },
      normalizeString: function(path, allowAboveRoot){
      var res = '';
      var lastSegmentLength = 0;
      var lastSlash = -1;
      var dots = 0;
      var code = 0;
      for(var i = 0; i <= path.length; ++i){
      if(i < path.length){
      code = path.charCodeAt(i);
      }else if(this.isPathSeparator(code)){
      break;
      }else{
      code = 47;
      };
      if(this.isPathSeparator(code)){
      if(lastSlash===i-1 || dots===1){
      }else if(dots === 2){
      if(res.length < 2 || !(lastSegmentLength===2) || !(res.charCodeAt(res.length-1)===46) || !(res.charCodeAt(res.length-2)===46)){
      if(res.length > 2){
      const lastSlashIndex = res.lastIndexOf(this.sep);
      if(lastSlashIndex===-1){
      res = '';
      lastSegmentLength = 0;
      }else{
      res = res.slice(0, lastSlashIndex);
      lastSegmentLength = res.length - 1 - res.lastIndexOf(this.sep);
      };
      lastSlash = i;
      dots = 0;
      continue;
      }else if(!(res.length===0)){
      res = '';
      lastSegmentLength = 0;
      lastSlash = i;
      dots = 0;
      continue;
      };
      };
      if(allowAboveRoot){
      res += res.length > 0 ? (this.sep + '..') : '..';
      lastSegmentLength = 2;
      };
      }else{
      if (res.length > 0){
      res += this.sep + path.slice(lastSlash + 1, i);
      }else{
      res = path.slice(lastSlash + 1, i);
      };
      lastSegmentLength = i - lastSlash - 1;
      };
      lastSlash = i;
      dots = 0;
      }else if(code===46 && !(dots===-1)){
      ++dots;
      }else{
      dots = -1;
      };
      };
      return res;
      },
      resolve: function(args){
      if(!Array.isArray(args)){
      args = Array.prototype.slice.call(arguments);
      };
      var resolvedDevice = '';
      var resolvedTail = '';
      var resolvedAbsolute = false;
      for(var i = args.length - 1; i > -1; i--){
      var path = args[i];
      _validate_argument_type(path, 'string', 'Path', '_path.resolve');
      if(path.length===0){
      continue;
      };
      const len = path.length;
      var rootEnd = 0;
      var device = '';
      var isAbsolute = false;
      const code = path.charCodeAt(0);
      if(len===1){
      if(this.isPathSeparator(code)){
      rootEnd = 1;
      isAbsolute = true;
      };
      }else if(this.isPathSeparator(code)){
      isAbsolute = true;
      if(this.isPathSeparator(path.charCodeAt(1))){
      var j = 2;
      var last = j;
      while(j < len && !this.isPathSeparator(path.charCodeAt(j))){
      j++;
      };
      if(j < len && !(j===last)){
      const firstPart = path.slice(last, j);
      last = j;
      while(j < len && this.isPathSeparator(path.charCodeAt(j))){
      j++;
      };
      if(j < len && !(j===last)){
      last = j;
      while(j < len && !this.isPathSeparator(path.charCodeAt(j))){
      j++;
      };
      if(j===len || !(j===last)){
      device = this.sep + this.sep + firstPart + this.sep + path.slice(last, j);
      rootEnd = j;
      };
      };
      };
      }else{
      rootEnd = 1;
      };
      }else if(this.isDeviceRoot(code) && path.charCodeAt(1)===58){
      device = path.slice(0, 2);
      rootEnd = 2;
      if(len > 2 && this.isPathSeparator(path.charCodeAt(2))){
      isAbsolute = true;
      rootEnd = 3;
      };
      };
      if(device.length > 0){
      if(resolvedDevice.length > 0){
      if(!(device.toLowerCase()===resolvedDevice.toLowerCase())){
      continue;
      };
      }else{
      resolvedDevice = device;
      };
      };
      if(resolvedAbsolute){
      if(resolvedDevice.length > 0){
      break;
      };
      }else{
      resolvedTail = path.slice(rootEnd) + this.sep + resolvedTail;
      resolvedAbsolute = isAbsolute;
      if(isAbsolute && resolvedDevice.length > 0){
      break;
      };
      };
      };
      resolvedTail = this.normalizeString(resolvedTail, !resolvedAbsolute);
      return resolvedAbsolute ? resolvedDevice + this.sep + resolvedTail : (resolvedDevice + resolvedTail) || '.';
      },
      normalize: function(path, removeTrailingSlash){
      _validate_argument_type(path, 'string', 'Path', '_path.normalize');
      removeTrailingSlash = _avoid_nilb(removeTrailingSlash, true);
      _validate_argument_type(removeTrailingSlash, ['boolean', 'number'], 'Remove trailing slashes', '_path.normalize');
      const len = path.length;
      if(len===0){
      return '';
      };
      var rootEnd = 0;
      var device = undefined;
      var isAbsolute = false;
      const code = path.charCodeAt(0);
      if(len===1){
      return this.isPathSeparator(code) ? (removeTrailingSlash ? '' : this.sep) : path;
      };
      if(this.isPathSeparator(code)){
      isAbsolute = true;
      if(this.isPathSeparator(path.charCodeAt(1))){
      var j = 2;
      var last = j;
      while (j < len && !this.isPathSeparator(path.charCodeAt(j))){
      j++;
      };
      if(j < len && !(j===last)){
      const firstPart = path.slice(last, j);
      last = j;
      while (j < len && this.isPathSeparator(path.charCodeAt(j))){
      j++;
      };
      if(j < len && !(j===last)){
      last = j;
      while (j < len && !this.isPathSeparator(path.charCodeAt(j))){
      j++;
      };
      if(j===len){
      return (this.sep + this.sep + firstPart + this.sep + path.slice(last) + (removeTrailingSlash ? '' : this.sep));
      };
      if(!(j===last)){
      device = this.sep + this.sep + firstPart + this.sep + path.slice(last, j);
      rootEnd = j;
      };
      };
      };
      }else{
      rootEnd = 1;
      };
      }else if(this.isDeviceRoot(code) && path.charCodeAt(1)===58){
      device = path.slice(0, 2);
      rootEnd = 2;
      if(len > 2 && this.isPathSeparator(path.charCodeAt(2))){
      isAbsolute = true;
      rootEnd = 3;
      };
      };
      var tail = rootEnd < len ? this.normalizeString(path.slice(rootEnd), !isAbsolute) : '';
      if(tail.length > 0 && this.isPathSeparator(path.charCodeAt(len - 1)) && !removeTrailingSlash){
      tail += this.sep;
      };
      if(device===undefined){
      return isAbsolute ? ((tail.length===0 && removeTrailingSlash ? '' : this.sep) + tail) : tail;
      };
      return isAbsolute ? (device + (tail.length===0 && removeTrailingSlash ? '' : this.sep) + tail) : (device + tail);
      },
      isAbsolute: function(path){
      _validate_argument_type(path, 'string', 'Path', '_path.isAbsolute');
      const len = path.length;
      if(len===0){
      return false;
      };
      const code = path.charCodeAt(0);
      return this.isPathSeparator(code) || len > 2 && this.isDeviceRoot(code) && path.charCodeAt(1) === 58 && this.isPathSeparator(path.charCodeAt(2));
      },
      join: function(args){
      if(!Array.isArray(args)){
      args = Array.prototype.slice.call(arguments);
      };
      if(args.length===0){
      return '.';
      };
      var joined = undefined;
      var firstPart = undefined;
      for(var i = 0; i < args.length; ++i){
      const arg = args[i];
      _validate_argument_type(arg, 'string', 'Path', '_path.join');
      if(arg.length > 0){
      if(joined === undefined){
      joined = firstPart = arg;
      }else{
      joined += (this.sep + arg);
      };
      };
      };
      if(joined === undefined){
      return '.';
      };
      var needsReplace = true;
      var slashCount = 0;
      if(this.isPathSeparator(firstPart.charCodeAt(0))){
      ++slashCount;
      const firstLen = firstPart.length;
      if(firstLen > 1 && this.isPathSeparator(firstPart.charCodeAt(1))){
      ++slashCount;
      if(firstLen > 2){
      if(this.isPathSeparator(firstPart.charCodeAt(2))){
      ++slashCount;
      }else{
      needsReplace = false;
      };
      };
      };
      };
      if(needsReplace){
      while(slashCount < joined.length && this.isPathSeparator(joined.charCodeAt(slashCount))){
      slashCount++;
      };
      if(slashCount >= 2){
      joined = this.sep + joined.slice(slashCount);
      };
      };
      return this.normalize(joined);
      },
      relative: function(from, to){
      _validate_argument_type(from, 'string', 'From path', '_path.relative');
      _validate_argument_type(to, 'string', 'To path', '_path.relative');
      if(from===to){
      return '';
      };
      const fromOrig = this.resolve(from);
      const toOrig = this.resolve(to);
      if(fromOrig===toOrig){
      return '';
      };
      from = fromOrig.toLowerCase();
      to = toOrig.toLowerCase();
      if(from===to){
      return '';
      };
      var fromStart = 0;
      while(fromStart < from.length && from.charCodeAt(fromStart)===this.sep.charCodeAt(0)){
      fromStart++;
      };
      var fromEnd = from.length;
      while(fromEnd - 1 > fromStart && from.charCodeAt(fromEnd - 1)===this.sep.charCodeAt(0)){
      fromEnd--;
      };
      const fromLen = fromEnd - fromStart;
      var toStart = 0;
      while(toStart < to.length && to.charCodeAt(toStart)===this.sep.charCodeAt(0)){
      toStart++;
      };
      var toEnd = to.length;
      while(toEnd - 1 > toStart && to.charCodeAt(toEnd - 1)===this.sep.charCodeAt(0)){
      toEnd--;
      };
      const toLen = toEnd - toStart;
      const length = fromLen < toLen ? fromLen : toLen;
      var lastCommonSep = -1;
      var i = 0;
      for(; i < length; i++){
      const fromCode = from.charCodeAt(fromStart + i);
      if(!(fromCode===to.charCodeAt(toStart + i))){
      break;
      }else if(fromCode===this.sep.charCodeAt(0)){
      lastCommonSep = i;
      };
      };
      if(!(i===length)){
      if(lastCommonSep===-1){
      return toOrig;
      };
      }else{
      if(toLen > length){
      if(to.charCodeAt(toStart + i)===this.sep.charCodeAt(0)){
      return toOrig.slice(toStart + i + 1);
      };
      if(i===2){
      return toOrig.slice(toStart + i);
      };
      };
      if(fromLen > length){
      if(from.charCodeAt(fromStart + i)===this.sep.charCodeAt(0)){
      lastCommonSep = i;
      }else if(i===2){
      lastCommonSep = 3;
      };
      };
      if(lastCommonSep===-1){
      lastCommonSep = 0;
      };
      };
      var out = '';
      for(i = fromStart + lastCommonSep + 1; i <= fromEnd; ++i){
      if(i===fromEnd || from.charCodeAt(i)===this.sep.charCodeAt(0)){
      out += out.length===0 ? '..' : this.sep + '..';
      };
      };
      toStart += lastCommonSep;
      if(out.length > 0){
      return out + toOrig.slice(toStart, toEnd);
      };
      if(toOrig.charCodeAt(toStart)===this.sep.charCodeAt(0)){
      ++toStart;
      };
      return toOrig.slice(toStart, toEnd);
      },
      toNamespacedPath: function(path){
      if(typeof path!='string'){
      return path;
      };
      if(path.length===0){
      return '';
      };
      const resolvedPath = this.resolve(path);
      if(resolvedPath.length <= 2){
      return path;
      };
      if(resolvedPath.charCodeAt(0)===this.sep.charCodeAt(0)){
      if(resolvedPath.charCodeAt(1)===this.sep.charCodeAt(0)){
      const code = resolvedPath.charCodeAt(2);
      if(!(code===63) && !(code===46)){
      return (this.sep + this.sep + '?' + this.sep + 'UNC' + this.sep + resolvedPath.slice(2));
      };
      };
      }else if(this.isDeviceRoot(resolvedPath.charCodeAt(0)) && resolvedPath.charCodeAt(1)===58 && resolvedPath.charCodeAt(2)===this.sep.charCodeAt(0)){
      return (this.sep + this.sep + '?' + this.sep + resolvedPath);
      };
      return path;
      },
      dirname: function(path){
      _validate_argument_type(path, 'string', 'Path', '_path.dirname');
      const len = path.length;
      if(len===0){
      return '.';
      };
      var rootEnd = -1;
      var offset = 0;
      const code = path.charCodeAt(0);
      if(len===1){
      return this.isPathSeparator(code) ? path : '.';
      };
      if(this.isPathSeparator(code)){
      rootEnd = offset = 1;
      if(this.isPathSeparator(path.charCodeAt(1))){
      var j = 2;
      var last = j;
      while(j < len && !this.isPathSeparator(path.charCodeAt(j))){
      j++;
      };
      if(j < len && !(j===last)){
      last = j;
      while(j < len && this.isPathSeparator(path.charCodeAt(j))){
      j++;
      };
      if(j < len && !(j===last)){
      last = j;
      while (j < len && !this.isPathSeparator(path.charCodeAt(j))){
      j++;
      };
      if(j===len){
      return path;
      };
      if(!(j===last)){
      rootEnd = offset = j + 1;
      };
      };
      };
      };
      }else if(this.isDeviceRoot(code) && path.charCodeAt(1)===58){
      rootEnd = len > 2 && this.isPathSeparator(path.charCodeAt(2)) ? 3 : 2;
      offset = rootEnd;
      };
      var end = -1;
      var matchedSlash = true;
      for(var i = len - 1; i >= offset; --i){
      if(this.isPathSeparator(path.charCodeAt(i))){
      if(!matchedSlash){
      end = i;
      break;
      };
      }else{
      matchedSlash = false;
      };
      };
      if(end===-1){
      if(rootEnd===-1){
      return '.';
      };
      end = rootEnd;
      };
      return path.slice(0, end);
      },
      basename: function(path, ext){
      _validate_argument_type(path, 'string', 'Path', '_path.basename');
      _validate_argument_type(ext, ['string','undefined','null'], 'File extension to remove', '_path.basename');
      var start = 0;
      var end = -1;
      var matchedSlash = true;
      var i = 0;
      if(path.length >= 2 && this.isDeviceRoot(path.charCodeAt(0)) && path.charCodeAt(1)===58){
      start = 2;
      };
      if(!(_is_nilb(ext)) && ext.length > 0 && ext.length <= path.length){
      if(ext===path){
      return '';
      };
      var extIdx = ext.length - 1;
      var firstNonSlashEnd = -1;
      for(i = path.length - 1; i >= start; --i){
      const code = path.charCodeAt(i);
      if(this.isPathSeparator(code)){
      if(!matchedSlash){
      start = i + 1;
      break;
      };
      }else{
      if(firstNonSlashEnd===-1){
      matchedSlash = false;
      firstNonSlashEnd = i + 1;
      };
      if(ext==='*'){
      if(code===46 && end===-1){
      end = i;
      };
      }else{
      if(extIdx >= 0){
      if(code===ext.charCodeAt(extIdx)){
      if(--extIdx===-1){
      end = i;
      };
      }else{
      extIdx = -1;
      end = firstNonSlashEnd;
      };
      };
      };
      };
      };
      if(start===end){
      end = firstNonSlashEnd;
      }else if(end === -1){
      end = path.length;
      };
      return path.slice(start, end);
      };
      for(i = path.length - 1; i >= start; --i){
      if(this.isPathSeparator(path.charCodeAt(i))){
      if(!matchedSlash){
      start = i + 1;
      break;
      };
      }else if(end===-1){
      matchedSlash = false;
      end = i + 1;
      };
      };
      if(end===-1){
      return '';
      };
      return path.slice(start, end);
      },
      extname: function(path){
      _validate_argument_type(path, 'string', 'Path', '_path.extname');
      var start = 0;
      var startDot = -1;
      var startPart = 0;
      var end = -1;
      var matchedSlash = true;
      var preDotState = 0;
      if(path.length >= 2 && path.charCodeAt(1)===58 && this.isDeviceRoot(path.charCodeAt(0))){
      start = startPart = 2;
      };
      for(var i = path.length - 1; i >= start; --i){
      const code = path.charCodeAt(i);
      if(this.isPathSeparator(code)){
      if(!matchedSlash){
      startPart = i + 1;
      break;
      };
      continue;
      };
      if(end===-1){
      matchedSlash = false;
      end = i + 1;
      };
      if(code===46){
      if(startDot===-1){
      startDot = i;
      }else if(!(preDotState===1)){
      preDotState = 1;
      };
      }else if(!(startDot===-1)){
      preDotState = -1;
      };
      };
      if(startDot===-1 || end===-1 || preDotState===0 || (preDotState===1 && startDot===end - 1 && startDot===startPart + 1)){
      return '';
      };
      return path.slice(startDot, end);
      },
      format: function(pathObject){
      _validate_argument_type(pathObject, 'object', 'Path object', '_path.format');
      var dir = pathObject.dir || pathObject.root;
      var base = pathObject.base || (pathObject.name || '' + pathObject.ext || '');
      if(!dir){
      return base;
      };
      return dir===pathObject.root ? (dir + base) : (dir + this.sep + base);
      },
      parse: function(path){
      _validate_argument_type(path, 'string', 'Path', '_path.parse');
      const ret = { root: '', dir: '', base: '', ext: '', name: '', items: [] };
      if(path.length===0){
      return ret;
      };
      const len = path.length;
      var rootEnd = 0;
      var code = path.charCodeAt(0);
      if(len===1){
      if(this.isPathSeparator(code)){
      ret.root = ret.dir = path;
      return ret;
      };
      ret.base = ret.name = ret.items[0] = path;
      return ret;
      };
      ret.items = path.split(/[\\/]+/).filter(function(el){return el.length > 0});
      if(this.isPathSeparator(code)){
      rootEnd = 1;
      if(this.isPathSeparator(path.charCodeAt(1))){
      var j = 2;
      var last = j;
      while(j < len && !this.isPathSeparator(path.charCodeAt(j))){
      j++;
      };
      if(j < len && !(j===last)){
      last = j;
      while (j < len && this.isPathSeparator(path.charCodeAt(j))){
      j++;
      };
      if(j < len && !(j===last)){
      last = j;
      while (j < len && !this.isPathSeparator(path.charCodeAt(j))){
      j++;
      };
      if(j===len){
      rootEnd = j;
      }else if(!(j===last)){
      rootEnd = j + 1;
      };
      };
      };
      };
      }else if(this.isDeviceRoot(code) && path.charCodeAt(1)===58){
      if(len <= 2){
      ret.root = ret.dir = path;
      return ret;
      };
      rootEnd = 2;
      if(this.isPathSeparator(path.charCodeAt(2))){
      if (len===3){
      ret.root = ret.dir = path;
      return ret;
      };
      rootEnd = 3;
      };
      };
      if(rootEnd > 0){
      ret.root = path.slice(0, rootEnd);
      };
      var startDot = -1;
      var startPart = rootEnd;
      var end = -1;
      var matchedSlash = true;
      var i = path.length - 1;
      var preDotState = 0;
      for(; i >= rootEnd; --i){
      code = path.charCodeAt(i);
      if(this.isPathSeparator(code)){
      if(!matchedSlash){
      startPart = i + 1;
      break;
      };
      continue;
      };
      if(end===-1){
      matchedSlash = false;
      end = i + 1;
      };
      if(code===46){
      if(startDot===-1){
      startDot = i;
      }else if(!(preDotState===1)){
      preDotState = 1;
      };
      }else if(!(startDot===-1)){
      preDotState = -1;
      };
      };
      if(!(end===-1)){
      if(startDot===-1 || preDotState === 0 || (preDotState===1 && startDot===end-1 && startDot===startPart+1)){
      ret.base = ret.name = path.slice(startPart, end);
      }else{
      ret.name = path.slice(startPart, startDot);
      ret.base = path.slice(startPart, end);
      ret.ext = path.slice(startDot, end);
      };
      };
      if(startPart > 0 && !(startPart===rootEnd)){
      ret.dir = path.slice(0, startPart - 1);
      }else{
      ret.dir = ret.root;
      };
      return ret;
      }
      };
      function project_directory(){
      var path = project_path();
      var c = '';
      var s = 0;
      var end = -1;
      for(var i = path.length - 1; i > -1; i--){
      if(_path.isPathSeparator(path.charCodeAt(i))){
      s++;
      if(c==='appsremote' || c==='appslocal'){
      end = i;
      break;
      }else{
      if(s===1){
      end = i;
      if(!(c==='project.xml')){
      break;
      };
      };
      if(s===2 && !(c==='engine')){
      break;
      };
      c = '';
      };
      }else{
      c = path.charAt(i) + c;
      };
      };
      return end===-1 ? _path.dirname(path) : path.slice(0, end);
      };
      function installation_path(){
      return JSON.parse(native("filesystem", "fileinfo", "settings.ini")).directory;
      };
      function _get_system_data(){
      RANDOM_FILE = "temp_" + rand() + ".bat";
      native("filesystem","writefile",JSON.stringify({path:RANDOM_FILE,value:"chcp 65001\r\nSET",base64:false,append:false}));
      native_async("processmanager","start",JSON.stringify({location:RANDOM_FILE,working_folder:"",waitfinish:true,arguments:"",version:2}))!
      var data_list = base64_decode(_result().split(",")[0]).split('\r\n').slice(2,-1);
      sleep(1000)!
      native("filesystem","removefile",RANDOM_FILE);
      SYSTEM_ENV_DATA = {};
      for(var i = 0; i < data_list.length; i++){
      if(data_list[i].indexOf('=') > -1){
      var data = data_list[i].split('=');
      var name = data[0];
      var value = data[1];
      SYSTEM_ENV_DATA[name] = value.indexOf("\\") > -1 ? _path.normalize(value) : value;
      };
      };
      if(SYSTEM_ENV_DATA["USERPROFILE"]){
      ["Desktop","Downloads","Documents","Pictures","Videos","Music","Favorites"].forEach(function(e){SYSTEM_ENV_DATA[e] = _path.join(SYSTEM_ENV_DATA["USERPROFILE"], e)});
      };
      };
      function _get_system_path(){
      var name = _function_argument("name");
      _if(typeof SYSTEM_ENV_DATA=="undefined",function(){
      _call_function(_get_system_data,{})!
      _result_function();
      })!
      var labels = {
      "App Data":"APPDATA",
      "Local App Data": "LOCALAPPDATA",
      "Program Files":"ProgramFiles",
      "Program Files (x86)":"ProgramFiles(x86)",
      "Program Data":"ProgramData",
      "Public":"PUBLIC",
      "System Drive":"SystemDrive",
      "System Root":"SystemRoot",
      "Windows Directory":"windir",
      "Temp":"TEMP",
      "User Name":"USERNAME",
      "User Profile":"USERPROFILE",
      "Computer Name":"COMPUTERNAME"
      };
      var label = _avoid_nilb(labels[name], name);
      if(_is_nilb(SYSTEM_ENV_DATA[label])){
      fail(_K=="ru" ? 'Не удалось найти путь "' + name + '" в системных данных.' : 'Could not find path "' + name + '" in system data.');
      };
      _function_return(SYSTEM_ENV_DATA[label]);
      };
      

      
      
      VAR_PROJECT_DIRECTORY = project_directory()
      

      
      
      _set_if_expression("dHJ1ZQ==");
      _if(true,function(){
      
         
         
         var json = JSON.parse(native("filesystem", "fileinfo", VAR_PROJECT_DIRECTORY + "/CaptchaAutoSolver/content"))
         VAR_FILEINFO_EXISTS = json["exists"]
         VAR_1 = json["size"]
         VAR_1 = json["directory"]
         VAR_1 = json["is_directory"]
         VAR_1 = new Date(json["last_modified"] * 1000)
         

         
         
         _set_if_expression("W1tGSUxFSU5GT19FWElTVFNdXSA9PSBmYWxzZQ==");
         _if(VAR_FILEINFO_EXISTS == false,function(){
         
            
            
            native("filesystem", "createdir", VAR_PROJECT_DIRECTORY + "/CaptchaAutoSolver/content")
            

         })!
         

         
         
         var json = JSON.parse(native("filesystem", "fileinfo", VAR_PROJECT_DIRECTORY + "/CaptchaAutoSolver/content/hcaptcha"))
         VAR_FILEINFO_EXISTS = json["exists"]
         VAR_1 = json["size"]
         VAR_1 = json["directory"]
         VAR_1 = json["is_directory"]
         VAR_1 = new Date(json["last_modified"] * 1000)
         

         
         
         _set_if_expression("W1tGSUxFSU5GT19FWElTVFNdXSA9PSBmYWxzZQ==");
         _if(VAR_FILEINFO_EXISTS == false,function(){
         
            
            
            native("filesystem", "createdir", VAR_PROJECT_DIRECTORY + "/CaptchaAutoSolver/content/hcaptcha")
            

         })!
         

         
         
         var json = JSON.parse(native("filesystem", "fileinfo", VAR_PROJECT_DIRECTORY + "/CaptchaAutoSolver/content/recaptcha"))
         VAR_FILEINFO_EXISTS = json["exists"]
         VAR_1 = json["size"]
         VAR_1 = json["directory"]
         VAR_1 = json["is_directory"]
         VAR_1 = new Date(json["last_modified"] * 1000)
         

         
         
         _set_if_expression("W1tGSUxFSU5GT19FWElTVFNdXSA9PSBmYWxzZQ==");
         _if(VAR_FILEINFO_EXISTS == false,function(){
         
            
            
            native("filesystem", "createdir", VAR_PROJECT_DIRECTORY + "/CaptchaAutoSolver/content/recaptcha")
            

         })!
         

      })!
      

      
      
      _set_if_expression("dHJ1ZQ==");
      _if(true,function(){
      
         
         
         VAR_TEMP_DATA = "ew0KICAgImNvbnRlbnRfc2NyaXB0cyI6IFsgew0KICAgICAgImFsbF9mcmFtZXMiOiB0cnVlLA0KICAgICAgImpzIjogWyJjb250ZW50L3NjcmlwdC5qcyJdLA0KICAgICAgIm1hdGNoZXMiOiBbICJcdTAwM0NhbGxfdXJscz4iIF0sDQogICAgICAicnVuX2F0IjogImRvY3VtZW50X3N0YXJ0Ig0KICAgfSBdLA0KICAgImNvbnRlbnRfc2VjdXJpdHlfcG9saWN5Ijogew0KICAgICAgImV4dGVuc2lvbl9wYWdlcyI6ICJzY3JpcHQtc3JjICdzZWxmJzsgb2JqZWN0LXNyYyAnc2VsZiciDQogICB9LA0KICAgIm1hbmlmZXN0X3ZlcnNpb24iOiAzLA0KICAgIm5hbWUiOiAiSW5qZWN0aW9ucyIsDQogICAicGVybWlzc2lvbnMiOiBbICJzdG9yYWdlIiwgImNvbnRleHRNZW51cyIgXSwNCiAgICJ2ZXJzaW9uIjogIjEuMC41IiwNCiAgICJ3ZWJfYWNjZXNzaWJsZV9yZXNvdXJjZXMiOiBbIHsNCiAgICAgICJtYXRjaGVzIjogWyAiXHUwMDNDYWxsX3VybHM+IiBdLA0KICAgICAgInJlc291cmNlcyI6IFsgImNvbnRlbnQvKiIgXQ0KICAgfSBdDQp9DQo="
         

         
         
         var json = JSON.parse(native("filesystem", "fileinfo", VAR_PROJECT_DIRECTORY + "/CaptchaAutoSolver/manifest.json"))
         VAR_FILEINFO_EXISTS = json["exists"]
         VAR_1 = json["size"]
         VAR_1 = json["directory"]
         VAR_1 = json["is_directory"]
         VAR_1 = new Date(json["last_modified"] * 1000)
         

         
         
         _cycle_params().if_else = VAR_FILEINFO_EXISTS == false;
         _set_if_expression("W1tGSUxFSU5GT19FWElTVFNdXSA9PSBmYWxzZQ==");
         _if(_cycle_params().if_else,function(){
         
            
            
            native("filesystem", "writefile", JSON.stringify({path: VAR_PROJECT_DIRECTORY + "/CaptchaAutoSolver/manifest.json",value: (VAR_TEMP_DATA).toString(),base64:true,append:false}))
            

         })!
         

         
         
         _if(!_cycle_params().if_else,function(){
         
            
            
            VAR_FILE_CONTENT = native("filesystem", "readfile", JSON.stringify({value: VAR_PROJECT_DIRECTORY + "/CaptchaAutoSolver/manifest.json",base64:true,from:0,to:0}))
            

            
            
            _set_if_expression("W1tGSUxFX0NPTlRFTlRdXSAhPSBbW1RFTVBfREFUQV1d");
            _if(VAR_FILE_CONTENT != VAR_TEMP_DATA,function(){
            
               
               
               native("filesystem", "writefile", JSON.stringify({path: VAR_PROJECT_DIRECTORY + "/CaptchaAutoSolver/manifest.json",value: (VAR_TEMP_DATA).toString(),base64:true,append:false}))
               

            })!
            

         })!
         delete _cycle_params().if_else;
         

      })!
      

      
      
      _set_if_expression("dHJ1ZQ==");
      _if(true,function(){
      
         
         
         _cycle_params().if_else = VAR_RECAPTCHA_USE == 1 && VAR_HCAPTCHA_USE == 1;
         _set_if_expression("W1tSRUNBUFRDSEFfVVNFXV0gPT0gMSAmJiBbW0hDQVBUQ0hBX1VTRV1dID09IDE=");
         _if(_cycle_params().if_else,function(){
         
            
            
            VAR_TEMP_DATA = "bGV0IHNjcmlwdHMgPSBbDQoJWyJjb250ZW50L2hjYXB0Y2hhL2ludGVyY2VwdG9yLmpzIl0sDQoJWyJjb250ZW50L2hjYXB0Y2hhL2h1bnRlci5qcyJdLA0KCVsiY29udGVudC9yZWNhcHRjaGEvaW50ZXJjZXB0b3IuanMiXSwNCglbImNvbnRlbnQvcmVjYXB0Y2hhL2h1bnRlci5qcyJdDQpdOw0Kc2NyaXB0cy5mb3JFYWNoKHMgPT4gew0KCWlmIChzLmxlbmd0aCA+IDEgJiYgIXNbMV0pIHtyZXR1cm47fQ0KCWxldCBzY3JpcHQgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdzY3JpcHQnKTsNCglzY3JpcHQuc3JjID0gY2hyb21lLnJ1bnRpbWUuZ2V0VVJMKHNbMF0pOw0KCShkb2N1bWVudC5oZWFkfHxkb2N1bWVudC5kb2N1bWVudEVsZW1lbnQpLnByZXBlbmQoc2NyaXB0KTsNCn0pOw=="
            

         })!
         

         
         
         _if(!_cycle_params().if_else,function(){
         
            
            
            _set_if_expression("W1tIQ0FQVENIQV9VU0VdXSA9PSAx");
            _if(VAR_HCAPTCHA_USE == 1,function(){
            
               
               
               VAR_TEMP_DATA = "bGV0IHNjcmlwdHMgPSBbDQoJWyJjb250ZW50L2hjYXB0Y2hhL2ludGVyY2VwdG9yLmpzIl0sDQoJWyJjb250ZW50L2hjYXB0Y2hhL2h1bnRlci5qcyJdDQpdOw0Kc2NyaXB0cy5mb3JFYWNoKHMgPT4gew0KCWlmIChzLmxlbmd0aCA+IDEgJiYgIXNbMV0pIHtyZXR1cm47fQ0KCWxldCBzY3JpcHQgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdzY3JpcHQnKTsNCglzY3JpcHQuc3JjID0gY2hyb21lLnJ1bnRpbWUuZ2V0VVJMKHNbMF0pOw0KCShkb2N1bWVudC5oZWFkfHxkb2N1bWVudC5kb2N1bWVudEVsZW1lbnQpLnByZXBlbmQoc2NyaXB0KTsNCn0pOw=="
               

            })!
            

            
            
            _set_if_expression("W1tSRUNBUFRDSEFfVVNFXV0gPT0gMQ==");
            _if(VAR_RECAPTCHA_USE == 1,function(){
            
               
               
               VAR_TEMP_DATA = "bGV0IHNjcmlwdHMgPSBbDQoJWyJjb250ZW50L3JlY2FwdGNoYS9pbnRlcmNlcHRvci5qcyJdLA0KCVsiY29udGVudC9yZWNhcHRjaGEvaHVudGVyLmpzIl0NCl07DQpzY3JpcHRzLmZvckVhY2gocyA9PiB7DQoJaWYgKHMubGVuZ3RoID4gMSAmJiAhc1sxXSkge3JldHVybjt9DQoJbGV0IHNjcmlwdCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ3NjcmlwdCcpOw0KCXNjcmlwdC5zcmMgPSBjaHJvbWUucnVudGltZS5nZXRVUkwoc1swXSk7DQoJKGRvY3VtZW50LmhlYWR8fGRvY3VtZW50LmRvY3VtZW50RWxlbWVudCkucHJlcGVuZChzY3JpcHQpOw0KfSk7"
               

            })!
            

         })!
         delete _cycle_params().if_else;
         

         
         
         var json = JSON.parse(native("filesystem", "fileinfo", VAR_PROJECT_DIRECTORY + "/CaptchaAutoSolver/content/script.js"))
         VAR_FILEINFO_EXISTS = json["exists"]
         VAR_1 = json["size"]
         VAR_1 = json["directory"]
         VAR_1 = json["is_directory"]
         VAR_1 = new Date(json["last_modified"] * 1000)
         

         
         
         _cycle_params().if_else = VAR_FILEINFO_EXISTS == false;
         _set_if_expression("W1tGSUxFSU5GT19FWElTVFNdXSA9PSBmYWxzZQ==");
         _if(_cycle_params().if_else,function(){
         
            
            
            native("filesystem", "writefile", JSON.stringify({path: VAR_PROJECT_DIRECTORY + "/CaptchaAutoSolver/content/script.js",value: (VAR_TEMP_DATA).toString(),base64:true,append:false}))
            

         })!
         

         
         
         _if(!_cycle_params().if_else,function(){
         
            
            
            VAR_FILE_CONTENT = native("filesystem", "readfile", JSON.stringify({value: VAR_PROJECT_DIRECTORY + "/CaptchaAutoSolver/content/script.js",base64:true,from:0,to:0}))
            

            
            
            _set_if_expression("W1tGSUxFX0NPTlRFTlRdXSAhPSBbW1RFTVBfREFUQV1d");
            _if(VAR_FILE_CONTENT != VAR_TEMP_DATA,function(){
            
               
               
               native("filesystem", "writefile", JSON.stringify({path: VAR_PROJECT_DIRECTORY + "/CaptchaAutoSolver/content/script.js",value: (VAR_TEMP_DATA).toString(),base64:true,append:false}))
               

            })!
            

         })!
         delete _cycle_params().if_else;
         

      })!
      

      
      
      _set_if_expression("dHJ1ZQ==");
      _if(true,function(){
      
         
         
         VAR_TEMP_DATA = "KCgpID0+IHsNCiAgICBjb25zdCBfaW50SWQgPSBzZXRJbnRlcnZhbCgoKSA9PiB7DQoJCWxldCB0ZXh0YXJlYSA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoInRleHRhcmVhW25hbWU9aC1jYXB0Y2hhLXJlc3BvbnNlXSIpOw0KCQlpZiAoIXRleHRhcmVhKSByZXR1cm47DQoJCWxldCBjb250YWluZXIgPSB0ZXh0YXJlYS5wYXJlbnROb2RlOw0KCQlpZiAoIWNvbnRhaW5lci5pZCkgew0KCQkJY29udGFpbmVyLmlkID0gImhjYXB0Y2hhLWNvbnRhaW5lci0iICsgRGF0ZS5ub3coKTsNCgkJfQ0KCQlpZihjb250YWluZXIuZGF0YXNldC5zaXRla2V5KXsNCgkJCWxldCBjYXB0Y2hhSW5mbyA9IHsNCgkJCQljb250YWluZXJJZDogY29udGFpbmVyLmlkLA0KCQkJCXNpdGVrZXk6IGNvbnRhaW5lci5kYXRhc2V0LnNpdGVrZXksDQoJCQkJY2FsbGJhY2s6IGNvbnRhaW5lci5kYXRhc2V0LmNhbGxiYWNrIHx8IG51bGwsDQoJCQl9Ow0KCQkJd2luZG93LmNhcHRjaGFJbmZvaHR3byA9IGNhcHRjaGFJbmZvOw0KCQkJY2xlYXJJbnRlcnZhbChfaW50SWQpOw0KCQl9DQogICAgfSwgMzAwMCk7DQoNCn0pKCk="
         

         
         
         var json = JSON.parse(native("filesystem", "fileinfo", VAR_PROJECT_DIRECTORY + "/CaptchaAutoSolver/content/hcaptcha/hunter.js"))
         VAR_FILEINFO_EXISTS = json["exists"]
         VAR_1 = json["size"]
         VAR_1 = json["directory"]
         VAR_1 = json["is_directory"]
         VAR_1 = new Date(json["last_modified"] * 1000)
         

         
         
         _cycle_params().if_else = VAR_FILEINFO_EXISTS == false;
         _set_if_expression("W1tGSUxFSU5GT19FWElTVFNdXSA9PSBmYWxzZQ==");
         _if(_cycle_params().if_else,function(){
         
            
            
            native("filesystem", "writefile", JSON.stringify({path: VAR_PROJECT_DIRECTORY + "/CaptchaAutoSolver/content/hcaptcha/hunter.js",value: (VAR_TEMP_DATA).toString(),base64:true,append:false}))
            

         })!
         

         
         
         _if(!_cycle_params().if_else,function(){
         
            
            
            VAR_FILE_CONTENT = native("filesystem", "readfile", JSON.stringify({value: VAR_PROJECT_DIRECTORY + "/CaptchaAutoSolver/content/hcaptcha/hunter.js",base64:true,from:0,to:0}))
            

            
            
            _set_if_expression("W1tGSUxFX0NPTlRFTlRdXSAhPSBbW1RFTVBfREFUQV1d");
            _if(VAR_FILE_CONTENT != VAR_TEMP_DATA,function(){
            
               
               
               native("filesystem", "writefile", JSON.stringify({path: VAR_PROJECT_DIRECTORY + "/CaptchaAutoSolver/content/hcaptcha/hunter.js",value: (VAR_TEMP_DATA).toString(),base64:true,append:false}))
               

            })!
            

         })!
         delete _cycle_params().if_else;
         

      })!
      

      
      
      _set_if_expression("dHJ1ZQ==");
      _if(true,function(){
      
         
         
         VAR_TEMP_DATA = "KCgpID0+IHsNCiAgICBsZXQgaENhcHRjaGFJbnN0YW5jZTsNCiAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkod2luZG93LCAiaGNhcHRjaGEiLCB7DQogICAgICAgIGdldDogZnVuY3Rpb24gKCkgew0KICAgICAgICAgICAgcmV0dXJuIGhDYXB0Y2hhSW5zdGFuY2U7DQogICAgICAgIH0sDQogICAgICAgIHNldDogZnVuY3Rpb24gKGUpIHsNCiAgICAgICAgICAgIGhDYXB0Y2hhSW5zdGFuY2UgPSBlOw0KDQogICAgICAgICAgICBsZXQgb3JpZ2luYWxSZW5kZXJGdW5jID0gZS5yZW5kZXI7DQoNCiAgICAgICAgICAgIGhDYXB0Y2hhSW5zdGFuY2UucmVuZGVyID0gZnVuY3Rpb24gKGNvbnRhaW5lciwgb3B0cykgew0KICAgICAgICAgICAgICAgIGNyZWF0ZUhDYXB0Y2hhV2lkZ2V0KGNvbnRhaW5lciwgb3B0cyk7DQogICAgICAgICAgICAgICAgcmV0dXJuIG9yaWdpbmFsUmVuZGVyRnVuYyhjb250YWluZXIsIG9wdHMpOw0KICAgICAgICAgICAgfTsNCg0KICAgICAgICAgICAgaGNhcHRjaGEuZ2V0UmVzcG9uc2UgPSAoKSA9PiBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKCdbbmFtZT1oLWNhcHRjaGEtcmVzcG9uc2VdJykudmFsdWU7DQogICAgICAgIH0sDQogICAgfSk7DQogICAgbGV0IGNyZWF0ZUhDYXB0Y2hhV2lkZ2V0ID0gZnVuY3Rpb24gKGNvbnRhaW5lciwgb3B0cykgew0KICAgICAgICBpZiAodHlwZW9mIGNvbnRhaW5lciAhPT0gJ3N0cmluZycpIHsNCiAgICAgICAgICAgIGlmICghY29udGFpbmVyLmlkKSB7DQogICAgICAgICAgICAgICAgY29udGFpbmVyLmlkID0gImhjYXB0Y2hhLWNvbnRhaW5lci0iICsgRGF0ZS5ub3coKTsNCiAgICAgICAgICAgIH0NCiAgICAgICAgICAgIGNvbnRhaW5lciA9IGNvbnRhaW5lci5pZDsNCiAgICAgICAgfQ0KICAgICAgICBpZiAob3B0cy5jYWxsYmFjayAhPT0gdW5kZWZpbmVkICYmIHR5cGVvZiBvcHRzLmNhbGxiYWNrID09PSAiZnVuY3Rpb24iKSB7DQogICAgICAgICAgICBsZXQga2V5ID0gImhjYXB0Y2hhQ2FsbGJhY2siICsgRGF0ZS5ub3coKTsNCiAgICAgICAgICAgIHdpbmRvd1trZXldID0gb3B0cy5jYWxsYmFjazsNCiAgICAgICAgICAgIG9wdHMuY2FsbGJhY2sgPSBrZXk7DQogICAgICAgIH0NCiAgICAgICAgbGV0IGNhcHRjaGFJbmZvID0gew0KCQkJY29udGFpbmVySWQ6IGNvbnRhaW5lciwNCiAgICAgICAgICAgIHNpdGVrZXk6IG9wdHMuc2l0ZWtleSwNCiAgICAgICAgICAgIGNhbGxiYWNrOiBvcHRzLmNhbGxiYWNrLA0KICAgICAgICB9Ow0KCQl3aW5kb3cuY2FwdGNoYUluZm9oID0gY2FwdGNoYUluZm87DQogICAgfQ0KfSkoKQ=="
         

         
         
         var json = JSON.parse(native("filesystem", "fileinfo", VAR_PROJECT_DIRECTORY + "/CaptchaAutoSolver/content/hcaptcha/interceptor.js"))
         VAR_FILEINFO_EXISTS = json["exists"]
         VAR_1 = json["size"]
         VAR_1 = json["directory"]
         VAR_1 = json["is_directory"]
         VAR_1 = new Date(json["last_modified"] * 1000)
         

         
         
         _cycle_params().if_else = VAR_FILEINFO_EXISTS == false;
         _set_if_expression("W1tGSUxFSU5GT19FWElTVFNdXSA9PSBmYWxzZQ==");
         _if(_cycle_params().if_else,function(){
         
            
            
            native("filesystem", "writefile", JSON.stringify({path: VAR_PROJECT_DIRECTORY + "/CaptchaAutoSolver/content/hcaptcha/interceptor.js",value: (VAR_TEMP_DATA).toString(),base64:true,append:false}))
            

         })!
         

         
         
         _if(!_cycle_params().if_else,function(){
         
            
            
            VAR_FILE_CONTENT = native("filesystem", "readfile", JSON.stringify({value: VAR_PROJECT_DIRECTORY + "/CaptchaAutoSolver/content/hcaptcha/interceptor.js",base64:true,from:0,to:0}))
            

            
            
            _set_if_expression("W1tGSUxFX0NPTlRFTlRdXSAhPSBbW1RFTVBfREFUQV1d");
            _if(VAR_FILE_CONTENT != VAR_TEMP_DATA,function(){
            
               
               
               native("filesystem", "writefile", JSON.stringify({path: VAR_PROJECT_DIRECTORY + "/CaptchaAutoSolver/content/hcaptcha/interceptor.js",value: (VAR_TEMP_DATA).toString(),base64:true,append:false}))
               

            })!
            

         })!
         delete _cycle_params().if_else;
         

      })!
      

      
      
      _set_if_expression("dHJ1ZQ==");
      _if(true,function(){
      
         
         
         VAR_TEMP_DATA = "KCgpID0+IHsNCiAgICBzZXRJbnRlcnZhbChmdW5jdGlvbiAoKSB7DQogICAgICAgIGlmICh3aW5kb3cuX19fZ3JlY2FwdGNoYV9jZmcgPT09IHVuZGVmaW5lZCkge3JldHVybjt9DQogICAgICAgIGlmIChfX19ncmVjYXB0Y2hhX2NmZy5jbGllbnRzID09PSB1bmRlZmluZWQpIHtyZXR1cm47fQ0KICAgICAgICBmb3IgKGxldCB3aWRnZXRJZCBpbiBfX19ncmVjYXB0Y2hhX2NmZy5jbGllbnRzKSB7DQogICAgICAgICAgICBsZXQgd2lkZ2V0ID0gX19fZ3JlY2FwdGNoYV9jZmcuY2xpZW50c1t3aWRnZXRJZF07DQogICAgICAgICAgICBsZXQgd2lkZ2V0SW5mbyA9IGdldFJlY2FwdGNoYVdpZGdldEluZm8od2lkZ2V0KTsNCiAgICAgICAgICAgIHdpbmRvdy53aWRnZXRJbmZvcmUgPSB3aWRnZXRJbmZvOw0KICAgICAgICB9DQogICAgfSwgMzAwMCk7DQogICAgbGV0IGdldFJlY2FwdGNoYVdpZGdldEluZm8gPSBmdW5jdGlvbiAod2lkZ2V0KSB7DQogICAgICAgIGxldCBpbmZvID0gew0KICAgICAgICAgICAgY2FwdGNoYVR5cGU6ICJyZWNhcHRjaGEiLA0KICAgICAgICAgICAgd2lkZ2V0SWQ6IHdpZGdldC5pZCwNCiAgICAgICAgICAgIHZlcnNpb246ICJ2MiIsDQogICAgICAgICAgICBzaXRla2V5OiBudWxsLA0KICAgICAgICAgICAgYWN0aW9uOiBudWxsLA0KICAgICAgICAgICAgczogbnVsbCwNCiAgICAgICAgICAgIGNhbGxiYWNrOiBudWxsLA0KICAgICAgICAgICAgZW50ZXJwcmlzZTogZ3JlY2FwdGNoYS5lbnRlcnByaXNlID8gdHJ1ZSA6IGZhbHNlLA0KICAgICAgICAgICAgY29udGFpbmVySWQ6IG51bGwsDQogICAgICAgICAgICBiaW5kZWRCdXR0b25JZDogbnVsbCwNCiAgICAgICAgfTsNCiAgICAgICAgbGV0IGlzQmFkZ2UgPSBmYWxzZTsNCiAgICAgICAgbWFpbkxvb3A6IGZvciAobGV0IGsxIGluIHdpZGdldCkgew0KICAgICAgICAgICAgaWYgKHR5cGVvZiB3aWRnZXRbazFdICE9PSAib2JqZWN0Iikge2NvbnRpbnVlO30NCiAgICAgICAgICAgIGZvciAobGV0IGsyIGluIHdpZGdldFtrMV0pIHsNCiAgICAgICAgICAgICAgICBpZiAod2lkZ2V0W2sxXVtrMl0gJiYgd2lkZ2V0W2sxXVtrMl0uY2xhc3NMaXN0ICYmIHdpZGdldFtrMV1bazJdLmNsYXNzTGlzdC5jb250YWlucygiZ3JlY2FwdGNoYS1iYWRnZSIpKSB7DQogICAgICAgICAgICAgICAgICAgIGlzQmFkZ2UgPSB0cnVlOw0KICAgICAgICAgICAgICAgICAgICBicmVhayBtYWluTG9vcDsNCiAgICAgICAgICAgICAgICB9DQogICAgICAgICAgICB9DQogICAgICAgIH0NCiAgICAgICAgaWYgKGlzQmFkZ2UpIHsNCiAgICAgICAgICAgIGluZm8udmVyc2lvbiA9ICJ2MyI7DQogICAgICAgICAgICBmb3IgKGxldCBrMSBpbiB3aWRnZXQpIHsNCiAgICAgICAgICAgICAgICBsZXQgb2JqID0gd2lkZ2V0W2sxXTsNCiAgICAgICAgICAgICAgICBpZiAodHlwZW9mIG9iaiAhPT0gIm9iamVjdCIpIHtjb250aW51ZTt9DQogICAgICAgICAgICAgICAgZm9yIChsZXQgazIgaW4gb2JqKSB7DQogICAgICAgICAgICAgICAgICAgIGlmICh0eXBlb2Ygb2JqW2syXSAhPT0gInN0cmluZyIpIHtjb250aW51ZTt9DQogICAgICAgICAgICAgICAgICAgIGlmIChvYmpbazJdID09ICJmdWxsc2NyZWVuIikgaW5mby52ZXJzaW9uID0gInYyX2ludmlzaWJsZSI7DQogICAgICAgICAgICAgICAgfQ0KICAgICAgICAgICAgfQ0KICAgICAgICB9DQogICAgICAgIGxldCBuMTsNCiAgICAgICAgZm9yIChsZXQgayBpbiB3aWRnZXQpIHsNCiAgICAgICAgICAgIGlmICh3aWRnZXRba10gJiYgd2lkZ2V0W2tdLm5vZGVUeXBlKSB7DQogICAgICAgICAgICAgICAgaWYgKHdpZGdldFtrXS5pZCkgew0KICAgICAgICAgICAgICAgICAgICBpbmZvLmNvbnRhaW5lcklkID0gd2lkZ2V0W2tdLmlkOw0KICAgICAgICAgICAgICAgIH0gZWxzZSBpZiAod2lkZ2V0W2tdLmRhdGFzZXQuc2l0ZWtleSkgew0KICAgICAgICAgICAgICAgICAgICB3aWRnZXRba10uaWQgPSAicmVjYXB0Y2hhLWNvbnRhaW5lci0iICsgRGF0ZS5ub3coKTsNCiAgICAgICAgICAgICAgICAgICAgaW5mby5jb250YWluZXJJZCA9IHdpZGdldFtrXS5pZDsNCiAgICAgICAgICAgICAgICB9IGVsc2UgaWYgKGluZm8udmVyc2lvbiA9PSAndjInKSB7DQogICAgICAgICAgICAgICAgICAgIGlmICghbjEpIHsNCiAgICAgICAgICAgICAgICAgICAgICAgIG4xID0gd2lkZ2V0W2tdOw0KICAgICAgICAgICAgICAgICAgICAgICAgY29udGludWU7DQogICAgICAgICAgICAgICAgICAgIH0NCiAgICAgICAgICAgICAgICAgICAgaWYgKHdpZGdldFtrXS5pc1NhbWVOb2RlKG4xKSkgew0KICAgICAgICAgICAgICAgICAgICAgICAgd2lkZ2V0W2tdLmlkID0gInJlY2FwdGNoYS1jb250YWluZXItIiArIERhdGUubm93KCk7DQogICAgICAgICAgICAgICAgICAgICAgICBpbmZvLmNvbnRhaW5lcklkID0gd2lkZ2V0W2tdLmlkOw0KICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWs7DQogICAgICAgICAgICAgICAgICAgIH0NCiAgICAgICAgICAgICAgICB9DQogICAgICAgICAgICB9DQogICAgICAgIH0NCiAgICAgICAgZm9yIChsZXQgazEgaW4gd2lkZ2V0KSB7DQogICAgICAgICAgICBsZXQgb2JqID0gd2lkZ2V0W2sxXTsNCiAgICAgICAgICAgIGlmICh0eXBlb2Ygb2JqICE9PSAib2JqZWN0Iikge2NvbnRpbnVlO30NCiAgICAgICAgICAgIGZvciAobGV0IGsyIGluIG9iaikgew0KICAgICAgICAgICAgICAgIGlmIChvYmpbazJdID09PSBudWxsKSB7Y29udGludWU7fQ0KICAgICAgICAgICAgICAgIGlmICh0eXBlb2Ygb2JqW2syXSAhPT0gIm9iamVjdCIpIHtjb250aW51ZTt9DQogICAgICAgICAgICAgICAgaWYgKG9ialtrMl0uc2l0ZWtleSA9PT0gdW5kZWZpbmVkKSB7Y29udGludWU7fQ0KICAgICAgICAgICAgICAgIGlmIChvYmpbazJdLmFjdGlvbiA9PT0gdW5kZWZpbmVkKSB7Y29udGludWU7fQ0KICAgICAgICAgICAgICAgIGZvciAobGV0IGszIGluIG9ialtrMl0pIHsNCiAgICAgICAgICAgICAgICAgICAgaWYgKGszID09PSAic2l0ZWtleSIpIGluZm8uc2l0ZWtleSA9IG9ialtrMl1bazNdOw0KICAgICAgICAgICAgICAgICAgICBpZiAoazMgPT09ICJhY3Rpb24iKSBpbmZvLmFjdGlvbiA9IG9ialtrMl1bazNdOw0KICAgICAgICAgICAgICAgICAgICBpZiAoazMgPT09ICJzIikgaW5mby5zID0gb2JqW2syXVtrM107DQogICAgICAgICAgICAgICAgICAgIGlmIChrMyA9PT0gImNhbGxiYWNrIikgaW5mby5jYWxsYmFjayA9IG9ialtrMl1bazNdOw0KICAgICAgICAgICAgICAgICAgICBpZiAoazMgPT09ICJiaW5kIiAmJiBvYmpbazJdW2szXSkgew0KICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHR5cGVvZiBvYmpbazJdW2szXSA9PT0gInN0cmluZyIpIHsNCiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpbmZvLmJpbmRlZEJ1dHRvbklkID0gb2JqW2syXVtrM107DQogICAgICAgICAgICAgICAgICAgICAgICB9IGVsc2Ugew0KICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCBidXR0b24gPSBvYmpbazJdW2szXTsNCiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoYnV0dG9uLmlkID09PSB1bmRlZmluZWQpIHsNCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYnV0dG9uLmlkID0gInJlY2FwdGNoYUJpbmRlZEVsZW1lbnQiICsgd2lkZ2V0LmlkOw0KICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0NCiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpbmZvLmJpbmRlZEJ1dHRvbklkID0gYnV0dG9uLmlkOw0KICAgICAgICAgICAgICAgICAgICAgICAgfQ0KICAgICAgICAgICAgICAgICAgICB9DQogICAgICAgICAgICAgICAgfQ0KICAgICAgICAgICAgfQ0KICAgICAgICB9DQogICAgICAgIGlmICh0eXBlb2YgaW5mby5jYWxsYmFjayA9PT0gImZ1bmN0aW9uIikgew0KICAgICAgICAgICAgbGV0IGNhbGxiYWNrS2V5ID0gInJlQ2FwdGNoYVdpZGdldENhbGxiYWNrIiArIHdpZGdldC5pZDsNCiAgICAgICAgICAgIHdpbmRvd1tjYWxsYmFja0tleV0gPSBpbmZvLmNhbGxiYWNrOw0KICAgICAgICAgICAgaW5mby5jYWxsYmFjayA9IGNhbGxiYWNrS2V5Ow0KICAgICAgICB9DQogICAgICAgIHJldHVybiBpbmZvOw0KICAgIH07DQp9KSgp"
         

         
         
         var json = JSON.parse(native("filesystem", "fileinfo", VAR_PROJECT_DIRECTORY + "/CaptchaAutoSolver/content/recaptcha/hunter.js"))
         VAR_FILEINFO_EXISTS = json["exists"]
         VAR_1 = json["size"]
         VAR_1 = json["directory"]
         VAR_1 = json["is_directory"]
         VAR_1 = new Date(json["last_modified"] * 1000)
         

         
         
         _cycle_params().if_else = VAR_FILEINFO_EXISTS == false;
         _set_if_expression("W1tGSUxFSU5GT19FWElTVFNdXSA9PSBmYWxzZQ==");
         _if(_cycle_params().if_else,function(){
         
            
            
            native("filesystem", "writefile", JSON.stringify({path: VAR_PROJECT_DIRECTORY + "/CaptchaAutoSolver/content/recaptcha/hunter.js",value: (VAR_TEMP_DATA).toString(),base64:true,append:false}))
            

         })!
         

         
         
         _if(!_cycle_params().if_else,function(){
         
            
            
            VAR_FILE_CONTENT = native("filesystem", "readfile", JSON.stringify({value: VAR_PROJECT_DIRECTORY + "/CaptchaAutoSolver/content/recaptcha/hunter.js",base64:true,from:0,to:0}))
            

            
            
            _set_if_expression("W1tGSUxFX0NPTlRFTlRdXSAhPSBbW1RFTVBfREFUQV1d");
            _if(VAR_FILE_CONTENT != VAR_TEMP_DATA,function(){
            
               
               
               native("filesystem", "writefile", JSON.stringify({path: VAR_PROJECT_DIRECTORY + "/CaptchaAutoSolver/content/recaptcha/hunter.js",value: (VAR_TEMP_DATA).toString(),base64:true,append:false}))
               

            })!
            

         })!
         delete _cycle_params().if_else;
         

      })!
      

      
      
      _set_if_expression("dHJ1ZQ==");
      _if(true,function(){
      
         
         
         VAR_TEMP_DATA = "KCgpID0+IHsNCiAgICBsZXQgcmVjYXB0Y2hhSW5zdGFuY2U7DQogICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KHdpbmRvdywgImdyZWNhcHRjaGEiLCB7DQogICAgICAgIGdldDogZnVuY3Rpb24gKCkgew0KICAgICAgICAgICAgcmV0dXJuIHJlY2FwdGNoYUluc3RhbmNlOw0KICAgICAgICB9LA0KICAgICAgICBzZXQ6IGZ1bmN0aW9uIChlKSB7DQogICAgICAgICAgICByZWNhcHRjaGFJbnN0YW5jZSA9IGU7DQogICAgICAgICAgICBtYW5hZ2VSZWNhcHRjaGFPYmooZSk7DQogICAgICAgICAgICBtYW5hZ2VFbnRlcnByaXNlT2JqKGUpOw0KICAgICAgICB9LA0KICAgIH0pOw0KICAgIGxldCBtYW5hZ2VSZWNhcHRjaGFPYmogPSBmdW5jdGlvbiAob2JqKSB7DQogICAgICAgIGlmICh3aW5kb3cuX19fZ3JlY2FwdGNoYV9jZmcgPT09IHVuZGVmaW5lZCkge3JldHVybjt9DQogICAgICAgIGxldCBvcmlnaW5hbEV4ZWN1dGVGdW5jOw0KICAgICAgICBsZXQgb3JpZ2luYWxSZXNldEZ1bmM7DQogICAgICAgIGlmIChvYmouZXhlY3V0ZSkgb3JpZ2luYWxFeGVjdXRlRnVuYyA9IG9iai5leGVjdXRlOw0KICAgICAgICBpZiAob2JqLnJlc2V0KSBvcmlnaW5hbFJlc2V0RnVuYyA9IG9iai5yZXNldDsNCiAgICAgICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KG9iaiwgImV4ZWN1dGUiLCB7DQogICAgICAgICAgICBnZXQ6IGZ1bmN0aW9uICgpIHsNCiAgICAgICAgICAgICAgICByZXR1cm4gYXN5bmMgZnVuY3Rpb24gKHNpdGVrZXksIG9wdGlvbnMpIHsNCiAgICAgICAgICAgICAgICAgICAgaWYgKCFvcHRpb25zKSB7DQogICAgICAgICAgICAgICAgICAgICAgICBpZiAoIWlzSW52aXNpYmxlKCkpIHsNCiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gYXdhaXQgb3JpZ2luYWxFeGVjdXRlRnVuYyhzaXRla2V5LCBvcHRpb25zKTsNCiAgICAgICAgICAgICAgICAgICAgICAgIH0NCiAgICAgICAgICAgICAgICAgICAgfQ0KICAgICAgICAgICAgICAgICAgICBsZXQgY29uZmlnID0gYXdhaXQgc2VuZE1zZ1RvU29sdmVyQ1MoImdldENvbmZpZyIpOw0KICAgICAgICAgICAgICAgICAgICByZXR1cm4gYXdhaXQgb3JpZ2luYWxFeGVjdXRlRnVuYyhzaXRla2V5LCBvcHRpb25zKTsNCiAgICAgICAgICAgICAgICAgICAgbGV0IHdpZGdldElkID0gYWRkV2lkZ2V0SW5mbyhzaXRla2V5LCBvcHRpb25zKTsNCiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGF3YWl0IHdhaXRGb3JSZXN1bHQod2lkZ2V0SWQpOw0KICAgICAgICAgICAgICAgIH07DQogICAgICAgICAgICB9LA0KICAgICAgICAgICAgc2V0OiBmdW5jdGlvbiAoZSkgew0KICAgICAgICAgICAgICAgIG9yaWdpbmFsRXhlY3V0ZUZ1bmMgPSBlOw0KICAgICAgICAgICAgfSwNCiAgICAgICAgfSk7DQogICAgICAgIE9iamVjdC5kZWZpbmVQcm9wZXJ0eShvYmosICJyZXNldCIsIHsNCiAgICAgICAgICAgIGdldDogZnVuY3Rpb24gKCkgew0KICAgICAgICAgICAgICAgIHJldHVybiBmdW5jdGlvbiAod2lkZ2V0SWQpIHsNCiAgICAgICAgICAgICAgICAgICAgaWYgKHdpZGdldElkID09PSB1bmRlZmluZWQpIHsNCiAgICAgICAgICAgICAgICAgICAgICAgIGxldCBpZHMgPSBPYmplY3Qua2V5cyhfX19ncmVjYXB0Y2hhX2NmZy5jbGllbnRzKVswXTsNCiAgICAgICAgICAgICAgICAgICAgICAgIHdpZGdldElkID0gaWRzLmxlbmd0aCA/IGlkc1swXSA6IDA7DQogICAgICAgICAgICAgICAgICAgIH0NCiAgICAgICAgICAgICAgICAgICAgcmVzZXRDYXB0Y2hhV2lkZ2V0KCJyZWNhcHRjaGEiLCB3aWRnZXRJZCk7DQogICAgICAgICAgICAgICAgICAgIHJldHVybiBvcmlnaW5hbFJlc2V0RnVuYyh3aWRnZXRJZCk7DQogICAgICAgICAgICAgICAgfTsNCiAgICAgICAgICAgIH0sDQogICAgICAgICAgICBzZXQ6IGZ1bmN0aW9uIChlKSB7DQogICAgICAgICAgICAgICAgb3JpZ2luYWxSZXNldEZ1bmMgPSBlOw0KICAgICAgICAgICAgfSwNCiAgICAgICAgfSk7DQogICAgfTsNCiAgICBsZXQgbWFuYWdlRW50ZXJwcmlzZU9iaiA9IGZ1bmN0aW9uIChvYmopIHsNCiAgICAgICAgaWYgKHdpbmRvdy5fX19ncmVjYXB0Y2hhX2NmZyA9PT0gdW5kZWZpbmVkKSB7cmV0dXJuO30NCiAgICAgICAgbGV0IG9yaWdpbmFsRW50ZXJwcmlzZU9iajsNCiAgICAgICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KG9iaiwgImVudGVycHJpc2UiLCB7DQogICAgICAgICAgICBnZXQ6IGZ1bmN0aW9uICgpIHsNCiAgICAgICAgICAgICAgICByZXR1cm4gb3JpZ2luYWxFbnRlcnByaXNlT2JqOw0KICAgICAgICAgICAgfSwNCiAgICAgICAgICAgIHNldDogZnVuY3Rpb24gKGVudCkgew0KICAgICAgICAgICAgICAgIG9yaWdpbmFsRW50ZXJwcmlzZU9iaiA9IGVudDsNCiAgICAgICAgICAgICAgICBsZXQgb3JpZ2luYWxFeGVjdXRlRnVuYzsNCiAgICAgICAgICAgICAgICBsZXQgb3JpZ2luYWxSZXNldEZ1bmM7DQogICAgICAgICAgICAgICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KGVudCwgImV4ZWN1dGUiLCB7DQogICAgICAgICAgICAgICAgICAgIGdldDogZnVuY3Rpb24gKCkgew0KICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGFzeW5jIGZ1bmN0aW9uIChzaXRla2V5LCBvcHRpb25zKSB7DQogICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKCFvcHRpb25zKSB7DQogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICghaXNJbnZpc2libGUoKSkgew0KICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGF3YWl0IG9yaWdpbmFsRXhlY3V0ZUZ1bmMoc2l0ZWtleSwgb3B0aW9ucyk7DQogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0NCiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9DQogICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IGNvbmZpZyA9IGF3YWl0IHNlbmRNc2dUb1NvbHZlckNTKCJnZXRDb25maWciKTsNCiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gYXdhaXQgb3JpZ2luYWxFeGVjdXRlRnVuYyhzaXRla2V5LCBvcHRpb25zKTsNCiAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgd2lkZ2V0SWQgPSBhZGRXaWRnZXRJbmZvKHNpdGVrZXksIG9wdGlvbnMsICIxIik7DQogICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGF3YWl0IHdhaXRGb3JSZXN1bHQod2lkZ2V0SWQpOw0KICAgICAgICAgICAgICAgICAgICAgICAgfTsNCiAgICAgICAgICAgICAgICAgICAgfSwNCiAgICAgICAgICAgICAgICAgICAgc2V0OiBmdW5jdGlvbiAoZSkgew0KICAgICAgICAgICAgICAgICAgICAgICAgb3JpZ2luYWxFeGVjdXRlRnVuYyA9IGU7DQogICAgICAgICAgICAgICAgICAgIH0sDQogICAgICAgICAgICAgICAgfSk7DQogICAgICAgICAgICAgICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KGVudCwgInJlc2V0Iiwgew0KICAgICAgICAgICAgICAgICAgICBnZXQ6IGZ1bmN0aW9uICgpIHsNCiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBmdW5jdGlvbiAod2lkZ2V0SWQpIHsNCiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAod2lkZ2V0SWQgPT09IHVuZGVmaW5lZCkgew0KICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgaWRzID0gT2JqZWN0LmtleXMoX19fZ3JlY2FwdGNoYV9jZmcuY2xpZW50cylbMF07DQogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHdpZGdldElkID0gaWRzLmxlbmd0aCA/IGlkc1swXSA6IDA7DQogICAgICAgICAgICAgICAgICAgICAgICAgICAgfQ0KICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlc2V0Q2FwdGNoYVdpZGdldCgicmVjYXB0Y2hhIiwgd2lkZ2V0SWQpOw0KICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBvcmlnaW5hbFJlc2V0RnVuYyh3aWRnZXRJZCk7DQogICAgICAgICAgICAgICAgICAgICAgICB9Ow0KICAgICAgICAgICAgICAgICAgICB9LA0KICAgICAgICAgICAgICAgICAgICBzZXQ6IGZ1bmN0aW9uIChlKSB7DQogICAgICAgICAgICAgICAgICAgICAgICBvcmlnaW5hbFJlc2V0RnVuYyA9IGU7DQogICAgICAgICAgICAgICAgICAgIH0sDQogICAgICAgICAgICAgICAgfSk7DQogICAgICAgICAgICB9LA0KICAgICAgICB9KTsNCiAgICB9Ow0KICAgIGxldCBhZGRXaWRnZXRJbmZvID0gZnVuY3Rpb24gKHNpdGVrZXksIG9wdGlvbnMsIGVudGVycHJpc2UpIHsNCiAgICAgICAgbGV0IHdpZGdldElkID0gcGFyc2VJbnQoRGF0ZS5ub3coKSAvIDEwMDApOw0KICAgICAgICBsZXQgYmFkZ2UgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKCIuZ3JlY2FwdGNoYS1iYWRnZSIpOw0KICAgICAgICBpZiAoIWJhZGdlLmlkKSBiYWRnZS5pZCA9ICJyZWNhcHRjaGEtYmFkZ2UtIiArIHdpZGdldElkOw0KICAgICAgICBsZXQgY2FsbGJhY2sgPSAicnYzRXhlY0NhbGxiYWNrIiArIHdpZGdldElkOw0KICAgICAgICB3aW5kb3dbY2FsbGJhY2tdID0gZnVuY3Rpb24gKHJlc3BvbnNlKSB7DQogICAgICAgICAgICBnZXRDYXB0Y2hhV2lkZ2V0QnV0dG9uKCJyZWNhcHRjaGEiLCB3aWRnZXRJZCkuZGF0YXNldC5yZXNwb25zZSA9IHJlc3BvbnNlOw0KICAgICAgICB9Ow0KICAgICAgICBsZXQgd2lkZ2V0SW5mbyA9IHsNCiAgICAgICAgICAgIGNhcHRjaGFUeXBlOiAicmVjYXB0Y2hhIiwNCiAgICAgICAgICAgIHdpZGdldElkOiB3aWRnZXRJZCwNCiAgICAgICAgICAgIHZlcnNpb246ICJ2MyIsDQogICAgICAgICAgICBzaXRla2V5OiBzaXRla2V5LA0KICAgICAgICAgICAgYWN0aW9uOiBvcHRpb25zID8gb3B0aW9ucy5hY3Rpb24gOiAnJywNCiAgICAgICAgICAgIHM6IG51bGwsDQogICAgICAgICAgICBlbnRlcnByaXNlOiBlbnRlcnByaXNlID8gdHJ1ZSA6IGZhbHNlLA0KICAgICAgICAgICAgY2FsbGJhY2s6IGNhbGxiYWNrLA0KICAgICAgICAgICAgY29udGFpbmVySWQ6IGJhZGdlLmlkLA0KICAgICAgICB9Ow0KICAgICAgICB3aW5kb3cud2lkZ2V0SW5mb3JldGhyZWUgPSB3aWRnZXRJbmZvOw0KICAgICAgICByZXR1cm4gd2lkZ2V0SWQ7DQogICAgfTsNCiAgICBsZXQgd2FpdEZvclJlc3VsdCA9IGZ1bmN0aW9uICh3aWRnZXRJZCkgew0KICAgICAgICByZXR1cm4gbmV3IFByb21pc2UoZnVuY3Rpb24gKHJlc29sdmUsIHJlamVjdCkgew0KICAgICAgICAgICAgbGV0IGludGVydmFsID0gc2V0SW50ZXJ2YWwoZnVuY3Rpb24gKCkgew0KICAgICAgICAgICAgICAgIGxldCBidXR0b24gPSBnZXRDYXB0Y2hhV2lkZ2V0QnV0dG9uKCJyZWNhcHRjaGEiLCB3aWRnZXRJZCk7DQoNCiAgICAgICAgICAgICAgICBpZiAoYnV0dG9uICYmIGJ1dHRvbi5kYXRhc2V0LnJlc3BvbnNlKSB7DQogICAgICAgICAgICAgICAgICAgIHJlc29sdmUoYnV0dG9uLmRhdGFzZXQucmVzcG9uc2UpOw0KICAgICAgICAgICAgICAgICAgICBjbGVhckludGVydmFsKGludGVydmFsKTsNCiAgICAgICAgICAgICAgICB9DQogICAgICAgICAgICB9LCA1MDApOw0KICAgICAgICB9KTsNCiAgICB9Ow0KICAgIGxldCBpc0ludmlzaWJsZSA9IGZ1bmN0aW9uICgpIHsNCiAgICAgICAgbGV0IHdpZGdldHMgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yQWxsKCdoZWFkIGNhcHRjaGEtd2lkZ2V0Jyk7DQogICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgd2lkZ2V0cy5sZW5ndGg7IGkrKykgew0KICAgICAgICAgICAgaWYgKHdpZGdldHNbaV0uZGF0YXNldC52ZXJzaW9uID09ICd2Ml9pbnZpc2libGUnKSB7DQogICAgICAgICAgICAgICAgbGV0IGJhZGdlID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcignLmdyZWNhcHRjaGEtYmFkZ2UnKTsNCiAgICAgICAgICAgICAgICBiYWRnZS5pZCA9ICJyZWNhcHRjaGEtYmFkZ2UtIiArIHdpZGdldHNbaV0uZGF0YXNldC53aWRnZXRJZDsNCiAgICAgICAgICAgICAgICB3aWRnZXRzW2ldLmRhdGFzZXQuY29udGFpbmVySWQgPSBiYWRnZS5pZDsNCiAgICAgICAgICAgICAgICByZXR1cm4gdHJ1ZTsNCiAgICAgICAgICAgIH0NCiAgICAgICAgfQ0KICAgICAgICByZXR1cm4gZmFsc2U7DQogICAgfTsNCn0pKCk="
         

         
         
         var json = JSON.parse(native("filesystem", "fileinfo", VAR_PROJECT_DIRECTORY + "/CaptchaAutoSolver/content/recaptcha/interceptor.js"))
         VAR_FILEINFO_EXISTS = json["exists"]
         VAR_1 = json["size"]
         VAR_1 = json["directory"]
         VAR_1 = json["is_directory"]
         VAR_1 = new Date(json["last_modified"] * 1000)
         

         
         
         _cycle_params().if_else = VAR_FILEINFO_EXISTS == false;
         _set_if_expression("W1tGSUxFSU5GT19FWElTVFNdXSA9PSBmYWxzZQ==");
         _if(_cycle_params().if_else,function(){
         
            
            
            native("filesystem", "writefile", JSON.stringify({path: VAR_PROJECT_DIRECTORY + "/CaptchaAutoSolver/content/recaptcha/interceptor.js",value: (VAR_TEMP_DATA).toString(),base64:true,append:false}))
            

         })!
         

         
         
         _if(!_cycle_params().if_else,function(){
         
            
            
            VAR_FILE_CONTENT = native("filesystem", "readfile", JSON.stringify({value: VAR_PROJECT_DIRECTORY + "/CaptchaAutoSolver/content/recaptcha/interceptor.js",base64:true,from:0,to:0}))
            

            
            
            _set_if_expression("W1tGSUxFX0NPTlRFTlRdXSAhPSBbW1RFTVBfREFUQV1d");
            _if(VAR_FILE_CONTENT != VAR_TEMP_DATA,function(){
            
               
               
               native("filesystem", "writefile", JSON.stringify({path: VAR_PROJECT_DIRECTORY + "/CaptchaAutoSolver/content/recaptcha/interceptor.js",value: (VAR_TEMP_DATA).toString(),base64:true,append:false}))
               

            })!
            

         })!
         delete _cycle_params().if_else;
         

      })!
      

   }
   

function GoodXevilPaySolver_GXP_ReCaptchav2TakeToken()
   {
   
      
      
      VAR_APIKEY = _function_argument("APIKEY")
      

      
      
      VAR_SITE_URL = _function_argument("site_url")
      

      
      
      VAR_SITEKEY = _function_argument("sitekey")
      

      
      
      var regexp_result = native("regexp", "first", JSON.stringify({text: VAR_APIKEY,regexp:("([0-9A-Za-z\u005c|]\u007b20,50\u007d)").toString()}))
      if(regexp_result.length == 0)
      regexp_result = []
      else
      regexp_result = JSON.parse(regexp_result)
      VAR_ALL_MATCH = regexp_result.pop()
      if(typeof(VAR_ALL_MATCH) == 'undefined' || !VAR_ALL_MATCH)
      VAR_ALL_MATCH = ""
      VAR_LIST_WITH_GROUPS = regexp_result
      VAR_APIKEY = regexp_result[0]
      if(typeof(VAR_APIKEY) == 'undefined' || !VAR_APIKEY)
      VAR_APIKEY = ""
      if(regexp_result.length == 0)
      {
      VAR_APIKEY = VAR_ALL_MATCH
      }
      if(VAR_ALL_MATCH != "" && Array.isArray(VAR_ALL_MATCH))
      VAR_LIST_WITH_GROUPS.unshift(VAR_ALL_MATCH)
      

      
      
      solver_properties_clear("capmonster")
      solver_property("capmonster","serverurl","http://sctg.xyz")
      solver_property("capmonster","key",VAR_APIKEY)
      solver_property("capmonster","method","userrecaptcha")
      solver_property("capmonster","pageurl",VAR_SITE_URL)
      solver_property("capmonster","googlekey",VAR_SITEKEY)
      solve_base64_no_fail("capmonster", "")!
      VAR_SAVED_CONTENT = _result();
      

      
      
      _function_return(VAR_SAVED_CONTENT)
      

   }
   

function GoodXevilPaySolver_GXP_HcaptchaAutoSolver()
   {
   
      
      
      VAR_APIKEY = _function_argument("apikey")
      

      
      
      var regexp_result = native("regexp", "first", JSON.stringify({text: VAR_APIKEY,regexp:("([0-9A-Za-z\u005c|]\u007b20,50\u007d)").toString()}))
      if(regexp_result.length == 0)
      regexp_result = []
      else
      regexp_result = JSON.parse(regexp_result)
      VAR_ALL_MATCH = regexp_result.pop()
      if(typeof(VAR_ALL_MATCH) == 'undefined' || !VAR_ALL_MATCH)
      VAR_ALL_MATCH = ""
      VAR_LIST_WITH_GROUPS = regexp_result
      VAR_APIKEY = regexp_result[0]
      if(typeof(VAR_APIKEY) == 'undefined' || !VAR_APIKEY)
      VAR_APIKEY = ""
      if(regexp_result.length == 0)
      {
      VAR_APIKEY = VAR_ALL_MATCH
      }
      if(VAR_ALL_MATCH != "" && Array.isArray(VAR_ALL_MATCH))
      VAR_LIST_WITH_GROUPS.unshift(VAR_ALL_MATCH)
      

      
      
      VAR_TEMP_DATA2 = ""
      

      
      
      VAR_TEMP_DATA = ""
      

      
      
      _do(function(){
      _set_action_info({ name: "While" });
      VAR_CYCLE_INDEX = _iterator() - 1
      BREAK_CONDITION = VAR_TEMP_DATA == "";
      if(!BREAK_CONDITION)_break();
      
         
         
         _set_if_expression("W1tDWUNMRV9JTkRFWF1dICE9IDA=");
         _if(VAR_CYCLE_INDEX != 0,function(){
         
            
            
            sleep(500)!
            

         })!
         

         
         
         _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gMzA=");
         _if(VAR_CYCLE_INDEX > 30,function(){
         
            
            
            fail((_K==="en" ? "Hcaptcha is not detected on the page" : "Hcaptcha не обнаружена на странице"));
            

         })!
         

         
         
         _call(function()
         {
         _on_fail(function(){
         VAR_LAST_ERROR = _result()
         VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
         VAR_WAS_ERROR = false
         _break(1,true)
         })
         CYCLES.Current().RemoveLabel("function")
         
            
            
            page().script2("[[TEMP_DATA]] = window.captchaInfoh;",JSON.stringify(_read_variables(["VAR_TEMP_DATA"])))!
            var _parse_result = JSON.parse(_result())
            _write_variables(JSON.parse(_parse_result.variables))
            if(!_parse_result.is_success)
            fail(_parse_result.error)
            

         },null)!
         

         
         
         _set_if_expression("W1tURU1QX0RBVEFdXSA9PSAiIg==");
         _if(VAR_TEMP_DATA == "",function(){
         
            
            
            _call(function()
            {
            _on_fail(function(){
            VAR_LAST_ERROR = _result()
            VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
            VAR_WAS_ERROR = false
            _break(1,true)
            })
            CYCLES.Current().RemoveLabel("function")
            
               
               
               page().script2("[[TEMP_DATA2]] = window.captchaInfohtwo;",JSON.stringify(_read_variables(["VAR_TEMP_DATA2"])))!
               var _parse_result = JSON.parse(_result())
               _write_variables(JSON.parse(_parse_result.variables))
               if(!_parse_result.is_success)
               fail(_parse_result.error)
               

            },null)!
            

            
            
            _set_if_expression("W1tURU1QX0RBVEEyXV0gIT0gIiI=");
            _if(VAR_TEMP_DATA2 != "",function(){
            
               
               
               _call(function()
               {
               _on_fail(function(){
               VAR_LAST_ERROR = _result()
               VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
               VAR_WAS_ERROR = false
               _break(1,true)
               })
               CYCLES.Current().RemoveLabel("function")
               
                  
                  
                  page().script2("[[TEMP_DATA]] = window.captchaInfoh;",JSON.stringify(_read_variables(["VAR_TEMP_DATA"])))!
                  var _parse_result = JSON.parse(_result())
                  _write_variables(JSON.parse(_parse_result.variables))
                  if(!_parse_result.is_success)
                  fail(_parse_result.error)
                  

               },null)!
               

               
               
               _set_if_expression("W1tURU1QX0RBVEFdXSA9PSAiIg==");
               _if(VAR_TEMP_DATA == "",function(){
               
                  
                  
                  VAR_TEMP_DATA = VAR_TEMP_DATA2
                  

               })!
               

            })!
            

         })!
         

      })!
      

      
      
      /*Browser*/
      url()!
      VAR_SITE_URL = _result()
      

      
      
      VAR_SAVED_CONTENT = "ERROR"
      

      
      
      _do(function(){
      _set_action_info({ name: "For" });
      VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(0)
      if(VAR_CYCLE_INDEX > parseInt(3))_break();
      
         
         
         _set_if_expression("W1tDWUNMRV9JTkRFWF1dID49IDI=");
         _if(VAR_CYCLE_INDEX >= 2,function(){
         
            
            
            fail((_K==="en" ? "Error when solving captcha: " + VAR_SAVED_CONTENT : "Ошибка при решении капчи: " + VAR_SAVED_CONTENT));
            

         })!
         

         
         
         _call(function()
         {
         _on_fail(function(){
         VAR_LAST_ERROR = _result()
         VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
         VAR_WAS_ERROR = false
         _break(1,true)
         })
         CYCLES.Current().RemoveLabel("function")
         
            
            
            solver_properties_clear("capmonster")
            solver_property("capmonster","serverurl","http://sctg.xyz")
            solver_property("capmonster","key",VAR_APIKEY)
            solver_property("capmonster","method","hcaptcha")
            solver_property("capmonster","pageurl",VAR_SITE_URL)
            solver_property("capmonster","sitekey",VAR_TEMP_DATA["sitekey"])
            solve_base64_no_fail("capmonster", "")!
            VAR_SAVED_CONTENT = _result();
            

         },null)!
         

         
         
         VAR_STRING_MATCHES = Boolean(native("regexp", "ismatch", JSON.stringify({text: VAR_SAVED_CONTENT,regexp:("(ERROR)").toString()})) == "true")
         

         
         
         VAR_STRING_MATCHES2 = Boolean(native("regexp", "ismatch", JSON.stringify({text: VAR_SAVED_CONTENT,regexp:("(_FAIL)").toString()})) == "true")
         

         
         
         _set_if_expression("W1tTVFJJTkdfTUFUQ0hFU11dIHx8IFtbU1RSSU5HX01BVENIRVMyXV0=");
         _if(VAR_STRING_MATCHES || VAR_STRING_MATCHES2,function(){
         
            
            
            sleep(1000)!
            

            
            
            _next("function")
            

         })!
         

         
         
         _break("function")
         

      })!
      

      
      
      VAR_ERROR_ID = 0
      

      
      
      _call(function()
      {
      _on_fail(function(){
      VAR_LAST_ERROR = _result()
      VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
      VAR_WAS_ERROR = false
      _break(1,true)
      })
      CYCLES.Current().RemoveLabel("function")
      
         
         
         page().script2("let container = document.querySelector(\u0027#\u0027+window.captchaInfohtwo.containerId);\r\n  for(let area of container.querySelectorAll(\u0022textarea\u0022))\u007b\r\n    area.value = [[SAVED_CONTENT]];\r\n  \u007d\r\n  for(let frame of container.querySelectorAll(\u0022iframe\u0022))\u007b\r\n    frame.setAttribute(\u0022data-hcaptcha-response\u0022, [[SAVED_CONTENT]]);\r\n  \u007d\r\n  if(window.captchaInfohtwo.callback != null)\u007b\r\n    let textarea = document.createElement(\u0027textarea\u0027);\r\n    textarea.id = \u0027callback-trigger\u0027;\r\n    textarea.setAttribute(\u0027data-function\u0027, window.captchaInfohtwo.callback);\r\n    textarea.value = [[SAVED_CONTENT]];\r\n    document.body.appendChild(textarea);\r\n    textarea = document.querySelector(\u0027textarea[id=callback-trigger]\u0027);\r\n    let func = textarea.getAttribute(\u0027data-function\u0027);\r\n    let data = textarea.value;\r\n    textarea.remove();\r\n    window[func](data);\r\n  \u007d",JSON.stringify(_read_variables(["VAR_SAVED_CONTENT"])))!
         var _parse_result = JSON.parse(_result())
         _write_variables(JSON.parse(_parse_result.variables))
         if(!_parse_result.is_success)
         fail(_parse_result.error)
         

      },null)!
      

      
      
      _set_if_expression("W1tXQVNfRVJST1JdXQ==");
      _if(typeof(VAR_WAS_ERROR) !== "undefined" ? (VAR_WAS_ERROR) : undefined,function(){
      
         
         
         VAR_ERROR_ID = parseInt(VAR_ERROR_ID) + parseInt(1)
         

      })!
      

      
      
      _call(function()
      {
      _on_fail(function(){
      VAR_LAST_ERROR = _result()
      VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
      VAR_WAS_ERROR = false
      _break(1,true)
      })
      CYCLES.Current().RemoveLabel("function")
      
         
         
         page().script2("let container = document.querySelector(\u0027#\u0027+window.captchaInfoh.containerId);\r\n  for(let area of container.querySelectorAll(\u0022textarea\u0022))\u007b\r\n    area.value = [[SAVED_CONTENT]];\r\n  \u007d\r\n  for(let frame of container.querySelectorAll(\u0022iframe\u0022))\u007b\r\n    frame.setAttribute(\u0022data-hcaptcha-response\u0022, [[SAVED_CONTENT]]);\r\n  \u007d\r\n  if(window.captchaInfoh.callback != null)\u007b\r\n    let textarea = document.createElement(\u0027textarea\u0027);\r\n    textarea.id = \u0027callback-trigger\u0027;\r\n    textarea.setAttribute(\u0027data-function\u0027, window.captchaInfoh.callback);\r\n    textarea.value = [[SAVED_CONTENT]];\r\n    document.body.appendChild(textarea);\r\n    textarea = document.querySelector(\u0027textarea[id=callback-trigger]\u0027);\r\n    let func = textarea.getAttribute(\u0027data-function\u0027);\r\n    let data = textarea.value;\r\n    textarea.remove();\r\n    window[func](data);\r\n  \u007d",JSON.stringify(_read_variables(["VAR_SAVED_CONTENT"])))!
         var _parse_result = JSON.parse(_result())
         _write_variables(JSON.parse(_parse_result.variables))
         if(!_parse_result.is_success)
         fail(_parse_result.error)
         

      },null)!
      

      
      
      _call(function()
      {
      _on_fail(function(){
      VAR_LAST_ERROR = _result()
      VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
      VAR_WAS_ERROR = false
      _break(1,true)
      })
      CYCLES.Current().RemoveLabel("function")
      
         
         
         _set_if_expression("ZmFsc2U=");
         _if(false,function(){
         
            
            
            page().script2("var xpath = \u0027//textarea[@name=\u0022g-recaptcha-response\u0022]\u0027;\r\nvar result = document.evaluate(xpath, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null);\r\nvar element = result.singleNodeValue;\r\n\r\nif (element) \u007b\r\n  element.innerText = [[SAVED_CONTENT]];\r\n\u007d\r\n\r\nvar xpath = \u0027//textarea[@name=\u0022h-captcha-response\u0022]\u0027;\r\nvar result = document.evaluate(xpath, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null);\r\nvar element = result.singleNodeValue;\r\n\r\nif (element) \u007b\r\n  element.innerText = [[SAVED_CONTENT]];\r\n\u007d\r\n",JSON.stringify(_read_variables(["VAR_SAVED_CONTENT"])))!
            var _parse_result = JSON.parse(_result())
            _write_variables(JSON.parse(_parse_result.variables))
            if(!_parse_result.is_success)
            fail(_parse_result.error)
            

         })!
         

      },null)!
      

      
      
      _set_if_expression("W1tXQVNfRVJST1JdXQ==");
      _if(typeof(VAR_WAS_ERROR) !== "undefined" ? (VAR_WAS_ERROR) : undefined,function(){
      
         
         
         VAR_ERROR_ID = parseInt(VAR_ERROR_ID) + parseInt(1)
         

      })!
      

      
      
      _set_if_expression("W1tFUlJPUl9JRF1dID09IDI=");
      _if(VAR_ERROR_ID == 2,function(){
      
         
         
         fail((_K==="en" ? "Hcaptcha is not solved" : "Hcaptcha не решена"));
         

      })!
      

   }
   

function GoodXevilPaySolver_GXP_HcaptchaTakeToken()
   {
   
      
      
      VAR_APIKEY = _function_argument("APIKEY")
      

      
      
      VAR_SITE_URL = _function_argument("site_url")
      

      
      
      VAR_SITEKEY = _function_argument("sitekey")
      

      
      
      var regexp_result = native("regexp", "first", JSON.stringify({text: VAR_APIKEY,regexp:("([0-9A-Za-z\u005c|]\u007b20,50\u007d)").toString()}))
      if(regexp_result.length == 0)
      regexp_result = []
      else
      regexp_result = JSON.parse(regexp_result)
      VAR_ALL_MATCH = regexp_result.pop()
      if(typeof(VAR_ALL_MATCH) == 'undefined' || !VAR_ALL_MATCH)
      VAR_ALL_MATCH = ""
      VAR_LIST_WITH_GROUPS = regexp_result
      VAR_APIKEY = regexp_result[0]
      if(typeof(VAR_APIKEY) == 'undefined' || !VAR_APIKEY)
      VAR_APIKEY = ""
      if(regexp_result.length == 0)
      {
      VAR_APIKEY = VAR_ALL_MATCH
      }
      if(VAR_ALL_MATCH != "" && Array.isArray(VAR_ALL_MATCH))
      VAR_LIST_WITH_GROUPS.unshift(VAR_ALL_MATCH)
      

      
      
      solver_properties_clear("capmonster")
      solver_property("capmonster","serverurl","http://sctg.xyz")
      solver_property("capmonster","key",VAR_APIKEY)
      solver_property("capmonster","method","hcaptcha")
      solver_property("capmonster","pageurl",VAR_SITE_URL)
      solver_property("capmonster","sitekey",VAR_SITEKEY)
      solve_base64_no_fail("capmonster", "")!
      VAR_SAVED_CONTENT = _result();
      

      
      
      _function_return(VAR_SAVED_CONTENT)
      

   }
   

function GoodXevilPaySolver_GXP_GetBalance()
   {
   
      
      
      VAR_APIKEY = _function_argument("APIKEY")
      

      
      
      var regexp_result = native("regexp", "first", JSON.stringify({text: VAR_APIKEY,regexp:("([0-9A-Za-z\u005c|]\u007b20,50\u007d)").toString()}))
      if(regexp_result.length == 0)
      regexp_result = []
      else
      regexp_result = JSON.parse(regexp_result)
      VAR_ALL_MATCH = regexp_result.pop()
      if(typeof(VAR_ALL_MATCH) == 'undefined' || !VAR_ALL_MATCH)
      VAR_ALL_MATCH = ""
      VAR_LIST_WITH_GROUPS = regexp_result
      VAR_APIKEY = regexp_result[0]
      if(typeof(VAR_APIKEY) == 'undefined' || !VAR_APIKEY)
      VAR_APIKEY = ""
      if(regexp_result.length == 0)
      {
      VAR_APIKEY = VAR_ALL_MATCH
      }
      if(VAR_ALL_MATCH != "" && Array.isArray(VAR_ALL_MATCH))
      VAR_LIST_WITH_GROUPS.unshift(VAR_ALL_MATCH)
      

      
      
      _switch_http_client_main()
      http_client_get2("http://sctg.xyz/res.php?action=getbalance\u0026key=" + VAR_APIKEY,{method:("GET"),headers:("")})!
      

      
      
      _switch_http_client_main()
      VAR_SAVED_CONTENT = http_client_encoded_content("utf-8")
      

      
      
      _set_if_expression("W1tTQVZFRF9DT05URU5UXV0ubGVuZ3RoID09IDA=");
      _if(VAR_SAVED_CONTENT.length == 0,function(){
      
         
         
         fail((_K==="en" ? "Couldn't figure out the balance" : "Не получилось узнать баланс"));
         

      })!
      

      
      
      _function_return(VAR_SAVED_CONTENT)
      

   }
   

