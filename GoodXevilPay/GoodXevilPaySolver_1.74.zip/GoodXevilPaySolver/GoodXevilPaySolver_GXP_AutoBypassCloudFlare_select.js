var aesgppza = GetInputConstructorValue("aesgppza", loader);
                 if(aesgppza["original"].length == 0)
                 {
                   Invalid("custom_button" + " is empty");
                   return;
                 }
var yzwrhush = GetInputConstructorValue("yzwrhush", loader);
                 if(yzwrhush["original"].length == 0)
                 {
                   Invalid("max_time" + " is empty");
                   return;
                 }
var teqjpivy = GetInputConstructorValue("teqjpivy", loader);
                 if(teqjpivy["original"].length == 0)
                 {
                   Invalid("whait_element" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_AutoBypassCloudFlare_code").html())({"aesgppza": aesgppza["updated"],"yzwrhush": yzwrhush["updated"],"teqjpivy": teqjpivy["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
