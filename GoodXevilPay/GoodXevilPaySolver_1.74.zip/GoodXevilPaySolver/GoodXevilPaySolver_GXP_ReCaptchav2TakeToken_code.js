_call_function(GoodXevilPaySolver_GXP_ReCaptchav2TakeToken,{ "APIKEY": (<%= rwbzfbie %>),"site_url": (<%= zvzpnxwz %>),"sitekey": (<%= gulvxcws %>) })!
<%= variable %> = _result_function()
