var fbucaowh = GetInputConstructorValue("fbucaowh", loader);
                 if(fbucaowh["original"].length == 0)
                 {
                   Invalid("hCaptcha_USE" + " is empty");
                   return;
                 }
var ibrglglm = GetInputConstructorValue("ibrglglm", loader);
                 if(ibrglglm["original"].length == 0)
                 {
                   Invalid("ReCaptcha_USE" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_ForAutosolveReHCaptcha_code").html())({"fbucaowh": fbucaowh["updated"],"ibrglglm": ibrglglm["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
