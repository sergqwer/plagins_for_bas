<div class="container-fluid">
<%= _.template($('#input_constructor').html())({id:"bgjbgxxm", description:"apikey", default_selector: "string", disable_int:true, value_string: "", help: {description: "apikey с сервиса https://t.me/Xevil_check_bot\n\napikey from https://t.me/Xevil_check_bot"} }) %>
<%= _.template($('#input_constructor').html())({id:"armjekxp", description:"mouse", default_selector: "expression", disable_int:true, disable_string:true, value_string: "true", help: {description: "Включить емуляцию движения миши: true - включить, false - отключить\n\nEnable mouse movement imulation: true - enable, false - disable"} }) %>
</div>
<div class="tooltipinternal">
<div class="tr tooltip-paragraph-first-fold">Эта функция решает капчу антибот через сервис решения капчи https://t.me/Xevil_check_bot</div>
<div class="tr tooltip-paragraph-fold">Для работы достаточно вызвать ее не странице с капчей</div>
<div class="tr tooltip-paragraph-fold">This function solves captcha antibot through the captcha solving service https://t.me/Xevil_check_bot.</div>
<div class="tr tooltip-paragraph-last-fold">To work, you just need to call it on the page with the captcha</div>
</div>
<%= _.template($('#back').html())({action:"executeandadd", visible:true}) %>
