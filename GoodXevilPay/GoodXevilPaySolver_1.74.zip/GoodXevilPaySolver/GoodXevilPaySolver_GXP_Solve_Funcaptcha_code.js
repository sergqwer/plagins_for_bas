_call_function(GoodXevilPaySolver_GXP_Solve_Funcaptcha,{ "APIKey": (<%= ybcpieii %>),"CaptchaNumber": (<%= lutrhmbn %>),"CaptchaSelector": (<%= zorbadls %>),"MaxLimitTask": (<%= riwvtflv %>) })!
