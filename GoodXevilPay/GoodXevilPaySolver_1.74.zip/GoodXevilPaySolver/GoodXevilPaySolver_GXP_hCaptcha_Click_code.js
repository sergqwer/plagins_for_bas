_call_function(GoodXevilPaySolver_GXP_hCaptcha_Click,{ "apikey": (<%= qtlbxixf %>),"CaptchaSelector": (<%= jhspznkm %>),"InvisibleCaptcha": (<%= otbvfmzo %>),"TrySolve": (<%= ktlxkopn %>) })!
