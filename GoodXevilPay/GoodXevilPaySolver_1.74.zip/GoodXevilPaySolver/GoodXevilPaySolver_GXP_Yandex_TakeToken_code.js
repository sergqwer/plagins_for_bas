_call_function(GoodXevilPaySolver_GXP_Yandex_TakeToken,{ "apikey": (<%= oklcfxnh %>),"pageurl": (<%= jscxdgfg %>),"sitekey": (<%= iodedhvo %>) })!
<%= variable %> = _result_function()
