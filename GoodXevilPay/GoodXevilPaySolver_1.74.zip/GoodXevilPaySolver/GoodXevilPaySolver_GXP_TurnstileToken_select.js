var iaxyrvuw = GetInputConstructorValue("iaxyrvuw", loader);
                 if(iaxyrvuw["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var jhtfdfkq = GetInputConstructorValue("jhtfdfkq", loader);
                 if(jhtfdfkq["original"].length == 0)
                 {
                   Invalid("site_url" + " is empty");
                   return;
                 }
var pmemrsdt = GetInputConstructorValue("pmemrsdt", loader);
                 if(pmemrsdt["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_TurnstileToken_code").html())({"iaxyrvuw": iaxyrvuw["updated"],"jhtfdfkq": jhtfdfkq["updated"],"pmemrsdt": pmemrsdt["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
