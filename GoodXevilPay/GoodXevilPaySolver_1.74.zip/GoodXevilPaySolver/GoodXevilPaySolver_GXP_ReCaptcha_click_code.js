_call_function(GoodXevilPaySolver_GXP_ReCaptcha_click,{ "apikey": (<%= vcgdgnug %>),"CaptchaSelector": (<%= ihxonhtp %>),"InvisibleCaptcha": (<%= bztyxouz %>),"TrySolve": (<%= qjeoefnb %>) })!
