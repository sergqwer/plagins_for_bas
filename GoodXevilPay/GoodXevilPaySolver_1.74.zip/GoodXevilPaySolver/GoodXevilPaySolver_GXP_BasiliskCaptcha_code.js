_call_function(GoodXevilPaySolver_GXP_BasiliskCaptcha,{ "apikey": (<%= xdrdoxik %>),"sitekey": (<%= awlvyrzi %>),"siteurl": (<%= jmvqoukq %>) })!
