var nclzyaec = GetInputConstructorValue("nclzyaec", loader);
                 if(nclzyaec["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var dpnodkww = GetInputConstructorValue("dpnodkww", loader);
                 if(dpnodkww["original"].length == 0)
                 {
                   Invalid("arab_fix" + " is empty");
                   return;
                 }
var zgeboqwu = GetInputConstructorValue("zgeboqwu", loader);
                 if(zgeboqwu["original"].length == 0)
                 {
                   Invalid("captcha_submit" + " is empty");
                   return;
                 }
var smaxxamz = GetInputConstructorValue("smaxxamz", loader);
                 if(smaxxamz["original"].length == 0)
                 {
                   Invalid("foto_captcha" + " is empty");
                   return;
                 }
var urfgeloh = GetInputConstructorValue("urfgeloh", loader);
                 if(urfgeloh["original"].length == 0)
                 {
                   Invalid("pixel_coef" + " is empty");
                   return;
                 }
var hmiejlmg = GetInputConstructorValue("hmiejlmg", loader);
                 if(hmiejlmg["original"].length == 0)
                 {
                   Invalid("reload_captcha" + " is empty");
                   return;
                 }
var drsbllvn = GetInputConstructorValue("drsbllvn", loader);
                 if(drsbllvn["original"].length == 0)
                 {
                   Invalid("type_data" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SolverGeetestIcon_code").html())({"nclzyaec": nclzyaec["updated"],"dpnodkww": dpnodkww["updated"],"zgeboqwu": zgeboqwu["updated"],"smaxxamz": smaxxamz["updated"],"urfgeloh": urfgeloh["updated"],"hmiejlmg": hmiejlmg["updated"],"drsbllvn": drsbllvn["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
