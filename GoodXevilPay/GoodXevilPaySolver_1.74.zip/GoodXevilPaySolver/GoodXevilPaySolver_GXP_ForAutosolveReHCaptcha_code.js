_call_function(GoodXevilPaySolver_GXP_ForAutosolveReHCaptcha,{ "hCaptcha_USE": (<%= fbucaowh %>),"ReCaptcha_USE": (<%= ibrglglm %>) })!
