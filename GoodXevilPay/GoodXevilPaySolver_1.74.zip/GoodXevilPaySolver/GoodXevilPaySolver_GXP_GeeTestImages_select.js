var kzwgceoh = GetInputConstructorValue("kzwgceoh", loader);
                 if(kzwgceoh["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var ajzlxkgp = GetInputConstructorValue("ajzlxkgp", loader);
                 if(ajzlxkgp["original"].length == 0)
                 {
                   Invalid("images_button" + " is empty");
                   return;
                 }
var spmdffxv = GetInputConstructorValue("spmdffxv", loader);
                 if(spmdffxv["original"].length == 0)
                 {
                   Invalid("reload_button" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_GeeTestImages_code").html())({"kzwgceoh": kzwgceoh["updated"],"ajzlxkgp": ajzlxkgp["updated"],"spmdffxv": spmdffxv["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
