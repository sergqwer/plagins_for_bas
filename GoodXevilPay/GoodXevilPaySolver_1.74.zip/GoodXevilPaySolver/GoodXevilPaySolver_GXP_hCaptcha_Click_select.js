var qtlbxixf = GetInputConstructorValue("qtlbxixf", loader);
                 if(qtlbxixf["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var jhspznkm = GetInputConstructorValue("jhspznkm", loader);
                 if(jhspznkm["original"].length == 0)
                 {
                   Invalid("CaptchaSelector" + " is empty");
                   return;
                 }
var otbvfmzo = GetInputConstructorValue("otbvfmzo", loader);
                 if(otbvfmzo["original"].length == 0)
                 {
                   Invalid("InvisibleCaptcha" + " is empty");
                   return;
                 }
var ktlxkopn = GetInputConstructorValue("ktlxkopn", loader);
                 if(ktlxkopn["original"].length == 0)
                 {
                   Invalid("TrySolve" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_hCaptcha_Click_code").html())({"qtlbxixf": qtlbxixf["updated"],"jhspznkm": jhspznkm["updated"],"otbvfmzo": otbvfmzo["updated"],"ktlxkopn": ktlxkopn["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
