var fgwkhxwx = GetInputConstructorValue("fgwkhxwx", loader);
                 if(fgwkhxwx["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var qawaxyyf = GetInputConstructorValue("qawaxyyf", loader);
                 if(qawaxyyf["original"].length == 0)
                 {
                   Invalid("site_url" + " is empty");
                   return;
                 }
var aiyuqjcc = GetInputConstructorValue("aiyuqjcc", loader);
                 if(aiyuqjcc["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_HcaptchaTakeToken_code").html())({"fgwkhxwx": fgwkhxwx["updated"],"qawaxyyf": qawaxyyf["updated"],"aiyuqjcc": aiyuqjcc["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
