_call_function(GoodXevilPaySolver_GXP_TurnstileToken,{ "APIKEY": (<%= iaxyrvuw %>),"site_url": (<%= jhtfdfkq %>),"sitekey": (<%= pmemrsdt %>) })!
<%= variable %> = _result_function()
