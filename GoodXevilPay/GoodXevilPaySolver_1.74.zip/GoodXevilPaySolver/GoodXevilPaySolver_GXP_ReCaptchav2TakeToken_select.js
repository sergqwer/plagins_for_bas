var rwbzfbie = GetInputConstructorValue("rwbzfbie", loader);
                 if(rwbzfbie["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var zvzpnxwz = GetInputConstructorValue("zvzpnxwz", loader);
                 if(zvzpnxwz["original"].length == 0)
                 {
                   Invalid("site_url" + " is empty");
                   return;
                 }
var gulvxcws = GetInputConstructorValue("gulvxcws", loader);
                 if(gulvxcws["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_ReCaptchav2TakeToken_code").html())({"rwbzfbie": rwbzfbie["updated"],"zvzpnxwz": zvzpnxwz["updated"],"gulvxcws": gulvxcws["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
