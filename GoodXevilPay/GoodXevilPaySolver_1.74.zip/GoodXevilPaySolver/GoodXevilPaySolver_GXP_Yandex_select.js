var rzuxibco = GetInputConstructorValue("rzuxibco", loader);
                 if(rzuxibco["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var wylwpwqj = GetInputConstructorValue("wylwpwqj", loader);
                 if(wylwpwqj["original"].length == 0)
                 {
                   Invalid("CaptchaSelector" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_Yandex_code").html())({"rzuxibco": rzuxibco["updated"],"wylwpwqj": wylwpwqj["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
