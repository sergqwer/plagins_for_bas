var vcgdgnug = GetInputConstructorValue("vcgdgnug", loader);
                 if(vcgdgnug["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var ihxonhtp = GetInputConstructorValue("ihxonhtp", loader);
                 if(ihxonhtp["original"].length == 0)
                 {
                   Invalid("CaptchaSelector" + " is empty");
                   return;
                 }
var bztyxouz = GetInputConstructorValue("bztyxouz", loader);
                 if(bztyxouz["original"].length == 0)
                 {
                   Invalid("InvisibleCaptcha" + " is empty");
                   return;
                 }
var qjeoefnb = GetInputConstructorValue("qjeoefnb", loader);
                 if(qjeoefnb["original"].length == 0)
                 {
                   Invalid("TrySolve" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_ReCaptcha_click_code").html())({"vcgdgnug": vcgdgnug["updated"],"ihxonhtp": ihxonhtp["updated"],"bztyxouz": bztyxouz["updated"],"qjeoefnb": qjeoefnb["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
