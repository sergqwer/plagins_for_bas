var oklcfxnh = GetInputConstructorValue("oklcfxnh", loader);
                 if(oklcfxnh["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var jscxdgfg = GetInputConstructorValue("jscxdgfg", loader);
                 if(jscxdgfg["original"].length == 0)
                 {
                   Invalid("pageurl" + " is empty");
                   return;
                 }
var iodedhvo = GetInputConstructorValue("iodedhvo", loader);
                 if(iodedhvo["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_Yandex_TakeToken_code").html())({"oklcfxnh": oklcfxnh["updated"],"jscxdgfg": jscxdgfg["updated"],"iodedhvo": iodedhvo["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
