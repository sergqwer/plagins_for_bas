<div class="container-fluid">
<%= _.template($('#input_constructor').html())({id:"pfdhqsef", description:"apikey", default_selector: "string", disable_expression:true, disable_int:true, value_string: "", help: {description: "apikey с сервиса https://t.me/Xevil_check_bot\n\napikey from https://t.me/Xevil_check_bot"} }) %>
</div>
<div class="tooltipinternal">
<div class="tr tooltip-paragraph-first-fold">Автоматически решает капчу на сайте work.cash</div>
<div class="tr tooltip-paragraph-last-fold">Automatically solves captcha on work.cash site</div>
</div>
<%= _.template($('#back').html())({action:"executeandadd", visible:true}) %>
