_call_function(GoodXevilPaySolver_GXP_AutoBypassCloudFlare,{ "custom_button": (<%= aesgppza %>),"max_time": (<%= yzwrhush %>),"whait_element": (<%= teqjpivy %>) })!
