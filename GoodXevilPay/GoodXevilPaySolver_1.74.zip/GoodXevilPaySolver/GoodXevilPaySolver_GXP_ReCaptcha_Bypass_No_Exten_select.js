var mbvlsmij = GetInputConstructorValue("mbvlsmij", loader);
                 if(mbvlsmij["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var fptivbhw = GetInputConstructorValue("fptivbhw", loader);
                 if(fptivbhw["original"].length == 0)
                 {
                   Invalid("enterprise" + " is empty");
                   return;
                 }
var eodvcogt = GetInputConstructorValue("eodvcogt", loader);
                 if(eodvcogt["original"].length == 0)
                 {
                   Invalid("index" + " is empty");
                   return;
                 }
var cetrlqzg = GetInputConstructorValue("cetrlqzg", loader);
                 if(cetrlqzg["original"].length == 0)
                 {
                   Invalid("invisible" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_ReCaptcha_Bypass_No_Exten_code").html())({"mbvlsmij": mbvlsmij["updated"],"fptivbhw": fptivbhw["updated"],"eodvcogt": eodvcogt["updated"],"cetrlqzg": cetrlqzg["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
