_call_function(GoodXevilPaySolver_GXP_HcaptchaTakeToken,{ "APIKEY": (<%= fgwkhxwx %>),"site_url": (<%= qawaxyyf %>),"sitekey": (<%= aiyuqjcc %>) })!
<%= variable %> = _result_function()
