<div class="container-fluid">
<%= _.template($('#input_constructor').html())({id:"jysldhqh", description:"apikey", default_selector: "string", disable_int:true, value_string: "", help: {description: "Ваш api ключ с сервиса https://t.me/Xevil_check_bot"} }) %>
<%= _.template($('#input_constructor').html())({id:"axrvugkp", description:"button_capthca", default_selector: "string", disable_int:true, value_string: " >CSS> .geetest_btn_click", help: {description: "Идентификатор кнопки, после нажатия которой появляется капча"} }) %>
<%= _.template($('#input_constructor').html())({id:"pnsnvzqi", description:"captcha_submit", default_selector: "string", disable_int:true, value_string: " >CSS> .geetest_submit", help: {description: "Идентификатор кнопки, подтвердить решение"} }) %>
<%= _.template($('#input_constructor').html())({id:"yrafeuxg", description:"foto_captcha", default_selector: "string", disable_int:true, value_string: " >CSS> .geetest_bg", help: {description: "Идентификатор кнопки, фото капчи"} }) %>
<%= _.template($('#input_constructor').html())({id:"kcrmbmog", description:"pixel_coef", default_selector: "int", disable_string:true, value_number: 0, min_number:-999999, max_number:999999, help: {description: "Число пикселей для коректировки результата"} }) %>
<%= _.template($('#input_constructor').html())({id:"bdovgxyx", description:"reload_captcha", default_selector: "string", disable_int:true, value_string: " >CSS> .geetest_refresh", help: {description: "Идентификатор кнопки, обновление капчи"} }) %>
</div>
<div class="tooltipinternal">
<div class="tr tooltip-paragraph-first-fold">Автоматически решает Geetest Icon на странице, для работы требуется функция GXP_AllowCacheForGeetestIcon</div>
</div>
<%= _.template($('#back').html())({action:"executeandadd", visible:true}) %>
