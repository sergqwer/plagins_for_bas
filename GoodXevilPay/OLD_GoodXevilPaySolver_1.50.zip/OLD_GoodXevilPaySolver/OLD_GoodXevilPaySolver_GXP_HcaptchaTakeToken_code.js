_call_function(OLD_GoodXevilPaySolver_GXP_HcaptchaTakeToken,{ "APIKEY": (<%= qxbfuwtd %>),"site_url": (<%= updvkxlt %>),"sitekey": (<%= jadssjyp %>) })!
<%= variable %> = _result_function()
