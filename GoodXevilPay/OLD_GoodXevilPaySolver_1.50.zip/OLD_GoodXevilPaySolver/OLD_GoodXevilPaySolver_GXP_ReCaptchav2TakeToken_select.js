var vohrhrqz = GetInputConstructorValue("vohrhrqz", loader);
                 if(vohrhrqz["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var kefqoqru = GetInputConstructorValue("kefqoqru", loader);
                 if(kefqoqru["original"].length == 0)
                 {
                   Invalid("site_url" + " is empty");
                   return;
                 }
var idcpoypy = GetInputConstructorValue("idcpoypy", loader);
                 if(idcpoypy["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#OLD_GoodXevilPaySolver_GXP_ReCaptchav2TakeToken_code").html())({"vohrhrqz": vohrhrqz["updated"],"kefqoqru": kefqoqru["updated"],"idcpoypy": idcpoypy["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
