_call_function(OLD_GoodXevilPaySolver_GXP_GetBalance,{ "APIKEY": (<%= xwyuxmtq %>) })!
<%= variable %> = _result_function()
