var cspaolhq = GetInputConstructorValue("cspaolhq", loader);
                 if(cspaolhq["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var gtouzsyw = GetInputConstructorValue("gtouzsyw", loader);
                 if(gtouzsyw["original"].length == 0)
                 {
                   Invalid("mouse" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#OLD_GoodXevilPaySolver_GXP_Antibot_code").html())({"cspaolhq": cspaolhq["updated"],"gtouzsyw": gtouzsyw["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
