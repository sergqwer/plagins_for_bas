var jysldhqh = GetInputConstructorValue("jysldhqh", loader);
                 if(jysldhqh["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var axrvugkp = GetInputConstructorValue("axrvugkp", loader);
                 if(axrvugkp["original"].length == 0)
                 {
                   Invalid("button_capthca" + " is empty");
                   return;
                 }
var pnsnvzqi = GetInputConstructorValue("pnsnvzqi", loader);
                 if(pnsnvzqi["original"].length == 0)
                 {
                   Invalid("captcha_submit" + " is empty");
                   return;
                 }
var yrafeuxg = GetInputConstructorValue("yrafeuxg", loader);
                 if(yrafeuxg["original"].length == 0)
                 {
                   Invalid("foto_captcha" + " is empty");
                   return;
                 }
var kcrmbmog = GetInputConstructorValue("kcrmbmog", loader);
                 if(kcrmbmog["original"].length == 0)
                 {
                   Invalid("pixel_coef" + " is empty");
                   return;
                 }
var bdovgxyx = GetInputConstructorValue("bdovgxyx", loader);
                 if(bdovgxyx["original"].length == 0)
                 {
                   Invalid("reload_captcha" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#OLD_GoodXevilPaySolver_GXP_SolverGeetestIcon_code").html())({"jysldhqh": jysldhqh["updated"],"axrvugkp": axrvugkp["updated"],"pnsnvzqi": pnsnvzqi["updated"],"yrafeuxg": yrafeuxg["updated"],"kcrmbmog": kcrmbmog["updated"],"bdovgxyx": bdovgxyx["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
