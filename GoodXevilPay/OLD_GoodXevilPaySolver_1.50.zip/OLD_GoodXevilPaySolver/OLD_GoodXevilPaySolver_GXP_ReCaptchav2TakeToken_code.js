_call_function(OLD_GoodXevilPaySolver_GXP_ReCaptchav2TakeToken,{ "APIKEY": (<%= vohrhrqz %>),"site_url": (<%= kefqoqru %>),"sitekey": (<%= idcpoypy %>) })!
<%= variable %> = _result_function()
