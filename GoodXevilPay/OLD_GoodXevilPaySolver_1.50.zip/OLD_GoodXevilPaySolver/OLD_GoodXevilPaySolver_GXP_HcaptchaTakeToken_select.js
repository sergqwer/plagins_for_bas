var qxbfuwtd = GetInputConstructorValue("qxbfuwtd", loader);
                 if(qxbfuwtd["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var updvkxlt = GetInputConstructorValue("updvkxlt", loader);
                 if(updvkxlt["original"].length == 0)
                 {
                   Invalid("site_url" + " is empty");
                   return;
                 }
var jadssjyp = GetInputConstructorValue("jadssjyp", loader);
                 if(jadssjyp["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#OLD_GoodXevilPaySolver_GXP_HcaptchaTakeToken_code").html())({"qxbfuwtd": qxbfuwtd["updated"],"updvkxlt": updvkxlt["updated"],"jadssjyp": jadssjyp["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
