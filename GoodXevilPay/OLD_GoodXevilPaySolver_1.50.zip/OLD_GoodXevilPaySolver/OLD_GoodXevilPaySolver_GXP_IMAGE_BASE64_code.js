_call_function(OLD_GoodXevilPaySolver_GXP_IMAGE_BASE64,{ "APIKEY": (<%= vmhytcfk %>),"IMAGE_BASE64": (<%= awihfcmx %>) })!
<%= variable %> = _result_function()
