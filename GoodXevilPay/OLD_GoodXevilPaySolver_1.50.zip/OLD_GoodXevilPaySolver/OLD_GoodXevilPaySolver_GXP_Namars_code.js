_call_function(OLD_GoodXevilPaySolver_GXP_Namars,{ "apikey": (<%= mrxszcod %>) })!
<%= variable %> = _result_function()
