var hxzvczcf = GetInputConstructorValue("hxzvczcf", loader);
                 if(hxzvczcf["original"].length == 0)
                 {
                   Invalid("arrow_id" + " is empty");
                   return;
                 }
var lylrqlhj = GetInputConstructorValue("lylrqlhj", loader);
                 if(lylrqlhj["original"].length == 0)
                 {
                   Invalid("avtoupdate" + " is empty");
                   return;
                 }
var xshrnkte = GetInputConstructorValue("xshrnkte", loader);
                 if(xshrnkte["original"].length == 0)
                 {
                   Invalid("button_id" + " is empty");
                   return;
                 }
var dyiukjni = GetInputConstructorValue("dyiukjni", loader);
                 if(dyiukjni["original"].length == 0)
                 {
                   Invalid("coef" + " is empty");
                   return;
                 }
var akaaxnsr = GetInputConstructorValue("akaaxnsr", loader);
                 if(akaaxnsr["original"].length == 0)
                 {
                   Invalid("image id" + " is empty");
                   return;
                 }
var kqplrucx = GetInputConstructorValue("kqplrucx", loader);
                 if(kqplrucx["original"].length == 0)
                 {
                   Invalid("key" + " is empty");
                   return;
                 }
var xywotulq = GetInputConstructorValue("xywotulq", loader);
                 if(xywotulq["original"].length == 0)
                 {
                   Invalid("pixel_koef" + " is empty");
                   return;
                 }
var rlwtubgb = GetInputConstructorValue("rlwtubgb", loader);
                 if(rlwtubgb["original"].length == 0)
                 {
                   Invalid("reload_id" + " is empty");
                   return;
                 }
var kimqmogf = GetInputConstructorValue("kimqmogf", loader);
                 if(kimqmogf["original"].length == 0)
                 {
                   Invalid("speed" + " is empty");
                   return;
                 }
var cgzrjerz = GetInputConstructorValue("cgzrjerz", loader);
                 if(cgzrjerz["original"].length == 0)
                 {
                   Invalid("type_slide" + " is empty");
                   return;
                 }
var wlkvcfze = GetInputConstructorValue("wlkvcfze", loader);
                 if(wlkvcfze["original"].length == 0)
                 {
                   Invalid("type_swipe" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#OLD_GoodXevilPaySolver_GXP_SliderSolver_code").html())({"hxzvczcf": hxzvczcf["updated"],"lylrqlhj": lylrqlhj["updated"],"xshrnkte": xshrnkte["updated"],"dyiukjni": dyiukjni["updated"],"akaaxnsr": akaaxnsr["updated"],"kqplrucx": kqplrucx["updated"],"xywotulq": xywotulq["updated"],"rlwtubgb": rlwtubgb["updated"],"kimqmogf": kimqmogf["updated"],"cgzrjerz": cgzrjerz["updated"],"wlkvcfze": wlkvcfze["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
