var aamlmjif = GetInputConstructorValue("aamlmjif", loader);
                 if(aamlmjif["original"].length == 0)
                 {
                   Invalid("arrow_id" + " is empty");
                   return;
                 }
var gxfkvkhj = GetInputConstructorValue("gxfkvkhj", loader);
                 if(gxfkvkhj["original"].length == 0)
                 {
                   Invalid("avtoupdate" + " is empty");
                   return;
                 }
var yoeuwpzt = GetInputConstructorValue("yoeuwpzt", loader);
                 if(yoeuwpzt["original"].length == 0)
                 {
                   Invalid("button_id" + " is empty");
                   return;
                 }
var wfnsvlhc = GetInputConstructorValue("wfnsvlhc", loader);
                 if(wfnsvlhc["original"].length == 0)
                 {
                   Invalid("coef" + " is empty");
                   return;
                 }
var ueemcvih = GetInputConstructorValue("ueemcvih", loader);
                 if(ueemcvih["original"].length == 0)
                 {
                   Invalid("image id" + " is empty");
                   return;
                 }
var jmqryafg = GetInputConstructorValue("jmqryafg", loader);
                 if(jmqryafg["original"].length == 0)
                 {
                   Invalid("key" + " is empty");
                   return;
                 }
var zllbmvpq = GetInputConstructorValue("zllbmvpq", loader);
                 if(zllbmvpq["original"].length == 0)
                 {
                   Invalid("pixel_koef" + " is empty");
                   return;
                 }
var axnrftsm = GetInputConstructorValue("axnrftsm", loader);
                 if(axnrftsm["original"].length == 0)
                 {
                   Invalid("reload_id" + " is empty");
                   return;
                 }
var hfcyfmec = GetInputConstructorValue("hfcyfmec", loader);
                 if(hfcyfmec["original"].length == 0)
                 {
                   Invalid("speed" + " is empty");
                   return;
                 }
var aiotoriw = GetInputConstructorValue("aiotoriw", loader);
                 if(aiotoriw["original"].length == 0)
                 {
                   Invalid("type_slide" + " is empty");
                   return;
                 }
var wxxpawpn = GetInputConstructorValue("wxxpawpn", loader);
                 if(wxxpawpn["original"].length == 0)
                 {
                   Invalid("type_swipe" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SliderSolver_code").html())({"aamlmjif": aamlmjif["updated"],"gxfkvkhj": gxfkvkhj["updated"],"yoeuwpzt": yoeuwpzt["updated"],"wfnsvlhc": wfnsvlhc["updated"],"ueemcvih": ueemcvih["updated"],"jmqryafg": jmqryafg["updated"],"zllbmvpq": zllbmvpq["updated"],"axnrftsm": axnrftsm["updated"],"hfcyfmec": hfcyfmec["updated"],"aiotoriw": aiotoriw["updated"],"wxxpawpn": wxxpawpn["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
