_call_function(GoodXevilPaySolver_GXP_AutoBypassCloudFlare,{ "custom_button": (<%= dwbhorwc %>),"max_time": (<%= mppxgfsr %>),"whait_element": (<%= lxzziuwl %>) })!
