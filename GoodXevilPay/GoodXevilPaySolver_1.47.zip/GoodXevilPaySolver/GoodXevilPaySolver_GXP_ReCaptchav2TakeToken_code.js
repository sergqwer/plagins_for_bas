_call_function(GoodXevilPaySolver_GXP_ReCaptchav2TakeToken,{ "APIKEY": (<%= qcapklzh %>),"site_url": (<%= ogijkyys %>),"sitekey": (<%= csjaydxy %>) })!
<%= variable %> = _result_function()
