var dwbhorwc = GetInputConstructorValue("dwbhorwc", loader);
                 if(dwbhorwc["original"].length == 0)
                 {
                   Invalid("custom_button" + " is empty");
                   return;
                 }
var mppxgfsr = GetInputConstructorValue("mppxgfsr", loader);
                 if(mppxgfsr["original"].length == 0)
                 {
                   Invalid("max_time" + " is empty");
                   return;
                 }
var lxzziuwl = GetInputConstructorValue("lxzziuwl", loader);
                 if(lxzziuwl["original"].length == 0)
                 {
                   Invalid("whait_element" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_AutoBypassCloudFlare_code").html())({"dwbhorwc": dwbhorwc["updated"],"mppxgfsr": mppxgfsr["updated"],"lxzziuwl": lxzziuwl["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
