var qcapklzh = GetInputConstructorValue("qcapklzh", loader);
                 if(qcapklzh["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var ogijkyys = GetInputConstructorValue("ogijkyys", loader);
                 if(ogijkyys["original"].length == 0)
                 {
                   Invalid("site_url" + " is empty");
                   return;
                 }
var csjaydxy = GetInputConstructorValue("csjaydxy", loader);
                 if(csjaydxy["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_ReCaptchav2TakeToken_code").html())({"qcapklzh": qcapklzh["updated"],"ogijkyys": ogijkyys["updated"],"csjaydxy": csjaydxy["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
