var hxsehiii = GetInputConstructorValue("hxsehiii", loader);
                 if(hxsehiii["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var yaairexs = GetInputConstructorValue("yaairexs", loader);
                 if(yaairexs["original"].length == 0)
                 {
                   Invalid("button_capthca" + " is empty");
                   return;
                 }
var wxrzdpmt = GetInputConstructorValue("wxrzdpmt", loader);
                 if(wxrzdpmt["original"].length == 0)
                 {
                   Invalid("captcha_submit" + " is empty");
                   return;
                 }
var xbkhguqz = GetInputConstructorValue("xbkhguqz", loader);
                 if(xbkhguqz["original"].length == 0)
                 {
                   Invalid("foto_captcha" + " is empty");
                   return;
                 }
var ulvtyraj = GetInputConstructorValue("ulvtyraj", loader);
                 if(ulvtyraj["original"].length == 0)
                 {
                   Invalid("reload_captcha" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SolverGeetestIcon_code").html())({"hxsehiii": hxsehiii["updated"],"yaairexs": yaairexs["updated"],"wxrzdpmt": wxrzdpmt["updated"],"xbkhguqz": xbkhguqz["updated"],"ulvtyraj": ulvtyraj["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
