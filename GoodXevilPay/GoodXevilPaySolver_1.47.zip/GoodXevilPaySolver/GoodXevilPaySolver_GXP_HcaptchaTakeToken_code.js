_call_function(GoodXevilPaySolver_GXP_HcaptchaTakeToken,{ "APIKEY": (<%= abiolxky %>),"site_url": (<%= yxaifsww %>),"sitekey": (<%= isoyzvum %>) })!
<%= variable %> = _result_function()
