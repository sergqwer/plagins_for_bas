_call_function(GoodXevilPaySolver_GXP_IMAGE_BASE64,{ "APIKEY": (<%= lvhdbqql %>),"IMAGE_BASE64": (<%= wdgldkxk %>) })!
<%= variable %> = _result_function()
