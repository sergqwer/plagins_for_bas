_call_function(GoodXevilPaySolver_GXP_RsCaptchaSolver,{ "apikey": (<%= tdqahoyt %>) })!
