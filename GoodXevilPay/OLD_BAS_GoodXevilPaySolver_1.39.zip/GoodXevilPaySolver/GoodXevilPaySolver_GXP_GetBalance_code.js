_call_function(GoodXevilPaySolver_GXP_GetBalance,{ "APIKEY": (<%= ibzjibmq %>) })!
<%= variable %> = _result_function()
