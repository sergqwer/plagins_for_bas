_call_function(GoodXevilPaySolver_GXP_ReCaptchav2TakeToken,{ "APIKEY": (<%= wfrhvegh %>),"site_url": (<%= boogkcfm %>),"sitekey": (<%= krvwcqfk %>) })!
<%= variable %> = _result_function()
