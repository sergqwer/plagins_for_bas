_call_function(GoodXevilPaySolver_GXP_IMAGE_BASE64,{ "APIKEY": (<%= dfbujnxv %>),"IMAGE_BASE64": (<%= neuueyxw %>) })!
<%= variable %> = _result_function()
