var ltenihpt = GetInputConstructorValue("ltenihpt", loader);
                 if(ltenihpt["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var iatgyvks = GetInputConstructorValue("iatgyvks", loader);
                 if(iatgyvks["original"].length == 0)
                 {
                   Invalid("button_capthca" + " is empty");
                   return;
                 }
var mnhgtwlc = GetInputConstructorValue("mnhgtwlc", loader);
                 if(mnhgtwlc["original"].length == 0)
                 {
                   Invalid("captcha_submit" + " is empty");
                   return;
                 }
var nwtmpavq = GetInputConstructorValue("nwtmpavq", loader);
                 if(nwtmpavq["original"].length == 0)
                 {
                   Invalid("foto_captcha" + " is empty");
                   return;
                 }
var ldajmckf = GetInputConstructorValue("ldajmckf", loader);
                 if(ldajmckf["original"].length == 0)
                 {
                   Invalid("reload_captcha" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SolverGeetestIcon_code").html())({"ltenihpt": ltenihpt["updated"],"iatgyvks": iatgyvks["updated"],"mnhgtwlc": mnhgtwlc["updated"],"nwtmpavq": nwtmpavq["updated"],"ldajmckf": ldajmckf["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
