_call_function(GoodXevilPaySolver_GXP_HcaptchaTakeToken,{ "APIKEY": (<%= ctnxwkzt %>),"site_url": (<%= jfryphcl %>),"sitekey": (<%= ncyzclde %>) })!
<%= variable %> = _result_function()
