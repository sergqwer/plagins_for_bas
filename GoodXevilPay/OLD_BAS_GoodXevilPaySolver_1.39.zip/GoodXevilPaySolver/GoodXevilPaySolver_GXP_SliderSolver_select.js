var ipxzffew = GetInputConstructorValue("ipxzffew", loader);
                 if(ipxzffew["original"].length == 0)
                 {
                   Invalid("arrow_id" + " is empty");
                   return;
                 }
var hxatklqc = GetInputConstructorValue("hxatklqc", loader);
                 if(hxatklqc["original"].length == 0)
                 {
                   Invalid("avtoupdate" + " is empty");
                   return;
                 }
var jhygwyqo = GetInputConstructorValue("jhygwyqo", loader);
                 if(jhygwyqo["original"].length == 0)
                 {
                   Invalid("button_id" + " is empty");
                   return;
                 }
var qzxysqru = GetInputConstructorValue("qzxysqru", loader);
                 if(qzxysqru["original"].length == 0)
                 {
                   Invalid("coef" + " is empty");
                   return;
                 }
var xeteqboo = GetInputConstructorValue("xeteqboo", loader);
                 if(xeteqboo["original"].length == 0)
                 {
                   Invalid("image id" + " is empty");
                   return;
                 }
var okelddrd = GetInputConstructorValue("okelddrd", loader);
                 if(okelddrd["original"].length == 0)
                 {
                   Invalid("key" + " is empty");
                   return;
                 }
var npzodkuv = GetInputConstructorValue("npzodkuv", loader);
                 if(npzodkuv["original"].length == 0)
                 {
                   Invalid("pixel_koef" + " is empty");
                   return;
                 }
var clpgppsw = GetInputConstructorValue("clpgppsw", loader);
                 if(clpgppsw["original"].length == 0)
                 {
                   Invalid("reload_id" + " is empty");
                   return;
                 }
var mmyflzls = GetInputConstructorValue("mmyflzls", loader);
                 if(mmyflzls["original"].length == 0)
                 {
                   Invalid("speed" + " is empty");
                   return;
                 }
var ppdlzwcs = GetInputConstructorValue("ppdlzwcs", loader);
                 if(ppdlzwcs["original"].length == 0)
                 {
                   Invalid("type_slide" + " is empty");
                   return;
                 }
var nyfdqakm = GetInputConstructorValue("nyfdqakm", loader);
                 if(nyfdqakm["original"].length == 0)
                 {
                   Invalid("type_swipe" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SliderSolver_code").html())({"ipxzffew": ipxzffew["updated"],"hxatklqc": hxatklqc["updated"],"jhygwyqo": jhygwyqo["updated"],"qzxysqru": qzxysqru["updated"],"xeteqboo": xeteqboo["updated"],"okelddrd": okelddrd["updated"],"npzodkuv": npzodkuv["updated"],"clpgppsw": clpgppsw["updated"],"mmyflzls": mmyflzls["updated"],"ppdlzwcs": ppdlzwcs["updated"],"nyfdqakm": nyfdqakm["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
