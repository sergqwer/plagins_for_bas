var ctnxwkzt = GetInputConstructorValue("ctnxwkzt", loader);
                 if(ctnxwkzt["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var jfryphcl = GetInputConstructorValue("jfryphcl", loader);
                 if(jfryphcl["original"].length == 0)
                 {
                   Invalid("site_url" + " is empty");
                   return;
                 }
var ncyzclde = GetInputConstructorValue("ncyzclde", loader);
                 if(ncyzclde["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_HcaptchaTakeToken_code").html())({"ctnxwkzt": ctnxwkzt["updated"],"jfryphcl": jfryphcl["updated"],"ncyzclde": ncyzclde["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
