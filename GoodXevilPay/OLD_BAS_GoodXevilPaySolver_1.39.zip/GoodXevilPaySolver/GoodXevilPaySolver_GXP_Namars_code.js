_call_function(GoodXevilPaySolver_GXP_Namars,{ "apikey": (<%= qgcvsetd %>) })!
<%= variable %> = _result_function()
