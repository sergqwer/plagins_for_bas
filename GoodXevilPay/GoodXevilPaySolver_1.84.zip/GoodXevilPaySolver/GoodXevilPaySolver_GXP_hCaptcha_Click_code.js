_call_function(GoodXevilPaySolver_GXP_hCaptcha_Click,{ "apikey": (<%= jgtoinjy %>),"CaptchaSelector": (<%= cupvuarg %>),"InvisibleCaptcha": (<%= nlwfgpyv %>),"TrySolve": (<%= nnfijryj %>) })!
