_call_function(GoodXevilPaySolver_GXP_HcaptchaTakeToken,{ "APIKEY": (<%= kezkvwxx %>),"site_url": (<%= pqaqhdmp %>),"sitekey": (<%= dgzymnht %>) })!
<%= variable %> = _result_function()
