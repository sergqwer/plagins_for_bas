var kdxwowtk = GetInputConstructorValue("kdxwowtk", loader);
                 if(kdxwowtk["original"].length == 0)
                 {
                   Invalid("arrow_id" + " is empty");
                   return;
                 }
var mcijeykn = GetInputConstructorValue("mcijeykn", loader);
                 if(mcijeykn["original"].length == 0)
                 {
                   Invalid("avtoupdate" + " is empty");
                   return;
                 }
var mkbdimbk = GetInputConstructorValue("mkbdimbk", loader);
                 if(mkbdimbk["original"].length == 0)
                 {
                   Invalid("button_id" + " is empty");
                   return;
                 }
var qbuisgaf = GetInputConstructorValue("qbuisgaf", loader);
                 if(qbuisgaf["original"].length == 0)
                 {
                   Invalid("coef" + " is empty");
                   return;
                 }
var yevyklhq = GetInputConstructorValue("yevyklhq", loader);
                 if(yevyklhq["original"].length == 0)
                 {
                   Invalid("image id" + " is empty");
                   return;
                 }
var lypoifyx = GetInputConstructorValue("lypoifyx", loader);
                 if(lypoifyx["original"].length == 0)
                 {
                   Invalid("key" + " is empty");
                   return;
                 }
var ckfrlexe = GetInputConstructorValue("ckfrlexe", loader);
                 if(ckfrlexe["original"].length == 0)
                 {
                   Invalid("pixel_koef" + " is empty");
                   return;
                 }
var wzewtppr = GetInputConstructorValue("wzewtppr", loader);
                 if(wzewtppr["original"].length == 0)
                 {
                   Invalid("reload_id" + " is empty");
                   return;
                 }
var dzhnzjby = GetInputConstructorValue("dzhnzjby", loader);
                 if(dzhnzjby["original"].length == 0)
                 {
                   Invalid("speed" + " is empty");
                   return;
                 }
var ynxtcrue = GetInputConstructorValue("ynxtcrue", loader);
                 if(ynxtcrue["original"].length == 0)
                 {
                   Invalid("type_slide" + " is empty");
                   return;
                 }
var jewisina = GetInputConstructorValue("jewisina", loader);
                 if(jewisina["original"].length == 0)
                 {
                   Invalid("type_swipe" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SliderSolver_code").html())({"kdxwowtk": kdxwowtk["updated"],"mcijeykn": mcijeykn["updated"],"mkbdimbk": mkbdimbk["updated"],"qbuisgaf": qbuisgaf["updated"],"yevyklhq": yevyklhq["updated"],"lypoifyx": lypoifyx["updated"],"ckfrlexe": ckfrlexe["updated"],"wzewtppr": wzewtppr["updated"],"dzhnzjby": dzhnzjby["updated"],"ynxtcrue": ynxtcrue["updated"],"jewisina": jewisina["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
