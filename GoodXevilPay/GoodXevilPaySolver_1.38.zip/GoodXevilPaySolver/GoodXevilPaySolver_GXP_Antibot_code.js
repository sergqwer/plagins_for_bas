_call_function(GoodXevilPaySolver_GXP_Antibot,{ "apikey": (<%= qdffgirc %>),"mouse": (<%= dpqbuksi %>) })!
