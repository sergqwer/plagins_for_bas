_call_function(GoodXevilPaySolver_GXP_ReCaptchav2TakeToken,{ "APIKEY": (<%= phwcnnpv %>),"site_url": (<%= apqdechq %>),"sitekey": (<%= yinzzqpb %>) })!
<%= variable %> = _result_function()
