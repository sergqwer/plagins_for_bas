var kezkvwxx = GetInputConstructorValue("kezkvwxx", loader);
                 if(kezkvwxx["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var pqaqhdmp = GetInputConstructorValue("pqaqhdmp", loader);
                 if(pqaqhdmp["original"].length == 0)
                 {
                   Invalid("site_url" + " is empty");
                   return;
                 }
var dgzymnht = GetInputConstructorValue("dgzymnht", loader);
                 if(dgzymnht["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_HcaptchaTakeToken_code").html())({"kezkvwxx": kezkvwxx["updated"],"pqaqhdmp": pqaqhdmp["updated"],"dgzymnht": dgzymnht["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
