var odvmpacr = GetInputConstructorValue("odvmpacr", loader);
                 if(odvmpacr["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var lqcgkpqk = GetInputConstructorValue("lqcgkpqk", loader);
                 if(lqcgkpqk["original"].length == 0)
                 {
                   Invalid("timer" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_BuxMoney_PayupVideo_code").html())({"odvmpacr": odvmpacr["updated"],"lqcgkpqk": lqcgkpqk["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
