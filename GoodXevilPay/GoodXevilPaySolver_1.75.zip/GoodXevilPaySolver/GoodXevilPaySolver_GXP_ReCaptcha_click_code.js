_call_function(GoodXevilPaySolver_GXP_ReCaptcha_click,{ "apikey": (<%= wbamahbt %>),"CaptchaSelector": (<%= bdlijsqf %>),"InvisibleCaptcha": (<%= epvhfqqg %>),"TrySolve": (<%= denyedpo %>) })!
