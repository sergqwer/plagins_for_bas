_call_function(GoodXevilPaySolver_GXP_hCaptcha_Click,{ "apikey": (<%= dlhodgec %>),"CaptchaSelector": (<%= dpinlhwj %>),"InvisibleCaptcha": (<%= nvauxaiv %>),"TrySolve": (<%= nrdvmrlm %>) })!
