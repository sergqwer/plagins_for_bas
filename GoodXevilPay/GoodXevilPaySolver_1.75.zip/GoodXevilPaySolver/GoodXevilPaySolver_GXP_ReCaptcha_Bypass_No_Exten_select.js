var ioayagjq = GetInputConstructorValue("ioayagjq", loader);
                 if(ioayagjq["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var rbiemrpo = GetInputConstructorValue("rbiemrpo", loader);
                 if(rbiemrpo["original"].length == 0)
                 {
                   Invalid("enterprise" + " is empty");
                   return;
                 }
var tjhxublo = GetInputConstructorValue("tjhxublo", loader);
                 if(tjhxublo["original"].length == 0)
                 {
                   Invalid("index" + " is empty");
                   return;
                 }
var ozwgfoxq = GetInputConstructorValue("ozwgfoxq", loader);
                 if(ozwgfoxq["original"].length == 0)
                 {
                   Invalid("invisible" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_ReCaptcha_Bypass_No_Exten_code").html())({"ioayagjq": ioayagjq["updated"],"rbiemrpo": rbiemrpo["updated"],"tjhxublo": tjhxublo["updated"],"ozwgfoxq": ozwgfoxq["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
