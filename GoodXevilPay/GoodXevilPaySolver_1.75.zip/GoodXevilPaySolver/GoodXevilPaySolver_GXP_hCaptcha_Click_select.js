var dlhodgec = GetInputConstructorValue("dlhodgec", loader);
                 if(dlhodgec["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var dpinlhwj = GetInputConstructorValue("dpinlhwj", loader);
                 if(dpinlhwj["original"].length == 0)
                 {
                   Invalid("CaptchaSelector" + " is empty");
                   return;
                 }
var nvauxaiv = GetInputConstructorValue("nvauxaiv", loader);
                 if(nvauxaiv["original"].length == 0)
                 {
                   Invalid("InvisibleCaptcha" + " is empty");
                   return;
                 }
var nrdvmrlm = GetInputConstructorValue("nrdvmrlm", loader);
                 if(nrdvmrlm["original"].length == 0)
                 {
                   Invalid("TrySolve" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_hCaptcha_Click_code").html())({"dlhodgec": dlhodgec["updated"],"dpinlhwj": dpinlhwj["updated"],"nvauxaiv": nvauxaiv["updated"],"nrdvmrlm": nrdvmrlm["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
