var dnvnubwj = GetInputConstructorValue("dnvnubwj", loader);
                 if(dnvnubwj["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var iqonigaf = GetInputConstructorValue("iqonigaf", loader);
                 if(iqonigaf["original"].length == 0)
                 {
                   Invalid("CaptchaSelector" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_Yandex_code").html())({"dnvnubwj": dnvnubwj["updated"],"iqonigaf": iqonigaf["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
