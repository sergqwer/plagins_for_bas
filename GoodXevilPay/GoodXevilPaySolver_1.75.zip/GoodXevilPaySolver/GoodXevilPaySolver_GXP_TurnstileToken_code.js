_call_function(GoodXevilPaySolver_GXP_TurnstileToken,{ "APIKEY": (<%= zxbnbssg %>),"site_url": (<%= afbafjxy %>),"sitekey": (<%= dxmrcilz %>) })!
<%= variable %> = _result_function()
