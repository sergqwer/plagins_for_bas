_call_function(GoodXevilPaySolver_GXP_Yandex_TakeToken,{ "apikey": (<%= xvvrupog %>),"pageurl": (<%= lehqnfnp %>),"sitekey": (<%= lnxwfwje %>) })!
<%= variable %> = _result_function()
