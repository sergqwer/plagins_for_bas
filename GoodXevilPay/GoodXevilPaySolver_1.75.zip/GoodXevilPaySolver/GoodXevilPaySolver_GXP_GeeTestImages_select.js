var gxhwynel = GetInputConstructorValue("gxhwynel", loader);
                 if(gxhwynel["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var mgxxkexb = GetInputConstructorValue("mgxxkexb", loader);
                 if(mgxxkexb["original"].length == 0)
                 {
                   Invalid("images_button" + " is empty");
                   return;
                 }
var pyvnpmot = GetInputConstructorValue("pyvnpmot", loader);
                 if(pyvnpmot["original"].length == 0)
                 {
                   Invalid("reload_button" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_GeeTestImages_code").html())({"gxhwynel": gxhwynel["updated"],"mgxxkexb": mgxxkexb["updated"],"pyvnpmot": pyvnpmot["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
