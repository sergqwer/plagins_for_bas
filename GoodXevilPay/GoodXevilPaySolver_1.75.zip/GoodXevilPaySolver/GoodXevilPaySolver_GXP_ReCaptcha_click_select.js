var wbamahbt = GetInputConstructorValue("wbamahbt", loader);
                 if(wbamahbt["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var bdlijsqf = GetInputConstructorValue("bdlijsqf", loader);
                 if(bdlijsqf["original"].length == 0)
                 {
                   Invalid("CaptchaSelector" + " is empty");
                   return;
                 }
var epvhfqqg = GetInputConstructorValue("epvhfqqg", loader);
                 if(epvhfqqg["original"].length == 0)
                 {
                   Invalid("InvisibleCaptcha" + " is empty");
                   return;
                 }
var denyedpo = GetInputConstructorValue("denyedpo", loader);
                 if(denyedpo["original"].length == 0)
                 {
                   Invalid("TrySolve" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_ReCaptcha_click_code").html())({"wbamahbt": wbamahbt["updated"],"bdlijsqf": bdlijsqf["updated"],"epvhfqqg": epvhfqqg["updated"],"denyedpo": denyedpo["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
