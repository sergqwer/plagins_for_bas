var btdlvqcx = GetInputConstructorValue("btdlvqcx", loader);
                 if(btdlvqcx["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var hakrhugw = GetInputConstructorValue("hakrhugw", loader);
                 if(hakrhugw["original"].length == 0)
                 {
                   Invalid("site_url" + " is empty");
                   return;
                 }
var zinqcvtw = GetInputConstructorValue("zinqcvtw", loader);
                 if(zinqcvtw["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_ReCaptchav2TakeToken_code").html())({"btdlvqcx": btdlvqcx["updated"],"hakrhugw": hakrhugw["updated"],"zinqcvtw": zinqcvtw["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
