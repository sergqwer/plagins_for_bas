var ohtrfwcs = GetInputConstructorValue("ohtrfwcs", loader);
                 if(ohtrfwcs["original"].length == 0)
                 {
                   Invalid("hCaptcha_USE" + " is empty");
                   return;
                 }
var ppwgetsk = GetInputConstructorValue("ppwgetsk", loader);
                 if(ppwgetsk["original"].length == 0)
                 {
                   Invalid("ReCaptcha_USE" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_ForAutosolveReHCaptcha_code").html())({"ohtrfwcs": ohtrfwcs["updated"],"ppwgetsk": ppwgetsk["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
