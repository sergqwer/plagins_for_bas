var xwtnfhzc = GetInputConstructorValue("xwtnfhzc", loader);
                 if(xwtnfhzc["original"].length == 0)
                 {
                   Invalid("APIKey" + " is empty");
                   return;
                 }
var evmcapms = GetInputConstructorValue("evmcapms", loader);
                 if(evmcapms["original"].length == 0)
                 {
                   Invalid("CaptchaNumber" + " is empty");
                   return;
                 }
var renqajyv = GetInputConstructorValue("renqajyv", loader);
                 if(renqajyv["original"].length == 0)
                 {
                   Invalid("CaptchaSelector" + " is empty");
                   return;
                 }
var zjbjhnha = GetInputConstructorValue("zjbjhnha", loader);
                 if(zjbjhnha["original"].length == 0)
                 {
                   Invalid("MaxLimitTask" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_Solve_Funcaptcha_code").html())({"xwtnfhzc": xwtnfhzc["updated"],"evmcapms": evmcapms["updated"],"renqajyv": renqajyv["updated"],"zjbjhnha": zjbjhnha["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
