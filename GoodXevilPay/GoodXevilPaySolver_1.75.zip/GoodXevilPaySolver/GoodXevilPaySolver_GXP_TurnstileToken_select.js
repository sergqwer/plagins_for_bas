var zxbnbssg = GetInputConstructorValue("zxbnbssg", loader);
                 if(zxbnbssg["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var afbafjxy = GetInputConstructorValue("afbafjxy", loader);
                 if(afbafjxy["original"].length == 0)
                 {
                   Invalid("site_url" + " is empty");
                   return;
                 }
var dxmrcilz = GetInputConstructorValue("dxmrcilz", loader);
                 if(dxmrcilz["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_TurnstileToken_code").html())({"zxbnbssg": zxbnbssg["updated"],"afbafjxy": afbafjxy["updated"],"dxmrcilz": dxmrcilz["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
