var ahnqybnt = GetInputConstructorValue("ahnqybnt", loader);
                 if(ahnqybnt["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var qfshizgt = GetInputConstructorValue("qfshizgt", loader);
                 if(qfshizgt["original"].length == 0)
                 {
                   Invalid("site_url" + " is empty");
                   return;
                 }
var thebqtug = GetInputConstructorValue("thebqtug", loader);
                 if(thebqtug["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_HcaptchaTakeToken_code").html())({"ahnqybnt": ahnqybnt["updated"],"qfshizgt": qfshizgt["updated"],"thebqtug": thebqtug["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
