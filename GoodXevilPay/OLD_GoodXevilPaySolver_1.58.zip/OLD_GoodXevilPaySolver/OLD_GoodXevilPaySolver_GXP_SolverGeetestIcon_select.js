var ievfmdfq = GetInputConstructorValue("ievfmdfq", loader);
                 if(ievfmdfq["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var nhjtmzfb = GetInputConstructorValue("nhjtmzfb", loader);
                 if(nhjtmzfb["original"].length == 0)
                 {
                   Invalid("captcha_submit" + " is empty");
                   return;
                 }
var kadinynz = GetInputConstructorValue("kadinynz", loader);
                 if(kadinynz["original"].length == 0)
                 {
                   Invalid("foto_captcha" + " is empty");
                   return;
                 }
var xtdzvokt = GetInputConstructorValue("xtdzvokt", loader);
                 if(xtdzvokt["original"].length == 0)
                 {
                   Invalid("pixel_coef" + " is empty");
                   return;
                 }
var sylktvus = GetInputConstructorValue("sylktvus", loader);
                 if(sylktvus["original"].length == 0)
                 {
                   Invalid("reload_captcha" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#OLD_GoodXevilPaySolver_GXP_SolverGeetestIcon_code").html())({"ievfmdfq": ievfmdfq["updated"],"nhjtmzfb": nhjtmzfb["updated"],"kadinynz": kadinynz["updated"],"xtdzvokt": xtdzvokt["updated"],"sylktvus": sylktvus["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
