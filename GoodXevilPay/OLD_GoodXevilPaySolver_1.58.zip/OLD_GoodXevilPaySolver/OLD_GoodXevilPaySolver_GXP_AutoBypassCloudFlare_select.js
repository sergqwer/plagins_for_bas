var fiaxpndx = GetInputConstructorValue("fiaxpndx", loader);
                 if(fiaxpndx["original"].length == 0)
                 {
                   Invalid("custom_button" + " is empty");
                   return;
                 }
var sycytycf = GetInputConstructorValue("sycytycf", loader);
                 if(sycytycf["original"].length == 0)
                 {
                   Invalid("max_time" + " is empty");
                   return;
                 }
var pyikocaq = GetInputConstructorValue("pyikocaq", loader);
                 if(pyikocaq["original"].length == 0)
                 {
                   Invalid("whait_element" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#OLD_GoodXevilPaySolver_GXP_AutoBypassCloudFlare_code").html())({"fiaxpndx": fiaxpndx["updated"],"sycytycf": sycytycf["updated"],"pyikocaq": pyikocaq["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
