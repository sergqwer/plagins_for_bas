_call_function(OLD_GoodXevilPaySolver_GXP_ReCaptchav2TakeToken,{ "APIKEY": (<%= rborjooe %>),"site_url": (<%= tzhcxrwz %>),"sitekey": (<%= fchedxty %>) })!
<%= variable %> = _result_function()
