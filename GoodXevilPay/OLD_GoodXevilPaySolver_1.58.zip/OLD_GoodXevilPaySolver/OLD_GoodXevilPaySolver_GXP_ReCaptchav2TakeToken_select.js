var rborjooe = GetInputConstructorValue("rborjooe", loader);
                 if(rborjooe["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var tzhcxrwz = GetInputConstructorValue("tzhcxrwz", loader);
                 if(tzhcxrwz["original"].length == 0)
                 {
                   Invalid("site_url" + " is empty");
                   return;
                 }
var fchedxty = GetInputConstructorValue("fchedxty", loader);
                 if(fchedxty["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#OLD_GoodXevilPaySolver_GXP_ReCaptchav2TakeToken_code").html())({"rborjooe": rborjooe["updated"],"tzhcxrwz": tzhcxrwz["updated"],"fchedxty": fchedxty["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
