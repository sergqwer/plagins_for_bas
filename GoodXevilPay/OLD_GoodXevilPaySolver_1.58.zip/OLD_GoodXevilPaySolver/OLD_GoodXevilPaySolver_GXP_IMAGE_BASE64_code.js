_call_function(OLD_GoodXevilPaySolver_GXP_IMAGE_BASE64,{ "APIKEY": (<%= yzdsubob %>),"IMAGE_BASE64": (<%= hjzbxtfh %>) })!
<%= variable %> = _result_function()
