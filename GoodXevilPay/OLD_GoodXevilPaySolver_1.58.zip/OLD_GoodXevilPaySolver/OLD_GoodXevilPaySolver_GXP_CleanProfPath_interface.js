<div class="container-fluid">
</div>
<div class="tooltipinternal">
<div class="tr tooltip-paragraph-first-fold">Очищает папку prof от временных профилей, запускать при старте потока</div>
<div class="tr tooltip-paragraph-last-fold">Clears the prof folder from temporary profiles, run at thread startup</div>
</div>
<%= _.template($('#back').html())({action:"executeandadd", visible:true}) %>
