var vhdjfrtr = GetInputConstructorValue("vhdjfrtr", loader);
                 if(vhdjfrtr["original"].length == 0)
                 {
                   Invalid("arrow_id" + " is empty");
                   return;
                 }
var fkdxwspf = GetInputConstructorValue("fkdxwspf", loader);
                 if(fkdxwspf["original"].length == 0)
                 {
                   Invalid("avtoupdate" + " is empty");
                   return;
                 }
var jnpxofsu = GetInputConstructorValue("jnpxofsu", loader);
                 if(jnpxofsu["original"].length == 0)
                 {
                   Invalid("button_id" + " is empty");
                   return;
                 }
var dnbqixfo = GetInputConstructorValue("dnbqixfo", loader);
                 if(dnbqixfo["original"].length == 0)
                 {
                   Invalid("coef" + " is empty");
                   return;
                 }
var iesqpxla = GetInputConstructorValue("iesqpxla", loader);
                 if(iesqpxla["original"].length == 0)
                 {
                   Invalid("image id" + " is empty");
                   return;
                 }
var wkfbgfbf = GetInputConstructorValue("wkfbgfbf", loader);
                 if(wkfbgfbf["original"].length == 0)
                 {
                   Invalid("key" + " is empty");
                   return;
                 }
var qpcmgazj = GetInputConstructorValue("qpcmgazj", loader);
                 if(qpcmgazj["original"].length == 0)
                 {
                   Invalid("pixel_koef" + " is empty");
                   return;
                 }
var zvkmmiaj = GetInputConstructorValue("zvkmmiaj", loader);
                 if(zvkmmiaj["original"].length == 0)
                 {
                   Invalid("reload_id" + " is empty");
                   return;
                 }
var jnapxhxk = GetInputConstructorValue("jnapxhxk", loader);
                 if(jnapxhxk["original"].length == 0)
                 {
                   Invalid("speed" + " is empty");
                   return;
                 }
var otzwnqjr = GetInputConstructorValue("otzwnqjr", loader);
                 if(otzwnqjr["original"].length == 0)
                 {
                   Invalid("type_slide" + " is empty");
                   return;
                 }
var ugjcqtoe = GetInputConstructorValue("ugjcqtoe", loader);
                 if(ugjcqtoe["original"].length == 0)
                 {
                   Invalid("type_swipe" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#OLD_GoodXevilPaySolver_GXP_SliderSolver_code").html())({"vhdjfrtr": vhdjfrtr["updated"],"fkdxwspf": fkdxwspf["updated"],"jnpxofsu": jnpxofsu["updated"],"dnbqixfo": dnbqixfo["updated"],"iesqpxla": iesqpxla["updated"],"wkfbgfbf": wkfbgfbf["updated"],"qpcmgazj": qpcmgazj["updated"],"zvkmmiaj": zvkmmiaj["updated"],"jnapxhxk": jnapxhxk["updated"],"otzwnqjr": otzwnqjr["updated"],"ugjcqtoe": ugjcqtoe["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
