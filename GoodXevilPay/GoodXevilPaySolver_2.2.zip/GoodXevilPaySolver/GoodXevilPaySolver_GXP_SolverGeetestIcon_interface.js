<div class="container-fluid">
<%= _.template($('#input_constructor').html())({id:"tfdyvhku", description:"ApiKey", default_selector: "string", disable_int:true, value_string: "", help: {description: "<div>apikey с сервиса https://t.me/Xevil_check_bot</div><div>apikey from https://t.me/Xevil_check_bot</div>"} }) %>
<%= _.template($('#input_constructor').html())({id:"gptcgrdm", description:"Model Type", variants: [0, 1], default_selector: "int", disable_string:true, value_number: 0, min_number:-999999, max_number:999999, help: {description: "<div>Тип ИИ для решения капчи</div><div>0 - Точность 85% - поддерживаются только 2 вида</div><div>1 - Точность 45% - совсем другой подход к решению, поддержка всех видов Geetest Icon, на разных видах капчи, разная точность</div>"} }) %>
<%= _.template($('#input_constructor').html())({id:"pagzduvs", description:"Reverse the result", variants: [0, 1], default_selector: "int", disable_string:true, value_number: 0, min_number:-999999, max_number:999999, help: {description: "<div>0 - off</div><div>1 - on</div>"} }) %>
<%= _.template($('#input_constructor').html())({id:"rcfmpiix", description:"Captcha Box", default_selector: "string", disable_int:true, value_string: " >XPATH> //div[@class='geetest_fullpage_click_box']", help: {description: "<div>Идентификатор фото капчи</div><div></div><div>Captcha photo identifier</div>"} }) %>
<%= _.template($('#input_constructor').html())({id:"xhydiykf", description:"Submit Button", default_selector: "string", disable_int:true, value_string: ">XPATH> //div[@class='geetest_fullpage_click_box']//a[@class='geetest_commit']", help: {description: "<div>Идентификатор кнопки, подтвердить решение</div><div></div><div>Button ID, confirm decision</div>"} }) %>
<%= _.template($('#input_constructor').html())({id:"ujmqnmoh", description:"Reload Button", default_selector: "string", disable_int:true, value_string: ">XPATH> //div[@class='geetest_fullpage_click_box']//a[@class='geetest_refresh']", help: {description: "<div>Идентификатор кнопки, обновление капчи</div><div></div><div>Button ID, captcha update</div>"} }) %>
<%= _.template($('#input_constructor').html())({id:"mpziqazk", description:"Fix by pixels", default_selector: "int", disable_string:true, value_number: 0, min_number:-999999, max_number:999999, help: {description: "<div>Число пикселей для коректировки результата</div><div></div><div>Number of pixels to adjust the result</div>"} }) %>
</div>
<div class="tooltipinternal">
<div class="tr tooltip-paragraph-first-fold">Автоматически решает Geetest Icon на странице</div>
<div class="tr tooltip-paragraph-last-fold">Automatically resolves the Geetest Icon on the page</div>
</div>
<%= _.template($('#back').html())({action:"executeandadd", visible:true}) %>
