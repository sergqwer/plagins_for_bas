_call_function(GoodXevilPaySolver_GXP_Namars,{ "apikey": (<%= liituior %>) })!
<%= variable %> = _result_function()
