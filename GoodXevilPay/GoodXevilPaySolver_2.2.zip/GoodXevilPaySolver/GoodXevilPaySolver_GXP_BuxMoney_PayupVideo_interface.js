<div class="container-fluid">
<%= _.template($('#input_constructor').html())({id:"vjpaihwh", description:"ApiKey", default_selector: "string", disable_int:true, value_string: "", help: {description: "<div>apikey с сервиса https://t.me/Xevil_check_bot</div><div>apikey from https://t.me/Xevil_check_bot</div>"} }) %>
<%= _.template($('#input_constructor').html())({id:"lrludjev", description:"timer", default_selector: "int", disable_expression:true, disable_string:true, value_number: 4, min_number:-999999, max_number:999999, help: {description: "<div>Сколько секунд ждать появление капчи</div><div>How many seconds to wait for captcha to appear</div>"} }) %>
</div>
<div class="tooltipinternal">
<div class="tr tooltip-paragraph-first-fold">Данная функция решает капчу с сайтов BuxMoney/PayupVideo через сервис https://t.me/Xevil_check_bot</div>
<div class="tr tooltip-paragraph-last-fold">This function solves captcha from BuxMoney/PayupVideo sites via https://t.me/Xevil_check_bot service.</div>
</div>
<%= _.template($('#back').html())({action:"executeandadd", visible:true}) %>
