var tkgnljtj = GetInputConstructorValue("tkgnljtj", loader);
                 if(tkgnljtj["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var xbvgvkyi = GetInputConstructorValue("xbvgvkyi", loader);
                 if(xbvgvkyi["original"].length == 0)
                 {
                   Invalid("CaptchaSelector" + " is empty");
                   return;
                 }
var mmqunkyp = GetInputConstructorValue("mmqunkyp", loader);
                 if(mmqunkyp["original"].length == 0)
                 {
                   Invalid("InvisibleCaptcha" + " is empty");
                   return;
                 }
var zicdjxjj = GetInputConstructorValue("zicdjxjj", loader);
                 if(zicdjxjj["original"].length == 0)
                 {
                   Invalid("TrySolve" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_ReCaptcha_click_code").html())({"tkgnljtj": tkgnljtj["updated"],"xbvgvkyi": xbvgvkyi["updated"],"mmqunkyp": mmqunkyp["updated"],"zicdjxjj": zicdjxjj["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
