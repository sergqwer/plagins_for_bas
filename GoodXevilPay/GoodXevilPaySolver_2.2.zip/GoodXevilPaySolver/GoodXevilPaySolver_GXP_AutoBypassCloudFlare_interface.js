<div class="container-fluid">
<%= _.template($('#input_constructor').html())({id:"svdjgvzz", description:"Selector", default_selector: "string", disable_int:true, value_string: "false", help: {description: "<div>На некоторых сайтах собственный селектор CloudFlare, впишите его здесь</div><div>false - игнорировать этот параметр</div><div>Some sites have their own CloudFlare selector, type it here</div><div>false - ignore this parameter</div>"} }) %>
<%= _.template($('#input_constructor').html())({id:"gryczvea", description:"Time Whait", default_selector: "int", disable_string:true, value_number: 45, min_number:-999999, max_number:999999, help: {description: "<div>Максимальное время ожидания в секундах</div><div>Maximum waiting time in seconds</div>"} }) %>
<%= _.template($('#input_constructor').html())({id:"cshhqtqr", description:"Element for skip", default_selector: "string", disable_int:true, value_string: "false", help: {description: "<div>Елемент на странице, после появления которого скрипт прервет ожидания</div><div>false - игнорировать этот параметр</div><div>Например вам надо загрузить страницу входа на сайт, но там клауд, указываете здесь идентификатор формы ввода логина</div><div>The element on the page, after the appearance of which the script will interrupt the expectations</div><div>false - ignore this parameter</div><div>For example, you need to load the login page, but there is a clud, specify here the ID of the login form</div>"} }) %>
</div>
<div class="tooltipinternal">
<div class="tr tooltip-paragraph-first-fold">Автоматически проходит CloudFlare на любом сайте в браузере, просто небольшой удобный скрипт</div>
<div class="tr tooltip-paragraph-last-fold">Automatically passes CloudFlare on any site in the browser, just a little handy script</div>
</div>
<%= _.template($('#back').html())({action:"executeandadd", visible:true}) %>
