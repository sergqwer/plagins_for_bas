<div class="container-fluid">
<%= _.template($('#input_constructor').html())({id:"csoiwgab", description:"Solve Service", default_selector: "string", variants: ["SCTG", "Multibot"], disable_expression:true, disable_int:true, value_string: "SCTG", help: {description: "<div>Выберите нужный вам сервис для решения капчи</div><div>Choose the service you need to solve captcha</div>"} }) %>
<%= _.template($('#input_constructor').html())({id:"zrmropmn", description:"ApiKey", default_selector: "string", disable_int:true, value_string: "", help: {description: "<div>apikey с сервиса https://t.me/Xevil_check_bot или https://multibot.in/</div><div>apikey from https://t.me/Xevil_check_bot or https://multibot.in/</div>"} }) %>
<%= _.template($('#input_constructor').html())({id:"mwdlyjmm", description:"Selector", default_selector: "string", disable_int:true, value_string: ">CSS> iframe[src*='checkbox']>FRAME> >CSS> #checkbox", help: {description: "<div>Селектор hCaptcha</div><div>hCaptcha selector</div>"} }) %>
<%= _.template($('#input_constructor').html())({id:"avmrmhvb", description:"Attempts", default_selector: "int", disable_string:true, value_number: 20, min_number:-999999, max_number:999999, help: {description: "<div>Количество попыток решения капчи</div><div>Number of attempts to solve captcha</div>"} }) %>
</div>
<div class="tooltipinternal">
<div class="tr tooltip-paragraph-first-fold">Решает кликами hCaptcha через сервис https://t.me/Xevil_check_bot или https://multibot.in/, оплачивается каждое изображение. Для работы требуется функция "hCaptcha CacheAllow"</div>
<div class="tr tooltip-paragraph-last-fold">Resolves by hCaptcha clicks through the service https://t.me/Xevil_check_bot or https://multibot.in/, paid per image. The function “hCaptcha CacheAllow” is required for operation</div>
</div>
<%= _.template($('#back').html())({action:"executeandadd", visible:true}) %>
