_call_function(GoodXevilPaySolver_GXP_AutoBypassCloudFlare,{ "custom_button": (<%= svdjgvzz %>),"max_time": (<%= gryczvea %>),"whait_element": (<%= cshhqtqr %>) })!
