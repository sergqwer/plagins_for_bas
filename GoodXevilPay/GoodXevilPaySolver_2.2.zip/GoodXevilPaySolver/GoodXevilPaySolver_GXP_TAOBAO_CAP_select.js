var bzbrhlyh = GetInputConstructorValue("bzbrhlyh", loader);
                 if(bzbrhlyh["original"].length == 0)
                 {
                   Invalid("FRAME_PATH" + " is empty");
                   return;
                 }
var vbimkmvl = GetInputConstructorValue("vbimkmvl", loader);
                 if(vbimkmvl["original"].length == 0)
                 {
                   Invalid("SCTG_APIKEY" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_TAOBAO_CAP_code").html())({"bzbrhlyh": bzbrhlyh["updated"],"vbimkmvl": vbimkmvl["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
