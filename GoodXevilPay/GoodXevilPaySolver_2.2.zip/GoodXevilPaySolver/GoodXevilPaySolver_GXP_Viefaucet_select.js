var ponzuvfj = GetInputConstructorValue("ponzuvfj", loader);
                 if(ponzuvfj["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var rqwveeza = GetInputConstructorValue("rqwveeza", loader);
                 if(rqwveeza["original"].length == 0)
                 {
                   Invalid("Service_Solver" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_Viefaucet_code").html())({"ponzuvfj": ponzuvfj["updated"],"rqwveeza": rqwveeza["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
