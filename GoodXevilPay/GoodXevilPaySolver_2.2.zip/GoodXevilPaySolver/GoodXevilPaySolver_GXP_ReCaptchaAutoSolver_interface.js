<div class="container-fluid">
<%= _.template($('#input_constructor').html())({id:"lzfgcgqm", description:"Solve Service", default_selector: "string", variants: ["SCTG", "Multibot"], disable_expression:true, disable_int:true, value_string: "SCTG", help: {description: "<div>Выберите нужный вам сервис для решения капчи</div><div>Choose the service you need to solve captcha</div>"} }) %>
<%= _.template($('#input_constructor').html())({id:"ptmvhwwj", description:"ApiKey", default_selector: "string", disable_int:true, value_string: "", help: {description: "<div>apikey с сервиса https://t.me/Xevil_check_bot или https://multibot.in/</div><div>apikey from https://t.me/Xevil_check_bot or https://multibot.in/</div>"} }) %>
<%= _.template($('#variable_constructor').html())({id:"Save", description:"Result", default_variable: "RECAPTCHA_TOKEN", help: {description: ""}}) %>
</div>
<div class="tooltipinternal">
<div class="tr tooltip-paragraph-first-fold">Автоматически решает ReCaptcha на странице, для работы требуется функция "ExtForReHCaptcha"</div>
<div class="tr tooltip-paragraph-last-fold">Automatically solves ReCaptcha on the page, "ExtForReHCaptcha" is required to work</div>
</div>
<%= _.template($('#back').html())({action:"executeandadd", visible:true}) %>
