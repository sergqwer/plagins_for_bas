var pmvdseyg = GetInputConstructorValue("pmvdseyg", loader);
                 if(pmvdseyg["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var ofvlppwy = GetInputConstructorValue("ofvlppwy", loader);
                 if(ofvlppwy["original"].length == 0)
                 {
                   Invalid("enterprise" + " is empty");
                   return;
                 }
var inxvpdzb = GetInputConstructorValue("inxvpdzb", loader);
                 if(inxvpdzb["original"].length == 0)
                 {
                   Invalid("index" + " is empty");
                   return;
                 }
var odhznjmh = GetInputConstructorValue("odhznjmh", loader);
                 if(odhznjmh["original"].length == 0)
                 {
                   Invalid("invisible" + " is empty");
                   return;
                 }
var gltwwyuw = GetInputConstructorValue("gltwwyuw", loader);
                 if(gltwwyuw["original"].length == 0)
                 {
                   Invalid("recaptchaframe" + " is empty");
                   return;
                 }
var xknmvqbc = GetInputConstructorValue("xknmvqbc", loader);
                 if(xknmvqbc["original"].length == 0)
                 {
                   Invalid("Service_Solver" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_ReCaptcha_Bypass_No_Exten_code").html())({"pmvdseyg": pmvdseyg["updated"],"ofvlppwy": ofvlppwy["updated"],"inxvpdzb": inxvpdzb["updated"],"odhznjmh": odhznjmh["updated"],"gltwwyuw": gltwwyuw["updated"],"xknmvqbc": xknmvqbc["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
