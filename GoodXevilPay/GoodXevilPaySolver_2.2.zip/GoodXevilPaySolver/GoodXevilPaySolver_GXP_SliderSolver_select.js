var fjhnjpbg = GetInputConstructorValue("fjhnjpbg", loader);
                 if(fjhnjpbg["original"].length == 0)
                 {
                   Invalid("arrow_id" + " is empty");
                   return;
                 }
var qbwcdnlk = GetInputConstructorValue("qbwcdnlk", loader);
                 if(qbwcdnlk["original"].length == 0)
                 {
                   Invalid("Attempts" + " is empty");
                   return;
                 }
var qmdcozec = GetInputConstructorValue("qmdcozec", loader);
                 if(qmdcozec["original"].length == 0)
                 {
                   Invalid("avtoupdate" + " is empty");
                   return;
                 }
var zmhuscly = GetInputConstructorValue("zmhuscly", loader);
                 if(zmhuscly["original"].length == 0)
                 {
                   Invalid("button_id" + " is empty");
                   return;
                 }
var vbnefiin = GetInputConstructorValue("vbnefiin", loader);
                 if(vbnefiin["original"].length == 0)
                 {
                   Invalid("coef" + " is empty");
                   return;
                 }
var teqpprzd = GetInputConstructorValue("teqpprzd", loader);
                 if(teqpprzd["original"].length == 0)
                 {
                   Invalid("image id" + " is empty");
                   return;
                 }
var fjgenyxa = GetInputConstructorValue("fjgenyxa", loader);
                 if(fjgenyxa["original"].length == 0)
                 {
                   Invalid("key" + " is empty");
                   return;
                 }
var ysjfuoca = GetInputConstructorValue("ysjfuoca", loader);
                 if(ysjfuoca["original"].length == 0)
                 {
                   Invalid("pixel_koef" + " is empty");
                   return;
                 }
var rrwwsrul = GetInputConstructorValue("rrwwsrul", loader);
                 if(rrwwsrul["original"].length == 0)
                 {
                   Invalid("reload_id" + " is empty");
                   return;
                 }
var yomgcidi = GetInputConstructorValue("yomgcidi", loader);
                 if(yomgcidi["original"].length == 0)
                 {
                   Invalid("slider_type" + " is empty");
                   return;
                 }
var cfchcrwh = GetInputConstructorValue("cfchcrwh", loader);
                 if(cfchcrwh["original"].length == 0)
                 {
                   Invalid("speed" + " is empty");
                   return;
                 }
var czcxfyic = GetInputConstructorValue("czcxfyic", loader);
                 if(czcxfyic["original"].length == 0)
                 {
                   Invalid("type_slide" + " is empty");
                   return;
                 }
var fwuvvqpp = GetInputConstructorValue("fwuvvqpp", loader);
                 if(fwuvvqpp["original"].length == 0)
                 {
                   Invalid("type_swipe" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SliderSolver_code").html())({"fjhnjpbg": fjhnjpbg["updated"],"qbwcdnlk": qbwcdnlk["updated"],"qmdcozec": qmdcozec["updated"],"zmhuscly": zmhuscly["updated"],"vbnefiin": vbnefiin["updated"],"teqpprzd": teqpprzd["updated"],"fjgenyxa": fjgenyxa["updated"],"ysjfuoca": ysjfuoca["updated"],"rrwwsrul": rrwwsrul["updated"],"yomgcidi": yomgcidi["updated"],"cfchcrwh": cfchcrwh["updated"],"czcxfyic": czcxfyic["updated"],"fwuvvqpp": fwuvvqpp["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
