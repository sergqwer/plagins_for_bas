var svdjgvzz = GetInputConstructorValue("svdjgvzz", loader);
                 if(svdjgvzz["original"].length == 0)
                 {
                   Invalid("custom_button" + " is empty");
                   return;
                 }
var gryczvea = GetInputConstructorValue("gryczvea", loader);
                 if(gryczvea["original"].length == 0)
                 {
                   Invalid("max_time" + " is empty");
                   return;
                 }
var cshhqtqr = GetInputConstructorValue("cshhqtqr", loader);
                 if(cshhqtqr["original"].length == 0)
                 {
                   Invalid("whait_element" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_AutoBypassCloudFlare_code").html())({"svdjgvzz": svdjgvzz["updated"],"gryczvea": gryczvea["updated"],"cshhqtqr": cshhqtqr["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
