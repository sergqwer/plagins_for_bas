var yyhbrnyn = GetInputConstructorValue("yyhbrnyn", loader);
                 if(yyhbrnyn["original"].length == 0)
                 {
                   Invalid("arrow_id" + " is empty");
                   return;
                 }
var bcpswlkz = GetInputConstructorValue("bcpswlkz", loader);
                 if(bcpswlkz["original"].length == 0)
                 {
                   Invalid("avtoupdate" + " is empty");
                   return;
                 }
var fcrmghqw = GetInputConstructorValue("fcrmghqw", loader);
                 if(fcrmghqw["original"].length == 0)
                 {
                   Invalid("button_id" + " is empty");
                   return;
                 }
var wwoiwmpy = GetInputConstructorValue("wwoiwmpy", loader);
                 if(wwoiwmpy["original"].length == 0)
                 {
                   Invalid("coef" + " is empty");
                   return;
                 }
var rgtfxgwr = GetInputConstructorValue("rgtfxgwr", loader);
                 if(rgtfxgwr["original"].length == 0)
                 {
                   Invalid("image id" + " is empty");
                   return;
                 }
var cpaasacy = GetInputConstructorValue("cpaasacy", loader);
                 if(cpaasacy["original"].length == 0)
                 {
                   Invalid("key" + " is empty");
                   return;
                 }
var ootlfcaa = GetInputConstructorValue("ootlfcaa", loader);
                 if(ootlfcaa["original"].length == 0)
                 {
                   Invalid("pixel_koef" + " is empty");
                   return;
                 }
var kxxltjml = GetInputConstructorValue("kxxltjml", loader);
                 if(kxxltjml["original"].length == 0)
                 {
                   Invalid("reload_id" + " is empty");
                   return;
                 }
var meetpqmn = GetInputConstructorValue("meetpqmn", loader);
                 if(meetpqmn["original"].length == 0)
                 {
                   Invalid("speed" + " is empty");
                   return;
                 }
var tedcdxmj = GetInputConstructorValue("tedcdxmj", loader);
                 if(tedcdxmj["original"].length == 0)
                 {
                   Invalid("type_slide" + " is empty");
                   return;
                 }
var fztvpxpf = GetInputConstructorValue("fztvpxpf", loader);
                 if(fztvpxpf["original"].length == 0)
                 {
                   Invalid("type_swipe" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SliderSolver_code").html())({"yyhbrnyn": yyhbrnyn["updated"],"bcpswlkz": bcpswlkz["updated"],"fcrmghqw": fcrmghqw["updated"],"wwoiwmpy": wwoiwmpy["updated"],"rgtfxgwr": rgtfxgwr["updated"],"cpaasacy": cpaasacy["updated"],"ootlfcaa": ootlfcaa["updated"],"kxxltjml": kxxltjml["updated"],"meetpqmn": meetpqmn["updated"],"tedcdxmj": tedcdxmj["updated"],"fztvpxpf": fztvpxpf["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
