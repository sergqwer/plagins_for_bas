_call_function(GoodXevilPaySolver_GXP_HcaptchaTakeToken,{ "APIKEY": (<%= yvabhlis %>),"site_url": (<%= vvtpipxb %>),"sitekey": (<%= rwgiihkt %>) })!
<%= variable %> = _result_function()
