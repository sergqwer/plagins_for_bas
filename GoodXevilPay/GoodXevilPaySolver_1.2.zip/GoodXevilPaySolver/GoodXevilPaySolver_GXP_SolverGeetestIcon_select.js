var srtmxvah = GetInputConstructorValue("srtmxvah", loader);
                 if(srtmxvah["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var hqaglrsh = GetInputConstructorValue("hqaglrsh", loader);
                 if(hqaglrsh["original"].length == 0)
                 {
                   Invalid("button_capthca" + " is empty");
                   return;
                 }
var lhaskomc = GetInputConstructorValue("lhaskomc", loader);
                 if(lhaskomc["original"].length == 0)
                 {
                   Invalid("captcha_submit" + " is empty");
                   return;
                 }
var lubdyixx = GetInputConstructorValue("lubdyixx", loader);
                 if(lubdyixx["original"].length == 0)
                 {
                   Invalid("foto_captcha" + " is empty");
                   return;
                 }
var zmvjftoi = GetInputConstructorValue("zmvjftoi", loader);
                 if(zmvjftoi["original"].length == 0)
                 {
                   Invalid("reload_captcha" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SolverGeetestIcon_code").html())({"srtmxvah": srtmxvah["updated"],"hqaglrsh": hqaglrsh["updated"],"lhaskomc": lhaskomc["updated"],"lubdyixx": lubdyixx["updated"],"zmvjftoi": zmvjftoi["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
