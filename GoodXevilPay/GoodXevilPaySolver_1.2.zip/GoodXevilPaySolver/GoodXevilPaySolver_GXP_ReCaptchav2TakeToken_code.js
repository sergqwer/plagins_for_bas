_call_function(GoodXevilPaySolver_GXP_ReCaptchav2TakeToken,{ "APIKEY": (<%= dskjtkra %>),"site_url": (<%= udovprgl %>),"sitekey": (<%= cpboqabh %>) })!
<%= variable %> = _result_function()
