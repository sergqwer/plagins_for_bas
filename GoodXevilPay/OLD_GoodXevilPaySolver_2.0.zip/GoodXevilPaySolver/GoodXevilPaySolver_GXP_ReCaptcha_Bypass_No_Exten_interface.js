<div class="container-fluid">
<%= _.template($('#input_constructor').html())({id:"xknmvqbc", description:"Solve Service", default_selector: "string", variants: ["SCTG", "Multibot"], disable_expression:true, disable_int:true, value_string: "SCTG", help: {description: "<div>Выберите нужный вам сервис для решения капчи</div><div>Choose the service you need to solve captcha</div>"} }) %>
<%= _.template($('#input_constructor').html())({id:"pmvdseyg", description:"ApiKey", default_selector: "string", disable_int:true, value_string: "", help: {description: "<div>apikey с сервиса https://t.me/Xevil_check_bot или https://multibot.in/</div><div>apikey from https://t.me/Xevil_check_bot or https://multibot.in/</div>"} }) %>
<%= _.template($('#input_constructor').html())({id:"gltwwyuw", description:"recaptchaframe", default_selector: "string", disable_int:true, value_string: "false", help: {description: "<div>На некоторых сайтах ReCaptcha находится по фрейме, здесь надо вписать путь к фрейму, а не к самой капче</div><div>On some sites ReCaptcha is located on the frame, here you need to enter the path to the frame, not to the captcha itself</div>"} }) %>
<%= _.template($('#input_constructor').html())({id:"inxvpdzb", description:"index", default_selector: "int", disable_string:true, value_number: 0, min_number:-999999, max_number:999999, help: {description: "<div>Индекс капчи на странице</div><div>Captcha index on the page</div>"} }) %>
<%= _.template($('#input_constructor').html())({id:"odhznjmh", description:"invisible", default_selector: "int", variants: [0, 1], disable_string:true, value_number: 0, min_number:-999999, max_number:999999, help: {description: "<div>0 - not invisible</div><div>1 - invisible</div>"} }) %>
<%= _.template($('#input_constructor').html())({id:"ofvlppwy", description:"enterprise", default_selector: "int", variants: [0, 1], disable_string:true, value_number: 0, min_number:-999999, max_number:999999, help: {description: "<div>0 - not enterprise</div><div>1 - enterprise</div>"} }) %>
<%= _.template($('#variable_constructor').html())({id:"Save", description:"Result", default_variable: "RECAPTCHA_TOKEN", help: {description: ""}}) %>
</div>
<div class="tooltipinternal">
<div class="tr tooltip-paragraph-first-fold">Автоматически решает ReCaptcha на странице без использования расширения, и сторонних js в коде страницы</div>
<div class="tr tooltip-paragraph-last-fold">Automatically solves ReCaptcha on the page without using extension, and third-party js in the page code</div>
</div>
<%= _.template($('#back').html())({action:"executeandadd", visible:true}) %>
