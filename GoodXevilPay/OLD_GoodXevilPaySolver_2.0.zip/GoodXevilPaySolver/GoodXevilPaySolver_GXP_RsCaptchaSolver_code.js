_call_function(GoodXevilPaySolver_GXP_RsCaptchaSolver,{ "apikey": (<%= sshhuajt %>),"Service_Solver": (<%= fvzmigtv %>) })!
