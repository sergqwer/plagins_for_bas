<div class="container-fluid">
<%= _.template($('#input_constructor').html())({id:"pvtlnchd", description:"Solve Service", default_selector: "string", variants: ["SCTG", "Multibot"], disable_expression:true, disable_int:true, value_string: "SCTG", help: {description: "<div>Выберите нужный вам сервис для решения капчи</div><div>Choose the service you need to solve captcha</div>"} }) %>
<%= _.template($('#input_constructor').html())({id:"qjmbbvbt", description:"ApiKey", default_selector: "string", disable_int:true, value_string: "", help: {description: "<div>apikey с сервиса https://t.me/Xevil_check_bot или https://multibot.in/</div><div>apikey from https://t.me/Xevil_check_bot or https://multibot.in/</div>"} }) %>
<%= _.template($('#input_constructor').html())({id:"ylnivjsz", description:"Image BASE64", default_selector: "string", disable_int:true, value_string: "", help: {description: "<div>Изображение в формате base64</div><div>Image in base64 format</div>"} }) %>
<%= _.template($('#variable_constructor').html())({id:"Save", description:"Result", default_variable: "RESULT", help: {description: "<div>Ответ от сервиса решения капчи</div><div>Response from the captcha solution service</div>"}}) %>
</div>
<div class="tooltipinternal">
<div class="tr tooltip-paragraph-first-fold">Решает изображения в формате base64</div>
<div class="tr tooltip-paragraph-fold">Resolves images in base64 format</div>
<div class="tr tooltip-paragraph-fold">When solving via SCTG, there is an option to specify a model:</div>
<div class="tr tooltip-paragraph-last-fold">https://sctg.readme.io/reference/choosing-a-model-to-solve</div>
</div>
<%= _.template($('#back').html())({action:"executeandadd", visible:true}) %>
