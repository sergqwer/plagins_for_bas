<div class="container-fluid">
<%= _.template($('#input_constructor').html())({id:"xnrkaier", description:"custom_button", default_selector: "string", disable_int:true, value_string: "false", help: {description: "На некоторых сайтах собственный ид кнопри при прохождении клауда, можете вписать этот ид здесь\nfalse - игнорировать этот параметр\n\nSome sites have their own knopri id when passing the claude, you can enter this id here\nfalse - ignore this parameter"} }) %>
<%= _.template($('#input_constructor').html())({id:"apbltrlf", description:"max_time", default_selector: "int", disable_string:true, value_number: 250, min_number:-999999, max_number:999999, help: {description: "Максимальное время ожидания в секундах\n\nMaximum waiting time in seconds"} }) %>
<%= _.template($('#input_constructor').html())({id:"bsufbkyi", description:"whait_element", default_selector: "string", disable_int:true, value_string: "false", help: {description: "Елемент на странице, после появления которого скрипт прервет ожидания\nfalse - игнорировать этот параметр\nНапример вам надо загрузить страницу входа на сайт, но там клауд, указываете здесь идентификатор формы ввода логина\n\n\nThe element on the page, after the appearance of which the script will interrupt the expectations\nfalse - ignore this parameter\nFor example, you need to load the login page, but there is a clud, specify here the ID of the login form."} }) %>
</div>
<div class="tooltipinternal">
<div class="tr tooltip-paragraph-first-fold">Автоматически проходит CloudFlare на любом сайте в браузере, просто небольшой удобный скрипт</div>
<div class="tr tooltip-paragraph-last-fold">Automatically passes CloudFlare on any site in the browser, just a little handy script</div>
</div>
<%= _.template($('#back').html())({action:"executeandadd", visible:true}) %>
