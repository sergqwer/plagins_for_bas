_call_function(GoodXevilPaySolver_GXP_AutoBypassCloudFlare,{ "custom_button": (<%= xnrkaier %>),"max_time": (<%= apbltrlf %>),"whait_element": (<%= bsufbkyi %>) })!
