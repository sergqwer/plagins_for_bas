var shsarmuj = GetInputConstructorValue("shsarmuj", loader);
                 if(shsarmuj["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var zimpbzfq = GetInputConstructorValue("zimpbzfq", loader);
                 if(zimpbzfq["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var kkjetdbv = GetInputConstructorValue("kkjetdbv", loader);
                 if(kkjetdbv["original"].length == 0)
                 {
                   Invalid("siteurl" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_BasiliskCaptcha_code").html())({"shsarmuj": shsarmuj["updated"],"zimpbzfq": zimpbzfq["updated"],"kkjetdbv": kkjetdbv["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
