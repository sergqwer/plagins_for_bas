var hspjufgu = GetInputConstructorValue("hspjufgu", loader);
                 if(hspjufgu["original"].length == 0)
                 {
                   Invalid("arrow_id" + " is empty");
                   return;
                 }
var ffzvxtxh = GetInputConstructorValue("ffzvxtxh", loader);
                 if(ffzvxtxh["original"].length == 0)
                 {
                   Invalid("avtoupdate" + " is empty");
                   return;
                 }
var iyfgkbxc = GetInputConstructorValue("iyfgkbxc", loader);
                 if(iyfgkbxc["original"].length == 0)
                 {
                   Invalid("button_id" + " is empty");
                   return;
                 }
var svcweapu = GetInputConstructorValue("svcweapu", loader);
                 if(svcweapu["original"].length == 0)
                 {
                   Invalid("coef" + " is empty");
                   return;
                 }
var alnugsii = GetInputConstructorValue("alnugsii", loader);
                 if(alnugsii["original"].length == 0)
                 {
                   Invalid("image id" + " is empty");
                   return;
                 }
var eexxglrz = GetInputConstructorValue("eexxglrz", loader);
                 if(eexxglrz["original"].length == 0)
                 {
                   Invalid("key" + " is empty");
                   return;
                 }
var mndddkor = GetInputConstructorValue("mndddkor", loader);
                 if(mndddkor["original"].length == 0)
                 {
                   Invalid("pixel_koef" + " is empty");
                   return;
                 }
var dzkaoikm = GetInputConstructorValue("dzkaoikm", loader);
                 if(dzkaoikm["original"].length == 0)
                 {
                   Invalid("reload_id" + " is empty");
                   return;
                 }
var ikqegdax = GetInputConstructorValue("ikqegdax", loader);
                 if(ikqegdax["original"].length == 0)
                 {
                   Invalid("speed" + " is empty");
                   return;
                 }
var pabvmzsm = GetInputConstructorValue("pabvmzsm", loader);
                 if(pabvmzsm["original"].length == 0)
                 {
                   Invalid("type_slide" + " is empty");
                   return;
                 }
var hjzevxkp = GetInputConstructorValue("hjzevxkp", loader);
                 if(hjzevxkp["original"].length == 0)
                 {
                   Invalid("type_swipe" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SliderSolver_code").html())({"hspjufgu": hspjufgu["updated"],"ffzvxtxh": ffzvxtxh["updated"],"iyfgkbxc": iyfgkbxc["updated"],"svcweapu": svcweapu["updated"],"alnugsii": alnugsii["updated"],"eexxglrz": eexxglrz["updated"],"mndddkor": mndddkor["updated"],"dzkaoikm": dzkaoikm["updated"],"ikqegdax": ikqegdax["updated"],"pabvmzsm": pabvmzsm["updated"],"hjzevxkp": hjzevxkp["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
