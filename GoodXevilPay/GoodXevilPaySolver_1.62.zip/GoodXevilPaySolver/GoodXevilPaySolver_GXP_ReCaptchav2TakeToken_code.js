_call_function(GoodXevilPaySolver_GXP_ReCaptchav2TakeToken,{ "APIKEY": (<%= buhzbize %>),"site_url": (<%= cevnrhpb %>),"sitekey": (<%= ujeawwhv %>) })!
<%= variable %> = _result_function()
