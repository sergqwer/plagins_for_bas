var xnrkaier = GetInputConstructorValue("xnrkaier", loader);
                 if(xnrkaier["original"].length == 0)
                 {
                   Invalid("custom_button" + " is empty");
                   return;
                 }
var apbltrlf = GetInputConstructorValue("apbltrlf", loader);
                 if(apbltrlf["original"].length == 0)
                 {
                   Invalid("max_time" + " is empty");
                   return;
                 }
var bsufbkyi = GetInputConstructorValue("bsufbkyi", loader);
                 if(bsufbkyi["original"].length == 0)
                 {
                   Invalid("whait_element" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_AutoBypassCloudFlare_code").html())({"xnrkaier": xnrkaier["updated"],"apbltrlf": apbltrlf["updated"],"bsufbkyi": bsufbkyi["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
