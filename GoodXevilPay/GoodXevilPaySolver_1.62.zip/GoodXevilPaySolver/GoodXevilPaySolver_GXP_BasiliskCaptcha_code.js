_call_function(GoodXevilPaySolver_GXP_BasiliskCaptcha,{ "apikey": (<%= shsarmuj %>),"sitekey": (<%= zimpbzfq %>),"siteurl": (<%= kkjetdbv %>) })!
