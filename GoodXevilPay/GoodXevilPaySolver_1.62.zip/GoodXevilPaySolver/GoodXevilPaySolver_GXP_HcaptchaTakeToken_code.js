_call_function(GoodXevilPaySolver_GXP_HcaptchaTakeToken,{ "APIKEY": (<%= svlvvcgt %>),"site_url": (<%= hadbowfv %>),"sitekey": (<%= jwzvjvzc %>) })!
<%= variable %> = _result_function()
