var buhzbize = GetInputConstructorValue("buhzbize", loader);
                 if(buhzbize["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var cevnrhpb = GetInputConstructorValue("cevnrhpb", loader);
                 if(cevnrhpb["original"].length == 0)
                 {
                   Invalid("site_url" + " is empty");
                   return;
                 }
var ujeawwhv = GetInputConstructorValue("ujeawwhv", loader);
                 if(ujeawwhv["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_ReCaptchav2TakeToken_code").html())({"buhzbize": buhzbize["updated"],"cevnrhpb": cevnrhpb["updated"],"ujeawwhv": ujeawwhv["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
