_call_function(GoodXevilPaySolver_GXP_IMAGE_BASE64,{ "APIKEY": (<%= qdotpefx %>),"IMAGE_BASE64": (<%= nffwacwx %>) })!
<%= variable %> = _result_function()
