var iksaxuhh = GetInputConstructorValue("iksaxuhh", loader);
                 if(iksaxuhh["original"].length == 0)
                 {
                   Invalid("arrow_id" + " is empty");
                   return;
                 }
var szixmevt = GetInputConstructorValue("szixmevt", loader);
                 if(szixmevt["original"].length == 0)
                 {
                   Invalid("avtoupdate" + " is empty");
                   return;
                 }
var ekmkcnig = GetInputConstructorValue("ekmkcnig", loader);
                 if(ekmkcnig["original"].length == 0)
                 {
                   Invalid("button_id" + " is empty");
                   return;
                 }
var qqaqxiud = GetInputConstructorValue("qqaqxiud", loader);
                 if(qqaqxiud["original"].length == 0)
                 {
                   Invalid("coef" + " is empty");
                   return;
                 }
var qixenmrz = GetInputConstructorValue("qixenmrz", loader);
                 if(qixenmrz["original"].length == 0)
                 {
                   Invalid("image id" + " is empty");
                   return;
                 }
var rzaxyskt = GetInputConstructorValue("rzaxyskt", loader);
                 if(rzaxyskt["original"].length == 0)
                 {
                   Invalid("key" + " is empty");
                   return;
                 }
var ylsrhvvy = GetInputConstructorValue("ylsrhvvy", loader);
                 if(ylsrhvvy["original"].length == 0)
                 {
                   Invalid("pixel_koef" + " is empty");
                   return;
                 }
var siqxnwnk = GetInputConstructorValue("siqxnwnk", loader);
                 if(siqxnwnk["original"].length == 0)
                 {
                   Invalid("reload_id" + " is empty");
                   return;
                 }
var cnckrkii = GetInputConstructorValue("cnckrkii", loader);
                 if(cnckrkii["original"].length == 0)
                 {
                   Invalid("speed" + " is empty");
                   return;
                 }
var jceghccv = GetInputConstructorValue("jceghccv", loader);
                 if(jceghccv["original"].length == 0)
                 {
                   Invalid("type_slide" + " is empty");
                   return;
                 }
var pkothers = GetInputConstructorValue("pkothers", loader);
                 if(pkothers["original"].length == 0)
                 {
                   Invalid("type_swipe" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SliderSolver_code").html())({"iksaxuhh": iksaxuhh["updated"],"szixmevt": szixmevt["updated"],"ekmkcnig": ekmkcnig["updated"],"qqaqxiud": qqaqxiud["updated"],"qixenmrz": qixenmrz["updated"],"rzaxyskt": rzaxyskt["updated"],"ylsrhvvy": ylsrhvvy["updated"],"siqxnwnk": siqxnwnk["updated"],"cnckrkii": cnckrkii["updated"],"jceghccv": jceghccv["updated"],"pkothers": pkothers["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
