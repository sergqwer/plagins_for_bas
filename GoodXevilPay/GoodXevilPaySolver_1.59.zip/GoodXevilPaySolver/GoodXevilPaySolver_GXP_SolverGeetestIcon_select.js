var lsognfos = GetInputConstructorValue("lsognfos", loader);
                 if(lsognfos["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var ejvfpawh = GetInputConstructorValue("ejvfpawh", loader);
                 if(ejvfpawh["original"].length == 0)
                 {
                   Invalid("captcha_submit" + " is empty");
                   return;
                 }
var lamfewfu = GetInputConstructorValue("lamfewfu", loader);
                 if(lamfewfu["original"].length == 0)
                 {
                   Invalid("foto_captcha" + " is empty");
                   return;
                 }
var tzzjeiga = GetInputConstructorValue("tzzjeiga", loader);
                 if(tzzjeiga["original"].length == 0)
                 {
                   Invalid("pixel_coef" + " is empty");
                   return;
                 }
var lmczxfxc = GetInputConstructorValue("lmczxfxc", loader);
                 if(lmczxfxc["original"].length == 0)
                 {
                   Invalid("reload_captcha" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SolverGeetestIcon_code").html())({"lsognfos": lsognfos["updated"],"ejvfpawh": ejvfpawh["updated"],"lamfewfu": lamfewfu["updated"],"tzzjeiga": tzzjeiga["updated"],"lmczxfxc": lmczxfxc["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
