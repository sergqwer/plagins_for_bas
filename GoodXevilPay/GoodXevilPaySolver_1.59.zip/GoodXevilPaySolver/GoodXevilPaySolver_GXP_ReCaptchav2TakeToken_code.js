_call_function(GoodXevilPaySolver_GXP_ReCaptchav2TakeToken,{ "APIKEY": (<%= sbidfgrd %>),"site_url": (<%= thjcendp %>),"sitekey": (<%= vyjxjnzq %>) })!
<%= variable %> = _result_function()
