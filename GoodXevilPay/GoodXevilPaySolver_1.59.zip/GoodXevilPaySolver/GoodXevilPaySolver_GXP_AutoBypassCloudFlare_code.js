_call_function(GoodXevilPaySolver_GXP_AutoBypassCloudFlare,{ "custom_button": (<%= cvvlrzss %>),"max_time": (<%= uupoionh %>),"whait_element": (<%= vzlbchcc %>) })!
