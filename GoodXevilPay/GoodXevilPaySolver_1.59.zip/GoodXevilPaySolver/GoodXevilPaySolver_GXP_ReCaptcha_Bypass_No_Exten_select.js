var onpyrbmz = GetInputConstructorValue("onpyrbmz", loader);
                 if(onpyrbmz["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var uypvxsej = GetInputConstructorValue("uypvxsej", loader);
                 if(uypvxsej["original"].length == 0)
                 {
                   Invalid("index" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_ReCaptcha_Bypass_No_Exten_code").html())({"onpyrbmz": onpyrbmz["updated"],"uypvxsej": uypvxsej["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
