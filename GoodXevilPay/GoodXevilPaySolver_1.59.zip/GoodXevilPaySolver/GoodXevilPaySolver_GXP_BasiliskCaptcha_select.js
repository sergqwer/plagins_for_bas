var hkjdlolk = GetInputConstructorValue("hkjdlolk", loader);
                 if(hkjdlolk["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var kqvwvxaj = GetInputConstructorValue("kqvwvxaj", loader);
                 if(kqvwvxaj["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var pqoezmij = GetInputConstructorValue("pqoezmij", loader);
                 if(pqoezmij["original"].length == 0)
                 {
                   Invalid("siteurl" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_BasiliskCaptcha_code").html())({"hkjdlolk": hkjdlolk["updated"],"kqvwvxaj": kqvwvxaj["updated"],"pqoezmij": pqoezmij["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
