var cvvlrzss = GetInputConstructorValue("cvvlrzss", loader);
                 if(cvvlrzss["original"].length == 0)
                 {
                   Invalid("custom_button" + " is empty");
                   return;
                 }
var uupoionh = GetInputConstructorValue("uupoionh", loader);
                 if(uupoionh["original"].length == 0)
                 {
                   Invalid("max_time" + " is empty");
                   return;
                 }
var vzlbchcc = GetInputConstructorValue("vzlbchcc", loader);
                 if(vzlbchcc["original"].length == 0)
                 {
                   Invalid("whait_element" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_AutoBypassCloudFlare_code").html())({"cvvlrzss": cvvlrzss["updated"],"uupoionh": uupoionh["updated"],"vzlbchcc": vzlbchcc["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
