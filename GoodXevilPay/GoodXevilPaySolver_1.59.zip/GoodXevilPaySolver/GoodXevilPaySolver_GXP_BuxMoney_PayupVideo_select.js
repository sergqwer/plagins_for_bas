var fxerlaox = GetInputConstructorValue("fxerlaox", loader);
                 if(fxerlaox["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var fipzgxso = GetInputConstructorValue("fipzgxso", loader);
                 if(fipzgxso["original"].length == 0)
                 {
                   Invalid("timer" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_BuxMoney_PayupVideo_code").html())({"fxerlaox": fxerlaox["updated"],"fipzgxso": fipzgxso["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
