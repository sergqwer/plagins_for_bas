_call_function(GoodXevilPaySolver_GXP_Namars,{ "apikey": (<%= czkgymdu %>) })!
<%= variable %> = _result_function()
