_call_function(GoodXevilPaySolver_GXP_HcaptchaTakeToken,{ "APIKEY": (<%= pqdxslwb %>),"site_url": (<%= ljuxlxvq %>),"sitekey": (<%= ngbyskey %>) })!
<%= variable %> = _result_function()
