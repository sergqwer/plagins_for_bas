_call_function(GoodXevilPaySolver_GXP_ReCaptchav2TakeToken,{ "APIKEY": (<%= ekehokcg %>),"site_url": (<%= rrytexyv %>),"sitekey": (<%= beqhhymb %>) })!
<%= variable %> = _result_function()
