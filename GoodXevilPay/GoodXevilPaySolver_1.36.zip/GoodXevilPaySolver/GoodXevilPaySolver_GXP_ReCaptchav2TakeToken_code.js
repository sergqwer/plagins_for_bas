_call_function(GoodXevilPaySolver_GXP_ReCaptchav2TakeToken,{ "APIKEY": (<%= ygtcszcm %>),"site_url": (<%= vdqsvhce %>),"sitekey": (<%= yxijmdvl %>) })!
<%= variable %> = _result_function()
