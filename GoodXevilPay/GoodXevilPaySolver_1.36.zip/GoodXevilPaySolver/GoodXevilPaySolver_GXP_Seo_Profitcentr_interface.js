<div class="container-fluid">
<%= _.template($('#input_constructor').html())({id:"mnpqdwaf", description:"apikey", default_selector: "string", disable_int:true, value_string: "", help: {description: "apikey с бота в телеграмме https://t.me/Xevil_check_bot"} }) %>
</div>
<div class="tooltipinternal">
<div class="tr tooltip-paragraph-first-fold">Решает капчу на сайтe profitcentr.com с помощью сервиса https://t.me/Xevil_check_bot, для того чтобы решить капчу, запустите функцию на странице с капчей, если скрипт не смог решить капчу за 5 раз, он вернет ошибку которую можно обработать дейстиваем "Игнорировать ошибки"</div>
</div>
<%= _.template($('#back').html())({action:"executeandadd", visible:true}) %>
