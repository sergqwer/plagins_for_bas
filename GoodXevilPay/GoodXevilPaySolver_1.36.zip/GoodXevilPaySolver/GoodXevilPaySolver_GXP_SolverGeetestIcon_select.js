var qkyjqynx = GetInputConstructorValue("qkyjqynx", loader);
                 if(qkyjqynx["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var jvovllnh = GetInputConstructorValue("jvovllnh", loader);
                 if(jvovllnh["original"].length == 0)
                 {
                   Invalid("button_capthca" + " is empty");
                   return;
                 }
var hbvwiioq = GetInputConstructorValue("hbvwiioq", loader);
                 if(hbvwiioq["original"].length == 0)
                 {
                   Invalid("captcha_submit" + " is empty");
                   return;
                 }
var rmjktzbm = GetInputConstructorValue("rmjktzbm", loader);
                 if(rmjktzbm["original"].length == 0)
                 {
                   Invalid("foto_captcha" + " is empty");
                   return;
                 }
var zxyyepsp = GetInputConstructorValue("zxyyepsp", loader);
                 if(zxyyepsp["original"].length == 0)
                 {
                   Invalid("reload_captcha" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SolverGeetestIcon_code").html())({"qkyjqynx": qkyjqynx["updated"],"jvovllnh": jvovllnh["updated"],"hbvwiioq": hbvwiioq["updated"],"rmjktzbm": rmjktzbm["updated"],"zxyyepsp": zxyyepsp["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
