var dvxrbpmq = GetInputConstructorValue("dvxrbpmq", loader);
                 if(dvxrbpmq["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var hrnarhjq = GetInputConstructorValue("hrnarhjq", loader);
                 if(hrnarhjq["original"].length == 0)
                 {
                   Invalid("button_capthca" + " is empty");
                   return;
                 }
var ylozrvin = GetInputConstructorValue("ylozrvin", loader);
                 if(ylozrvin["original"].length == 0)
                 {
                   Invalid("captcha_submit" + " is empty");
                   return;
                 }
var onyvvpcs = GetInputConstructorValue("onyvvpcs", loader);
                 if(onyvvpcs["original"].length == 0)
                 {
                   Invalid("foto_captcha" + " is empty");
                   return;
                 }
var fmkpduwk = GetInputConstructorValue("fmkpduwk", loader);
                 if(fmkpduwk["original"].length == 0)
                 {
                   Invalid("reload_captcha" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SolverGeetestIcon_code").html())({"dvxrbpmq": dvxrbpmq["updated"],"hrnarhjq": hrnarhjq["updated"],"ylozrvin": ylozrvin["updated"],"onyvvpcs": onyvvpcs["updated"],"fmkpduwk": fmkpduwk["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
