<div class="container-fluid">
</div>
<div class="tooltipinternal">
<div class="tr tooltip-paragraph-first-fold">Очищает папку prof от временных профилей, запускать при старте потока</div>
</div>
<%= _.template($('#back').html())({action:"executeandadd", visible:true}) %>
