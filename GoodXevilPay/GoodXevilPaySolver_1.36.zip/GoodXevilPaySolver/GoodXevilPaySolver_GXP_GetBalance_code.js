_call_function(GoodXevilPaySolver_GXP_GetBalance,{ "APIKEY": (<%= rufcuxqw %>) })!
<%= variable %> = _result_function()
