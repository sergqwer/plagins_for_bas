var nmfntzra = GetInputConstructorValue("nmfntzra", loader);
                 if(nmfntzra["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var ayberliw = GetInputConstructorValue("ayberliw", loader);
                 if(ayberliw["original"].length == 0)
                 {
                   Invalid("IMAGE_BASE64" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_IMAGE_BASE64_code").html())({"nmfntzra": nmfntzra["updated"],"ayberliw": ayberliw["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
