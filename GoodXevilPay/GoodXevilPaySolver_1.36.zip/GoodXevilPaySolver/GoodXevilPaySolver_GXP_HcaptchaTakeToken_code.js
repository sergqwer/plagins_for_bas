_call_function(GoodXevilPaySolver_GXP_HcaptchaTakeToken,{ "APIKEY": (<%= qwhfyelo %>),"site_url": (<%= zthhpsza %>),"sitekey": (<%= xeokensu %>) })!
<%= variable %> = _result_function()
