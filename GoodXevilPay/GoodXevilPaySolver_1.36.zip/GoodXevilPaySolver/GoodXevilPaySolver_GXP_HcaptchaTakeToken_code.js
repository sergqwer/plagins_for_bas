_call_function(GoodXevilPaySolver_GXP_HcaptchaTakeToken,{ "APIKEY": (<%= wezaojif %>),"site_url": (<%= fnhnjsmc %>),"sitekey": (<%= imbszzvo %>) })!
<%= variable %> = _result_function()
