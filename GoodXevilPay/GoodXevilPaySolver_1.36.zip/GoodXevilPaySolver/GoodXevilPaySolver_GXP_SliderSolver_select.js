var ehlzayan = GetInputConstructorValue("ehlzayan", loader);
                 if(ehlzayan["original"].length == 0)
                 {
                   Invalid("arrow_id" + " is empty");
                   return;
                 }
var pkapdocy = GetInputConstructorValue("pkapdocy", loader);
                 if(pkapdocy["original"].length == 0)
                 {
                   Invalid("avtoupdate" + " is empty");
                   return;
                 }
var jfpbsrpz = GetInputConstructorValue("jfpbsrpz", loader);
                 if(jfpbsrpz["original"].length == 0)
                 {
                   Invalid("button_id" + " is empty");
                   return;
                 }
var vgwoudax = GetInputConstructorValue("vgwoudax", loader);
                 if(vgwoudax["original"].length == 0)
                 {
                   Invalid("coef" + " is empty");
                   return;
                 }
var vxrladus = GetInputConstructorValue("vxrladus", loader);
                 if(vxrladus["original"].length == 0)
                 {
                   Invalid("image id" + " is empty");
                   return;
                 }
var govtwuiz = GetInputConstructorValue("govtwuiz", loader);
                 if(govtwuiz["original"].length == 0)
                 {
                   Invalid("key" + " is empty");
                   return;
                 }
var qxisbodm = GetInputConstructorValue("qxisbodm", loader);
                 if(qxisbodm["original"].length == 0)
                 {
                   Invalid("pixel_koef" + " is empty");
                   return;
                 }
var acmgsjsa = GetInputConstructorValue("acmgsjsa", loader);
                 if(acmgsjsa["original"].length == 0)
                 {
                   Invalid("reload_id" + " is empty");
                   return;
                 }
var mleqfbtl = GetInputConstructorValue("mleqfbtl", loader);
                 if(mleqfbtl["original"].length == 0)
                 {
                   Invalid("speed" + " is empty");
                   return;
                 }
var tzhwpdor = GetInputConstructorValue("tzhwpdor", loader);
                 if(tzhwpdor["original"].length == 0)
                 {
                   Invalid("type_slide" + " is empty");
                   return;
                 }
var rtsjxcxu = GetInputConstructorValue("rtsjxcxu", loader);
                 if(rtsjxcxu["original"].length == 0)
                 {
                   Invalid("type_swipe" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SliderSolver_code").html())({"ehlzayan": ehlzayan["updated"],"pkapdocy": pkapdocy["updated"],"jfpbsrpz": jfpbsrpz["updated"],"vgwoudax": vgwoudax["updated"],"vxrladus": vxrladus["updated"],"govtwuiz": govtwuiz["updated"],"qxisbodm": qxisbodm["updated"],"acmgsjsa": acmgsjsa["updated"],"mleqfbtl": mleqfbtl["updated"],"tzhwpdor": tzhwpdor["updated"],"rtsjxcxu": rtsjxcxu["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
