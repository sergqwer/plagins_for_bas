var ugbjtfuh = GetInputConstructorValue("ugbjtfuh", loader);
                 if(ugbjtfuh["original"].length == 0)
                 {
                   Invalid("arrow_id" + " is empty");
                   return;
                 }
var rowbxpdc = GetInputConstructorValue("rowbxpdc", loader);
                 if(rowbxpdc["original"].length == 0)
                 {
                   Invalid("avtoupdate" + " is empty");
                   return;
                 }
var grnswkgs = GetInputConstructorValue("grnswkgs", loader);
                 if(grnswkgs["original"].length == 0)
                 {
                   Invalid("button_id" + " is empty");
                   return;
                 }
var lmitjywo = GetInputConstructorValue("lmitjywo", loader);
                 if(lmitjywo["original"].length == 0)
                 {
                   Invalid("coef" + " is empty");
                   return;
                 }
var fmzznfpq = GetInputConstructorValue("fmzznfpq", loader);
                 if(fmzznfpq["original"].length == 0)
                 {
                   Invalid("image id" + " is empty");
                   return;
                 }
var qqaddlmc = GetInputConstructorValue("qqaddlmc", loader);
                 if(qqaddlmc["original"].length == 0)
                 {
                   Invalid("key" + " is empty");
                   return;
                 }
var jxvztsvt = GetInputConstructorValue("jxvztsvt", loader);
                 if(jxvztsvt["original"].length == 0)
                 {
                   Invalid("pixel_koef" + " is empty");
                   return;
                 }
var mhfoalih = GetInputConstructorValue("mhfoalih", loader);
                 if(mhfoalih["original"].length == 0)
                 {
                   Invalid("reload_id" + " is empty");
                   return;
                 }
var jeylxpof = GetInputConstructorValue("jeylxpof", loader);
                 if(jeylxpof["original"].length == 0)
                 {
                   Invalid("speed" + " is empty");
                   return;
                 }
var kwkcrbvz = GetInputConstructorValue("kwkcrbvz", loader);
                 if(kwkcrbvz["original"].length == 0)
                 {
                   Invalid("type_slide" + " is empty");
                   return;
                 }
var uyvwghoa = GetInputConstructorValue("uyvwghoa", loader);
                 if(uyvwghoa["original"].length == 0)
                 {
                   Invalid("type_swipe" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SliderSolver_code").html())({"ugbjtfuh": ugbjtfuh["updated"],"rowbxpdc": rowbxpdc["updated"],"grnswkgs": grnswkgs["updated"],"lmitjywo": lmitjywo["updated"],"fmzznfpq": fmzznfpq["updated"],"qqaddlmc": qqaddlmc["updated"],"jxvztsvt": jxvztsvt["updated"],"mhfoalih": mhfoalih["updated"],"jeylxpof": jeylxpof["updated"],"kwkcrbvz": kwkcrbvz["updated"],"uyvwghoa": uyvwghoa["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
