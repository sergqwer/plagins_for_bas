var rxcymsxj = GetInputConstructorValue("rxcymsxj", loader);
                 if(rxcymsxj["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var ccnaiwfy = GetInputConstructorValue("ccnaiwfy", loader);
                 if(ccnaiwfy["original"].length == 0)
                 {
                   Invalid("mouse" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_Antibot_code").html())({"rxcymsxj": rxcymsxj["updated"],"ccnaiwfy": ccnaiwfy["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
