_call_function(GoodXevilPaySolver_GXP_IMAGE_BASE64,{ "APIKEY": (<%= nmfntzra %>),"IMAGE_BASE64": (<%= ayberliw %>) })!
<%= variable %> = _result_function()
