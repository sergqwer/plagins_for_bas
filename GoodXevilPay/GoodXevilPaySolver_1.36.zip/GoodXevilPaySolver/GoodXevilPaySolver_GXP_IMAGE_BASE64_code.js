_call_function(GoodXevilPaySolver_GXP_IMAGE_BASE64,{ "APIKEY": (<%= xthcwcky %>),"IMAGE_BASE64": (<%= yemkoxck %>) })!
<%= variable %> = _result_function()
