var qwhfyelo = GetInputConstructorValue("qwhfyelo", loader);
                 if(qwhfyelo["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var zthhpsza = GetInputConstructorValue("zthhpsza", loader);
                 if(zthhpsza["original"].length == 0)
                 {
                   Invalid("site_url" + " is empty");
                   return;
                 }
var xeokensu = GetInputConstructorValue("xeokensu", loader);
                 if(xeokensu["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_HcaptchaTakeToken_code").html())({"qwhfyelo": qwhfyelo["updated"],"zthhpsza": zthhpsza["updated"],"xeokensu": xeokensu["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
