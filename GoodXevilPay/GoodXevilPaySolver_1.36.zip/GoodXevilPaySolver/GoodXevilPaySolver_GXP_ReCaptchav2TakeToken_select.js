var ygtcszcm = GetInputConstructorValue("ygtcszcm", loader);
                 if(ygtcszcm["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var vdqsvhce = GetInputConstructorValue("vdqsvhce", loader);
                 if(vdqsvhce["original"].length == 0)
                 {
                   Invalid("site_url" + " is empty");
                   return;
                 }
var yxijmdvl = GetInputConstructorValue("yxijmdvl", loader);
                 if(yxijmdvl["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_ReCaptchav2TakeToken_code").html())({"ygtcszcm": ygtcszcm["updated"],"vdqsvhce": vdqsvhce["updated"],"yxijmdvl": yxijmdvl["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
