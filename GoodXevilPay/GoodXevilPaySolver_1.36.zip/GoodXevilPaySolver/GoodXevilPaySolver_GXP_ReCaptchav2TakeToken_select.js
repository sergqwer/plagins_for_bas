var ekehokcg = GetInputConstructorValue("ekehokcg", loader);
                 if(ekehokcg["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var rrytexyv = GetInputConstructorValue("rrytexyv", loader);
                 if(rrytexyv["original"].length == 0)
                 {
                   Invalid("site_url" + " is empty");
                   return;
                 }
var beqhhymb = GetInputConstructorValue("beqhhymb", loader);
                 if(beqhhymb["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_ReCaptchav2TakeToken_code").html())({"ekehokcg": ekehokcg["updated"],"rrytexyv": rrytexyv["updated"],"beqhhymb": beqhhymb["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
