var yaywenxd = GetInputConstructorValue("yaywenxd", loader);
                 if(yaywenxd["original"].length == 0)
                 {
                   Invalid("arrow_id" + " is empty");
                   return;
                 }
var ekwjziug = GetInputConstructorValue("ekwjziug", loader);
                 if(ekwjziug["original"].length == 0)
                 {
                   Invalid("avtoupdate" + " is empty");
                   return;
                 }
var lxvgeoss = GetInputConstructorValue("lxvgeoss", loader);
                 if(lxvgeoss["original"].length == 0)
                 {
                   Invalid("button_id" + " is empty");
                   return;
                 }
var kzcttvfk = GetInputConstructorValue("kzcttvfk", loader);
                 if(kzcttvfk["original"].length == 0)
                 {
                   Invalid("coef" + " is empty");
                   return;
                 }
var lzaktnvs = GetInputConstructorValue("lzaktnvs", loader);
                 if(lzaktnvs["original"].length == 0)
                 {
                   Invalid("image id" + " is empty");
                   return;
                 }
var gfjzaqqf = GetInputConstructorValue("gfjzaqqf", loader);
                 if(gfjzaqqf["original"].length == 0)
                 {
                   Invalid("key" + " is empty");
                   return;
                 }
var xmzyqify = GetInputConstructorValue("xmzyqify", loader);
                 if(xmzyqify["original"].length == 0)
                 {
                   Invalid("pixel_koef" + " is empty");
                   return;
                 }
var bwtspxwa = GetInputConstructorValue("bwtspxwa", loader);
                 if(bwtspxwa["original"].length == 0)
                 {
                   Invalid("reload_id" + " is empty");
                   return;
                 }
var xemfmhhs = GetInputConstructorValue("xemfmhhs", loader);
                 if(xemfmhhs["original"].length == 0)
                 {
                   Invalid("speed" + " is empty");
                   return;
                 }
var erlgjuid = GetInputConstructorValue("erlgjuid", loader);
                 if(erlgjuid["original"].length == 0)
                 {
                   Invalid("type_slide" + " is empty");
                   return;
                 }
var veugifph = GetInputConstructorValue("veugifph", loader);
                 if(veugifph["original"].length == 0)
                 {
                   Invalid("type_swipe" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SliderSolver_code").html())({"yaywenxd": yaywenxd["updated"],"ekwjziug": ekwjziug["updated"],"lxvgeoss": lxvgeoss["updated"],"kzcttvfk": kzcttvfk["updated"],"lzaktnvs": lzaktnvs["updated"],"gfjzaqqf": gfjzaqqf["updated"],"xmzyqify": xmzyqify["updated"],"bwtspxwa": bwtspxwa["updated"],"xemfmhhs": xemfmhhs["updated"],"erlgjuid": erlgjuid["updated"],"veugifph": veugifph["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
