var xlzthorq = GetInputConstructorValue("xlzthorq", loader);
                 if(xlzthorq["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var bmkruvzp = GetInputConstructorValue("bmkruvzp", loader);
                 if(bmkruvzp["original"].length == 0)
                 {
                   Invalid("timer" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_BuxMoney_PayupVideo_code").html())({"xlzthorq": xlzthorq["updated"],"bmkruvzp": bmkruvzp["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
