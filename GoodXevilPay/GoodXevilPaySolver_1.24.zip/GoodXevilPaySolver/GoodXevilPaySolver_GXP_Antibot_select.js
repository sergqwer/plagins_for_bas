var lhqesqgq = GetInputConstructorValue("lhqesqgq", loader);
                 if(lhqesqgq["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var qcibzjry = GetInputConstructorValue("qcibzjry", loader);
                 if(qcibzjry["original"].length == 0)
                 {
                   Invalid("mouse" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_Antibot_code").html())({"lhqesqgq": lhqesqgq["updated"],"qcibzjry": qcibzjry["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
