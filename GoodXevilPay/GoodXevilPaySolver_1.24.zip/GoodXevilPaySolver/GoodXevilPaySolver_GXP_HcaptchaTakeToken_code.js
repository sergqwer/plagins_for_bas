_call_function(GoodXevilPaySolver_GXP_HcaptchaTakeToken,{ "APIKEY": (<%= txilhord %>),"site_url": (<%= pokecuwt %>),"sitekey": (<%= fgcymtdi %>) })!
<%= variable %> = _result_function()
