_call_function(GoodXevilPaySolver_GXP_ReCaptchav2TakeToken,{ "APIKEY": (<%= zikiykmw %>),"site_url": (<%= vddfpcdl %>),"sitekey": (<%= dopwdhel %>) })!
<%= variable %> = _result_function()
