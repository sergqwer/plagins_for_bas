var qkhzumfd = GetInputConstructorValue("qkhzumfd", loader);
                 if(qkhzumfd["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var jknnfgnc = GetInputConstructorValue("jknnfgnc", loader);
                 if(jknnfgnc["original"].length == 0)
                 {
                   Invalid("button_capthca" + " is empty");
                   return;
                 }
var oahislto = GetInputConstructorValue("oahislto", loader);
                 if(oahislto["original"].length == 0)
                 {
                   Invalid("captcha_submit" + " is empty");
                   return;
                 }
var gcmqtuwk = GetInputConstructorValue("gcmqtuwk", loader);
                 if(gcmqtuwk["original"].length == 0)
                 {
                   Invalid("foto_captcha" + " is empty");
                   return;
                 }
var fceckjsz = GetInputConstructorValue("fceckjsz", loader);
                 if(fceckjsz["original"].length == 0)
                 {
                   Invalid("reload_captcha" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SolverGeetestIcon_code").html())({"qkhzumfd": qkhzumfd["updated"],"jknnfgnc": jknnfgnc["updated"],"oahislto": oahislto["updated"],"gcmqtuwk": gcmqtuwk["updated"],"fceckjsz": fceckjsz["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
