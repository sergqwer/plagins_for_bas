var twlmwsrw = GetInputConstructorValue("twlmwsrw", loader);
                 if(twlmwsrw["original"].length == 0)
                 {
                   Invalid("custom_button" + " is empty");
                   return;
                 }
var bzsrrdiu = GetInputConstructorValue("bzsrrdiu", loader);
                 if(bzsrrdiu["original"].length == 0)
                 {
                   Invalid("max_time" + " is empty");
                   return;
                 }
var sxvmcpjg = GetInputConstructorValue("sxvmcpjg", loader);
                 if(sxvmcpjg["original"].length == 0)
                 {
                   Invalid("whait_element" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#OLD_GoodXevilPaySolver_GXP_AutoBypassCloudFlare_code").html())({"twlmwsrw": twlmwsrw["updated"],"bzsrrdiu": bzsrrdiu["updated"],"sxvmcpjg": sxvmcpjg["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
