_call_function(OLD_GoodXevilPaySolver_GXP_HcaptchaTakeToken,{ "APIKEY": (<%= mewsjagz %>),"site_url": (<%= cnsaeaee %>),"sitekey": (<%= zsadkxkw %>) })!
<%= variable %> = _result_function()
