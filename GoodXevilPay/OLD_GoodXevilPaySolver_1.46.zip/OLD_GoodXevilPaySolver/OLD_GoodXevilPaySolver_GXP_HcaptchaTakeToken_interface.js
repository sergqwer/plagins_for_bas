<div class="container-fluid">
<%= _.template($('#input_constructor').html())({id:"mewsjagz", description:"APIKEY", default_selector: "string", disable_int:true, value_string: "", help: {description: "apikey с сервиса https://t.me/Xevil_check_bot"} }) %>
<%= _.template($('#input_constructor').html())({id:"cnsaeaee", description:"site_url", default_selector: "string", disable_int:true, value_string: "", help: {description: "Полный URL страницы где находится Hcaptcha"} }) %>
<%= _.template($('#input_constructor').html())({id:"zsadkxkw", description:"sitekey", default_selector: "string", disable_int:true, value_string: "", help: {description: "Значение параметра data-sitekey Hcaptcha"} }) %>
<%= _.template($('#variable_constructor').html())({id:"Save", description:"Результат", default_variable: "HCAPTCHA_TOKEN", help: {description: "Токен hcaptcha"}}) %>
</div>
<div class="tooltipinternal">
<div class="tr tooltip-paragraph-first-fold">Эта функция получает токен Hcaptcha через сервис решения капчи https://t.me/Xevil_check_bot</div>
</div>
<%= _.template($('#back').html())({action:"executeandadd", visible:true}) %>
