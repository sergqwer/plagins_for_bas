var uyqnlusq = GetInputConstructorValue("uyqnlusq", loader);
                 if(uyqnlusq["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var ajdnrptp = GetInputConstructorValue("ajdnrptp", loader);
                 if(ajdnrptp["original"].length == 0)
                 {
                   Invalid("mouse" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#OLD_GoodXevilPaySolver_GXP_Antibot_code").html())({"uyqnlusq": uyqnlusq["updated"],"ajdnrptp": ajdnrptp["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
