_call_function(OLD_GoodXevilPaySolver_GXP_IMAGE_BASE64,{ "APIKEY": (<%= vzzwwnre %>),"IMAGE_BASE64": (<%= dnautcud %>) })!
<%= variable %> = _result_function()
