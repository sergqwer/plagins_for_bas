_call_function(OLD_GoodXevilPaySolver_GXP_ReCaptchav2TakeToken,{ "APIKEY": (<%= qhhchens %>),"site_url": (<%= rsqqfxfs %>),"sitekey": (<%= yikiupuk %>) })!
<%= variable %> = _result_function()
