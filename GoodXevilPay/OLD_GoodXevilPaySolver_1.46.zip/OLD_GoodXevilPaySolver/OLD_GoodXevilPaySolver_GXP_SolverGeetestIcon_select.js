var cfjjmpkk = GetInputConstructorValue("cfjjmpkk", loader);
                 if(cfjjmpkk["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var ffhoqzko = GetInputConstructorValue("ffhoqzko", loader);
                 if(ffhoqzko["original"].length == 0)
                 {
                   Invalid("button_capthca" + " is empty");
                   return;
                 }
var yzlykkki = GetInputConstructorValue("yzlykkki", loader);
                 if(yzlykkki["original"].length == 0)
                 {
                   Invalid("captcha_submit" + " is empty");
                   return;
                 }
var owwfdrju = GetInputConstructorValue("owwfdrju", loader);
                 if(owwfdrju["original"].length == 0)
                 {
                   Invalid("foto_captcha" + " is empty");
                   return;
                 }
var yctrlvbs = GetInputConstructorValue("yctrlvbs", loader);
                 if(yctrlvbs["original"].length == 0)
                 {
                   Invalid("reload_captcha" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#OLD_GoodXevilPaySolver_GXP_SolverGeetestIcon_code").html())({"cfjjmpkk": cfjjmpkk["updated"],"ffhoqzko": ffhoqzko["updated"],"yzlykkki": yzlykkki["updated"],"owwfdrju": owwfdrju["updated"],"yctrlvbs": yctrlvbs["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
