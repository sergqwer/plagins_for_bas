var rbmfowdm = GetInputConstructorValue("rbmfowdm", loader);
                 if(rbmfowdm["original"].length == 0)
                 {
                   Invalid("arrow_id" + " is empty");
                   return;
                 }
var wmzprnpe = GetInputConstructorValue("wmzprnpe", loader);
                 if(wmzprnpe["original"].length == 0)
                 {
                   Invalid("avtoupdate" + " is empty");
                   return;
                 }
var zsqmsmve = GetInputConstructorValue("zsqmsmve", loader);
                 if(zsqmsmve["original"].length == 0)
                 {
                   Invalid("button_id" + " is empty");
                   return;
                 }
var yiuqwsyb = GetInputConstructorValue("yiuqwsyb", loader);
                 if(yiuqwsyb["original"].length == 0)
                 {
                   Invalid("coef" + " is empty");
                   return;
                 }
var hqulkwvm = GetInputConstructorValue("hqulkwvm", loader);
                 if(hqulkwvm["original"].length == 0)
                 {
                   Invalid("image id" + " is empty");
                   return;
                 }
var rkqsbvhi = GetInputConstructorValue("rkqsbvhi", loader);
                 if(rkqsbvhi["original"].length == 0)
                 {
                   Invalid("key" + " is empty");
                   return;
                 }
var uambpmda = GetInputConstructorValue("uambpmda", loader);
                 if(uambpmda["original"].length == 0)
                 {
                   Invalid("pixel_koef" + " is empty");
                   return;
                 }
var zcoizvph = GetInputConstructorValue("zcoizvph", loader);
                 if(zcoizvph["original"].length == 0)
                 {
                   Invalid("reload_id" + " is empty");
                   return;
                 }
var yalcecmk = GetInputConstructorValue("yalcecmk", loader);
                 if(yalcecmk["original"].length == 0)
                 {
                   Invalid("speed" + " is empty");
                   return;
                 }
var fqdeopvr = GetInputConstructorValue("fqdeopvr", loader);
                 if(fqdeopvr["original"].length == 0)
                 {
                   Invalid("type_slide" + " is empty");
                   return;
                 }
var cufsdsje = GetInputConstructorValue("cufsdsje", loader);
                 if(cufsdsje["original"].length == 0)
                 {
                   Invalid("type_swipe" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#OLD_GoodXevilPaySolver_GXP_SliderSolver_code").html())({"rbmfowdm": rbmfowdm["updated"],"wmzprnpe": wmzprnpe["updated"],"zsqmsmve": zsqmsmve["updated"],"yiuqwsyb": yiuqwsyb["updated"],"hqulkwvm": hqulkwvm["updated"],"rkqsbvhi": rkqsbvhi["updated"],"uambpmda": uambpmda["updated"],"zcoizvph": zcoizvph["updated"],"yalcecmk": yalcecmk["updated"],"fqdeopvr": fqdeopvr["updated"],"cufsdsje": cufsdsje["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
