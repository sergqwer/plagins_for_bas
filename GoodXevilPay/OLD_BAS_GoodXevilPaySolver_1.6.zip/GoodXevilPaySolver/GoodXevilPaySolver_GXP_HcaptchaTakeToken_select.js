var cvppmwqj = GetInputConstructorValue("cvppmwqj", loader);
                 if(cvppmwqj["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var xbqvkqxy = GetInputConstructorValue("xbqvkqxy", loader);
                 if(xbqvkqxy["original"].length == 0)
                 {
                   Invalid("site_url" + " is empty");
                   return;
                 }
var yexbnbea = GetInputConstructorValue("yexbnbea", loader);
                 if(yexbnbea["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_HcaptchaTakeToken_code").html())({"cvppmwqj": cvppmwqj["updated"],"xbqvkqxy": xbqvkqxy["updated"],"yexbnbea": yexbnbea["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
