var xmojkjjk = GetInputConstructorValue("xmojkjjk", loader);
                 if(xmojkjjk["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var zoyvxfvw = GetInputConstructorValue("zoyvxfvw", loader);
                 if(zoyvxfvw["original"].length == 0)
                 {
                   Invalid("site_url" + " is empty");
                   return;
                 }
var yzldinwe = GetInputConstructorValue("yzldinwe", loader);
                 if(yzldinwe["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_ReCaptchav2TakeToken_code").html())({"xmojkjjk": xmojkjjk["updated"],"zoyvxfvw": zoyvxfvw["updated"],"yzldinwe": yzldinwe["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
