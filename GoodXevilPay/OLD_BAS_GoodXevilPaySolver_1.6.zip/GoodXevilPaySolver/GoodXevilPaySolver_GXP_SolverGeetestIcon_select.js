var ywgouqwv = GetInputConstructorValue("ywgouqwv", loader);
                 if(ywgouqwv["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var juiwngnl = GetInputConstructorValue("juiwngnl", loader);
                 if(juiwngnl["original"].length == 0)
                 {
                   Invalid("button_capthca" + " is empty");
                   return;
                 }
var phrkaqjr = GetInputConstructorValue("phrkaqjr", loader);
                 if(phrkaqjr["original"].length == 0)
                 {
                   Invalid("captcha_submit" + " is empty");
                   return;
                 }
var angcxvpw = GetInputConstructorValue("angcxvpw", loader);
                 if(angcxvpw["original"].length == 0)
                 {
                   Invalid("foto_captcha" + " is empty");
                   return;
                 }
var xqisewhe = GetInputConstructorValue("xqisewhe", loader);
                 if(xqisewhe["original"].length == 0)
                 {
                   Invalid("reload_captcha" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SolverGeetestIcon_code").html())({"ywgouqwv": ywgouqwv["updated"],"juiwngnl": juiwngnl["updated"],"phrkaqjr": phrkaqjr["updated"],"angcxvpw": angcxvpw["updated"],"xqisewhe": xqisewhe["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
