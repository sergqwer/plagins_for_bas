_call_function(GoodXevilPaySolver_GXP_ReCaptchav2TakeToken,{ "APIKEY": (<%= xmojkjjk %>),"site_url": (<%= zoyvxfvw %>),"sitekey": (<%= yzldinwe %>) })!
<%= variable %> = _result_function()
