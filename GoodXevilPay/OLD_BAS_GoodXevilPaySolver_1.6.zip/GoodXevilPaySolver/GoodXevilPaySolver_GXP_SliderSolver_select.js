var nwmsqhbh = GetInputConstructorValue("nwmsqhbh", loader);
                 if(nwmsqhbh["original"].length == 0)
                 {
                   Invalid("arrow_id" + " is empty");
                   return;
                 }
var nppmyphg = GetInputConstructorValue("nppmyphg", loader);
                 if(nppmyphg["original"].length == 0)
                 {
                   Invalid("avtoupdate" + " is empty");
                   return;
                 }
var htytczqa = GetInputConstructorValue("htytczqa", loader);
                 if(htytczqa["original"].length == 0)
                 {
                   Invalid("button_id" + " is empty");
                   return;
                 }
var vzzyzkei = GetInputConstructorValue("vzzyzkei", loader);
                 if(vzzyzkei["original"].length == 0)
                 {
                   Invalid("coef" + " is empty");
                   return;
                 }
var sfcusxcy = GetInputConstructorValue("sfcusxcy", loader);
                 if(sfcusxcy["original"].length == 0)
                 {
                   Invalid("image id" + " is empty");
                   return;
                 }
var iccyikdc = GetInputConstructorValue("iccyikdc", loader);
                 if(iccyikdc["original"].length == 0)
                 {
                   Invalid("key" + " is empty");
                   return;
                 }
var jcibxsao = GetInputConstructorValue("jcibxsao", loader);
                 if(jcibxsao["original"].length == 0)
                 {
                   Invalid("pixel_koef" + " is empty");
                   return;
                 }
var swdndekw = GetInputConstructorValue("swdndekw", loader);
                 if(swdndekw["original"].length == 0)
                 {
                   Invalid("reload_id" + " is empty");
                   return;
                 }
var vzmeeskv = GetInputConstructorValue("vzmeeskv", loader);
                 if(vzmeeskv["original"].length == 0)
                 {
                   Invalid("speed" + " is empty");
                   return;
                 }
var bwfgdhoe = GetInputConstructorValue("bwfgdhoe", loader);
                 if(bwfgdhoe["original"].length == 0)
                 {
                   Invalid("type_slide" + " is empty");
                   return;
                 }
var uzwrvdab = GetInputConstructorValue("uzwrvdab", loader);
                 if(uzwrvdab["original"].length == 0)
                 {
                   Invalid("type_swipe" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SliderSolver_code").html())({"nwmsqhbh": nwmsqhbh["updated"],"nppmyphg": nppmyphg["updated"],"htytczqa": htytczqa["updated"],"vzzyzkei": vzzyzkei["updated"],"sfcusxcy": sfcusxcy["updated"],"iccyikdc": iccyikdc["updated"],"jcibxsao": jcibxsao["updated"],"swdndekw": swdndekw["updated"],"vzmeeskv": vzmeeskv["updated"],"bwfgdhoe": bwfgdhoe["updated"],"uzwrvdab": uzwrvdab["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
