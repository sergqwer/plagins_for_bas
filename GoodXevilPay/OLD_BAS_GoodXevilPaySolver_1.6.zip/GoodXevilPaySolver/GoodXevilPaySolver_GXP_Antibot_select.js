var qrqmdzaz = GetInputConstructorValue("qrqmdzaz", loader);
                 if(qrqmdzaz["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var auyrsqgy = GetInputConstructorValue("auyrsqgy", loader);
                 if(auyrsqgy["original"].length == 0)
                 {
                   Invalid("mouse" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_Antibot_code").html())({"qrqmdzaz": qrqmdzaz["updated"],"auyrsqgy": auyrsqgy["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
