_call_function(GoodXevilPaySolver_GXP_HcaptchaTakeToken,{ "APIKEY": (<%= cvppmwqj %>),"site_url": (<%= xbqvkqxy %>),"sitekey": (<%= yexbnbea %>) })!
<%= variable %> = _result_function()
