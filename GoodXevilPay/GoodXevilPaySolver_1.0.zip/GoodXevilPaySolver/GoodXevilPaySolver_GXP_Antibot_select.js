var ehibedqy = GetInputConstructorValue("ehibedqy", loader);
                 if(ehibedqy["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var ewlierwk = GetInputConstructorValue("ewlierwk", loader);
                 if(ewlierwk["original"].length == 0)
                 {
                   Invalid("mouse" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_Antibot_code").html())({"ehibedqy": ehibedqy["updated"],"ewlierwk": ewlierwk["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
