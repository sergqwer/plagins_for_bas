var rrrhvmnr = GetInputConstructorValue("rrrhvmnr", loader);
                 if(rrrhvmnr["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var qpaxvkgu = GetInputConstructorValue("qpaxvkgu", loader);
                 if(qpaxvkgu["original"].length == 0)
                 {
                   Invalid("mouse" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_Antibot_code").html())({"rrrhvmnr": rrrhvmnr["updated"],"qpaxvkgu": qpaxvkgu["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
