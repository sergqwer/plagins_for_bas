var doqrrcmo = GetInputConstructorValue("doqrrcmo", loader);
                 if(doqrrcmo["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var rxgwrppi = GetInputConstructorValue("rxgwrppi", loader);
                 if(rxgwrppi["original"].length == 0)
                 {
                   Invalid("timer" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_BuxMoney_PayupVideo_code").html())({"doqrrcmo": doqrrcmo["updated"],"rxgwrppi": rxgwrppi["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
