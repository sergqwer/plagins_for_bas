_call_function(GoodXevilPaySolver_GXP_Antibot,{ "apikey": (<%= fxfwqfkk %>),"mouse": (<%= bjieiobt %>) })!
