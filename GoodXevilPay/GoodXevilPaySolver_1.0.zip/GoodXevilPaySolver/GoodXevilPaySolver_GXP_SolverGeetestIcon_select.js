var njuzhgyx = GetInputConstructorValue("njuzhgyx", loader);
                 if(njuzhgyx["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var ajtjkkql = GetInputConstructorValue("ajtjkkql", loader);
                 if(ajtjkkql["original"].length == 0)
                 {
                   Invalid("button_capthca" + " is empty");
                   return;
                 }
var rxydntqa = GetInputConstructorValue("rxydntqa", loader);
                 if(rxydntqa["original"].length == 0)
                 {
                   Invalid("captcha_submit" + " is empty");
                   return;
                 }
var yxrpxvzr = GetInputConstructorValue("yxrpxvzr", loader);
                 if(yxrpxvzr["original"].length == 0)
                 {
                   Invalid("foto_captcha" + " is empty");
                   return;
                 }
var akejaqwx = GetInputConstructorValue("akejaqwx", loader);
                 if(akejaqwx["original"].length == 0)
                 {
                   Invalid("reload_captcha" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SolverGeetestIcon_code").html())({"njuzhgyx": njuzhgyx["updated"],"ajtjkkql": ajtjkkql["updated"],"rxydntqa": rxydntqa["updated"],"yxrpxvzr": yxrpxvzr["updated"],"akejaqwx": akejaqwx["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
