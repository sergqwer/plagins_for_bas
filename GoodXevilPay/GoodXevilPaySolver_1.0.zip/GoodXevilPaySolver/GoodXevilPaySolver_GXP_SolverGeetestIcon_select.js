var ntetvbqb = GetInputConstructorValue("ntetvbqb", loader);
                 if(ntetvbqb["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var kllfjnml = GetInputConstructorValue("kllfjnml", loader);
                 if(kllfjnml["original"].length == 0)
                 {
                   Invalid("button_capthca" + " is empty");
                   return;
                 }
var hdoxveki = GetInputConstructorValue("hdoxveki", loader);
                 if(hdoxveki["original"].length == 0)
                 {
                   Invalid("captcha_submit" + " is empty");
                   return;
                 }
var wdlwwxwj = GetInputConstructorValue("wdlwwxwj", loader);
                 if(wdlwwxwj["original"].length == 0)
                 {
                   Invalid("foto_captcha" + " is empty");
                   return;
                 }
var eopffscz = GetInputConstructorValue("eopffscz", loader);
                 if(eopffscz["original"].length == 0)
                 {
                   Invalid("reload_captcha" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SolverGeetestIcon_code").html())({"ntetvbqb": ntetvbqb["updated"],"kllfjnml": kllfjnml["updated"],"hdoxveki": hdoxveki["updated"],"wdlwwxwj": wdlwwxwj["updated"],"eopffscz": eopffscz["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
