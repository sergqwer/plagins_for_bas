var hquiaywo = GetInputConstructorValue("hquiaywo", loader);
                 if(hquiaywo["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var mziqguhp = GetInputConstructorValue("mziqguhp", loader);
                 if(mziqguhp["original"].length == 0)
                 {
                   Invalid("button_capthca" + " is empty");
                   return;
                 }
var gwqegjrr = GetInputConstructorValue("gwqegjrr", loader);
                 if(gwqegjrr["original"].length == 0)
                 {
                   Invalid("captcha_submit" + " is empty");
                   return;
                 }
var mtabqtuj = GetInputConstructorValue("mtabqtuj", loader);
                 if(mtabqtuj["original"].length == 0)
                 {
                   Invalid("foto_captcha" + " is empty");
                   return;
                 }
var wrowrtdn = GetInputConstructorValue("wrowrtdn", loader);
                 if(wrowrtdn["original"].length == 0)
                 {
                   Invalid("reload_captcha" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SolverGeetestIcon_code").html())({"hquiaywo": hquiaywo["updated"],"mziqguhp": mziqguhp["updated"],"gwqegjrr": gwqegjrr["updated"],"mtabqtuj": mtabqtuj["updated"],"wrowrtdn": wrowrtdn["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
