var oumjjkps = GetInputConstructorValue("oumjjkps", loader);
                 if(oumjjkps["original"].length == 0)
                 {
                   Invalid("arrow_id" + " is empty");
                   return;
                 }
var olredmbo = GetInputConstructorValue("olredmbo", loader);
                 if(olredmbo["original"].length == 0)
                 {
                   Invalid("avtoupdate" + " is empty");
                   return;
                 }
var mbfjlxij = GetInputConstructorValue("mbfjlxij", loader);
                 if(mbfjlxij["original"].length == 0)
                 {
                   Invalid("button_id" + " is empty");
                   return;
                 }
var ddtmewop = GetInputConstructorValue("ddtmewop", loader);
                 if(ddtmewop["original"].length == 0)
                 {
                   Invalid("coef" + " is empty");
                   return;
                 }
var icohcqxm = GetInputConstructorValue("icohcqxm", loader);
                 if(icohcqxm["original"].length == 0)
                 {
                   Invalid("image id" + " is empty");
                   return;
                 }
var illbycqp = GetInputConstructorValue("illbycqp", loader);
                 if(illbycqp["original"].length == 0)
                 {
                   Invalid("key" + " is empty");
                   return;
                 }
var kipqwhzr = GetInputConstructorValue("kipqwhzr", loader);
                 if(kipqwhzr["original"].length == 0)
                 {
                   Invalid("pixel_koef" + " is empty");
                   return;
                 }
var attulcup = GetInputConstructorValue("attulcup", loader);
                 if(attulcup["original"].length == 0)
                 {
                   Invalid("reload_id" + " is empty");
                   return;
                 }
var lvrfvrtn = GetInputConstructorValue("lvrfvrtn", loader);
                 if(lvrfvrtn["original"].length == 0)
                 {
                   Invalid("speed" + " is empty");
                   return;
                 }
var kkqmldev = GetInputConstructorValue("kkqmldev", loader);
                 if(kkqmldev["original"].length == 0)
                 {
                   Invalid("type_slide" + " is empty");
                   return;
                 }
var jqwjfjmj = GetInputConstructorValue("jqwjfjmj", loader);
                 if(jqwjfjmj["original"].length == 0)
                 {
                   Invalid("type_swipe" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SliderSolver_code").html())({"oumjjkps": oumjjkps["updated"],"olredmbo": olredmbo["updated"],"mbfjlxij": mbfjlxij["updated"],"ddtmewop": ddtmewop["updated"],"icohcqxm": icohcqxm["updated"],"illbycqp": illbycqp["updated"],"kipqwhzr": kipqwhzr["updated"],"attulcup": attulcup["updated"],"lvrfvrtn": lvrfvrtn["updated"],"kkqmldev": kkqmldev["updated"],"jqwjfjmj": jqwjfjmj["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
