var bzklebri = GetInputConstructorValue("bzklebri", loader);
                 if(bzklebri["original"].length == 0)
                 {
                   Invalid("arrow_id" + " is empty");
                   return;
                 }
var dtsumtkh = GetInputConstructorValue("dtsumtkh", loader);
                 if(dtsumtkh["original"].length == 0)
                 {
                   Invalid("avtoupdate" + " is empty");
                   return;
                 }
var pkuyfcpj = GetInputConstructorValue("pkuyfcpj", loader);
                 if(pkuyfcpj["original"].length == 0)
                 {
                   Invalid("button_id" + " is empty");
                   return;
                 }
var zwhjbosd = GetInputConstructorValue("zwhjbosd", loader);
                 if(zwhjbosd["original"].length == 0)
                 {
                   Invalid("coef" + " is empty");
                   return;
                 }
var baxfbpdj = GetInputConstructorValue("baxfbpdj", loader);
                 if(baxfbpdj["original"].length == 0)
                 {
                   Invalid("image id" + " is empty");
                   return;
                 }
var cohnvtxw = GetInputConstructorValue("cohnvtxw", loader);
                 if(cohnvtxw["original"].length == 0)
                 {
                   Invalid("key" + " is empty");
                   return;
                 }
var ewgtuzer = GetInputConstructorValue("ewgtuzer", loader);
                 if(ewgtuzer["original"].length == 0)
                 {
                   Invalid("pixel_koef" + " is empty");
                   return;
                 }
var qtemopys = GetInputConstructorValue("qtemopys", loader);
                 if(qtemopys["original"].length == 0)
                 {
                   Invalid("reload_id" + " is empty");
                   return;
                 }
var ubzxwhgk = GetInputConstructorValue("ubzxwhgk", loader);
                 if(ubzxwhgk["original"].length == 0)
                 {
                   Invalid("speed" + " is empty");
                   return;
                 }
var bzrooddp = GetInputConstructorValue("bzrooddp", loader);
                 if(bzrooddp["original"].length == 0)
                 {
                   Invalid("type_slide" + " is empty");
                   return;
                 }
var gwycmbby = GetInputConstructorValue("gwycmbby", loader);
                 if(gwycmbby["original"].length == 0)
                 {
                   Invalid("type_swipe" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SliderSolver_code").html())({"bzklebri": bzklebri["updated"],"dtsumtkh": dtsumtkh["updated"],"pkuyfcpj": pkuyfcpj["updated"],"zwhjbosd": zwhjbosd["updated"],"baxfbpdj": baxfbpdj["updated"],"cohnvtxw": cohnvtxw["updated"],"ewgtuzer": ewgtuzer["updated"],"qtemopys": qtemopys["updated"],"ubzxwhgk": ubzxwhgk["updated"],"bzrooddp": bzrooddp["updated"],"gwycmbby": gwycmbby["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
