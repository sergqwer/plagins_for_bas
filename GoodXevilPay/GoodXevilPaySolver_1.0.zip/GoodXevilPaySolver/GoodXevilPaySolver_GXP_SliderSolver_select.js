var xflfujkh = GetInputConstructorValue("xflfujkh", loader);
                 if(xflfujkh["original"].length == 0)
                 {
                   Invalid("arrow_id" + " is empty");
                   return;
                 }
var qhposvlb = GetInputConstructorValue("qhposvlb", loader);
                 if(qhposvlb["original"].length == 0)
                 {
                   Invalid("avtoupdate" + " is empty");
                   return;
                 }
var zhvgefns = GetInputConstructorValue("zhvgefns", loader);
                 if(zhvgefns["original"].length == 0)
                 {
                   Invalid("button_id" + " is empty");
                   return;
                 }
var akvsmanw = GetInputConstructorValue("akvsmanw", loader);
                 if(akvsmanw["original"].length == 0)
                 {
                   Invalid("coef" + " is empty");
                   return;
                 }
var pzlwnqxp = GetInputConstructorValue("pzlwnqxp", loader);
                 if(pzlwnqxp["original"].length == 0)
                 {
                   Invalid("image id" + " is empty");
                   return;
                 }
var bxriluzi = GetInputConstructorValue("bxriluzi", loader);
                 if(bxriluzi["original"].length == 0)
                 {
                   Invalid("key" + " is empty");
                   return;
                 }
var zotbshdu = GetInputConstructorValue("zotbshdu", loader);
                 if(zotbshdu["original"].length == 0)
                 {
                   Invalid("pixel_koef" + " is empty");
                   return;
                 }
var kstkmstm = GetInputConstructorValue("kstkmstm", loader);
                 if(kstkmstm["original"].length == 0)
                 {
                   Invalid("reload_id" + " is empty");
                   return;
                 }
var fjotlzqy = GetInputConstructorValue("fjotlzqy", loader);
                 if(fjotlzqy["original"].length == 0)
                 {
                   Invalid("speed" + " is empty");
                   return;
                 }
var bipqlybx = GetInputConstructorValue("bipqlybx", loader);
                 if(bipqlybx["original"].length == 0)
                 {
                   Invalid("type_slide" + " is empty");
                   return;
                 }
var pscwwqsh = GetInputConstructorValue("pscwwqsh", loader);
                 if(pscwwqsh["original"].length == 0)
                 {
                   Invalid("type_swipe" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SliderSolver_code").html())({"xflfujkh": xflfujkh["updated"],"qhposvlb": qhposvlb["updated"],"zhvgefns": zhvgefns["updated"],"akvsmanw": akvsmanw["updated"],"pzlwnqxp": pzlwnqxp["updated"],"bxriluzi": bxriluzi["updated"],"zotbshdu": zotbshdu["updated"],"kstkmstm": kstkmstm["updated"],"fjotlzqy": fjotlzqy["updated"],"bipqlybx": bipqlybx["updated"],"pscwwqsh": pscwwqsh["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
