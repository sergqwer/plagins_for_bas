var urhxsbnt = GetInputConstructorValue("urhxsbnt", loader);
                 if(urhxsbnt["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var wdxuldgu = GetInputConstructorValue("wdxuldgu", loader);
                 if(wdxuldgu["original"].length == 0)
                 {
                   Invalid("site_url" + " is empty");
                   return;
                 }
var rnlxrjzy = GetInputConstructorValue("rnlxrjzy", loader);
                 if(rnlxrjzy["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_HcaptchaTakeToken_code").html())({"urhxsbnt": urhxsbnt["updated"],"wdxuldgu": wdxuldgu["updated"],"rnlxrjzy": rnlxrjzy["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
