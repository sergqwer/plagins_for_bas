var pwpmvblm = GetInputConstructorValue("pwpmvblm", loader);
                 if(pwpmvblm["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var yanogghq = GetInputConstructorValue("yanogghq", loader);
                 if(yanogghq["original"].length == 0)
                 {
                   Invalid("site_url" + " is empty");
                   return;
                 }
var ydvxasji = GetInputConstructorValue("ydvxasji", loader);
                 if(ydvxasji["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_HcaptchaTakeToken_code").html())({"pwpmvblm": pwpmvblm["updated"],"yanogghq": yanogghq["updated"],"ydvxasji": ydvxasji["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
