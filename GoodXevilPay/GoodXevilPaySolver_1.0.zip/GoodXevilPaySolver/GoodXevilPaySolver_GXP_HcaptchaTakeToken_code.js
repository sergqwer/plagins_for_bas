_call_function(GoodXevilPaySolver_GXP_HcaptchaTakeToken,{ "APIKEY": (<%= urhxsbnt %>),"site_url": (<%= wdxuldgu %>),"sitekey": (<%= rnlxrjzy %>) })!
<%= variable %> = _result_function()
