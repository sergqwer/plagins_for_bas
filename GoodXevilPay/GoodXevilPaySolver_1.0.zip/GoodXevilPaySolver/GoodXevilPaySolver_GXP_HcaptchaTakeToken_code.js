_call_function(GoodXevilPaySolver_GXP_HcaptchaTakeToken,{ "APIKEY": (<%= nxhhiebz %>),"site_url": (<%= hlcmgtve %>),"sitekey": (<%= xmikpmuu %>) })!
<%= variable %> = _result_function()
