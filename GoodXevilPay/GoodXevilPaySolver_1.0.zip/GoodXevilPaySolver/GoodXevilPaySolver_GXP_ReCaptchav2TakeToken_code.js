_call_function(GoodXevilPaySolver_GXP_ReCaptchav2TakeToken,{ "APIKEY": (<%= cxgmevad %>),"site_url": (<%= uwtbvlmf %>),"sitekey": (<%= poedvnqp %>) })!
<%= variable %> = _result_function()
