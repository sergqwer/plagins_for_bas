_call_function(GoodXevilPaySolver_GXP_ReCaptchav2TakeToken,{ "APIKEY": (<%= hagideil %>),"site_url": (<%= ofvrrcfu %>),"sitekey": (<%= lzxjinrc %>) })!
<%= variable %> = _result_function()
