_call_function(GoodXevilPaySolver_GXP_ReCaptchav2TakeToken,{ "APIKEY": (<%= tvallmpy %>),"site_url": (<%= ctagvcke %>),"sitekey": (<%= fgwkcfmn %>) })!
<%= variable %> = _result_function()
