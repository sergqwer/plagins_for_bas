var ifrefybx = GetInputConstructorValue("ifrefybx", loader);
                 if(ifrefybx["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var qijglory = GetInputConstructorValue("qijglory", loader);
                 if(qijglory["original"].length == 0)
                 {
                   Invalid("site_url" + " is empty");
                   return;
                 }
var kiqhcfaw = GetInputConstructorValue("kiqhcfaw", loader);
                 if(kiqhcfaw["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_HcaptchaTakeToken_code").html())({"ifrefybx": ifrefybx["updated"],"qijglory": qijglory["updated"],"kiqhcfaw": kiqhcfaw["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
