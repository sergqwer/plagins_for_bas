var fdpzpyhh = GetInputConstructorValue("fdpzpyhh", loader);
                 if(fdpzpyhh["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var qxqgrfwo = GetInputConstructorValue("qxqgrfwo", loader);
                 if(qxqgrfwo["original"].length == 0)
                 {
                   Invalid("timer" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_BuxMoney_PayupVideo_code").html())({"fdpzpyhh": fdpzpyhh["updated"],"qxqgrfwo": qxqgrfwo["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
