_call_function(GoodXevilPaySolver_GXP_HcaptchaTakeToken,{ "APIKEY": (<%= ifrefybx %>),"site_url": (<%= qijglory %>),"sitekey": (<%= kiqhcfaw %>) })!
<%= variable %> = _result_function()
