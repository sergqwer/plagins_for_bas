_call_function(GoodXevilPaySolver_GXP_IMAGE_BASE64,{ "APIKEY": (<%= gcpyvvnb %>),"IMAGE_BASE64": (<%= ztswimxq %>) })!
<%= variable %> = _result_function()
