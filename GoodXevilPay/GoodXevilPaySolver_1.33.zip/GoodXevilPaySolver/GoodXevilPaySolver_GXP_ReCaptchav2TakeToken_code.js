_call_function(GoodXevilPaySolver_GXP_ReCaptchav2TakeToken,{ "APIKEY": (<%= fbayjxjp %>),"site_url": (<%= toewogrw %>),"sitekey": (<%= gisidxnk %>) })!
<%= variable %> = _result_function()
