var npieyuul = GetInputConstructorValue("npieyuul", loader);
                 if(npieyuul["original"].length == 0)
                 {
                   Invalid("arrow_id" + " is empty");
                   return;
                 }
var zusnlirp = GetInputConstructorValue("zusnlirp", loader);
                 if(zusnlirp["original"].length == 0)
                 {
                   Invalid("avtoupdate" + " is empty");
                   return;
                 }
var zaddbuma = GetInputConstructorValue("zaddbuma", loader);
                 if(zaddbuma["original"].length == 0)
                 {
                   Invalid("button_id" + " is empty");
                   return;
                 }
var yszwzdml = GetInputConstructorValue("yszwzdml", loader);
                 if(yszwzdml["original"].length == 0)
                 {
                   Invalid("coef" + " is empty");
                   return;
                 }
var dpinixlb = GetInputConstructorValue("dpinixlb", loader);
                 if(dpinixlb["original"].length == 0)
                 {
                   Invalid("image id" + " is empty");
                   return;
                 }
var gchhbvqe = GetInputConstructorValue("gchhbvqe", loader);
                 if(gchhbvqe["original"].length == 0)
                 {
                   Invalid("key" + " is empty");
                   return;
                 }
var uvakhgjf = GetInputConstructorValue("uvakhgjf", loader);
                 if(uvakhgjf["original"].length == 0)
                 {
                   Invalid("pixel_koef" + " is empty");
                   return;
                 }
var dkrofrll = GetInputConstructorValue("dkrofrll", loader);
                 if(dkrofrll["original"].length == 0)
                 {
                   Invalid("reload_id" + " is empty");
                   return;
                 }
var nrlycwpe = GetInputConstructorValue("nrlycwpe", loader);
                 if(nrlycwpe["original"].length == 0)
                 {
                   Invalid("speed" + " is empty");
                   return;
                 }
var gdymnwej = GetInputConstructorValue("gdymnwej", loader);
                 if(gdymnwej["original"].length == 0)
                 {
                   Invalid("type_slide" + " is empty");
                   return;
                 }
var moczwres = GetInputConstructorValue("moczwres", loader);
                 if(moczwres["original"].length == 0)
                 {
                   Invalid("type_swipe" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SliderSolver_code").html())({"npieyuul": npieyuul["updated"],"zusnlirp": zusnlirp["updated"],"zaddbuma": zaddbuma["updated"],"yszwzdml": yszwzdml["updated"],"dpinixlb": dpinixlb["updated"],"gchhbvqe": gchhbvqe["updated"],"uvakhgjf": uvakhgjf["updated"],"dkrofrll": dkrofrll["updated"],"nrlycwpe": nrlycwpe["updated"],"gdymnwej": gdymnwej["updated"],"moczwres": moczwres["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
