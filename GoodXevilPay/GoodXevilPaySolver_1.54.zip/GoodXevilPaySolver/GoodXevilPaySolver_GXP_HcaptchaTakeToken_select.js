var bpfuvzeh = GetInputConstructorValue("bpfuvzeh", loader);
                 if(bpfuvzeh["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var dmhjtcky = GetInputConstructorValue("dmhjtcky", loader);
                 if(dmhjtcky["original"].length == 0)
                 {
                   Invalid("site_url" + " is empty");
                   return;
                 }
var jcoorhlh = GetInputConstructorValue("jcoorhlh", loader);
                 if(jcoorhlh["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_HcaptchaTakeToken_code").html())({"bpfuvzeh": bpfuvzeh["updated"],"dmhjtcky": dmhjtcky["updated"],"jcoorhlh": jcoorhlh["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
