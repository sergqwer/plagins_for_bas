_call_function(GoodXevilPaySolver_GXP_BasiliskCaptcha,{ "apikey": (<%= nwrizfid %>),"sitekey": (<%= kgbzkpbk %>),"siteurl": (<%= ipeinrzx %>) })!
