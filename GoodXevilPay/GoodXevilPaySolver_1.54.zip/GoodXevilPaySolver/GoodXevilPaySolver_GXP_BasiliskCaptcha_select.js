var nwrizfid = GetInputConstructorValue("nwrizfid", loader);
                 if(nwrizfid["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var kgbzkpbk = GetInputConstructorValue("kgbzkpbk", loader);
                 if(kgbzkpbk["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var ipeinrzx = GetInputConstructorValue("ipeinrzx", loader);
                 if(ipeinrzx["original"].length == 0)
                 {
                   Invalid("siteurl" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_BasiliskCaptcha_code").html())({"nwrizfid": nwrizfid["updated"],"kgbzkpbk": kgbzkpbk["updated"],"ipeinrzx": ipeinrzx["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
