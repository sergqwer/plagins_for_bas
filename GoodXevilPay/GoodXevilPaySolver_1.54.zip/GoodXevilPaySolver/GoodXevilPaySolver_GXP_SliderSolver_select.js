var pbvlkdxq = GetInputConstructorValue("pbvlkdxq", loader);
                 if(pbvlkdxq["original"].length == 0)
                 {
                   Invalid("arrow_id" + " is empty");
                   return;
                 }
var rwkrfqlo = GetInputConstructorValue("rwkrfqlo", loader);
                 if(rwkrfqlo["original"].length == 0)
                 {
                   Invalid("avtoupdate" + " is empty");
                   return;
                 }
var lwmhnssh = GetInputConstructorValue("lwmhnssh", loader);
                 if(lwmhnssh["original"].length == 0)
                 {
                   Invalid("button_id" + " is empty");
                   return;
                 }
var svzxfpom = GetInputConstructorValue("svzxfpom", loader);
                 if(svzxfpom["original"].length == 0)
                 {
                   Invalid("coef" + " is empty");
                   return;
                 }
var snpqbnfh = GetInputConstructorValue("snpqbnfh", loader);
                 if(snpqbnfh["original"].length == 0)
                 {
                   Invalid("image id" + " is empty");
                   return;
                 }
var rjhpxhjr = GetInputConstructorValue("rjhpxhjr", loader);
                 if(rjhpxhjr["original"].length == 0)
                 {
                   Invalid("key" + " is empty");
                   return;
                 }
var hbudqgjg = GetInputConstructorValue("hbudqgjg", loader);
                 if(hbudqgjg["original"].length == 0)
                 {
                   Invalid("pixel_koef" + " is empty");
                   return;
                 }
var pwbblxrr = GetInputConstructorValue("pwbblxrr", loader);
                 if(pwbblxrr["original"].length == 0)
                 {
                   Invalid("reload_id" + " is empty");
                   return;
                 }
var hpqgzwof = GetInputConstructorValue("hpqgzwof", loader);
                 if(hpqgzwof["original"].length == 0)
                 {
                   Invalid("speed" + " is empty");
                   return;
                 }
var trutozqh = GetInputConstructorValue("trutozqh", loader);
                 if(trutozqh["original"].length == 0)
                 {
                   Invalid("type_slide" + " is empty");
                   return;
                 }
var rntbupfi = GetInputConstructorValue("rntbupfi", loader);
                 if(rntbupfi["original"].length == 0)
                 {
                   Invalid("type_swipe" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SliderSolver_code").html())({"pbvlkdxq": pbvlkdxq["updated"],"rwkrfqlo": rwkrfqlo["updated"],"lwmhnssh": lwmhnssh["updated"],"svzxfpom": svzxfpom["updated"],"snpqbnfh": snpqbnfh["updated"],"rjhpxhjr": rjhpxhjr["updated"],"hbudqgjg": hbudqgjg["updated"],"pwbblxrr": pwbblxrr["updated"],"hpqgzwof": hpqgzwof["updated"],"trutozqh": trutozqh["updated"],"rntbupfi": rntbupfi["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
