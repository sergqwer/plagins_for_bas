_call_function(GoodXevilPaySolver_GXP_AutoBypassCloudFlare,{ "custom_button": (<%= nqaovjsp %>),"max_time": (<%= ukiozbgz %>),"whait_element": (<%= xvkrdsiu %>) })!
