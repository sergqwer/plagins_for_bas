var rtwigfho = GetInputConstructorValue("rtwigfho", loader);
                 if(rtwigfho["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var hobajprn = GetInputConstructorValue("hobajprn", loader);
                 if(hobajprn["original"].length == 0)
                 {
                   Invalid("site_url" + " is empty");
                   return;
                 }
var merrllho = GetInputConstructorValue("merrllho", loader);
                 if(merrllho["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_ReCaptchav2TakeToken_code").html())({"rtwigfho": rtwigfho["updated"],"hobajprn": hobajprn["updated"],"merrllho": merrllho["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
