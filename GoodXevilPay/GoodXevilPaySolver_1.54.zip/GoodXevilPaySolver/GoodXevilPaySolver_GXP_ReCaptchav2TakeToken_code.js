_call_function(GoodXevilPaySolver_GXP_ReCaptchav2TakeToken,{ "APIKEY": (<%= rtwigfho %>),"site_url": (<%= hobajprn %>),"sitekey": (<%= merrllho %>) })!
<%= variable %> = _result_function()
