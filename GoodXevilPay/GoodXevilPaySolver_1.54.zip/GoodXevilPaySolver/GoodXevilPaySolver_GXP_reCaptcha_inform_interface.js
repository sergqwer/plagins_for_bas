<div class="container-fluid">
<%= _.template($('#variable_constructor').html())({id:"Save", description:"Result", default_variable: "RECAPTCHA_DATA", help: {description: "Данные с recaptcha на странице"}}) %>
</div>
<div class="tooltipinternal">
<div class="tr tooltip-paragraph-first-fold">Получает данные о всех найденых reCaptcha на странице </div>
</div>
<%= _.template($('#back').html())({action:"executeandadd", visible:true}) %>
