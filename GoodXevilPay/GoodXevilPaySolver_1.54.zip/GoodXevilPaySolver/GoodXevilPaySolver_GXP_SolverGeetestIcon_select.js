var eakmwgyp = GetInputConstructorValue("eakmwgyp", loader);
                 if(eakmwgyp["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var hwexkodw = GetInputConstructorValue("hwexkodw", loader);
                 if(hwexkodw["original"].length == 0)
                 {
                   Invalid("captcha_submit" + " is empty");
                   return;
                 }
var axyfrbvf = GetInputConstructorValue("axyfrbvf", loader);
                 if(axyfrbvf["original"].length == 0)
                 {
                   Invalid("foto_captcha" + " is empty");
                   return;
                 }
var abvlkmqf = GetInputConstructorValue("abvlkmqf", loader);
                 if(abvlkmqf["original"].length == 0)
                 {
                   Invalid("pixel_coef" + " is empty");
                   return;
                 }
var sljcilbi = GetInputConstructorValue("sljcilbi", loader);
                 if(sljcilbi["original"].length == 0)
                 {
                   Invalid("reload_captcha" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SolverGeetestIcon_code").html())({"eakmwgyp": eakmwgyp["updated"],"hwexkodw": hwexkodw["updated"],"axyfrbvf": axyfrbvf["updated"],"abvlkmqf": abvlkmqf["updated"],"sljcilbi": sljcilbi["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
