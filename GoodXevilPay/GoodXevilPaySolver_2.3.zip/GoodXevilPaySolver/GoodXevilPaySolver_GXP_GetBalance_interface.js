<div class="container-fluid">
<%= _.template($('#input_constructor').html())({id:"jfvgcuwb", description:"Solve Service", default_selector: "string", variants: ["SCTG", "Multibot"], disable_expression:true, disable_int:true, value_string: "SCTG", help: {description: "<div>Выберите нужный вам сервис для решения капчи</div><div>Choose the service you need to solve captcha</div>"} }) %>
<%= _.template($('#input_constructor').html())({id:"buvrrgrs", description:"ApiKey", default_selector: "string", disable_int:true, value_string: "", help: {description: "<div>apikey с сервиса https://t.me/Xevil_check_bot или https://multibot.in/</div><div>apikey from https://t.me/Xevil_check_bot or https://multibot.in/</div>"} }) %>
<%= _.template($('#variable_constructor').html())({id:"Save", description:"Result", default_variable: "BALANCE_RESULT", help: {description: "Баланс аккаунта"}}) %>
</div>
<div class="tooltipinternal">
<div class="tr tooltip-paragraph-first-fold">Эта функция получает баланс ключа с сервиса https://t.me/Xevil_check_bot или https://multibot.in/</div>
<div class="tr tooltip-paragraph-last-fold">This function retrieves the key balance from the service https://t.me/Xevil_check_bot or https://multibot.in/</div>
</div>
<%= _.template($('#back').html())({action:"executeandadd", visible:true}) %>
