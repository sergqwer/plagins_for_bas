var skyusaai = GetInputConstructorValue("skyusaai", loader);
                 if(skyusaai["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var hserbyqw = GetInputConstructorValue("hserbyqw", loader);
                 if(hserbyqw["original"].length == 0)
                 {
                   Invalid("Service_Solver" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_IconCaptchaSolver_code").html())({"skyusaai": skyusaai["updated"],"hserbyqw": hserbyqw["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
