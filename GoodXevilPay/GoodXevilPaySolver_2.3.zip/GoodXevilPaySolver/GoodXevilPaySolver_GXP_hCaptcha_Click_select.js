var zrmropmn = GetInputConstructorValue("zrmropmn", loader);
                 if(zrmropmn["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var mwdlyjmm = GetInputConstructorValue("mwdlyjmm", loader);
                 if(mwdlyjmm["original"].length == 0)
                 {
                   Invalid("CaptchaSelector" + " is empty");
                   return;
                 }
var csoiwgab = GetInputConstructorValue("csoiwgab", loader);
                 if(csoiwgab["original"].length == 0)
                 {
                   Invalid("Service_Solver" + " is empty");
                   return;
                 }
var avmrmhvb = GetInputConstructorValue("avmrmhvb", loader);
                 if(avmrmhvb["original"].length == 0)
                 {
                   Invalid("TrySolve" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_hCaptcha_Click_code").html())({"zrmropmn": zrmropmn["updated"],"mwdlyjmm": mwdlyjmm["updated"],"csoiwgab": csoiwgab["updated"],"avmrmhvb": avmrmhvb["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
