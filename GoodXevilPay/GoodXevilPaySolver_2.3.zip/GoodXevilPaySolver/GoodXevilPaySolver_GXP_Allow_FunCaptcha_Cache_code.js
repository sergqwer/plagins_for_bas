_call_function(GoodXevilPaySolver_GXP_Allow_FunCaptcha_Cache,{  })!
