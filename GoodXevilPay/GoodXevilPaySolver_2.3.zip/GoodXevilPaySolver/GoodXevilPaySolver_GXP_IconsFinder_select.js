var pjvtitzf = GetInputConstructorValue("pjvtitzf", loader);
                 if(pjvtitzf["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var omxawyio = GetInputConstructorValue("omxawyio", loader);
                 if(omxawyio["original"].length == 0)
                 {
                   Invalid("iconselement" + " is empty");
                   return;
                 }
var xwhmsgde = GetInputConstructorValue("xwhmsgde", loader);
                 if(xwhmsgde["original"].length == 0)
                 {
                   Invalid("Service_Solver" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_IconsFinder_code").html())({"pjvtitzf": pjvtitzf["updated"],"omxawyio": omxawyio["updated"],"xwhmsgde": xwhmsgde["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
