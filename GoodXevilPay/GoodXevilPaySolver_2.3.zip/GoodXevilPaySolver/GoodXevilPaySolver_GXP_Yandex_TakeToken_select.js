var kjunlokl = GetInputConstructorValue("kjunlokl", loader);
                 if(kjunlokl["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var mlgqqpjm = GetInputConstructorValue("mlgqqpjm", loader);
                 if(mlgqqpjm["original"].length == 0)
                 {
                   Invalid("pageurl" + " is empty");
                   return;
                 }
var ulynmyzo = GetInputConstructorValue("ulynmyzo", loader);
                 if(ulynmyzo["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_Yandex_TakeToken_code").html())({"kjunlokl": kjunlokl["updated"],"mlgqqpjm": mlgqqpjm["updated"],"ulynmyzo": ulynmyzo["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
