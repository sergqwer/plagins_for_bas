_call_function(GoodXevilPaySolver_GXP_TAOBAO_CAP,{ "FRAME_PATH": (<%= bzbrhlyh %>),"SCTG_APIKEY": (<%= vbimkmvl %>) })!
