_call_function(GoodXevilPaySolver_GXP_IMAGE_BASE64,{ "APIKEY": (<%= qjmbbvbt %>),"IMAGE_BASE64": (<%= ylnivjsz %>),"Service_Solver": (<%= pvtlnchd %>) })!
<%= variable %> = _result_function()
