var ppwvkztp = GetInputConstructorValue("ppwvkztp", loader);
                 if(ppwvkztp["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var pnbxhoyg = GetInputConstructorValue("pnbxhoyg", loader);
                 if(pnbxhoyg["original"].length == 0)
                 {
                   Invalid("Service_Solver" + " is empty");
                   return;
                 }
var rcyhfjxn = GetInputConstructorValue("rcyhfjxn", loader);
                 if(rcyhfjxn["original"].length == 0)
                 {
                   Invalid("site_url" + " is empty");
                   return;
                 }
var fmpctygk = GetInputConstructorValue("fmpctygk", loader);
                 if(fmpctygk["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_HcaptchaTakeToken_code").html())({"ppwvkztp": ppwvkztp["updated"],"pnbxhoyg": pnbxhoyg["updated"],"rcyhfjxn": rcyhfjxn["updated"],"fmpctygk": fmpctygk["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
