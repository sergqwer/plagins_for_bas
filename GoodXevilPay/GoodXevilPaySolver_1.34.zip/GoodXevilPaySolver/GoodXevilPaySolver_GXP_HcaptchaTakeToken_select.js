var zsvagyev = GetInputConstructorValue("zsvagyev", loader);
                 if(zsvagyev["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var qyjaqlph = GetInputConstructorValue("qyjaqlph", loader);
                 if(qyjaqlph["original"].length == 0)
                 {
                   Invalid("site_url" + " is empty");
                   return;
                 }
var vdwzgylu = GetInputConstructorValue("vdwzgylu", loader);
                 if(vdwzgylu["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_HcaptchaTakeToken_code").html())({"zsvagyev": zsvagyev["updated"],"qyjaqlph": qyjaqlph["updated"],"vdwzgylu": vdwzgylu["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
