var cpyockqj = GetInputConstructorValue("cpyockqj", loader);
                 if(cpyockqj["original"].length == 0)
                 {
                   Invalid("arrow_id" + " is empty");
                   return;
                 }
var qolmasaz = GetInputConstructorValue("qolmasaz", loader);
                 if(qolmasaz["original"].length == 0)
                 {
                   Invalid("avtoupdate" + " is empty");
                   return;
                 }
var sqdpqoiz = GetInputConstructorValue("sqdpqoiz", loader);
                 if(sqdpqoiz["original"].length == 0)
                 {
                   Invalid("button_id" + " is empty");
                   return;
                 }
var ypzrrcmx = GetInputConstructorValue("ypzrrcmx", loader);
                 if(ypzrrcmx["original"].length == 0)
                 {
                   Invalid("coef" + " is empty");
                   return;
                 }
var llgpgjmu = GetInputConstructorValue("llgpgjmu", loader);
                 if(llgpgjmu["original"].length == 0)
                 {
                   Invalid("image id" + " is empty");
                   return;
                 }
var nxqgpyqk = GetInputConstructorValue("nxqgpyqk", loader);
                 if(nxqgpyqk["original"].length == 0)
                 {
                   Invalid("key" + " is empty");
                   return;
                 }
var kvvbjgsc = GetInputConstructorValue("kvvbjgsc", loader);
                 if(kvvbjgsc["original"].length == 0)
                 {
                   Invalid("pixel_koef" + " is empty");
                   return;
                 }
var trtlxhip = GetInputConstructorValue("trtlxhip", loader);
                 if(trtlxhip["original"].length == 0)
                 {
                   Invalid("reload_id" + " is empty");
                   return;
                 }
var shpczccf = GetInputConstructorValue("shpczccf", loader);
                 if(shpczccf["original"].length == 0)
                 {
                   Invalid("speed" + " is empty");
                   return;
                 }
var hrlbmrtz = GetInputConstructorValue("hrlbmrtz", loader);
                 if(hrlbmrtz["original"].length == 0)
                 {
                   Invalid("type_slide" + " is empty");
                   return;
                 }
var indvtbks = GetInputConstructorValue("indvtbks", loader);
                 if(indvtbks["original"].length == 0)
                 {
                   Invalid("type_swipe" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SliderSolver_code").html())({"cpyockqj": cpyockqj["updated"],"qolmasaz": qolmasaz["updated"],"sqdpqoiz": sqdpqoiz["updated"],"ypzrrcmx": ypzrrcmx["updated"],"llgpgjmu": llgpgjmu["updated"],"nxqgpyqk": nxqgpyqk["updated"],"kvvbjgsc": kvvbjgsc["updated"],"trtlxhip": trtlxhip["updated"],"shpczccf": shpczccf["updated"],"hrlbmrtz": hrlbmrtz["updated"],"indvtbks": indvtbks["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
