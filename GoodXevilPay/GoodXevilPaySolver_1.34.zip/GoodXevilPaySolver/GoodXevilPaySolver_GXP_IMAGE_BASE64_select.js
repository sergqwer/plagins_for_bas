var lcydgngz = GetInputConstructorValue("lcydgngz", loader);
                 if(lcydgngz["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var kfuvivgm = GetInputConstructorValue("kfuvivgm", loader);
                 if(kfuvivgm["original"].length == 0)
                 {
                   Invalid("IMAGE_BASE64" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_IMAGE_BASE64_code").html())({"lcydgngz": lcydgngz["updated"],"kfuvivgm": kfuvivgm["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
