_call_function(GoodXevilPaySolver_GXP_HcaptchaTakeToken,{ "APIKEY": (<%= zsvagyev %>),"site_url": (<%= qyjaqlph %>),"sitekey": (<%= vdwzgylu %>) })!
<%= variable %> = _result_function()
