var tgarvehe = GetInputConstructorValue("tgarvehe", loader);
                 if(tgarvehe["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var jojinguh = GetInputConstructorValue("jojinguh", loader);
                 if(jojinguh["original"].length == 0)
                 {
                   Invalid("site_url" + " is empty");
                   return;
                 }
var boinmhgw = GetInputConstructorValue("boinmhgw", loader);
                 if(boinmhgw["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_ReCaptchav2TakeToken_code").html())({"tgarvehe": tgarvehe["updated"],"jojinguh": jojinguh["updated"],"boinmhgw": boinmhgw["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
