_call_function(GoodXevilPaySolver_GXP_ReCaptchav2TakeToken,{ "APIKEY": (<%= tgarvehe %>),"site_url": (<%= jojinguh %>),"sitekey": (<%= boinmhgw %>) })!
<%= variable %> = _result_function()
