var bakzpqcl = GetInputConstructorValue("bakzpqcl", loader);
                 if(bakzpqcl["original"].length == 0)
                 {
                   Invalid("main_frame_checkbox" + " is empty");
                   return;
                 }
var yenznuan = GetInputConstructorValue("yenznuan", loader);
                 if(yenznuan["original"].length == 0)
                 {
                   Invalid("main_frame_solver" + " is empty");
                   return;
                 }
var mgqpncql = GetInputConstructorValue("mgqpncql", loader);
                 if(mgqpncql["original"].length == 0)
                 {
                   Invalid("servisename" + " is empty");
                   return;
                 }
var eveevkaq = GetInputConstructorValue("eveevkaq", loader);
                 if(eveevkaq["original"].length == 0)
                 {
                   Invalid("speed" + " is empty");
                   return;
                 }
var bzmopzmn = GetInputConstructorValue("bzmopzmn", loader);
                 if(bzmopzmn["original"].length == 0)
                 {
                   Invalid("try_solved" + " is empty");
                   return;
                 }
var argiiqzm = GetInputConstructorValue("argiiqzm", loader);
                 if(argiiqzm["original"].length == 0)
                 {
                   Invalid("userapikey" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#hCaptchaClick_hcaptcha_solver_code").html())({"bakzpqcl": bakzpqcl["updated"],"yenznuan": yenznuan["updated"],"mgqpncql": mgqpncql["updated"],"eveevkaq": eveevkaq["updated"],"bzmopzmn": bzmopzmn["updated"],"argiiqzm": argiiqzm["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
