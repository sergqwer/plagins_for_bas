var yzmnpntx = GetInputConstructorValue("yzmnpntx", loader);
                 if(yzmnpntx["original"].length == 0)
                 {
                   Invalid("arrow_id" + " is empty");
                   return;
                 }
var bcbozdtg = GetInputConstructorValue("bcbozdtg", loader);
                 if(bcbozdtg["original"].length == 0)
                 {
                   Invalid("avtoupdate" + " is empty");
                   return;
                 }
var duqyjvet = GetInputConstructorValue("duqyjvet", loader);
                 if(duqyjvet["original"].length == 0)
                 {
                   Invalid("button_id" + " is empty");
                   return;
                 }
var qapiitlm = GetInputConstructorValue("qapiitlm", loader);
                 if(qapiitlm["original"].length == 0)
                 {
                   Invalid("coef" + " is empty");
                   return;
                 }
var spripqzc = GetInputConstructorValue("spripqzc", loader);
                 if(spripqzc["original"].length == 0)
                 {
                   Invalid("image id" + " is empty");
                   return;
                 }
var kkuqjrnr = GetInputConstructorValue("kkuqjrnr", loader);
                 if(kkuqjrnr["original"].length == 0)
                 {
                   Invalid("key" + " is empty");
                   return;
                 }
var rnrymznt = GetInputConstructorValue("rnrymznt", loader);
                 if(rnrymznt["original"].length == 0)
                 {
                   Invalid("pixel_koef" + " is empty");
                   return;
                 }
var kxsjzndn = GetInputConstructorValue("kxsjzndn", loader);
                 if(kxsjzndn["original"].length == 0)
                 {
                   Invalid("reload_id" + " is empty");
                   return;
                 }
var jsodcwgg = GetInputConstructorValue("jsodcwgg", loader);
                 if(jsodcwgg["original"].length == 0)
                 {
                   Invalid("speed" + " is empty");
                   return;
                 }
var eytbgtpa = GetInputConstructorValue("eytbgtpa", loader);
                 if(eytbgtpa["original"].length == 0)
                 {
                   Invalid("type_slide" + " is empty");
                   return;
                 }
var nnisthnc = GetInputConstructorValue("nnisthnc", loader);
                 if(nnisthnc["original"].length == 0)
                 {
                   Invalid("type_swipe" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#OLD_GoodXevilPaySolver_GXP_SliderSolver_code").html())({"yzmnpntx": yzmnpntx["updated"],"bcbozdtg": bcbozdtg["updated"],"duqyjvet": duqyjvet["updated"],"qapiitlm": qapiitlm["updated"],"spripqzc": spripqzc["updated"],"kkuqjrnr": kkuqjrnr["updated"],"rnrymznt": rnrymznt["updated"],"kxsjzndn": kxsjzndn["updated"],"jsodcwgg": jsodcwgg["updated"],"eytbgtpa": eytbgtpa["updated"],"nnisthnc": nnisthnc["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
