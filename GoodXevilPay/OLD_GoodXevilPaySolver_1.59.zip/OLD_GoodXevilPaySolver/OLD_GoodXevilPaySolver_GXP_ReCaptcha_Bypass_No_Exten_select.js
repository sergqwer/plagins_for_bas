var fvjacczi = GetInputConstructorValue("fvjacczi", loader);
                 if(fvjacczi["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var gqwvctze = GetInputConstructorValue("gqwvctze", loader);
                 if(gqwvctze["original"].length == 0)
                 {
                   Invalid("index" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#OLD_GoodXevilPaySolver_GXP_ReCaptcha_Bypass_No_Exten_code").html())({"fvjacczi": fvjacczi["updated"],"gqwvctze": gqwvctze["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
