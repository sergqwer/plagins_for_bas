var lolseyfb = GetInputConstructorValue("lolseyfb", loader);
                 if(lolseyfb["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var gcddpczb = GetInputConstructorValue("gcddpczb", loader);
                 if(gcddpczb["original"].length == 0)
                 {
                   Invalid("mouse" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#OLD_GoodXevilPaySolver_GXP_Antibot_code").html())({"lolseyfb": lolseyfb["updated"],"gcddpczb": gcddpczb["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
