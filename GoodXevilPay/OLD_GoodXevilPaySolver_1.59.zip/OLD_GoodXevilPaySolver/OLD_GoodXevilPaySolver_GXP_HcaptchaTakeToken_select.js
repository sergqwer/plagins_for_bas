var vgqpfjbk = GetInputConstructorValue("vgqpfjbk", loader);
                 if(vgqpfjbk["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var xlsofmck = GetInputConstructorValue("xlsofmck", loader);
                 if(xlsofmck["original"].length == 0)
                 {
                   Invalid("site_url" + " is empty");
                   return;
                 }
var oluopgvc = GetInputConstructorValue("oluopgvc", loader);
                 if(oluopgvc["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#OLD_GoodXevilPaySolver_GXP_HcaptchaTakeToken_code").html())({"vgqpfjbk": vgqpfjbk["updated"],"xlsofmck": xlsofmck["updated"],"oluopgvc": oluopgvc["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
