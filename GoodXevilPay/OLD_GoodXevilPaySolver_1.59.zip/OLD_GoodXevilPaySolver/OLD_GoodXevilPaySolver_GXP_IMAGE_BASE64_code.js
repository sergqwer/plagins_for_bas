_call_function(OLD_GoodXevilPaySolver_GXP_IMAGE_BASE64,{ "APIKEY": (<%= qmmceile %>),"IMAGE_BASE64": (<%= brvyohob %>) })!
<%= variable %> = _result_function()
