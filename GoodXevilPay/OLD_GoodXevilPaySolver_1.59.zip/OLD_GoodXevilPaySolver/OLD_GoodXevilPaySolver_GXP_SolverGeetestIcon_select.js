var umkpooku = GetInputConstructorValue("umkpooku", loader);
                 if(umkpooku["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var kryksfbd = GetInputConstructorValue("kryksfbd", loader);
                 if(kryksfbd["original"].length == 0)
                 {
                   Invalid("captcha_submit" + " is empty");
                   return;
                 }
var eqbkxgnn = GetInputConstructorValue("eqbkxgnn", loader);
                 if(eqbkxgnn["original"].length == 0)
                 {
                   Invalid("foto_captcha" + " is empty");
                   return;
                 }
var sqtmsspt = GetInputConstructorValue("sqtmsspt", loader);
                 if(sqtmsspt["original"].length == 0)
                 {
                   Invalid("pixel_coef" + " is empty");
                   return;
                 }
var pbpffabe = GetInputConstructorValue("pbpffabe", loader);
                 if(pbpffabe["original"].length == 0)
                 {
                   Invalid("reload_captcha" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#OLD_GoodXevilPaySolver_GXP_SolverGeetestIcon_code").html())({"umkpooku": umkpooku["updated"],"kryksfbd": kryksfbd["updated"],"eqbkxgnn": eqbkxgnn["updated"],"sqtmsspt": sqtmsspt["updated"],"pbpffabe": pbpffabe["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
