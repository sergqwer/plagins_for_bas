var wseityri = GetInputConstructorValue("wseityri", loader);
                 if(wseityri["original"].length == 0)
                 {
                   Invalid("custom_button" + " is empty");
                   return;
                 }
var kqrajzlc = GetInputConstructorValue("kqrajzlc", loader);
                 if(kqrajzlc["original"].length == 0)
                 {
                   Invalid("max_time" + " is empty");
                   return;
                 }
var hfbshdxq = GetInputConstructorValue("hfbshdxq", loader);
                 if(hfbshdxq["original"].length == 0)
                 {
                   Invalid("whait_element" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#OLD_GoodXevilPaySolver_GXP_AutoBypassCloudFlare_code").html())({"wseityri": wseityri["updated"],"kqrajzlc": kqrajzlc["updated"],"hfbshdxq": hfbshdxq["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
