<div class="container-fluid">
<%= _.template($('#input_constructor').html())({id:"umkpooku", description:"apikey", default_selector: "string", disable_int:true, value_string: "", help: {description: "Ваш api ключ с сервиса https://t.me/Xevil_check_bot\n\nYour api key from https://t.me/Xevil_check_bot"} }) %>
<%= _.template($('#input_constructor').html())({id:"kryksfbd", description:"captcha_submit", default_selector: "string", disable_int:true, value_string: ">XPATH> //div[@class='geetest_fullpage_click_box']//a[@class='geetest_commit']", help: {description: "Идентификатор кнопки, подтвердить решение\n\nButton ID, confirm decision"} }) %>
<%= _.template($('#input_constructor').html())({id:"eqbkxgnn", description:"foto_captcha", default_selector: "string", disable_int:true, value_string: " >XPATH> //div[@class='geetest_fullpage_click_box']", help: {description: "Идентификатор фото капчи\n\nCaptcha photo identifier"} }) %>
<%= _.template($('#input_constructor').html())({id:"sqtmsspt", description:"pixel_coef", default_selector: "int", disable_string:true, value_number: 0, min_number:-999999, max_number:999999, help: {description: "Число пикселей для коректировки результата\n\nNumber of pixels to adjust the result"} }) %>
<%= _.template($('#input_constructor').html())({id:"pbpffabe", description:"reload_captcha", default_selector: "string", disable_int:true, value_string: ">XPATH> //div[@class='geetest_fullpage_click_box']//a[@class='geetest_refresh']", help: {description: "Идентификатор кнопки, обновление капчи\n\nButton ID, captcha update"} }) %>
</div>
<div class="tooltipinternal">
<div class="tr tooltip-paragraph-first-fold">Автоматически решает Geetest Icon на странице</div>
<div class="tr tooltip-paragraph-last-fold">Automatically resolves the Geetest Icon on the page</div>
</div>
<%= _.template($('#back').html())({action:"executeandadd", visible:true}) %>
