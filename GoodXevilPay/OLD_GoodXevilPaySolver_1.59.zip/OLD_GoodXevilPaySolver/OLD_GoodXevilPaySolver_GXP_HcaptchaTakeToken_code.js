_call_function(OLD_GoodXevilPaySolver_GXP_HcaptchaTakeToken,{ "APIKEY": (<%= vgqpfjbk %>),"site_url": (<%= xlsofmck %>),"sitekey": (<%= oluopgvc %>) })!
<%= variable %> = _result_function()
