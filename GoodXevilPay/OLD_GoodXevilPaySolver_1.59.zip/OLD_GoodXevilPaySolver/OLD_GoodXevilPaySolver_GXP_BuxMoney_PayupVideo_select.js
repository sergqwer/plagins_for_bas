var vtlrwheg = GetInputConstructorValue("vtlrwheg", loader);
                 if(vtlrwheg["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var umqmkodb = GetInputConstructorValue("umqmkodb", loader);
                 if(umqmkodb["original"].length == 0)
                 {
                   Invalid("timer" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#OLD_GoodXevilPaySolver_GXP_BuxMoney_PayupVideo_code").html())({"vtlrwheg": vtlrwheg["updated"],"umqmkodb": umqmkodb["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
