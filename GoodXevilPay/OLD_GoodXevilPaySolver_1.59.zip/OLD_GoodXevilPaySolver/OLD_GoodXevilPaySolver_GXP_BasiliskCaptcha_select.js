var lkqgexaz = GetInputConstructorValue("lkqgexaz", loader);
                 if(lkqgexaz["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var atsclusq = GetInputConstructorValue("atsclusq", loader);
                 if(atsclusq["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var ygocyrlc = GetInputConstructorValue("ygocyrlc", loader);
                 if(ygocyrlc["original"].length == 0)
                 {
                   Invalid("siteurl" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#OLD_GoodXevilPaySolver_GXP_BasiliskCaptcha_code").html())({"lkqgexaz": lkqgexaz["updated"],"atsclusq": atsclusq["updated"],"ygocyrlc": ygocyrlc["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
