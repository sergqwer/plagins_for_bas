_call_function(OLD_GoodXevilPaySolver_GXP_AutoBypassCloudFlare,{ "custom_button": (<%= wseityri %>),"max_time": (<%= kqrajzlc %>),"whait_element": (<%= hfbshdxq %>) })!
