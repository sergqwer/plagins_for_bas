_call_function(OLD_GoodXevilPaySolver_GXP_ReCaptchav2TakeToken,{ "APIKEY": (<%= azojpaug %>),"site_url": (<%= kqhypqip %>),"sitekey": (<%= hnsqupev %>) })!
<%= variable %> = _result_function()
