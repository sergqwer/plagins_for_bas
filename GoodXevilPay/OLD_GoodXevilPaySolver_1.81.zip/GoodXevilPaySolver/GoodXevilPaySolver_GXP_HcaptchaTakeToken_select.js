var iobwxpqr = GetInputConstructorValue("iobwxpqr", loader);
                 if(iobwxpqr["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var gdhmmfib = GetInputConstructorValue("gdhmmfib", loader);
                 if(gdhmmfib["original"].length == 0)
                 {
                   Invalid("site_url" + " is empty");
                   return;
                 }
var kfbulxvb = GetInputConstructorValue("kfbulxvb", loader);
                 if(kfbulxvb["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_HcaptchaTakeToken_code").html())({"iobwxpqr": iobwxpqr["updated"],"gdhmmfib": gdhmmfib["updated"],"kfbulxvb": kfbulxvb["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
