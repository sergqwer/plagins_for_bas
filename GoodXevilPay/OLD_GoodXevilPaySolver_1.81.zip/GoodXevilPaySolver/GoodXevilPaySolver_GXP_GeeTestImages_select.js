var mhyvtoup = GetInputConstructorValue("mhyvtoup", loader);
                 if(mhyvtoup["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var gqwgluwo = GetInputConstructorValue("gqwgluwo", loader);
                 if(gqwgluwo["original"].length == 0)
                 {
                   Invalid("images_button" + " is empty");
                   return;
                 }
var jpabebqy = GetInputConstructorValue("jpabebqy", loader);
                 if(jpabebqy["original"].length == 0)
                 {
                   Invalid("reload_button" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_GeeTestImages_code").html())({"mhyvtoup": mhyvtoup["updated"],"gqwgluwo": gqwgluwo["updated"],"jpabebqy": jpabebqy["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
