var gfgwbbrs = GetInputConstructorValue("gfgwbbrs", loader);
                 if(gfgwbbrs["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var kmxqfkzw = GetInputConstructorValue("kmxqfkzw", loader);
                 if(kmxqfkzw["original"].length == 0)
                 {
                   Invalid("iconselement" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_IconsFinder_code").html())({"gfgwbbrs": gfgwbbrs["updated"],"kmxqfkzw": kmxqfkzw["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
