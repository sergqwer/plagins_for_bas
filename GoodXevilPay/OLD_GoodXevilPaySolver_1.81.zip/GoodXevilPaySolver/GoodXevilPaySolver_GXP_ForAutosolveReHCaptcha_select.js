var ovrdmhiu = GetInputConstructorValue("ovrdmhiu", loader);
                 if(ovrdmhiu["original"].length == 0)
                 {
                   Invalid("hCaptcha_USE" + " is empty");
                   return;
                 }
var pcqcbpvg = GetInputConstructorValue("pcqcbpvg", loader);
                 if(pcqcbpvg["original"].length == 0)
                 {
                   Invalid("ReCaptcha_USE" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_ForAutosolveReHCaptcha_code").html())({"ovrdmhiu": ovrdmhiu["updated"],"pcqcbpvg": pcqcbpvg["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
