var owhlbnab = GetInputConstructorValue("owhlbnab", loader);
                 if(owhlbnab["original"].length == 0)
                 {
                   Invalid("arrow_id" + " is empty");
                   return;
                 }
var btkepuip = GetInputConstructorValue("btkepuip", loader);
                 if(btkepuip["original"].length == 0)
                 {
                   Invalid("Attempts" + " is empty");
                   return;
                 }
var untvmmnd = GetInputConstructorValue("untvmmnd", loader);
                 if(untvmmnd["original"].length == 0)
                 {
                   Invalid("avtoupdate" + " is empty");
                   return;
                 }
var zpgucikm = GetInputConstructorValue("zpgucikm", loader);
                 if(zpgucikm["original"].length == 0)
                 {
                   Invalid("button_id" + " is empty");
                   return;
                 }
var ohtzvukt = GetInputConstructorValue("ohtzvukt", loader);
                 if(ohtzvukt["original"].length == 0)
                 {
                   Invalid("coef" + " is empty");
                   return;
                 }
var svxgnsia = GetInputConstructorValue("svxgnsia", loader);
                 if(svxgnsia["original"].length == 0)
                 {
                   Invalid("image id" + " is empty");
                   return;
                 }
var txqajamx = GetInputConstructorValue("txqajamx", loader);
                 if(txqajamx["original"].length == 0)
                 {
                   Invalid("key" + " is empty");
                   return;
                 }
var nkgraitr = GetInputConstructorValue("nkgraitr", loader);
                 if(nkgraitr["original"].length == 0)
                 {
                   Invalid("pixel_koef" + " is empty");
                   return;
                 }
var ggvxnrvw = GetInputConstructorValue("ggvxnrvw", loader);
                 if(ggvxnrvw["original"].length == 0)
                 {
                   Invalid("reload_id" + " is empty");
                   return;
                 }
var xhexdzqy = GetInputConstructorValue("xhexdzqy", loader);
                 if(xhexdzqy["original"].length == 0)
                 {
                   Invalid("slider_type" + " is empty");
                   return;
                 }
var jizfpped = GetInputConstructorValue("jizfpped", loader);
                 if(jizfpped["original"].length == 0)
                 {
                   Invalid("speed" + " is empty");
                   return;
                 }
var mhfdnrub = GetInputConstructorValue("mhfdnrub", loader);
                 if(mhfdnrub["original"].length == 0)
                 {
                   Invalid("type_slide" + " is empty");
                   return;
                 }
var wyxtofew = GetInputConstructorValue("wyxtofew", loader);
                 if(wyxtofew["original"].length == 0)
                 {
                   Invalid("type_swipe" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SliderSolver_code").html())({"owhlbnab": owhlbnab["updated"],"btkepuip": btkepuip["updated"],"untvmmnd": untvmmnd["updated"],"zpgucikm": zpgucikm["updated"],"ohtzvukt": ohtzvukt["updated"],"svxgnsia": svxgnsia["updated"],"txqajamx": txqajamx["updated"],"nkgraitr": nkgraitr["updated"],"ggvxnrvw": ggvxnrvw["updated"],"xhexdzqy": xhexdzqy["updated"],"jizfpped": jizfpped["updated"],"mhfdnrub": mhfdnrub["updated"],"wyxtofew": wyxtofew["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
