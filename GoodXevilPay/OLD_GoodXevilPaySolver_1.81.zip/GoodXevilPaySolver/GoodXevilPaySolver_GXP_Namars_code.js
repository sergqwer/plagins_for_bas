_call_function(GoodXevilPaySolver_GXP_Namars,{ "apikey": (<%= wifzavxy %>) })!
<%= variable %> = _result_function()
