var wmyceobh = GetInputConstructorValue("wmyceobh", loader);
                 if(wmyceobh["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var wqiaottr = GetInputConstructorValue("wqiaottr", loader);
                 if(wqiaottr["original"].length == 0)
                 {
                   Invalid("button_capthca" + " is empty");
                   return;
                 }
var pvfyqvqe = GetInputConstructorValue("pvfyqvqe", loader);
                 if(pvfyqvqe["original"].length == 0)
                 {
                   Invalid("captcha_submit" + " is empty");
                   return;
                 }
var gqaypvrw = GetInputConstructorValue("gqaypvrw", loader);
                 if(gqaypvrw["original"].length == 0)
                 {
                   Invalid("foto_captcha" + " is empty");
                   return;
                 }
var yrdyhfix = GetInputConstructorValue("yrdyhfix", loader);
                 if(yrdyhfix["original"].length == 0)
                 {
                   Invalid("pixel_coef" + " is empty");
                   return;
                 }
var laaswylk = GetInputConstructorValue("laaswylk", loader);
                 if(laaswylk["original"].length == 0)
                 {
                   Invalid("reload_captcha" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SolverGeetestIcon_code").html())({"wmyceobh": wmyceobh["updated"],"wqiaottr": wqiaottr["updated"],"pvfyqvqe": pvfyqvqe["updated"],"gqaypvrw": gqaypvrw["updated"],"yrdyhfix": yrdyhfix["updated"],"laaswylk": laaswylk["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
