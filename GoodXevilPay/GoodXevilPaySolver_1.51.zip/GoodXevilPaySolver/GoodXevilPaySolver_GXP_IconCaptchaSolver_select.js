var sptvgwif = GetInputConstructorValue("sptvgwif", loader);
                 if(sptvgwif["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_IconCaptchaSolver_code").html())({"sptvgwif": sptvgwif["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
