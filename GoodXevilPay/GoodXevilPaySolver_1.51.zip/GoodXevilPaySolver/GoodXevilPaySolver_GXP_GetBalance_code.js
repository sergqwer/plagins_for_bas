_call_function(GoodXevilPaySolver_GXP_GetBalance,{ "APIKEY": (<%= extqzzpy %>) })!
<%= variable %> = _result_function()
