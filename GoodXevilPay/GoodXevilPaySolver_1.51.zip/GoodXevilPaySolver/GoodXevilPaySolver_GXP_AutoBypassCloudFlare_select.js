var xfvanirg = GetInputConstructorValue("xfvanirg", loader);
                 if(xfvanirg["original"].length == 0)
                 {
                   Invalid("custom_button" + " is empty");
                   return;
                 }
var ggpbezgy = GetInputConstructorValue("ggpbezgy", loader);
                 if(ggpbezgy["original"].length == 0)
                 {
                   Invalid("max_time" + " is empty");
                   return;
                 }
var cwidlupy = GetInputConstructorValue("cwidlupy", loader);
                 if(cwidlupy["original"].length == 0)
                 {
                   Invalid("whait_element" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_AutoBypassCloudFlare_code").html())({"xfvanirg": xfvanirg["updated"],"ggpbezgy": ggpbezgy["updated"],"cwidlupy": cwidlupy["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
