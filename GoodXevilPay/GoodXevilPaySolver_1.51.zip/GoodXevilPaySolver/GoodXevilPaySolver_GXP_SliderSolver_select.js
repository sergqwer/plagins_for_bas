var wvfezsln = GetInputConstructorValue("wvfezsln", loader);
                 if(wvfezsln["original"].length == 0)
                 {
                   Invalid("arrow_id" + " is empty");
                   return;
                 }
var iqcdofgp = GetInputConstructorValue("iqcdofgp", loader);
                 if(iqcdofgp["original"].length == 0)
                 {
                   Invalid("avtoupdate" + " is empty");
                   return;
                 }
var bsysmmah = GetInputConstructorValue("bsysmmah", loader);
                 if(bsysmmah["original"].length == 0)
                 {
                   Invalid("button_id" + " is empty");
                   return;
                 }
var nrpxfoit = GetInputConstructorValue("nrpxfoit", loader);
                 if(nrpxfoit["original"].length == 0)
                 {
                   Invalid("coef" + " is empty");
                   return;
                 }
var ympjnzco = GetInputConstructorValue("ympjnzco", loader);
                 if(ympjnzco["original"].length == 0)
                 {
                   Invalid("image id" + " is empty");
                   return;
                 }
var wisygrii = GetInputConstructorValue("wisygrii", loader);
                 if(wisygrii["original"].length == 0)
                 {
                   Invalid("key" + " is empty");
                   return;
                 }
var kuzljpmx = GetInputConstructorValue("kuzljpmx", loader);
                 if(kuzljpmx["original"].length == 0)
                 {
                   Invalid("pixel_koef" + " is empty");
                   return;
                 }
var svgedifa = GetInputConstructorValue("svgedifa", loader);
                 if(svgedifa["original"].length == 0)
                 {
                   Invalid("reload_id" + " is empty");
                   return;
                 }
var mckvafrf = GetInputConstructorValue("mckvafrf", loader);
                 if(mckvafrf["original"].length == 0)
                 {
                   Invalid("speed" + " is empty");
                   return;
                 }
var aiuipjmh = GetInputConstructorValue("aiuipjmh", loader);
                 if(aiuipjmh["original"].length == 0)
                 {
                   Invalid("type_slide" + " is empty");
                   return;
                 }
var epwbcmrb = GetInputConstructorValue("epwbcmrb", loader);
                 if(epwbcmrb["original"].length == 0)
                 {
                   Invalid("type_swipe" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SliderSolver_code").html())({"wvfezsln": wvfezsln["updated"],"iqcdofgp": iqcdofgp["updated"],"bsysmmah": bsysmmah["updated"],"nrpxfoit": nrpxfoit["updated"],"ympjnzco": ympjnzco["updated"],"wisygrii": wisygrii["updated"],"kuzljpmx": kuzljpmx["updated"],"svgedifa": svgedifa["updated"],"mckvafrf": mckvafrf["updated"],"aiuipjmh": aiuipjmh["updated"],"epwbcmrb": epwbcmrb["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
