_call_function(GoodXevilPaySolver_GXP_ReCaptchav2TakeToken,{ "APIKEY": (<%= sslkvzsw %>),"site_url": (<%= rijnvgip %>),"sitekey": (<%= jixrzjnk %>) })!
<%= variable %> = _result_function()
