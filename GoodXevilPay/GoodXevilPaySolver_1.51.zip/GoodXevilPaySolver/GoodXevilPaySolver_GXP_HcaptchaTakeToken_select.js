var xuqyccrd = GetInputConstructorValue("xuqyccrd", loader);
                 if(xuqyccrd["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var rkljoqgx = GetInputConstructorValue("rkljoqgx", loader);
                 if(rkljoqgx["original"].length == 0)
                 {
                   Invalid("site_url" + " is empty");
                   return;
                 }
var wyabgunm = GetInputConstructorValue("wyabgunm", loader);
                 if(wyabgunm["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_HcaptchaTakeToken_code").html())({"xuqyccrd": xuqyccrd["updated"],"rkljoqgx": rkljoqgx["updated"],"wyabgunm": wyabgunm["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
