_call_function(GoodXevilPaySolver_GXP_AutoBypassCloudFlare,{ "custom_button": (<%= xfvanirg %>),"max_time": (<%= ggpbezgy %>),"whait_element": (<%= cwidlupy %>) })!
