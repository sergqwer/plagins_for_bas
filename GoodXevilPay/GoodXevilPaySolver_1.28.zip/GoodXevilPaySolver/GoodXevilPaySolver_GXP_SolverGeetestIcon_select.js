var lshajbrz = GetInputConstructorValue("lshajbrz", loader);
                 if(lshajbrz["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var qfokxxks = GetInputConstructorValue("qfokxxks", loader);
                 if(qfokxxks["original"].length == 0)
                 {
                   Invalid("button_capthca" + " is empty");
                   return;
                 }
var qgjkqegd = GetInputConstructorValue("qgjkqegd", loader);
                 if(qgjkqegd["original"].length == 0)
                 {
                   Invalid("captcha_submit" + " is empty");
                   return;
                 }
var pareukob = GetInputConstructorValue("pareukob", loader);
                 if(pareukob["original"].length == 0)
                 {
                   Invalid("foto_captcha" + " is empty");
                   return;
                 }
var rrihpvmu = GetInputConstructorValue("rrihpvmu", loader);
                 if(rrihpvmu["original"].length == 0)
                 {
                   Invalid("reload_captcha" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SolverGeetestIcon_code").html())({"lshajbrz": lshajbrz["updated"],"qfokxxks": qfokxxks["updated"],"qgjkqegd": qgjkqegd["updated"],"pareukob": pareukob["updated"],"rrihpvmu": rrihpvmu["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
