var tymeaxtx = GetInputConstructorValue("tymeaxtx", loader);
                 if(tymeaxtx["original"].length == 0)
                 {
                   Invalid("arrow_id" + " is empty");
                   return;
                 }
var visefdnr = GetInputConstructorValue("visefdnr", loader);
                 if(visefdnr["original"].length == 0)
                 {
                   Invalid("avtoupdate" + " is empty");
                   return;
                 }
var vjpuxirv = GetInputConstructorValue("vjpuxirv", loader);
                 if(vjpuxirv["original"].length == 0)
                 {
                   Invalid("button_id" + " is empty");
                   return;
                 }
var btsrkfyv = GetInputConstructorValue("btsrkfyv", loader);
                 if(btsrkfyv["original"].length == 0)
                 {
                   Invalid("coef" + " is empty");
                   return;
                 }
var bkrgkzfn = GetInputConstructorValue("bkrgkzfn", loader);
                 if(bkrgkzfn["original"].length == 0)
                 {
                   Invalid("image id" + " is empty");
                   return;
                 }
var engxgjle = GetInputConstructorValue("engxgjle", loader);
                 if(engxgjle["original"].length == 0)
                 {
                   Invalid("key" + " is empty");
                   return;
                 }
var wxwcmcbn = GetInputConstructorValue("wxwcmcbn", loader);
                 if(wxwcmcbn["original"].length == 0)
                 {
                   Invalid("pixel_koef" + " is empty");
                   return;
                 }
var vqblebeh = GetInputConstructorValue("vqblebeh", loader);
                 if(vqblebeh["original"].length == 0)
                 {
                   Invalid("reload_id" + " is empty");
                   return;
                 }
var wovpdvpg = GetInputConstructorValue("wovpdvpg", loader);
                 if(wovpdvpg["original"].length == 0)
                 {
                   Invalid("speed" + " is empty");
                   return;
                 }
var syvxkkbm = GetInputConstructorValue("syvxkkbm", loader);
                 if(syvxkkbm["original"].length == 0)
                 {
                   Invalid("type_slide" + " is empty");
                   return;
                 }
var tgjxblsq = GetInputConstructorValue("tgjxblsq", loader);
                 if(tgjxblsq["original"].length == 0)
                 {
                   Invalid("type_swipe" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SliderSolver_code").html())({"tymeaxtx": tymeaxtx["updated"],"visefdnr": visefdnr["updated"],"vjpuxirv": vjpuxirv["updated"],"btsrkfyv": btsrkfyv["updated"],"bkrgkzfn": bkrgkzfn["updated"],"engxgjle": engxgjle["updated"],"wxwcmcbn": wxwcmcbn["updated"],"vqblebeh": vqblebeh["updated"],"wovpdvpg": wovpdvpg["updated"],"syvxkkbm": syvxkkbm["updated"],"tgjxblsq": tgjxblsq["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
