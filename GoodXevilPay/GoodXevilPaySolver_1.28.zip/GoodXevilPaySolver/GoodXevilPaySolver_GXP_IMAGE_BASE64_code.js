_call_function(GoodXevilPaySolver_GXP_IMAGE_BASE64,{ "APIKEY": (<%= zcpzaczs %>),"IMAGE_BASE64": (<%= chnhdyfg %>) })!
<%= variable %> = _result_function()
