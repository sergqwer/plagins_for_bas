var njoocuoo = GetInputConstructorValue("njoocuoo", loader);
                 if(njoocuoo["original"].length == 0)
                 {
                   Invalid("AutoSettings" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_ForAutosolveReHCaptcha_code").html())({"njoocuoo": njoocuoo["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
