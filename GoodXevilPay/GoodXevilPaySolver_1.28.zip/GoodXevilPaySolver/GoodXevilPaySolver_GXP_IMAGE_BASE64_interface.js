<div class="container-fluid">
<%= _.template($('#input_constructor').html())({id:"zcpzaczs", description:"APIKEY", default_selector: "string", disable_expression:true, disable_int:true, value_string: "", help: {description: "apikey с сервиса https://t.me/Xevil_check_bot"} }) %>
<%= _.template($('#input_constructor').html())({id:"chnhdyfg", description:"IMAGE_BASE64", default_selector: "string", disable_int:true, value_string: "", help: {description: "Изображение в формате base64"} }) %>
<%= _.template($('#variable_constructor').html())({id:"Save", description:"Result", default_variable: "RESULT", help: {description: "Ответ от сервиса решения капчи"}}) %>
</div>
<div class="tooltipinternal">
<div class="tr tooltip-paragraph-first-fold">Решает изображения в формате base64</div>
</div>
<%= _.template($('#back').html())({action:"executeandadd", visible:true}) %>
