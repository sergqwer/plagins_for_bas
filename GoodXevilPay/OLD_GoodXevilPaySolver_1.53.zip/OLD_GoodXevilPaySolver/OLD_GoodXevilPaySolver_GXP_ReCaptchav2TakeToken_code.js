_call_function(OLD_GoodXevilPaySolver_GXP_ReCaptchav2TakeToken,{ "APIKEY": (<%= pbnfmkne %>),"site_url": (<%= brphqsdr %>),"sitekey": (<%= ojswxxgm %>) })!
<%= variable %> = _result_function()
