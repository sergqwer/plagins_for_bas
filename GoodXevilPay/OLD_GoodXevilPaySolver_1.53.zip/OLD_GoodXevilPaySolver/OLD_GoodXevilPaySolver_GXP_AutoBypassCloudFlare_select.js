var wwhqeqtp = GetInputConstructorValue("wwhqeqtp", loader);
                 if(wwhqeqtp["original"].length == 0)
                 {
                   Invalid("custom_button" + " is empty");
                   return;
                 }
var upbttuim = GetInputConstructorValue("upbttuim", loader);
                 if(upbttuim["original"].length == 0)
                 {
                   Invalid("max_time" + " is empty");
                   return;
                 }
var arhjvixj = GetInputConstructorValue("arhjvixj", loader);
                 if(arhjvixj["original"].length == 0)
                 {
                   Invalid("whait_element" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#OLD_GoodXevilPaySolver_GXP_AutoBypassCloudFlare_code").html())({"wwhqeqtp": wwhqeqtp["updated"],"upbttuim": upbttuim["updated"],"arhjvixj": arhjvixj["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
