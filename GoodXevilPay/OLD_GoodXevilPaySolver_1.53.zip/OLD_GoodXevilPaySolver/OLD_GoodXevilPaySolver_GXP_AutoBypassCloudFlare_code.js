_call_function(OLD_GoodXevilPaySolver_GXP_AutoBypassCloudFlare,{ "custom_button": (<%= wwhqeqtp %>),"max_time": (<%= upbttuim %>),"whait_element": (<%= arhjvixj %>) })!
