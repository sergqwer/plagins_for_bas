var mcvfmruz = GetInputConstructorValue("mcvfmruz", loader);
                 if(mcvfmruz["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var gisqwedu = GetInputConstructorValue("gisqwedu", loader);
                 if(gisqwedu["original"].length == 0)
                 {
                   Invalid("captcha_submit" + " is empty");
                   return;
                 }
var nqejpcth = GetInputConstructorValue("nqejpcth", loader);
                 if(nqejpcth["original"].length == 0)
                 {
                   Invalid("foto_captcha" + " is empty");
                   return;
                 }
var wjshowvz = GetInputConstructorValue("wjshowvz", loader);
                 if(wjshowvz["original"].length == 0)
                 {
                   Invalid("pixel_coef" + " is empty");
                   return;
                 }
var dnczyfvs = GetInputConstructorValue("dnczyfvs", loader);
                 if(dnczyfvs["original"].length == 0)
                 {
                   Invalid("reload_captcha" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#OLD_GoodXevilPaySolver_GXP_SolverGeetestIcon_code").html())({"mcvfmruz": mcvfmruz["updated"],"gisqwedu": gisqwedu["updated"],"nqejpcth": nqejpcth["updated"],"wjshowvz": wjshowvz["updated"],"dnczyfvs": dnczyfvs["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
