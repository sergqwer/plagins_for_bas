_call_function(OLD_GoodXevilPaySolver_GXP_IMAGE_BASE64,{ "APIKEY": (<%= oxmgvack %>),"IMAGE_BASE64": (<%= ulmvwnoj %>) })!
<%= variable %> = _result_function()
