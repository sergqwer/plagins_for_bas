var rapzicxs = GetInputConstructorValue("rapzicxs", loader);
                 if(rapzicxs["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#OLD_GoodXevilPaySolver_GXP_Viefaucet_code").html())({"rapzicxs": rapzicxs["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
