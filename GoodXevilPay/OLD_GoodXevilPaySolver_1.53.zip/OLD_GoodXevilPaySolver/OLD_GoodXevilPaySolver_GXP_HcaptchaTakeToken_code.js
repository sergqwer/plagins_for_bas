_call_function(OLD_GoodXevilPaySolver_GXP_HcaptchaTakeToken,{ "APIKEY": (<%= onidtbew %>),"site_url": (<%= gilkevmn %>),"sitekey": (<%= rodzrhno %>) })!
<%= variable %> = _result_function()
