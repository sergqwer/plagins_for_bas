var qcnzhvtu = GetInputConstructorValue("qcnzhvtu", loader);
                 if(qcnzhvtu["original"].length == 0)
                 {
                   Invalid("arrow_id" + " is empty");
                   return;
                 }
var otuhxwct = GetInputConstructorValue("otuhxwct", loader);
                 if(otuhxwct["original"].length == 0)
                 {
                   Invalid("avtoupdate" + " is empty");
                   return;
                 }
var hitdezxn = GetInputConstructorValue("hitdezxn", loader);
                 if(hitdezxn["original"].length == 0)
                 {
                   Invalid("button_id" + " is empty");
                   return;
                 }
var sxztgjrb = GetInputConstructorValue("sxztgjrb", loader);
                 if(sxztgjrb["original"].length == 0)
                 {
                   Invalid("coef" + " is empty");
                   return;
                 }
var tefyerhs = GetInputConstructorValue("tefyerhs", loader);
                 if(tefyerhs["original"].length == 0)
                 {
                   Invalid("image id" + " is empty");
                   return;
                 }
var smgqzxqo = GetInputConstructorValue("smgqzxqo", loader);
                 if(smgqzxqo["original"].length == 0)
                 {
                   Invalid("key" + " is empty");
                   return;
                 }
var malutdez = GetInputConstructorValue("malutdez", loader);
                 if(malutdez["original"].length == 0)
                 {
                   Invalid("pixel_koef" + " is empty");
                   return;
                 }
var hrvnwaff = GetInputConstructorValue("hrvnwaff", loader);
                 if(hrvnwaff["original"].length == 0)
                 {
                   Invalid("reload_id" + " is empty");
                   return;
                 }
var thfogtff = GetInputConstructorValue("thfogtff", loader);
                 if(thfogtff["original"].length == 0)
                 {
                   Invalid("speed" + " is empty");
                   return;
                 }
var rdidpbkh = GetInputConstructorValue("rdidpbkh", loader);
                 if(rdidpbkh["original"].length == 0)
                 {
                   Invalid("type_slide" + " is empty");
                   return;
                 }
var bnxipuhi = GetInputConstructorValue("bnxipuhi", loader);
                 if(bnxipuhi["original"].length == 0)
                 {
                   Invalid("type_swipe" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#OLD_GoodXevilPaySolver_GXP_SliderSolver_code").html())({"qcnzhvtu": qcnzhvtu["updated"],"otuhxwct": otuhxwct["updated"],"hitdezxn": hitdezxn["updated"],"sxztgjrb": sxztgjrb["updated"],"tefyerhs": tefyerhs["updated"],"smgqzxqo": smgqzxqo["updated"],"malutdez": malutdez["updated"],"hrvnwaff": hrvnwaff["updated"],"thfogtff": thfogtff["updated"],"rdidpbkh": rdidpbkh["updated"],"bnxipuhi": bnxipuhi["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
