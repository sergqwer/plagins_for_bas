var qjoawrtf = GetInputConstructorValue("qjoawrtf", loader);
                 if(qjoawrtf["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var dzebfzge = GetInputConstructorValue("dzebfzge", loader);
                 if(dzebfzge["original"].length == 0)
                 {
                   Invalid("timer" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#OLD_GoodXevilPaySolver_GXP_BuxMoney_PayupVideo_code").html())({"qjoawrtf": qjoawrtf["updated"],"dzebfzge": dzebfzge["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
