var pbnfmkne = GetInputConstructorValue("pbnfmkne", loader);
                 if(pbnfmkne["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var brphqsdr = GetInputConstructorValue("brphqsdr", loader);
                 if(brphqsdr["original"].length == 0)
                 {
                   Invalid("site_url" + " is empty");
                   return;
                 }
var ojswxxgm = GetInputConstructorValue("ojswxxgm", loader);
                 if(ojswxxgm["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#OLD_GoodXevilPaySolver_GXP_ReCaptchav2TakeToken_code").html())({"pbnfmkne": pbnfmkne["updated"],"brphqsdr": brphqsdr["updated"],"ojswxxgm": ojswxxgm["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
