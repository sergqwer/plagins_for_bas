var hafcvqay = GetInputConstructorValue("hafcvqay", loader);
                 if(hafcvqay["original"].length == 0)
                 {
                   Invalid("arrow_id" + " is empty");
                   return;
                 }
var lmnrjwvk = GetInputConstructorValue("lmnrjwvk", loader);
                 if(lmnrjwvk["original"].length == 0)
                 {
                   Invalid("avtoupdate" + " is empty");
                   return;
                 }
var utsopnbc = GetInputConstructorValue("utsopnbc", loader);
                 if(utsopnbc["original"].length == 0)
                 {
                   Invalid("button_id" + " is empty");
                   return;
                 }
var dlylayzs = GetInputConstructorValue("dlylayzs", loader);
                 if(dlylayzs["original"].length == 0)
                 {
                   Invalid("coef" + " is empty");
                   return;
                 }
var ghevpeey = GetInputConstructorValue("ghevpeey", loader);
                 if(ghevpeey["original"].length == 0)
                 {
                   Invalid("image id" + " is empty");
                   return;
                 }
var fzepapfh = GetInputConstructorValue("fzepapfh", loader);
                 if(fzepapfh["original"].length == 0)
                 {
                   Invalid("key" + " is empty");
                   return;
                 }
var cuzmvuac = GetInputConstructorValue("cuzmvuac", loader);
                 if(cuzmvuac["original"].length == 0)
                 {
                   Invalid("pixel_koef" + " is empty");
                   return;
                 }
var lownqcsk = GetInputConstructorValue("lownqcsk", loader);
                 if(lownqcsk["original"].length == 0)
                 {
                   Invalid("reload_id" + " is empty");
                   return;
                 }
var ffvxslpb = GetInputConstructorValue("ffvxslpb", loader);
                 if(ffvxslpb["original"].length == 0)
                 {
                   Invalid("speed" + " is empty");
                   return;
                 }
var dwvwkqns = GetInputConstructorValue("dwvwkqns", loader);
                 if(dwvwkqns["original"].length == 0)
                 {
                   Invalid("type_slide" + " is empty");
                   return;
                 }
var qvxnpfqi = GetInputConstructorValue("qvxnpfqi", loader);
                 if(qvxnpfqi["original"].length == 0)
                 {
                   Invalid("type_swipe" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#OLD_GoodXevilPaySolver_GXP_SliderSolver_code").html())({"hafcvqay": hafcvqay["updated"],"lmnrjwvk": lmnrjwvk["updated"],"utsopnbc": utsopnbc["updated"],"dlylayzs": dlylayzs["updated"],"ghevpeey": ghevpeey["updated"],"fzepapfh": fzepapfh["updated"],"cuzmvuac": cuzmvuac["updated"],"lownqcsk": lownqcsk["updated"],"ffvxslpb": ffvxslpb["updated"],"dwvwkqns": dwvwkqns["updated"],"qvxnpfqi": qvxnpfqi["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
