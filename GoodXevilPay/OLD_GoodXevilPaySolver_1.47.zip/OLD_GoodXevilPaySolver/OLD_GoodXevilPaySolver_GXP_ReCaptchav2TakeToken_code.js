_call_function(OLD_GoodXevilPaySolver_GXP_ReCaptchav2TakeToken,{ "APIKEY": (<%= ecujnfoz %>),"site_url": (<%= vyqnznhm %>),"sitekey": (<%= ryonivmf %>) })!
<%= variable %> = _result_function()
