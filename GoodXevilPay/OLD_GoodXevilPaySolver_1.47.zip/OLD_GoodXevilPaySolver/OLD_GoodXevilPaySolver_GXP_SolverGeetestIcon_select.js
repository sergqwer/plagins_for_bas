var yhfmxzvg = GetInputConstructorValue("yhfmxzvg", loader);
                 if(yhfmxzvg["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var htgheqnu = GetInputConstructorValue("htgheqnu", loader);
                 if(htgheqnu["original"].length == 0)
                 {
                   Invalid("button_capthca" + " is empty");
                   return;
                 }
var wgpjlboq = GetInputConstructorValue("wgpjlboq", loader);
                 if(wgpjlboq["original"].length == 0)
                 {
                   Invalid("captcha_submit" + " is empty");
                   return;
                 }
var lnpnnggs = GetInputConstructorValue("lnpnnggs", loader);
                 if(lnpnnggs["original"].length == 0)
                 {
                   Invalid("foto_captcha" + " is empty");
                   return;
                 }
var iwuoxxte = GetInputConstructorValue("iwuoxxte", loader);
                 if(iwuoxxte["original"].length == 0)
                 {
                   Invalid("reload_captcha" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#OLD_GoodXevilPaySolver_GXP_SolverGeetestIcon_code").html())({"yhfmxzvg": yhfmxzvg["updated"],"htgheqnu": htgheqnu["updated"],"wgpjlboq": wgpjlboq["updated"],"lnpnnggs": lnpnnggs["updated"],"iwuoxxte": iwuoxxte["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
