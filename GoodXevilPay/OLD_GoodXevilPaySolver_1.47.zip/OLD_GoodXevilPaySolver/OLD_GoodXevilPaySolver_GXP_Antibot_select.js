var oldakuet = GetInputConstructorValue("oldakuet", loader);
                 if(oldakuet["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var lzcltfzn = GetInputConstructorValue("lzcltfzn", loader);
                 if(lzcltfzn["original"].length == 0)
                 {
                   Invalid("mouse" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#OLD_GoodXevilPaySolver_GXP_Antibot_code").html())({"oldakuet": oldakuet["updated"],"lzcltfzn": lzcltfzn["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
