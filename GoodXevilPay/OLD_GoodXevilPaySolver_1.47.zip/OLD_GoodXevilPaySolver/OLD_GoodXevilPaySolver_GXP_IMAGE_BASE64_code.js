_call_function(OLD_GoodXevilPaySolver_GXP_IMAGE_BASE64,{ "APIKEY": (<%= eflgirqm %>),"IMAGE_BASE64": (<%= weueupiu %>) })!
<%= variable %> = _result_function()
