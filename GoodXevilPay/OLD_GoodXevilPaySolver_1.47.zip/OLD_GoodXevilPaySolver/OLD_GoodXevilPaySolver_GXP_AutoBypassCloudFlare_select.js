var fbqyhgkb = GetInputConstructorValue("fbqyhgkb", loader);
                 if(fbqyhgkb["original"].length == 0)
                 {
                   Invalid("custom_button" + " is empty");
                   return;
                 }
var ubtkirvp = GetInputConstructorValue("ubtkirvp", loader);
                 if(ubtkirvp["original"].length == 0)
                 {
                   Invalid("max_time" + " is empty");
                   return;
                 }
var krzgobjk = GetInputConstructorValue("krzgobjk", loader);
                 if(krzgobjk["original"].length == 0)
                 {
                   Invalid("whait_element" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#OLD_GoodXevilPaySolver_GXP_AutoBypassCloudFlare_code").html())({"fbqyhgkb": fbqyhgkb["updated"],"ubtkirvp": ubtkirvp["updated"],"krzgobjk": krzgobjk["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
