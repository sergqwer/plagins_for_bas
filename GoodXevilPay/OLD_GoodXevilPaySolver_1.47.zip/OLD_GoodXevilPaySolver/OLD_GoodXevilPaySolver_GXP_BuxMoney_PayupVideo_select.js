var tdamdild = GetInputConstructorValue("tdamdild", loader);
                 if(tdamdild["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var clqzfrzk = GetInputConstructorValue("clqzfrzk", loader);
                 if(clqzfrzk["original"].length == 0)
                 {
                   Invalid("timer" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#OLD_GoodXevilPaySolver_GXP_BuxMoney_PayupVideo_code").html())({"tdamdild": tdamdild["updated"],"clqzfrzk": clqzfrzk["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
