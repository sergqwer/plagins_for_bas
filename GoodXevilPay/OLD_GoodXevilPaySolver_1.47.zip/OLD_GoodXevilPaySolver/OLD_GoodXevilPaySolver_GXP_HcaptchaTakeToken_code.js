_call_function(OLD_GoodXevilPaySolver_GXP_HcaptchaTakeToken,{ "APIKEY": (<%= uxtlbrbc %>),"site_url": (<%= lvylrsvs %>),"sitekey": (<%= xumcodyf %>) })!
<%= variable %> = _result_function()
