var qrymrfpb = GetInputConstructorValue("qrymrfpb", loader);
                 if(qrymrfpb["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#OLD_GoodXevilPaySolver_GXP_IconCaptchaSolver_code").html())({"qrymrfpb": qrymrfpb["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
