_call_function(OLD_GoodXevilPaySolver_GXP_AutoBypassCloudFlare,{ "custom_button": (<%= fbqyhgkb %>),"max_time": (<%= ubtkirvp %>),"whait_element": (<%= krzgobjk %>) })!
