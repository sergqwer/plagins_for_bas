_call_function(GoodXevilPaySolver_GXP_ReCaptchav2TakeToken,{ "APIKEY": (<%= hyzodkwq %>),"Service_Solver": (<%= highpcra %>),"site_url": (<%= pxqyxuli %>),"sitekey": (<%= uzeowkvg %>) })!
<%= variable %> = _result_function()
