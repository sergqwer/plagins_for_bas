_call_function(GoodXevilPaySolver_GXP_Solve_Funcaptcha,{ "APIKey": (<%= pvrcfrkq %>),"CaptchaNumber": (<%= wempqvoi %>),"CaptchaSelector": (<%= kfhfnlry %>),"MaxLimitTask": (<%= npwabztl %>) })!
