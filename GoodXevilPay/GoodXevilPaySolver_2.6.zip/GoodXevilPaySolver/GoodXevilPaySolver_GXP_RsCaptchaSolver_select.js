var sshhuajt = GetInputConstructorValue("sshhuajt", loader);
                 if(sshhuajt["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var fvzmigtv = GetInputConstructorValue("fvzmigtv", loader);
                 if(fvzmigtv["original"].length == 0)
                 {
                   Invalid("Service_Solver" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_RsCaptchaSolver_code").html())({"sshhuajt": sshhuajt["updated"],"fvzmigtv": fvzmigtv["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
