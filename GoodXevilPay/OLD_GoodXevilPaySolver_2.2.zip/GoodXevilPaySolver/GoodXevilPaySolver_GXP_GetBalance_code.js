_call_function(GoodXevilPaySolver_GXP_GetBalance,{ "APIKEY": (<%= buvrrgrs %>),"Service_Solver": (<%= jfvgcuwb %>) })!
<%= variable %> = _result_function()
