<div class="container-fluid">
</div>
<div class="tooltipinternal">
<div class="tr tooltip-paragraph-first-fold">Разрешает кеш для решения невидимой ReCaptcha кликами. Вызывать до загрузки страницы с капчей, можно в начале скрипта, до первой загрузки страницы. Настройки сбрасываются при переключении вкладок, применении настроек браузера, профилей браузера, отпечатков, прокси</div>
<div class="tr tooltip-paragraph-last-fold">Enables cache to resolve invisible ReCaptcha. Call before the page with captcha is loaded, can be called at the beginning of the script, before the first page load. Settings are reset when switching tabs, applying browser settings, browser profiles, fingerprints, proxies</div>
</div>
<%= _.template($('#back').html())({action:"executeandadd", visible:true}) %>
