_call_function(GoodXevilPaySolver_GXP_ReCaptchaAutoSolver,{ "apikey": (<%= ptmvhwwj %>),"Service_Solver": (<%= lzfgcgqm %>) })!
<%= variable %> = _result_function()
