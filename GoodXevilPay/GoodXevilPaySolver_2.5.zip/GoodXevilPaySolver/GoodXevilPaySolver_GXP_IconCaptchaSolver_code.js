_call_function(GoodXevilPaySolver_GXP_IconCaptchaSolver,{ "apikey": (<%= skyusaai %>),"Service_Solver": (<%= hserbyqw %>) })!
