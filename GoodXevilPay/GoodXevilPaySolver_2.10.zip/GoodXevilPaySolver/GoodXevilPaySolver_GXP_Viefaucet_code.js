_call_function(GoodXevilPaySolver_GXP_Viefaucet,{ "apikey": (<%= ponzuvfj %>),"Service_Solver": (<%= rqwveeza %>) })!
