_call_function(GoodXevilPaySolver_GXP_HcaptchaAutoSolver,{ "apikey": (<%= qafcmiok %>),"FrameWithCaptcha": (<%= dsvlzfcb %>),"Service_Solver": (<%= juaglbnj %>) })!
<%= variable %> = _result_function()
