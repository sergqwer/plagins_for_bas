var bmsmmtqx = GetInputConstructorValue("bmsmmtqx", loader);
                 if(bmsmmtqx["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var gzgbxpld = GetInputConstructorValue("gzgbxpld", loader);
                 if(gzgbxpld["original"].length == 0)
                 {
                   Invalid("images_button" + " is empty");
                   return;
                 }
var dzinglup = GetInputConstructorValue("dzinglup", loader);
                 if(dzinglup["original"].length == 0)
                 {
                   Invalid("reload_button" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_GeeTestImages_code").html())({"bmsmmtqx": bmsmmtqx["updated"],"gzgbxpld": gzgbxpld["updated"],"dzinglup": dzinglup["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
