_call_function(GoodXevilPaySolver_GXP_hCaptcha_Click,{ "apikey": (<%= zrmropmn %>),"CaptchaSelector": (<%= mwdlyjmm %>),"Service_Solver": (<%= csoiwgab %>),"TrySolve": (<%= avmrmhvb %>) })!
