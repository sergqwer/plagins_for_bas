_call_function(GoodXevilPaySolver_GXP_ReCaptchav2TakeToken,{ "APIKEY": (<%= shzuhwig %>),"site_url": (<%= ijuiwfcy %>),"sitekey": (<%= yejcqsyy %>) })!
<%= variable %> = _result_function()
