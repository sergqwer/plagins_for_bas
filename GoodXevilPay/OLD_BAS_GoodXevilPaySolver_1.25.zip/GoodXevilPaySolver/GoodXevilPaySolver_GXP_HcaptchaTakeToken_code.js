_call_function(GoodXevilPaySolver_GXP_HcaptchaTakeToken,{ "APIKEY": (<%= iehntscy %>),"site_url": (<%= letpgwxf %>),"sitekey": (<%= trrezupf %>) })!
<%= variable %> = _result_function()
