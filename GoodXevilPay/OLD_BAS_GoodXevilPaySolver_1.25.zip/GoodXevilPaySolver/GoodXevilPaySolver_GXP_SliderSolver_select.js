var nnyzeyvc = GetInputConstructorValue("nnyzeyvc", loader);
                 if(nnyzeyvc["original"].length == 0)
                 {
                   Invalid("arrow_id" + " is empty");
                   return;
                 }
var tousensi = GetInputConstructorValue("tousensi", loader);
                 if(tousensi["original"].length == 0)
                 {
                   Invalid("avtoupdate" + " is empty");
                   return;
                 }
var tpnzpcrl = GetInputConstructorValue("tpnzpcrl", loader);
                 if(tpnzpcrl["original"].length == 0)
                 {
                   Invalid("button_id" + " is empty");
                   return;
                 }
var tpimzvfu = GetInputConstructorValue("tpimzvfu", loader);
                 if(tpimzvfu["original"].length == 0)
                 {
                   Invalid("coef" + " is empty");
                   return;
                 }
var dbuwsxst = GetInputConstructorValue("dbuwsxst", loader);
                 if(dbuwsxst["original"].length == 0)
                 {
                   Invalid("image id" + " is empty");
                   return;
                 }
var ikjnklzs = GetInputConstructorValue("ikjnklzs", loader);
                 if(ikjnklzs["original"].length == 0)
                 {
                   Invalid("key" + " is empty");
                   return;
                 }
var qlvgijiv = GetInputConstructorValue("qlvgijiv", loader);
                 if(qlvgijiv["original"].length == 0)
                 {
                   Invalid("pixel_koef" + " is empty");
                   return;
                 }
var wmewrozs = GetInputConstructorValue("wmewrozs", loader);
                 if(wmewrozs["original"].length == 0)
                 {
                   Invalid("reload_id" + " is empty");
                   return;
                 }
var qkgjqejq = GetInputConstructorValue("qkgjqejq", loader);
                 if(qkgjqejq["original"].length == 0)
                 {
                   Invalid("speed" + " is empty");
                   return;
                 }
var mclsdpjr = GetInputConstructorValue("mclsdpjr", loader);
                 if(mclsdpjr["original"].length == 0)
                 {
                   Invalid("type_slide" + " is empty");
                   return;
                 }
var jrfxrktt = GetInputConstructorValue("jrfxrktt", loader);
                 if(jrfxrktt["original"].length == 0)
                 {
                   Invalid("type_swipe" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SliderSolver_code").html())({"nnyzeyvc": nnyzeyvc["updated"],"tousensi": tousensi["updated"],"tpnzpcrl": tpnzpcrl["updated"],"tpimzvfu": tpimzvfu["updated"],"dbuwsxst": dbuwsxst["updated"],"ikjnklzs": ikjnklzs["updated"],"qlvgijiv": qlvgijiv["updated"],"wmewrozs": wmewrozs["updated"],"qkgjqejq": qkgjqejq["updated"],"mclsdpjr": mclsdpjr["updated"],"jrfxrktt": jrfxrktt["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
