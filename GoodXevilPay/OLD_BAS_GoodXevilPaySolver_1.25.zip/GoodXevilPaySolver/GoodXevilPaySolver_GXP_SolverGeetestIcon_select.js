var rbzjgnwm = GetInputConstructorValue("rbzjgnwm", loader);
                 if(rbzjgnwm["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var etotanyg = GetInputConstructorValue("etotanyg", loader);
                 if(etotanyg["original"].length == 0)
                 {
                   Invalid("button_capthca" + " is empty");
                   return;
                 }
var aagfqpsj = GetInputConstructorValue("aagfqpsj", loader);
                 if(aagfqpsj["original"].length == 0)
                 {
                   Invalid("captcha_submit" + " is empty");
                   return;
                 }
var grbnonta = GetInputConstructorValue("grbnonta", loader);
                 if(grbnonta["original"].length == 0)
                 {
                   Invalid("foto_captcha" + " is empty");
                   return;
                 }
var qzaolcuf = GetInputConstructorValue("qzaolcuf", loader);
                 if(qzaolcuf["original"].length == 0)
                 {
                   Invalid("reload_captcha" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SolverGeetestIcon_code").html())({"rbzjgnwm": rbzjgnwm["updated"],"etotanyg": etotanyg["updated"],"aagfqpsj": aagfqpsj["updated"],"grbnonta": grbnonta["updated"],"qzaolcuf": qzaolcuf["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
