_call_function(GoodXevilPaySolver_GXP_ReCaptchav2TakeToken,{ "APIKEY": (<%= ixxypntf %>),"site_url": (<%= wfewbajq %>),"sitekey": (<%= gbdybena %>) })!
<%= variable %> = _result_function()
