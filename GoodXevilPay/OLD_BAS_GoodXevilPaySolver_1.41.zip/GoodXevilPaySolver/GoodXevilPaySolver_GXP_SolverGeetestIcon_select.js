var ettqfver = GetInputConstructorValue("ettqfver", loader);
                 if(ettqfver["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var wmjzrezx = GetInputConstructorValue("wmjzrezx", loader);
                 if(wmjzrezx["original"].length == 0)
                 {
                   Invalid("button_capthca" + " is empty");
                   return;
                 }
var lpioncfk = GetInputConstructorValue("lpioncfk", loader);
                 if(lpioncfk["original"].length == 0)
                 {
                   Invalid("captcha_submit" + " is empty");
                   return;
                 }
var sebyhvqx = GetInputConstructorValue("sebyhvqx", loader);
                 if(sebyhvqx["original"].length == 0)
                 {
                   Invalid("foto_captcha" + " is empty");
                   return;
                 }
var hfacozjt = GetInputConstructorValue("hfacozjt", loader);
                 if(hfacozjt["original"].length == 0)
                 {
                   Invalid("reload_captcha" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SolverGeetestIcon_code").html())({"ettqfver": ettqfver["updated"],"wmjzrezx": wmjzrezx["updated"],"lpioncfk": lpioncfk["updated"],"sebyhvqx": sebyhvqx["updated"],"hfacozjt": hfacozjt["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
