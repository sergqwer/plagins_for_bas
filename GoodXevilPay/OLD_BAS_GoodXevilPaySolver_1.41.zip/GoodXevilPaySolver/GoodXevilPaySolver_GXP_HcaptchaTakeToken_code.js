_call_function(GoodXevilPaySolver_GXP_HcaptchaTakeToken,{ "APIKEY": (<%= vfdiobeg %>),"site_url": (<%= ywkjsswn %>),"sitekey": (<%= wpgpsevb %>) })!
<%= variable %> = _result_function()
