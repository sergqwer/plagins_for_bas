function GoodXevilPaySolver_GXP_reCaptcha_inform()
   {
   
      
      
      page().script2("function findRecaptchaClients() {\r\n  // eslint-disable-next-line camelcase\r\n  if (typeof (___grecaptcha_cfg) !== 'undefined') {\r\n    // eslint-disable-next-line camelcase, no-undef\r\n    return Object.entries(___grecaptcha_cfg.clients).map(([cid, client]) => {\r\n      const data = { id: cid, version: cid >= 10000 ? 'V3' : 'V2' };\r\n      const objects = Object.entries(client).filter(([_, value]) => value && typeof value === 'object');\r\n\r\n      objects.forEach(([toplevelKey, toplevel]) => {\r\n        const found = Object.entries(toplevel).find(([_, value]) => (\r\n          value && typeof value === 'object' && 'sitekey' in value && 'size' in value\r\n        ));\r\n     \r\n        if (typeof toplevel === 'object' && toplevel instanceof HTMLElement && toplevel['tagName'] === 'DIV'){\r\n            data.pageurl = toplevel.baseURI;\r\n        }\r\n        \r\n        if (found) {\r\n          const [sublevelKey, sublevel] = found;\r\n\r\n          data.sitekey = sublevel.sitekey;\r\n          const callbackKey = data.version === 'V2' ? 'callback' : 'promise-callback';\r\n          const callback = sublevel[callbackKey];\r\n          if (!callback) {\r\n            data.callback = null;\r\n            data.function = null;\r\n          } else {\r\n            data.function = callback;\r\n            const keys = [cid, toplevelKey, sublevelKey, callbackKey].map((key) => `['${key}']`).join('');\r\n            data.callback = `___grecaptcha_cfg.clients${keys}`;\r\n          }\r\n        }\r\n      });\r\n      return data;\r\n    });\r\n  }\r\n  return [];\r\n}\r\n\r\nlet res = findRecaptchaClients()\r\n[[RECAPTCHA_DATA]] = res;",JSON.stringify(_read_variables(["VAR_RECAPTCHA_DATA"])))!
      var _parse_result = JSON.parse(_result())
      _write_variables(JSON.parse(_parse_result.variables))
      if(!_parse_result.is_success)
      fail(_parse_result.error)
      

      
      
      _function_return(VAR_RECAPTCHA_DATA)
      

   }
   

function GoodXevilPaySolver_GXP_Cwallet()
   {
   
      
      
      VAR_APIKEY = _function_argument("apikey")
      

      
      
      var regexp_result = native("regexp", "first", JSON.stringify({text: VAR_APIKEY,regexp:"([0-9A-Za-z]\u007b20,40\u007d)"}))
      if(regexp_result.length == 0)
      regexp_result = []
      else
      regexp_result = JSON.parse(regexp_result)
      VAR_ALL_MATCH = regexp_result.pop()
      if(typeof(VAR_ALL_MATCH) == 'undefined' || !VAR_ALL_MATCH)
      VAR_ALL_MATCH = ""
      VAR_APIKEY = regexp_result[0]
      if(typeof(VAR_APIKEY) == 'undefined' || !VAR_APIKEY)
      VAR_APIKEY = ""
      if(regexp_result.length == 0)
      {
      VAR_APIKEY = VAR_ALL_MATCH
      }
      

      
      
      /*Browser*/
      ;_SELECTOR=" \u003eXPATH\u003e //div[contains(@class, \u0022captcha\u0022) and @style]";
      get_element_selector(_SELECTOR, false).nowait().exist()!
      VAR_IS_EXISTS = _result() == 1
      _if(VAR_IS_EXISTS, function(){
      get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
      VAR_IS_EXISTS = _result().indexOf("true")>=0
      })!
      

      
      
      _set_if_expression("W1tJU19FWElTVFNdXSA9PSBmYWxzZQ==");
      _if(VAR_IS_EXISTS == false,function(){
      
         
         
         _call(function()
         {
         _on_fail(function(){
         VAR_LAST_ERROR = _result()
         VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
         VAR_WAS_ERROR = false
         _break(1,true)
         })
         CYCLES.Current().RemoveLabel("function")
         
            
            
            /*Browser*/
            waiter_timeout_next(15000)
            wait_async_load()!
            

         },null)!
         

         
         
         /*Browser*/
         ;_SELECTOR=" \u003eXPATH\u003e //div[contains(@class, \u0022captcha\u0022) and @style]";
         get_element_selector(_SELECTOR, false).nowait().exist()!
         VAR_IS_EXISTS = _result() == 1
         _if(VAR_IS_EXISTS, function(){
         get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
         VAR_IS_EXISTS = _result().indexOf("true")>=0
         })!
         

         
         
         _set_if_expression("W1tJU19FWElTVFNdXSA9PSBmYWxzZQ==");
         _if(VAR_IS_EXISTS == false,function(){
         
            
            
            fail((_K==="en" ? "No captcha found" : "Капча не найдена"));
            

         })!
         

      })!
      

      
      
      VAR_GOOD_SOLV = false
      

      
      
      _do(function(){
      _set_action_info({ name: "For" });
      VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(0)
      if(VAR_CYCLE_INDEX > parseInt(5))_break();
      
         
         
         _set_if_expression("W1tHT09EX1NPTFZdXQ==");
         _if(typeof(VAR_GOOD_SOLV) !== "undefined" ? (VAR_GOOD_SOLV) : undefined,function(){
         
            
            
            /*Browser*/
            ;_SELECTOR=" \u003eXPATH\u003e //div[contains(@class, \u0022captcha\u0022)]/h5[text()]";
            get_element_selector(_SELECTOR, false).nowait().exist()!
            VAR_IS_EXISTS = _result() == 1
            _if(VAR_IS_EXISTS, function(){
            get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
            VAR_IS_EXISTS = _result().indexOf("true")>=0
            })!
            

            
            
            _cycle_params().if_else = typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined;
            _set_if_expression("W1tJU19FWElTVFNdXQ==");
            _if(_cycle_params().if_else,function(){
            
               
               
               VAR_GOOD_SOLV = false
               

            })!
            

            
            
            _if(!_cycle_params().if_else,function(){
            
               
               
               _break("function")
               

            })!
            delete _cycle_params().if_else;
            

         })!
         

         
         
         _set_if_expression("W1tDWUNMRV9JTkRFWF1dID09IDQ=");
         _if(VAR_CYCLE_INDEX == 4,function(){
         
            
            
            fail((_K==="en" ? "Captcha is not solved" : "Капча не решена"));
            

         })!
         

         
         
         _set_if_expression("W1tDWUNMRV9JTkRFWF1dICE9IDA=");
         _if(VAR_CYCLE_INDEX != 0,function(){
         
            
            
            /*Browser*/
            _SELECTOR = " \u003eXPATH\u003e //div[contains(@class, \u0022captcha\u0022)]/button[contains(@class, \u0022icon-button\u0022)]";
            wait_element_visible(_SELECTOR)!
            _call(_random_point, {})!
            _if(_result().length > 0, function(){
            move( {} )!
            get_element_selector(_SELECTOR, false).clarify(X,Y)!
            _call(_clarify, {} )!
            mouse(X,Y)!
            })!
            

            
            
            _call(function()
            {
            _on_fail(function(){
            VAR_LAST_ERROR = _result()
            VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
            VAR_WAS_ERROR = false
            _break(1,true)
            })
            CYCLES.Current().RemoveLabel("function")
            
               
               
               /*Browser*/
               waiter_timeout_next(15000)
               wait_async_load()!
               

            },null)!
            

         })!
         

         
         
         /*Browser*/
         _SELECTOR = " \u003eXPATH\u003e //div[contains(@class, \u0022captcha\u0022) and @style]";
         wait_element(_SELECTOR)!
         get_element_selector(_SELECTOR, false).exist()!
         _if(_result() == "1", function(){
         get_element_selector(_SELECTOR, false).render_base64()!
         VAR_SCREENSHOT_BASE64 = _result()
         })!
         

         
         
         /*Browser*/
         scroll(1,1)!
         

         
         
         /*Browser*/
         _SELECTOR = " \u003eXPATH\u003e //div[contains(@class, \u0022captcha\u0022) and @style]";
         wait_element(_SELECTOR)!
         get_element_selector(_SELECTOR, false).script("(function(){var rect = self.getBoundingClientRect();return (rect.left + positionx).toString() + '|' + (rect.top + positiony).toString() + '|' + (rect.right - rect.left).toString() + '|' + (rect.bottom - rect.top).toString()})();")!
         if(_result().length > 0)
         {
         var split = _result().split("|")
         VAR_X = parseInt(split[0])
         VAR_Y = parseInt(split[1])
         VAR_WIDTH = parseInt(split[2])
         VAR_HEIGHT = parseInt(split[3])
         }
         

         
         
         solver_properties_clear("capmonster")
         solver_property("capmonster","serverurl","http://goodxevilpay.pp.ua/")
         solver_property("capmonster","key",VAR_APIKEY)
         solver_property("capmonster","method","cwallet")
         solver_property("capmonster","body",VAR_SCREENSHOT_BASE64)
         solve_base64_no_fail("capmonster", "")!
         VAR_SAVED_CONTENT = _result();
         

         
         
         VAR_STRING_MATCHES = Boolean(native("regexp", "ismatch", JSON.stringify({text: VAR_SAVED_CONTENT,regexp:"(ERROR)"})) == "true")
         

         
         
         VAR_STRING_MATCHES2 = Boolean(native("regexp", "ismatch", JSON.stringify({text: VAR_SAVED_CONTENT,regexp:"(_FAIL)"})) == "true")
         

         
         
         VAR_STRING_MATCHES3 = Boolean(native("regexp", "ismatch", JSON.stringify({text: VAR_SAVED_CONTENT,regexp:"(_)"})) == "true")
         

         
         
         _set_if_expression("W1tTVFJJTkdfTUFUQ0hFU11dIHx8IFtbU1RSSU5HX01BVENIRVMyXV0gfHwgW1tTVFJJTkdfTUFUQ0hFUzNdXQ==");
         _if(VAR_STRING_MATCHES || VAR_STRING_MATCHES2 || VAR_STRING_MATCHES3,function(){
         
            
            
            _next("function")
            

         })!
         

         
         
         VAR_PARSED_LIST = (VAR_SAVED_CONTENT).split(";")
         

         
         
         VAR_LIST_LENGTH = (VAR_PARSED_LIST).length
         

         
         
         _set_if_expression("W1tMSVNUX0xFTkdUSF1dIDwgMw==");
         _if(VAR_LIST_LENGTH < 3,function(){
         
            
            
            _next("function")
            

         })!
         

         
         
         /*Browser*/
         scroll(1,1)!
         

         
         
         _do_with_params({"foreach_data":(VAR_PARSED_LIST)},function(){
         _set_action_info({ name: "Foreach" });
         VAR_CYCLE_INDEX = _iterator() - 1
         if(VAR_CYCLE_INDEX > _cycle_param("foreach_data").length - 1)_break();
         VAR_FOREACH_DATA = _cycle_param("foreach_data")[VAR_CYCLE_INDEX]
         
            
            
            VAR_SCAN_RESULT_LIST = native("regexp", "scan", JSON.stringify({text: VAR_FOREACH_DATA,regexp:"\u005cd+"}))
            if(VAR_SCAN_RESULT_LIST.length == 0)
            VAR_SCAN_RESULT_LIST = []
            else
            VAR_SCAN_RESULT_LIST = JSON.parse(VAR_SCAN_RESULT_LIST)
            

            
            
            VAR_LIST_LENGTH = (VAR_SCAN_RESULT_LIST).length
            

            
            
            _set_if_expression("W1tMSVNUX0xFTkdUSF1dICE9IDI=");
            _if(VAR_LIST_LENGTH != 2,function(){
            
               
               
               fail_user("Не понятный ответ от сервера: " + VAR_SAVED_CONTENT,false)
               

            })!
            

            
            
            VAR_X_XEVIL = parseInt(VAR_SCAN_RESULT_LIST[0]);
            VAR_Y_XEVIL = parseInt(VAR_SCAN_RESULT_LIST[1]);
            

            
            
            /*Browser*/
            move(VAR_X + VAR_X_XEVIL,VAR_Y + VAR_Y_XEVIL,  {} )!
            mouse(VAR_X + VAR_X_XEVIL,VAR_Y + VAR_Y_XEVIL)!
            

         })!
         

         
         
         /*Browser*/
         _SELECTOR = " \u003eXPATH\u003e //div[contains(@class, \u0022captcha\u0022)]/button/div[@class=\u0022button-inner\u0022]";
         wait_element_visible(_SELECTOR)!
         _call(_random_point, {})!
         _if(_result().length > 0, function(){
         move( {} )!
         get_element_selector(_SELECTOR, false).clarify(X,Y)!
         _call(_clarify, {} )!
         mouse(X,Y)!
         })!
         

         
         
         VAR_GOOD_SOLV = true
         

         
         
         _call(function()
         {
         _on_fail(function(){
         VAR_LAST_ERROR = _result()
         VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
         VAR_WAS_ERROR = false
         _break(1,true)
         })
         CYCLES.Current().RemoveLabel("function")
         
            
            
            /*Browser*/
            waiter_timeout_next(15000)
            wait_async_load()!
            

         },null)!
         

      })!
      

   }
   

function GoodXevilPaySolver_GXP_RsCaptchaSolver()
   {
   
      
      
      VAR_APIKEY = _function_argument("apikey")
      

      
      
      var regexp_result = native("regexp", "first", JSON.stringify({text: VAR_APIKEY,regexp:"([0-9A-Za-z]\u007b20,40\u007d)"}))
      if(regexp_result.length == 0)
      regexp_result = []
      else
      regexp_result = JSON.parse(regexp_result)
      VAR_ALL_MATCH = regexp_result.pop()
      if(typeof(VAR_ALL_MATCH) == 'undefined' || !VAR_ALL_MATCH)
      VAR_ALL_MATCH = ""
      VAR_APIKEY = regexp_result[0]
      if(typeof(VAR_APIKEY) == 'undefined' || !VAR_APIKEY)
      VAR_APIKEY = ""
      if(regexp_result.length == 0)
      {
      VAR_APIKEY = VAR_ALL_MATCH
      }
      

      
      
      /*Browser*/
      _SELECTOR = " \u003eXPATH\u003e //img[@id=\u0022rscaptcha_img\u0022]";
      wait_element(_SELECTOR)!
      get_element_selector(_SELECTOR, false).exist()!
      _if(_result() == "1", function(){
      get_element_selector(_SELECTOR, false).render_base64()!
      VAR_ICONCAPTCHAMODAL__BODY = _result()
      })!
      

      
      
      /*Browser*/
      scroll(1,1)!
      

      
      
      /*Browser*/
      _SELECTOR = " \u003eXPATH\u003e //img[@id=\u0022rscaptcha_img\u0022]";
      wait_element(_SELECTOR)!
      get_element_selector(_SELECTOR, false).script("(function(){var rect = self.getBoundingClientRect();return (rect.left + positionx).toString() + '|' + (rect.top + positiony).toString() + '|' + (rect.right - rect.left).toString() + '|' + (rect.bottom - rect.top).toString()})();")!
      if(_result().length > 0)
      {
      var split = _result().split("|")
      VAR_X = parseInt(split[0])
      VAR_Y = parseInt(split[1])
      VAR_WITH_DATA = parseInt(split[2])
      VAR_HEIGHT_DATA = parseInt(split[3])
      }
      

      
      
      solver_properties_clear("capmonster")
      solver_property("capmonster","serverurl","http://goodxevilpay.pp.ua/")
      solver_property("capmonster","key",VAR_APIKEY)
      solver_property("capmonster","method","rscaptcha")
      solver_property("capmonster","body",VAR_ICONCAPTCHAMODAL__BODY)
      solve_base64_no_fail("capmonster", "")!
      VAR_SAVED_CONTENT = _result();
      

      
      
      VAR_STRING_MATCHES = Boolean(native("regexp", "ismatch", JSON.stringify({text: VAR_SAVED_CONTENT,regexp:"(ERROR)"})) == "true")
      

      
      
      VAR_STRING_MATCHES2 = Boolean(native("regexp", "ismatch", JSON.stringify({text: VAR_SAVED_CONTENT,regexp:"(_FAIL)"})) == "true")
      

      
      
      VAR_STRING_MATCHES3 = Boolean(native("regexp", "ismatch", JSON.stringify({text: VAR_SAVED_CONTENT,regexp:"(_)"})) == "true")
      

      
      
      _set_if_expression("W1tTVFJJTkdfTUFUQ0hFU11dIHx8IFtbU1RSSU5HX01BVENIRVMyXV0gfHwgW1tTVFJJTkdfTUFUQ0hFUzNdXQ==");
      _if(VAR_STRING_MATCHES || VAR_STRING_MATCHES2 || VAR_STRING_MATCHES3,function(){
      
         
         
         fail((_K==="en" ? "Captcha is not solved" : "Капча не решена"));
         

      })!
      

      
      
      VAR_SCAN_RESULT_LIST = native("regexp", "scan", JSON.stringify({text: VAR_SAVED_CONTENT,regexp:"\u005cd+"}))
      if(VAR_SCAN_RESULT_LIST.length == 0)
      VAR_SCAN_RESULT_LIST = []
      else
      VAR_SCAN_RESULT_LIST = JSON.parse(VAR_SCAN_RESULT_LIST)
      

      
      
      VAR_LIST_LENGTH = (VAR_SCAN_RESULT_LIST).length
      

      
      
      _set_if_expression("W1tMSVNUX0xFTkdUSF1dICE9IDI=");
      _if(VAR_LIST_LENGTH != 2,function(){
      
         
         
         fail((_K==="en" ? "Unclear response from the server" : "Не понятный ответ от сервера"));
         

      })!
      

      
      
      VAR_X_XEVIL = parseInt(VAR_SCAN_RESULT_LIST[0]);
      VAR_Y_XEVIL = parseInt(VAR_SCAN_RESULT_LIST[1]);
      

      
      
      /*Browser*/
      move(VAR_X + VAR_X_XEVIL,VAR_Y + VAR_Y_XEVIL,  {} )!
      mouse(VAR_X + VAR_X_XEVIL,VAR_Y + VAR_Y_XEVIL)!
      

   }
   

function GoodXevilPaySolver_GXP_Namars()
   {
   
      
      
      VAR_APIKEY = _function_argument("apikey")
      

      
      
      var regexp_result = native("regexp", "first", JSON.stringify({text: VAR_APIKEY,regexp:"([0-9A-Za-z]\u007b20,40\u007d)"}))
      if(regexp_result.length == 0)
      regexp_result = []
      else
      regexp_result = JSON.parse(regexp_result)
      VAR_ALL_MATCH = regexp_result.pop()
      if(typeof(VAR_ALL_MATCH) == 'undefined' || !VAR_ALL_MATCH)
      VAR_ALL_MATCH = ""
      VAR_APIKEY = regexp_result[0]
      if(typeof(VAR_APIKEY) == 'undefined' || !VAR_APIKEY)
      VAR_APIKEY = ""
      if(regexp_result.length == 0)
      {
      VAR_APIKEY = VAR_ALL_MATCH
      }
      

      
      
      VAR_IMAGE_DATA = ""
      

      
      
      _do(function(){
      _set_action_info({ name: "While" });
      VAR_CYCLE_INDEX = _iterator() - 1
      BREAK_CONDITION = true;
      if(!BREAK_CONDITION)_break();
      
         
         
         _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gMTU=");
         _if(VAR_CYCLE_INDEX > 15,function(){
         
            
            
            fail((_K==="en" ? "Couldn't decide to find the captcha" : "Не смог решить найти капчу"));
            

         })!
         

         
         
         sleep(1000)!
         

         
         
         /*Browser*/
         wait_load("*namars.com/captcha/*")!
         cache_get_base64("*namars.com/captcha/*")!
         VAR_IMAGE_DATA = _result()
         

         
         
         _set_if_expression("W1tJTUFHRV9EQVRBXV0gIT0gIiI=");
         _if(VAR_IMAGE_DATA != "",function(){
         
            
            
            _break("function")
            

         })!
         

      })!
      

      
      
      solver_properties_clear("capmonster")
      solver_property("capmonster","serverurl","http://goodxevilpay.pp.ua/")
      solver_property("capmonster","key",VAR_APIKEY)
      solver_property("capmonster","method","base64")
      solver_property("capmonster","body",VAR_IMAGE_DATA)
      solve_base64_no_fail("capmonster", "")!
      VAR_SAVED_CONTENT = _result();
      

      
      
      _function_return(VAR_SAVED_CONTENT)
      

   }
   

function GoodXevilPaySolver_GXP_Namars_CacheAllow()
   {
   
      
      
      /*Browser*/
      cache_allow("*namars.com/captcha/*")!
      

   }
   

function GoodXevilPaySolver_GXP_teaserfast()
   {
   
      
      
      VAR_APIKEY = _function_argument("apikey")
      

      
      
      var regexp_result = native("regexp", "first", JSON.stringify({text: VAR_APIKEY,regexp:"([0-9A-Za-z]\u007b20,40\u007d)"}))
      if(regexp_result.length == 0)
      regexp_result = []
      else
      regexp_result = JSON.parse(regexp_result)
      VAR_ALL_MATCH = regexp_result.pop()
      if(typeof(VAR_ALL_MATCH) == 'undefined' || !VAR_ALL_MATCH)
      VAR_ALL_MATCH = ""
      VAR_APIKEY = regexp_result[0]
      if(typeof(VAR_APIKEY) == 'undefined' || !VAR_APIKEY)
      VAR_APIKEY = ""
      if(regexp_result.length == 0)
      {
      VAR_APIKEY = VAR_ALL_MATCH
      }
      

      
      
      VAR_NOW_ID_FRAME = ""
      

      
      
      VAR_GOOD_SOLVE = 0
      

      
      
      VAR_TYPE_DATA = "1"
      

      
      
      _do(function(){
      _set_action_info({ name: "For" });
      VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(0)
      if(VAR_CYCLE_INDEX > parseInt(6))_break();
      
         
         
         _set_if_expression("W1tDWUNMRV9JTkRFWF1dID49IDU=");
         _if(VAR_CYCLE_INDEX >= 5,function(){
         
            
            
            fail((_K==="en" ? "The service was unable to solve the captcha in 3 attempts" : "Сервис не смог решить капчу за 3 попытки"));
            

         })!
         

         
         
         /*Browser*/
         ;_SELECTOR=" \u003eXPATH\u003e //div[@class=\u0022task_captcha\u0022]//div[@id=\u0022tcaptchaimage\u0022]";
         get_element_selector(_SELECTOR, false).nowait().exist()!
         VAR_IS_EXISTS = _result() == 1
         _if(VAR_IS_EXISTS, function(){
         get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
         VAR_IS_EXISTS = _result().indexOf("true")>=0
         })!
         

         
         
         _set_if_expression("W1tJU19FWElTVFNdXQ==");
         _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
         
            
            
            VAR_TYPE_DATA = "1"
            

         })!
         

         
         
         /*Browser*/
         ;_SELECTOR=" \u003eXPATH\u003e //div[@class=\u0022task_captcha\u0022]//div[@id=\u0022t2captchaimage\u0022]";
         get_element_selector(_SELECTOR, false).nowait().exist()!
         VAR_IS_EXISTS2 = _result() == 1
         _if(VAR_IS_EXISTS2, function(){
         get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
         VAR_IS_EXISTS2 = _result().indexOf("true")>=0
         })!
         

         
         
         _set_if_expression("W1tJU19FWElTVFMyXV0=");
         _if(typeof(VAR_IS_EXISTS2) !== "undefined" ? (VAR_IS_EXISTS2) : undefined,function(){
         
            
            
            VAR_TYPE_DATA = "2"
            

         })!
         

         
         
         _set_if_expression("W1tJU19FWElTVFNdXSA9PSBmYWxzZSAmJiBbW0lTX0VYSVNUUzJdXSA9PSBmYWxzZQ==");
         _if(VAR_IS_EXISTS == false && VAR_IS_EXISTS2 == false,function(){
         
            
            
            _set_if_expression("W1tHT09EX1NPTFZFXV0gPT0gMQ==");
            _if(VAR_GOOD_SOLVE == 1,function(){
            
               
               
               _break("function")
               

            })!
            

            
            
            sleep(2000)!
            

            
            
            _next("function")
            

         })!
         

         
         
         /*Browser*/
         page().script("document.documentElement.outerHTML")!
         VAR_SAVED_PAGE_HTML = _result()
         

         
         
         _cycle_params().if_else = VAR_TYPE_DATA == 1;
         _set_if_expression("W1tUWVBFX0RBVEFdXSA9PSAx");
         _if(_cycle_params().if_else,function(){
         
            
            
            html_parser_xpath_parse(VAR_SAVED_PAGE_HTML)
            if((false) && !html_parser_xpath_exist("//div[@class=\u0022task_captcha\u0022]//div[@id=\u0022tcaptchaimage\u0022]/@style"))
            fail("Can't resolve query " + "//div[@class=\u0022task_captcha\u0022]//div[@id=\u0022tcaptchaimage\u0022]/@style");
            VAR_MAIN_IMG = html_parser_xpath_xml("//div[@class=\u0022task_captcha\u0022]//div[@id=\u0022tcaptchaimage\u0022]/@style")
            

         })!
         

         
         
         _if(!_cycle_params().if_else,function(){
         
            
            
            html_parser_xpath_parse(VAR_SAVED_PAGE_HTML)
            if((false) && !html_parser_xpath_exist("//div[@class=\u0022task_captcha\u0022]//div[@id=\u0022t2captchaimage\u0022]/@style"))
            fail("Can't resolve query " + "//div[@class=\u0022task_captcha\u0022]//div[@id=\u0022t2captchaimage\u0022]/@style");
            VAR_MAIN_IMG = html_parser_xpath_xml("//div[@class=\u0022task_captcha\u0022]//div[@id=\u0022t2captchaimage\u0022]/@style")
            

         })!
         delete _cycle_params().if_else;
         

         
         
         html_parser_xpath_parse(VAR_SAVED_PAGE_HTML)
         if((false) && !html_parser_xpath_exist("//div[@class=\u0022task_captcha\u0022]//div[@id=\u0022tcsmallimage\u0022]/@style"))
         fail("Can't resolve query " + "//div[@class=\u0022task_captcha\u0022]//div[@id=\u0022tcsmallimage\u0022]/@style");
         VAR_TASK_IMG = html_parser_xpath_xml("//div[@class=\u0022task_captcha\u0022]//div[@id=\u0022tcsmallimage\u0022]/@style")
         

         
         
         _set_if_expression("W1tUQVNLX0lNR11dID09ICIiIHx8IFtbTUFJTl9JTUddXSA9PSAiIg==");
         _if(VAR_TASK_IMG == "" || VAR_MAIN_IMG == "",function(){
         
            
            
            sleep(2000)!
            

            
            
            _next("function")
            

         })!
         

         
         
         VAR_SCAN_RESULT_LIST = native("regexp", "scan", JSON.stringify({text: VAR_MAIN_IMG,regexp:"([A-Za-z0-9\u005c+/=]+)"}))
         if(VAR_SCAN_RESULT_LIST.length == 0)
         VAR_SCAN_RESULT_LIST = []
         else
         VAR_SCAN_RESULT_LIST = JSON.parse(VAR_SCAN_RESULT_LIST)
         

         
         
         VAR_MAIN_IMG = ""
         

         
         
         VAR_TEMP_INDEX = 0
         

         
         
         _do_with_params({"foreach_data":(VAR_SCAN_RESULT_LIST)},function(){
         _set_action_info({ name: "Foreach" });
         VAR_CYCLE_INDEX = _iterator() - 1
         if(VAR_CYCLE_INDEX > _cycle_param("foreach_data").length - 1)_break();
         VAR_FOREACH_DATA = _cycle_param("foreach_data")[VAR_CYCLE_INDEX]
         
            
            
            _set_if_expression("W1tGT1JFQUNIX0RBVEFdXS5sZW5ndGggPiBbW1RFTVBfSU5ERVhdXQ==");
            _if(VAR_FOREACH_DATA.length > VAR_TEMP_INDEX,function(){
            
               
               
               VAR_TEMP_INDEX = VAR_FOREACH_DATA.length
               

               
               
               VAR_MAIN_IMG = VAR_FOREACH_DATA
               

            })!
            

         })!
         

         
         
         VAR_SCAN_RESULT_LIST = native("regexp", "scan", JSON.stringify({text: VAR_TASK_IMG,regexp:"([A-Za-z0-9\u005c+/=]+)"}))
         if(VAR_SCAN_RESULT_LIST.length == 0)
         VAR_SCAN_RESULT_LIST = []
         else
         VAR_SCAN_RESULT_LIST = JSON.parse(VAR_SCAN_RESULT_LIST)
         

         
         
         VAR_TASK_IMG = ""
         

         
         
         VAR_TEMP_INDEX = 0
         

         
         
         _do_with_params({"foreach_data":(VAR_SCAN_RESULT_LIST)},function(){
         _set_action_info({ name: "Foreach" });
         VAR_CYCLE_INDEX = _iterator() - 1
         if(VAR_CYCLE_INDEX > _cycle_param("foreach_data").length - 1)_break();
         VAR_FOREACH_DATA = _cycle_param("foreach_data")[VAR_CYCLE_INDEX]
         
            
            
            _set_if_expression("W1tGT1JFQUNIX0RBVEFdXS5sZW5ndGggPiBbW1RFTVBfSU5ERVhdXQ==");
            _if(VAR_FOREACH_DATA.length > VAR_TEMP_INDEX,function(){
            
               
               
               VAR_TEMP_INDEX = VAR_FOREACH_DATA.length
               

               
               
               VAR_TASK_IMG = VAR_FOREACH_DATA
               

            })!
            

         })!
         

         
         
         _call(function()
         {
         _on_fail(function(){
         VAR_LAST_ERROR = _result()
         VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
         VAR_WAS_ERROR = false
         _break(1,true)
         })
         CYCLES.Current().RemoveLabel("function")
         
            
            
            solver_properties_clear("capmonster")
            solver_property("capmonster","serverurl","http://goodxevilpay.pp.ua/")
            solver_property("capmonster","key",VAR_APIKEY)
            solver_property("capmonster","method","teaserfast")
            solver_property("capmonster","main_photo",VAR_MAIN_IMG)
            solver_property("capmonster","task",VAR_TASK_IMG)
            solve_base64_no_fail("capmonster", "")!
            VAR_SAVED_CONTENT = _result();
            

         },null)!
         

         
         
         _set_if_expression("W1tXQVNfRVJST1JdXQ==");
         _if(typeof(VAR_WAS_ERROR) !== "undefined" ? (VAR_WAS_ERROR) : undefined,function(){
         
            
            
            _next("function")
            

         })!
         

         
         
         VAR_STRING_MATCHES = Boolean(native("regexp", "ismatch", JSON.stringify({text: VAR_SAVED_CONTENT,regexp:"(ERROR)"})) == "true")
         

         
         
         VAR_STRING_MATCHES2 = Boolean(native("regexp", "ismatch", JSON.stringify({text: VAR_SAVED_CONTENT,regexp:"(_FAIL)"})) == "true")
         

         
         
         _set_if_expression("W1tTVFJJTkdfTUFUQ0hFU11dIHx8IFtbU1RSSU5HX01BVENIRVMyXV0=");
         _if(VAR_STRING_MATCHES || VAR_STRING_MATCHES2,function(){
         
            
            
            _next("function")
            

         })!
         

         
         
         VAR_SCAN_RESULT_LIST = native("regexp", "scan", JSON.stringify({text: VAR_SAVED_CONTENT,regexp:"\u005cd+"}))
         if(VAR_SCAN_RESULT_LIST.length == 0)
         VAR_SCAN_RESULT_LIST = []
         else
         VAR_SCAN_RESULT_LIST = JSON.parse(VAR_SCAN_RESULT_LIST)
         

         
         
         VAR_LIST_LENGTH = (VAR_SCAN_RESULT_LIST).length
         

         
         
         _set_if_expression("W1tMSVNUX0xFTkdUSF1dICE9IDI=");
         _if(VAR_LIST_LENGTH != 2,function(){
         
            
            
            fail((_K==="en" ? "Unclear response from the server: " + VAR_SAVED_CONTENT : "Не понятный ответ от сервера: " + VAR_SAVED_CONTENT));
            

         })!
         

         
         
         /*Browser*/
         scroll(1,1)!
         

         
         
         _cycle_params().if_else = VAR_TYPE_DATA == 1;
         _set_if_expression("W1tUWVBFX0RBVEFdXSA9PSAx");
         _if(_cycle_params().if_else,function(){
         
            
            
            /*Browser*/
            _SELECTOR = " \u003eXPATH\u003e //div[@class=\u0022task_captcha\u0022]//div[@id=\u0022tcaptchaimage\u0022]";waiter_timeout_next(1000)
            waiter_nofail_next();
            wait_element(_SELECTOR)!
            get_element_selector(_SELECTOR, false).nowait().script("(function(){var rect = self.getBoundingClientRect();return (rect.left + positionx).toString() + '|' + (rect.top + positiony).toString() + '|' + (rect.right - rect.left).toString() + '|' + (rect.bottom - rect.top).toString()})();")!
            if(_result().length > 0)
            {
            var split = _result().split("|")
            VAR_X = parseInt(split[0])
            VAR_Y = parseInt(split[1])
            VAR_WIDTH = parseInt(split[2])
            VAR_HEIGHT = parseInt(split[3])
            }
            

         })!
         

         
         
         _if(!_cycle_params().if_else,function(){
         
            
            
            /*Browser*/
            _SELECTOR = " \u003eXPATH\u003e //div[@class=\u0022task_captcha\u0022]//div[@id=\u0022t2captchaimage\u0022]";waiter_timeout_next(1000)
            waiter_nofail_next();
            wait_element(_SELECTOR)!
            get_element_selector(_SELECTOR, false).nowait().script("(function(){var rect = self.getBoundingClientRect();return (rect.left + positionx).toString() + '|' + (rect.top + positiony).toString() + '|' + (rect.right - rect.left).toString() + '|' + (rect.bottom - rect.top).toString()})();")!
            if(_result().length > 0)
            {
            var split = _result().split("|")
            VAR_X = parseInt(split[0])
            VAR_Y = parseInt(split[1])
            VAR_WIDTH = parseInt(split[2])
            VAR_HEIGHT = parseInt(split[3])
            }
            

         })!
         delete _cycle_params().if_else;
         

         
         
         VAR_X_XEVIL = parseInt(VAR_SCAN_RESULT_LIST[0]);
         VAR_Y_XEVIL = parseInt(VAR_SCAN_RESULT_LIST[1]);
         

         
         
         /*Browser*/
         move(VAR_X + VAR_X_XEVIL - 2,VAR_Y + VAR_Y_XEVIL - 2,  {} )!
         mouse(VAR_X + VAR_X_XEVIL - 2,VAR_Y + VAR_Y_XEVIL - 2)!
         

         
         
         /*Browser*/
         _SELECTOR = " \u003eXPATH\u003e //a[contains(@onclick, \u0022submit_captha\u0022)]";waiter_timeout_next(1000)
         waiter_nofail_next();
         wait_element_visible(_SELECTOR)!
         _call(_random_point, {})!
         _if(_result().length > 0, function(){
         move( {} )!
         get_element_selector(_SELECTOR, false).nowait().clarify(X,Y)!
         _call(_clarify, {} )!
         mouse(X,Y)!
         })!
         

         
         
         VAR_GOOD_SOLVE = 1
         

         
         
         sleep(2000)!
         

      })!
      

   }
   

function GoodXevilPaySolver_GXP_WorkCash()
   {
   
      
      
      VAR_APIKEY = _function_argument("apikey")
      

      
      
      var regexp_result = native("regexp", "first", JSON.stringify({text: VAR_APIKEY,regexp:"([0-9A-Za-z]\u007b20,40\u007d)"}))
      if(regexp_result.length == 0)
      regexp_result = []
      else
      regexp_result = JSON.parse(regexp_result)
      VAR_ALL_MATCH = regexp_result.pop()
      if(typeof(VAR_ALL_MATCH) == 'undefined' || !VAR_ALL_MATCH)
      VAR_ALL_MATCH = ""
      VAR_APIKEY = regexp_result[0]
      if(typeof(VAR_APIKEY) == 'undefined' || !VAR_APIKEY)
      VAR_APIKEY = ""
      if(regexp_result.length == 0)
      {
      VAR_APIKEY = VAR_ALL_MATCH
      }
      

      
      
      /*Browser*/
      ;_SELECTOR=" \u003eCSS\u003e #wrapper_captcha";
      get_element_selector(_SELECTOR, false).nowait().exist()!
      VAR_IS_EXISTS = _result() == 1
      _if(VAR_IS_EXISTS, function(){
      get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
      VAR_IS_EXISTS = _result().indexOf("true")>=0
      })!
      

      
      
      _set_if_expression("W1tJU19FWElTVFNdXSA9PSBmYWxzZQ==");
      _if(VAR_IS_EXISTS == false,function(){
      
         
         
         _call(function()
         {
         _on_fail(function(){
         VAR_LAST_ERROR = _result()
         VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
         VAR_WAS_ERROR = false
         _break(1,true)
         })
         CYCLES.Current().RemoveLabel("function")
         
            
            
            /*Browser*/
            waiter_timeout_next(15000)
            wait_async_load()!
            

         },null)!
         

         
         
         /*Browser*/
         ;_SELECTOR=" \u003eCSS\u003e #wrapper_captcha";
         get_element_selector(_SELECTOR, false).nowait().exist()!
         VAR_IS_EXISTS = _result() == 1
         _if(VAR_IS_EXISTS, function(){
         get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
         VAR_IS_EXISTS = _result().indexOf("true")>=0
         })!
         

         
         
         _set_if_expression("W1tJU19FWElTVFNdXSA9PSBmYWxzZQ==");
         _if(VAR_IS_EXISTS == false,function(){
         
            
            
            fail((_K==="en" ? "Captcha was not found" : "Капча не найдена"));
            

         })!
         

      })!
      

      
      
      /*Browser*/
      ;_SELECTOR=" \u003eCSS\u003e #captcha-alert";
      get_element_selector(_SELECTOR, false).nowait().exist()!
      VAR_IS_EXISTS = _result() == 1
      _if(VAR_IS_EXISTS, function(){
      get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
      VAR_IS_EXISTS = _result().indexOf("true")>=0
      })!
      

      
      
      _set_if_expression("W1tJU19FWElTVFNdXQ==");
      _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
      
         
         
         fail((_K==="en" ? "Website error" : "Ошибка на сайте"));
         

      })!
      

      
      
      /*Browser*/
      scroll(1,1)!
      

      
      
      /*Browser*/
      _SELECTOR = " \u003eCSS\u003e #wrapper_captcha";
      wait_element(_SELECTOR)!
      get_element_selector(_SELECTOR, false).exist()!
      _if(_result() == "1", function(){
      get_element_selector(_SELECTOR, false).render_base64()!
      VAR_SCREENSHOT_BASE64 = _result()
      })!
      

      
      
      /*Browser*/
      _SELECTOR = " \u003eCSS\u003e #wrapper_captcha";
      wait_element(_SELECTOR)!
      get_element_selector(_SELECTOR, false).script("(function(){var rect = self.getBoundingClientRect();return (rect.left + positionx).toString() + '|' + (rect.top + positiony).toString() + '|' + (rect.right - rect.left).toString() + '|' + (rect.bottom - rect.top).toString()})();")!
      if(_result().length > 0)
      {
      var split = _result().split("|")
      VAR_X = parseInt(split[0])
      VAR_Y = parseInt(split[1])
      VAR_WIDTH = parseInt(split[2])
      VAR_HEIGHT = parseInt(split[3])
      }
      

      
      
      solver_properties_clear("capmonster")
      solver_property("capmonster","serverurl","http://goodxevilpay.pp.ua/")
      solver_property("capmonster","key",VAR_APIKEY)
      solver_property("capmonster","method","workcash")
      solver_property("capmonster","body",VAR_SCREENSHOT_BASE64)
      solve_base64_no_fail("capmonster", "")!
      VAR_SAVED_CONTENT = _result();
      

      
      
      VAR_STRING_MATCHES = Boolean(native("regexp", "ismatch", JSON.stringify({text: VAR_SAVED_CONTENT,regexp:"(ERROR)"})) == "true")
      

      
      
      VAR_STRING_MATCHES2 = Boolean(native("regexp", "ismatch", JSON.stringify({text: VAR_SAVED_CONTENT,regexp:"(_FAIL)"})) == "true")
      

      
      
      VAR_STRING_MATCHES3 = Boolean(native("regexp", "ismatch", JSON.stringify({text: VAR_SAVED_CONTENT,regexp:"(_)"})) == "true")
      

      
      
      _set_if_expression("W1tTVFJJTkdfTUFUQ0hFU11dIHx8IFtbU1RSSU5HX01BVENIRVMyXV0gfHwgW1tTVFJJTkdfTUFUQ0hFUzNdXQ==");
      _if(VAR_STRING_MATCHES || VAR_STRING_MATCHES2 || VAR_STRING_MATCHES3,function(){
      
         
         
         fail_user("Капча не решена",false)
         

      })!
      

      
      
      VAR_PARSED_LIST = (VAR_SAVED_CONTENT).split(";")
      

      
      
      VAR_LIST_LENGTH = (VAR_PARSED_LIST).length
      

      
      
      _set_if_expression("W1tMSVNUX0xFTkdUSF1dIDwgMw==");
      _if(VAR_LIST_LENGTH < 3,function(){
      
         
         
         fail((_K==="en" ? "Unclear response from the server: " + VAR_SAVED_CONTENT : "Не понятный ответ от сервера: " + VAR_SAVED_CONTENT));
         

      })!
      

      
      
      /*Browser*/
      scroll(1,1)!
      

      
      
      _do_with_params({"foreach_data":(VAR_PARSED_LIST)},function(){
      _set_action_info({ name: "Foreach" });
      VAR_CYCLE_INDEX = _iterator() - 1
      if(VAR_CYCLE_INDEX > _cycle_param("foreach_data").length - 1)_break();
      VAR_FOREACH_DATA = _cycle_param("foreach_data")[VAR_CYCLE_INDEX]
      
         
         
         VAR_SCAN_RESULT_LIST = native("regexp", "scan", JSON.stringify({text: VAR_FOREACH_DATA,regexp:"\u005cd+"}))
         if(VAR_SCAN_RESULT_LIST.length == 0)
         VAR_SCAN_RESULT_LIST = []
         else
         VAR_SCAN_RESULT_LIST = JSON.parse(VAR_SCAN_RESULT_LIST)
         

         
         
         VAR_LIST_LENGTH = (VAR_SCAN_RESULT_LIST).length
         

         
         
         _set_if_expression("W1tMSVNUX0xFTkdUSF1dICE9IDI=");
         _if(VAR_LIST_LENGTH != 2,function(){
         
            
            
            fail((_K==="en" ? "Unclear response from the server" : "Не понятный ответ от сервера"));
            

         })!
         

         
         
         VAR_X_XEVIL = parseInt(VAR_SCAN_RESULT_LIST[0]);
         VAR_Y_XEVIL = parseInt(VAR_SCAN_RESULT_LIST[1]);
         

         
         
         /*Browser*/
         move(VAR_X + VAR_X_XEVIL,VAR_Y + VAR_Y_XEVIL,  {} )!
         mouse(VAR_X + VAR_X_XEVIL,VAR_Y + VAR_Y_XEVIL)!
         

      })!
      

   }
   

function GoodXevilPaySolver_GXP_RsCaptchaFreeSolver()
   {
   
      
      
      /*Browser*/
      _SELECTOR = " \u003eXPATH\u003e //img[@id=\u0022rscaptcha_img\u0022]";
      wait_element(_SELECTOR)!
      get_element_selector(_SELECTOR, false).script("(function(){var rect = self.getBoundingClientRect();return (rect.left + positionx).toString() + '|' + (rect.top + positiony).toString() + '|' + (rect.right - rect.left).toString() + '|' + (rect.bottom - rect.top).toString()})();")!
      if(_result().length > 0)
      {
      var split = _result().split("|")
      VAR_X = parseInt(split[0])
      VAR_Y = parseInt(split[1])
      VAR_WIDTH = parseInt(split[2])
      VAR_HEIGHT = parseInt(split[3])
      }
      

      
      
      /*Browser*/
      _SELECTOR = " \u003eXPATH\u003e //img[@id=\u0022rscaptcha_img\u0022]";
      wait_element(_SELECTOR)!
      get_element_selector(_SELECTOR, false).exist()!
      _if(_result() == "1", function(){
      get_element_selector(_SELECTOR, false).render_base64()!
      VAR_ICONCAPTCHAMODAL__BODY = _result()
      })!
      

      
      
      /*Browser*/
      scroll(1,1)!
      

      
      
      /*Browser*/
      _SELECTOR = " \u003eXPATH\u003e //img[@id=\u0022rscaptcha_img\u0022]";
      wait_element(_SELECTOR)!
      get_element_selector(_SELECTOR, false).script("(function(){var rect = self.getBoundingClientRect();return (rect.left + positionx).toString() + '|' + (rect.top + positiony).toString() + '|' + (rect.right - rect.left).toString() + '|' + (rect.bottom - rect.top).toString()})();")!
      if(_result().length > 0)
      {
      var split = _result().split("|")
      VAR_X_L = parseInt(split[0])
      VAR_Y_L = parseInt(split[1])
      VAR_WITH_DATA = parseInt(split[2])
      VAR_HEIGHT_DATA = parseInt(split[3])
      }
      

      
      
      VAR_LOADED_IMAGE_ID = native("imageprocessing", "load", VAR_ICONCAPTCHAMODAL__BODY)
      

      
      
      {
      var split = native("imageprocessing", "getsize", VAR_LOADED_IMAGE_ID).split(",")
      VAR_IMAGE_WIDTH = parseInt(split[0])
      VAR_IMAGE_HEIGHT = parseInt(split[1])
      }
      

      
      
      VAR_POINT_X = VAR_IMAGE_HEIGHT/2
      

      
      
      VAR_POINT_X = VAR_POINT_X.toString()
      

      
      
      var regexp_result = native("regexp", "first", JSON.stringify({text: VAR_POINT_X,regexp:"\u005cd+"}))
      if(regexp_result.length == 0)
      regexp_result = []
      else
      regexp_result = JSON.parse(regexp_result)
      VAR_ALL_MATCH = regexp_result.pop()
      if(typeof(VAR_ALL_MATCH) == 'undefined' || !VAR_ALL_MATCH)
      VAR_ALL_MATCH = ""
      VAR_POINT_X = regexp_result[0]
      if(typeof(VAR_POINT_X) == 'undefined' || !VAR_POINT_X)
      VAR_POINT_X = ""
      if(regexp_result.length == 0)
      {
      VAR_POINT_X = VAR_ALL_MATCH
      }
      

      
      
      VAR_POINT_X = parseInt(VAR_POINT_X);
      

      
      
      VAR_TEMP_LIST = []
      

      
      
      VAR_POINT_X = VAR_POINT_X
      

      
      
      VAR_PIXEL_WHITE_MAX = 0
      

      
      
      VAR_PIXEL_WHITE_NOW = 0
      

      
      
      VAR_PIXEL_WHITE_STOP = 0
      

      
      
      {
      var split = native("imageprocessing", "getpixel", (VAR_LOADED_IMAGE_ID) + "," + (2) + "," + (2)).split(",")
      VAR_PIXEL_R = parseInt(split[0])
      VAR_PIXEL_G = parseInt(split[1])
      VAR_PIXEL_B = parseInt(split[2])
      VAR_PIXEL_A = parseInt(split[3])
      }
      

      
      
      _cycle_params().if_else = VAR_PIXEL_B > 200;
      _set_if_expression("W1tQSVhFTF9CXV0gPiAyMDA=");
      _if(_cycle_params().if_else,function(){
      
         
         
         _do(function(){
         _set_action_info({ name: "For" });
         VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(0)
         if(VAR_CYCLE_INDEX > parseInt(VAR_IMAGE_WIDTH - 1))_break();
         
            
            
            VAR_CYCLE_INDEX_X = VAR_CYCLE_INDEX
            

            
            
            VAR_NO_WHITE_PIXEL = 0
            

            
            
            VAR_NO_WHITE_PIXEL_DATA = 0
            

            
            
            _do(function(){
            _set_action_info({ name: "For" });
            VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(0)
            if(VAR_CYCLE_INDEX > parseInt(VAR_IMAGE_HEIGHT - 1))_break();
            
               
               
               {
               var split = native("imageprocessing", "getpixel", (VAR_LOADED_IMAGE_ID) + "," + (VAR_CYCLE_INDEX_X) + "," + (VAR_CYCLE_INDEX)).split(",")
               VAR_PIXEL_R = parseInt(split[0])
               VAR_PIXEL_G = parseInt(split[1])
               VAR_PIXEL_B = parseInt(split[2])
               VAR_PIXEL_A = parseInt(split[3])
               }
               

               
               
               _cycle_params().if_else = VAR_PIXEL_B <= 245;
               _set_if_expression("W1tQSVhFTF9CXV0gPD0gMjQ1");
               _if(_cycle_params().if_else,function(){
               
                  
                  
                  VAR_PIXEL_WHITE_NOW = 1
                  

                  
                  
                  VAR_PIXEL_WHITE_MAX = parseInt(VAR_PIXEL_WHITE_MAX) + parseInt(1)
                  

               })!
               

               
               
               _if(!_cycle_params().if_else,function(){
               
                  
                  
                  VAR_NO_WHITE_PIXEL_DATA = parseInt(VAR_NO_WHITE_PIXEL_DATA) + parseInt(1)
                  

               })!
               delete _cycle_params().if_else;
               

            })!
            

            
            
            _set_if_expression("W1tOT19XSElURV9QSVhFTF9EQVRBXV0gKyA1ID49IFtbSU1BR0VfSEVJR0hUXV0=");
            _if(VAR_NO_WHITE_PIXEL_DATA + 5 >= VAR_IMAGE_HEIGHT,function(){
            
               
               
               VAR_NO_WHITE_PIXEL = parseInt(VAR_NO_WHITE_PIXEL) + parseInt(1)
               

            })!
            

            
            
            _set_if_expression("W1tOT19XSElURV9QSVhFTF1dID09IDE=");
            _if(VAR_NO_WHITE_PIXEL == 1,function(){
            
               
               
               _set_if_expression("W1tQSVhFTF9XSElURV9OT1ddXSA9PSAx");
               _if(VAR_PIXEL_WHITE_NOW == 1,function(){
               
                  
                  
                  VAR_PIXEL_WHITE_STOP = parseInt(VAR_PIXEL_WHITE_STOP) + parseInt(1)
                  

                  
                  
                  _set_if_expression("W1tQSVhFTF9XSElURV9TVE9QXV0gPiA4");
                  _if(VAR_PIXEL_WHITE_STOP > 8,function(){
                  
                     
                     
                     VAR_PIXEL_WHITE_STOP = 0
                     

                     
                     
                     VAR_PIXEL_WHITE_NOW = 0
                     

                     
                     
                     VAR_TEMP_LIST.push(VAR_PIXEL_WHITE_MAX)
                     

                     
                     
                     VAR_PIXEL_WHITE_MAX = 0
                     

                  })!
                  

               })!
               

            })!
            

         })!
         

      })!
      

      
      
      _if(!_cycle_params().if_else,function(){
      
         
         
         _do(function(){
         _set_action_info({ name: "For" });
         VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(0)
         if(VAR_CYCLE_INDEX > parseInt(VAR_IMAGE_WIDTH - 1))_break();
         
            
            
            VAR_CYCLE_INDEX_X = VAR_CYCLE_INDEX
            

            
            
            VAR_NO_WHITE_PIXEL = 0
            

            
            
            VAR_NO_WHITE_PIXEL_DATA = 0
            

            
            
            _do(function(){
            _set_action_info({ name: "For" });
            VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(0)
            if(VAR_CYCLE_INDEX > parseInt(VAR_IMAGE_HEIGHT - 1))_break();
            
               
               
               {
               var split = native("imageprocessing", "getpixel", (VAR_LOADED_IMAGE_ID) + "," + (VAR_CYCLE_INDEX_X) + "," + (VAR_CYCLE_INDEX)).split(",")
               VAR_PIXEL_R = parseInt(split[0])
               VAR_PIXEL_G = parseInt(split[1])
               VAR_PIXEL_B = parseInt(split[2])
               VAR_PIXEL_A = parseInt(split[3])
               }
               

               
               
               _cycle_params().if_else = VAR_PIXEL_B >= 78;
               _set_if_expression("W1tQSVhFTF9CXV0gPj0gNzg=");
               _if(_cycle_params().if_else,function(){
               
                  
                  
                  VAR_PIXEL_WHITE_NOW = 1
                  

                  
                  
                  VAR_PIXEL_WHITE_MAX = parseInt(VAR_PIXEL_WHITE_MAX) + parseInt(1)
                  

               })!
               

               
               
               _if(!_cycle_params().if_else,function(){
               
                  
                  
                  VAR_NO_WHITE_PIXEL_DATA = parseInt(VAR_NO_WHITE_PIXEL_DATA) + parseInt(1)
                  

               })!
               delete _cycle_params().if_else;
               

            })!
            

            
            
            _set_if_expression("W1tOT19XSElURV9QSVhFTF9EQVRBXV0gKyA1ID49IFtbSU1BR0VfSEVJR0hUXV0=");
            _if(VAR_NO_WHITE_PIXEL_DATA + 5 >= VAR_IMAGE_HEIGHT,function(){
            
               
               
               VAR_NO_WHITE_PIXEL = parseInt(VAR_NO_WHITE_PIXEL) + parseInt(1)
               

            })!
            

            
            
            _set_if_expression("W1tOT19XSElURV9QSVhFTF1dID09IDE=");
            _if(VAR_NO_WHITE_PIXEL == 1,function(){
            
               
               
               _set_if_expression("W1tQSVhFTF9XSElURV9OT1ddXSA9PSAx");
               _if(VAR_PIXEL_WHITE_NOW == 1,function(){
               
                  
                  
                  VAR_PIXEL_WHITE_STOP = parseInt(VAR_PIXEL_WHITE_STOP) + parseInt(1)
                  

                  
                  
                  _set_if_expression("W1tQSVhFTF9XSElURV9TVE9QXV0gPiA4");
                  _if(VAR_PIXEL_WHITE_STOP > 8,function(){
                  
                     
                     
                     VAR_PIXEL_WHITE_STOP = 0
                     

                     
                     
                     VAR_PIXEL_WHITE_NOW = 0
                     

                     
                     
                     VAR_TEMP_LIST.push(VAR_PIXEL_WHITE_MAX)
                     

                     
                     
                     VAR_PIXEL_WHITE_MAX = 0
                     

                  })!
                  

               })!
               

            })!
            

         })!
         

      })!
      delete _cycle_params().if_else;
      

      
      
      _do(function(){
      _set_action_info({ name: "For" });
      VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
      if(VAR_CYCLE_INDEX > parseInt(99))_break();
      
         
         
         VAR_TEMP_LIST = VAR_TEMP_LIST.filter(function(e){return e!== VAR_CYCLE_INDEX })
         

      })!
      

      
      
      VAR_COUNT_TEMP_INDEX = [
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
      ]
      

      
      
      _do(function(){
      _set_action_info({ name: "For" });
      VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
      if(VAR_CYCLE_INDEX > parseInt(100))_break();
      
         
         
         var numbers = VAR_TEMP_LIST
         var count = {};
         var leastFrequentNumber;
         var leastFrequentIndex;
         var minmaxdif = VAR_CYCLE_INDEX;
         // Підрахунок кількості входжень кожного числа
         for (var i = 0; i < numbers.length; i++) {
         var number = numbers[i];
         // Враховуємо різницю в 2 як одне число
         var adjustedNumber = Math.floor(number / minmaxdif) * minmaxdif;
         if (count[adjustedNumber] === undefined) {
         count[adjustedNumber] = 1;
         } else {
         count[adjustedNumber]++;
         }
         }
         // Пошук найрідше зустрічаються числа та їх індексу
         var minFrequency = Infinity;
         for (var j = 0; j < numbers.length; j++) {
         var currentNumber = numbers[j];
         var adjustedCurrentNumber = Math.floor(currentNumber / minmaxdif) * minmaxdif;
         if (count[adjustedCurrentNumber] < minFrequency) {
         minFrequency = count[adjustedCurrentNumber];
         leastFrequentNumber = currentNumber;
         leastFrequentIndex = j;
         }
         }
         totalCount = Object.keys(count).length;
         VAR_DEBUG_TEMP = totalCount
         VAR_LOW_INDEX = leastFrequentIndex;
         VAR_LOW_INDEX = VAR_LOW_INDEX + 1
         

         
         
         _set_if_expression("W1tERUJVR19URU1QXV0gPiAx");
         _if(VAR_DEBUG_TEMP > 1,function(){
         
            
            
            VAR_LIST_ELEMENT = (VAR_COUNT_TEMP_INDEX)[VAR_LOW_INDEX];
            

            
            
            VAR_LIST_ELEMENT = parseInt(VAR_LIST_ELEMENT) + parseInt(1)
            

            
            
            VAR_COUNT_TEMP_INDEX[(VAR_LOW_INDEX < 0) ? (VAR_COUNT_TEMP_INDEX.length + VAR_LOW_INDEX) : VAR_LOW_INDEX] = VAR_LIST_ELEMENT;
            

         })!
         

      })!
      

      
      
      _do(function(){
      _set_action_info({ name: "For" });
      VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(0)
      if(VAR_CYCLE_INDEX > parseInt(100))_break();
      
         
         
         VAR_TEMP_VARIABLE = 100 - VAR_CYCLE_INDEX
         

         
         
         VAR_VALUE_INDEX = (VAR_COUNT_TEMP_INDEX).indexOf(VAR_TEMP_VARIABLE)
         

         
         
         _set_if_expression("W1tWQUxVRV9JTkRFWF1dICE9IC0x");
         _if(VAR_VALUE_INDEX != -1,function(){
         
            
            
            _break("function")
            

         })!
         

      })!
      

      
      
      VAR_LOW_INDEX = VAR_VALUE_INDEX
      

      
      
      VAR_LIST_LENGTH = (VAR_TEMP_LIST).length
      

      
      
      native("imageprocessing", "delete", VAR_LOADED_IMAGE_ID)
      

      
      
      VAR_TEMP_INDEX = parseInt((((VAR_WITH_DATA/VAR_LIST_LENGTH) * VAR_LOW_INDEX) - VAR_WITH_DATA/VAR_LIST_LENGTH/2) - 5)
      

      
      
      _set_if_expression("ZmFsc2U=");
      _if(false,function(){
      
         
         
         VAR_TEMP_INDEX = parseInt((((100/VAR_LIST_LENGTH) * VAR_LOW_INDEX) - 100/VAR_LIST_LENGTH/2) - 2)
         

         
         
         /*Browser*/
         _SELECTOR = " \u003eXPATH\u003e //div[@id=\u0022captcha-solve\u0022]/div[@class=\u0022dot\u0022]";
         wait_element(_SELECTOR)!
         get_element_selector(_SELECTOR, false).set_attr("style", "top: 40%; left: " + VAR_TEMP_INDEX + "%;")!
         

         
         
         /*Browser*/
         _SELECTOR = " \u003eXPATH\u003e //div[@id=\u0022captcha-solve\u0022]/div[@class=\u0022dot\u0022]";
         wait_element_visible(_SELECTOR)!
         _call(_random_point, {})!
         _if(_result().length > 0, function(){
         move( {} )!
         get_element_selector(_SELECTOR, false).clarify(X,Y)!
         _call(_clarify, {} )!
         })!
         

         
         
         /*Browser*/
         _SELECTOR = " \u003eXPATH\u003e //div[@id=\u0022captcha-solve\u0022]/div[@class=\u0022dot\u0022]";
         wait_element(_SELECTOR)!
         get_element_selector(_SELECTOR, false).set_attr("style", "display:none;")!
         

         
         
         _get_browser_screen_settings()!
         ;(function(){
         var result = JSON.parse(_result())
         VAR_SCROLL_X = result["ScrollX"]
         VAR_SCROLL_Y = result["ScrollY"]
         VAR_CURSOR_X = result["CursorX"]
         VAR_CURSOR_Y = result["CursorY"]
         VAR_BROWSER_WIDTH = result["Width"]
         VAR_BROWSER_HEIGHT = result["Height"]
         })();
         

         
         
         /*Browser*/
         mouse(VAR_CURSOR_X,VAR_CURSOR_Y)!
         

      })!
      

      
      
      /*Browser*/
      move(VAR_X_L + VAR_TEMP_INDEX,VAR_Y_L + (VAR_HEIGHT_DATA/2) - 5,  {} )!
      mouse(VAR_X_L + VAR_TEMP_INDEX,VAR_Y_L + (VAR_HEIGHT_DATA/2) - 5)!
      

   }
   

function GoodXevilPaySolver_GXP_CleanProfPath()
   {
   
      
      
      _L["Path"] = {"ru":"Путь"};
      _L["To path"] = {"ru":"До пути"};
      _L["From path"] = {"ru":"От пути"};
      _L["Path object"] = {"ru":"Объект пути"};
      _L["File extension to remove"] = {"ru":"Удаляемое расширение файла"};
      _path = {
      sep: '/',
      delimiter: ';',
      isPathSeparator: function(code){
      return code===47 || code===92;
      },
      isDeviceRoot: function(code){
      return code >= 65 && code <= 90 || code >= 97 && code <= 122;
      },
      normalizeString: function(path, allowAboveRoot){
      var res = '';
      var lastSegmentLength = 0;
      var lastSlash = -1;
      var dots = 0;
      var code = 0;
      for(var i = 0; i <= path.length; ++i){
      if(i < path.length){
      code = path.charCodeAt(i);
      }else if(this.isPathSeparator(code)){
      break;
      }else{
      code = 47;
      };
      if(this.isPathSeparator(code)){
      if(lastSlash===i-1 || dots===1){
      }else if(dots === 2){
      if(res.length < 2 || !(lastSegmentLength===2) || !(res.charCodeAt(res.length-1)===46) || !(res.charCodeAt(res.length-2)===46)){
      if(res.length > 2){
      const lastSlashIndex = res.lastIndexOf(this.sep);
      if(lastSlashIndex===-1){
      res = '';
      lastSegmentLength = 0;
      }else{
      res = res.slice(0, lastSlashIndex);
      lastSegmentLength = res.length - 1 - res.lastIndexOf(this.sep);
      };
      lastSlash = i;
      dots = 0;
      continue;
      }else if(!(res.length===0)){
      res = '';
      lastSegmentLength = 0;
      lastSlash = i;
      dots = 0;
      continue;
      };
      };
      if(allowAboveRoot){
      res += res.length > 0 ? (this.sep + '..') : '..';
      lastSegmentLength = 2;
      };
      }else{
      if (res.length > 0){
      res += this.sep + path.slice(lastSlash + 1, i);
      }else{
      res = path.slice(lastSlash + 1, i);
      };
      lastSegmentLength = i - lastSlash - 1;
      };
      lastSlash = i;
      dots = 0;
      }else if(code===46 && !(dots===-1)){
      ++dots;
      }else{
      dots = -1;
      };
      };
      return res;
      },
      resolve: function(args){
      if(!Array.isArray(args)){
      args = Array.prototype.slice.call(arguments);
      };
      var resolvedDevice = '';
      var resolvedTail = '';
      var resolvedAbsolute = false;
      for(var i = args.length - 1; i > -1; i--){
      var path = args[i];
      _validate_argument_type(path, 'string', 'Path', '_path.resolve');
      if(path.length===0){
      continue;
      };
      const len = path.length;
      var rootEnd = 0;
      var device = '';
      var isAbsolute = false;
      const code = path.charCodeAt(0);
      if(len===1){
      if(this.isPathSeparator(code)){
      rootEnd = 1;
      isAbsolute = true;
      };
      }else if(this.isPathSeparator(code)){
      isAbsolute = true;
      if(this.isPathSeparator(path.charCodeAt(1))){
      var j = 2;
      var last = j;
      while(j < len && !this.isPathSeparator(path.charCodeAt(j))){
      j++;
      };
      if(j < len && !(j===last)){
      const firstPart = path.slice(last, j);
      last = j;
      while(j < len && this.isPathSeparator(path.charCodeAt(j))){
      j++;
      };
      if(j < len && !(j===last)){
      last = j;
      while(j < len && !this.isPathSeparator(path.charCodeAt(j))){
      j++;
      };
      if(j===len || !(j===last)){
      device = this.sep + this.sep + firstPart + this.sep + path.slice(last, j);
      rootEnd = j;
      };
      };
      };
      }else{
      rootEnd = 1;
      };
      }else if(this.isDeviceRoot(code) && path.charCodeAt(1)===58){
      device = path.slice(0, 2);
      rootEnd = 2;
      if(len > 2 && this.isPathSeparator(path.charCodeAt(2))){
      isAbsolute = true;
      rootEnd = 3;
      };
      };
      if(device.length > 0){
      if(resolvedDevice.length > 0){
      if(!(device.toLowerCase()===resolvedDevice.toLowerCase())){
      continue;
      };
      }else{
      resolvedDevice = device;
      };
      };
      if(resolvedAbsolute){
      if(resolvedDevice.length > 0){
      break;
      };
      }else{
      resolvedTail = path.slice(rootEnd) + this.sep + resolvedTail;
      resolvedAbsolute = isAbsolute;
      if(isAbsolute && resolvedDevice.length > 0){
      break;
      };
      };
      };
      resolvedTail = this.normalizeString(resolvedTail, !resolvedAbsolute);
      return resolvedAbsolute ? resolvedDevice + this.sep + resolvedTail : (resolvedDevice + resolvedTail) || '.';
      },
      normalize: function(path, removeTrailingSlash){
      _validate_argument_type(path, 'string', 'Path', '_path.normalize');
      removeTrailingSlash = _avoid_nilb(removeTrailingSlash, true);
      _validate_argument_type(removeTrailingSlash, ['boolean', 'number'], 'Remove trailing slashes', '_path.normalize');
      const len = path.length;
      if(len===0){
      return '';
      };
      var rootEnd = 0;
      var device = undefined;
      var isAbsolute = false;
      const code = path.charCodeAt(0);
      if(len===1){
      return this.isPathSeparator(code) ? (removeTrailingSlash ? '' : this.sep) : path;
      };
      if(this.isPathSeparator(code)){
      isAbsolute = true;
      if(this.isPathSeparator(path.charCodeAt(1))){
      var j = 2;
      var last = j;
      while (j < len && !this.isPathSeparator(path.charCodeAt(j))){
      j++;
      };
      if(j < len && !(j===last)){
      const firstPart = path.slice(last, j);
      last = j;
      while (j < len && this.isPathSeparator(path.charCodeAt(j))){
      j++;
      };
      if(j < len && !(j===last)){
      last = j;
      while (j < len && !this.isPathSeparator(path.charCodeAt(j))){
      j++;
      };
      if(j===len){
      return (this.sep + this.sep + firstPart + this.sep + path.slice(last) + (removeTrailingSlash ? '' : this.sep));
      };
      if(!(j===last)){
      device = this.sep + this.sep + firstPart + this.sep + path.slice(last, j);
      rootEnd = j;
      };
      };
      };
      }else{
      rootEnd = 1;
      };
      }else if(this.isDeviceRoot(code) && path.charCodeAt(1)===58){
      device = path.slice(0, 2);
      rootEnd = 2;
      if(len > 2 && this.isPathSeparator(path.charCodeAt(2))){
      isAbsolute = true;
      rootEnd = 3;
      };
      };
      var tail = rootEnd < len ? this.normalizeString(path.slice(rootEnd), !isAbsolute) : '';
      if(tail.length > 0 && this.isPathSeparator(path.charCodeAt(len - 1)) && !removeTrailingSlash){
      tail += this.sep;
      };
      if(device===undefined){
      return isAbsolute ? ((tail.length===0 && removeTrailingSlash ? '' : this.sep) + tail) : tail;
      };
      return isAbsolute ? (device + (tail.length===0 && removeTrailingSlash ? '' : this.sep) + tail) : (device + tail);
      },
      isAbsolute: function(path){
      _validate_argument_type(path, 'string', 'Path', '_path.isAbsolute');
      const len = path.length;
      if(len===0){
      return false;
      };
      const code = path.charCodeAt(0);
      return this.isPathSeparator(code) || len > 2 && this.isDeviceRoot(code) && path.charCodeAt(1) === 58 && this.isPathSeparator(path.charCodeAt(2));
      },
      join: function(args){
      if(!Array.isArray(args)){
      args = Array.prototype.slice.call(arguments);
      };
      if(args.length===0){
      return '.';
      };
      var joined = undefined;
      var firstPart = undefined;
      for(var i = 0; i < args.length; ++i){
      const arg = args[i];
      _validate_argument_type(arg, 'string', 'Path', '_path.join');
      if(arg.length > 0){
      if(joined === undefined){
      joined = firstPart = arg;
      }else{
      joined += (this.sep + arg);
      };
      };
      };
      if(joined === undefined){
      return '.';
      };
      var needsReplace = true;
      var slashCount = 0;
      if(this.isPathSeparator(firstPart.charCodeAt(0))){
      ++slashCount;
      const firstLen = firstPart.length;
      if(firstLen > 1 && this.isPathSeparator(firstPart.charCodeAt(1))){
      ++slashCount;
      if(firstLen > 2){
      if(this.isPathSeparator(firstPart.charCodeAt(2))){
      ++slashCount;
      }else{
      needsReplace = false;
      };
      };
      };
      };
      if(needsReplace){
      while(slashCount < joined.length && this.isPathSeparator(joined.charCodeAt(slashCount))){
      slashCount++;
      };
      if(slashCount >= 2){
      joined = this.sep + joined.slice(slashCount);
      };
      };
      return this.normalize(joined);
      },
      relative: function(from, to){
      _validate_argument_type(from, 'string', 'From path', '_path.relative');
      _validate_argument_type(to, 'string', 'To path', '_path.relative');
      if(from===to){
      return '';
      };
      const fromOrig = this.resolve(from);
      const toOrig = this.resolve(to);
      if(fromOrig===toOrig){
      return '';
      };
      from = fromOrig.toLowerCase();
      to = toOrig.toLowerCase();
      if(from===to){
      return '';
      };
      var fromStart = 0;
      while(fromStart < from.length && from.charCodeAt(fromStart)===this.sep.charCodeAt(0)){
      fromStart++;
      };
      var fromEnd = from.length;
      while(fromEnd - 1 > fromStart && from.charCodeAt(fromEnd - 1)===this.sep.charCodeAt(0)){
      fromEnd--;
      };
      const fromLen = fromEnd - fromStart;
      var toStart = 0;
      while(toStart < to.length && to.charCodeAt(toStart)===this.sep.charCodeAt(0)){
      toStart++;
      };
      var toEnd = to.length;
      while(toEnd - 1 > toStart && to.charCodeAt(toEnd - 1)===this.sep.charCodeAt(0)){
      toEnd--;
      };
      const toLen = toEnd - toStart;
      const length = fromLen < toLen ? fromLen : toLen;
      var lastCommonSep = -1;
      var i = 0;
      for(; i < length; i++){
      const fromCode = from.charCodeAt(fromStart + i);
      if(!(fromCode===to.charCodeAt(toStart + i))){
      break;
      }else if(fromCode===this.sep.charCodeAt(0)){
      lastCommonSep = i;
      };
      };
      if(!(i===length)){
      if(lastCommonSep===-1){
      return toOrig;
      };
      }else{
      if(toLen > length){
      if(to.charCodeAt(toStart + i)===this.sep.charCodeAt(0)){
      return toOrig.slice(toStart + i + 1);
      };
      if(i===2){
      return toOrig.slice(toStart + i);
      };
      };
      if(fromLen > length){
      if(from.charCodeAt(fromStart + i)===this.sep.charCodeAt(0)){
      lastCommonSep = i;
      }else if(i===2){
      lastCommonSep = 3;
      };
      };
      if(lastCommonSep===-1){
      lastCommonSep = 0;
      };
      };
      var out = '';
      for(i = fromStart + lastCommonSep + 1; i <= fromEnd; ++i){
      if(i===fromEnd || from.charCodeAt(i)===this.sep.charCodeAt(0)){
      out += out.length===0 ? '..' : this.sep + '..';
      };
      };
      toStart += lastCommonSep;
      if(out.length > 0){
      return out + toOrig.slice(toStart, toEnd);
      };
      if(toOrig.charCodeAt(toStart)===this.sep.charCodeAt(0)){
      ++toStart;
      };
      return toOrig.slice(toStart, toEnd);
      },
      toNamespacedPath: function(path){
      if(typeof path!='string'){
      return path;
      };
      if(path.length===0){
      return '';
      };
      const resolvedPath = this.resolve(path);
      if(resolvedPath.length <= 2){
      return path;
      };
      if(resolvedPath.charCodeAt(0)===this.sep.charCodeAt(0)){
      if(resolvedPath.charCodeAt(1)===this.sep.charCodeAt(0)){
      const code = resolvedPath.charCodeAt(2);
      if(!(code===63) && !(code===46)){
      return (this.sep + this.sep + '?' + this.sep + 'UNC' + this.sep + resolvedPath.slice(2));
      };
      };
      }else if(this.isDeviceRoot(resolvedPath.charCodeAt(0)) && resolvedPath.charCodeAt(1)===58 && resolvedPath.charCodeAt(2)===this.sep.charCodeAt(0)){
      return (this.sep + this.sep + '?' + this.sep + resolvedPath);
      };
      return path;
      },
      dirname: function(path){
      _validate_argument_type(path, 'string', 'Path', '_path.dirname');
      const len = path.length;
      if(len===0){
      return '.';
      };
      var rootEnd = -1;
      var offset = 0;
      const code = path.charCodeAt(0);
      if(len===1){
      return this.isPathSeparator(code) ? path : '.';
      };
      if(this.isPathSeparator(code)){
      rootEnd = offset = 1;
      if(this.isPathSeparator(path.charCodeAt(1))){
      var j = 2;
      var last = j;
      while(j < len && !this.isPathSeparator(path.charCodeAt(j))){
      j++;
      };
      if(j < len && !(j===last)){
      last = j;
      while(j < len && this.isPathSeparator(path.charCodeAt(j))){
      j++;
      };
      if(j < len && !(j===last)){
      last = j;
      while (j < len && !this.isPathSeparator(path.charCodeAt(j))){
      j++;
      };
      if(j===len){
      return path;
      };
      if(!(j===last)){
      rootEnd = offset = j + 1;
      };
      };
      };
      };
      }else if(this.isDeviceRoot(code) && path.charCodeAt(1)===58){
      rootEnd = len > 2 && this.isPathSeparator(path.charCodeAt(2)) ? 3 : 2;
      offset = rootEnd;
      };
      var end = -1;
      var matchedSlash = true;
      for(var i = len - 1; i >= offset; --i){
      if(this.isPathSeparator(path.charCodeAt(i))){
      if(!matchedSlash){
      end = i;
      break;
      };
      }else{
      matchedSlash = false;
      };
      };
      if(end===-1){
      if(rootEnd===-1){
      return '.';
      };
      end = rootEnd;
      };
      return path.slice(0, end);
      },
      basename: function(path, ext){
      _validate_argument_type(path, 'string', 'Path', '_path.basename');
      _validate_argument_type(ext, ['string','undefined','null'], 'File extension to remove', '_path.basename');
      var start = 0;
      var end = -1;
      var matchedSlash = true;
      var i = 0;
      if(path.length >= 2 && this.isDeviceRoot(path.charCodeAt(0)) && path.charCodeAt(1)===58){
      start = 2;
      };
      if(!(_is_nilb(ext)) && ext.length > 0 && ext.length <= path.length){
      if(ext===path){
      return '';
      };
      var extIdx = ext.length - 1;
      var firstNonSlashEnd = -1;
      for(i = path.length - 1; i >= start; --i){
      const code = path.charCodeAt(i);
      if(this.isPathSeparator(code)){
      if(!matchedSlash){
      start = i + 1;
      break;
      };
      }else{
      if(firstNonSlashEnd===-1){
      matchedSlash = false;
      firstNonSlashEnd = i + 1;
      };
      if(ext==='*'){
      if(code===46 && end===-1){
      end = i;
      };
      }else{
      if(extIdx >= 0){
      if(code===ext.charCodeAt(extIdx)){
      if(--extIdx===-1){
      end = i;
      };
      }else{
      extIdx = -1;
      end = firstNonSlashEnd;
      };
      };
      };
      };
      };
      if(start===end){
      end = firstNonSlashEnd;
      }else if(end === -1){
      end = path.length;
      };
      return path.slice(start, end);
      };
      for(i = path.length - 1; i >= start; --i){
      if(this.isPathSeparator(path.charCodeAt(i))){
      if(!matchedSlash){
      start = i + 1;
      break;
      };
      }else if(end===-1){
      matchedSlash = false;
      end = i + 1;
      };
      };
      if(end===-1){
      return '';
      };
      return path.slice(start, end);
      },
      extname: function(path){
      _validate_argument_type(path, 'string', 'Path', '_path.extname');
      var start = 0;
      var startDot = -1;
      var startPart = 0;
      var end = -1;
      var matchedSlash = true;
      var preDotState = 0;
      if(path.length >= 2 && path.charCodeAt(1)===58 && this.isDeviceRoot(path.charCodeAt(0))){
      start = startPart = 2;
      };
      for(var i = path.length - 1; i >= start; --i){
      const code = path.charCodeAt(i);
      if(this.isPathSeparator(code)){
      if(!matchedSlash){
      startPart = i + 1;
      break;
      };
      continue;
      };
      if(end===-1){
      matchedSlash = false;
      end = i + 1;
      };
      if(code===46){
      if(startDot===-1){
      startDot = i;
      }else if(!(preDotState===1)){
      preDotState = 1;
      };
      }else if(!(startDot===-1)){
      preDotState = -1;
      };
      };
      if(startDot===-1 || end===-1 || preDotState===0 || (preDotState===1 && startDot===end - 1 && startDot===startPart + 1)){
      return '';
      };
      return path.slice(startDot, end);
      },
      format: function(pathObject){
      _validate_argument_type(pathObject, 'object', 'Path object', '_path.format');
      var dir = pathObject.dir || pathObject.root;
      var base = pathObject.base || (pathObject.name || '' + pathObject.ext || '');
      if(!dir){
      return base;
      };
      return dir===pathObject.root ? (dir + base) : (dir + this.sep + base);
      },
      parse: function(path){
      _validate_argument_type(path, 'string', 'Path', '_path.parse');
      const ret = { root: '', dir: '', base: '', ext: '', name: '', items: [] };
      if(path.length===0){
      return ret;
      };
      const len = path.length;
      var rootEnd = 0;
      var code = path.charCodeAt(0);
      if(len===1){
      if(this.isPathSeparator(code)){
      ret.root = ret.dir = path;
      return ret;
      };
      ret.base = ret.name = ret.items[0] = path;
      return ret;
      };
      ret.items = path.split(/[\\/]+/).filter(function(el){return el.length > 0});
      if(this.isPathSeparator(code)){
      rootEnd = 1;
      if(this.isPathSeparator(path.charCodeAt(1))){
      var j = 2;
      var last = j;
      while(j < len && !this.isPathSeparator(path.charCodeAt(j))){
      j++;
      };
      if(j < len && !(j===last)){
      last = j;
      while (j < len && this.isPathSeparator(path.charCodeAt(j))){
      j++;
      };
      if(j < len && !(j===last)){
      last = j;
      while (j < len && !this.isPathSeparator(path.charCodeAt(j))){
      j++;
      };
      if(j===len){
      rootEnd = j;
      }else if(!(j===last)){
      rootEnd = j + 1;
      };
      };
      };
      };
      }else if(this.isDeviceRoot(code) && path.charCodeAt(1)===58){
      if(len <= 2){
      ret.root = ret.dir = path;
      return ret;
      };
      rootEnd = 2;
      if(this.isPathSeparator(path.charCodeAt(2))){
      if (len===3){
      ret.root = ret.dir = path;
      return ret;
      };
      rootEnd = 3;
      };
      };
      if(rootEnd > 0){
      ret.root = path.slice(0, rootEnd);
      };
      var startDot = -1;
      var startPart = rootEnd;
      var end = -1;
      var matchedSlash = true;
      var i = path.length - 1;
      var preDotState = 0;
      for(; i >= rootEnd; --i){
      code = path.charCodeAt(i);
      if(this.isPathSeparator(code)){
      if(!matchedSlash){
      startPart = i + 1;
      break;
      };
      continue;
      };
      if(end===-1){
      matchedSlash = false;
      end = i + 1;
      };
      if(code===46){
      if(startDot===-1){
      startDot = i;
      }else if(!(preDotState===1)){
      preDotState = 1;
      };
      }else if(!(startDot===-1)){
      preDotState = -1;
      };
      };
      if(!(end===-1)){
      if(startDot===-1 || preDotState === 0 || (preDotState===1 && startDot===end-1 && startDot===startPart+1)){
      ret.base = ret.name = path.slice(startPart, end);
      }else{
      ret.name = path.slice(startPart, startDot);
      ret.base = path.slice(startPart, end);
      ret.ext = path.slice(startDot, end);
      };
      };
      if(startPart > 0 && !(startPart===rootEnd)){
      ret.dir = path.slice(0, startPart - 1);
      }else{
      ret.dir = ret.root;
      };
      return ret;
      }
      };
      function project_directory(){
      var path = project_path();
      var c = '';
      var s = 0;
      var end = -1;
      for(var i = path.length - 1; i > -1; i--){
      if(_path.isPathSeparator(path.charCodeAt(i))){
      s++;
      if(c==='appsremote' || c==='appslocal'){
      end = i;
      break;
      }else{
      if(s===1){
      end = i;
      if(!(c==='project.xml')){
      break;
      };
      };
      if(s===2 && !(c==='engine')){
      break;
      };
      c = '';
      };
      }else{
      c = path.charAt(i) + c;
      };
      };
      return end===-1 ? _path.dirname(path) : path.slice(0, end);
      };
      function installation_path(){
      return JSON.parse(native("filesystem", "fileinfo", "settings.ini")).directory;
      };
      function _get_system_data(){
      RANDOM_FILE = "temp_" + rand() + ".bat";
      native("filesystem","writefile",JSON.stringify({path:RANDOM_FILE,value:"chcp 65001\r\nSET",base64:false,append:false}));
      native_async("processmanager","start",JSON.stringify({location:RANDOM_FILE,working_folder:"",waitfinish:true,arguments:"",version:2}))!
      var data_list = base64_decode(_result().split(",")[0]).split('\r\n').slice(2,-1);
      sleep(1000)!
      native("filesystem","removefile",RANDOM_FILE);
      SYSTEM_ENV_DATA = {};
      for(var i = 0; i < data_list.length; i++){
      if(data_list[i].indexOf('=') > -1){
      var data = data_list[i].split('=');
      var name = data[0];
      var value = data[1];
      SYSTEM_ENV_DATA[name] = value.indexOf("\\") > -1 ? _path.normalize(value) : value;
      };
      };
      if(SYSTEM_ENV_DATA["USERPROFILE"]){
      ["Desktop","Downloads","Documents","Pictures","Videos","Music","Favorites"].forEach(function(e){SYSTEM_ENV_DATA[e] = _path.join(SYSTEM_ENV_DATA["USERPROFILE"], e)});
      };
      };
      function _get_system_path(){
      var name = _function_argument("name");
      _if(typeof SYSTEM_ENV_DATA=="undefined",function(){
      _call_function(_get_system_data,{})!
      _result_function();
      })!
      var labels = {
      "App Data":"APPDATA",
      "Local App Data": "LOCALAPPDATA",
      "Program Files":"ProgramFiles",
      "Program Files (x86)":"ProgramFiles(x86)",
      "Program Data":"ProgramData",
      "Public":"PUBLIC",
      "System Drive":"SystemDrive",
      "System Root":"SystemRoot",
      "Windows Directory":"windir",
      "Temp":"TEMP",
      "User Name":"USERNAME",
      "User Profile":"USERPROFILE",
      "Computer Name":"COMPUTERNAME"
      };
      var label = _avoid_nilb(labels[name], name);
      if(_is_nilb(SYSTEM_ENV_DATA[label])){
      fail(_K=="ru" ? 'Не удалось найти путь "' + name + '" в системных данных.' : 'Could not find path "' + name + '" in system data.');
      };
      _function_return(SYSTEM_ENV_DATA[label]);
      };
      

      
      
      VAR_INSTALLATION_PATH = installation_path();
      

      
      
      native_async("filesystem", "search", JSON.stringify({folder: VAR_INSTALLATION_PATH + "/prof",mask: "*",contains:"",include_folders:true,include_files:false,recursive:false}))!
      VAR_FILE_SEARCH_RESULT = JSON.parse(_result())["d"]
      

      
      
      _do_with_params({"foreach_data":(VAR_FILE_SEARCH_RESULT)},function(){
      _set_action_info({ name: "Foreach" });
      VAR_CYCLE_INDEX = _iterator() - 1
      if(VAR_CYCLE_INDEX > _cycle_param("foreach_data").length - 1)_break();
      VAR_FOREACH_DATA = _cycle_param("foreach_data")[VAR_CYCLE_INDEX]
      
         
         
         _call(function()
         {
         _on_fail(function(){
         VAR_LAST_ERROR = _result()
         VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
         VAR_WAS_ERROR = false
         _break(1,true)
         })
         CYCLES.Current().RemoveLabel("function")
         
            
            
            native("filesystem", "removefile", VAR_FOREACH_DATA)
            

         },null)!
         

      })!
      

   }
   

function GoodXevilPaySolver_GXP_AutoConfirmCallback_ReCaptcha()
   {
   
      
      
      VAR_SAVED_CONTENT = _function_argument("token")
      

      
      
      VAR_TEMP_DATA2 = ""
      

      
      
      VAR_TEMP_DATA = ""
      

      
      
      _do(function(){
      _set_action_info({ name: "While" });
      VAR_CYCLE_INDEX = _iterator() - 1
      BREAK_CONDITION = VAR_TEMP_DATA == "";
      if(!BREAK_CONDITION)_break();
      
         
         
         _set_if_expression("W1tDWUNMRV9JTkRFWF1dICE9IDA=");
         _if(VAR_CYCLE_INDEX != 0,function(){
         
            
            
            sleep(500)!
            

         })!
         

         
         
         _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gMzA=");
         _if(VAR_CYCLE_INDEX > 30,function(){
         
            
            
            fail((_K==="en" ? "ReCaptcha is not detected on the page" : "ReCaptcha не обнаружена на странице"));
            

         })!
         

         
         
         _call(function()
         {
         _on_fail(function(){
         VAR_LAST_ERROR = _result()
         VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
         VAR_WAS_ERROR = false
         _break(1,true)
         })
         CYCLES.Current().RemoveLabel("function")
         
            
            
            page().script2("[[TEMP_DATA]] = window.widgetInfore;",JSON.stringify(_read_variables(["VAR_TEMP_DATA"])))!
            var _parse_result = JSON.parse(_result())
            _write_variables(JSON.parse(_parse_result.variables))
            if(!_parse_result.is_success)
            fail(_parse_result.error)
            

         },null)!
         

      })!
      

      
      
      _call(function()
      {
      _on_fail(function(){
      VAR_LAST_ERROR = _result()
      VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
      VAR_WAS_ERROR = false
      _break(1,true)
      })
      CYCLES.Current().RemoveLabel("function")
      
         
         
         /*Browser*/
         _SELECTOR = " \u003eCSS\u003eiframe[src*=\u0027anchor\u0027]\u003eFRAME\u003e \u003eXPATH\u003e //input[@id=\u0022recaptcha-token\u0022]";
         wait_element(_SELECTOR)!
         get_element_selector(_SELECTOR, false).set_attr("value", VAR_SAVED_CONTENT)!
         

      },null)!
      

      
      
      _call(function()
      {
      _on_fail(function(){
      VAR_LAST_ERROR = _result()
      VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
      VAR_WAS_ERROR = false
      _break(1,true)
      })
      CYCLES.Current().RemoveLabel("function")
      
         
         
         page().script2("var xpath = '//textarea[@name=\"g-recaptcha-response\"]';\r\nvar result = document.evaluate(xpath, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null);\r\nvar element = result.singleNodeValue;\r\n\r\nif (element) {\r\n  element.innerText = [[SAVED_CONTENT]];\r\n}\r\n",JSON.stringify(_read_variables(["VAR_SAVED_CONTENT"])))!
         var _parse_result = JSON.parse(_result())
         _write_variables(JSON.parse(_parse_result.variables))
         if(!_parse_result.is_success)
         fail(_parse_result.error)
         

      },null)!
      

      
      
      _call(function()
      {
      _on_fail(function(){
      VAR_LAST_ERROR = _result()
      VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
      VAR_WAS_ERROR = false
      _break(1,true)
      })
      CYCLES.Current().RemoveLabel("function")
      
         
         
         page().script2("if(window.widgetInfore.callback != null){\r\n    let func = window.widgetInfore.callback\r\n    let data = [[SAVED_CONTENT]];\r\n    window[func](data);\r\n}\r\n",JSON.stringify(_read_variables(["VAR_SAVED_CONTENT"])))!
         var _parse_result = JSON.parse(_result())
         _write_variables(JSON.parse(_parse_result.variables))
         if(!_parse_result.is_success)
         fail(_parse_result.error)
         

      },null)!
      

      
      
      _call(function()
      {
      _on_fail(function(){
      VAR_LAST_ERROR = _result()
      VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
      VAR_WAS_ERROR = false
      _break(1,true)
      })
      CYCLES.Current().RemoveLabel("function")
      
         
         
         page().script2("function getBindedElements(widget) {\r\n    let elements = {\r\n        button: null,\r\n        textarea: null,\r\n    };\r\n    if (widget.bindedButtonId) {\r\n        let button = document.querySelector(\"#\" + widget.bindedButtonId);\r\n        if (button.length) elements.button = button;\r\n    } else {\r\n        let textarea = document.querySelector(\"#\" + widget.containerId + \" textarea[name=g-recaptcha-response]\");\r\n        if (textarea.length) elements.textarea = textarea;\r\n    }\r\n    return elements;\r\n}  \r\n\r\nfunction getForm(widget) {\r\n    let binded = getBindedElements(widget);\r\n    if (binded.textarea) {\r\n        return binded.textarea.closest(\"form\");\r\n    }\r\n    return binded.button.closest(\"form\");\r\n}\r\n\r\nlet textarea = getBindedElements(window.widgetInfore).textarea;\r\nif (!textarea) {\r\n    textarea = getForm(window.widgetInfore).find(\"textarea[name=g-recaptcha-response]\");\r\n}\r\ntextarea.val([[SAVED_CONTENT]]);\r\n\r\nif(window.widgetInfore.callback != null){\r\n    let func = window.widgetInfore.callback\r\n    let data = [[SAVED_CONTENT]];\r\n    window[func](data);\r\n}",JSON.stringify(_read_variables(["VAR_SAVED_CONTENT"])))!
         var _parse_result = JSON.parse(_result())
         _write_variables(JSON.parse(_parse_result.variables))
         if(!_parse_result.is_success)
         fail(_parse_result.error)
         

      },null)!
      

      
      
      _call(function()
      {
      _on_fail(function(){
      VAR_LAST_ERROR = _result()
      VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
      VAR_WAS_ERROR = false
      _break(1,true)
      })
      CYCLES.Current().RemoveLabel("function")
      
         
         
         page().script2("function setRecaptchaToken(token, clientIdx = 0) {\r\n  var recap = window[\"___grecaptcha_cfg\"].clients[clientIdx];\r\n  Object.keys(recap).forEach(function(k) {\r\n      if (recap[k] != null && recap[k][k] != null && recap[k][k][\"callback\"] != null)  {\r\n           recap[k][k].callback(token);\r\n           console.log('recap token sumbited')\r\n           return;\r\n      } \r\n  });  \r\n}\r\n\r\nsetRecaptchaToken([[SAVED_CONTENT]])",JSON.stringify(_read_variables(["VAR_SAVED_CONTENT"])))!
         var _parse_result = JSON.parse(_result())
         _write_variables(JSON.parse(_parse_result.variables))
         if(!_parse_result.is_success)
         fail(_parse_result.error)
         

      },null)!
      

   }
   

function GoodXevilPaySolver_GXP_AutoConfirmCallback_Hcaptcha()
   {
   
      
      
      VAR_SAVED_CONTENT = _function_argument("token")
      

      
      
      VAR_TEMP_DATA2 = ""
      

      
      
      VAR_TEMP_DATA = ""
      

      
      
      _do(function(){
      _set_action_info({ name: "While" });
      VAR_CYCLE_INDEX = _iterator() - 1
      BREAK_CONDITION = VAR_TEMP_DATA == "";
      if(!BREAK_CONDITION)_break();
      
         
         
         _set_if_expression("W1tDWUNMRV9JTkRFWF1dICE9IDA=");
         _if(VAR_CYCLE_INDEX != 0,function(){
         
            
            
            sleep(500)!
            

         })!
         

         
         
         _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gMzA=");
         _if(VAR_CYCLE_INDEX > 30,function(){
         
            
            
            fail((_K==="en" ? "Hcaptcha is not detected on the page" : "Hcaptcha не обнаружена на странице"));
            

         })!
         

         
         
         _call(function()
         {
         _on_fail(function(){
         VAR_LAST_ERROR = _result()
         VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
         VAR_WAS_ERROR = false
         _break(1,true)
         })
         CYCLES.Current().RemoveLabel("function")
         
            
            
            page().script2("[[TEMP_DATA]] = window.captchaInfoh;",JSON.stringify(_read_variables(["VAR_TEMP_DATA"])))!
            var _parse_result = JSON.parse(_result())
            _write_variables(JSON.parse(_parse_result.variables))
            if(!_parse_result.is_success)
            fail(_parse_result.error)
            

         },null)!
         

         
         
         _set_if_expression("W1tURU1QX0RBVEFdXSA9PSAiIg==");
         _if(VAR_TEMP_DATA == "",function(){
         
            
            
            _call(function()
            {
            _on_fail(function(){
            VAR_LAST_ERROR = _result()
            VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
            VAR_WAS_ERROR = false
            _break(1,true)
            })
            CYCLES.Current().RemoveLabel("function")
            
               
               
               page().script2("[[TEMP_DATA2]] = window.captchaInfohtwo;",JSON.stringify(_read_variables(["VAR_TEMP_DATA2"])))!
               var _parse_result = JSON.parse(_result())
               _write_variables(JSON.parse(_parse_result.variables))
               if(!_parse_result.is_success)
               fail(_parse_result.error)
               

            },null)!
            

            
            
            _set_if_expression("W1tURU1QX0RBVEEyXV0gIT0gIiI=");
            _if(VAR_TEMP_DATA2 != "",function(){
            
               
               
               _call(function()
               {
               _on_fail(function(){
               VAR_LAST_ERROR = _result()
               VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
               VAR_WAS_ERROR = false
               _break(1,true)
               })
               CYCLES.Current().RemoveLabel("function")
               
                  
                  
                  page().script2("[[TEMP_DATA]] = window.captchaInfoh;",JSON.stringify(_read_variables(["VAR_TEMP_DATA"])))!
                  var _parse_result = JSON.parse(_result())
                  _write_variables(JSON.parse(_parse_result.variables))
                  if(!_parse_result.is_success)
                  fail(_parse_result.error)
                  

               },null)!
               

               
               
               _set_if_expression("W1tURU1QX0RBVEFdXSA9PSAiIg==");
               _if(VAR_TEMP_DATA == "",function(){
               
                  
                  
                  VAR_TEMP_DATA = VAR_TEMP_DATA2
                  

               })!
               

            })!
            

         })!
         

      })!
      

      
      
      _call(function()
      {
      _on_fail(function(){
      VAR_LAST_ERROR = _result()
      VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
      VAR_WAS_ERROR = false
      _break(1,true)
      })
      CYCLES.Current().RemoveLabel("function")
      
         
         
         page().script2("let container = document.querySelector('#'+window.captchaInfohtwo.containerId);\r\n  for(let area of container.querySelectorAll(\"textarea\")){\r\n    area.value = [[SAVED_CONTENT]];\r\n  }\r\n  for(let frame of container.querySelectorAll(\"iframe\")){\r\n    frame.setAttribute(\"data-hcaptcha-response\", [[SAVED_CONTENT]]);\r\n  }\r\n  if(window.captchaInfohtwo.callback != null){\r\n    let textarea = document.createElement('textarea');\r\n    textarea.id = 'callback-trigger';\r\n    textarea.setAttribute('data-function', window.captchaInfohtwo.callback);\r\n    textarea.value = [[SAVED_CONTENT]];\r\n    document.body.appendChild(textarea);\r\n    textarea = document.querySelector('textarea[id=callback-trigger]');\r\n    let func = textarea.getAttribute('data-function');\r\n    let data = textarea.value;\r\n    textarea.remove();\r\n    window[func](data);\r\n  }",JSON.stringify(_read_variables(["VAR_SAVED_CONTENT"])))!
         var _parse_result = JSON.parse(_result())
         _write_variables(JSON.parse(_parse_result.variables))
         if(!_parse_result.is_success)
         fail(_parse_result.error)
         

      },null)!
      

      
      
      _set_if_expression("W1tXQVNfRVJST1JdXQ==");
      _if(typeof(VAR_WAS_ERROR) !== "undefined" ? (VAR_WAS_ERROR) : undefined,function(){
      
         
         
         VAR_ERROR_ID = parseInt(VAR_ERROR_ID) + parseInt(1)
         

      })!
      

      
      
      _call(function()
      {
      _on_fail(function(){
      VAR_LAST_ERROR = _result()
      VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
      VAR_WAS_ERROR = false
      _break(1,true)
      })
      CYCLES.Current().RemoveLabel("function")
      
         
         
         page().script2("let container = document.querySelector('#'+window.captchaInfoh.containerId);\r\n  for(let area of container.querySelectorAll(\"textarea\")){\r\n    area.value = [[SAVED_CONTENT]];\r\n  }\r\n  for(let frame of container.querySelectorAll(\"iframe\")){\r\n    frame.setAttribute(\"data-hcaptcha-response\", [[SAVED_CONTENT]]);\r\n  }\r\n  if(window.captchaInfoh.callback != null){\r\n    let textarea = document.createElement('textarea');\r\n    textarea.id = 'callback-trigger';\r\n    textarea.setAttribute('data-function', window.captchaInfoh.callback);\r\n    textarea.value = [[SAVED_CONTENT]];\r\n    document.body.appendChild(textarea);\r\n    textarea = document.querySelector('textarea[id=callback-trigger]');\r\n    let func = textarea.getAttribute('data-function');\r\n    let data = textarea.value;\r\n    textarea.remove();\r\n    window[func](data);\r\n  }",JSON.stringify(_read_variables(["VAR_SAVED_CONTENT"])))!
         var _parse_result = JSON.parse(_result())
         _write_variables(JSON.parse(_parse_result.variables))
         if(!_parse_result.is_success)
         fail(_parse_result.error)
         

      },null)!
      

      
      
      _call(function()
      {
      _on_fail(function(){
      VAR_LAST_ERROR = _result()
      VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
      VAR_WAS_ERROR = false
      _break(1,true)
      })
      CYCLES.Current().RemoveLabel("function")
      
         
         
         _set_if_expression("ZmFsc2U=");
         _if(false,function(){
         
            
            
            page().script2("var xpath = '//textarea[@name=\"g-recaptcha-response\"]';\r\nvar result = document.evaluate(xpath, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null);\r\nvar element = result.singleNodeValue;\r\n\r\nif (element) {\r\n  element.innerText = [[SAVED_CONTENT]];\r\n}\r\n\r\nvar xpath = '//textarea[@name=\"h-captcha-response\"]';\r\nvar result = document.evaluate(xpath, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null);\r\nvar element = result.singleNodeValue;\r\n\r\nif (element) {\r\n  element.innerText = [[SAVED_CONTENT]];\r\n}\r\n",JSON.stringify(_read_variables(["VAR_SAVED_CONTENT"])))!
            var _parse_result = JSON.parse(_result())
            _write_variables(JSON.parse(_parse_result.variables))
            if(!_parse_result.is_success)
            fail(_parse_result.error)
            

         })!
         

      },null)!
      

      
      
      _set_if_expression("W1tXQVNfRVJST1JdXQ==");
      _if(typeof(VAR_WAS_ERROR) !== "undefined" ? (VAR_WAS_ERROR) : undefined,function(){
      
         
         
         VAR_ERROR_ID = parseInt(VAR_ERROR_ID) + parseInt(1)
         

      })!
      

      
      
      _set_if_expression("W1tFUlJPUl9JRF1dID09IDI=");
      _if(VAR_ERROR_ID == 2,function(){
      
         
         
         fail((_K==="en" ? "Hcaptcha is not solved" : "Hcaptcha не решена"));
         

      })!
      

   }
   

function GoodXevilPaySolver_GXP_Viefaucet()
   {
   
      
      
      VAR_APIKEY = _function_argument("apikey")
      

      
      
      var regexp_result = native("regexp", "first", JSON.stringify({text: VAR_APIKEY,regexp:"([0-9A-Za-z]\u007b20,40\u007d)"}))
      if(regexp_result.length == 0)
      regexp_result = []
      else
      regexp_result = JSON.parse(regexp_result)
      VAR_ALL_MATCH = regexp_result.pop()
      if(typeof(VAR_ALL_MATCH) == 'undefined' || !VAR_ALL_MATCH)
      VAR_ALL_MATCH = ""
      VAR_APIKEY = regexp_result[0]
      if(typeof(VAR_APIKEY) == 'undefined' || !VAR_APIKEY)
      VAR_APIKEY = ""
      if(regexp_result.length == 0)
      {
      VAR_APIKEY = VAR_ALL_MATCH
      }
      

      
      
      /*Browser*/
      ;_SELECTOR=" \u003eXPATH\u003e //div[@class=\u0022captcha-solve\u0022]/img[@class=\u0022captcha-image\u0022]";
      get_element_selector(_SELECTOR, false).nowait().exist()!
      VAR_IS_EXISTS = _result() == 1
      _if(VAR_IS_EXISTS, function(){
      get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
      VAR_IS_EXISTS = _result().indexOf("true")>=0
      })!
      

      
      
      _do(function(){
      _set_action_info({ name: "While" });
      VAR_CYCLE_INDEX = _iterator() - 1
      BREAK_CONDITION = VAR_IS_EXISTS == false;
      if(!BREAK_CONDITION)_break();
      
         
         
         _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gMzA=");
         _if(VAR_CYCLE_INDEX > 30,function(){
         
            
            
            fail((_K==="en" ? "Didn't wait for the captcha image" : "Не дождался изображение капчи"));
            

         })!
         

         
         
         sleep(1000)!
         

         
         
         /*Browser*/
         ;_SELECTOR=" \u003eXPATH\u003e //div[@class=\u0022captcha-solve\u0022]/img[@class=\u0022captcha-image\u0022]";
         get_element_selector(_SELECTOR, false).nowait().exist()!
         VAR_IS_EXISTS = _result() == 1
         _if(VAR_IS_EXISTS, function(){
         get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
         VAR_IS_EXISTS = _result().indexOf("true")>=0
         })!
         

      })!
      

      
      
      /*Browser*/
      _SELECTOR = " \u003eXPATH\u003e //div[@class=\u0022captcha-solve\u0022]/img[@class=\u0022captcha-image\u0022]";
      wait_element(_SELECTOR)!
      get_element_selector(_SELECTOR, false).script("(function(){var rect = self.getBoundingClientRect();return (rect.left + positionx).toString() + '|' + (rect.top + positiony).toString() + '|' + (rect.right - rect.left).toString() + '|' + (rect.bottom - rect.top).toString()})();")!
      if(_result().length > 0)
      {
      var split = _result().split("|")
      VAR_X = parseInt(split[0])
      VAR_Y = parseInt(split[1])
      VAR_WIDTH = parseInt(split[2])
      VAR_HEIGHT = parseInt(split[3])
      }
      

      
      
      /*Browser*/
      page().script("document.documentElement.outerHTML")!
      VAR_SAVED_PAGE_HTML = _result()
      

      
      
      html_parser_xpath_parse(VAR_SAVED_PAGE_HTML)
      if((true) && !html_parser_xpath_exist("//div[@class=\u0022captcha-solve\u0022]/img[@class=\u0022captcha-image\u0022]/@src"))
      fail("Can't resolve query " + "//div[@class=\u0022captcha-solve\u0022]/img[@class=\u0022captcha-image\u0022]/@src");
      VAR_XPATH_XML = html_parser_xpath_xml("//div[@class=\u0022captcha-solve\u0022]/img[@class=\u0022captcha-image\u0022]/@src")
      

      
      
      VAR_SCAN_RESULT_LIST = native("regexp", "scan", JSON.stringify({text: VAR_XPATH_XML,regexp:"([A-Za-z0-9\u005c+/=]+)"}))
      if(VAR_SCAN_RESULT_LIST.length == 0)
      VAR_SCAN_RESULT_LIST = []
      else
      VAR_SCAN_RESULT_LIST = JSON.parse(VAR_SCAN_RESULT_LIST)
      

      
      
      VAR_IMAGE_DATA = ""
      

      
      
      VAR_TEMP_INDEX = 0
      

      
      
      _do_with_params({"foreach_data":(VAR_SCAN_RESULT_LIST)},function(){
      _set_action_info({ name: "Foreach" });
      VAR_CYCLE_INDEX = _iterator() - 1
      if(VAR_CYCLE_INDEX > _cycle_param("foreach_data").length - 1)_break();
      VAR_FOREACH_DATA = _cycle_param("foreach_data")[VAR_CYCLE_INDEX]
      
         
         
         _set_if_expression("W1tGT1JFQUNIX0RBVEFdXS5sZW5ndGggPiBbW1RFTVBfSU5ERVhdXQ==");
         _if(VAR_FOREACH_DATA.length > VAR_TEMP_INDEX,function(){
         
            
            
            VAR_TEMP_INDEX = VAR_FOREACH_DATA.length
            

            
            
            VAR_IMAGE_DATA = VAR_FOREACH_DATA
            

         })!
         

      })!
      

      
      
      _set_if_expression("W1tURU1QX0lOREVYXV0gPCA1MA==");
      _if(VAR_TEMP_INDEX < 50,function(){
      
         
         
         fail((_K==="en" ? "The image is too small" : "Слишком маленькое изображение"));
         

      })!
      

      
      
      _call(function()
      {
      _on_fail(function(){
      VAR_LAST_ERROR = _result()
      VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
      VAR_WAS_ERROR = false
      _break(1,true)
      })
      CYCLES.Current().RemoveLabel("function")
      
         
         
         solver_properties_clear("capmonster")
         solver_property("capmonster","serverurl","http://goodxevilpay.pp.ua/")
         solver_property("capmonster","key",VAR_APIKEY)
         solver_property("capmonster","method","viefaucet")
         solver_property("capmonster","body",VAR_IMAGE_DATA)
         solve_base64_no_fail("capmonster", "")!
         VAR_SAVED_CONTENT = _result();
         

      },null)!
      

      
      
      _set_if_expression("W1tXQVNfRVJST1JdXQ==");
      _if(typeof(VAR_WAS_ERROR) !== "undefined" ? (VAR_WAS_ERROR) : undefined,function(){
      
         
         
         _next("function")
         

      })!
      

      
      
      VAR_STRING_MATCHES = Boolean(native("regexp", "ismatch", JSON.stringify({text: VAR_SAVED_CONTENT,regexp:"(ERROR)"})) == "true")
      

      
      
      VAR_STRING_MATCHES2 = Boolean(native("regexp", "ismatch", JSON.stringify({text: VAR_SAVED_CONTENT,regexp:"(_FAIL)"})) == "true")
      

      
      
      VAR_STRING_MATCHES3 = Boolean(native("regexp", "ismatch", JSON.stringify({text: VAR_SAVED_CONTENT,regexp:"(_)"})) == "true")
      

      
      
      _set_if_expression("W1tTVFJJTkdfTUFUQ0hFU11dIHx8IFtbU1RSSU5HX01BVENIRVMyXV0gfHwgW1tTVFJJTkdfTUFUQ0hFUzNdXQ==");
      _if(VAR_STRING_MATCHES || VAR_STRING_MATCHES2 || VAR_STRING_MATCHES3,function(){
      
         
         
         fail((_K==="en" ? "The captcha is not solved" : "Капча не решена"));
         

      })!
      

      
      
      VAR_SCAN_RESULT_LIST = native("regexp", "scan", JSON.stringify({text: VAR_SAVED_CONTENT,regexp:"\u005cd+"}))
      if(VAR_SCAN_RESULT_LIST.length == 0)
      VAR_SCAN_RESULT_LIST = []
      else
      VAR_SCAN_RESULT_LIST = JSON.parse(VAR_SCAN_RESULT_LIST)
      

      
      
      VAR_LIST_LENGTH = (VAR_SCAN_RESULT_LIST).length
      

      
      
      _set_if_expression("W1tMSVNUX0xFTkdUSF1dICE9IDI=");
      _if(VAR_LIST_LENGTH != 2,function(){
      
         
         
         fail((_K==="en" ? "Unclear response from the server" : "Не понятный ответ от сервера"));
         

      })!
      

      
      
      VAR_X_XEVIL = parseInt(VAR_SCAN_RESULT_LIST[0]);
      VAR_Y_XEVIL = parseInt(VAR_SCAN_RESULT_LIST[1]);
      

      
      
      /*Browser*/
      move(VAR_X + VAR_X_XEVIL,VAR_Y + VAR_Y_XEVIL,  {} )!
      mouse(VAR_X + VAR_X_XEVIL,VAR_Y + VAR_Y_XEVIL)!
      

   }
   

function GoodXevilPaySolver_GXP_IMAGE_BASE64()
   {
   
      
      
      VAR_APIKEY = _function_argument("APIKEY")
      

      
      
      VAR_IMAGE_BASE64 = _function_argument("IMAGE_BASE64")
      

      
      
      var regexp_result = native("regexp", "first", JSON.stringify({text: VAR_APIKEY,regexp:"([0-9A-Za-z]\u007b20,40\u007d)"}))
      if(regexp_result.length == 0)
      regexp_result = []
      else
      regexp_result = JSON.parse(regexp_result)
      VAR_ALL_MATCH = regexp_result.pop()
      if(typeof(VAR_ALL_MATCH) == 'undefined' || !VAR_ALL_MATCH)
      VAR_ALL_MATCH = ""
      VAR_APIKEY = regexp_result[0]
      if(typeof(VAR_APIKEY) == 'undefined' || !VAR_APIKEY)
      VAR_APIKEY = ""
      if(regexp_result.length == 0)
      {
      VAR_APIKEY = VAR_ALL_MATCH
      }
      

      
      
      VAR_SCAN_RESULT_LIST = native("regexp", "scan", JSON.stringify({text: VAR_IMAGE_BASE64,regexp:"([A-Za-z0-9\u005c+/=]+)"}))
      if(VAR_SCAN_RESULT_LIST.length == 0)
      VAR_SCAN_RESULT_LIST = []
      else
      VAR_SCAN_RESULT_LIST = JSON.parse(VAR_SCAN_RESULT_LIST)
      

      
      
      VAR_IMAGE_DATA = ""
      

      
      
      VAR_TEMP_INDEX = 0
      

      
      
      _do_with_params({"foreach_data":(VAR_SCAN_RESULT_LIST)},function(){
      _set_action_info({ name: "Foreach" });
      VAR_CYCLE_INDEX = _iterator() - 1
      if(VAR_CYCLE_INDEX > _cycle_param("foreach_data").length - 1)_break();
      VAR_FOREACH_DATA = _cycle_param("foreach_data")[VAR_CYCLE_INDEX]
      
         
         
         _set_if_expression("W1tGT1JFQUNIX0RBVEFdXS5sZW5ndGggPiBbW1RFTVBfSU5ERVhdXQ==");
         _if(VAR_FOREACH_DATA.length > VAR_TEMP_INDEX,function(){
         
            
            
            VAR_TEMP_INDEX = VAR_FOREACH_DATA.length
            

            
            
            VAR_IMAGE_DATA = VAR_FOREACH_DATA
            

         })!
         

      })!
      

      
      
      _set_if_expression("W1tURU1QX0lOREVYXV0gPCA1MA==");
      _if(VAR_TEMP_INDEX < 50,function(){
      
         
         
         fail((_K==="en" ? "The image is too small" : "Слишком маленькое изображение"));
         

      })!
      

      
      
      solver_properties_clear("capmonster")
      solver_property("capmonster","serverurl","http://goodxevilpay.pp.ua/")
      solver_property("capmonster","key",VAR_APIKEY)
      solver_property("capmonster","method","base64")
      solver_property("capmonster","body",VAR_IMAGE_DATA)
      solve_base64_no_fail("capmonster", "")!
      VAR_SAVED_CONTENT = _result();
      

      
      
      _function_return(VAR_SAVED_CONTENT)
      

   }
   

function GoodXevilPaySolver_GXP_ProtonMail()
   {
   
      
      
      VAR_APIKEY = _function_argument("APIKEY")
      

      
      
      var regexp_result = native("regexp", "first", JSON.stringify({text: VAR_APIKEY,regexp:"([0-9A-Za-z]\u007b20,40\u007d)"}))
      if(regexp_result.length == 0)
      regexp_result = []
      else
      regexp_result = JSON.parse(regexp_result)
      VAR_ALL_MATCH = regexp_result.pop()
      if(typeof(VAR_ALL_MATCH) == 'undefined' || !VAR_ALL_MATCH)
      VAR_ALL_MATCH = ""
      VAR_APIKEY = regexp_result[0]
      if(typeof(VAR_APIKEY) == 'undefined' || !VAR_APIKEY)
      VAR_APIKEY = ""
      if(regexp_result.length == 0)
      {
      VAR_APIKEY = VAR_ALL_MATCH
      }
      

      
      
      /*Browser*/
      ;_SELECTOR="\u003eCSS\u003e iframe[src*=\u0027/captcha\u0027]\u003eFRAME\u003e \u003eCSS\u003e iframe[src*=\u0027/captcha\u0027]\u003eFRAME\u003e \u003eCSS\u003e canvas";
      get_element_selector(_SELECTOR, false).nowait().exist()!
      VAR_IS_EXISTS = _result() == 1
      _if(VAR_IS_EXISTS, function(){
      get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
      VAR_IS_EXISTS = _result().indexOf("true")>=0
      })!
      

      
      
      _set_if_expression("W1tJU19FWElTVFNdXSA9PSBmYWxzZQ==");
      _if(VAR_IS_EXISTS == false,function(){
      
         
         
         _call(function()
         {
         _on_fail(function(){
         VAR_LAST_ERROR = _result()
         VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
         VAR_WAS_ERROR = false
         _break(1,true)
         })
         CYCLES.Current().RemoveLabel("function")
         
            
            
            /*Browser*/
            waiter_timeout_next(15000)
            wait_async_load()!
            

         },null)!
         

         
         
         /*Browser*/
         ;_SELECTOR="\u003eCSS\u003e iframe[src*=\u0027/captcha\u0027]\u003eFRAME\u003e \u003eCSS\u003e iframe[src*=\u0027/captcha\u0027]\u003eFRAME\u003e \u003eCSS\u003e canvas";
         get_element_selector(_SELECTOR, false).nowait().exist()!
         VAR_IS_EXISTS = _result() == 1
         _if(VAR_IS_EXISTS, function(){
         get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
         VAR_IS_EXISTS = _result().indexOf("true")>=0
         })!
         

         
         
         _set_if_expression("W1tJU19FWElTVFNdXSA9PSBmYWxzZQ==");
         _if(VAR_IS_EXISTS == false,function(){
         
            
            
            fail((_K==="en" ? "No captcha found" : "Капча не найдена"));
            

         })!
         

      })!
      

      
      
      /*Browser*/
      _SELECTOR = "\u003eCSS\u003e iframe[src*=\u0027/captcha\u0027]\u003eFRAME\u003e \u003eCSS\u003e iframe[src*=\u0027/captcha\u0027]\u003eFRAME\u003e \u003eCSS\u003e canvas";
      wait_element(_SELECTOR)!
      get_element_selector(_SELECTOR, false).exist()!
      _if(_result() == "1", function(){
      get_element_selector(_SELECTOR, false).render_base64()!
      VAR_SCREENSHOT_BASE64 = _result()
      })!
      

      
      
      /*Browser*/
      _SELECTOR = "\u003eCSS\u003e iframe[src*=\u0027/captcha\u0027]\u003eFRAME\u003e \u003eCSS\u003e iframe[src*=\u0027/captcha\u0027]\u003eFRAME\u003e \u003eCSS\u003e canvas";
      wait_element(_SELECTOR)!
      get_element_selector(_SELECTOR, false).script("(function(){var rect = self.getBoundingClientRect();return (rect.left + positionx).toString() + '|' + (rect.top + positiony).toString() + '|' + (rect.right - rect.left).toString() + '|' + (rect.bottom - rect.top).toString()})();")!
      if(_result().length > 0)
      {
      var split = _result().split("|")
      VAR_X = parseInt(split[0])
      VAR_Y = parseInt(split[1])
      VAR_WIDTH = parseInt(split[2])
      VAR_HEIGHT = parseInt(split[3])
      }
      

      
      
      VAR_LOADED_IMAGE_ID = native("imageprocessing", "load", VAR_SCREENSHOT_BASE64)
      

      
      
      VAR_CROPPED_IMAGE_ID = native("imageprocessing", "sub", (VAR_LOADED_IMAGE_ID) + "," + (0) + "," + (60) + "," + (VAR_WIDTH) + "," + (VAR_HEIGHT - 60))
      

      
      
      VAR_IMAGE_DATA = native("imageprocessing", "getdata", VAR_CROPPED_IMAGE_ID)
      

      
      
      native("imageprocessing", "delete", VAR_CROPPED_IMAGE_ID)
      

      
      
      native("imageprocessing", "delete", VAR_LOADED_IMAGE_ID)
      

      
      
      solver_properties_clear("capmonster")
      solver_property("capmonster","serverurl","http://goodxevilpay.pp.ua/")
      solver_property("capmonster","key",VAR_APIKEY)
      solver_property("capmonster","method","protonmail")
      solver_property("capmonster","body",VAR_IMAGE_DATA)
      solve_base64_no_fail("capmonster", "")!
      VAR_SAVED_CONTENT = _result();
      

      
      
      VAR_SCAN_RESULT_LIST = native("regexp", "scan", JSON.stringify({text: VAR_SAVED_CONTENT,regexp:"\u005cd+"}))
      if(VAR_SCAN_RESULT_LIST.length == 0)
      VAR_SCAN_RESULT_LIST = []
      else
      VAR_SCAN_RESULT_LIST = JSON.parse(VAR_SCAN_RESULT_LIST)
      

      
      
      VAR_LIST_LENGTH = (VAR_SCAN_RESULT_LIST).length
      

      
      
      _set_if_expression("W1tMSVNUX0xFTkdUSF1dICE9IDI=");
      _if(VAR_LIST_LENGTH != 2,function(){
      
         
         
         fail((_K==="en" ? "Unclear response from the server" : "Не понятный ответ от сервера"));
         

      })!
      

      
      
      VAR_X_XEVIL = parseInt(VAR_SCAN_RESULT_LIST[0]);
      VAR_Y_XEVIL = parseInt(VAR_SCAN_RESULT_LIST[1]);
      

      
      
      /*Browser*/
      move(VAR_X + 32,VAR_Y + 32,  {} )!
      mouse_down(VAR_X + 32,VAR_Y + 32)!
      

      
      
      /*Browser*/
      var move_settings =  {"speed": 50,"gravity": 4,"deviation": 5} ;
      move_settings["do_mouse_up"] = "true"
      move(VAR_X + VAR_X_XEVIL,VAR_Y + VAR_Y_XEVIL + 60, move_settings)!
      

      
      
      /*Browser*/
      _SELECTOR = "\u003eCSS\u003e iframe[src*=\u0027/captcha\u0027]\u003eFRAME\u003e \u003eCSS\u003e iframe[src*=\u0027/captcha\u0027]\u003eFRAME\u003e \u003eCSS\u003e button\u003eAT\u003e0";
      wait_element_visible(_SELECTOR)!
      _call(_random_point, {})!
      _if(_result().length > 0, function(){
      move( {} )!
      get_element_selector(_SELECTOR, false).clarify(X,Y)!
      _call(_clarify, {} )!
      mouse(X,Y)!
      })!
      

   }
   

function GoodXevilPaySolver_GXP_SurfEarner_AllowCache()
   {
   
      
      
      /*Browser*/
      cache_allow("*captcha.surfearner.com/collage/preview.php?*")!
      

   }
   

function GoodXevilPaySolver_GXP_SurfEarner()
   {
   
      
      
      VAR_APIKEY = _function_argument("apikey")
      

      
      
      var regexp_result = native("regexp", "first", JSON.stringify({text: VAR_APIKEY,regexp:"([0-9A-Za-z]\u007b20,40\u007d)"}))
      if(regexp_result.length == 0)
      regexp_result = []
      else
      regexp_result = JSON.parse(regexp_result)
      VAR_ALL_MATCH = regexp_result.pop()
      if(typeof(VAR_ALL_MATCH) == 'undefined' || !VAR_ALL_MATCH)
      VAR_ALL_MATCH = ""
      VAR_APIKEY = regexp_result[0]
      if(typeof(VAR_APIKEY) == 'undefined' || !VAR_APIKEY)
      VAR_APIKEY = ""
      if(regexp_result.length == 0)
      {
      VAR_APIKEY = VAR_ALL_MATCH
      }
      

      
      
      /*Browser*/
      cache_allow("*captcha.surfearner.com/collage/preview.php?*")!
      

      
      
      VAR_NOW_ID_FRAME = ""
      

      
      
      _do(function(){
      _set_action_info({ name: "For" });
      VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(0)
      if(VAR_CYCLE_INDEX > parseInt(4))_break();
      
         
         
         _set_if_expression("W1tDWUNMRV9JTkRFWF1dID49IDM=");
         _if(VAR_CYCLE_INDEX >= 3,function(){
         
            
            
            fail((_K==="en" ? "The service was unable to solve the captcha in 3 attempts" : "Сервис не смог решить капчу за 3 попытки"));
            

         })!
         

         
         
         _set_if_expression("W1tDWUNMRV9JTkRFWF1dICE9IDA=");
         _if(VAR_CYCLE_INDEX != 0,function(){
         
            
            
            /*Browser*/
            ;_SELECTOR=VAR_NOW_ID_FRAME + " \u003eXPATH\u003e id(\u0022secaptcha-refresh\u0022)";
            get_element_selector(_SELECTOR, false).nowait().exist()!
            VAR_IS_EXISTS = _result() == 1
            _if(VAR_IS_EXISTS, function(){
            get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
            VAR_IS_EXISTS = _result().indexOf("true")>=0
            })!
            

            
            
            _cycle_params().if_else = typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined;
            _set_if_expression("W1tJU19FWElTVFNdXQ==");
            _if(_cycle_params().if_else,function(){
            
               
               
               /*Browser*/
               _SELECTOR = VAR_NOW_ID_FRAME + " \u003eXPATH\u003e id(\u0022secaptcha-refresh\u0022)";
               wait_element_visible(_SELECTOR)!
               _call(_random_point, {})!
               _if(_result().length > 0, function(){
               move( {} )!
               get_element_selector(_SELECTOR, false).clarify(X,Y)!
               _call(_clarify, {} )!
               mouse(X,Y)!
               })!
               

               
               
               sleep(1000)!
               

            })!
            

            
            
            _if(!_cycle_params().if_else,function(){
            
               
               
               fail((_K==="en" ? "Captcha was not found" : "Капча не найдена"));
               

            })!
            delete _cycle_params().if_else;
            

         })!
         

         
         
         /*Browser*/
         ;_SELECTOR=VAR_NOW_ID_FRAME + " \u003eXPATH\u003e id(\u0022secaptcha-wrap\u0022)";
         get_element_selector(_SELECTOR, false).nowait().exist()!
         VAR_IS_EXISTS = _result() == 1
         _if(VAR_IS_EXISTS, function(){
         get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
         VAR_IS_EXISTS = _result().indexOf("true")>=0
         })!
         

         
         
         _set_if_expression("W1tJU19FWElTVFNdXSA9PSBmYWxzZQ==");
         _if(VAR_IS_EXISTS == false,function(){
         
            
            
            VAR_NOW_ID_FRAME = "\u003eXPATH\u003e id(\u0022_se_visit_frame\u0022)\u003eFRAME\u003e"
            

            
            
            /*Browser*/
            ;_SELECTOR=VAR_NOW_ID_FRAME + " \u003eXPATH\u003e id(\u0022secaptcha-wrap\u0022)";
            get_element_selector(_SELECTOR, false).nowait().exist()!
            VAR_IS_EXISTS = _result() == 1
            _if(VAR_IS_EXISTS, function(){
            get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
            VAR_IS_EXISTS = _result().indexOf("true")>=0
            })!
            

            
            
            _set_if_expression("W1tJU19FWElTVFNdXSA9PSBmYWxzZQ==");
            _if(VAR_IS_EXISTS == false,function(){
            
               
               
               fail((_K==="en" ? "No captcha image found" : "Не найдено изображение капчи"));
               

            })!
            

         })!
         

         
         
         /*Browser*/
         wait_load("*captcha.surfearner.com/collage/preview.php?*")!
         cache_get_base64("*captcha.surfearner.com/collage/preview.php?*")!
         VAR_SAVED_CACHE = _result()
         

         
         
         _do(function(){
         _set_action_info({ name: "While" });
         VAR_CYCLE_INDEX = _iterator() - 1
         BREAK_CONDITION = VAR_SAVED_CACHE == "";
         if(!BREAK_CONDITION)_break();
         
            
            
            sleep(1000)!
            

            
            
            _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gMjA=");
            _if(VAR_CYCLE_INDEX > 20,function(){
            
               
               
               fail((_K==="en" ? "Captcha was not found" : "Капча не найдена"));
               

            })!
            

            
            
            _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gMTA=");
            _if(VAR_CYCLE_INDEX > 10,function(){
            
               
               
               /*Browser*/
               ;_SELECTOR=VAR_NOW_ID_FRAME + " \u003eXPATH\u003e id(\u0022secaptcha-refresh\u0022)";
               get_element_selector(_SELECTOR, false).nowait().exist()!
               VAR_IS_EXISTS = _result() == 1
               _if(VAR_IS_EXISTS, function(){
               get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
               VAR_IS_EXISTS = _result().indexOf("true")>=0
               })!
               

               
               
               _cycle_params().if_else = typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined;
               _set_if_expression("W1tJU19FWElTVFNdXQ==");
               _if(_cycle_params().if_else,function(){
               
                  
                  
                  /*Browser*/
                  _SELECTOR = VAR_NOW_ID_FRAME + " \u003eXPATH\u003e id(\u0022secaptcha-refresh\u0022)";
                  wait_element_visible(_SELECTOR)!
                  _call(_random_point, {})!
                  _if(_result().length > 0, function(){
                  move( {} )!
                  get_element_selector(_SELECTOR, false).clarify(X,Y)!
                  _call(_clarify, {} )!
                  mouse(X,Y)!
                  })!
                  

                  
                  
                  sleep(1000)!
                  

               })!
               

               
               
               _if(!_cycle_params().if_else,function(){
               
                  
                  
                  fail((_K==="en" ? "Captcha was not found" : "Капча не найдена"));
                  

               })!
               delete _cycle_params().if_else;
               

            })!
            

            
            
            /*Browser*/
            wait_load("*captcha.surfearner.com/collage/preview.php?*")!
            cache_get_base64("*captcha.surfearner.com/collage/preview.php?*")!
            VAR_SAVED_CACHE = _result()
            

         })!
         

         
         
         /*Browser*/
         cache_data_clear()!
         

         
         
         _call(function()
         {
         _on_fail(function(){
         VAR_LAST_ERROR = _result()
         VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
         VAR_WAS_ERROR = false
         _break(1,true)
         })
         CYCLES.Current().RemoveLabel("function")
         
            
            
            solver_properties_clear("capmonster")
            solver_property("capmonster","serverurl","http://goodxevilpay.pp.ua/")
            solver_property("capmonster","key",VAR_APIKEY)
            solver_property("capmonster","method","surfearner")
            solver_property("capmonster","body",VAR_SAVED_CACHE)
            solve_base64_no_fail("capmonster", "")!
            VAR_SAVED_CONTENT = _result();
            

         },null)!
         

         
         
         _set_if_expression("W1tXQVNfRVJST1JdXQ==");
         _if(typeof(VAR_WAS_ERROR) !== "undefined" ? (VAR_WAS_ERROR) : undefined,function(){
         
            
            
            _next("function")
            

         })!
         

         
         
         VAR_STRING_MATCHES = Boolean(native("regexp", "ismatch", JSON.stringify({text: VAR_SAVED_CONTENT,regexp:"(ERROR)"})) == "true")
         

         
         
         VAR_STRING_MATCHES2 = Boolean(native("regexp", "ismatch", JSON.stringify({text: VAR_SAVED_CONTENT,regexp:"(_FAIL)"})) == "true")
         

         
         
         _set_if_expression("W1tTVFJJTkdfTUFUQ0hFU11dIHx8IFtbU1RSSU5HX01BVENIRVMyXV0=");
         _if(VAR_STRING_MATCHES || VAR_STRING_MATCHES2,function(){
         
            
            
            _next("function")
            

         })!
         

         
         
         VAR_SCAN_RESULT_LIST = native("regexp", "scan", JSON.stringify({text: VAR_SAVED_CONTENT,regexp:"\u005cd+"}))
         if(VAR_SCAN_RESULT_LIST.length == 0)
         VAR_SCAN_RESULT_LIST = []
         else
         VAR_SCAN_RESULT_LIST = JSON.parse(VAR_SCAN_RESULT_LIST)
         

         
         
         VAR_LIST_LENGTH = (VAR_SCAN_RESULT_LIST).length
         

         
         
         _set_if_expression("W1tMSVNUX0xFTkdUSF1dICE9IDI=");
         _if(VAR_LIST_LENGTH != 2,function(){
         
            
            
            fail((_K==="en" ? "Unclear response from the server" : "Не понятный ответ от сервера"));
            

         })!
         

         
         
         /*Browser*/
         scroll(1,1)!
         

         
         
         /*Browser*/
         _SELECTOR = VAR_NOW_ID_FRAME + " \u003eXPATH\u003e id(\u0022secaptcha-wrap\u0022)";
         wait_element(_SELECTOR)!
         get_element_selector(_SELECTOR, false).script("(function(){var rect = self.getBoundingClientRect();return (rect.left + positionx).toString() + '|' + (rect.top + positiony).toString() + '|' + (rect.right - rect.left).toString() + '|' + (rect.bottom - rect.top).toString()})();")!
         if(_result().length > 0)
         {
         var split = _result().split("|")
         VAR_X = parseInt(split[0])
         VAR_Y = parseInt(split[1])
         VAR_WIDTH = parseInt(split[2])
         VAR_HEIGHT = parseInt(split[3])
         }
         

         
         
         VAR_X_XEVIL = parseInt(VAR_SCAN_RESULT_LIST[0]);
         VAR_Y_XEVIL = parseInt(VAR_SCAN_RESULT_LIST[1]);
         

         
         
         /*Browser*/
         move(VAR_X + VAR_X_XEVIL,VAR_Y + VAR_Y_XEVIL,  {} )!
         mouse(VAR_X + VAR_X_XEVIL,VAR_Y + VAR_Y_XEVIL)!
         

         
         
         _break("function")
         

      })!
      

   }
   

function GoodXevilPaySolver_GXP_BuxMoney_PayupVideo()
   {
   
      
      
      VAR_TIMER = _function_argument("timer")
      

      
      
      VAR_APIKEY = _function_argument("apikey")
      

      
      
      var regexp_result = native("regexp", "first", JSON.stringify({text: VAR_APIKEY,regexp:"([0-9A-Za-z]\u007b20,40\u007d)"}))
      if(regexp_result.length == 0)
      regexp_result = []
      else
      regexp_result = JSON.parse(regexp_result)
      VAR_ALL_MATCH = regexp_result.pop()
      if(typeof(VAR_ALL_MATCH) == 'undefined' || !VAR_ALL_MATCH)
      VAR_ALL_MATCH = ""
      VAR_APIKEY = regexp_result[0]
      if(typeof(VAR_APIKEY) == 'undefined' || !VAR_APIKEY)
      VAR_APIKEY = ""
      if(regexp_result.length == 0)
      {
      VAR_APIKEY = VAR_ALL_MATCH
      }
      

      
      
      VAR_URL = "goodxevilpay.pp.ua"
      

      
      
      /*Browser*/
      ;_SELECTOR=" \u003eXPATH\u003e //div[contains(@class, \u0022captcha\u0022) and contains(@class, \u0022task\u0022)]//*[contains(@style, \u0022base64\u0022)]";
      get_element_selector(_SELECTOR, false).nowait().exist()!
      VAR_IS_EXISTS = _result() == 1
      _if(VAR_IS_EXISTS, function(){
      get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
      VAR_IS_EXISTS = _result().indexOf("true")>=0
      })!
      

      
      
      VAR_GOOD_SOLVE = "0"
      

      
      
      _do(function(){
      _set_action_info({ name: "While" });
      VAR_CYCLE_INDEX = _iterator() - 1
      BREAK_CONDITION = VAR_IS_EXISTS == false;
      if(!BREAK_CONDITION)_break();
      
         
         
         _set_if_expression("W1tDWUNMRV9JTkRFWF1dID49IFtbVElNRVJdXQ==");
         _if(VAR_CYCLE_INDEX >= VAR_TIMER,function(){
         
            
            
            fail((_K==="en" ? "Captcha was not found" : "Капча не найдена"));
            

         })!
         

         
         
         sleep(1000)!
         

         
         
         /*Browser*/
         ;_SELECTOR=" \u003eXPATH\u003e //div[contains(@class, \u0022captcha\u0022) and contains(@class, \u0022task\u0022)]//*[contains(@style, \u0022base64\u0022)]";
         get_element_selector(_SELECTOR, false).nowait().exist()!
         VAR_IS_EXISTS = _result() == 1
         _if(VAR_IS_EXISTS, function(){
         get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
         VAR_IS_EXISTS = _result().indexOf("true")>=0
         })!
         

      })!
      

      
      
      _do(function(){
      _set_action_info({ name: "While" });
      VAR_CYCLE_INDEX = _iterator() - 1
      BREAK_CONDITION = true;
      if(!BREAK_CONDITION)_break();
      
         
         
         /*Browser*/
         ;_SELECTOR=" \u003eCSS\u003e #captcha-alert";
         get_element_selector(_SELECTOR, false).nowait().exist()!
         VAR_IS_EXISTS = _result() == 1
         _if(VAR_IS_EXISTS, function(){
         get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
         VAR_IS_EXISTS = _result().indexOf("true")>=0
         })!
         

         
         
         _set_if_expression("W1tJU19FWElTVFNdXQ==");
         _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
         
            
            
            fail((_K==="en" ? "Captcha is not solved, the solution time has expired" : "Капча не решена, время решения истекло"));
            

         })!
         

         
         
         _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gNCAmJiBbW0dPT0RfU09MVkVdXSAhPSAiMSI=");
         _if(VAR_CYCLE_INDEX > 4 && VAR_GOOD_SOLVE != "1",function(){
         
            
            
            fail((_K==="en" ? "Captcha has not been solved in 4 tries" : "Капча не решена за 4 попытки"));
            

         })!
         

         
         
         _set_if_expression("W1tDWUNMRV9JTkRFWF1dICE9IDA=");
         _if(VAR_CYCLE_INDEX != 0,function(){
         
            
            
            sleep(3000)!
            

         })!
         

         
         
         /*Browser*/
         ;_SELECTOR=" \u003eXPATH\u003e //div[contains(@class, \u0022captcha\u0022) and contains(@class, \u0022task\u0022)]//*[contains(@style, \u0022base64\u0022)]";
         get_element_selector(_SELECTOR, false).nowait().exist()!
         VAR_IS_EXISTS = _result() == 1
         _if(VAR_IS_EXISTS, function(){
         get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
         VAR_IS_EXISTS = _result().indexOf("true")>=0
         })!
         

         
         
         _set_if_expression("W1tJU19FWElTVFNdXSA9PSBmYWxzZQ==");
         _if(VAR_IS_EXISTS == false,function(){
         
            
            
            _set_if_expression("W1tHT09EX1NPTFZFXV0gPT0gIjEi");
            _if(VAR_GOOD_SOLVE == "1",function(){
            
               
               
               _break("function")
               

            })!
            

            
            
            sleep(4000)!
            

            
            
            _next("function")
            

         })!
         

         
         
         VAR_GOOD_SOLVE = "0"
         

         
         
         /*Browser*/
         ;_SELECTOR=" \u003eXPATH\u003e //div[contains(@class, \u0022captcha\u0022) and contains(@class, \u0022task\u0022)]//*[contains(@style, \u0022base64\u0022)]";
         get_element_selector(_SELECTOR, false).nowait().exist()!
         VAR_IS_EXISTS = _result() == 1
         _if(VAR_IS_EXISTS, function(){
         get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
         VAR_IS_EXISTS = _result().indexOf("true")>=0
         })!
         

         
         
         _set_if_expression("W1tJU19FWElTVFNdXSA9PSBmYWxzZQ==");
         _if(VAR_IS_EXISTS == false,function(){
         
            
            
            _next("function")
            

         })!
         

         
         
         /*Browser*/
         page().script("document.documentElement.outerHTML")!
         VAR_SAVED_PAGE_HTML = _result()
         

         
         
         html_parser_xpath_parse(VAR_SAVED_PAGE_HTML)
         if((false) && !html_parser_xpath_exist("//div[contains(@class, \u0022captcha\u0022) and contains(@class, \u0022task\u0022)]//*[contains(@style, \u0022base64\u0022)]"))
         fail("Can't resolve query " + "//div[contains(@class, \u0022captcha\u0022) and contains(@class, \u0022task\u0022)]//*[contains(@style, \u0022base64\u0022)]");
         VAR_SCREENSHOT_BASE64 = html_parser_xpath_xml("//div[contains(@class, \u0022captcha\u0022) and contains(@class, \u0022task\u0022)]//*[contains(@style, \u0022base64\u0022)]")
         

         
         
         var regexp_result = native("regexp", "first", JSON.stringify({text: VAR_SCREENSHOT_BASE64,regexp:"\u0026quot;data:image/png;base64\u005c,([\u005cs\u005cS]+?)\u0026quot;"}))
         if(regexp_result.length == 0)
         regexp_result = []
         else
         regexp_result = JSON.parse(regexp_result)
         VAR_ALL_MATCH = regexp_result.pop()
         if(typeof(VAR_ALL_MATCH) == 'undefined' || !VAR_ALL_MATCH)
         VAR_ALL_MATCH = ""
         VAR_SCREENSHOT_BASE64 = regexp_result[0]
         if(typeof(VAR_SCREENSHOT_BASE64) == 'undefined' || !VAR_SCREENSHOT_BASE64)
         VAR_SCREENSHOT_BASE64 = ""
         if(regexp_result.length == 0)
         {
         VAR_SCREENSHOT_BASE64 = VAR_ALL_MATCH
         }
         

         
         
         _set_if_expression("dHJ1ZQ==");
         _if(true,function(){
         
            
            
            _call(function()
            {
            _on_fail(function(){
            VAR_LAST_ERROR = _result()
            VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
            VAR_WAS_ERROR = false
            _break(1,true)
            })
            CYCLES.Current().RemoveLabel("function")
            
               
               
               _switch_http_client_main()
               http_client_post("http://" + VAR_URL + "/in.php", ["key",VAR_APIKEY,"method","buxmoney","body",VAR_SCREENSHOT_BASE64], {"content-type":("multipart"), "encoding":("UTF-8"), "method":("POST"),headers:("")})!
               

            },null)!
            

            
            
            _set_if_expression("W1tXQVNfRVJST1JdXQ==");
            _if(typeof(VAR_WAS_ERROR) !== "undefined" ? (VAR_WAS_ERROR) : undefined,function(){
            
               
               
               _next("function")
               

            })!
            

            
            
            /*Browser*/
            scroll(1,1)!
            

            
            
            /*Browser*/
            _SELECTOR = " \u003eXPATH\u003e //*[contains(@style, \u0022" + VAR_SCREENSHOT_BASE64 + "\u0022)]";
            wait_element(_SELECTOR)!
            get_element_selector(_SELECTOR, false).script("(function(){var rect = self.getBoundingClientRect();return (rect.left + positionx).toString() + '|' + (rect.top + positiony).toString() + '|' + (rect.right - rect.left).toString() + '|' + (rect.bottom - rect.top).toString()})();")!
            if(_result().length > 0)
            {
            var split = _result().split("|")
            VAR_X = parseInt(split[0])
            VAR_Y = parseInt(split[1])
            VAR_WIDTH = parseInt(split[2])
            VAR_HEIGHT = parseInt(split[3])
            }
            

            
            
            _switch_http_client_main()
            VAR_SAVED_CONTENT = http_client_encoded_content("auto")
            

            
            
            VAR_STRING_CONTAINS = Boolean(native("regexp", "ismatch", JSON.stringify({text: VAR_SAVED_CONTENT,regexp:"(\u005c|)"})) == "true")
            

            
            
            _set_if_expression("W1tTVFJJTkdfQ09OVEFJTlNdXQ==");
            _if(typeof(VAR_STRING_CONTAINS) !== "undefined" ? (VAR_STRING_CONTAINS) : undefined,function(){
            
               
               
               sleep(1000)!
               

               
               
               VAR_ID = VAR_SAVED_CONTENT.split("|")[1]
               

               
               
               _switch_http_client_main()
               http_client_get2("http://" + VAR_URL + "/res.php?key=" + VAR_APIKEY + "\u0026id=" + VAR_ID,{method:("GET"),headers:("")})!
               

               
               
               _switch_http_client_main()
               VAR_SAVED_CONTENT = http_client_encoded_content("auto")
               

               
               
               _do(function(){
               _set_action_info({ name: "While" });
               VAR_CYCLE_INDEX = _iterator() - 1
               BREAK_CONDITION = VAR_SAVED_CONTENT == "CAPCHA_NOT_READY";
               if(!BREAK_CONDITION)_break();
               
                  
                  
                  _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gMTU=");
                  _if(VAR_CYCLE_INDEX > 15,function(){
                  
                     
                     
                     fail((_K==="en" ? "Service didn't solve captcha in 15 seconds" : "Сервис не решил капчу за 15 секунд"));
                     

                  })!
                  

                  
                  
                  sleep(1000)!
                  

                  
                  
                  _call(function()
                  {
                  _on_fail(function(){
                  VAR_LAST_ERROR = _result()
                  VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
                  VAR_WAS_ERROR = false
                  _break(1,true)
                  })
                  CYCLES.Current().RemoveLabel("function")
                  
                     
                     
                     _switch_http_client_main()
                     http_client_get2("http://" + VAR_URL + "/res.php?key=" + VAR_APIKEY + "\u0026id=" + VAR_ID,{method:("GET"),headers:("")})!
                     

                  },null)!
                  

                  
                  
                  _switch_http_client_main()
                  VAR_SAVED_CONTENT = http_client_encoded_content("auto")
                  

               })!
               

               
               
               VAR_STRING_CONTAINS = Boolean(native("regexp", "ismatch", JSON.stringify({text: VAR_SAVED_CONTENT,regexp:"(\u005c|)"})) == "true")
               

               
               
               _cycle_params().if_else = typeof(VAR_STRING_CONTAINS) !== "undefined" ? (VAR_STRING_CONTAINS) : undefined;
               _set_if_expression("W1tTVFJJTkdfQ09OVEFJTlNdXQ==");
               _if(_cycle_params().if_else,function(){
               
                  
                  
                  VAR_SCAN_RESULT_LIST = native("regexp", "scan", JSON.stringify({text: VAR_SAVED_CONTENT,regexp:"(\u005cd+)"}))
                  if(VAR_SCAN_RESULT_LIST.length == 0)
                  VAR_SCAN_RESULT_LIST = []
                  else
                  VAR_SCAN_RESULT_LIST = JSON.parse(VAR_SCAN_RESULT_LIST)
                  

                  
                  
                  VAR_LIST_LENGTH = (VAR_SCAN_RESULT_LIST).length
                  

                  
                  
                  _set_if_expression("W1tMSVNUX0xFTkdUSF1dICE9IDI=");
                  _if(VAR_LIST_LENGTH != 2,function(){
                  
                     
                     
                     _next("function")
                     

                  })!
                  

                  
                  
                  VAR_XIMG = parseInt(VAR_SCAN_RESULT_LIST[0]);
                  VAR_YIMG = parseInt(VAR_SCAN_RESULT_LIST[1]);
                  

                  
                  
                  /*Browser*/
                  ;_SELECTOR=" \u003eCSS\u003e #captcha-alert";
                  get_element_selector(_SELECTOR, false).nowait().exist()!
                  VAR_IS_EXISTS = _result() == 1
                  _if(VAR_IS_EXISTS, function(){
                  get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
                  VAR_IS_EXISTS = _result().indexOf("true")>=0
                  })!
                  

                  
                  
                  _set_if_expression("W1tJU19FWElTVFNdXQ==");
                  _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
                  
                     
                     
                     fail((_K==="en" ? "Captcha is not solved, the solution time has expired" : "Капча не решена, время решения истекло"));
                     

                  })!
                  

                  
                  
                  /*Browser*/
                  move(VAR_X+VAR_XIMG,VAR_Y+VAR_YIMG,  {} )!
                  mouse(VAR_X+VAR_XIMG,VAR_Y+VAR_YIMG)!
                  

                  
                  
                  VAR_GOOD_SOLVE = "1"
                  

                  
                  
                  sleep(4000)!
                  

               })!
               

               
               
               _if(!_cycle_params().if_else,function(){
               
                  
                  
                  /*Browser*/
                  _SELECTOR = " \u003eCSS\u003e #reload \u003e svg";waiter_timeout_next(1000)
                  waiter_nofail_next();
                  wait_element_visible(_SELECTOR)!
                  _call(_random_point, {})!
                  _if(_result().length > 0, function(){
                  X = parseInt(_result().split(",")[0])
                  Y = parseInt(_result().split(",")[1])
                  mouse(X,Y)!
                  })!
                  

               })!
               delete _cycle_params().if_else;
               

            })!
            

         })!
         

         
         
         _set_if_expression("ZmFsc2U=");
         _if(false,function(){
         
            
            
            /*Browser*/
            _SELECTOR = " \u003eCSS\u003e #reload \u003e svg";waiter_timeout_next(5000)
            waiter_nofail_next();
            wait_element_visible(_SELECTOR)!
            _call(_random_point, {})!
            _if(_result().length > 0, function(){
            X = parseInt(_result().split(",")[0])
            Y = parseInt(_result().split(",")[1])
            mouse(X,Y)!
            })!
            

         })!
         

      })!
      

   }
   

function GoodXevilPaySolver_GXP_Seo_SeoTime()
   {
   
      
      
      VAR_APIKEY = _function_argument("apikey")
      

      
      
      var regexp_result = native("regexp", "first", JSON.stringify({text: VAR_APIKEY,regexp:"([0-9A-Za-z]\u007b20,40\u007d)"}))
      if(regexp_result.length == 0)
      regexp_result = []
      else
      regexp_result = JSON.parse(regexp_result)
      VAR_ALL_MATCH = regexp_result.pop()
      if(typeof(VAR_ALL_MATCH) == 'undefined' || !VAR_ALL_MATCH)
      VAR_ALL_MATCH = ""
      VAR_APIKEY = regexp_result[0]
      if(typeof(VAR_APIKEY) == 'undefined' || !VAR_APIKEY)
      VAR_APIKEY = ""
      if(regexp_result.length == 0)
      {
      VAR_APIKEY = VAR_ALL_MATCH
      }
      

      
      
      VAR_URL_ADRESS_SOLVER = "http://goodxevilpay.pp.ua"
      

      
      
      VAR_ERROR_FATAL = 0
      

      
      
      _do(function(){
      _set_action_info({ name: "For" });
      VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
      if(VAR_CYCLE_INDEX > parseInt(6))_break();
      
         
         
         _set_if_expression("W1tDWUNMRV9JTkRFWF1dID49IDY=");
         _if(VAR_CYCLE_INDEX >= 6,function(){
         
            
            
            fail((_K==="en" ? "Couldn't solve the captcha in 6 times" : "Не получилось решить капчу за 6 раз"));
            

         })!
         

         
         
         _call(function()
         {
         _on_fail(function(){
         VAR_LAST_ERROR = _result()
         VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
         VAR_WAS_ERROR = false
         _break(1,true)
         })
         CYCLES.Current().RemoveLabel("function")
         
            
            
            VAR_LIST_SCREENSHOTS = []
            

            
            
            /*Browser*/
            page().script("document.documentElement.outerHTML")!
            VAR_SAVED_PAGE_HTML = _result()
            

            
            
            html_parser_xpath_parse(VAR_SAVED_PAGE_HTML)
            VAR_XPATH_XML_LIST = html_parser_xpath_xml_list("//*[contains(@class,\u0027out-capcha-lab\u0027)]")
            

            
            
            VAR_LIST_LENGTH = (VAR_XPATH_XML_LIST).length
            

            
            
            _do(function(){
            _set_action_info({ name: "While" });
            VAR_CYCLE_INDEX = _iterator() - 1
            BREAK_CONDITION = VAR_LIST_LENGTH == 0;
            if(!BREAK_CONDITION)_break();
            
               
               
               _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gMzA=");
               _if(VAR_CYCLE_INDEX > 30,function(){
               
                  
                  
                  fail((_K==="en" ? "Didn't wait for the captcha in 30 seconds" : "Не дождался капчи за 30 секунд"));
                  

               })!
               

               
               
               sleep(1000)!
               

               
               
               /*Browser*/
               page().script("document.documentElement.outerHTML")!
               VAR_SAVED_PAGE_HTML = _result()
               

               
               
               html_parser_xpath_parse(VAR_SAVED_PAGE_HTML)
               VAR_XPATH_XML_LIST = html_parser_xpath_xml_list("//*[contains(@class,\u0027out-capcha-lab\u0027)]")
               

               
               
               VAR_LIST_LENGTH = (VAR_XPATH_XML_LIST).length
               

            })!
            

            
            
            VAR_XPATH_XML_LIST = (function(){var seen = {}; return (VAR_XPATH_XML_LIST).filter(function(item) { return seen.hasOwnProperty(item) ? false : (seen[item] = true); });})();
            

            
            
            _do_with_params({"foreach_data":(VAR_XPATH_XML_LIST)},function(){
            _set_action_info({ name: "Foreach" });
            VAR_CYCLE_INDEX = _iterator() - 1
            if(VAR_CYCLE_INDEX > _cycle_param("foreach_data").length - 1)_break();
            VAR_FOREACH_DATA = _cycle_param("foreach_data")[VAR_CYCLE_INDEX]
            
               
               
               VAR_SCREENSHOT_BASE64 = VAR_FOREACH_DATA.split("base64,")[1].split(")")[0]
               

               
               
               VAR_LIST_SCREENSHOTS.push(VAR_SCREENSHOT_BASE64)
               

            })!
            

            
            
            html_parser_xpath_parse(VAR_SAVED_PAGE_HTML)
            if((true) && !html_parser_xpath_exist("//*[contains(@class,\u0027out-capcha-title\u0027)]"))
            fail("Can't resolve query " + "//*[contains(@class,\u0027out-capcha-title\u0027)]");
            VAR_CAPTCHA_TEXT = html_parser_xpath_text("//*[contains(@class,\u0027out-capcha-title\u0027)]")
            

            
            
            VAR_CAPTCHA_TEXT = native("regexp", "replace", JSON.stringify({text: VAR_CAPTCHA_TEXT,regexp:"(\u005c \u005c )",replace:""}))
            

            
            
            _switch_http_client_main()
            general_timeout_next(15000)
            http_client_post(VAR_URL_ADRESS_SOLVER + "/in.php", ["method","seotime","body_1",VAR_LIST_SCREENSHOTS[0],"body_2",VAR_LIST_SCREENSHOTS[1],"body_3",VAR_LIST_SCREENSHOTS[2],"body_4",VAR_LIST_SCREENSHOTS[3],"body_5",VAR_LIST_SCREENSHOTS[4],"textinstructions",VAR_CAPTCHA_TEXT,"key",VAR_APIKEY], {"content-type":("multipart"), "encoding":("UTF-8"), "method":("POST"),headers:("")})!
            

            
            
            _switch_http_client_main()
            VAR_SAVED_CONTENT = http_client_encoded_content("utf-8")
            

            
            
            VAR_STRING_CONTAINS = Boolean(native("regexp", "ismatch", JSON.stringify({text: VAR_SAVED_CONTENT,regexp:"(ERROR)"})) == "true")
            

            
            
            _set_if_expression("W1tTVFJJTkdfQ09OVEFJTlNdXQ==");
            _if(typeof(VAR_STRING_CONTAINS) !== "undefined" ? (VAR_STRING_CONTAINS) : undefined,function(){
            
               
               
               fail((_K==="en" ? "There was an error when recognizing captcha" : "Произошла ошибка при распознавании капчи"));
               

            })!
            

            
            
            VAR_ID = VAR_SAVED_CONTENT.split("|")[1]
            

            
            
            _do(function(){
            _set_action_info({ name: "While" });
            VAR_CYCLE_INDEX = _iterator() - 1
            BREAK_CONDITION = true;
            if(!BREAK_CONDITION)_break();
            
               
               
               _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gMzA=");
               _if(VAR_CYCLE_INDEX > 30,function(){
               
                  
                  
                  fail((_K==="en" ? "The service failed to recognize the captcha in 30 seconds" : "Сервис не распознал капчу за 30 секунд"));
                  

               })!
               

               
               
               sleep(1000)!
               

               
               
               _switch_http_client_main()
               http_client_get2(VAR_URL_ADRESS_SOLVER + "/res.php?key=" + VAR_APIKEY + "\u0026id=" + VAR_ID,{method:("GET"),headers:("")})!
               

               
               
               _switch_http_client_main()
               VAR_SAVED_CONTENT = http_client_encoded_content("utf-8")
               

               
               
               _set_if_expression("W1tTQVZFRF9DT05URU5UXV0gIT0gIkNBUENIQV9OT1RfUkVBRFki");
               _if(VAR_SAVED_CONTENT != "CAPCHA_NOT_READY",function(){
               
                  
                  
                  _break("function")
                  

               })!
               

            })!
            

            
            
            VAR_STRING_CONTAINS = Boolean(native("regexp", "ismatch", JSON.stringify({text: VAR_SAVED_CONTENT,regexp:"(ERROR)"})) == "true")
            

            
            
            _set_if_expression("W1tTVFJJTkdfQ09OVEFJTlNdXQ==");
            _if(typeof(VAR_STRING_CONTAINS) !== "undefined" ? (VAR_STRING_CONTAINS) : undefined,function(){
            
               
               
               fail((_K==="en" ? "There was an error when recognizing captcha" : "Произошла ошибка при распознавании капчи"));
               

            })!
            

            
            
            VAR_IMAGES = VAR_SAVED_CONTENT.split("|")[1]
            

            
            
            VAR_IMAGES = VAR_IMAGES.split(",")
            

            
            
            _do_with_params({"foreach_data":(VAR_IMAGES)},function(){
            _set_action_info({ name: "Foreach" });
            VAR_CYCLE_INDEX = _iterator() - 1
            if(VAR_CYCLE_INDEX > _cycle_param("foreach_data").length - 1)_break();
            VAR_FOREACH_DATA = _cycle_param("foreach_data")[VAR_CYCLE_INDEX]
            
               
               
               VAR_ID = VAR_FOREACH_DATA - 1
               

               
               
               /*Browser*/
               _SELECTOR = " \u003eXPATH\u003e //label[@class=\u0022out-capcha-lab\u0022]\u003eAT\u003e" + VAR_ID;
               wait_element_visible(_SELECTOR)!
               _call(_random_point, {})!
               _if(_result().length > 0, function(){
               X = parseInt(_result().split(",")[0])
               Y = parseInt(_result().split(",")[1])
               mouse(X,Y)!
               })!
               

            })!
            

            
            
            _break("function")
            

         },null)!
         

         
         
         _set_if_expression("W1tXQVNfRVJST1JdXQ==");
         _if(typeof(VAR_WAS_ERROR) !== "undefined" ? (VAR_WAS_ERROR) : undefined,function(){
         
            
            
            page().script2("re_load_capcha();",JSON.stringify(_read_variables([])))!
            var _parse_result = JSON.parse(_result())
            _write_variables(JSON.parse(_parse_result.variables))
            if(!_parse_result.is_success)
            fail(_parse_result.error)
            

            
            
            sleep(1000)!
            

         })!
         

      })!
      

   }
   

function GoodXevilPaySolver_GXP_Seo_SeoFast()
   {
   
      
      
      VAR_APIKEY = _function_argument("apikey")
      

      
      
      var regexp_result = native("regexp", "first", JSON.stringify({text: VAR_APIKEY,regexp:"([0-9A-Za-z]\u007b20,40\u007d)"}))
      if(regexp_result.length == 0)
      regexp_result = []
      else
      regexp_result = JSON.parse(regexp_result)
      VAR_ALL_MATCH = regexp_result.pop()
      if(typeof(VAR_ALL_MATCH) == 'undefined' || !VAR_ALL_MATCH)
      VAR_ALL_MATCH = ""
      VAR_APIKEY = regexp_result[0]
      if(typeof(VAR_APIKEY) == 'undefined' || !VAR_APIKEY)
      VAR_APIKEY = ""
      if(regexp_result.length == 0)
      {
      VAR_APIKEY = VAR_ALL_MATCH
      }
      

      
      
      VAR_ERROR_FATAL = 0
      

      
      
      _do(function(){
      _set_action_info({ name: "For" });
      VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
      if(VAR_CYCLE_INDEX > parseInt(6))_break();
      
         
         
         _set_if_expression("W1tDWUNMRV9JTkRFWF1dID49IDY=");
         _if(VAR_CYCLE_INDEX >= 6,function(){
         
            
            
            fail((_K==="en" ? "Couldn't solve the captcha in 6 times" : "Не получилось решить капчу за 6 раз"));
            

         })!
         

         
         
         _call(function()
         {
         _on_fail(function(){
         VAR_LAST_ERROR = _result()
         VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
         VAR_WAS_ERROR = false
         _break(1,true)
         })
         CYCLES.Current().RemoveLabel("function")
         
            
            
            VAR_LIST_SCREENSHOTS = []
            

            
            
            /*Browser*/
            page().script("document.documentElement.outerHTML")!
            VAR_SAVED_PAGE_HTML = _result()
            

            
            
            html_parser_xpath_parse(VAR_SAVED_PAGE_HTML)
            VAR_XPATH_XML_LIST = html_parser_xpath_xml_list("//*[contains(@class,\u0027out-capcha-lab\u0027)]")
            

            
            
            VAR_LIST_LENGTH = (VAR_XPATH_XML_LIST).length
            

            
            
            _do(function(){
            _set_action_info({ name: "While" });
            VAR_CYCLE_INDEX = _iterator() - 1
            BREAK_CONDITION = VAR_LIST_LENGTH == 0;
            if(!BREAK_CONDITION)_break();
            
               
               
               _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gMzA=");
               _if(VAR_CYCLE_INDEX > 30,function(){
               
                  
                  
                  fail((_K==="en" ? "Didn't wait for the captcha in 30 seconds" : "Не дождался капчи за 30 секунд"));
                  

               })!
               

               
               
               sleep(1000)!
               

               
               
               /*Browser*/
               page().script("document.documentElement.outerHTML")!
               VAR_SAVED_PAGE_HTML = _result()
               

               
               
               html_parser_xpath_parse(VAR_SAVED_PAGE_HTML)
               VAR_XPATH_XML_LIST = html_parser_xpath_xml_list("//*[contains(@class,\u0027out-capcha-lab\u0027)]")
               

               
               
               VAR_LIST_LENGTH = (VAR_XPATH_XML_LIST).length
               

            })!
            

            
            
            VAR_XPATH_XML_LIST = (function(){var seen = {}; return (VAR_XPATH_XML_LIST).filter(function(item) { return seen.hasOwnProperty(item) ? false : (seen[item] = true); });})();
            

            
            
            _do_with_params({"foreach_data":(VAR_XPATH_XML_LIST)},function(){
            _set_action_info({ name: "Foreach" });
            VAR_CYCLE_INDEX = _iterator() - 1
            if(VAR_CYCLE_INDEX > _cycle_param("foreach_data").length - 1)_break();
            VAR_FOREACH_DATA = _cycle_param("foreach_data")[VAR_CYCLE_INDEX]
            
               
               
               VAR_SCREENSHOT_BASE64 = VAR_FOREACH_DATA.split("base64,")[1].split(")")[0]
               

               
               
               VAR_LIST_SCREENSHOTS.push(VAR_SCREENSHOT_BASE64)
               

            })!
            

            
            
            html_parser_xpath_parse(VAR_SAVED_PAGE_HTML)
            if((true) && !html_parser_xpath_exist("//*[contains(@class,\u0027out-capcha-title\u0027)]"))
            fail("Can't resolve query " + "//*[contains(@class,\u0027out-capcha-title\u0027)]");
            VAR_CAPTCHA_TEXT = html_parser_xpath_text("//*[contains(@class,\u0027out-capcha-title\u0027)]")
            

            
            
            VAR_CAPTCHA_TEXT = native("regexp", "replace", JSON.stringify({text: VAR_CAPTCHA_TEXT,regexp:"(\u005c \u005c )",replace:""}))
            

            
            
            _switch_http_client_main()
            general_timeout_next(15000)
            http_client_post("http://goodxevilpay.pp.ua/in.php", ["method","seofast","body_1",VAR_LIST_SCREENSHOTS[0],"body_2",VAR_LIST_SCREENSHOTS[1],"body_3",VAR_LIST_SCREENSHOTS[2],"body_4",VAR_LIST_SCREENSHOTS[3],"body_5",VAR_LIST_SCREENSHOTS[4],"textinstructions",VAR_CAPTCHA_TEXT,"key",VAR_APIKEY], {"content-type":("multipart"), "encoding":("UTF-8"), "method":("POST"),headers:("")})!
            

            
            
            _switch_http_client_main()
            VAR_SAVED_CONTENT = http_client_encoded_content("utf-8")
            

            
            
            VAR_STRING_CONTAINS = Boolean(native("regexp", "ismatch", JSON.stringify({text: VAR_SAVED_CONTENT,regexp:"(ERROR)"})) == "true")
            

            
            
            _set_if_expression("W1tTVFJJTkdfQ09OVEFJTlNdXQ==");
            _if(typeof(VAR_STRING_CONTAINS) !== "undefined" ? (VAR_STRING_CONTAINS) : undefined,function(){
            
               
               
               fail((_K==="en" ? "There was an error when recognizing captcha" : "Произошла ошибка при распознавании капчи"));
               

            })!
            

            
            
            VAR_ID = VAR_SAVED_CONTENT.split("|")[1]
            

            
            
            _do(function(){
            _set_action_info({ name: "While" });
            VAR_CYCLE_INDEX = _iterator() - 1
            BREAK_CONDITION = true;
            if(!BREAK_CONDITION)_break();
            
               
               
               _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gMzA=");
               _if(VAR_CYCLE_INDEX > 30,function(){
               
                  
                  
                  fail((_K==="en" ? "The service failed to recognize the captcha in 30 seconds" : "Сервис не распознал капчу за 30 секунд"));
                  

               })!
               

               
               
               sleep(1000)!
               

               
               
               _switch_http_client_main()
               http_client_get2("http://goodxevilpay.pp.ua/res.php?key=" + VAR_APIKEY + "\u0026id=" + VAR_ID,{method:("GET"),headers:("")})!
               

               
               
               _switch_http_client_main()
               VAR_SAVED_CONTENT = http_client_encoded_content("utf-8")
               

               
               
               _set_if_expression("W1tTQVZFRF9DT05URU5UXV0gIT0gIkNBUENIQV9OT1RfUkVBRFki");
               _if(VAR_SAVED_CONTENT != "CAPCHA_NOT_READY",function(){
               
                  
                  
                  _break("function")
                  

               })!
               

            })!
            

            
            
            VAR_STRING_CONTAINS = Boolean(native("regexp", "ismatch", JSON.stringify({text: VAR_SAVED_CONTENT,regexp:"(ERROR)"})) == "true")
            

            
            
            _set_if_expression("W1tTVFJJTkdfQ09OVEFJTlNdXQ==");
            _if(typeof(VAR_STRING_CONTAINS) !== "undefined" ? (VAR_STRING_CONTAINS) : undefined,function(){
            
               
               
               fail((_K==="en" ? "There was an error when recognizing captcha" : "Произошла ошибка при распознавании капчи"));
               

            })!
            

            
            
            VAR_IMAGES = VAR_SAVED_CONTENT.split("|")[1]
            

            
            
            VAR_IMAGES = VAR_IMAGES.split(",")
            

            
            
            _do_with_params({"foreach_data":(VAR_IMAGES)},function(){
            _set_action_info({ name: "Foreach" });
            VAR_CYCLE_INDEX = _iterator() - 1
            if(VAR_CYCLE_INDEX > _cycle_param("foreach_data").length - 1)_break();
            VAR_FOREACH_DATA = _cycle_param("foreach_data")[VAR_CYCLE_INDEX]
            
               
               
               VAR_ID = VAR_FOREACH_DATA - 1
               

               
               
               /*Browser*/
               _SELECTOR = " \u003eXPATH\u003e //label[@class=\u0022out-capcha-lab\u0022]\u003eAT\u003e" + VAR_ID;
               wait_element_visible(_SELECTOR)!
               _call(_random_point, {})!
               _if(_result().length > 0, function(){
               X = parseInt(_result().split(",")[0])
               Y = parseInt(_result().split(",")[1])
               mouse(X,Y)!
               })!
               

            })!
            

            
            
            _break("function")
            

         },null)!
         

         
         
         _set_if_expression("W1tXQVNfRVJST1JdXQ==");
         _if(typeof(VAR_WAS_ERROR) !== "undefined" ? (VAR_WAS_ERROR) : undefined,function(){
         
            
            
            page().script2("reload_capcha();",JSON.stringify(_read_variables([])))!
            var _parse_result = JSON.parse(_result())
            _write_variables(JSON.parse(_parse_result.variables))
            if(!_parse_result.is_success)
            fail(_parse_result.error)
            

            
            
            sleep(1000)!
            

         })!
         

      })!
      

   }
   

function GoodXevilPaySolver_GXP_Seo_Profitcentr()
   {
   
      
      
      VAR_APIKEY = _function_argument("apikey")
      

      
      
      var regexp_result = native("regexp", "first", JSON.stringify({text: VAR_APIKEY,regexp:"([0-9A-Za-z]\u007b20,40\u007d)"}))
      if(regexp_result.length == 0)
      regexp_result = []
      else
      regexp_result = JSON.parse(regexp_result)
      VAR_ALL_MATCH = regexp_result.pop()
      if(typeof(VAR_ALL_MATCH) == 'undefined' || !VAR_ALL_MATCH)
      VAR_ALL_MATCH = ""
      VAR_APIKEY = regexp_result[0]
      if(typeof(VAR_APIKEY) == 'undefined' || !VAR_APIKEY)
      VAR_APIKEY = ""
      if(regexp_result.length == 0)
      {
      VAR_APIKEY = VAR_ALL_MATCH
      }
      

      
      
      VAR_ERROR_FATAL = 0
      

      
      
      _do(function(){
      _set_action_info({ name: "For" });
      VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
      if(VAR_CYCLE_INDEX > parseInt(6))_break();
      
         
         
         _set_if_expression("W1tDWUNMRV9JTkRFWF1dID49IDY=");
         _if(VAR_CYCLE_INDEX >= 6,function(){
         
            
            
            fail((_K==="en" ? "Couldn't solve the captcha in 6 times" : "Не получилось решить капчу за 6 раз"));
            

         })!
         

         
         
         _call(function()
         {
         _on_fail(function(){
         VAR_LAST_ERROR = _result()
         VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
         VAR_WAS_ERROR = false
         _break(1,true)
         })
         CYCLES.Current().RemoveLabel("function")
         
            
            
            VAR_LIST_SCREENSHOTS = []
            

            
            
            /*Browser*/
            page().script("document.documentElement.outerHTML")!
            VAR_SAVED_PAGE_HTML = _result()
            

            
            
            html_parser_xpath_parse(VAR_SAVED_PAGE_HTML)
            VAR_XPATH_XML_LIST = html_parser_xpath_xml_list("//*[contains(@class,\u0027out-capcha-lab\u0027)]")
            

            
            
            VAR_LIST_LENGTH = (VAR_XPATH_XML_LIST).length
            

            
            
            _do(function(){
            _set_action_info({ name: "While" });
            VAR_CYCLE_INDEX = _iterator() - 1
            BREAK_CONDITION = VAR_LIST_LENGTH == 0;
            if(!BREAK_CONDITION)_break();
            
               
               
               _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gMzA=");
               _if(VAR_CYCLE_INDEX > 30,function(){
               
                  
                  
                  fail((_K==="en" ? "Didn't wait for the captcha in 30 seconds" : "Не дождался капчи за 30 секунд"));
                  

               })!
               

               
               
               sleep(1000)!
               

               
               
               /*Browser*/
               page().script("document.documentElement.outerHTML")!
               VAR_SAVED_PAGE_HTML = _result()
               

               
               
               html_parser_xpath_parse(VAR_SAVED_PAGE_HTML)
               VAR_XPATH_XML_LIST = html_parser_xpath_xml_list("//*[contains(@class,\u0027out-capcha-lab\u0027)]")
               

               
               
               VAR_LIST_LENGTH = (VAR_XPATH_XML_LIST).length
               

            })!
            

            
            
            VAR_XPATH_XML_LIST = (function(){var seen = {}; return (VAR_XPATH_XML_LIST).filter(function(item) { return seen.hasOwnProperty(item) ? false : (seen[item] = true); });})();
            

            
            
            _do_with_params({"foreach_data":(VAR_XPATH_XML_LIST)},function(){
            _set_action_info({ name: "Foreach" });
            VAR_CYCLE_INDEX = _iterator() - 1
            if(VAR_CYCLE_INDEX > _cycle_param("foreach_data").length - 1)_break();
            VAR_FOREACH_DATA = _cycle_param("foreach_data")[VAR_CYCLE_INDEX]
            
               
               
               VAR_SCREENSHOT_BASE64 = VAR_FOREACH_DATA.split("base64,")[1].split(")")[0]
               

               
               
               VAR_LIST_SCREENSHOTS.push(VAR_SCREENSHOT_BASE64)
               

            })!
            

            
            
            html_parser_xpath_parse(VAR_SAVED_PAGE_HTML)
            if((true) && !html_parser_xpath_exist("//*[contains(@class,\u0027out-capcha-title\u0027)]"))
            fail("Can't resolve query " + "//*[contains(@class,\u0027out-capcha-title\u0027)]");
            VAR_CAPTCHA_TEXT = html_parser_xpath_text("//*[contains(@class,\u0027out-capcha-title\u0027)]")
            

            
            
            VAR_CAPTCHA_TEXT = native("regexp", "replace", JSON.stringify({text: VAR_CAPTCHA_TEXT,regexp:"(\u005c \u005c )",replace:""}))
            

            
            
            _switch_http_client_main()
            general_timeout_next(15000)
            http_client_post("http://goodxevilpay.pp.ua/in.php", ["method","profit","body_1",VAR_LIST_SCREENSHOTS[0],"body_2",VAR_LIST_SCREENSHOTS[1],"body_3",VAR_LIST_SCREENSHOTS[2],"body_4",VAR_LIST_SCREENSHOTS[3],"body_5",VAR_LIST_SCREENSHOTS[4],"body_6",VAR_LIST_SCREENSHOTS[5],"textinstructions",VAR_CAPTCHA_TEXT,"key",VAR_APIKEY], {"content-type":("multipart"), "encoding":("UTF-8"), "method":("POST"),headers:("")})!
            

            
            
            _switch_http_client_main()
            VAR_SAVED_CONTENT = http_client_encoded_content("utf-8")
            

            
            
            VAR_STRING_CONTAINS = Boolean(native("regexp", "ismatch", JSON.stringify({text: VAR_SAVED_CONTENT,regexp:"(ERROR)"})) == "true")
            

            
            
            _set_if_expression("W1tTVFJJTkdfQ09OVEFJTlNdXQ==");
            _if(typeof(VAR_STRING_CONTAINS) !== "undefined" ? (VAR_STRING_CONTAINS) : undefined,function(){
            
               
               
               fail((_K==="en" ? "There was an error when recognizing captcha" : "Произошла ошибка при распознавании капчи"));
               

            })!
            

            
            
            VAR_ID = VAR_SAVED_CONTENT.split("|")[1]
            

            
            
            _do(function(){
            _set_action_info({ name: "While" });
            VAR_CYCLE_INDEX = _iterator() - 1
            BREAK_CONDITION = true;
            if(!BREAK_CONDITION)_break();
            
               
               
               _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gMzA=");
               _if(VAR_CYCLE_INDEX > 30,function(){
               
                  
                  
                  fail((_K==="en" ? "The service failed to recognize the captcha in 30 seconds" : "Сервис не распознал капчу за 30 секунд"));
                  

               })!
               

               
               
               sleep(1000)!
               

               
               
               _switch_http_client_main()
               http_client_get2("http://goodxevilpay.pp.ua/res.php?key=" + VAR_APIKEY + "\u0026id=" + VAR_ID,{method:("GET"),headers:("")})!
               

               
               
               _switch_http_client_main()
               VAR_SAVED_CONTENT = http_client_encoded_content("utf-8")
               

               
               
               _set_if_expression("W1tTQVZFRF9DT05URU5UXV0gIT0gIkNBUENIQV9OT1RfUkVBRFki");
               _if(VAR_SAVED_CONTENT != "CAPCHA_NOT_READY",function(){
               
                  
                  
                  _break("function")
                  

               })!
               

            })!
            

            
            
            VAR_STRING_CONTAINS = Boolean(native("regexp", "ismatch", JSON.stringify({text: VAR_SAVED_CONTENT,regexp:"(ERROR)"})) == "true")
            

            
            
            _set_if_expression("W1tTVFJJTkdfQ09OVEFJTlNdXQ==");
            _if(typeof(VAR_STRING_CONTAINS) !== "undefined" ? (VAR_STRING_CONTAINS) : undefined,function(){
            
               
               
               fail((_K==="en" ? "There was an error when recognizing captcha" : "Произошла ошибка при распознавании капчи"));
               

            })!
            

            
            
            VAR_IMAGES = VAR_SAVED_CONTENT.split("|")[1]
            

            
            
            VAR_IMAGES = VAR_IMAGES.split(",")
            

            
            
            _do_with_params({"foreach_data":(VAR_IMAGES)},function(){
            _set_action_info({ name: "Foreach" });
            VAR_CYCLE_INDEX = _iterator() - 1
            if(VAR_CYCLE_INDEX > _cycle_param("foreach_data").length - 1)_break();
            VAR_FOREACH_DATA = _cycle_param("foreach_data")[VAR_CYCLE_INDEX]
            
               
               
               VAR_ID = VAR_FOREACH_DATA - 1
               

               
               
               /*Browser*/
               _SELECTOR = " \u003eXPATH\u003e //label[@class=\u0022out-capcha-lab\u0022]\u003eAT\u003e" + VAR_ID;
               wait_element_visible(_SELECTOR)!
               _call(_random_point, {})!
               _if(_result().length > 0, function(){
               X = parseInt(_result().split(",")[0])
               Y = parseInt(_result().split(",")[1])
               mouse(X,Y)!
               })!
               

            })!
            

            
            
            _break("function")
            

         },null)!
         

         
         
         _set_if_expression("W1tXQVNfRVJST1JdXQ==");
         _if(typeof(VAR_WAS_ERROR) !== "undefined" ? (VAR_WAS_ERROR) : undefined,function(){
         
            
            
            page().script2("re_load_capcha();",JSON.stringify(_read_variables([])))!
            var _parse_result = JSON.parse(_result())
            _write_variables(JSON.parse(_parse_result.variables))
            if(!_parse_result.is_success)
            fail(_parse_result.error)
            

            
            
            sleep(1000)!
            

         })!
         

      })!
      

   }
   

function GoodXevilPaySolver_GXP_SliderSolver()
   {
   
      
      
      VAR_ARROW_ID = _function_argument("arrow_id")
      

      
      
      VAR_BUTTON_ID = _function_argument("button_id")
      

      
      
      VAR_TYPE_SLIDE = _function_argument("type_slide")
      

      
      
      VAR_COEF = _function_argument("coef")
      

      
      
      VAR_IMAGE_ID = _function_argument("image id")
      

      
      
      VAR_RELOAD_ID = _function_argument("reload_id")
      

      
      
      VAR_CAPTCHA_ID = 0
      

      
      
      VAR_PIXEL_KOEF = _function_argument("pixel_koef")
      

      
      
      VAR_AVTOUPDATE = _function_argument("avtoupdate")
      

      
      
      VAR_KEY = _function_argument("key")
      

      
      
      var regexp_result = native("regexp", "first", JSON.stringify({text: VAR_KEY,regexp:"([0-9A-Za-z]\u007b20,40\u007d)"}))
      if(regexp_result.length == 0)
      regexp_result = []
      else
      regexp_result = JSON.parse(regexp_result)
      VAR_ALL_MATCH = regexp_result.pop()
      if(typeof(VAR_ALL_MATCH) == 'undefined' || !VAR_ALL_MATCH)
      VAR_ALL_MATCH = ""
      VAR_KEY = regexp_result[0]
      if(typeof(VAR_KEY) == 'undefined' || !VAR_KEY)
      VAR_KEY = ""
      if(regexp_result.length == 0)
      {
      VAR_KEY = VAR_ALL_MATCH
      }
      

      
      
      VAR_SPEED = _function_argument("speed")
      

      
      
      VAR_TYPE_SWIPE = _function_argument("type_swipe")
      

      
      
      _call(function()
      {
      _on_fail(function(){
      VAR_LAST_ERROR = _result()
      VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
      VAR_WAS_ERROR = false
      _break(1,true)
      })
      CYCLES.Current().RemoveLabel("function")
      
         
         
         /*Browser*/
         waiter_timeout_next(5000)
         wait_async_load()!
         

      },null)!
      

      
      
      /*Browser*/
      ;_SELECTOR=VAR_IMAGE_ID + "\u003eAT\u003e" + VAR_CAPTCHA_ID;
      get_element_selector(_SELECTOR, false).nowait().exist()!
      VAR_IS_EXISTS = _result() == 1
      _if(VAR_IS_EXISTS, function(){
      get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
      VAR_IS_EXISTS = _result().indexOf("true")>=0
      })!
      

      
      
      _do(function(){
      _set_action_info({ name: "While" });
      VAR_CYCLE_INDEX = _iterator() - 1
      BREAK_CONDITION = VAR_IS_EXISTS == false;
      if(!BREAK_CONDITION)_break();
      
         
         
         _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gNQ==");
         _if(VAR_CYCLE_INDEX > 5,function(){
         
            
            
            fail((_K==="en" ? "Captcha not found, reload the page" : "Капча не найдена, перезагрузите страницу"));
            

         })!
         

         
         
         _set_if_expression("W1tCVVRUT05fSURdXSAhPSAiTk9ORSI=");
         _if(VAR_BUTTON_ID != "NONE",function(){
         
            
            
            /*Browser*/
            ;_SELECTOR=VAR_BUTTON_ID;
            get_element_selector(_SELECTOR, false).nowait().exist()!
            VAR_IS_EXISTS = _result() == 1
            _if(VAR_IS_EXISTS, function(){
            get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
            VAR_IS_EXISTS = _result().indexOf("true")>=0
            })!
            

            
            
            _cycle_params().if_else = VAR_IS_EXISTS == false;
            _set_if_expression("W1tJU19FWElTVFNdXSA9PSBmYWxzZQ==");
            _if(_cycle_params().if_else,function(){
            
               
               
               fail((_K==="en" ? "Captcha not found, reload the page" : "Капча не найдена, перезагрузите страницу"));
               

            })!
            

            
            
            _if(!_cycle_params().if_else,function(){
            
               
               
               /*Browser*/
               _SELECTOR = VAR_BUTTON_ID;
               wait_element_visible(_SELECTOR)!
               _call(_random_point, {})!
               _if(_result().length > 0, function(){
               move( {} )!
               get_element_selector(_SELECTOR, false).clarify(X,Y)!
               _call(_clarify, {} )!
               mouse(X,Y)!
               })!
               

               
               
               _call(function()
               {
               _on_fail(function(){
               VAR_LAST_ERROR = _result()
               VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
               VAR_WAS_ERROR = false
               _break(1,true)
               })
               CYCLES.Current().RemoveLabel("function")
               
                  
                  
                  /*Browser*/
                  IDDLE_EMULATION_END = Date.now() + 1000 * (4)
                  IDDLE_EMULATION_DISTRIBUTION = [2,3,3,3,4,4]
                  _get_browser_screen_settings()!
                  IDDLE_EMULATION_RESULT = JSON.parse(_result())
                  IDDLE_CURSOR_POSITION_X = IDDLE_EMULATION_RESULT["CursorX"]
                  IDDLE_CURSOR_POSITION_Y = IDDLE_EMULATION_RESULT["CursorY"]
                  IDDLE_CURSOR_POSITION_WIDTH = IDDLE_EMULATION_RESULT["Width"]
                  IDDLE_CURSOR_POSITION_HEIGHT = IDDLE_EMULATION_RESULT["Height"]
                  IDDLE_CURSOR_POSITION_WAS_SCROLL = false
                  _do(function(){
                  if(Date.now() >= IDDLE_EMULATION_END)
                  _break()
                  IDDLE_EMULATION_CURRENT_ITEM = IDDLE_EMULATION_DISTRIBUTION[Math.floor(Math.random()*IDDLE_EMULATION_DISTRIBUTION.length)]
                  if(_iterator() == 1 && IDDLE_EMULATION_DISTRIBUTION.indexOf(2)>=0)
                  IDDLE_EMULATION_CURRENT_ITEM = 2
                  _if(IDDLE_EMULATION_CURRENT_ITEM == 1, function(){
                  //scroll
                  IDDLE_EMULATION_CURRENT_DIRECTION = (rand(1,2) == 2) ? "<MOUSESCROLLUP>" : "<MOUSESCROLLDOWN>"
                  if(!IDDLE_CURSOR_POSITION_WAS_SCROLL)
                  IDDLE_EMULATION_CURRENT_DIRECTION = "<MOUSESCROLLDOWN>"
                  IDDLE_CURSOR_POSITION_WAS_SCROLL = true
                  IDDLE_EMULATION_CURRENT_NUMBER = rand(1,5)
                  _do(function(){
                  if(_iterator() >= IDDLE_EMULATION_CURRENT_NUMBER)
                  _break()
                  _type(IDDLE_EMULATION_CURRENT_DIRECTION,1000)!
                  sleep(rand(300,1000))!
                  })!
                  })!
                  _if(IDDLE_EMULATION_CURRENT_ITEM == 2, function(){
                  //long move
                  page().script("document.documentElement.scrollLeft")!
                  IDDLE_CURSOR_POSITION_SCROLL_X = parseInt(_result())
                  page().script("document.documentElement.scrollTop")!
                  IDDLE_CURSOR_POSITION_SCROLL_Y = parseInt(_result())
                  IDDLE_CURSOR_POSITION_X = rand(1,IDDLE_CURSOR_POSITION_WIDTH)
                  IDDLE_CURSOR_POSITION_Y = rand(1,IDDLE_CURSOR_POSITION_HEIGHT)
                  move(IDDLE_CURSOR_POSITION_SCROLL_X + IDDLE_CURSOR_POSITION_X,IDDLE_CURSOR_POSITION_SCROLL_Y + IDDLE_CURSOR_POSITION_Y)!
                  })!
                  _if(IDDLE_EMULATION_CURRENT_ITEM == 3, function(){
                  //short move
                  if(IDDLE_CURSOR_POSITION_X < 0 || IDDLE_CURSOR_POSITION_Y < 0)
                  _break()
                  page().script("document.documentElement.scrollLeft")!
                  IDDLE_CURSOR_POSITION_SCROLL_X = parseInt(_result())
                  page().script("document.documentElement.scrollTop")!
                  IDDLE_CURSOR_POSITION_SCROLL_Y = parseInt(_result())
                  IDDLE_EMULATION_CURRENT_NUMBER = rand(1,4)
                  _do(function(){
                  if(_iterator() >= IDDLE_EMULATION_CURRENT_NUMBER)
                  _break()
                  IDDLE_CURSOR_POSITION_X += rand(-50,50)
                  IDDLE_CURSOR_POSITION_Y += rand(-50,50)
                  if(IDDLE_CURSOR_POSITION_X > IDDLE_CURSOR_POSITION_WIDTH)
                  IDDLE_CURSOR_POSITION_X = IDDLE_CURSOR_POSITION_WIDTH
                  if(IDDLE_CURSOR_POSITION_Y > IDDLE_CURSOR_POSITION_HEIGHT)
                  IDDLE_CURSOR_POSITION_Y = IDDLE_CURSOR_POSITION_HEIGHT
                  if(IDDLE_CURSOR_POSITION_X < 0)
                  IDDLE_CURSOR_POSITION_X = 0
                  if(IDDLE_CURSOR_POSITION_Y < 0)
                  IDDLE_CURSOR_POSITION_Y = 0
                  move(IDDLE_CURSOR_POSITION_SCROLL_X + IDDLE_CURSOR_POSITION_X,IDDLE_CURSOR_POSITION_SCROLL_Y + IDDLE_CURSOR_POSITION_Y)!
                  _if(rand(1,10) > 3,function(){
                  sleep(rand(10,300))!
                  })!
                  })!
                  })!
                  _if(IDDLE_EMULATION_CURRENT_ITEM == 4, function(){
                  //sleep
                  sleep(rand(500,5000))!
                  })!
                  })!
                  

               },null)!
               

            })!
            delete _cycle_params().if_else;
            

         })!
         

         
         
         /*Browser*/
         ;_SELECTOR=VAR_IMAGE_ID;
         get_element_selector(_SELECTOR, true).length()!
         VAR_ELEMENT_LENGTH = _result()
         

         
         
         _cycle_params().if_else = VAR_ELEMENT_LENGTH > 1;
         _set_if_expression("W1tFTEVNRU5UX0xFTkdUSF1dID4gMQ==");
         _if(_cycle_params().if_else,function(){
         
            
            
            _do(function(){
            _set_action_info({ name: "For" });
            VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(0)
            if(VAR_CYCLE_INDEX > parseInt(VAR_ELEMENT_LENGTH - 1))_break();
            
               
               
               /*Browser*/
               ;_SELECTOR=VAR_IMAGE_ID + "\u003eAT\u003e" + VAR_CYCLE_INDEX;
               get_element_selector(_SELECTOR, false).nowait().exist()!
               VAR_IS_EXISTS = _result() == 1
               _if(VAR_IS_EXISTS, function(){
               get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
               VAR_IS_EXISTS = _result().indexOf("true")>=0
               })!
               

               
               
               _set_if_expression("W1tJU19FWElTVFNdXQ==");
               _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
               
                  
                  
                  VAR_CAPTCHA_ID = VAR_CYCLE_INDEX
                  

                  
                  
                  _break("function")
                  

               })!
               

            })!
            

         })!
         

         
         
         _if(!_cycle_params().if_else,function(){
         
            
            
            /*Browser*/
            ;_SELECTOR=VAR_IMAGE_ID + "\u003eAT\u003e" + VAR_CAPTCHA_ID;
            get_element_selector(_SELECTOR, false).nowait().exist()!
            VAR_IS_EXISTS = _result() == 1
            _if(VAR_IS_EXISTS, function(){
            get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
            VAR_IS_EXISTS = _result().indexOf("true")>=0
            })!
            

         })!
         delete _cycle_params().if_else;
         

      })!
      

      
      
      /*Browser*/
      ;_SELECTOR=VAR_IMAGE_ID + "\u003eAT\u003e" + VAR_CAPTCHA_ID;
      get_element_selector(_SELECTOR, false).nowait().exist()!
      VAR_IS_EXISTS = _result() == 1
      _if(VAR_IS_EXISTS, function(){
      get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
      VAR_IS_EXISTS = _result().indexOf("true")>=0
      })!
      

      
      
      _do(function(){
      _set_action_info({ name: "While" });
      VAR_CYCLE_INDEX = _iterator() - 1
      BREAK_CONDITION = VAR_IS_EXISTS;
      if(!BREAK_CONDITION)_break();
      
         
         
         _set_if_expression("W1tDWUNMRV9JTkRFWF1dID49IDk=");
         _if(VAR_CYCLE_INDEX >= 9,function(){
         
            
            
            fail((_K==="en" ? "The captcha has not been solved in 10 tries" : "Капча не решена за 10 попыток"));
            

         })!
         

         
         
         /*Browser*/
         _SELECTOR = VAR_IMAGE_ID + "\u003eAT\u003e" + VAR_CAPTCHA_ID;
         wait_element(_SELECTOR)!
         get_element_selector(_SELECTOR, false).exist()!
         _if(_result() == "1", function(){
         get_element_selector(_SELECTOR, false).render_base64()!
         VAR_SCREENSHOT_BASE64 = _result()
         })!
         

         
         
         VAR_STRING_LENGTH = VAR_SCREENSHOT_BASE64.length
         

         
         
         _set_if_expression("W1tTVFJJTkdfTEVOR1RIXV0gPCAxMDAwICYmIFtbQ1lDTEVfSU5ERVhdXSA9PSAw");
         _if(VAR_STRING_LENGTH < 1000 && VAR_CYCLE_INDEX == 0,function(){
         
            
            
            fail((_K==="en" ? "The image is too small, you obviously set the wrong image ID" : "Слишком маленькая картинка, вы явно задали не тот идентификатор изображения"));
            

         })!
         

         
         
         _set_if_expression("W1tTVFJJTkdfTEVOR1RIXV0gPCAxMDAwICYmIFtbQ1lDTEVfSU5ERVhdXSAhPSAw");
         _if(VAR_STRING_LENGTH < 1000 && VAR_CYCLE_INDEX != 0,function(){
         
            
            
            _function_return("good")
            

         })!
         

         
         
         _do(function(){
         _set_action_info({ name: "For" });
         VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
         if(VAR_CYCLE_INDEX > parseInt(3))_break();
         
            
            
            _set_if_expression("W1tDWUNMRV9JTkRFWF1dID49IDM=");
            _if(VAR_CYCLE_INDEX >= 3,function(){
            
               
               
               fail_user(VAR_LAST_ERROR,false)
               

            })!
            

            
            
            _call(function()
            {
            _on_fail(function(){
            VAR_LAST_ERROR = _result()
            VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
            VAR_WAS_ERROR = false
            _break(1,true)
            })
            CYCLES.Current().RemoveLabel("function")
            
               
               
               _switch_http_client_main()
               http_client_post("http://goodxevilpay.pp.ua/in.php", ["method","geetest","key",VAR_KEY,"body",VAR_SCREENSHOT_BASE64], {"content-type":("multipart"), "encoding":("UTF-8"), "method":("POST"),headers:("")})!
               

               
               
               _switch_http_client_main()
               VAR_SAVED_CONTENT = http_client_encoded_content("utf-8")
               

               
               
               _break("function")
               

            },null)!
            

         })!
         

         
         
         VAR_STRING_CONTAINS = Boolean(native("regexp", "ismatch", JSON.stringify({text: VAR_SAVED_CONTENT,regexp:"(\u005c|)"})) == "true")
         

         
         
         _set_if_expression("W1tTVFJJTkdfQ09OVEFJTlNdXSA9PSBmYWxzZQ==");
         _if(VAR_STRING_CONTAINS == false,function(){
         
            
            
            fail_user(VAR_SAVED_CONTENT,false)
            

         })!
         

         
         
         sleep(1000)!
         

         
         
         VAR_ID = VAR_SAVED_CONTENT.split("|")[1]
         

         
         
         _do(function(){
         _set_action_info({ name: "For" });
         VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
         if(VAR_CYCLE_INDEX > parseInt(3))_break();
         
            
            
            _set_if_expression("W1tDWUNMRV9JTkRFWF1dID49IDM=");
            _if(VAR_CYCLE_INDEX >= 3,function(){
            
               
               
               fail_user(VAR_LAST_ERROR,false)
               

            })!
            

            
            
            _call(function()
            {
            _on_fail(function(){
            VAR_LAST_ERROR = _result()
            VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
            VAR_WAS_ERROR = false
            _break(1,true)
            })
            CYCLES.Current().RemoveLabel("function")
            
               
               
               _switch_http_client_main()
               http_client_get2("http://goodxevilpay.pp.ua/res.php?key=" + VAR_KEY + "\u0026id=" + VAR_ID,{method:("GET"),headers:("")})!
               

               
               
               _switch_http_client_main()
               VAR_SAVED_CONTENT = http_client_encoded_content("utf-8")
               

               
               
               _do(function(){
               _set_action_info({ name: "While" });
               VAR_CYCLE_INDEX = _iterator() - 1
               BREAK_CONDITION = VAR_SAVED_CONTENT == "CAPCHA_NOT_READY";
               if(!BREAK_CONDITION)_break();
               
                  
                  
                  sleep(1000)!
                  

                  
                  
                  _switch_http_client_main()
                  http_client_get2("http://goodxevilpay.pp.ua/res.php?key=" + VAR_KEY + "\u0026id=" + VAR_ID,{method:("GET"),headers:("")})!
                  

                  
                  
                  _switch_http_client_main()
                  VAR_SAVED_CONTENT = http_client_encoded_content("utf-8")
                  

               })!
               

               
               
               _break("function")
               

            },null)!
            

         })!
         

         
         
         VAR_STRING_CONTAINS = Boolean(native("regexp", "ismatch", JSON.stringify({text: VAR_SAVED_CONTENT,regexp:"(\u005c|)"})) == "true")
         

         
         
         _set_if_expression("W1tTVFJJTkdfQ09OVEFJTlNdXSA9PSBmYWxzZQ==");
         _if(VAR_STRING_CONTAINS == false,function(){
         
            
            
            /*Browser*/
            _SELECTOR = VAR_RELOAD_ID + "\u003eAT\u003e" + VAR_CAPTCHA_ID;waiter_timeout_next(1000)
            waiter_nofail_next();
            wait_element_visible(_SELECTOR)!
            _call(_random_point, {})!
            _if(_result().length > 0, function(){
            move( {} )!
            get_element_selector(_SELECTOR, false).nowait().clarify(X,Y)!
            _call(_clarify, {} )!
            mouse(X,Y)!
            })!
            

            
            
            _call(function()
            {
            _on_fail(function(){
            VAR_LAST_ERROR = _result()
            VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
            VAR_WAS_ERROR = false
            _break(1,true)
            })
            CYCLES.Current().RemoveLabel("function")
            
               
               
               /*Browser*/
               waiter_timeout_next(15000)
               wait_async_load()!
               

            },null)!
            

            
            
            _next("function")
            

         })!
         

         
         
         VAR_SCAN_RESULT_LIST = native("regexp", "scan", JSON.stringify({text: VAR_SAVED_CONTENT,regexp:"\u005cd+"}))
         if(VAR_SCAN_RESULT_LIST.length == 0)
         VAR_SCAN_RESULT_LIST = []
         else
         VAR_SCAN_RESULT_LIST = JSON.parse(VAR_SCAN_RESULT_LIST)
         

         
         
         VAR_LIST_LENGTH = (VAR_SCAN_RESULT_LIST).length
         

         
         
         _set_if_expression("W1tMSVNUX0xFTkdUSF1dICE9IDM=");
         _if(VAR_LIST_LENGTH != 3,function(){
         
            
            
            fail((_K==="en" ? "Unclear response from the server" : "Не понятный ответ от сервера"));
            

         })!
         

         
         
         VAR_X_XEVIL = (parseInt(VAR_SCAN_RESULT_LIST[0]) * VAR_COEF) + VAR_PIXEL_KOEF;
         VAR_Y_XEVIL = parseInt(VAR_SCAN_RESULT_LIST[1]);
         VAR_W_XEVIL = parseInt(VAR_SCAN_RESULT_LIST[2]);
         

         
         
         /*Browser*/
         scroll(1,1)!
         

         
         
         /*Browser*/
         _SELECTOR = VAR_ARROW_ID + "\u003eAT\u003e" + VAR_CAPTCHA_ID;
         wait_element(_SELECTOR)!
         get_element_selector(_SELECTOR, false).script("(function(){var rect = self.getBoundingClientRect();return (rect.left + positionx).toString() + '|' + (rect.top + positiony).toString() + '|' + (rect.right - rect.left).toString() + '|' + (rect.bottom - rect.top).toString()})();")!
         if(_result().length > 0)
         {
         var split = _result().split("|")
         VAR_X = parseInt(split[0])
         VAR_Y = parseInt(split[1])
         VAR_WIDTH = parseInt(split[2])
         VAR_HEIGHT = parseInt(split[3])
         }
         

         
         
         _cycle_params().if_else = VAR_TYPE_SLIDE == true;
         _set_if_expression("W1tUWVBFX1NMSURFXV0gPT0gdHJ1ZQ==");
         _if(_cycle_params().if_else,function(){
         
            
            
            /*Browser*/
            move(VAR_X + (VAR_WIDTH/2),VAR_Y + (VAR_HEIGHT/2),  {"speed": 100*VAR_SPEED,"gravity": 6,"deviation": 2.5} )!
            mouse_down(VAR_X + (VAR_WIDTH/2),VAR_Y + (VAR_HEIGHT/2))!
            

         })!
         

         
         
         _if(!_cycle_params().if_else,function(){
         
            
            
            /*Browser*/
            _SELECTOR = VAR_ARROW_ID + "\u003eAT\u003e" + VAR_CAPTCHA_ID;
            wait_element_visible(_SELECTOR)!
            _call(_random_point, {})!
            _if(_result().length > 0, function(){
            move( {} )!
            get_element_selector(_SELECTOR, false).clarify(X,Y)!
            _call(_clarify, {} )!
            mouse_down(X,Y)!
            })!
            

         })!
         delete _cycle_params().if_else;
         

         
         
         _set_if_expression("W1tUWVBFX1NXSVBFXV0gPT0gMQ==");
         _if(VAR_TYPE_SWIPE == 1,function(){
         
            
            
            VAR_RANDOM_SPEED = Math.floor(Math.random() * (parseInt(200) - parseInt(100) + 1)) + parseInt(100)
            

            
            
            VAR_RANDOM_PR = Math.floor(Math.random() * (parseInt(9) - parseInt(5) + 1)) + parseInt(5)
            

            
            
            /*Browser*/
            move(VAR_X+ (VAR_X_XEVIL/1.2),VAR_Y,  {"speed": VAR_RANDOM_SPEED*VAR_SPEED,"gravity": VAR_RANDOM_PR,"deviation": 4} )!
            

            
            
            VAR_RANDOM_SPEED = Math.floor(Math.random() * (parseInt(60) - parseInt(10) + 1)) + parseInt(10)
            

            
            
            VAR_RANDOM_PR = Math.floor(Math.random() * (parseInt(10) - parseInt(7) + 1)) + parseInt(7)
            

            
            
            /*Browser*/
            move(VAR_X+VAR_X_XEVIL + VAR_W_XEVIL/2,VAR_Y,  {"speed": VAR_RANDOM_SPEED*VAR_SPEED,"gravity": VAR_RANDOM_PR,"deviation": 0} )!
            

            
            
            VAR_RANDOM_Y = Math.floor(Math.random() * (parseInt(15) - parseInt(-15) + 1)) + parseInt(-15)
            

            
            
            /*Browser*/
            var move_settings =  {"speed": 50*VAR_SPEED,"gravity": 9,"deviation": 0} ;
            move_settings["do_mouse_up"] = "true"
            move(VAR_X+VAR_X_XEVIL + VAR_W_XEVIL/2,VAR_Y + VAR_RANDOM_Y, move_settings)!
            

         })!
         

         
         
         _set_if_expression("W1tUWVBFX1NXSVBFXV0gPT0gMg==");
         _if(VAR_TYPE_SWIPE == 2,function(){
         
            
            
            VAR_RANDOM_SPEED = Math.floor(Math.random() * (parseInt(40) - parseInt(20) + 1)) + parseInt(20)
            

            
            
            VAR_RANDOM_PR = Math.floor(Math.random() * (parseInt(4) - parseInt(3) + 1)) + parseInt(3)
            

            
            
            VAR_RANDOM_RT = Math.floor(Math.random() * (parseInt(2) - parseInt(1) + 1)) + parseInt(1)
            

            
            
            VAR_RANDOM_Y = Math.floor(Math.random() * (parseInt(5) - parseInt(-5) + 1)) + parseInt(-5)
            

            
            
            /*Browser*/
            var move_settings =  {"speed": VAR_RANDOM_SPEED*VAR_SPEED,"gravity": VAR_RANDOM_PR,"deviation": VAR_RANDOM_RT} ;
            move_settings["do_mouse_up"] = "true"
            move(VAR_WIDTH/2 + VAR_X+VAR_X_XEVIL + VAR_W_XEVIL/2,VAR_Y + VAR_RANDOM_Y, move_settings)!
            

         })!
         

         
         
         _set_if_expression("W1tUWVBFX1NXSVBFXV0gPT0gMw==");
         _if(VAR_TYPE_SWIPE == 3,function(){
         
            
            
            VAR_RANDOM_SPEED = Math.floor(Math.random() * (parseInt(200) - parseInt(150) + 1)) + parseInt(150)
            

            
            
            VAR_RANDOM_PR = Math.floor(Math.random() * (parseInt(4) - parseInt(3) + 1)) + parseInt(3)
            

            
            
            VAR_RANDOM_RT = Math.floor(Math.random() * (parseInt(3) - parseInt(2) + 1)) + parseInt(2)
            

            
            
            VAR_RANDOM_Y = Math.floor(Math.random() * (parseInt(5) - parseInt(-5) + 1)) + parseInt(-5)
            

            
            
            /*Browser*/
            var move_settings =  {"speed": VAR_RANDOM_SPEED*VAR_SPEED,"gravity": VAR_RANDOM_PR,"deviation": VAR_RANDOM_RT} ;
            move_settings["do_mouse_up"] = "true"
            move(VAR_WIDTH/2 + VAR_X+VAR_X_XEVIL + VAR_W_XEVIL/2,VAR_Y + VAR_RANDOM_Y, move_settings)!
            

         })!
         

         
         
         _set_if_expression("W1tUWVBFX1NXSVBFXV0gPT0gNA==");
         _if(VAR_TYPE_SWIPE == 4,function(){
         
            
            
            VAR_RANDOM_SPEED = Math.floor(Math.random() * (parseInt(200) - parseInt(150) + 1)) + parseInt(150)
            

            
            
            VAR_RANDOM_PR = Math.floor(Math.random() * (parseInt(9) - parseInt(7) + 1)) + parseInt(7)
            

            
            
            VAR_RANDOM_RT = Math.floor(Math.random() * (parseInt(1) - parseInt(0) + 1)) + parseInt(0)
            

            
            
            VAR_RANDOM_Y = Math.floor(Math.random() * (parseInt(5) - parseInt(-5) + 1)) + parseInt(-5)
            

            
            
            /*Browser*/
            var move_settings =  {"speed": VAR_RANDOM_SPEED*VAR_SPEED,"gravity": VAR_RANDOM_PR,"deviation": VAR_RANDOM_RT} ;
            move_settings["do_mouse_up"] = "true"
            move(VAR_WIDTH/2 + VAR_X+VAR_X_XEVIL + VAR_W_XEVIL/2,VAR_Y + VAR_RANDOM_Y, move_settings)!
            

         })!
         

         
         
         _call(function()
         {
         _on_fail(function(){
         VAR_LAST_ERROR = _result()
         VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
         VAR_WAS_ERROR = false
         _break(1,true)
         })
         CYCLES.Current().RemoveLabel("function")
         
            
            
            /*Browser*/
            waiter_timeout_next(5000)
            wait_async_load()!
            

         },null)!
         

         
         
         /*Browser*/
         ;_SELECTOR=VAR_IMAGE_ID + "\u003eAT\u003e" + VAR_CAPTCHA_ID;
         get_element_selector(_SELECTOR, false).nowait().exist()!
         VAR_IS_EXISTS = _result() == 1
         _if(VAR_IS_EXISTS, function(){
         get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
         VAR_IS_EXISTS = _result().indexOf("true")>=0
         })!
         

         
         
         /*Browser*/
         ;_SELECTOR=VAR_ARROW_ID + "\u003eAT\u003e" + VAR_CAPTCHA_ID;
         get_element_selector(_SELECTOR, false).nowait().exist()!
         VAR_IS_EXISTS2 = _result() == 1
         _if(VAR_IS_EXISTS2, function(){
         get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
         VAR_IS_EXISTS2 = _result().indexOf("true")>=0
         })!
         

         
         
         /*Browser*/
         ;_SELECTOR=VAR_RELOAD_ID + "\u003eAT\u003e" + VAR_CAPTCHA_ID;
         get_element_selector(_SELECTOR, false).nowait().exist()!
         VAR_IS_EXISTS3 = _result() == 1
         _if(VAR_IS_EXISTS3, function(){
         get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
         VAR_IS_EXISTS3 = _result().indexOf("true")>=0
         })!
         

         
         
         _set_if_expression("W1tBVlRPVVBEQVRFXV0gPT0gZmFsc2U=");
         _if(VAR_AVTOUPDATE == false,function(){
         
            
            
            _set_if_expression("W1tJU19FWElTVFNdXSAmJiBbW0lTX0VYSVNUUzJdXSAmJiBbW0lTX0VYSVNUUzNdXQ==");
            _if(VAR_IS_EXISTS && VAR_IS_EXISTS2 && VAR_IS_EXISTS3,function(){
            
               
               
               /*Browser*/
               _SELECTOR = VAR_RELOAD_ID + "\u003eAT\u003e" + VAR_CAPTCHA_ID;waiter_timeout_next(1000)
               waiter_nofail_next();
               wait_element_visible(_SELECTOR)!
               _call(_random_point, {})!
               _if(_result().length > 0, function(){
               move( {} )!
               get_element_selector(_SELECTOR, false).nowait().clarify(X,Y)!
               _call(_clarify, {} )!
               mouse(X,Y)!
               })!
               

               
               
               _call(function()
               {
               _on_fail(function(){
               VAR_LAST_ERROR = _result()
               VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
               VAR_WAS_ERROR = false
               _break(1,true)
               })
               CYCLES.Current().RemoveLabel("function")
               
                  
                  
                  /*Browser*/
                  waiter_timeout_next(15000)
                  wait_async_load()!
                  

               },null)!
               

            })!
            

         })!
         

      })!
      

   }
   

function GoodXevilPaySolver_GXP_SolverGeetestIcon()
   {
   
      
      
      /*Browser*/
      scroll(1,1)!
      

      
      
      /*Browser*/
      cache_allow("*static.geetest.com/captcha_v4/*")!
      

      
      
      /*Browser*/
      cache_allow("*static.geetest.com/nerualpic/original_icon_pic/*")!
      

      
      
      /*Browser*/
      cache_allow("*static.geetest.com/captcha_v3/*")!
      

      
      
      VAR_BUTTON_CAPTHCA = _function_argument("button_capthca")
      

      
      
      VAR_FOTO_CAPTCHA = _function_argument("foto_captcha")
      

      
      
      VAR_RELOAD_CAPTCHA = _function_argument("reload_captcha")
      

      
      
      VAR_APIKEY = _function_argument("apikey")
      

      
      
      VAR_CAPTCHA_SUBMIT = _function_argument("captcha_submit")
      

      
      
      VAR_CAPTCHA_ID = 0
      

      
      
      var regexp_result = native("regexp", "first", JSON.stringify({text: VAR_APIKEY,regexp:"([A-Za-z0-9]+)"}))
      if(regexp_result.length == 0)
      regexp_result = []
      else
      regexp_result = JSON.parse(regexp_result)
      VAR_ALL_MATCH = regexp_result.pop()
      if(typeof(VAR_ALL_MATCH) == 'undefined' || !VAR_ALL_MATCH)
      VAR_ALL_MATCH = ""
      VAR_APIKEY = regexp_result[0]
      if(typeof(VAR_APIKEY) == 'undefined' || !VAR_APIKEY)
      VAR_APIKEY = ""
      if(regexp_result.length == 0)
      {
      VAR_APIKEY = VAR_ALL_MATCH
      }
      

      
      
      _set_if_expression("W1tBUElLRVldXSA9PSAiIg==");
      _if(VAR_APIKEY == "",function(){
      
         
         
         fail((_K==="en" ? "Bad API key" : "Не верный API ключ"));
         

      })!
      

      
      
      VAR_URL_ADRESS_SOLVER = "http://127.0.0.1:10000"
      

      
      
      VAR_URL_ADRESS_SOLVER = "http://goodxevilpay.pp.ua"
      

      
      
      VAR_TRY_SOLVE = 0
      

      
      
      VAR_CAPTCHA_FIND = false
      

      
      
      _do(function(){
      _set_action_info({ name: "While" });
      VAR_CYCLE_INDEX = _iterator() - 1
      BREAK_CONDITION = true;
      if(!BREAK_CONDITION)_break();
      
         
         
         _set_if_expression("W1tUUllfU09MVkVdXSA+PSAxMA==");
         _if(VAR_TRY_SOLVE >= 10,function(){
         
            
            
            fail((_K==="en" ? "Fail solve captcha" : "Ошибка при решении капчи"));
            

         })!
         

         
         
         VAR_FIND_FOTO = 0
         

         
         
         _do(function(){
         _set_action_info({ name: "While" });
         VAR_CYCLE_INDEX = _iterator() - 1
         BREAK_CONDITION = true;
         if(!BREAK_CONDITION)_break();
         
            
            
            _set_if_expression("W1tDQVBUQ0hBX0ZJTkRdXSA9PSBmYWxzZQ==");
            _if(VAR_CAPTCHA_FIND == false,function(){
            
               
               
               _do(function(){
               _set_action_info({ name: "For" });
               VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(0)
               if(VAR_CYCLE_INDEX > parseInt(5))_break();
               
                  
                  
                  /*Browser*/
                  ;_SELECTOR=VAR_RELOAD_CAPTCHA + "\u003eAT\u003e" + VAR_CAPTCHA_ID;
                  get_element_selector(_SELECTOR, false).nowait().exist()!
                  VAR_IS_EXISTS = _result() == 1
                  _if(VAR_IS_EXISTS, function(){
                  get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
                  VAR_IS_EXISTS = _result().indexOf("true")>=0
                  })!
                  

                  
                  
                  _set_if_expression("W1tJU19FWElTVFNdXQ==");
                  _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
                  
                     
                     
                     VAR_CAPTCHA_FIND = true
                     

                     
                     
                     VAR_CAPTCHA_ID = VAR_CYCLE_INDEX
                     

                     
                     
                     _break("function")
                     

                  })!
                  

               })!
               

            })!
            

            
            
            _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gNQ==");
            _if(VAR_CYCLE_INDEX > 5,function(){
            
               
               
               VAR_FIND_FOTO = 0
               

               
               
               VAR_TRY_SOLVE = parseInt(VAR_TRY_SOLVE) + parseInt(1)
               

               
               
               _break("function")
               

            })!
            

            
            
            _set_if_expression("W1tUUllfU09MVkVdXSAhPSAw");
            _if(VAR_TRY_SOLVE != 0,function(){
            
               
               
               _do(function(){
               _set_action_info({ name: "While" });
               VAR_CYCLE_INDEX = _iterator() - 1
               BREAK_CONDITION = true;
               if(!BREAK_CONDITION)_break();
               
                  
                  
                  _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gNQ==");
                  _if(VAR_CYCLE_INDEX > 5,function(){
                  
                     
                     
                     _function_return("GoodSolver")
                     

                  })!
                  

                  
                  
                  /*Browser*/
                  ;_SELECTOR=VAR_BUTTON_CAPTHCA + " \u0026\u0026 " + VAR_CAPTCHA_FIND + " == false";
                  get_element_selector(_SELECTOR, false).nowait().exist()!
                  VAR_IS_EXISTS = _result() == 1
                  _if(VAR_IS_EXISTS, function(){
                  get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
                  VAR_IS_EXISTS = _result().indexOf("true")>=0
                  })!
                  

                  
                  
                  _set_if_expression("W1tJU19FWElTVFNdXQ==");
                  _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
                  
                     
                     
                     _break("function")
                     

                  })!
                  

                  
                  
                  /*Browser*/
                  ;_SELECTOR=VAR_RELOAD_CAPTCHA + "\u003eAT\u003e" + VAR_CAPTCHA_ID;
                  get_element_selector(_SELECTOR, false).nowait().exist()!
                  VAR_IS_EXISTS = _result() == 1
                  _if(VAR_IS_EXISTS, function(){
                  get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
                  VAR_IS_EXISTS = _result().indexOf("true")>=0
                  })!
                  

                  
                  
                  _set_if_expression("W1tJU19FWElTVFNdXQ==");
                  _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
                  
                     
                     
                     _break("function")
                     

                  })!
                  

               })!
               

            })!
            

            
            
            VAR_RANDOM_NUMBER = Math.floor(Math.random() * (parseInt(100) - parseInt(0) + 1)) + parseInt(0)
            

            
            
            _cycle_params().if_else = VAR_RANDOM_NUMBER > 95;
            _set_if_expression("W1tSQU5ET01fTlVNQkVSXV0gPiA5NQ==");
            _if(_cycle_params().if_else,function(){
            
               
               
               /*Browser*/
               IDDLE_EMULATION_END = Date.now() + 1000 * (1)
               IDDLE_EMULATION_DISTRIBUTION = [2,3,3,3,4,4]
               _get_browser_screen_settings()!
               IDDLE_EMULATION_RESULT = JSON.parse(_result())
               IDDLE_CURSOR_POSITION_X = IDDLE_EMULATION_RESULT["CursorX"]
               IDDLE_CURSOR_POSITION_Y = IDDLE_EMULATION_RESULT["CursorY"]
               IDDLE_CURSOR_POSITION_WIDTH = IDDLE_EMULATION_RESULT["Width"]
               IDDLE_CURSOR_POSITION_HEIGHT = IDDLE_EMULATION_RESULT["Height"]
               IDDLE_CURSOR_POSITION_WAS_SCROLL = false
               _do(function(){
               if(Date.now() >= IDDLE_EMULATION_END)
               _break()
               IDDLE_EMULATION_CURRENT_ITEM = IDDLE_EMULATION_DISTRIBUTION[Math.floor(Math.random()*IDDLE_EMULATION_DISTRIBUTION.length)]
               if(_iterator() == 1 && IDDLE_EMULATION_DISTRIBUTION.indexOf(2)>=0)
               IDDLE_EMULATION_CURRENT_ITEM = 2
               _if(IDDLE_EMULATION_CURRENT_ITEM == 1, function(){
               //scroll
               IDDLE_EMULATION_CURRENT_DIRECTION = (rand(1,2) == 2) ? "<MOUSESCROLLUP>" : "<MOUSESCROLLDOWN>"
               if(!IDDLE_CURSOR_POSITION_WAS_SCROLL)
               IDDLE_EMULATION_CURRENT_DIRECTION = "<MOUSESCROLLDOWN>"
               IDDLE_CURSOR_POSITION_WAS_SCROLL = true
               IDDLE_EMULATION_CURRENT_NUMBER = rand(1,5)
               _do(function(){
               if(_iterator() >= IDDLE_EMULATION_CURRENT_NUMBER)
               _break()
               _type(IDDLE_EMULATION_CURRENT_DIRECTION,1000)!
               sleep(rand(300,1000))!
               })!
               })!
               _if(IDDLE_EMULATION_CURRENT_ITEM == 2, function(){
               //long move
               page().script("document.documentElement.scrollLeft")!
               IDDLE_CURSOR_POSITION_SCROLL_X = parseInt(_result())
               page().script("document.documentElement.scrollTop")!
               IDDLE_CURSOR_POSITION_SCROLL_Y = parseInt(_result())
               IDDLE_CURSOR_POSITION_X = rand(1,IDDLE_CURSOR_POSITION_WIDTH)
               IDDLE_CURSOR_POSITION_Y = rand(1,IDDLE_CURSOR_POSITION_HEIGHT)
               move(IDDLE_CURSOR_POSITION_SCROLL_X + IDDLE_CURSOR_POSITION_X,IDDLE_CURSOR_POSITION_SCROLL_Y + IDDLE_CURSOR_POSITION_Y)!
               })!
               _if(IDDLE_EMULATION_CURRENT_ITEM == 3, function(){
               //short move
               if(IDDLE_CURSOR_POSITION_X < 0 || IDDLE_CURSOR_POSITION_Y < 0)
               _break()
               page().script("document.documentElement.scrollLeft")!
               IDDLE_CURSOR_POSITION_SCROLL_X = parseInt(_result())
               page().script("document.documentElement.scrollTop")!
               IDDLE_CURSOR_POSITION_SCROLL_Y = parseInt(_result())
               IDDLE_EMULATION_CURRENT_NUMBER = rand(1,4)
               _do(function(){
               if(_iterator() >= IDDLE_EMULATION_CURRENT_NUMBER)
               _break()
               IDDLE_CURSOR_POSITION_X += rand(-50,50)
               IDDLE_CURSOR_POSITION_Y += rand(-50,50)
               if(IDDLE_CURSOR_POSITION_X > IDDLE_CURSOR_POSITION_WIDTH)
               IDDLE_CURSOR_POSITION_X = IDDLE_CURSOR_POSITION_WIDTH
               if(IDDLE_CURSOR_POSITION_Y > IDDLE_CURSOR_POSITION_HEIGHT)
               IDDLE_CURSOR_POSITION_Y = IDDLE_CURSOR_POSITION_HEIGHT
               if(IDDLE_CURSOR_POSITION_X < 0)
               IDDLE_CURSOR_POSITION_X = 0
               if(IDDLE_CURSOR_POSITION_Y < 0)
               IDDLE_CURSOR_POSITION_Y = 0
               move(IDDLE_CURSOR_POSITION_SCROLL_X + IDDLE_CURSOR_POSITION_X,IDDLE_CURSOR_POSITION_SCROLL_Y + IDDLE_CURSOR_POSITION_Y)!
               _if(rand(1,10) > 3,function(){
               sleep(rand(10,300))!
               })!
               })!
               })!
               _if(IDDLE_EMULATION_CURRENT_ITEM == 4, function(){
               //sleep
               sleep(rand(500,5000))!
               })!
               })!
               

            })!
            

            
            
            _if(!_cycle_params().if_else,function(){
            
               
               
               sleep(1000)!
               

            })!
            delete _cycle_params().if_else;
            

            
            
            VAR_VWERSION2 = 0
            

            
            
            /*Browser*/
            _cache_get_all("*static.geetest.com/captcha_v4/*")!
            VAR_CACHE_LIST = JSON.parse(_result())
            

            
            
            VAR_LIST_LENGTH = (VAR_CACHE_LIST).length
            

            
            
            _set_if_expression("W1tMSVNUX0xFTkdUSF1dID09IDA=");
            _if(VAR_LIST_LENGTH == 0,function(){
            
               
               
               /*Browser*/
               _cache_get_all("*static.geetest.com/captcha_v3/*")!
               VAR_CACHE_LIST = JSON.parse(_result())
               

               
               
               VAR_LIST_LENGTH = (VAR_CACHE_LIST).length
               

               
               
               _set_if_expression("W1tMSVNUX0xFTkdUSF1dICE9IDA=");
               _if(VAR_LIST_LENGTH != 0,function(){
               
                  
                  
                  VAR_VWERSION2 = 1
                  

               })!
               

            })!
            

            
            
            VAR_LIST_LENGTH = (VAR_CACHE_LIST).length
            

            
            
            _set_if_expression("W1tMSVNUX0xFTkdUSF1dID09IDA=");
            _if(VAR_LIST_LENGTH == 0,function(){
            
               
               
               _next("function")
               

            })!
            

            
            
            VAR_MAIN_FOTO = VAR_CACHE_LIST[0]["body"]
            

            
            
            _set_if_expression("W1tNQUlOX0ZPVE9dXSA9PSAiIg==");
            _if(VAR_MAIN_FOTO == "",function(){
            
               
               
               _next("function")
               

            })!
            

            
            
            VAR_RANDOM_NUMBER = Math.floor(Math.random() * (parseInt(100) - parseInt(0) + 1)) + parseInt(0)
            

            
            
            _cycle_params().if_else = VAR_RANDOM_NUMBER > 95;
            _set_if_expression("W1tSQU5ET01fTlVNQkVSXV0gPiA5NQ==");
            _if(_cycle_params().if_else,function(){
            
               
               
               /*Browser*/
               IDDLE_EMULATION_END = Date.now() + 1000 * (1)
               IDDLE_EMULATION_DISTRIBUTION = [2,3,3,3,4,4]
               _get_browser_screen_settings()!
               IDDLE_EMULATION_RESULT = JSON.parse(_result())
               IDDLE_CURSOR_POSITION_X = IDDLE_EMULATION_RESULT["CursorX"]
               IDDLE_CURSOR_POSITION_Y = IDDLE_EMULATION_RESULT["CursorY"]
               IDDLE_CURSOR_POSITION_WIDTH = IDDLE_EMULATION_RESULT["Width"]
               IDDLE_CURSOR_POSITION_HEIGHT = IDDLE_EMULATION_RESULT["Height"]
               IDDLE_CURSOR_POSITION_WAS_SCROLL = false
               _do(function(){
               if(Date.now() >= IDDLE_EMULATION_END)
               _break()
               IDDLE_EMULATION_CURRENT_ITEM = IDDLE_EMULATION_DISTRIBUTION[Math.floor(Math.random()*IDDLE_EMULATION_DISTRIBUTION.length)]
               if(_iterator() == 1 && IDDLE_EMULATION_DISTRIBUTION.indexOf(2)>=0)
               IDDLE_EMULATION_CURRENT_ITEM = 2
               _if(IDDLE_EMULATION_CURRENT_ITEM == 1, function(){
               //scroll
               IDDLE_EMULATION_CURRENT_DIRECTION = (rand(1,2) == 2) ? "<MOUSESCROLLUP>" : "<MOUSESCROLLDOWN>"
               if(!IDDLE_CURSOR_POSITION_WAS_SCROLL)
               IDDLE_EMULATION_CURRENT_DIRECTION = "<MOUSESCROLLDOWN>"
               IDDLE_CURSOR_POSITION_WAS_SCROLL = true
               IDDLE_EMULATION_CURRENT_NUMBER = rand(1,5)
               _do(function(){
               if(_iterator() >= IDDLE_EMULATION_CURRENT_NUMBER)
               _break()
               _type(IDDLE_EMULATION_CURRENT_DIRECTION,1000)!
               sleep(rand(300,1000))!
               })!
               })!
               _if(IDDLE_EMULATION_CURRENT_ITEM == 2, function(){
               //long move
               page().script("document.documentElement.scrollLeft")!
               IDDLE_CURSOR_POSITION_SCROLL_X = parseInt(_result())
               page().script("document.documentElement.scrollTop")!
               IDDLE_CURSOR_POSITION_SCROLL_Y = parseInt(_result())
               IDDLE_CURSOR_POSITION_X = rand(1,IDDLE_CURSOR_POSITION_WIDTH)
               IDDLE_CURSOR_POSITION_Y = rand(1,IDDLE_CURSOR_POSITION_HEIGHT)
               move(IDDLE_CURSOR_POSITION_SCROLL_X + IDDLE_CURSOR_POSITION_X,IDDLE_CURSOR_POSITION_SCROLL_Y + IDDLE_CURSOR_POSITION_Y)!
               })!
               _if(IDDLE_EMULATION_CURRENT_ITEM == 3, function(){
               //short move
               if(IDDLE_CURSOR_POSITION_X < 0 || IDDLE_CURSOR_POSITION_Y < 0)
               _break()
               page().script("document.documentElement.scrollLeft")!
               IDDLE_CURSOR_POSITION_SCROLL_X = parseInt(_result())
               page().script("document.documentElement.scrollTop")!
               IDDLE_CURSOR_POSITION_SCROLL_Y = parseInt(_result())
               IDDLE_EMULATION_CURRENT_NUMBER = rand(1,4)
               _do(function(){
               if(_iterator() >= IDDLE_EMULATION_CURRENT_NUMBER)
               _break()
               IDDLE_CURSOR_POSITION_X += rand(-50,50)
               IDDLE_CURSOR_POSITION_Y += rand(-50,50)
               if(IDDLE_CURSOR_POSITION_X > IDDLE_CURSOR_POSITION_WIDTH)
               IDDLE_CURSOR_POSITION_X = IDDLE_CURSOR_POSITION_WIDTH
               if(IDDLE_CURSOR_POSITION_Y > IDDLE_CURSOR_POSITION_HEIGHT)
               IDDLE_CURSOR_POSITION_Y = IDDLE_CURSOR_POSITION_HEIGHT
               if(IDDLE_CURSOR_POSITION_X < 0)
               IDDLE_CURSOR_POSITION_X = 0
               if(IDDLE_CURSOR_POSITION_Y < 0)
               IDDLE_CURSOR_POSITION_Y = 0
               move(IDDLE_CURSOR_POSITION_SCROLL_X + IDDLE_CURSOR_POSITION_X,IDDLE_CURSOR_POSITION_SCROLL_Y + IDDLE_CURSOR_POSITION_Y)!
               _if(rand(1,10) > 3,function(){
               sleep(rand(10,300))!
               })!
               })!
               })!
               _if(IDDLE_EMULATION_CURRENT_ITEM == 4, function(){
               //sleep
               sleep(rand(500,5000))!
               })!
               })!
               

            })!
            

            
            
            _if(!_cycle_params().if_else,function(){
            
               
               
               sleep(1000)!
               

            })!
            delete _cycle_params().if_else;
            

            
            
            _set_if_expression("W1tWV0VSU0lPTjJdXSA9PSAw");
            _if(VAR_VWERSION2 == 0,function(){
            
               
               
               /*Browser*/
               _cache_get_all("*static.geetest.com/nerualpic/original_icon_pic/*")!
               VAR_CACHE_LIST = JSON.parse(_result())
               

               
               
               VAR_LIST_LENGTH = (VAR_CACHE_LIST).length
               

               
               
               _set_if_expression("W1tMSVNUX0xFTkdUSF1dIDwgMw==");
               _if(VAR_LIST_LENGTH < 3,function(){
               
                  
                  
                  VAR_FIND_FOTO = 0
                  

                  
                  
                  _break("function")
                  

               })!
               

            })!
            

            
            
            VAR_MAIN_FOTO = VAR_CACHE_LIST[0]["body"]
            

            
            
            VAR_FIND_FOTO = 1
            

            
            
            _break("function")
            

         })!
         

         
         
         _cycle_params().if_else = VAR_FIND_FOTO == 0;
         _set_if_expression("W1tGSU5EX0ZPVE9dXSA9PSAw");
         _if(_cycle_params().if_else,function(){
         
            
            
            _do(function(){
            _set_action_info({ name: "While" });
            VAR_CYCLE_INDEX = _iterator() - 1
            BREAK_CONDITION = true;
            if(!BREAK_CONDITION)_break();
            
               
               
               _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gNSAmJiBbW1RSWV9TT0xWRV1dID4gMA==");
               _if(VAR_CYCLE_INDEX > 5 && VAR_TRY_SOLVE > 0,function(){
               
                  
                  
                  /*Browser*/
                  cache_data_clear()!
                  

                  
                  
                  _function_return("GoodSolver")
                  

               })!
               

               
               
               _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gMTU=");
               _if(VAR_CYCLE_INDEX > 15,function(){
               
                  
                  
                  fail((_K==="en" ? "Couldn't wait for the captcha button" : "Не дождался кнопку с капчей"));
                  

               })!
               

               
               
               /*Browser*/
               ;_SELECTOR=VAR_BUTTON_CAPTHCA;
               get_element_selector(_SELECTOR, false).nowait().exist()!
               VAR_IS_EXISTS = _result() == 1
               _if(VAR_IS_EXISTS, function(){
               get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
               VAR_IS_EXISTS = _result().indexOf("true")>=0
               })!
               

               
               
               _set_if_expression("W1tJU19FWElTVFNdXQ==");
               _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
               
                  
                  
                  /*Browser*/
                  ;_SELECTOR=VAR_RELOAD_CAPTCHA + "\u003eAT\u003e" + VAR_CAPTCHA_ID;
                  get_element_selector(_SELECTOR, false).nowait().exist()!
                  VAR_IS_EXISTS = _result() == 1
                  _if(VAR_IS_EXISTS, function(){
                  get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
                  VAR_IS_EXISTS = _result().indexOf("true")>=0
                  })!
                  

                  
                  
                  _set_if_expression("W1tJU19FWElTVFNdXQ==");
                  _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
                  
                     
                     
                     /*Browser*/
                     _SELECTOR = VAR_RELOAD_CAPTCHA + "\u003eAT\u003e" + VAR_CAPTCHA_ID;
                     wait_element_visible(_SELECTOR)!
                     _call(_random_point, {})!
                     _if(_result().length > 0, function(){
                     move( {} )!
                     get_element_selector(_SELECTOR, false).clarify(X,Y)!
                     _call(_clarify, {} )!
                     mouse(X,Y)!
                     })!
                     

                     
                     
                     _break("function")
                     

                  })!
                  

                  
                  
                  /*Browser*/
                  _SELECTOR = VAR_BUTTON_CAPTHCA + "\u003eAT\u003e" + VAR_CAPTCHA_ID;
                  wait_element_visible(_SELECTOR)!
                  _call(_random_point, {})!
                  _if(_result().length > 0, function(){
                  move( {} )!
                  get_element_selector(_SELECTOR, false).clarify(X,Y)!
                  _call(_clarify, {} )!
                  mouse(X,Y)!
                  })!
                  

                  
                  
                  _break("function")
                  

               })!
               

               
               
               /*Browser*/
               ;_SELECTOR=VAR_RELOAD_CAPTCHA + "\u003eAT\u003e" + VAR_CAPTCHA_ID;
               get_element_selector(_SELECTOR, false).nowait().exist()!
               VAR_IS_EXISTS = _result() == 1
               _if(VAR_IS_EXISTS, function(){
               get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
               VAR_IS_EXISTS = _result().indexOf("true")>=0
               })!
               

               
               
               _set_if_expression("W1tJU19FWElTVFNdXQ==");
               _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
               
                  
                  
                  /*Browser*/
                  _SELECTOR = VAR_RELOAD_CAPTCHA + "\u003eAT\u003e" + VAR_CAPTCHA_ID;
                  wait_element_visible(_SELECTOR)!
                  _call(_random_point, {})!
                  _if(_result().length > 0, function(){
                  move( {} )!
                  get_element_selector(_SELECTOR, false).clarify(X,Y)!
                  _call(_clarify, {} )!
                  mouse(X,Y)!
                  })!
                  

                  
                  
                  _break("function")
                  

               })!
               

            })!
            

         })!
         

         
         
         _if(!_cycle_params().if_else,function(){
         
            
            
            _do(function(){
            _set_action_info({ name: "While" });
            VAR_CYCLE_INDEX = _iterator() - 1
            BREAK_CONDITION = true;
            if(!BREAK_CONDITION)_break();
            
               
               
               _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gNSAmJiBbW1RSWV9TT0xWRV1dID4gMA==");
               _if(VAR_CYCLE_INDEX > 5 && VAR_TRY_SOLVE > 0,function(){
               
                  
                  
                  /*Browser*/
                  cache_data_clear()!
                  

                  
                  
                  _function_return("GoodSolver")
                  

               })!
               

               
               
               _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gMzA=");
               _if(VAR_CYCLE_INDEX > 30,function(){
               
                  
                  
                  fail((_K==="en" ? "Couldn't wait for the captcha button" : "Не дождался кнопку с капчей"));
                  

               })!
               

               
               
               /*Browser*/
               ;_SELECTOR=VAR_BUTTON_CAPTHCA;
               get_element_selector(_SELECTOR, false).nowait().exist()!
               VAR_IS_EXISTS = _result() == 1
               _if(VAR_IS_EXISTS, function(){
               get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
               VAR_IS_EXISTS = _result().indexOf("true")>=0
               })!
               

               
               
               _set_if_expression("W1tJU19FWElTVFNdXQ==");
               _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
               
                  
                  
                  /*Browser*/
                  ;_SELECTOR=VAR_RELOAD_CAPTCHA + "\u003eAT\u003e" + VAR_CAPTCHA_ID;
                  get_element_selector(_SELECTOR, false).nowait().exist()!
                  VAR_IS_EXISTS = _result() == 1
                  _if(VAR_IS_EXISTS, function(){
                  get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
                  VAR_IS_EXISTS = _result().indexOf("true")>=0
                  })!
                  

                  
                  
                  _set_if_expression("W1tJU19FWElTVFNdXQ==");
                  _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
                  
                     
                     
                     _break("function")
                     

                  })!
                  

                  
                  
                  _set_if_expression("W1tUUllfU09MVkVdXSA9PSAw");
                  _if(VAR_TRY_SOLVE == 0,function(){
                  
                     
                     
                     /*Browser*/
                     _SELECTOR = VAR_BUTTON_CAPTHCA;
                     wait_element_visible(_SELECTOR)!
                     _call(_random_point, {})!
                     _if(_result().length > 0, function(){
                     move( {} )!
                     get_element_selector(_SELECTOR, false).clarify(X,Y)!
                     _call(_clarify, {} )!
                     mouse(X,Y)!
                     })!
                     

                     
                     
                     _break("function")
                     

                  })!
                  

               })!
               

               
               
               /*Browser*/
               ;_SELECTOR=VAR_RELOAD_CAPTCHA + "\u003eAT\u003e" + VAR_CAPTCHA_ID;
               get_element_selector(_SELECTOR, false).nowait().exist()!
               VAR_IS_EXISTS = _result() == 1
               _if(VAR_IS_EXISTS, function(){
               get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
               VAR_IS_EXISTS = _result().indexOf("true")>=0
               })!
               

               
               
               _set_if_expression("W1tJU19FWElTVFNdXQ==");
               _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
               
                  
                  
                  _break("function")
                  

               })!
               

            })!
            

         })!
         delete _cycle_params().if_else;
         

         
         
         VAR_ERROR_FIND_TASK_IMAGES = 0
         

         
         
         _do(function(){
         _set_action_info({ name: "While" });
         VAR_CYCLE_INDEX = _iterator() - 1
         BREAK_CONDITION = true;
         if(!BREAK_CONDITION)_break();
         
            
            
            _set_if_expression("W1tDWUNMRV9JTkRFWF1dID09IDEw");
            _if(VAR_CYCLE_INDEX == 10,function(){
            
               
               
               /*Browser*/
               _SELECTOR = VAR_RELOAD_CAPTCHA + "\u003eAT\u003e" + VAR_CAPTCHA_ID;
               wait_element_visible(_SELECTOR)!
               _call(_random_point, {})!
               _if(_result().length > 0, function(){
               move( {} )!
               get_element_selector(_SELECTOR, false).clarify(X,Y)!
               _call(_clarify, {} )!
               mouse(X,Y)!
               })!
               

            })!
            

            
            
            _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gMTU=");
            _if(VAR_CYCLE_INDEX > 15,function(){
            
               
               
               fail((_K==="en" ? "Didn't wait for the photo" : "Не дождался фото"));
               

            })!
            

            
            
            VAR_RANDOM_NUMBER = Math.floor(Math.random() * (parseInt(100) - parseInt(0) + 1)) + parseInt(0)
            

            
            
            _cycle_params().if_else = VAR_RANDOM_NUMBER > 95;
            _set_if_expression("W1tSQU5ET01fTlVNQkVSXV0gPiA5NQ==");
            _if(_cycle_params().if_else,function(){
            
               
               
               /*Browser*/
               IDDLE_EMULATION_END = Date.now() + 1000 * (1)
               IDDLE_EMULATION_DISTRIBUTION = [2,3,3,3,4,4]
               _get_browser_screen_settings()!
               IDDLE_EMULATION_RESULT = JSON.parse(_result())
               IDDLE_CURSOR_POSITION_X = IDDLE_EMULATION_RESULT["CursorX"]
               IDDLE_CURSOR_POSITION_Y = IDDLE_EMULATION_RESULT["CursorY"]
               IDDLE_CURSOR_POSITION_WIDTH = IDDLE_EMULATION_RESULT["Width"]
               IDDLE_CURSOR_POSITION_HEIGHT = IDDLE_EMULATION_RESULT["Height"]
               IDDLE_CURSOR_POSITION_WAS_SCROLL = false
               _do(function(){
               if(Date.now() >= IDDLE_EMULATION_END)
               _break()
               IDDLE_EMULATION_CURRENT_ITEM = IDDLE_EMULATION_DISTRIBUTION[Math.floor(Math.random()*IDDLE_EMULATION_DISTRIBUTION.length)]
               if(_iterator() == 1 && IDDLE_EMULATION_DISTRIBUTION.indexOf(2)>=0)
               IDDLE_EMULATION_CURRENT_ITEM = 2
               _if(IDDLE_EMULATION_CURRENT_ITEM == 1, function(){
               //scroll
               IDDLE_EMULATION_CURRENT_DIRECTION = (rand(1,2) == 2) ? "<MOUSESCROLLUP>" : "<MOUSESCROLLDOWN>"
               if(!IDDLE_CURSOR_POSITION_WAS_SCROLL)
               IDDLE_EMULATION_CURRENT_DIRECTION = "<MOUSESCROLLDOWN>"
               IDDLE_CURSOR_POSITION_WAS_SCROLL = true
               IDDLE_EMULATION_CURRENT_NUMBER = rand(1,5)
               _do(function(){
               if(_iterator() >= IDDLE_EMULATION_CURRENT_NUMBER)
               _break()
               _type(IDDLE_EMULATION_CURRENT_DIRECTION,1000)!
               sleep(rand(300,1000))!
               })!
               })!
               _if(IDDLE_EMULATION_CURRENT_ITEM == 2, function(){
               //long move
               page().script("document.documentElement.scrollLeft")!
               IDDLE_CURSOR_POSITION_SCROLL_X = parseInt(_result())
               page().script("document.documentElement.scrollTop")!
               IDDLE_CURSOR_POSITION_SCROLL_Y = parseInt(_result())
               IDDLE_CURSOR_POSITION_X = rand(1,IDDLE_CURSOR_POSITION_WIDTH)
               IDDLE_CURSOR_POSITION_Y = rand(1,IDDLE_CURSOR_POSITION_HEIGHT)
               move(IDDLE_CURSOR_POSITION_SCROLL_X + IDDLE_CURSOR_POSITION_X,IDDLE_CURSOR_POSITION_SCROLL_Y + IDDLE_CURSOR_POSITION_Y)!
               })!
               _if(IDDLE_EMULATION_CURRENT_ITEM == 3, function(){
               //short move
               if(IDDLE_CURSOR_POSITION_X < 0 || IDDLE_CURSOR_POSITION_Y < 0)
               _break()
               page().script("document.documentElement.scrollLeft")!
               IDDLE_CURSOR_POSITION_SCROLL_X = parseInt(_result())
               page().script("document.documentElement.scrollTop")!
               IDDLE_CURSOR_POSITION_SCROLL_Y = parseInt(_result())
               IDDLE_EMULATION_CURRENT_NUMBER = rand(1,4)
               _do(function(){
               if(_iterator() >= IDDLE_EMULATION_CURRENT_NUMBER)
               _break()
               IDDLE_CURSOR_POSITION_X += rand(-50,50)
               IDDLE_CURSOR_POSITION_Y += rand(-50,50)
               if(IDDLE_CURSOR_POSITION_X > IDDLE_CURSOR_POSITION_WIDTH)
               IDDLE_CURSOR_POSITION_X = IDDLE_CURSOR_POSITION_WIDTH
               if(IDDLE_CURSOR_POSITION_Y > IDDLE_CURSOR_POSITION_HEIGHT)
               IDDLE_CURSOR_POSITION_Y = IDDLE_CURSOR_POSITION_HEIGHT
               if(IDDLE_CURSOR_POSITION_X < 0)
               IDDLE_CURSOR_POSITION_X = 0
               if(IDDLE_CURSOR_POSITION_Y < 0)
               IDDLE_CURSOR_POSITION_Y = 0
               move(IDDLE_CURSOR_POSITION_SCROLL_X + IDDLE_CURSOR_POSITION_X,IDDLE_CURSOR_POSITION_SCROLL_Y + IDDLE_CURSOR_POSITION_Y)!
               _if(rand(1,10) > 3,function(){
               sleep(rand(10,300))!
               })!
               })!
               })!
               _if(IDDLE_EMULATION_CURRENT_ITEM == 4, function(){
               //sleep
               sleep(rand(500,5000))!
               })!
               })!
               

            })!
            

            
            
            _if(!_cycle_params().if_else,function(){
            
               
               
               sleep(1000)!
               

            })!
            delete _cycle_params().if_else;
            

            
            
            VAR_VWERSION2 = 0
            

            
            
            /*Browser*/
            _cache_get_all("*static.geetest.com/captcha_v4/*")!
            VAR_CACHE_LIST = JSON.parse(_result())
            

            
            
            VAR_LIST_LENGTH = (VAR_CACHE_LIST).length
            

            
            
            _set_if_expression("W1tMSVNUX0xFTkdUSF1dID09IDA=");
            _if(VAR_LIST_LENGTH == 0,function(){
            
               
               
               /*Browser*/
               _cache_get_all("*static.geetest.com/captcha_v3/*")!
               VAR_CACHE_LIST = JSON.parse(_result())
               

               
               
               VAR_LIST_LENGTH = (VAR_CACHE_LIST).length
               

               
               
               _set_if_expression("W1tMSVNUX0xFTkdUSF1dICE9IDA=");
               _if(VAR_LIST_LENGTH != 0,function(){
               
                  
                  
                  VAR_VWERSION2 = 1
                  

               })!
               

            })!
            

            
            
            VAR_LIST_LENGTH = (VAR_CACHE_LIST).length
            

            
            
            _set_if_expression("W1tMSVNUX0xFTkdUSF1dID09IDA=");
            _if(VAR_LIST_LENGTH == 0,function(){
            
               
               
               _next("function")
               

            })!
            

            
            
            VAR_MAIN_FOTO = VAR_CACHE_LIST[0]["body"]
            

            
            
            _set_if_expression("W1tNQUlOX0ZPVE9dXSA9PSAiIg==");
            _if(VAR_MAIN_FOTO == "",function(){
            
               
               
               _next("function")
               

            })!
            

            
            
            VAR_RANDOM_NUMBER = Math.floor(Math.random() * (parseInt(100) - parseInt(0) + 1)) + parseInt(0)
            

            
            
            _cycle_params().if_else = VAR_RANDOM_NUMBER > 95;
            _set_if_expression("W1tSQU5ET01fTlVNQkVSXV0gPiA5NQ==");
            _if(_cycle_params().if_else,function(){
            
               
               
               /*Browser*/
               IDDLE_EMULATION_END = Date.now() + 1000 * (1)
               IDDLE_EMULATION_DISTRIBUTION = [2,3,3,3,4,4]
               _get_browser_screen_settings()!
               IDDLE_EMULATION_RESULT = JSON.parse(_result())
               IDDLE_CURSOR_POSITION_X = IDDLE_EMULATION_RESULT["CursorX"]
               IDDLE_CURSOR_POSITION_Y = IDDLE_EMULATION_RESULT["CursorY"]
               IDDLE_CURSOR_POSITION_WIDTH = IDDLE_EMULATION_RESULT["Width"]
               IDDLE_CURSOR_POSITION_HEIGHT = IDDLE_EMULATION_RESULT["Height"]
               IDDLE_CURSOR_POSITION_WAS_SCROLL = false
               _do(function(){
               if(Date.now() >= IDDLE_EMULATION_END)
               _break()
               IDDLE_EMULATION_CURRENT_ITEM = IDDLE_EMULATION_DISTRIBUTION[Math.floor(Math.random()*IDDLE_EMULATION_DISTRIBUTION.length)]
               if(_iterator() == 1 && IDDLE_EMULATION_DISTRIBUTION.indexOf(2)>=0)
               IDDLE_EMULATION_CURRENT_ITEM = 2
               _if(IDDLE_EMULATION_CURRENT_ITEM == 1, function(){
               //scroll
               IDDLE_EMULATION_CURRENT_DIRECTION = (rand(1,2) == 2) ? "<MOUSESCROLLUP>" : "<MOUSESCROLLDOWN>"
               if(!IDDLE_CURSOR_POSITION_WAS_SCROLL)
               IDDLE_EMULATION_CURRENT_DIRECTION = "<MOUSESCROLLDOWN>"
               IDDLE_CURSOR_POSITION_WAS_SCROLL = true
               IDDLE_EMULATION_CURRENT_NUMBER = rand(1,5)
               _do(function(){
               if(_iterator() >= IDDLE_EMULATION_CURRENT_NUMBER)
               _break()
               _type(IDDLE_EMULATION_CURRENT_DIRECTION,1000)!
               sleep(rand(300,1000))!
               })!
               })!
               _if(IDDLE_EMULATION_CURRENT_ITEM == 2, function(){
               //long move
               page().script("document.documentElement.scrollLeft")!
               IDDLE_CURSOR_POSITION_SCROLL_X = parseInt(_result())
               page().script("document.documentElement.scrollTop")!
               IDDLE_CURSOR_POSITION_SCROLL_Y = parseInt(_result())
               IDDLE_CURSOR_POSITION_X = rand(1,IDDLE_CURSOR_POSITION_WIDTH)
               IDDLE_CURSOR_POSITION_Y = rand(1,IDDLE_CURSOR_POSITION_HEIGHT)
               move(IDDLE_CURSOR_POSITION_SCROLL_X + IDDLE_CURSOR_POSITION_X,IDDLE_CURSOR_POSITION_SCROLL_Y + IDDLE_CURSOR_POSITION_Y)!
               })!
               _if(IDDLE_EMULATION_CURRENT_ITEM == 3, function(){
               //short move
               if(IDDLE_CURSOR_POSITION_X < 0 || IDDLE_CURSOR_POSITION_Y < 0)
               _break()
               page().script("document.documentElement.scrollLeft")!
               IDDLE_CURSOR_POSITION_SCROLL_X = parseInt(_result())
               page().script("document.documentElement.scrollTop")!
               IDDLE_CURSOR_POSITION_SCROLL_Y = parseInt(_result())
               IDDLE_EMULATION_CURRENT_NUMBER = rand(1,4)
               _do(function(){
               if(_iterator() >= IDDLE_EMULATION_CURRENT_NUMBER)
               _break()
               IDDLE_CURSOR_POSITION_X += rand(-50,50)
               IDDLE_CURSOR_POSITION_Y += rand(-50,50)
               if(IDDLE_CURSOR_POSITION_X > IDDLE_CURSOR_POSITION_WIDTH)
               IDDLE_CURSOR_POSITION_X = IDDLE_CURSOR_POSITION_WIDTH
               if(IDDLE_CURSOR_POSITION_Y > IDDLE_CURSOR_POSITION_HEIGHT)
               IDDLE_CURSOR_POSITION_Y = IDDLE_CURSOR_POSITION_HEIGHT
               if(IDDLE_CURSOR_POSITION_X < 0)
               IDDLE_CURSOR_POSITION_X = 0
               if(IDDLE_CURSOR_POSITION_Y < 0)
               IDDLE_CURSOR_POSITION_Y = 0
               move(IDDLE_CURSOR_POSITION_SCROLL_X + IDDLE_CURSOR_POSITION_X,IDDLE_CURSOR_POSITION_SCROLL_Y + IDDLE_CURSOR_POSITION_Y)!
               _if(rand(1,10) > 3,function(){
               sleep(rand(10,300))!
               })!
               })!
               })!
               _if(IDDLE_EMULATION_CURRENT_ITEM == 4, function(){
               //sleep
               sleep(rand(500,5000))!
               })!
               })!
               

            })!
            

            
            
            _if(!_cycle_params().if_else,function(){
            
               
               
               sleep(1000)!
               

            })!
            delete _cycle_params().if_else;
            

            
            
            _set_if_expression("W1tWV0VSU0lPTjJdXSA9PSAw");
            _if(VAR_VWERSION2 == 0,function(){
            
               
               
               /*Browser*/
               _cache_get_all("*static.geetest.com/nerualpic/original_icon_pic/*")!
               VAR_CACHE_LIST = JSON.parse(_result())
               

               
               
               VAR_LIST_LENGTH = (VAR_CACHE_LIST).length
               

               
               
               _set_if_expression("W1tMSVNUX0xFTkdUSF1dIDwgMw==");
               _if(VAR_LIST_LENGTH < 3,function(){
               
                  
                  
                  VAR_ERROR_FIND_TASK_IMAGES = parseInt(VAR_ERROR_FIND_TASK_IMAGES) + parseInt(1)
                  

                  
                  
                  _break("function")
                  

               })!
               

               
               
               VAR_ALL_FOTO = [
               VAR_CACHE_LIST[0]["body"],
               VAR_CACHE_LIST[1]["body"],
               VAR_CACHE_LIST[2]["body"]
               ]
               

            })!
            

            
            
            _break("function")
            

         })!
         

         
         
         _set_if_expression("W1tFUlJPUl9GSU5EX1RBU0tfSU1BR0VTXV0gPT0gMQ==");
         _if(VAR_ERROR_FIND_TASK_IMAGES == 1,function(){
         
            
            
            VAR_TRY_SOLVE = parseInt(VAR_TRY_SOLVE) + parseInt(1)
            

            
            
            _next("function")
            

         })!
         

         
         
         /*Browser*/
         _SELECTOR = VAR_FOTO_CAPTCHA + "\u003eAT\u003e" + VAR_CAPTCHA_ID;
         wait_element(_SELECTOR)!
         get_element_selector(_SELECTOR, false).script("(function(){var rect = self.getBoundingClientRect();return (rect.left + positionx).toString() + '|' + (rect.top + positiony).toString() + '|' + (rect.right - rect.left).toString() + '|' + (rect.bottom - rect.top).toString()})();")!
         if(_result().length > 0)
         {
         var split = _result().split("|")
         VAR_X = parseInt(split[0])
         VAR_Y = parseInt(split[1])
         VAR_WIDTH = parseInt(split[2])
         VAR_HEIGHT = parseInt(split[3])
         }
         

         
         
         /*Browser*/
         cache_data_clear()!
         

         
         
         _cycle_params().if_else = VAR_VWERSION2 == 1;
         _set_if_expression("W1tWV0VSU0lPTjJdXSA9PSAx");
         _if(_cycle_params().if_else,function(){
         
            
            
            _switch_http_client_main()
            general_timeout_next(15000)
            http_client_post(VAR_URL_ADRESS_SOLVER + "/in.php", ["key",VAR_APIKEY, "method","geetest_icon","main_photo",VAR_MAIN_FOTO], {"content-type":("multipart"), "encoding":("UTF-8"), "method":("POST"),headers:("")})!
            

         })!
         

         
         
         _if(!_cycle_params().if_else,function(){
         
            
            
            _switch_http_client_main()
            general_timeout_next(15000)
            http_client_post(VAR_URL_ADRESS_SOLVER + "/in.php", ["key",VAR_APIKEY, "method","geetest_icon","main_photo",VAR_MAIN_FOTO,"task_1",VAR_ALL_FOTO[0],"task_2",VAR_ALL_FOTO[1],"task_3",VAR_ALL_FOTO[2]], {"content-type":("multipart"), "encoding":("UTF-8"), "method":("POST"),headers:("")})!
            

         })!
         delete _cycle_params().if_else;
         

         
         
         _switch_http_client_main()
         VAR_SAVED_CONTENT = http_client_encoded_content("utf-8")
         

         
         
         VAR_STRING_CONTAINS = Boolean(native("regexp", "ismatch", JSON.stringify({text: VAR_SAVED_CONTENT,regexp:"(ERROR)"})) == "true")
         

         
         
         _set_if_expression("W1tTVFJJTkdfQ09OVEFJTlNdXQ==");
         _if(typeof(VAR_STRING_CONTAINS) !== "undefined" ? (VAR_STRING_CONTAINS) : undefined,function(){
         
            
            
            /*Browser*/
            ;_SELECTOR=VAR_RELOAD_CAPTCHA + "\u003eAT\u003e" + VAR_CAPTCHA_ID;
            get_element_selector(_SELECTOR, false).nowait().exist()!
            VAR_IS_EXISTS = _result() == 1
            _if(VAR_IS_EXISTS, function(){
            get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
            VAR_IS_EXISTS = _result().indexOf("true")>=0
            })!
            

            
            
            _cycle_params().if_else = typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined;
            _set_if_expression("W1tJU19FWElTVFNdXQ==");
            _if(_cycle_params().if_else,function(){
            
               
               
               /*Browser*/
               cache_data_clear()!
               

               
               
               /*Browser*/
               _SELECTOR = VAR_RELOAD_CAPTCHA + "\u003eAT\u003e" + VAR_CAPTCHA_ID;
               wait_element_visible(_SELECTOR)!
               _call(_random_point, {})!
               _if(_result().length > 0, function(){
               move( {} )!
               get_element_selector(_SELECTOR, false).clarify(X,Y)!
               _call(_clarify, {} )!
               mouse(X,Y)!
               })!
               

            })!
            

            
            
            _if(!_cycle_params().if_else,function(){
            
               
               
               fail((_K==="en" ? "Fail solve captcha" : "Ошибка при решении капчи"));
               

            })!
            delete _cycle_params().if_else;
            

            
            
            VAR_TRY_SOLVE = parseInt(VAR_TRY_SOLVE) + parseInt(1)
            

            
            
            _next("function")
            

         })!
         

         
         
         VAR_ID = VAR_SAVED_CONTENT.split("|")[1]
         

         
         
         _do(function(){
         _set_action_info({ name: "While" });
         VAR_CYCLE_INDEX = _iterator() - 1
         BREAK_CONDITION = true;
         if(!BREAK_CONDITION)_break();
         
            
            
            _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gNjA=");
            _if(VAR_CYCLE_INDEX > 60,function(){
            
               
               
               fail((_K==="en" ? "The service failed to recognize the captcha in 30 seconds" : "Сервис не распознал капчу за 30 секунд"));
               

            })!
            

            
            
            VAR_RANDOM_NUMBER = Math.floor(Math.random() * (parseInt(100) - parseInt(0) + 1)) + parseInt(0)
            

            
            
            _cycle_params().if_else = VAR_RANDOM_NUMBER > 95;
            _set_if_expression("W1tSQU5ET01fTlVNQkVSXV0gPiA5NQ==");
            _if(_cycle_params().if_else,function(){
            
               
               
               /*Browser*/
               IDDLE_EMULATION_END = Date.now() + 1000 * (1)
               IDDLE_EMULATION_DISTRIBUTION = [2,3,3,3,4,4]
               _get_browser_screen_settings()!
               IDDLE_EMULATION_RESULT = JSON.parse(_result())
               IDDLE_CURSOR_POSITION_X = IDDLE_EMULATION_RESULT["CursorX"]
               IDDLE_CURSOR_POSITION_Y = IDDLE_EMULATION_RESULT["CursorY"]
               IDDLE_CURSOR_POSITION_WIDTH = IDDLE_EMULATION_RESULT["Width"]
               IDDLE_CURSOR_POSITION_HEIGHT = IDDLE_EMULATION_RESULT["Height"]
               IDDLE_CURSOR_POSITION_WAS_SCROLL = false
               _do(function(){
               if(Date.now() >= IDDLE_EMULATION_END)
               _break()
               IDDLE_EMULATION_CURRENT_ITEM = IDDLE_EMULATION_DISTRIBUTION[Math.floor(Math.random()*IDDLE_EMULATION_DISTRIBUTION.length)]
               if(_iterator() == 1 && IDDLE_EMULATION_DISTRIBUTION.indexOf(2)>=0)
               IDDLE_EMULATION_CURRENT_ITEM = 2
               _if(IDDLE_EMULATION_CURRENT_ITEM == 1, function(){
               //scroll
               IDDLE_EMULATION_CURRENT_DIRECTION = (rand(1,2) == 2) ? "<MOUSESCROLLUP>" : "<MOUSESCROLLDOWN>"
               if(!IDDLE_CURSOR_POSITION_WAS_SCROLL)
               IDDLE_EMULATION_CURRENT_DIRECTION = "<MOUSESCROLLDOWN>"
               IDDLE_CURSOR_POSITION_WAS_SCROLL = true
               IDDLE_EMULATION_CURRENT_NUMBER = rand(1,5)
               _do(function(){
               if(_iterator() >= IDDLE_EMULATION_CURRENT_NUMBER)
               _break()
               _type(IDDLE_EMULATION_CURRENT_DIRECTION,1000)!
               sleep(rand(300,1000))!
               })!
               })!
               _if(IDDLE_EMULATION_CURRENT_ITEM == 2, function(){
               //long move
               page().script("document.documentElement.scrollLeft")!
               IDDLE_CURSOR_POSITION_SCROLL_X = parseInt(_result())
               page().script("document.documentElement.scrollTop")!
               IDDLE_CURSOR_POSITION_SCROLL_Y = parseInt(_result())
               IDDLE_CURSOR_POSITION_X = rand(1,IDDLE_CURSOR_POSITION_WIDTH)
               IDDLE_CURSOR_POSITION_Y = rand(1,IDDLE_CURSOR_POSITION_HEIGHT)
               move(IDDLE_CURSOR_POSITION_SCROLL_X + IDDLE_CURSOR_POSITION_X,IDDLE_CURSOR_POSITION_SCROLL_Y + IDDLE_CURSOR_POSITION_Y)!
               })!
               _if(IDDLE_EMULATION_CURRENT_ITEM == 3, function(){
               //short move
               if(IDDLE_CURSOR_POSITION_X < 0 || IDDLE_CURSOR_POSITION_Y < 0)
               _break()
               page().script("document.documentElement.scrollLeft")!
               IDDLE_CURSOR_POSITION_SCROLL_X = parseInt(_result())
               page().script("document.documentElement.scrollTop")!
               IDDLE_CURSOR_POSITION_SCROLL_Y = parseInt(_result())
               IDDLE_EMULATION_CURRENT_NUMBER = rand(1,4)
               _do(function(){
               if(_iterator() >= IDDLE_EMULATION_CURRENT_NUMBER)
               _break()
               IDDLE_CURSOR_POSITION_X += rand(-50,50)
               IDDLE_CURSOR_POSITION_Y += rand(-50,50)
               if(IDDLE_CURSOR_POSITION_X > IDDLE_CURSOR_POSITION_WIDTH)
               IDDLE_CURSOR_POSITION_X = IDDLE_CURSOR_POSITION_WIDTH
               if(IDDLE_CURSOR_POSITION_Y > IDDLE_CURSOR_POSITION_HEIGHT)
               IDDLE_CURSOR_POSITION_Y = IDDLE_CURSOR_POSITION_HEIGHT
               if(IDDLE_CURSOR_POSITION_X < 0)
               IDDLE_CURSOR_POSITION_X = 0
               if(IDDLE_CURSOR_POSITION_Y < 0)
               IDDLE_CURSOR_POSITION_Y = 0
               move(IDDLE_CURSOR_POSITION_SCROLL_X + IDDLE_CURSOR_POSITION_X,IDDLE_CURSOR_POSITION_SCROLL_Y + IDDLE_CURSOR_POSITION_Y)!
               _if(rand(1,10) > 3,function(){
               sleep(rand(10,300))!
               })!
               })!
               })!
               _if(IDDLE_EMULATION_CURRENT_ITEM == 4, function(){
               //sleep
               sleep(rand(500,5000))!
               })!
               })!
               

            })!
            

            
            
            _if(!_cycle_params().if_else,function(){
            
               
               
               sleep(1000)!
               

            })!
            delete _cycle_params().if_else;
            

            
            
            _switch_http_client_main()
            http_client_get2(VAR_URL_ADRESS_SOLVER + "/res.php?key=" + VAR_APIKEY + "\u0026id=" + VAR_ID,{method:("GET"),headers:("")})!
            

            
            
            _switch_http_client_main()
            VAR_SAVED_CONTENT = http_client_encoded_content("utf-8")
            

            
            
            _set_if_expression("W1tTQVZFRF9DT05URU5UXV0gIT0gIkNBUENIQV9OT1RfUkVBRFki");
            _if(VAR_SAVED_CONTENT != "CAPCHA_NOT_READY",function(){
            
               
               
               _break("function")
               

            })!
            

         })!
         

         
         
         VAR_STRING_CONTAINS = Boolean(native("regexp", "ismatch", JSON.stringify({text: VAR_SAVED_CONTENT,regexp:"(ERROR)"})) == "true")
         

         
         
         _set_if_expression("W1tTVFJJTkdfQ09OVEFJTlNdXQ==");
         _if(typeof(VAR_STRING_CONTAINS) !== "undefined" ? (VAR_STRING_CONTAINS) : undefined,function(){
         
            
            
            /*Browser*/
            ;_SELECTOR=VAR_RELOAD_CAPTCHA + "\u003eAT\u003e" + VAR_CAPTCHA_ID;
            get_element_selector(_SELECTOR, false).nowait().exist()!
            VAR_IS_EXISTS = _result() == 1
            _if(VAR_IS_EXISTS, function(){
            get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
            VAR_IS_EXISTS = _result().indexOf("true")>=0
            })!
            

            
            
            _cycle_params().if_else = typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined;
            _set_if_expression("W1tJU19FWElTVFNdXQ==");
            _if(_cycle_params().if_else,function(){
            
               
               
               /*Browser*/
               _SELECTOR = VAR_RELOAD_CAPTCHA + "\u003eAT\u003e" + VAR_CAPTCHA_ID;
               wait_element_visible(_SELECTOR)!
               _call(_random_point, {})!
               _if(_result().length > 0, function(){
               move( {} )!
               get_element_selector(_SELECTOR, false).clarify(X,Y)!
               _call(_clarify, {} )!
               mouse(X,Y)!
               })!
               

            })!
            

            
            
            _if(!_cycle_params().if_else,function(){
            
               
               
               fail((_K==="en" ? "Fail solve captcha" : "Ошибка при решении капчи"));
               

            })!
            delete _cycle_params().if_else;
            

            
            
            VAR_TRY_SOLVE = parseInt(VAR_TRY_SOLVE) + parseInt(1)
            

            
            
            _next("function")
            

         })!
         

         
         
         VAR_DATA = VAR_SAVED_CONTENT.split("|")[1].split(":")[1].replace(/x/g, "").replace(/=/g, "").replace(/y/g, "").replace(/y/g, "")
         VAR_LIST_COORDINATES = [
         [parseInt(VAR_DATA.split(";")[0].split(",")[0]), parseInt(VAR_DATA.split(";")[0].split(",")[1])],
         [parseInt(VAR_DATA.split(";")[1].split(",")[0]), parseInt(VAR_DATA.split(";")[1].split(",")[1])],
         [parseInt(VAR_DATA.split(";")[2].split(",")[0]), parseInt(VAR_DATA.split(";")[2].split(",")[1])]
         ]
         

         
         
         /*Browser*/
         scroll(1,1)!
         

         
         
         _do_with_params({"foreach_data":(VAR_LIST_COORDINATES)},function(){
         _set_action_info({ name: "Foreach" });
         VAR_CYCLE_INDEX = _iterator() - 1
         if(VAR_CYCLE_INDEX > _cycle_param("foreach_data").length - 1)_break();
         VAR_FOREACH_DATA = _cycle_param("foreach_data")[VAR_CYCLE_INDEX]
         
            
            
            sleep(200)!
            

            
            
            /*Browser*/
            move(VAR_X + VAR_FOREACH_DATA[0],VAR_Y + VAR_FOREACH_DATA[1],  {} )!
            mouse(VAR_X + VAR_FOREACH_DATA[0],VAR_Y + VAR_FOREACH_DATA[1])!
            

         })!
         

         
         
         /*Browser*/
         _SELECTOR = VAR_CAPTCHA_SUBMIT + "\u003eAT\u003e" + VAR_CAPTCHA_ID;
         wait_element_visible(_SELECTOR)!
         _call(_random_point, {})!
         _if(_result().length > 0, function(){
         move( {} )!
         get_element_selector(_SELECTOR, false).clarify(X,Y)!
         _call(_clarify, {} )!
         mouse(X,Y)!
         })!
         

         
         
         VAR_TRY_SOLVE = parseInt(VAR_TRY_SOLVE) + parseInt(1)
         

      })!
      

   }
   

function GoodXevilPaySolver_GXP_AllowCacheForGeetestIcon()
   {
   
      
      
      /*Browser*/
      cache_allow("*static.geetest.com/captcha_v4/*")!
      

      
      
      /*Browser*/
      cache_allow("*static.geetest.com/nerualpic/original_icon_pic/*")!
      

      
      
      /*Browser*/
      cache_allow("*static.geetest.com/captcha_v3/*")!
      

   }
   

function GoodXevilPaySolver_GXP_Antibot()
   {
   
      
      
      VAR_APIKEY = _function_argument("apikey")
      

      
      
      VAR_MOUSE = _function_argument("mouse")
      

      
      
      var regexp_result = native("regexp", "first", JSON.stringify({text: VAR_APIKEY,regexp:"([0-9A-Za-z]\u007b20,40\u007d)"}))
      if(regexp_result.length == 0)
      regexp_result = []
      else
      regexp_result = JSON.parse(regexp_result)
      VAR_ALL_MATCH = regexp_result.pop()
      if(typeof(VAR_ALL_MATCH) == 'undefined' || !VAR_ALL_MATCH)
      VAR_ALL_MATCH = ""
      VAR_APIKEY = regexp_result[0]
      if(typeof(VAR_APIKEY) == 'undefined' || !VAR_APIKEY)
      VAR_APIKEY = ""
      if(regexp_result.length == 0)
      {
      VAR_APIKEY = VAR_ALL_MATCH
      }
      

      
      
      _do(function(){
      _set_action_info({ name: "While" });
      VAR_CYCLE_INDEX = _iterator() - 1
      BREAK_CONDITION = true;
      if(!BREAK_CONDITION)_break();
      
         
         
         _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gMTU=");
         _if(VAR_CYCLE_INDEX > 15,function(){
         
            
            
            fail((_K==="en" ? "Didn't wait for antibot captcha" : "Не дождался antibot капчи"));
            

         })!
         

         
         
         /*Browser*/
         page().script("document.documentElement.outerHTML")!
         VAR_SAVED_PAGE_HTML = _result()
         

         
         
         html_parser_xpath_parse(VAR_SAVED_PAGE_HTML)
         VAR_XPATH_XML_LIST = html_parser_xpath_xml_list("//img[contains(@src, \u0027data:image/png;base64\u0027)]/..")
         

         
         
         VAR_XPATH_XML_LIST = (function(){var seen = {}; return (VAR_XPATH_XML_LIST).filter(function(item) { return seen.hasOwnProperty(item) ? false : (seen[item] = true); });})();
         

         
         
         _set_if_expression("W1tYUEFUSF9YTUxfTElTVF1dLmxlbmd0aCA+IDM=");
         _if(VAR_XPATH_XML_LIST.length > 3,function(){
         
            
            
            _break("function")
            

         })!
         

         
         
         sleep(1000)!
         

      })!
      

      
      
      VAR_NORM_SOLVER = 2
      

      
      
      VAR_DATA_WORLD_IMG = {}
      

      
      
      VAR_MAIN_FOTO = ""
      

      
      
      VAR_MAIN_ID = 0
      

      
      
      VAR_REL_ID = 0
      

      
      
      VAR_REL_LIST = []
      

      
      
      _do_with_params({"foreach_data":(VAR_XPATH_XML_LIST)},function(){
      _set_action_info({ name: "Foreach" });
      VAR_CYCLE_INDEX = _iterator() - 1
      if(VAR_CYCLE_INDEX > _cycle_param("foreach_data").length - 1)_break();
      VAR_FOREACH_DATA = _cycle_param("foreach_data")[VAR_CYCLE_INDEX]
      
         
         
         _set_if_expression("W1tNQUlOX0lEXV0gPT0gMA==");
         _if(VAR_MAIN_ID == 0,function(){
         
            
            
            html_parser_xpath_parse(VAR_FOREACH_DATA)
            VAR_XPATH_EXISTS = html_parser_xpath_exist("//*[@id=\u0027antibotlinks_reset\u0027 and not(@rel)]")
            

            
            
            html_parser_xpath_parse(VAR_FOREACH_DATA)
            VAR_XPATH_EXISTS2 = html_parser_xpath_exist("//*[contains(@xmlns, \u0022www.w3.org\u0022) and not(@rel)]")
            

            
            
            _set_if_expression("W1tYUEFUSF9FWElTVFNdXSB8fCBbW1hQQVRIX0VYSVNUUzJdXQ==");
            _if(VAR_XPATH_EXISTS || VAR_XPATH_EXISTS2,function(){
            
               
               
               html_parser_xpath_parse(VAR_FOREACH_DATA)
               if((true) && !html_parser_xpath_exist("//@src"))
               fail("Can't resolve query " + "//@src");
               VAR_XPATH_XML = html_parser_xpath_xml("//@src")
               

               
               
               VAR_MAIN_FOTO = VAR_XPATH_XML.split("base64,")[1]
               

               
               
               VAR_MAIN_ID = 1
               

               
               
               _next("function")
               

            })!
            

         })!
         

         
         
         html_parser_xpath_parse(VAR_FOREACH_DATA)
         VAR_XPATH_EXISTS = html_parser_xpath_exist("//@rel")
         

         
         
         _cycle_params().if_else = VAR_XPATH_EXISTS && VAR_NORM_SOLVER != 0;
         _set_if_expression("W1tYUEFUSF9FWElTVFNdXSAmJiBbW05PUk1fU09MVkVSXV0gIT0gMA==");
         _if(_cycle_params().if_else,function(){
         
            
            
            VAR_NORM_SOLVER = 1
            

            
            
            html_parser_xpath_parse(VAR_FOREACH_DATA)
            if((true) && !html_parser_xpath_exist("//@src"))
            fail("Can't resolve query " + "//@src");
            VAR_XPATH_XML = html_parser_xpath_xml("//@src")
            

            
            
            html_parser_xpath_parse(VAR_FOREACH_DATA)
            if((true) && !html_parser_xpath_exist("//@rel"))
            fail("Can't resolve query " + "//@rel");
            VAR_XPATH_XML_REL = html_parser_xpath_xml("//@rel")
            

            
            
            VAR_REL_FOTO = VAR_XPATH_XML.split("base64,")[1]
            

            
            
            VAR_REL_LIST.push(VAR_XPATH_XML_REL + ";" + VAR_REL_FOTO)
            

            
            
            VAR_REL_ID = parseInt(VAR_REL_ID) + parseInt(1)
            

         })!
         

         
         
         _if(!_cycle_params().if_else,function(){
         
            
            
            html_parser_xpath_parse(VAR_FOREACH_DATA)
            VAR_XPATH_EXISTS = html_parser_xpath_exist("//*[@class=\u0022atblink\u0022]")
            

            
            
            _set_if_expression("W1tYUEFUSF9FWElTVFNdXSAmJiBbW05PUk1fU09MVkVSXV0gIT0gMQ==");
            _if(VAR_XPATH_EXISTS && VAR_NORM_SOLVER != 1,function(){
            
               
               
               VAR_NORM_SOLVER = 0
               

               
               
               html_parser_xpath_parse(VAR_FOREACH_DATA)
               if((true) && !html_parser_xpath_exist("//@src"))
               fail("Can't resolve query " + "//@src");
               VAR_XPATH_XML = html_parser_xpath_xml("//@src")
               

               
               
               VAR_REL_FOTO = VAR_XPATH_XML.split("base64,")[1]
               

               
               
               VAR_XPATH_XML_REL = VAR_REL_FOTO.length
               

               
               
               VAR_DATA_WORLD_IMG[VAR_XPATH_XML_REL] = VAR_XPATH_XML
               

               
               
               VAR_REL_LIST.push(VAR_XPATH_XML_REL + ";" + VAR_REL_FOTO)
               

               
               
               VAR_REL_ID = parseInt(VAR_REL_ID) + parseInt(1)
               

            })!
            

         })!
         delete _cycle_params().if_else;
         

      })!
      

      
      
      _set_if_expression("W1tNQUlOX0lEXV0gPT0gMA==");
      _if(VAR_MAIN_ID == 0,function(){
      
         
         
         fail((_K==="en" ? "Main captcha image not found" : "Не найдено основное изображение капчи"));
         

      })!
      

      
      
      _set_if_expression("W1tSRUxfSURdXSA8IDMgfHwgW1tSRUxfSURdXSA+IDQ=");
      _if(VAR_REL_ID < 3 || VAR_REL_ID > 4,function(){
      
         
         
         fail((_K==="en" ? "Found (" + VAR_REL_ID + ") antibot images with rel value" : "Найдено (" + VAR_REL_ID + ") изображений antibot с значением rel"));
         

      })!
      

      
      
      solver_properties_clear("capmonster")
      solver_property("capmonster","serverurl","http://goodxevilpay.pp.ua")
      solver_property("capmonster","key",VAR_APIKEY)
      solver_property("capmonster","method","antibot")
      solver_property("capmonster","main",VAR_MAIN_FOTO)
      VAR_REL_LIST.forEach(function(item) {
      VAR_REL_ID = item.split(";")[0]
      VAR_BASE64 = item.split(";")[1]
      solver_property("capmonster",VAR_REL_ID,VAR_BASE64)
      });
      solve_base64_no_fail("capmonster", "")!
      VAR_SAVED_CONTENT = _result();
      

      
      
      VAR_STRING_MATCHES = Boolean(native("regexp", "ismatch", JSON.stringify({text: VAR_SAVED_CONTENT,regexp:"(_)"})) == "true")
      

      
      
      _set_if_expression("W1tTVFJJTkdfTUFUQ0hFU11d");
      _if(typeof(VAR_STRING_MATCHES) !== "undefined" ? (VAR_STRING_MATCHES) : undefined,function(){
      
         
         
         fail((_K==="en" ? "Error when solving captcha" : "Ошибка при решении капчи"));
         

      })!
      

      
      
      VAR_SCAN_RESULT_LIST = native("regexp", "scan", JSON.stringify({text: VAR_SAVED_CONTENT,regexp:"\u005cd+"}))
      if(VAR_SCAN_RESULT_LIST.length == 0)
      VAR_SCAN_RESULT_LIST = []
      else
      VAR_SCAN_RESULT_LIST = JSON.parse(VAR_SCAN_RESULT_LIST)
      

      
      
      _set_if_expression("W1tTQ0FOX1JFU1VMVF9MSVNUXV0ubGVuZ3RoICE9IFtbUkVMX0xJU1RdXS5sZW5ndGg=");
      _if(VAR_SCAN_RESULT_LIST.length != VAR_REL_LIST.length,function(){
      
         
         
         fail((_K==="en" ? "The captcha solved by the service is not correct" : "Капча решена сервисом не верно"));
         

      })!
      

      
      
      _do_with_params({"foreach_data":(VAR_SCAN_RESULT_LIST)},function(){
      _set_action_info({ name: "Foreach" });
      VAR_CYCLE_INDEX = _iterator() - 1
      if(VAR_CYCLE_INDEX > _cycle_param("foreach_data").length - 1)_break();
      VAR_FOREACH_DATA = _cycle_param("foreach_data")[VAR_CYCLE_INDEX]
      
         
         
         _cycle_params().if_else = VAR_NORM_SOLVER == 1;
         _set_if_expression("W1tOT1JNX1NPTFZFUl1dID09IDE=");
         _if(_cycle_params().if_else,function(){
         
            
            
            _cycle_params().if_else = VAR_MOUSE == "true";
            _set_if_expression("W1tNT1VTRV1dID09ICJ0cnVlIg==");
            _if(_cycle_params().if_else,function(){
            
               
               
               /*Browser*/
               _SELECTOR = " \u003eXPATH\u003e //*[@rel=" + VAR_FOREACH_DATA + "]";
               wait_element_visible(_SELECTOR)!
               _call(_random_point, {})!
               _if(_result().length > 0, function(){
               move( {} )!
               get_element_selector(_SELECTOR, false).clarify(X,Y)!
               _call(_clarify, {} )!
               mouse(X,Y)!
               })!
               

            })!
            

            
            
            _if(!_cycle_params().if_else,function(){
            
               
               
               /*Browser*/
               _SELECTOR = " \u003eXPATH\u003e //*[@rel=" + VAR_FOREACH_DATA + "]";
               wait_element_visible(_SELECTOR)!
               _call(_random_point, {})!
               _if(_result().length > 0, function(){
               X = parseInt(_result().split(",")[0])
               Y = parseInt(_result().split(",")[1])
               mouse(X,Y)!
               })!
               

            })!
            delete _cycle_params().if_else;
            

         })!
         

         
         
         _if(!_cycle_params().if_else,function(){
         
            
            
            VAR_TEMP_SRC = VAR_DATA_WORLD_IMG[VAR_FOREACH_DATA]
            

            
            
            _cycle_params().if_else = VAR_MOUSE == "true";
            _set_if_expression("W1tNT1VTRV1dID09ICJ0cnVlIg==");
            _if(_cycle_params().if_else,function(){
            
               
               
               /*Browser*/
               _SELECTOR = " \u003eXPATH\u003e //img[contains(@src, \u0022" + VAR_TEMP_SRC + "\u0022)]";
               wait_element_visible(_SELECTOR)!
               _call(_random_point, {})!
               _if(_result().length > 0, function(){
               move( {} )!
               get_element_selector(_SELECTOR, false).clarify(X,Y)!
               _call(_clarify, {} )!
               mouse(X,Y)!
               })!
               

            })!
            

            
            
            _if(!_cycle_params().if_else,function(){
            
               
               
               /*Browser*/
               _SELECTOR = " \u003eXPATH\u003e //img[contains(@src, \u0022" + VAR_TEMP_SRC + "\u0022)]";
               wait_element_visible(_SELECTOR)!
               _call(_random_point, {})!
               _if(_result().length > 0, function(){
               X = parseInt(_result().split(",")[0])
               Y = parseInt(_result().split(",")[1])
               mouse(X,Y)!
               })!
               

            })!
            delete _cycle_params().if_else;
            

         })!
         delete _cycle_params().if_else;
         

      })!
      

   }
   

function GoodXevilPaySolver_GXP_ReCaptchaAutoSolver()
   {
   
      
      
      VAR_APIKEY = _function_argument("apikey")
      

      
      
      VAR_SERVER_URL = "http://127.0.0.1:10000"
      

      
      
      VAR_SERVER_URL = "http://goodxevilpay.pp.ua"
      

      
      
      var regexp_result = native("regexp", "first", JSON.stringify({text: VAR_APIKEY,regexp:"([0-9A-Za-z]\u007b20,40\u007d)"}))
      if(regexp_result.length == 0)
      regexp_result = []
      else
      regexp_result = JSON.parse(regexp_result)
      VAR_ALL_MATCH = regexp_result.pop()
      if(typeof(VAR_ALL_MATCH) == 'undefined' || !VAR_ALL_MATCH)
      VAR_ALL_MATCH = ""
      VAR_APIKEY = regexp_result[0]
      if(typeof(VAR_APIKEY) == 'undefined' || !VAR_APIKEY)
      VAR_APIKEY = ""
      if(regexp_result.length == 0)
      {
      VAR_APIKEY = VAR_ALL_MATCH
      }
      

      
      
      VAR_TEMP_DATA2 = ""
      

      
      
      VAR_TEMP_DATA = ""
      

      
      
      _do(function(){
      _set_action_info({ name: "While" });
      VAR_CYCLE_INDEX = _iterator() - 1
      BREAK_CONDITION = VAR_TEMP_DATA == "";
      if(!BREAK_CONDITION)_break();
      
         
         
         _set_if_expression("W1tDWUNMRV9JTkRFWF1dICE9IDA=");
         _if(VAR_CYCLE_INDEX != 0,function(){
         
            
            
            sleep(500)!
            

         })!
         

         
         
         _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gMzA=");
         _if(VAR_CYCLE_INDEX > 30,function(){
         
            
            
            fail((_K==="en" ? "ReCaptcha is not detected on the page" : "ReCaptcha не обнаружена на странице"));
            

         })!
         

         
         
         _call(function()
         {
         _on_fail(function(){
         VAR_LAST_ERROR = _result()
         VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
         VAR_WAS_ERROR = false
         _break(1,true)
         })
         CYCLES.Current().RemoveLabel("function")
         
            
            
            page().script2("[[TEMP_DATA]] = window.widgetInfore;",JSON.stringify(_read_variables(["VAR_TEMP_DATA"])))!
            var _parse_result = JSON.parse(_result())
            _write_variables(JSON.parse(_parse_result.variables))
            if(!_parse_result.is_success)
            fail(_parse_result.error)
            

         },null)!
         

      })!
      

      
      
      /*Browser*/
      url()!
      VAR_SITE_URL = _result()
      

      
      
      VAR_SAVED_CONTENT = "ERROR"
      

      
      
      _do(function(){
      _set_action_info({ name: "For" });
      VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(0)
      if(VAR_CYCLE_INDEX > parseInt(3))_break();
      
         
         
         _set_if_expression("W1tDWUNMRV9JTkRFWF1dID49IDI=");
         _if(VAR_CYCLE_INDEX >= 2,function(){
         
            
            
            fail((_K==="en" ? "Error solving captcha" : "Ошибка при решении капчи"));
            

         })!
         

         
         
         _call(function()
         {
         _on_fail(function(){
         VAR_LAST_ERROR = _result()
         VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
         VAR_WAS_ERROR = false
         _break(1,true)
         })
         CYCLES.Current().RemoveLabel("function")
         
            
            
            solver_properties_clear("capmonster")
            solver_property("capmonster","serverurl",VAR_SERVER_URL)
            solver_property("capmonster","key",VAR_APIKEY)
            solver_property("capmonster","method","userrecaptcha")
            solver_property("capmonster","pageurl",VAR_SITE_URL)
            solver_property("capmonster","googlekey",VAR_TEMP_DATA["sitekey"])
            solve_base64_no_fail("capmonster", "")!
            VAR_SAVED_CONTENT = _result();
            

         },null)!
         

         
         
         VAR_STRING_MATCHES = Boolean(native("regexp", "ismatch", JSON.stringify({text: VAR_SAVED_CONTENT,regexp:"(ERROR)"})) == "true")
         

         
         
         VAR_STRING_MATCHES2 = Boolean(native("regexp", "ismatch", JSON.stringify({text: VAR_SAVED_CONTENT,regexp:"(_FAIL)"})) == "true")
         

         
         
         _set_if_expression("W1tTVFJJTkdfTUFUQ0hFU11dIHx8IFtbU1RSSU5HX01BVENIRVMyXV0=");
         _if(VAR_STRING_MATCHES || VAR_STRING_MATCHES2,function(){
         
            
            
            sleep(1000)!
            

            
            
            _next("function")
            

         })!
         

         
         
         _break("function")
         

      })!
      

      
      
      _call(function()
      {
      _on_fail(function(){
      VAR_LAST_ERROR = _result()
      VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
      VAR_WAS_ERROR = false
      _break(1,true)
      })
      CYCLES.Current().RemoveLabel("function")
      
         
         
         /*Browser*/
         _SELECTOR = " \u003eCSS\u003eiframe[src*=\u0027anchor\u0027]\u003eFRAME\u003e \u003eXPATH\u003e //input[@id=\u0022recaptcha-token\u0022]";
         wait_element(_SELECTOR)!
         get_element_selector(_SELECTOR, false).set_attr("value", VAR_SAVED_CONTENT)!
         

      },null)!
      

      
      
      _call(function()
      {
      _on_fail(function(){
      VAR_LAST_ERROR = _result()
      VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
      VAR_WAS_ERROR = false
      _break(1,true)
      })
      CYCLES.Current().RemoveLabel("function")
      
         
         
         page().script2("var xpath = '//textarea[@name=\"g-recaptcha-response\"]';\r\nvar result = document.evaluate(xpath, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null);\r\nvar element = result.singleNodeValue;\r\n\r\nif (element) {\r\n  element.innerText = [[SAVED_CONTENT]];\r\n}\r\n",JSON.stringify(_read_variables(["VAR_SAVED_CONTENT"])))!
         var _parse_result = JSON.parse(_result())
         _write_variables(JSON.parse(_parse_result.variables))
         if(!_parse_result.is_success)
         fail(_parse_result.error)
         

      },null)!
      

      
      
      _call(function()
      {
      _on_fail(function(){
      VAR_LAST_ERROR = _result()
      VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
      VAR_WAS_ERROR = false
      _break(1,true)
      })
      CYCLES.Current().RemoveLabel("function")
      
         
         
         page().script2("if(window.widgetInfore.callback != null){\r\n    let func = window.widgetInfore.callback\r\n    let data = [[SAVED_CONTENT]];\r\n    window[func](data);\r\n}\r\n",JSON.stringify(_read_variables(["VAR_SAVED_CONTENT"])))!
         var _parse_result = JSON.parse(_result())
         _write_variables(JSON.parse(_parse_result.variables))
         if(!_parse_result.is_success)
         fail(_parse_result.error)
         

      },null)!
      

      
      
      _call(function()
      {
      _on_fail(function(){
      VAR_LAST_ERROR = _result()
      VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
      VAR_WAS_ERROR = false
      _break(1,true)
      })
      CYCLES.Current().RemoveLabel("function")
      
         
         
         page().script2("function getBindedElements(widget) {\r\n    let elements = {\r\n        button: null,\r\n        textarea: null,\r\n    };\r\n    if (widget.bindedButtonId) {\r\n        let button = document.querySelector(\"#\" + widget.bindedButtonId);\r\n        if (button.length) elements.button = button;\r\n    } else {\r\n        let textarea = document.querySelector(\"#\" + widget.containerId + \" textarea[name=g-recaptcha-response]\");\r\n        if (textarea.length) elements.textarea = textarea;\r\n    }\r\n    return elements;\r\n}  \r\n\r\nfunction getForm(widget) {\r\n    let binded = getBindedElements(widget);\r\n    if (binded.textarea) {\r\n        return binded.textarea.closest(\"form\");\r\n    }\r\n    return binded.button.closest(\"form\");\r\n}\r\n\r\nlet textarea = getBindedElements(window.widgetInfore).textarea;\r\nif (!textarea) {\r\n    textarea = getForm(window.widgetInfore).find(\"textarea[name=g-recaptcha-response]\");\r\n}\r\ntextarea.val([[SAVED_CONTENT]]);\r\n\r\nif(window.widgetInfore.callback != null){\r\n    let func = window.widgetInfore.callback\r\n    let data = [[SAVED_CONTENT]];\r\n    window[func](data);\r\n}",JSON.stringify(_read_variables(["VAR_SAVED_CONTENT"])))!
         var _parse_result = JSON.parse(_result())
         _write_variables(JSON.parse(_parse_result.variables))
         if(!_parse_result.is_success)
         fail(_parse_result.error)
         

      },null)!
      

      
      
      _call(function()
      {
      _on_fail(function(){
      VAR_LAST_ERROR = _result()
      VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
      VAR_WAS_ERROR = false
      _break(1,true)
      })
      CYCLES.Current().RemoveLabel("function")
      
         
         
         page().script2("function setRecaptchaToken(token, clientIdx = 0) {\r\n  var recap = window[\"___grecaptcha_cfg\"].clients[clientIdx];\r\n  Object.keys(recap).forEach(function(k) {\r\n      if (recap[k] != null && recap[k][k] != null && recap[k][k][\"callback\"] != null)  {\r\n           recap[k][k].callback(token);\r\n           console.log('recap token sumbited')\r\n           return;\r\n      } \r\n  });  \r\n}\r\n\r\nsetRecaptchaToken([[SAVED_CONTENT]])",JSON.stringify(_read_variables(["VAR_SAVED_CONTENT"])))!
         var _parse_result = JSON.parse(_result())
         _write_variables(JSON.parse(_parse_result.variables))
         if(!_parse_result.is_success)
         fail(_parse_result.error)
         

      },null)!
      

      
      
      _set_if_expression("ZmFsc2U=");
      _if(false,function(){
      
         
         
         page().script2("function findRecaptchaClients() {\r\n  // eslint-disable-next-line camelcase\r\n  if (typeof (___grecaptcha_cfg) !== 'undefined') {\r\n    // eslint-disable-next-line camelcase, no-undef\r\n    return Object.entries(___grecaptcha_cfg.clients).map(([cid, client]) => {\r\n      const data = { id: cid, version: cid >= 10000 ? 'V3' : 'V2' };\r\n      const objects = Object.entries(client).filter(([_, value]) => value && typeof value === 'object');\r\n\r\n      objects.forEach(([toplevelKey, toplevel]) => {\r\n        const found = Object.entries(toplevel).find(([_, value]) => (\r\n          value && typeof value === 'object' && 'sitekey' in value && 'size' in value\r\n        ));\r\n     \r\n        if (typeof toplevel === 'object' && toplevel instanceof HTMLElement && toplevel['tagName'] === 'DIV'){\r\n            data.pageurl = toplevel.baseURI;\r\n        }\r\n        \r\n        if (found) {\r\n          const [sublevelKey, sublevel] = found;\r\n\r\n          data.sitekey = sublevel.sitekey;\r\n          const callbackKey = data.version === 'V2' ? 'callback' : 'promise-callback';\r\n          const callback = sublevel[callbackKey];\r\n          if (!callback) {\r\n            data.callback = null;\r\n            data.function = null;\r\n          } else {\r\n            data.function = callback;\r\n            const keys = [cid, toplevelKey, sublevelKey, callbackKey].map((key) => `['${key}']`).join('');\r\n            data.callback = `___grecaptcha_cfg.clients${keys}`;\r\n          }\r\n        }\r\n      });\r\n      return data;\r\n    });\r\n  }\r\n  return [];\r\n}\r\n\r\nlet res = findRecaptchaClients()\r\n[[TEMP_DATA]] = res",JSON.stringify(_read_variables(["VAR_TEMP_DATA"])))!
         var _parse_result = JSON.parse(_result())
         _write_variables(JSON.parse(_parse_result.variables))
         if(!_parse_result.is_success)
         fail(_parse_result.error)
         

      })!
      

   }
   

function GoodXevilPaySolver_GXP_AutoBypassCloudFlare()
   {
   
      
      
      _do(function(){
      _set_action_info({ name: "While" });
      VAR_CYCLE_INDEX = _iterator() - 1
      BREAK_CONDITION = true;
      if(!BREAK_CONDITION)_break();
      
         
         
         _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gNQ==");
         _if(VAR_CYCLE_INDEX > 5,function(){
         
            
            
            fail((_K==="en" ? "Cloudflare didn't allow access to the site" : "Cloudflare не пустил на сайт"));
            

         })!
         

         
         
         _call(function()
         {
         _on_fail(function(){
         VAR_LAST_ERROR = _result()
         VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
         VAR_WAS_ERROR = false
         _break(1,true)
         })
         CYCLES.Current().RemoveLabel("function")
         
            
            
            /*Browser*/
            waiter_timeout_next(25000)
            wait_async_load()!
            

         },null)!
         

         
         
         _do(function(){
         _set_action_info({ name: "For" });
         VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
         if(VAR_CYCLE_INDEX > parseInt(250))_break();
         
            
            
            _call(function()
            {
            _on_fail(function(){
            VAR_LAST_ERROR = _result()
            VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
            VAR_WAS_ERROR = false
            _break(1,true)
            })
            CYCLES.Current().RemoveLabel("function")
            
               
               
               /*Browser*/
               ;_SELECTOR=" \u003eCSS\u003e .font-red";
               get_element_selector(_SELECTOR, false).nowait().exist()!
               VAR_IS_EXISTS = _result() == 1
               _if(VAR_IS_EXISTS, function(){
               get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
               VAR_IS_EXISTS = _result().indexOf("true")>=0
               })!
               

               
               
               _set_if_expression("W1tJU19FWElTVFNdXQ==");
               _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
               
                  
                  
                  page().script2("location.reload()",JSON.stringify(_read_variables([])))!
                  var _parse_result = JSON.parse(_result())
                  _write_variables(JSON.parse(_parse_result.variables))
                  if(!_parse_result.is_success)
                  fail(_parse_result.error)
                  

                  
                  
                  _call(function()
                  {
                  _on_fail(function(){
                  VAR_LAST_ERROR = _result()
                  VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
                  VAR_WAS_ERROR = false
                  _break(1,true)
                  })
                  CYCLES.Current().RemoveLabel("function")
                  
                     
                     
                     /*Browser*/
                     waiter_timeout_next(25000)
                     wait_async_load()!
                     

                     
                     
                     sleep(10000)!
                     

                  },null)!
                  

                  
                  
                  _next("function")
                  

               })!
               

            },null)!
            

            
            
            _call(function()
            {
            _on_fail(function(){
            VAR_LAST_ERROR = _result()
            VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
            VAR_WAS_ERROR = false
            _break(1,true)
            })
            CYCLES.Current().RemoveLabel("function")
            
               
               
               /*Browser*/
               ;_SELECTOR="\u003eMATCH\u003e\u003ch1\u003e403 Forbidden\u003c/h1\u003e";
               get_element_selector(_SELECTOR, false).nowait().exist()!
               VAR_IS_EXISTS = _result() == 1
               

               
               
               _set_if_expression("W1tJU19FWElTVFNdXQ==");
               _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
               
                  
                  
                  page().script2("location.reload()",JSON.stringify(_read_variables([])))!
                  var _parse_result = JSON.parse(_result())
                  _write_variables(JSON.parse(_parse_result.variables))
                  if(!_parse_result.is_success)
                  fail(_parse_result.error)
                  

                  
                  
                  _call(function()
                  {
                  _on_fail(function(){
                  VAR_LAST_ERROR = _result()
                  VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
                  VAR_WAS_ERROR = false
                  _break(1,true)
                  })
                  CYCLES.Current().RemoveLabel("function")
                  
                     
                     
                     /*Browser*/
                     waiter_timeout_next(25000)
                     wait_async_load()!
                     

                     
                     
                     sleep(10000)!
                     

                  },null)!
                  

                  
                  
                  _next("function")
                  

               })!
               

            },null)!
            

            
            
            _call(function()
            {
            _on_fail(function(){
            VAR_LAST_ERROR = _result()
            VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
            VAR_WAS_ERROR = false
            _break(1,true)
            })
            CYCLES.Current().RemoveLabel("function")
            
               
               
               /*Browser*/
               ;_SELECTOR=" \u003eCSS\u003e #challenge-body-text";
               get_element_selector(_SELECTOR, false).nowait().exist()!
               VAR_IS_EXISTS = _result() == 1
               _if(VAR_IS_EXISTS, function(){
               get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
               VAR_IS_EXISTS = _result().indexOf("true")>=0
               })!
               

               
               
               _set_if_expression("W1tJU19FWElTVFNdXSAmJiBbW0NZQ0xFX0lOREVYXV0gPT0gMTAw");
               _if(VAR_IS_EXISTS && VAR_CYCLE_INDEX == 100,function(){
               
                  
                  
                  page().script2("location.reload()",JSON.stringify(_read_variables([])))!
                  var _parse_result = JSON.parse(_result())
                  _write_variables(JSON.parse(_parse_result.variables))
                  if(!_parse_result.is_success)
                  fail(_parse_result.error)
                  

                  
                  
                  _call(function()
                  {
                  _on_fail(function(){
                  VAR_LAST_ERROR = _result()
                  VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
                  VAR_WAS_ERROR = false
                  _break(1,true)
                  })
                  CYCLES.Current().RemoveLabel("function")
                  
                     
                     
                     /*Browser*/
                     waiter_timeout_next(25000)
                     wait_async_load()!
                     

                     
                     
                     sleep(10000)!
                     

                  },null)!
                  

                  
                  
                  _next("function")
                  

               })!
               

               
               
               _set_if_expression("W1tJU19FWElTVFNdXSAmJiBbW0NZQ0xFX0lOREVYXV0gPT0gMjAw");
               _if(VAR_IS_EXISTS && VAR_CYCLE_INDEX == 200,function(){
               
                  
                  
                  page().script2("location.reload()",JSON.stringify(_read_variables([])))!
                  var _parse_result = JSON.parse(_result())
                  _write_variables(JSON.parse(_parse_result.variables))
                  if(!_parse_result.is_success)
                  fail(_parse_result.error)
                  

                  
                  
                  _call(function()
                  {
                  _on_fail(function(){
                  VAR_LAST_ERROR = _result()
                  VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
                  VAR_WAS_ERROR = false
                  _break(1,true)
                  })
                  CYCLES.Current().RemoveLabel("function")
                  
                     
                     
                     /*Browser*/
                     waiter_timeout_next(25000)
                     wait_async_load()!
                     

                     
                     
                     sleep(10000)!
                     

                  },null)!
                  

                  
                  
                  _next("function")
                  

               })!
               

            },null)!
            

            
            
            sleep(1000)!
            

            
            
            /*Browser*/
            ;_SELECTOR=" \u003eCSS\u003e #challenge-running";
            get_element_selector(_SELECTOR, false).nowait().exist()!
            VAR_IS_EXISTS = _result() == 1
            _if(VAR_IS_EXISTS, function(){
            get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
            VAR_IS_EXISTS = _result().indexOf("true")>=0
            })!
            

            
            
            _set_if_expression("W1tJU19FWElTVFNdXSA9PSBmYWxzZQ==");
            _if(VAR_IS_EXISTS == false,function(){
            
               
               
               _break("function")
               

            })!
            

            
            
            /*Browser*/
            ;_SELECTOR=" \u003eCSS\u003e iframe\u003eFRAME\u003e \u003eCSS\u003e img";
            get_element_selector(_SELECTOR, false).nowait().exist()!
            VAR_IS_EXISTS = _result() == 1
            _if(VAR_IS_EXISTS, function(){
            get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
            VAR_IS_EXISTS = _result().indexOf("true")>=0
            })!
            

            
            
            _set_if_expression("W1tJU19FWElTVFNdXQ==");
            _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
            
               
               
               /*Browser*/
               _SELECTOR = " \u003eCSS\u003e iframe\u003eFRAME\u003e \u003eCSS\u003e img";
               wait_element_visible(_SELECTOR)!
               _call(_random_point, {})!
               _if(_result().length > 0, function(){
               move( {} )!
               get_element_selector(_SELECTOR, false).clarify(X,Y)!
               _call(_clarify, {} )!
               mouse(X,Y)!
               })!
               

               
               
               _call(function()
               {
               _on_fail(function(){
               VAR_LAST_ERROR = _result()
               VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
               VAR_WAS_ERROR = false
               _break(1,true)
               })
               CYCLES.Current().RemoveLabel("function")
               
                  
                  
                  /*Browser*/
                  waiter_timeout_next(20000)
                  wait_async_load()!
                  

               },null)!
               

            })!
            

            
            
            /*Browser*/
            ;_SELECTOR="\u003eMATCH\u003e\u003ciframe src=\u0022https://challenges.cloudfla\u003eFRAME\u003e\u003eMATCH\u003e\u003cinput type=\u0022checkbox\u0022\u003e";
            get_element_selector(_SELECTOR, false).nowait().exist()!
            VAR_IS_EXISTS = _result() == 1
            _if(VAR_IS_EXISTS, function(){
            get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
            VAR_IS_EXISTS = _result().indexOf("true")>=0
            })!
            

            
            
            _set_if_expression("W1tJU19FWElTVFNdXQ==");
            _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
            
               
               
               /*Browser*/
               _SELECTOR = "\u003eMATCH\u003e\u003ciframe src=\u0022https://challenges.cloudfla\u003eFRAME\u003e\u003eMATCH\u003e\u003cinput type=\u0022checkbox\u0022\u003e";
               waiter_nofail_next();
               wait_element_visible(_SELECTOR)!
               _call(_random_point, {})!
               _if(_result().length > 0, function(){
               move( {} )!
               get_element_selector(_SELECTOR, false).nowait().clarify(X,Y)!
               _call(_clarify, {} )!
               mouse(X,Y)!
               })!
               

               
               
               _call(function()
               {
               _on_fail(function(){
               VAR_LAST_ERROR = _result()
               VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
               VAR_WAS_ERROR = false
               _break(1,true)
               })
               CYCLES.Current().RemoveLabel("function")
               
                  
                  
                  /*Browser*/
                  waiter_timeout_next(20000)
                  wait_async_load()!
                  

               },null)!
               

            })!
            

            
            
            /*Browser*/
            ;_SELECTOR="\u003eMATCH\u003e\u003ch1\u003eAccess denied\u003c/h1\u003e";
            get_element_selector(_SELECTOR, false).nowait().exist()!
            VAR_IS_EXISTS = _result() == 1
            _if(VAR_IS_EXISTS, function(){
            get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
            VAR_IS_EXISTS = _result().indexOf("true")>=0
            })!
            

            
            
            _set_if_expression("W1tJU19FWElTVFNdXQ==");
            _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
            
               
               
               fail((_K==="en" ? "Cloudflare banned the IP" : "Cloudflare забанила ип"));
               

            })!
            

         })!
         

         
         
         _call(function()
         {
         _on_fail(function(){
         VAR_LAST_ERROR = _result()
         VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
         VAR_WAS_ERROR = false
         _break(1,true)
         })
         CYCLES.Current().RemoveLabel("function")
         
            
            
            /*Browser*/
            waiter_timeout_next(15000)
            wait_async_load()!
            

         },null)!
         

         
         
         _break("function")
         

      })!
      

   }
   

function GoodXevilPaySolver_GXP_IconCaptchaFreeSolver()
   {
   
      
      
      /*Browser*/
      ;_SELECTOR=" \u003eCSS\u003e .iconcaptcha-modal";
      get_element_selector(_SELECTOR, false).nowait().exist()!
      VAR_IS_EXISTS = _result() == 1
      _if(VAR_IS_EXISTS, function(){
      get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
      VAR_IS_EXISTS = _result().indexOf("true")>=0
      })!
      

      
      
      /*Browser*/
      ;_SELECTOR=" \u003eCSS\u003e .iconcaptcha-modal__body-icons";
      get_element_selector(_SELECTOR, false).nowait().exist()!
      VAR_IS_EXISTS2 = _result() == 1
      _if(VAR_IS_EXISTS2, function(){
      get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
      VAR_IS_EXISTS2 = _result().indexOf("true")>=0
      })!
      

      
      
      _do(function(){
      _set_action_info({ name: "While" });
      VAR_CYCLE_INDEX = _iterator() - 1
      BREAK_CONDITION = VAR_IS_EXISTS == false && VAR_IS_EXISTS2 == false;
      if(!BREAK_CONDITION)_break();
      
         
         
         _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gMzA=");
         _if(VAR_CYCLE_INDEX > 30,function(){
         
            
            
            fail((_K==="en" ? "Didn't wait for iconcaptcha" : "Не дождался iconcaptcha"));
            

         })!
         

         
         
         sleep(1000)!
         

         
         
         /*Browser*/
         ;_SELECTOR=" \u003eCSS\u003e .iconcaptcha-modal__header";
         get_element_selector(_SELECTOR, false).nowait().exist()!
         VAR_IS_EXISTS2 = _result() == 1
         _if(VAR_IS_EXISTS2, function(){
         get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
         VAR_IS_EXISTS2 = _result().indexOf("true")>=0
         })!
         

         
         
         /*Browser*/
         ;_SELECTOR=" \u003eCSS\u003e .iconcaptcha-modal";
         get_element_selector(_SELECTOR, false).nowait().exist()!
         VAR_IS_EXISTS = _result() == 1
         _if(VAR_IS_EXISTS, function(){
         get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
         VAR_IS_EXISTS = _result().indexOf("true")>=0
         })!
         

      })!
      

      
      
      _set_if_expression("W1tJU19FWElTVFNdXSAmJiBbW0lTX0VYSVNUUzJdXSA9PSBmYWxzZQ==");
      _if(VAR_IS_EXISTS && VAR_IS_EXISTS2 == false,function(){
      
         
         
         /*Browser*/
         _SELECTOR = " \u003eCSS\u003e .iconcaptcha-modal";
         wait_element_visible(_SELECTOR)!
         _call(_random_point, {})!
         _if(_result().length > 0, function(){
         move( {} )!
         get_element_selector(_SELECTOR, false).clarify(X,Y)!
         _call(_clarify, {} )!
         mouse(X,Y)!
         })!
         

      })!
      

      
      
      /*Browser*/
      _SELECTOR = " \u003eCSS\u003e .iconcaptcha-modal__body-icons";
      wait_element(_SELECTOR)!
      get_element_selector(_SELECTOR, false).script("(function(){var rect = self.getBoundingClientRect();return (rect.left + positionx).toString() + '|' + (rect.top + positiony).toString() + '|' + (rect.right - rect.left).toString() + '|' + (rect.bottom - rect.top).toString()})();")!
      if(_result().length > 0)
      {
      var split = _result().split("|")
      VAR_X = parseInt(split[0])
      VAR_Y = parseInt(split[1])
      VAR_WIDTH = parseInt(split[2])
      VAR_HEIGHT = parseInt(split[3])
      }
      

      
      
      /*Browser*/
      move(VAR_X -3,VAR_Y - 20,  {} )!
      

      
      
      /*Browser*/
      _SELECTOR = " \u003eCSS\u003e .iconcaptcha-modal__body-icons";
      wait_element(_SELECTOR)!
      get_element_selector(_SELECTOR, false).exist()!
      _if(_result() == "1", function(){
      get_element_selector(_SELECTOR, false).render_base64()!
      VAR_ICONCAPTCHAMODAL__BODY = _result()
      })!
      

      
      
      /*Browser*/
      _SELECTOR = " \u003eCSS\u003e .iconcaptcha-modal__body-icons";
      wait_element(_SELECTOR)!
      get_element_selector(_SELECTOR, false).script("(function(){var rect = self.getBoundingClientRect();return (rect.left + positionx).toString() + '|' + (rect.top + positiony).toString() + '|' + (rect.right - rect.left).toString() + '|' + (rect.bottom - rect.top).toString()})();")!
      if(_result().length > 0)
      {
      var split = _result().split("|")
      VAR_X_L = parseInt(split[0])
      VAR_Y_L = parseInt(split[1])
      VAR_1 = parseInt(split[2])
      VAR_1 = parseInt(split[3])
      }
      

      
      
      VAR_LOADED_IMAGE_ID = native("imageprocessing", "load", VAR_ICONCAPTCHAMODAL__BODY)
      

      
      
      {
      var split = native("imageprocessing", "getsize", VAR_LOADED_IMAGE_ID).split(",")
      VAR_IMAGE_WIDTH = parseInt(split[0])
      VAR_IMAGE_HEIGHT = parseInt(split[1])
      }
      

      
      
      VAR_POINT_X = VAR_IMAGE_HEIGHT/2
      

      
      
      VAR_POINT_X = VAR_POINT_X.toString()
      

      
      
      var regexp_result = native("regexp", "first", JSON.stringify({text: VAR_POINT_X,regexp:"\u005cd+"}))
      if(regexp_result.length == 0)
      regexp_result = []
      else
      regexp_result = JSON.parse(regexp_result)
      VAR_ALL_MATCH = regexp_result.pop()
      if(typeof(VAR_ALL_MATCH) == 'undefined' || !VAR_ALL_MATCH)
      VAR_ALL_MATCH = ""
      VAR_POINT_X = regexp_result[0]
      if(typeof(VAR_POINT_X) == 'undefined' || !VAR_POINT_X)
      VAR_POINT_X = ""
      if(regexp_result.length == 0)
      {
      VAR_POINT_X = VAR_ALL_MATCH
      }
      

      
      
      VAR_POINT_X = parseInt(VAR_POINT_X);
      

      
      
      VAR_TEMP_LIST = []
      

      
      
      VAR_POINT_X = VAR_POINT_X
      

      
      
      VAR_PIXEL_WHITE_MAX = 0
      

      
      
      VAR_PIXEL_WHITE_NOW = 0
      

      
      
      VAR_PIXEL_WHITE_STOP = 0
      

      
      
      {
      var split = native("imageprocessing", "getpixel", (VAR_LOADED_IMAGE_ID) + "," + (2) + "," + (2)).split(",")
      VAR_PIXEL_R = parseInt(split[0])
      VAR_PIXEL_G = parseInt(split[1])
      VAR_PIXEL_B = parseInt(split[2])
      VAR_PIXEL_A = parseInt(split[3])
      }
      

      
      
      _cycle_params().if_else = VAR_PIXEL_B > 200;
      _set_if_expression("W1tQSVhFTF9CXV0gPiAyMDA=");
      _if(_cycle_params().if_else,function(){
      
         
         
         _do(function(){
         _set_action_info({ name: "For" });
         VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(0)
         if(VAR_CYCLE_INDEX > parseInt(VAR_IMAGE_WIDTH - 1))_break();
         
            
            
            VAR_CYCLE_INDEX_X = VAR_CYCLE_INDEX
            

            
            
            VAR_NO_WHITE_PIXEL = 0
            

            
            
            VAR_NO_WHITE_PIXEL_DATA = 0
            

            
            
            _do(function(){
            _set_action_info({ name: "For" });
            VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(0)
            if(VAR_CYCLE_INDEX > parseInt(VAR_IMAGE_HEIGHT - 1))_break();
            
               
               
               {
               var split = native("imageprocessing", "getpixel", (VAR_LOADED_IMAGE_ID) + "," + (VAR_CYCLE_INDEX_X) + "," + (VAR_CYCLE_INDEX)).split(",")
               VAR_PIXEL_R = parseInt(split[0])
               VAR_PIXEL_G = parseInt(split[1])
               VAR_PIXEL_B = parseInt(split[2])
               VAR_PIXEL_A = parseInt(split[3])
               }
               

               
               
               _cycle_params().if_else = VAR_PIXEL_B <= 240;
               _set_if_expression("W1tQSVhFTF9CXV0gPD0gMjQw");
               _if(_cycle_params().if_else,function(){
               
                  
                  
                  VAR_PIXEL_WHITE_NOW = 1
                  

                  
                  
                  VAR_PIXEL_WHITE_MAX = parseInt(VAR_PIXEL_WHITE_MAX) + parseInt(1)
                  

               })!
               

               
               
               _if(!_cycle_params().if_else,function(){
               
                  
                  
                  VAR_NO_WHITE_PIXEL_DATA = parseInt(VAR_NO_WHITE_PIXEL_DATA) + parseInt(1)
                  

               })!
               delete _cycle_params().if_else;
               

            })!
            

            
            
            _set_if_expression("W1tOT19XSElURV9QSVhFTF9EQVRBXV0gKyA1ID49IFtbSU1BR0VfSEVJR0hUXV0=");
            _if(VAR_NO_WHITE_PIXEL_DATA + 5 >= VAR_IMAGE_HEIGHT,function(){
            
               
               
               VAR_NO_WHITE_PIXEL = parseInt(VAR_NO_WHITE_PIXEL) + parseInt(1)
               

            })!
            

            
            
            _set_if_expression("W1tOT19XSElURV9QSVhFTF1dID09IDE=");
            _if(VAR_NO_WHITE_PIXEL == 1,function(){
            
               
               
               _set_if_expression("W1tQSVhFTF9XSElURV9OT1ddXSA9PSAx");
               _if(VAR_PIXEL_WHITE_NOW == 1,function(){
               
                  
                  
                  VAR_PIXEL_WHITE_STOP = parseInt(VAR_PIXEL_WHITE_STOP) + parseInt(1)
                  

                  
                  
                  _set_if_expression("W1tQSVhFTF9XSElURV9TVE9QXV0gPiA4");
                  _if(VAR_PIXEL_WHITE_STOP > 8,function(){
                  
                     
                     
                     VAR_PIXEL_WHITE_STOP = 0
                     

                     
                     
                     VAR_PIXEL_WHITE_NOW = 0
                     

                     
                     
                     VAR_TEMP_LIST.push(VAR_PIXEL_WHITE_MAX)
                     

                     
                     
                     VAR_PIXEL_WHITE_MAX = 0
                     

                  })!
                  

               })!
               

            })!
            

         })!
         

      })!
      

      
      
      _if(!_cycle_params().if_else,function(){
      
         
         
         _do(function(){
         _set_action_info({ name: "For" });
         VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(0)
         if(VAR_CYCLE_INDEX > parseInt(VAR_IMAGE_WIDTH - 1))_break();
         
            
            
            VAR_CYCLE_INDEX_X = VAR_CYCLE_INDEX
            

            
            
            VAR_NO_WHITE_PIXEL = 0
            

            
            
            VAR_NO_WHITE_PIXEL_DATA = 0
            

            
            
            _do(function(){
            _set_action_info({ name: "For" });
            VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(0)
            if(VAR_CYCLE_INDEX > parseInt(VAR_IMAGE_HEIGHT - 1))_break();
            
               
               
               {
               var split = native("imageprocessing", "getpixel", (VAR_LOADED_IMAGE_ID) + "," + (VAR_CYCLE_INDEX_X) + "," + (VAR_CYCLE_INDEX)).split(",")
               VAR_PIXEL_R = parseInt(split[0])
               VAR_PIXEL_G = parseInt(split[1])
               VAR_PIXEL_B = parseInt(split[2])
               VAR_PIXEL_A = parseInt(split[3])
               }
               

               
               
               _cycle_params().if_else = VAR_PIXEL_B >= 78;
               _set_if_expression("W1tQSVhFTF9CXV0gPj0gNzg=");
               _if(_cycle_params().if_else,function(){
               
                  
                  
                  VAR_PIXEL_WHITE_NOW = 1
                  

                  
                  
                  VAR_PIXEL_WHITE_MAX = parseInt(VAR_PIXEL_WHITE_MAX) + parseInt(1)
                  

               })!
               

               
               
               _if(!_cycle_params().if_else,function(){
               
                  
                  
                  VAR_NO_WHITE_PIXEL_DATA = parseInt(VAR_NO_WHITE_PIXEL_DATA) + parseInt(1)
                  

               })!
               delete _cycle_params().if_else;
               

            })!
            

            
            
            _set_if_expression("W1tOT19XSElURV9QSVhFTF9EQVRBXV0gKyA1ID49IFtbSU1BR0VfSEVJR0hUXV0=");
            _if(VAR_NO_WHITE_PIXEL_DATA + 5 >= VAR_IMAGE_HEIGHT,function(){
            
               
               
               VAR_NO_WHITE_PIXEL = parseInt(VAR_NO_WHITE_PIXEL) + parseInt(1)
               

            })!
            

            
            
            _set_if_expression("W1tOT19XSElURV9QSVhFTF1dID09IDE=");
            _if(VAR_NO_WHITE_PIXEL == 1,function(){
            
               
               
               _set_if_expression("W1tQSVhFTF9XSElURV9OT1ddXSA9PSAx");
               _if(VAR_PIXEL_WHITE_NOW == 1,function(){
               
                  
                  
                  VAR_PIXEL_WHITE_STOP = parseInt(VAR_PIXEL_WHITE_STOP) + parseInt(1)
                  

                  
                  
                  _set_if_expression("W1tQSVhFTF9XSElURV9TVE9QXV0gPiA4");
                  _if(VAR_PIXEL_WHITE_STOP > 8,function(){
                  
                     
                     
                     VAR_PIXEL_WHITE_STOP = 0
                     

                     
                     
                     VAR_PIXEL_WHITE_NOW = 0
                     

                     
                     
                     VAR_TEMP_LIST.push(VAR_PIXEL_WHITE_MAX)
                     

                     
                     
                     VAR_PIXEL_WHITE_MAX = 0
                     

                  })!
                  

               })!
               

            })!
            

         })!
         

      })!
      delete _cycle_params().if_else;
      

      
      
      _do(function(){
      _set_action_info({ name: "For" });
      VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
      if(VAR_CYCLE_INDEX > parseInt(99))_break();
      
         
         
         VAR_TEMP_LIST = VAR_TEMP_LIST.filter(function(e){return e!== VAR_CYCLE_INDEX })
         

      })!
      

      
      
      VAR_COUNT_TEMP_INDEX = [
      0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
      ]
      

      
      
      _do(function(){
      _set_action_info({ name: "For" });
      VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
      if(VAR_CYCLE_INDEX > parseInt(100))_break();
      
         
         
         var numbers = VAR_TEMP_LIST
         var count = {};
         var leastFrequentNumber;
         var leastFrequentIndex;
         var minmaxdif = VAR_CYCLE_INDEX;
         // Підрахунок кількості входжень кожного числа
         for (var i = 0; i < numbers.length; i++) {
         var number = numbers[i];
         // Враховуємо різницю в 2 як одне число
         var adjustedNumber = Math.floor(number / minmaxdif) * minmaxdif;
         if (count[adjustedNumber] === undefined) {
         count[adjustedNumber] = 1;
         } else {
         count[adjustedNumber]++;
         }
         }
         // Пошук найрідше зустрічаються числа та їх індексу
         var minFrequency = Infinity;
         for (var j = 0; j < numbers.length; j++) {
         var currentNumber = numbers[j];
         var adjustedCurrentNumber = Math.floor(currentNumber / minmaxdif) * minmaxdif;
         if (count[adjustedCurrentNumber] < minFrequency) {
         minFrequency = count[adjustedCurrentNumber];
         leastFrequentNumber = currentNumber;
         leastFrequentIndex = j;
         }
         }
         totalCount = Object.keys(count).length;
         VAR_DEBUG_TEMP = totalCount
         VAR_LOW_INDEX = leastFrequentIndex;
         VAR_LOW_INDEX = VAR_LOW_INDEX + 1
         

         
         
         _set_if_expression("W1tERUJVR19URU1QXV0gPiAx");
         _if(VAR_DEBUG_TEMP > 1,function(){
         
            
            
            VAR_LIST_ELEMENT = (VAR_COUNT_TEMP_INDEX)[VAR_LOW_INDEX];
            

            
            
            VAR_LIST_ELEMENT = parseInt(VAR_LIST_ELEMENT) + parseInt(1)
            

            
            
            VAR_COUNT_TEMP_INDEX[(VAR_LOW_INDEX < 0) ? (VAR_COUNT_TEMP_INDEX.length + VAR_LOW_INDEX) : VAR_LOW_INDEX] = VAR_LIST_ELEMENT;
            

         })!
         

      })!
      

      
      
      _do(function(){
      _set_action_info({ name: "For" });
      VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(0)
      if(VAR_CYCLE_INDEX > parseInt(100))_break();
      
         
         
         VAR_TEMP_VARIABLE = 100 - VAR_CYCLE_INDEX
         

         
         
         VAR_VALUE_INDEX = (VAR_COUNT_TEMP_INDEX).indexOf(VAR_TEMP_VARIABLE)
         

         
         
         _set_if_expression("W1tWQUxVRV9JTkRFWF1dICE9IC0x");
         _if(VAR_VALUE_INDEX != -1,function(){
         
            
            
            _break("function")
            

         })!
         

      })!
      

      
      
      VAR_LOW_INDEX = VAR_VALUE_INDEX
      

      
      
      VAR_LIST_LENGTH = (VAR_TEMP_LIST).length
      

      
      
      native("imageprocessing", "delete", VAR_LOADED_IMAGE_ID)
      

      
      
      VAR_TEMP_INDEX = parseInt((((100/VAR_LIST_LENGTH) * VAR_LOW_INDEX) - 100/VAR_LIST_LENGTH/2) - 2)
      

      
      
      /*Browser*/
      _SELECTOR = " \u003eCSS\u003e .iconcaptcha-modal__body-selection \u003ei";
      wait_element(_SELECTOR)!
      get_element_selector(_SELECTOR, false).set_attr("style", "display: inline; top: 40%; left: " + VAR_TEMP_INDEX + "%;")!
      

      
      
      /*Browser*/
      _SELECTOR = " \u003eCSS\u003e .iconcaptcha-modal__body-selection \u003ei";
      wait_element_visible(_SELECTOR)!
      _call(_random_point, {})!
      _if(_result().length > 0, function(){
      move( {} )!
      get_element_selector(_SELECTOR, false).clarify(X,Y)!
      _call(_clarify, {} )!
      mouse(X,Y)!
      })!
      

   }
   

function GoodXevilPaySolver_GXP_ForAutosolveReHCaptcha()
   {
   
      
      
      _L["Path"] = {"ru":"Путь"};
      _L["To path"] = {"ru":"До пути"};
      _L["From path"] = {"ru":"От пути"};
      _L["Path object"] = {"ru":"Объект пути"};
      _L["File extension to remove"] = {"ru":"Удаляемое расширение файла"};
      _path = {
      sep: '/',
      delimiter: ';',
      isPathSeparator: function(code){
      return code===47 || code===92;
      },
      isDeviceRoot: function(code){
      return code >= 65 && code <= 90 || code >= 97 && code <= 122;
      },
      normalizeString: function(path, allowAboveRoot){
      var res = '';
      var lastSegmentLength = 0;
      var lastSlash = -1;
      var dots = 0;
      var code = 0;
      for(var i = 0; i <= path.length; ++i){
      if(i < path.length){
      code = path.charCodeAt(i);
      }else if(this.isPathSeparator(code)){
      break;
      }else{
      code = 47;
      };
      if(this.isPathSeparator(code)){
      if(lastSlash===i-1 || dots===1){
      }else if(dots === 2){
      if(res.length < 2 || !(lastSegmentLength===2) || !(res.charCodeAt(res.length-1)===46) || !(res.charCodeAt(res.length-2)===46)){
      if(res.length > 2){
      const lastSlashIndex = res.lastIndexOf(this.sep);
      if(lastSlashIndex===-1){
      res = '';
      lastSegmentLength = 0;
      }else{
      res = res.slice(0, lastSlashIndex);
      lastSegmentLength = res.length - 1 - res.lastIndexOf(this.sep);
      };
      lastSlash = i;
      dots = 0;
      continue;
      }else if(!(res.length===0)){
      res = '';
      lastSegmentLength = 0;
      lastSlash = i;
      dots = 0;
      continue;
      };
      };
      if(allowAboveRoot){
      res += res.length > 0 ? (this.sep + '..') : '..';
      lastSegmentLength = 2;
      };
      }else{
      if (res.length > 0){
      res += this.sep + path.slice(lastSlash + 1, i);
      }else{
      res = path.slice(lastSlash + 1, i);
      };
      lastSegmentLength = i - lastSlash - 1;
      };
      lastSlash = i;
      dots = 0;
      }else if(code===46 && !(dots===-1)){
      ++dots;
      }else{
      dots = -1;
      };
      };
      return res;
      },
      resolve: function(args){
      if(!Array.isArray(args)){
      args = Array.prototype.slice.call(arguments);
      };
      var resolvedDevice = '';
      var resolvedTail = '';
      var resolvedAbsolute = false;
      for(var i = args.length - 1; i > -1; i--){
      var path = args[i];
      _validate_argument_type(path, 'string', 'Path', '_path.resolve');
      if(path.length===0){
      continue;
      };
      const len = path.length;
      var rootEnd = 0;
      var device = '';
      var isAbsolute = false;
      const code = path.charCodeAt(0);
      if(len===1){
      if(this.isPathSeparator(code)){
      rootEnd = 1;
      isAbsolute = true;
      };
      }else if(this.isPathSeparator(code)){
      isAbsolute = true;
      if(this.isPathSeparator(path.charCodeAt(1))){
      var j = 2;
      var last = j;
      while(j < len && !this.isPathSeparator(path.charCodeAt(j))){
      j++;
      };
      if(j < len && !(j===last)){
      const firstPart = path.slice(last, j);
      last = j;
      while(j < len && this.isPathSeparator(path.charCodeAt(j))){
      j++;
      };
      if(j < len && !(j===last)){
      last = j;
      while(j < len && !this.isPathSeparator(path.charCodeAt(j))){
      j++;
      };
      if(j===len || !(j===last)){
      device = this.sep + this.sep + firstPart + this.sep + path.slice(last, j);
      rootEnd = j;
      };
      };
      };
      }else{
      rootEnd = 1;
      };
      }else if(this.isDeviceRoot(code) && path.charCodeAt(1)===58){
      device = path.slice(0, 2);
      rootEnd = 2;
      if(len > 2 && this.isPathSeparator(path.charCodeAt(2))){
      isAbsolute = true;
      rootEnd = 3;
      };
      };
      if(device.length > 0){
      if(resolvedDevice.length > 0){
      if(!(device.toLowerCase()===resolvedDevice.toLowerCase())){
      continue;
      };
      }else{
      resolvedDevice = device;
      };
      };
      if(resolvedAbsolute){
      if(resolvedDevice.length > 0){
      break;
      };
      }else{
      resolvedTail = path.slice(rootEnd) + this.sep + resolvedTail;
      resolvedAbsolute = isAbsolute;
      if(isAbsolute && resolvedDevice.length > 0){
      break;
      };
      };
      };
      resolvedTail = this.normalizeString(resolvedTail, !resolvedAbsolute);
      return resolvedAbsolute ? resolvedDevice + this.sep + resolvedTail : (resolvedDevice + resolvedTail) || '.';
      },
      normalize: function(path, removeTrailingSlash){
      _validate_argument_type(path, 'string', 'Path', '_path.normalize');
      removeTrailingSlash = _avoid_nilb(removeTrailingSlash, true);
      _validate_argument_type(removeTrailingSlash, ['boolean', 'number'], 'Remove trailing slashes', '_path.normalize');
      const len = path.length;
      if(len===0){
      return '';
      };
      var rootEnd = 0;
      var device = undefined;
      var isAbsolute = false;
      const code = path.charCodeAt(0);
      if(len===1){
      return this.isPathSeparator(code) ? (removeTrailingSlash ? '' : this.sep) : path;
      };
      if(this.isPathSeparator(code)){
      isAbsolute = true;
      if(this.isPathSeparator(path.charCodeAt(1))){
      var j = 2;
      var last = j;
      while (j < len && !this.isPathSeparator(path.charCodeAt(j))){
      j++;
      };
      if(j < len && !(j===last)){
      const firstPart = path.slice(last, j);
      last = j;
      while (j < len && this.isPathSeparator(path.charCodeAt(j))){
      j++;
      };
      if(j < len && !(j===last)){
      last = j;
      while (j < len && !this.isPathSeparator(path.charCodeAt(j))){
      j++;
      };
      if(j===len){
      return (this.sep + this.sep + firstPart + this.sep + path.slice(last) + (removeTrailingSlash ? '' : this.sep));
      };
      if(!(j===last)){
      device = this.sep + this.sep + firstPart + this.sep + path.slice(last, j);
      rootEnd = j;
      };
      };
      };
      }else{
      rootEnd = 1;
      };
      }else if(this.isDeviceRoot(code) && path.charCodeAt(1)===58){
      device = path.slice(0, 2);
      rootEnd = 2;
      if(len > 2 && this.isPathSeparator(path.charCodeAt(2))){
      isAbsolute = true;
      rootEnd = 3;
      };
      };
      var tail = rootEnd < len ? this.normalizeString(path.slice(rootEnd), !isAbsolute) : '';
      if(tail.length > 0 && this.isPathSeparator(path.charCodeAt(len - 1)) && !removeTrailingSlash){
      tail += this.sep;
      };
      if(device===undefined){
      return isAbsolute ? ((tail.length===0 && removeTrailingSlash ? '' : this.sep) + tail) : tail;
      };
      return isAbsolute ? (device + (tail.length===0 && removeTrailingSlash ? '' : this.sep) + tail) : (device + tail);
      },
      isAbsolute: function(path){
      _validate_argument_type(path, 'string', 'Path', '_path.isAbsolute');
      const len = path.length;
      if(len===0){
      return false;
      };
      const code = path.charCodeAt(0);
      return this.isPathSeparator(code) || len > 2 && this.isDeviceRoot(code) && path.charCodeAt(1) === 58 && this.isPathSeparator(path.charCodeAt(2));
      },
      join: function(args){
      if(!Array.isArray(args)){
      args = Array.prototype.slice.call(arguments);
      };
      if(args.length===0){
      return '.';
      };
      var joined = undefined;
      var firstPart = undefined;
      for(var i = 0; i < args.length; ++i){
      const arg = args[i];
      _validate_argument_type(arg, 'string', 'Path', '_path.join');
      if(arg.length > 0){
      if(joined === undefined){
      joined = firstPart = arg;
      }else{
      joined += (this.sep + arg);
      };
      };
      };
      if(joined === undefined){
      return '.';
      };
      var needsReplace = true;
      var slashCount = 0;
      if(this.isPathSeparator(firstPart.charCodeAt(0))){
      ++slashCount;
      const firstLen = firstPart.length;
      if(firstLen > 1 && this.isPathSeparator(firstPart.charCodeAt(1))){
      ++slashCount;
      if(firstLen > 2){
      if(this.isPathSeparator(firstPart.charCodeAt(2))){
      ++slashCount;
      }else{
      needsReplace = false;
      };
      };
      };
      };
      if(needsReplace){
      while(slashCount < joined.length && this.isPathSeparator(joined.charCodeAt(slashCount))){
      slashCount++;
      };
      if(slashCount >= 2){
      joined = this.sep + joined.slice(slashCount);
      };
      };
      return this.normalize(joined);
      },
      relative: function(from, to){
      _validate_argument_type(from, 'string', 'From path', '_path.relative');
      _validate_argument_type(to, 'string', 'To path', '_path.relative');
      if(from===to){
      return '';
      };
      const fromOrig = this.resolve(from);
      const toOrig = this.resolve(to);
      if(fromOrig===toOrig){
      return '';
      };
      from = fromOrig.toLowerCase();
      to = toOrig.toLowerCase();
      if(from===to){
      return '';
      };
      var fromStart = 0;
      while(fromStart < from.length && from.charCodeAt(fromStart)===this.sep.charCodeAt(0)){
      fromStart++;
      };
      var fromEnd = from.length;
      while(fromEnd - 1 > fromStart && from.charCodeAt(fromEnd - 1)===this.sep.charCodeAt(0)){
      fromEnd--;
      };
      const fromLen = fromEnd - fromStart;
      var toStart = 0;
      while(toStart < to.length && to.charCodeAt(toStart)===this.sep.charCodeAt(0)){
      toStart++;
      };
      var toEnd = to.length;
      while(toEnd - 1 > toStart && to.charCodeAt(toEnd - 1)===this.sep.charCodeAt(0)){
      toEnd--;
      };
      const toLen = toEnd - toStart;
      const length = fromLen < toLen ? fromLen : toLen;
      var lastCommonSep = -1;
      var i = 0;
      for(; i < length; i++){
      const fromCode = from.charCodeAt(fromStart + i);
      if(!(fromCode===to.charCodeAt(toStart + i))){
      break;
      }else if(fromCode===this.sep.charCodeAt(0)){
      lastCommonSep = i;
      };
      };
      if(!(i===length)){
      if(lastCommonSep===-1){
      return toOrig;
      };
      }else{
      if(toLen > length){
      if(to.charCodeAt(toStart + i)===this.sep.charCodeAt(0)){
      return toOrig.slice(toStart + i + 1);
      };
      if(i===2){
      return toOrig.slice(toStart + i);
      };
      };
      if(fromLen > length){
      if(from.charCodeAt(fromStart + i)===this.sep.charCodeAt(0)){
      lastCommonSep = i;
      }else if(i===2){
      lastCommonSep = 3;
      };
      };
      if(lastCommonSep===-1){
      lastCommonSep = 0;
      };
      };
      var out = '';
      for(i = fromStart + lastCommonSep + 1; i <= fromEnd; ++i){
      if(i===fromEnd || from.charCodeAt(i)===this.sep.charCodeAt(0)){
      out += out.length===0 ? '..' : this.sep + '..';
      };
      };
      toStart += lastCommonSep;
      if(out.length > 0){
      return out + toOrig.slice(toStart, toEnd);
      };
      if(toOrig.charCodeAt(toStart)===this.sep.charCodeAt(0)){
      ++toStart;
      };
      return toOrig.slice(toStart, toEnd);
      },
      toNamespacedPath: function(path){
      if(typeof path!='string'){
      return path;
      };
      if(path.length===0){
      return '';
      };
      const resolvedPath = this.resolve(path);
      if(resolvedPath.length <= 2){
      return path;
      };
      if(resolvedPath.charCodeAt(0)===this.sep.charCodeAt(0)){
      if(resolvedPath.charCodeAt(1)===this.sep.charCodeAt(0)){
      const code = resolvedPath.charCodeAt(2);
      if(!(code===63) && !(code===46)){
      return (this.sep + this.sep + '?' + this.sep + 'UNC' + this.sep + resolvedPath.slice(2));
      };
      };
      }else if(this.isDeviceRoot(resolvedPath.charCodeAt(0)) && resolvedPath.charCodeAt(1)===58 && resolvedPath.charCodeAt(2)===this.sep.charCodeAt(0)){
      return (this.sep + this.sep + '?' + this.sep + resolvedPath);
      };
      return path;
      },
      dirname: function(path){
      _validate_argument_type(path, 'string', 'Path', '_path.dirname');
      const len = path.length;
      if(len===0){
      return '.';
      };
      var rootEnd = -1;
      var offset = 0;
      const code = path.charCodeAt(0);
      if(len===1){
      return this.isPathSeparator(code) ? path : '.';
      };
      if(this.isPathSeparator(code)){
      rootEnd = offset = 1;
      if(this.isPathSeparator(path.charCodeAt(1))){
      var j = 2;
      var last = j;
      while(j < len && !this.isPathSeparator(path.charCodeAt(j))){
      j++;
      };
      if(j < len && !(j===last)){
      last = j;
      while(j < len && this.isPathSeparator(path.charCodeAt(j))){
      j++;
      };
      if(j < len && !(j===last)){
      last = j;
      while (j < len && !this.isPathSeparator(path.charCodeAt(j))){
      j++;
      };
      if(j===len){
      return path;
      };
      if(!(j===last)){
      rootEnd = offset = j + 1;
      };
      };
      };
      };
      }else if(this.isDeviceRoot(code) && path.charCodeAt(1)===58){
      rootEnd = len > 2 && this.isPathSeparator(path.charCodeAt(2)) ? 3 : 2;
      offset = rootEnd;
      };
      var end = -1;
      var matchedSlash = true;
      for(var i = len - 1; i >= offset; --i){
      if(this.isPathSeparator(path.charCodeAt(i))){
      if(!matchedSlash){
      end = i;
      break;
      };
      }else{
      matchedSlash = false;
      };
      };
      if(end===-1){
      if(rootEnd===-1){
      return '.';
      };
      end = rootEnd;
      };
      return path.slice(0, end);
      },
      basename: function(path, ext){
      _validate_argument_type(path, 'string', 'Path', '_path.basename');
      _validate_argument_type(ext, ['string','undefined','null'], 'File extension to remove', '_path.basename');
      var start = 0;
      var end = -1;
      var matchedSlash = true;
      var i = 0;
      if(path.length >= 2 && this.isDeviceRoot(path.charCodeAt(0)) && path.charCodeAt(1)===58){
      start = 2;
      };
      if(!(_is_nilb(ext)) && ext.length > 0 && ext.length <= path.length){
      if(ext===path){
      return '';
      };
      var extIdx = ext.length - 1;
      var firstNonSlashEnd = -1;
      for(i = path.length - 1; i >= start; --i){
      const code = path.charCodeAt(i);
      if(this.isPathSeparator(code)){
      if(!matchedSlash){
      start = i + 1;
      break;
      };
      }else{
      if(firstNonSlashEnd===-1){
      matchedSlash = false;
      firstNonSlashEnd = i + 1;
      };
      if(ext==='*'){
      if(code===46 && end===-1){
      end = i;
      };
      }else{
      if(extIdx >= 0){
      if(code===ext.charCodeAt(extIdx)){
      if(--extIdx===-1){
      end = i;
      };
      }else{
      extIdx = -1;
      end = firstNonSlashEnd;
      };
      };
      };
      };
      };
      if(start===end){
      end = firstNonSlashEnd;
      }else if(end === -1){
      end = path.length;
      };
      return path.slice(start, end);
      };
      for(i = path.length - 1; i >= start; --i){
      if(this.isPathSeparator(path.charCodeAt(i))){
      if(!matchedSlash){
      start = i + 1;
      break;
      };
      }else if(end===-1){
      matchedSlash = false;
      end = i + 1;
      };
      };
      if(end===-1){
      return '';
      };
      return path.slice(start, end);
      },
      extname: function(path){
      _validate_argument_type(path, 'string', 'Path', '_path.extname');
      var start = 0;
      var startDot = -1;
      var startPart = 0;
      var end = -1;
      var matchedSlash = true;
      var preDotState = 0;
      if(path.length >= 2 && path.charCodeAt(1)===58 && this.isDeviceRoot(path.charCodeAt(0))){
      start = startPart = 2;
      };
      for(var i = path.length - 1; i >= start; --i){
      const code = path.charCodeAt(i);
      if(this.isPathSeparator(code)){
      if(!matchedSlash){
      startPart = i + 1;
      break;
      };
      continue;
      };
      if(end===-1){
      matchedSlash = false;
      end = i + 1;
      };
      if(code===46){
      if(startDot===-1){
      startDot = i;
      }else if(!(preDotState===1)){
      preDotState = 1;
      };
      }else if(!(startDot===-1)){
      preDotState = -1;
      };
      };
      if(startDot===-1 || end===-1 || preDotState===0 || (preDotState===1 && startDot===end - 1 && startDot===startPart + 1)){
      return '';
      };
      return path.slice(startDot, end);
      },
      format: function(pathObject){
      _validate_argument_type(pathObject, 'object', 'Path object', '_path.format');
      var dir = pathObject.dir || pathObject.root;
      var base = pathObject.base || (pathObject.name || '' + pathObject.ext || '');
      if(!dir){
      return base;
      };
      return dir===pathObject.root ? (dir + base) : (dir + this.sep + base);
      },
      parse: function(path){
      _validate_argument_type(path, 'string', 'Path', '_path.parse');
      const ret = { root: '', dir: '', base: '', ext: '', name: '', items: [] };
      if(path.length===0){
      return ret;
      };
      const len = path.length;
      var rootEnd = 0;
      var code = path.charCodeAt(0);
      if(len===1){
      if(this.isPathSeparator(code)){
      ret.root = ret.dir = path;
      return ret;
      };
      ret.base = ret.name = ret.items[0] = path;
      return ret;
      };
      ret.items = path.split(/[\\/]+/).filter(function(el){return el.length > 0});
      if(this.isPathSeparator(code)){
      rootEnd = 1;
      if(this.isPathSeparator(path.charCodeAt(1))){
      var j = 2;
      var last = j;
      while(j < len && !this.isPathSeparator(path.charCodeAt(j))){
      j++;
      };
      if(j < len && !(j===last)){
      last = j;
      while (j < len && this.isPathSeparator(path.charCodeAt(j))){
      j++;
      };
      if(j < len && !(j===last)){
      last = j;
      while (j < len && !this.isPathSeparator(path.charCodeAt(j))){
      j++;
      };
      if(j===len){
      rootEnd = j;
      }else if(!(j===last)){
      rootEnd = j + 1;
      };
      };
      };
      };
      }else if(this.isDeviceRoot(code) && path.charCodeAt(1)===58){
      if(len <= 2){
      ret.root = ret.dir = path;
      return ret;
      };
      rootEnd = 2;
      if(this.isPathSeparator(path.charCodeAt(2))){
      if (len===3){
      ret.root = ret.dir = path;
      return ret;
      };
      rootEnd = 3;
      };
      };
      if(rootEnd > 0){
      ret.root = path.slice(0, rootEnd);
      };
      var startDot = -1;
      var startPart = rootEnd;
      var end = -1;
      var matchedSlash = true;
      var i = path.length - 1;
      var preDotState = 0;
      for(; i >= rootEnd; --i){
      code = path.charCodeAt(i);
      if(this.isPathSeparator(code)){
      if(!matchedSlash){
      startPart = i + 1;
      break;
      };
      continue;
      };
      if(end===-1){
      matchedSlash = false;
      end = i + 1;
      };
      if(code===46){
      if(startDot===-1){
      startDot = i;
      }else if(!(preDotState===1)){
      preDotState = 1;
      };
      }else if(!(startDot===-1)){
      preDotState = -1;
      };
      };
      if(!(end===-1)){
      if(startDot===-1 || preDotState === 0 || (preDotState===1 && startDot===end-1 && startDot===startPart+1)){
      ret.base = ret.name = path.slice(startPart, end);
      }else{
      ret.name = path.slice(startPart, startDot);
      ret.base = path.slice(startPart, end);
      ret.ext = path.slice(startDot, end);
      };
      };
      if(startPart > 0 && !(startPart===rootEnd)){
      ret.dir = path.slice(0, startPart - 1);
      }else{
      ret.dir = ret.root;
      };
      return ret;
      }
      };
      function project_directory(){
      var path = project_path();
      var c = '';
      var s = 0;
      var end = -1;
      for(var i = path.length - 1; i > -1; i--){
      if(_path.isPathSeparator(path.charCodeAt(i))){
      s++;
      if(c==='appsremote' || c==='appslocal'){
      end = i;
      break;
      }else{
      if(s===1){
      end = i;
      if(!(c==='project.xml')){
      break;
      };
      };
      if(s===2 && !(c==='engine')){
      break;
      };
      c = '';
      };
      }else{
      c = path.charAt(i) + c;
      };
      };
      return end===-1 ? _path.dirname(path) : path.slice(0, end);
      };
      function installation_path(){
      return JSON.parse(native("filesystem", "fileinfo", "settings.ini")).directory;
      };
      function _get_system_data(){
      RANDOM_FILE = "temp_" + rand() + ".bat";
      native("filesystem","writefile",JSON.stringify({path:RANDOM_FILE,value:"chcp 65001\r\nSET",base64:false,append:false}));
      native_async("processmanager","start",JSON.stringify({location:RANDOM_FILE,working_folder:"",waitfinish:true,arguments:"",version:2}))!
      var data_list = base64_decode(_result().split(",")[0]).split('\r\n').slice(2,-1);
      sleep(1000)!
      native("filesystem","removefile",RANDOM_FILE);
      SYSTEM_ENV_DATA = {};
      for(var i = 0; i < data_list.length; i++){
      if(data_list[i].indexOf('=') > -1){
      var data = data_list[i].split('=');
      var name = data[0];
      var value = data[1];
      SYSTEM_ENV_DATA[name] = value.indexOf("\\") > -1 ? _path.normalize(value) : value;
      };
      };
      if(SYSTEM_ENV_DATA["USERPROFILE"]){
      ["Desktop","Downloads","Documents","Pictures","Videos","Music","Favorites"].forEach(function(e){SYSTEM_ENV_DATA[e] = _path.join(SYSTEM_ENV_DATA["USERPROFILE"], e)});
      };
      };
      function _get_system_path(){
      var name = _function_argument("name");
      _if(typeof SYSTEM_ENV_DATA=="undefined",function(){
      _call_function(_get_system_data,{})!
      _result_function();
      })!
      var labels = {
      "App Data":"APPDATA",
      "Local App Data": "LOCALAPPDATA",
      "Program Files":"ProgramFiles",
      "Program Files (x86)":"ProgramFiles(x86)",
      "Program Data":"ProgramData",
      "Public":"PUBLIC",
      "System Drive":"SystemDrive",
      "System Root":"SystemRoot",
      "Windows Directory":"windir",
      "Temp":"TEMP",
      "User Name":"USERNAME",
      "User Profile":"USERPROFILE",
      "Computer Name":"COMPUTERNAME"
      };
      var label = _avoid_nilb(labels[name], name);
      if(_is_nilb(SYSTEM_ENV_DATA[label])){
      fail(_K=="ru" ? 'Не удалось найти путь "' + name + '" в системных данных.' : 'Could not find path "' + name + '" in system data.');
      };
      _function_return(SYSTEM_ENV_DATA[label]);
      };
      

      
      
      VAR_PROJECT_DIRECTORY = project_directory()
      

      
      
      _set_if_expression("dHJ1ZQ==");
      _if(true,function(){
      
         
         
         var json = JSON.parse(native("filesystem", "fileinfo", VAR_PROJECT_DIRECTORY + "/CaptchaAutoSolver/content"))
         VAR_FILEINFO_EXISTS = json["exists"]
         VAR_1 = json["size"]
         VAR_1 = json["directory"]
         VAR_1 = json["is_directory"]
         VAR_1 = new Date(json["last_modified"] * 1000)
         

         
         
         _set_if_expression("W1tGSUxFSU5GT19FWElTVFNdXSA9PSBmYWxzZQ==");
         _if(VAR_FILEINFO_EXISTS == false,function(){
         
            
            
            native("filesystem", "createdir", VAR_PROJECT_DIRECTORY + "/CaptchaAutoSolver/content")
            

         })!
         

         
         
         var json = JSON.parse(native("filesystem", "fileinfo", VAR_PROJECT_DIRECTORY + "/CaptchaAutoSolver/content/hcaptcha"))
         VAR_FILEINFO_EXISTS = json["exists"]
         VAR_1 = json["size"]
         VAR_1 = json["directory"]
         VAR_1 = json["is_directory"]
         VAR_1 = new Date(json["last_modified"] * 1000)
         

         
         
         _set_if_expression("W1tGSUxFSU5GT19FWElTVFNdXSA9PSBmYWxzZQ==");
         _if(VAR_FILEINFO_EXISTS == false,function(){
         
            
            
            native("filesystem", "createdir", VAR_PROJECT_DIRECTORY + "/CaptchaAutoSolver/content/hcaptcha")
            

         })!
         

         
         
         var json = JSON.parse(native("filesystem", "fileinfo", VAR_PROJECT_DIRECTORY + "/CaptchaAutoSolver/content/recaptcha"))
         VAR_FILEINFO_EXISTS = json["exists"]
         VAR_1 = json["size"]
         VAR_1 = json["directory"]
         VAR_1 = json["is_directory"]
         VAR_1 = new Date(json["last_modified"] * 1000)
         

         
         
         _set_if_expression("W1tGSUxFSU5GT19FWElTVFNdXSA9PSBmYWxzZQ==");
         _if(VAR_FILEINFO_EXISTS == false,function(){
         
            
            
            native("filesystem", "createdir", VAR_PROJECT_DIRECTORY + "/CaptchaAutoSolver/content/recaptcha")
            

         })!
         

      })!
      

      
      
      _set_if_expression("dHJ1ZQ==");
      _if(true,function(){
      
         
         
         VAR_TEMP_DATA = "ew0KICAgImNvbnRlbnRfc2NyaXB0cyI6IFsgew0KICAgICAgImFsbF9mcmFtZXMiOiB0cnVlLA0KICAgICAgImpzIjogWyJjb250ZW50L3NjcmlwdC5qcyJdLA0KICAgICAgIm1hdGNoZXMiOiBbICJcdTAwM0NhbGxfdXJscz4iIF0sDQogICAgICAicnVuX2F0IjogImRvY3VtZW50X3N0YXJ0Ig0KICAgfSBdLA0KICAgImNvbnRlbnRfc2VjdXJpdHlfcG9saWN5Ijogew0KICAgICAgImV4dGVuc2lvbl9wYWdlcyI6ICJzY3JpcHQtc3JjICdzZWxmJzsgb2JqZWN0LXNyYyAnc2VsZiciDQogICB9LA0KICAgIm1hbmlmZXN0X3ZlcnNpb24iOiAzLA0KICAgIm5hbWUiOiAiSW5qZWN0aW9ucyIsDQogICAicGVybWlzc2lvbnMiOiBbICJzdG9yYWdlIiwgImNvbnRleHRNZW51cyIgXSwNCiAgICJ2ZXJzaW9uIjogIjEuMC41IiwNCiAgICJ3ZWJfYWNjZXNzaWJsZV9yZXNvdXJjZXMiOiBbIHsNCiAgICAgICJtYXRjaGVzIjogWyAiXHUwMDNDYWxsX3VybHM+IiBdLA0KICAgICAgInJlc291cmNlcyI6IFsgImNvbnRlbnQvKiIgXQ0KICAgfSBdDQp9DQo="
         

         
         
         var json = JSON.parse(native("filesystem", "fileinfo", VAR_PROJECT_DIRECTORY + "/CaptchaAutoSolver/manifest.json"))
         VAR_FILEINFO_EXISTS = json["exists"]
         VAR_1 = json["size"]
         VAR_1 = json["directory"]
         VAR_1 = json["is_directory"]
         VAR_1 = new Date(json["last_modified"] * 1000)
         

         
         
         _cycle_params().if_else = VAR_FILEINFO_EXISTS == false;
         _set_if_expression("W1tGSUxFSU5GT19FWElTVFNdXSA9PSBmYWxzZQ==");
         _if(_cycle_params().if_else,function(){
         
            
            
            native("filesystem", "writefile", JSON.stringify({path: VAR_PROJECT_DIRECTORY + "/CaptchaAutoSolver/manifest.json",value: (VAR_TEMP_DATA).toString(),base64:true,append:false}))
            

         })!
         

         
         
         _if(!_cycle_params().if_else,function(){
         
            
            
            VAR_FILE_CONTENT = native("filesystem", "readfile", JSON.stringify({value: VAR_PROJECT_DIRECTORY + "/CaptchaAutoSolver/manifest.json",base64:true,from:0,to:0}))
            

            
            
            _set_if_expression("W1tGSUxFX0NPTlRFTlRdXSAhPSBbW1RFTVBfREFUQV1d");
            _if(VAR_FILE_CONTENT != VAR_TEMP_DATA,function(){
            
               
               
               native("filesystem", "writefile", JSON.stringify({path: VAR_PROJECT_DIRECTORY + "/CaptchaAutoSolver/manifest.json",value: (VAR_TEMP_DATA).toString(),base64:true,append:false}))
               

            })!
            

         })!
         delete _cycle_params().if_else;
         

      })!
      

      
      
      _set_if_expression("dHJ1ZQ==");
      _if(true,function(){
      
         
         
         VAR_TEMP_DATA = "bGV0IHNjcmlwdHMgPSBbDQoJWyJjb250ZW50L2hjYXB0Y2hhL2ludGVyY2VwdG9yLmpzIl0sDQoJWyJjb250ZW50L2hjYXB0Y2hhL2h1bnRlci5qcyJdLA0KCVsiY29udGVudC9yZWNhcHRjaGEvaW50ZXJjZXB0b3IuanMiXSwNCglbImNvbnRlbnQvcmVjYXB0Y2hhL2h1bnRlci5qcyJdDQpdOw0Kc2NyaXB0cy5mb3JFYWNoKHMgPT4gew0KCWlmIChzLmxlbmd0aCA+IDEgJiYgIXNbMV0pIHtyZXR1cm47fQ0KCWxldCBzY3JpcHQgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdzY3JpcHQnKTsNCglzY3JpcHQuc3JjID0gY2hyb21lLnJ1bnRpbWUuZ2V0VVJMKHNbMF0pOw0KCShkb2N1bWVudC5oZWFkfHxkb2N1bWVudC5kb2N1bWVudEVsZW1lbnQpLnByZXBlbmQoc2NyaXB0KTsNCn0pOw=="
         

         
         
         var json = JSON.parse(native("filesystem", "fileinfo", VAR_PROJECT_DIRECTORY + "/CaptchaAutoSolver/content/script.js"))
         VAR_FILEINFO_EXISTS = json["exists"]
         VAR_1 = json["size"]
         VAR_1 = json["directory"]
         VAR_1 = json["is_directory"]
         VAR_1 = new Date(json["last_modified"] * 1000)
         

         
         
         _cycle_params().if_else = VAR_FILEINFO_EXISTS == false;
         _set_if_expression("W1tGSUxFSU5GT19FWElTVFNdXSA9PSBmYWxzZQ==");
         _if(_cycle_params().if_else,function(){
         
            
            
            native("filesystem", "writefile", JSON.stringify({path: VAR_PROJECT_DIRECTORY + "/CaptchaAutoSolver/content/script.js",value: (VAR_TEMP_DATA).toString(),base64:true,append:false}))
            

         })!
         

         
         
         _if(!_cycle_params().if_else,function(){
         
            
            
            VAR_FILE_CONTENT = native("filesystem", "readfile", JSON.stringify({value: VAR_PROJECT_DIRECTORY + "/CaptchaAutoSolver/content/script.js",base64:true,from:0,to:0}))
            

            
            
            _set_if_expression("W1tGSUxFX0NPTlRFTlRdXSAhPSBbW1RFTVBfREFUQV1d");
            _if(VAR_FILE_CONTENT != VAR_TEMP_DATA,function(){
            
               
               
               native("filesystem", "writefile", JSON.stringify({path: VAR_PROJECT_DIRECTORY + "/CaptchaAutoSolver/content/script.js",value: (VAR_TEMP_DATA).toString(),base64:true,append:false}))
               

            })!
            

         })!
         delete _cycle_params().if_else;
         

      })!
      

      
      
      _set_if_expression("dHJ1ZQ==");
      _if(true,function(){
      
         
         
         VAR_TEMP_DATA = "KCgpID0+IHsNCiAgICBjb25zdCBfaW50SWQgPSBzZXRJbnRlcnZhbCgoKSA9PiB7DQoJCWxldCB0ZXh0YXJlYSA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoInRleHRhcmVhW25hbWU9aC1jYXB0Y2hhLXJlc3BvbnNlXSIpOw0KCQlpZiAoIXRleHRhcmVhKSByZXR1cm47DQoJCWxldCBjb250YWluZXIgPSB0ZXh0YXJlYS5wYXJlbnROb2RlOw0KCQlpZiAoIWNvbnRhaW5lci5pZCkgew0KCQkJY29udGFpbmVyLmlkID0gImhjYXB0Y2hhLWNvbnRhaW5lci0iICsgRGF0ZS5ub3coKTsNCgkJfQ0KCQlpZihjb250YWluZXIuZGF0YXNldC5zaXRla2V5KXsNCgkJCWxldCBjYXB0Y2hhSW5mbyA9IHsNCgkJCQljb250YWluZXJJZDogY29udGFpbmVyLmlkLA0KCQkJCXNpdGVrZXk6IGNvbnRhaW5lci5kYXRhc2V0LnNpdGVrZXksDQoJCQkJY2FsbGJhY2s6IGNvbnRhaW5lci5kYXRhc2V0LmNhbGxiYWNrIHx8IG51bGwsDQoJCQl9Ow0KCQkJd2luZG93LmNhcHRjaGFJbmZvaHR3byA9IGNhcHRjaGFJbmZvOw0KCQkJY2xlYXJJbnRlcnZhbChfaW50SWQpOw0KCQl9DQogICAgfSwgMzAwMCk7DQoNCn0pKCk="
         

         
         
         var json = JSON.parse(native("filesystem", "fileinfo", VAR_PROJECT_DIRECTORY + "/CaptchaAutoSolver/content/hcaptcha/hunter.js"))
         VAR_FILEINFO_EXISTS = json["exists"]
         VAR_1 = json["size"]
         VAR_1 = json["directory"]
         VAR_1 = json["is_directory"]
         VAR_1 = new Date(json["last_modified"] * 1000)
         

         
         
         _cycle_params().if_else = VAR_FILEINFO_EXISTS == false;
         _set_if_expression("W1tGSUxFSU5GT19FWElTVFNdXSA9PSBmYWxzZQ==");
         _if(_cycle_params().if_else,function(){
         
            
            
            native("filesystem", "writefile", JSON.stringify({path: VAR_PROJECT_DIRECTORY + "/CaptchaAutoSolver/content/hcaptcha/hunter.js",value: (VAR_TEMP_DATA).toString(),base64:true,append:false}))
            

         })!
         

         
         
         _if(!_cycle_params().if_else,function(){
         
            
            
            VAR_FILE_CONTENT = native("filesystem", "readfile", JSON.stringify({value: VAR_PROJECT_DIRECTORY + "/CaptchaAutoSolver/content/hcaptcha/hunter.js",base64:true,from:0,to:0}))
            

            
            
            _set_if_expression("W1tGSUxFX0NPTlRFTlRdXSAhPSBbW1RFTVBfREFUQV1d");
            _if(VAR_FILE_CONTENT != VAR_TEMP_DATA,function(){
            
               
               
               native("filesystem", "writefile", JSON.stringify({path: VAR_PROJECT_DIRECTORY + "/CaptchaAutoSolver/content/hcaptcha/hunter.js",value: (VAR_TEMP_DATA).toString(),base64:true,append:false}))
               

            })!
            

         })!
         delete _cycle_params().if_else;
         

      })!
      

      
      
      _set_if_expression("dHJ1ZQ==");
      _if(true,function(){
      
         
         
         VAR_TEMP_DATA = "KCgpID0+IHsNCiAgICBsZXQgaENhcHRjaGFJbnN0YW5jZTsNCiAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkod2luZG93LCAiaGNhcHRjaGEiLCB7DQogICAgICAgIGdldDogZnVuY3Rpb24gKCkgew0KICAgICAgICAgICAgcmV0dXJuIGhDYXB0Y2hhSW5zdGFuY2U7DQogICAgICAgIH0sDQogICAgICAgIHNldDogZnVuY3Rpb24gKGUpIHsNCiAgICAgICAgICAgIGhDYXB0Y2hhSW5zdGFuY2UgPSBlOw0KDQogICAgICAgICAgICBsZXQgb3JpZ2luYWxSZW5kZXJGdW5jID0gZS5yZW5kZXI7DQoNCiAgICAgICAgICAgIGhDYXB0Y2hhSW5zdGFuY2UucmVuZGVyID0gZnVuY3Rpb24gKGNvbnRhaW5lciwgb3B0cykgew0KICAgICAgICAgICAgICAgIGNyZWF0ZUhDYXB0Y2hhV2lkZ2V0KGNvbnRhaW5lciwgb3B0cyk7DQogICAgICAgICAgICAgICAgcmV0dXJuIG9yaWdpbmFsUmVuZGVyRnVuYyhjb250YWluZXIsIG9wdHMpOw0KICAgICAgICAgICAgfTsNCg0KICAgICAgICAgICAgaGNhcHRjaGEuZ2V0UmVzcG9uc2UgPSAoKSA9PiBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKCdbbmFtZT1oLWNhcHRjaGEtcmVzcG9uc2VdJykudmFsdWU7DQogICAgICAgIH0sDQogICAgfSk7DQogICAgbGV0IGNyZWF0ZUhDYXB0Y2hhV2lkZ2V0ID0gZnVuY3Rpb24gKGNvbnRhaW5lciwgb3B0cykgew0KICAgICAgICBpZiAodHlwZW9mIGNvbnRhaW5lciAhPT0gJ3N0cmluZycpIHsNCiAgICAgICAgICAgIGlmICghY29udGFpbmVyLmlkKSB7DQogICAgICAgICAgICAgICAgY29udGFpbmVyLmlkID0gImhjYXB0Y2hhLWNvbnRhaW5lci0iICsgRGF0ZS5ub3coKTsNCiAgICAgICAgICAgIH0NCiAgICAgICAgICAgIGNvbnRhaW5lciA9IGNvbnRhaW5lci5pZDsNCiAgICAgICAgfQ0KICAgICAgICBpZiAob3B0cy5jYWxsYmFjayAhPT0gdW5kZWZpbmVkICYmIHR5cGVvZiBvcHRzLmNhbGxiYWNrID09PSAiZnVuY3Rpb24iKSB7DQogICAgICAgICAgICBsZXQga2V5ID0gImhjYXB0Y2hhQ2FsbGJhY2siICsgRGF0ZS5ub3coKTsNCiAgICAgICAgICAgIHdpbmRvd1trZXldID0gb3B0cy5jYWxsYmFjazsNCiAgICAgICAgICAgIG9wdHMuY2FsbGJhY2sgPSBrZXk7DQogICAgICAgIH0NCiAgICAgICAgbGV0IGNhcHRjaGFJbmZvID0gew0KCQkJY29udGFpbmVySWQ6IGNvbnRhaW5lciwNCiAgICAgICAgICAgIHNpdGVrZXk6IG9wdHMuc2l0ZWtleSwNCiAgICAgICAgICAgIGNhbGxiYWNrOiBvcHRzLmNhbGxiYWNrLA0KICAgICAgICB9Ow0KCQl3aW5kb3cuY2FwdGNoYUluZm9oID0gY2FwdGNoYUluZm87DQogICAgfQ0KfSkoKQ=="
         

         
         
         var json = JSON.parse(native("filesystem", "fileinfo", VAR_PROJECT_DIRECTORY + "/CaptchaAutoSolver/content/hcaptcha/interceptor.js"))
         VAR_FILEINFO_EXISTS = json["exists"]
         VAR_1 = json["size"]
         VAR_1 = json["directory"]
         VAR_1 = json["is_directory"]
         VAR_1 = new Date(json["last_modified"] * 1000)
         

         
         
         _cycle_params().if_else = VAR_FILEINFO_EXISTS == false;
         _set_if_expression("W1tGSUxFSU5GT19FWElTVFNdXSA9PSBmYWxzZQ==");
         _if(_cycle_params().if_else,function(){
         
            
            
            native("filesystem", "writefile", JSON.stringify({path: VAR_PROJECT_DIRECTORY + "/CaptchaAutoSolver/content/hcaptcha/interceptor.js",value: (VAR_TEMP_DATA).toString(),base64:true,append:false}))
            

         })!
         

         
         
         _if(!_cycle_params().if_else,function(){
         
            
            
            VAR_FILE_CONTENT = native("filesystem", "readfile", JSON.stringify({value: VAR_PROJECT_DIRECTORY + "/CaptchaAutoSolver/content/hcaptcha/interceptor.js",base64:true,from:0,to:0}))
            

            
            
            _set_if_expression("W1tGSUxFX0NPTlRFTlRdXSAhPSBbW1RFTVBfREFUQV1d");
            _if(VAR_FILE_CONTENT != VAR_TEMP_DATA,function(){
            
               
               
               native("filesystem", "writefile", JSON.stringify({path: VAR_PROJECT_DIRECTORY + "/CaptchaAutoSolver/content/hcaptcha/interceptor.js",value: (VAR_TEMP_DATA).toString(),base64:true,append:false}))
               

            })!
            

         })!
         delete _cycle_params().if_else;
         

      })!
      

      
      
      _set_if_expression("dHJ1ZQ==");
      _if(true,function(){
      
         
         
         VAR_TEMP_DATA = "KCgpID0+IHsNCiAgICBzZXRJbnRlcnZhbChmdW5jdGlvbiAoKSB7DQogICAgICAgIGlmICh3aW5kb3cuX19fZ3JlY2FwdGNoYV9jZmcgPT09IHVuZGVmaW5lZCkge3JldHVybjt9DQogICAgICAgIGlmIChfX19ncmVjYXB0Y2hhX2NmZy5jbGllbnRzID09PSB1bmRlZmluZWQpIHtyZXR1cm47fQ0KICAgICAgICBmb3IgKGxldCB3aWRnZXRJZCBpbiBfX19ncmVjYXB0Y2hhX2NmZy5jbGllbnRzKSB7DQogICAgICAgICAgICBsZXQgd2lkZ2V0ID0gX19fZ3JlY2FwdGNoYV9jZmcuY2xpZW50c1t3aWRnZXRJZF07DQogICAgICAgICAgICBsZXQgd2lkZ2V0SW5mbyA9IGdldFJlY2FwdGNoYVdpZGdldEluZm8od2lkZ2V0KTsNCiAgICAgICAgICAgIHdpbmRvdy53aWRnZXRJbmZvcmUgPSB3aWRnZXRJbmZvOw0KICAgICAgICB9DQogICAgfSwgMzAwMCk7DQogICAgbGV0IGdldFJlY2FwdGNoYVdpZGdldEluZm8gPSBmdW5jdGlvbiAod2lkZ2V0KSB7DQogICAgICAgIGxldCBpbmZvID0gew0KICAgICAgICAgICAgY2FwdGNoYVR5cGU6ICJyZWNhcHRjaGEiLA0KICAgICAgICAgICAgd2lkZ2V0SWQ6IHdpZGdldC5pZCwNCiAgICAgICAgICAgIHZlcnNpb246ICJ2MiIsDQogICAgICAgICAgICBzaXRla2V5OiBudWxsLA0KICAgICAgICAgICAgYWN0aW9uOiBudWxsLA0KICAgICAgICAgICAgczogbnVsbCwNCiAgICAgICAgICAgIGNhbGxiYWNrOiBudWxsLA0KICAgICAgICAgICAgZW50ZXJwcmlzZTogZ3JlY2FwdGNoYS5lbnRlcnByaXNlID8gdHJ1ZSA6IGZhbHNlLA0KICAgICAgICAgICAgY29udGFpbmVySWQ6IG51bGwsDQogICAgICAgICAgICBiaW5kZWRCdXR0b25JZDogbnVsbCwNCiAgICAgICAgfTsNCiAgICAgICAgbGV0IGlzQmFkZ2UgPSBmYWxzZTsNCiAgICAgICAgbWFpbkxvb3A6IGZvciAobGV0IGsxIGluIHdpZGdldCkgew0KICAgICAgICAgICAgaWYgKHR5cGVvZiB3aWRnZXRbazFdICE9PSAib2JqZWN0Iikge2NvbnRpbnVlO30NCiAgICAgICAgICAgIGZvciAobGV0IGsyIGluIHdpZGdldFtrMV0pIHsNCiAgICAgICAgICAgICAgICBpZiAod2lkZ2V0W2sxXVtrMl0gJiYgd2lkZ2V0W2sxXVtrMl0uY2xhc3NMaXN0ICYmIHdpZGdldFtrMV1bazJdLmNsYXNzTGlzdC5jb250YWlucygiZ3JlY2FwdGNoYS1iYWRnZSIpKSB7DQogICAgICAgICAgICAgICAgICAgIGlzQmFkZ2UgPSB0cnVlOw0KICAgICAgICAgICAgICAgICAgICBicmVhayBtYWluTG9vcDsNCiAgICAgICAgICAgICAgICB9DQogICAgICAgICAgICB9DQogICAgICAgIH0NCiAgICAgICAgaWYgKGlzQmFkZ2UpIHsNCiAgICAgICAgICAgIGluZm8udmVyc2lvbiA9ICJ2MyI7DQogICAgICAgICAgICBmb3IgKGxldCBrMSBpbiB3aWRnZXQpIHsNCiAgICAgICAgICAgICAgICBsZXQgb2JqID0gd2lkZ2V0W2sxXTsNCiAgICAgICAgICAgICAgICBpZiAodHlwZW9mIG9iaiAhPT0gIm9iamVjdCIpIHtjb250aW51ZTt9DQogICAgICAgICAgICAgICAgZm9yIChsZXQgazIgaW4gb2JqKSB7DQogICAgICAgICAgICAgICAgICAgIGlmICh0eXBlb2Ygb2JqW2syXSAhPT0gInN0cmluZyIpIHtjb250aW51ZTt9DQogICAgICAgICAgICAgICAgICAgIGlmIChvYmpbazJdID09ICJmdWxsc2NyZWVuIikgaW5mby52ZXJzaW9uID0gInYyX2ludmlzaWJsZSI7DQogICAgICAgICAgICAgICAgfQ0KICAgICAgICAgICAgfQ0KICAgICAgICB9DQogICAgICAgIGxldCBuMTsNCiAgICAgICAgZm9yIChsZXQgayBpbiB3aWRnZXQpIHsNCiAgICAgICAgICAgIGlmICh3aWRnZXRba10gJiYgd2lkZ2V0W2tdLm5vZGVUeXBlKSB7DQogICAgICAgICAgICAgICAgaWYgKHdpZGdldFtrXS5pZCkgew0KICAgICAgICAgICAgICAgICAgICBpbmZvLmNvbnRhaW5lcklkID0gd2lkZ2V0W2tdLmlkOw0KICAgICAgICAgICAgICAgIH0gZWxzZSBpZiAod2lkZ2V0W2tdLmRhdGFzZXQuc2l0ZWtleSkgew0KICAgICAgICAgICAgICAgICAgICB3aWRnZXRba10uaWQgPSAicmVjYXB0Y2hhLWNvbnRhaW5lci0iICsgRGF0ZS5ub3coKTsNCiAgICAgICAgICAgICAgICAgICAgaW5mby5jb250YWluZXJJZCA9IHdpZGdldFtrXS5pZDsNCiAgICAgICAgICAgICAgICB9IGVsc2UgaWYgKGluZm8udmVyc2lvbiA9PSAndjInKSB7DQogICAgICAgICAgICAgICAgICAgIGlmICghbjEpIHsNCiAgICAgICAgICAgICAgICAgICAgICAgIG4xID0gd2lkZ2V0W2tdOw0KICAgICAgICAgICAgICAgICAgICAgICAgY29udGludWU7DQogICAgICAgICAgICAgICAgICAgIH0NCiAgICAgICAgICAgICAgICAgICAgaWYgKHdpZGdldFtrXS5pc1NhbWVOb2RlKG4xKSkgew0KICAgICAgICAgICAgICAgICAgICAgICAgd2lkZ2V0W2tdLmlkID0gInJlY2FwdGNoYS1jb250YWluZXItIiArIERhdGUubm93KCk7DQogICAgICAgICAgICAgICAgICAgICAgICBpbmZvLmNvbnRhaW5lcklkID0gd2lkZ2V0W2tdLmlkOw0KICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWs7DQogICAgICAgICAgICAgICAgICAgIH0NCiAgICAgICAgICAgICAgICB9DQogICAgICAgICAgICB9DQogICAgICAgIH0NCiAgICAgICAgZm9yIChsZXQgazEgaW4gd2lkZ2V0KSB7DQogICAgICAgICAgICBsZXQgb2JqID0gd2lkZ2V0W2sxXTsNCiAgICAgICAgICAgIGlmICh0eXBlb2Ygb2JqICE9PSAib2JqZWN0Iikge2NvbnRpbnVlO30NCiAgICAgICAgICAgIGZvciAobGV0IGsyIGluIG9iaikgew0KICAgICAgICAgICAgICAgIGlmIChvYmpbazJdID09PSBudWxsKSB7Y29udGludWU7fQ0KICAgICAgICAgICAgICAgIGlmICh0eXBlb2Ygb2JqW2syXSAhPT0gIm9iamVjdCIpIHtjb250aW51ZTt9DQogICAgICAgICAgICAgICAgaWYgKG9ialtrMl0uc2l0ZWtleSA9PT0gdW5kZWZpbmVkKSB7Y29udGludWU7fQ0KICAgICAgICAgICAgICAgIGlmIChvYmpbazJdLmFjdGlvbiA9PT0gdW5kZWZpbmVkKSB7Y29udGludWU7fQ0KICAgICAgICAgICAgICAgIGZvciAobGV0IGszIGluIG9ialtrMl0pIHsNCiAgICAgICAgICAgICAgICAgICAgaWYgKGszID09PSAic2l0ZWtleSIpIGluZm8uc2l0ZWtleSA9IG9ialtrMl1bazNdOw0KICAgICAgICAgICAgICAgICAgICBpZiAoazMgPT09ICJhY3Rpb24iKSBpbmZvLmFjdGlvbiA9IG9ialtrMl1bazNdOw0KICAgICAgICAgICAgICAgICAgICBpZiAoazMgPT09ICJzIikgaW5mby5zID0gb2JqW2syXVtrM107DQogICAgICAgICAgICAgICAgICAgIGlmIChrMyA9PT0gImNhbGxiYWNrIikgaW5mby5jYWxsYmFjayA9IG9ialtrMl1bazNdOw0KICAgICAgICAgICAgICAgICAgICBpZiAoazMgPT09ICJiaW5kIiAmJiBvYmpbazJdW2szXSkgew0KICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHR5cGVvZiBvYmpbazJdW2szXSA9PT0gInN0cmluZyIpIHsNCiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpbmZvLmJpbmRlZEJ1dHRvbklkID0gb2JqW2syXVtrM107DQogICAgICAgICAgICAgICAgICAgICAgICB9IGVsc2Ugew0KICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCBidXR0b24gPSBvYmpbazJdW2szXTsNCiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoYnV0dG9uLmlkID09PSB1bmRlZmluZWQpIHsNCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYnV0dG9uLmlkID0gInJlY2FwdGNoYUJpbmRlZEVsZW1lbnQiICsgd2lkZ2V0LmlkOw0KICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0NCiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpbmZvLmJpbmRlZEJ1dHRvbklkID0gYnV0dG9uLmlkOw0KICAgICAgICAgICAgICAgICAgICAgICAgfQ0KICAgICAgICAgICAgICAgICAgICB9DQogICAgICAgICAgICAgICAgfQ0KICAgICAgICAgICAgfQ0KICAgICAgICB9DQogICAgICAgIGlmICh0eXBlb2YgaW5mby5jYWxsYmFjayA9PT0gImZ1bmN0aW9uIikgew0KICAgICAgICAgICAgbGV0IGNhbGxiYWNrS2V5ID0gInJlQ2FwdGNoYVdpZGdldENhbGxiYWNrIiArIHdpZGdldC5pZDsNCiAgICAgICAgICAgIHdpbmRvd1tjYWxsYmFja0tleV0gPSBpbmZvLmNhbGxiYWNrOw0KICAgICAgICAgICAgaW5mby5jYWxsYmFjayA9IGNhbGxiYWNrS2V5Ow0KICAgICAgICB9DQogICAgICAgIHJldHVybiBpbmZvOw0KICAgIH07DQp9KSgp"
         

         
         
         var json = JSON.parse(native("filesystem", "fileinfo", VAR_PROJECT_DIRECTORY + "/CaptchaAutoSolver/content/recaptcha/hunter.js"))
         VAR_FILEINFO_EXISTS = json["exists"]
         VAR_1 = json["size"]
         VAR_1 = json["directory"]
         VAR_1 = json["is_directory"]
         VAR_1 = new Date(json["last_modified"] * 1000)
         

         
         
         _cycle_params().if_else = VAR_FILEINFO_EXISTS == false;
         _set_if_expression("W1tGSUxFSU5GT19FWElTVFNdXSA9PSBmYWxzZQ==");
         _if(_cycle_params().if_else,function(){
         
            
            
            native("filesystem", "writefile", JSON.stringify({path: VAR_PROJECT_DIRECTORY + "/CaptchaAutoSolver/content/recaptcha/hunter.js",value: (VAR_TEMP_DATA).toString(),base64:true,append:false}))
            

         })!
         

         
         
         _if(!_cycle_params().if_else,function(){
         
            
            
            VAR_FILE_CONTENT = native("filesystem", "readfile", JSON.stringify({value: VAR_PROJECT_DIRECTORY + "/CaptchaAutoSolver/content/recaptcha/hunter.js",base64:true,from:0,to:0}))
            

            
            
            _set_if_expression("W1tGSUxFX0NPTlRFTlRdXSAhPSBbW1RFTVBfREFUQV1d");
            _if(VAR_FILE_CONTENT != VAR_TEMP_DATA,function(){
            
               
               
               native("filesystem", "writefile", JSON.stringify({path: VAR_PROJECT_DIRECTORY + "/CaptchaAutoSolver/content/recaptcha/hunter.js",value: (VAR_TEMP_DATA).toString(),base64:true,append:false}))
               

            })!
            

         })!
         delete _cycle_params().if_else;
         

      })!
      

      
      
      _set_if_expression("dHJ1ZQ==");
      _if(true,function(){
      
         
         
         VAR_TEMP_DATA = "KCgpID0+IHsNCiAgICBsZXQgcmVjYXB0Y2hhSW5zdGFuY2U7DQogICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KHdpbmRvdywgImdyZWNhcHRjaGEiLCB7DQogICAgICAgIGdldDogZnVuY3Rpb24gKCkgew0KICAgICAgICAgICAgcmV0dXJuIHJlY2FwdGNoYUluc3RhbmNlOw0KICAgICAgICB9LA0KICAgICAgICBzZXQ6IGZ1bmN0aW9uIChlKSB7DQogICAgICAgICAgICByZWNhcHRjaGFJbnN0YW5jZSA9IGU7DQogICAgICAgICAgICBtYW5hZ2VSZWNhcHRjaGFPYmooZSk7DQogICAgICAgICAgICBtYW5hZ2VFbnRlcnByaXNlT2JqKGUpOw0KICAgICAgICB9LA0KICAgIH0pOw0KICAgIGxldCBtYW5hZ2VSZWNhcHRjaGFPYmogPSBmdW5jdGlvbiAob2JqKSB7DQogICAgICAgIGlmICh3aW5kb3cuX19fZ3JlY2FwdGNoYV9jZmcgPT09IHVuZGVmaW5lZCkge3JldHVybjt9DQogICAgICAgIGxldCBvcmlnaW5hbEV4ZWN1dGVGdW5jOw0KICAgICAgICBsZXQgb3JpZ2luYWxSZXNldEZ1bmM7DQogICAgICAgIGlmIChvYmouZXhlY3V0ZSkgb3JpZ2luYWxFeGVjdXRlRnVuYyA9IG9iai5leGVjdXRlOw0KICAgICAgICBpZiAob2JqLnJlc2V0KSBvcmlnaW5hbFJlc2V0RnVuYyA9IG9iai5yZXNldDsNCiAgICAgICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KG9iaiwgImV4ZWN1dGUiLCB7DQogICAgICAgICAgICBnZXQ6IGZ1bmN0aW9uICgpIHsNCiAgICAgICAgICAgICAgICByZXR1cm4gYXN5bmMgZnVuY3Rpb24gKHNpdGVrZXksIG9wdGlvbnMpIHsNCiAgICAgICAgICAgICAgICAgICAgaWYgKCFvcHRpb25zKSB7DQogICAgICAgICAgICAgICAgICAgICAgICBpZiAoIWlzSW52aXNpYmxlKCkpIHsNCiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gYXdhaXQgb3JpZ2luYWxFeGVjdXRlRnVuYyhzaXRla2V5LCBvcHRpb25zKTsNCiAgICAgICAgICAgICAgICAgICAgICAgIH0NCiAgICAgICAgICAgICAgICAgICAgfQ0KICAgICAgICAgICAgICAgICAgICBsZXQgY29uZmlnID0gYXdhaXQgc2VuZE1zZ1RvU29sdmVyQ1MoImdldENvbmZpZyIpOw0KICAgICAgICAgICAgICAgICAgICByZXR1cm4gYXdhaXQgb3JpZ2luYWxFeGVjdXRlRnVuYyhzaXRla2V5LCBvcHRpb25zKTsNCiAgICAgICAgICAgICAgICAgICAgbGV0IHdpZGdldElkID0gYWRkV2lkZ2V0SW5mbyhzaXRla2V5LCBvcHRpb25zKTsNCiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGF3YWl0IHdhaXRGb3JSZXN1bHQod2lkZ2V0SWQpOw0KICAgICAgICAgICAgICAgIH07DQogICAgICAgICAgICB9LA0KICAgICAgICAgICAgc2V0OiBmdW5jdGlvbiAoZSkgew0KICAgICAgICAgICAgICAgIG9yaWdpbmFsRXhlY3V0ZUZ1bmMgPSBlOw0KICAgICAgICAgICAgfSwNCiAgICAgICAgfSk7DQogICAgICAgIE9iamVjdC5kZWZpbmVQcm9wZXJ0eShvYmosICJyZXNldCIsIHsNCiAgICAgICAgICAgIGdldDogZnVuY3Rpb24gKCkgew0KICAgICAgICAgICAgICAgIHJldHVybiBmdW5jdGlvbiAod2lkZ2V0SWQpIHsNCiAgICAgICAgICAgICAgICAgICAgaWYgKHdpZGdldElkID09PSB1bmRlZmluZWQpIHsNCiAgICAgICAgICAgICAgICAgICAgICAgIGxldCBpZHMgPSBPYmplY3Qua2V5cyhfX19ncmVjYXB0Y2hhX2NmZy5jbGllbnRzKVswXTsNCiAgICAgICAgICAgICAgICAgICAgICAgIHdpZGdldElkID0gaWRzLmxlbmd0aCA/IGlkc1swXSA6IDA7DQogICAgICAgICAgICAgICAgICAgIH0NCiAgICAgICAgICAgICAgICAgICAgcmVzZXRDYXB0Y2hhV2lkZ2V0KCJyZWNhcHRjaGEiLCB3aWRnZXRJZCk7DQogICAgICAgICAgICAgICAgICAgIHJldHVybiBvcmlnaW5hbFJlc2V0RnVuYyh3aWRnZXRJZCk7DQogICAgICAgICAgICAgICAgfTsNCiAgICAgICAgICAgIH0sDQogICAgICAgICAgICBzZXQ6IGZ1bmN0aW9uIChlKSB7DQogICAgICAgICAgICAgICAgb3JpZ2luYWxSZXNldEZ1bmMgPSBlOw0KICAgICAgICAgICAgfSwNCiAgICAgICAgfSk7DQogICAgfTsNCiAgICBsZXQgbWFuYWdlRW50ZXJwcmlzZU9iaiA9IGZ1bmN0aW9uIChvYmopIHsNCiAgICAgICAgaWYgKHdpbmRvdy5fX19ncmVjYXB0Y2hhX2NmZyA9PT0gdW5kZWZpbmVkKSB7cmV0dXJuO30NCiAgICAgICAgbGV0IG9yaWdpbmFsRW50ZXJwcmlzZU9iajsNCiAgICAgICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KG9iaiwgImVudGVycHJpc2UiLCB7DQogICAgICAgICAgICBnZXQ6IGZ1bmN0aW9uICgpIHsNCiAgICAgICAgICAgICAgICByZXR1cm4gb3JpZ2luYWxFbnRlcnByaXNlT2JqOw0KICAgICAgICAgICAgfSwNCiAgICAgICAgICAgIHNldDogZnVuY3Rpb24gKGVudCkgew0KICAgICAgICAgICAgICAgIG9yaWdpbmFsRW50ZXJwcmlzZU9iaiA9IGVudDsNCiAgICAgICAgICAgICAgICBsZXQgb3JpZ2luYWxFeGVjdXRlRnVuYzsNCiAgICAgICAgICAgICAgICBsZXQgb3JpZ2luYWxSZXNldEZ1bmM7DQogICAgICAgICAgICAgICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KGVudCwgImV4ZWN1dGUiLCB7DQogICAgICAgICAgICAgICAgICAgIGdldDogZnVuY3Rpb24gKCkgew0KICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGFzeW5jIGZ1bmN0aW9uIChzaXRla2V5LCBvcHRpb25zKSB7DQogICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKCFvcHRpb25zKSB7DQogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICghaXNJbnZpc2libGUoKSkgew0KICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGF3YWl0IG9yaWdpbmFsRXhlY3V0ZUZ1bmMoc2l0ZWtleSwgb3B0aW9ucyk7DQogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0NCiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9DQogICAgICAgICAgICAgICAgICAgICAgICAgICAgbGV0IGNvbmZpZyA9IGF3YWl0IHNlbmRNc2dUb1NvbHZlckNTKCJnZXRDb25maWciKTsNCiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gYXdhaXQgb3JpZ2luYWxFeGVjdXRlRnVuYyhzaXRla2V5LCBvcHRpb25zKTsNCiAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgd2lkZ2V0SWQgPSBhZGRXaWRnZXRJbmZvKHNpdGVrZXksIG9wdGlvbnMsICIxIik7DQogICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGF3YWl0IHdhaXRGb3JSZXN1bHQod2lkZ2V0SWQpOw0KICAgICAgICAgICAgICAgICAgICAgICAgfTsNCiAgICAgICAgICAgICAgICAgICAgfSwNCiAgICAgICAgICAgICAgICAgICAgc2V0OiBmdW5jdGlvbiAoZSkgew0KICAgICAgICAgICAgICAgICAgICAgICAgb3JpZ2luYWxFeGVjdXRlRnVuYyA9IGU7DQogICAgICAgICAgICAgICAgICAgIH0sDQogICAgICAgICAgICAgICAgfSk7DQogICAgICAgICAgICAgICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KGVudCwgInJlc2V0Iiwgew0KICAgICAgICAgICAgICAgICAgICBnZXQ6IGZ1bmN0aW9uICgpIHsNCiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBmdW5jdGlvbiAod2lkZ2V0SWQpIHsNCiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAod2lkZ2V0SWQgPT09IHVuZGVmaW5lZCkgew0KICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgaWRzID0gT2JqZWN0LmtleXMoX19fZ3JlY2FwdGNoYV9jZmcuY2xpZW50cylbMF07DQogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHdpZGdldElkID0gaWRzLmxlbmd0aCA/IGlkc1swXSA6IDA7DQogICAgICAgICAgICAgICAgICAgICAgICAgICAgfQ0KICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlc2V0Q2FwdGNoYVdpZGdldCgicmVjYXB0Y2hhIiwgd2lkZ2V0SWQpOw0KICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBvcmlnaW5hbFJlc2V0RnVuYyh3aWRnZXRJZCk7DQogICAgICAgICAgICAgICAgICAgICAgICB9Ow0KICAgICAgICAgICAgICAgICAgICB9LA0KICAgICAgICAgICAgICAgICAgICBzZXQ6IGZ1bmN0aW9uIChlKSB7DQogICAgICAgICAgICAgICAgICAgICAgICBvcmlnaW5hbFJlc2V0RnVuYyA9IGU7DQogICAgICAgICAgICAgICAgICAgIH0sDQogICAgICAgICAgICAgICAgfSk7DQogICAgICAgICAgICB9LA0KICAgICAgICB9KTsNCiAgICB9Ow0KICAgIGxldCBhZGRXaWRnZXRJbmZvID0gZnVuY3Rpb24gKHNpdGVrZXksIG9wdGlvbnMsIGVudGVycHJpc2UpIHsNCiAgICAgICAgbGV0IHdpZGdldElkID0gcGFyc2VJbnQoRGF0ZS5ub3coKSAvIDEwMDApOw0KICAgICAgICBsZXQgYmFkZ2UgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKCIuZ3JlY2FwdGNoYS1iYWRnZSIpOw0KICAgICAgICBpZiAoIWJhZGdlLmlkKSBiYWRnZS5pZCA9ICJyZWNhcHRjaGEtYmFkZ2UtIiArIHdpZGdldElkOw0KICAgICAgICBsZXQgY2FsbGJhY2sgPSAicnYzRXhlY0NhbGxiYWNrIiArIHdpZGdldElkOw0KICAgICAgICB3aW5kb3dbY2FsbGJhY2tdID0gZnVuY3Rpb24gKHJlc3BvbnNlKSB7DQogICAgICAgICAgICBnZXRDYXB0Y2hhV2lkZ2V0QnV0dG9uKCJyZWNhcHRjaGEiLCB3aWRnZXRJZCkuZGF0YXNldC5yZXNwb25zZSA9IHJlc3BvbnNlOw0KICAgICAgICB9Ow0KICAgICAgICBsZXQgd2lkZ2V0SW5mbyA9IHsNCiAgICAgICAgICAgIGNhcHRjaGFUeXBlOiAicmVjYXB0Y2hhIiwNCiAgICAgICAgICAgIHdpZGdldElkOiB3aWRnZXRJZCwNCiAgICAgICAgICAgIHZlcnNpb246ICJ2MyIsDQogICAgICAgICAgICBzaXRla2V5OiBzaXRla2V5LA0KICAgICAgICAgICAgYWN0aW9uOiBvcHRpb25zID8gb3B0aW9ucy5hY3Rpb24gOiAnJywNCiAgICAgICAgICAgIHM6IG51bGwsDQogICAgICAgICAgICBlbnRlcnByaXNlOiBlbnRlcnByaXNlID8gdHJ1ZSA6IGZhbHNlLA0KICAgICAgICAgICAgY2FsbGJhY2s6IGNhbGxiYWNrLA0KICAgICAgICAgICAgY29udGFpbmVySWQ6IGJhZGdlLmlkLA0KICAgICAgICB9Ow0KICAgICAgICB3aW5kb3cud2lkZ2V0SW5mb3JldGhyZWUgPSB3aWRnZXRJbmZvOw0KICAgICAgICByZXR1cm4gd2lkZ2V0SWQ7DQogICAgfTsNCiAgICBsZXQgd2FpdEZvclJlc3VsdCA9IGZ1bmN0aW9uICh3aWRnZXRJZCkgew0KICAgICAgICByZXR1cm4gbmV3IFByb21pc2UoZnVuY3Rpb24gKHJlc29sdmUsIHJlamVjdCkgew0KICAgICAgICAgICAgbGV0IGludGVydmFsID0gc2V0SW50ZXJ2YWwoZnVuY3Rpb24gKCkgew0KICAgICAgICAgICAgICAgIGxldCBidXR0b24gPSBnZXRDYXB0Y2hhV2lkZ2V0QnV0dG9uKCJyZWNhcHRjaGEiLCB3aWRnZXRJZCk7DQoNCiAgICAgICAgICAgICAgICBpZiAoYnV0dG9uICYmIGJ1dHRvbi5kYXRhc2V0LnJlc3BvbnNlKSB7DQogICAgICAgICAgICAgICAgICAgIHJlc29sdmUoYnV0dG9uLmRhdGFzZXQucmVzcG9uc2UpOw0KICAgICAgICAgICAgICAgICAgICBjbGVhckludGVydmFsKGludGVydmFsKTsNCiAgICAgICAgICAgICAgICB9DQogICAgICAgICAgICB9LCA1MDApOw0KICAgICAgICB9KTsNCiAgICB9Ow0KICAgIGxldCBpc0ludmlzaWJsZSA9IGZ1bmN0aW9uICgpIHsNCiAgICAgICAgbGV0IHdpZGdldHMgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yQWxsKCdoZWFkIGNhcHRjaGEtd2lkZ2V0Jyk7DQogICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgd2lkZ2V0cy5sZW5ndGg7IGkrKykgew0KICAgICAgICAgICAgaWYgKHdpZGdldHNbaV0uZGF0YXNldC52ZXJzaW9uID09ICd2Ml9pbnZpc2libGUnKSB7DQogICAgICAgICAgICAgICAgbGV0IGJhZGdlID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcignLmdyZWNhcHRjaGEtYmFkZ2UnKTsNCiAgICAgICAgICAgICAgICBiYWRnZS5pZCA9ICJyZWNhcHRjaGEtYmFkZ2UtIiArIHdpZGdldHNbaV0uZGF0YXNldC53aWRnZXRJZDsNCiAgICAgICAgICAgICAgICB3aWRnZXRzW2ldLmRhdGFzZXQuY29udGFpbmVySWQgPSBiYWRnZS5pZDsNCiAgICAgICAgICAgICAgICByZXR1cm4gdHJ1ZTsNCiAgICAgICAgICAgIH0NCiAgICAgICAgfQ0KICAgICAgICByZXR1cm4gZmFsc2U7DQogICAgfTsNCn0pKCk="
         

         
         
         var json = JSON.parse(native("filesystem", "fileinfo", VAR_PROJECT_DIRECTORY + "/CaptchaAutoSolver/content/recaptcha/interceptor.js"))
         VAR_FILEINFO_EXISTS = json["exists"]
         VAR_1 = json["size"]
         VAR_1 = json["directory"]
         VAR_1 = json["is_directory"]
         VAR_1 = new Date(json["last_modified"] * 1000)
         

         
         
         _cycle_params().if_else = VAR_FILEINFO_EXISTS == false;
         _set_if_expression("W1tGSUxFSU5GT19FWElTVFNdXSA9PSBmYWxzZQ==");
         _if(_cycle_params().if_else,function(){
         
            
            
            native("filesystem", "writefile", JSON.stringify({path: VAR_PROJECT_DIRECTORY + "/CaptchaAutoSolver/content/recaptcha/interceptor.js",value: (VAR_TEMP_DATA).toString(),base64:true,append:false}))
            

         })!
         

         
         
         _if(!_cycle_params().if_else,function(){
         
            
            
            VAR_FILE_CONTENT = native("filesystem", "readfile", JSON.stringify({value: VAR_PROJECT_DIRECTORY + "/CaptchaAutoSolver/content/recaptcha/interceptor.js",base64:true,from:0,to:0}))
            

            
            
            _set_if_expression("W1tGSUxFX0NPTlRFTlRdXSAhPSBbW1RFTVBfREFUQV1d");
            _if(VAR_FILE_CONTENT != VAR_TEMP_DATA,function(){
            
               
               
               native("filesystem", "writefile", JSON.stringify({path: VAR_PROJECT_DIRECTORY + "/CaptchaAutoSolver/content/recaptcha/interceptor.js",value: (VAR_TEMP_DATA).toString(),base64:true,append:false}))
               

            })!
            

         })!
         delete _cycle_params().if_else;
         

      })!
      

   }
   

function GoodXevilPaySolver_GXP_ReCaptchav2TakeToken()
   {
   
      
      
      VAR_APIKEY = _function_argument("APIKEY")
      

      
      
      VAR_SITE_URL = _function_argument("site_url")
      

      
      
      VAR_SITEKEY = _function_argument("sitekey")
      

      
      
      var regexp_result = native("regexp", "first", JSON.stringify({text: VAR_APIKEY,regexp:"([0-9A-Za-z]\u007b20,40\u007d)"}))
      if(regexp_result.length == 0)
      regexp_result = []
      else
      regexp_result = JSON.parse(regexp_result)
      VAR_ALL_MATCH = regexp_result.pop()
      if(typeof(VAR_ALL_MATCH) == 'undefined' || !VAR_ALL_MATCH)
      VAR_ALL_MATCH = ""
      VAR_APIKEY = regexp_result[0]
      if(typeof(VAR_APIKEY) == 'undefined' || !VAR_APIKEY)
      VAR_APIKEY = ""
      if(regexp_result.length == 0)
      {
      VAR_APIKEY = VAR_ALL_MATCH
      }
      

      
      
      solver_properties_clear("capmonster")
      solver_property("capmonster","serverurl","http://goodxevilpay.pp.ua")
      solver_property("capmonster","key",VAR_APIKEY)
      solver_property("capmonster","method","userrecaptcha")
      solver_property("capmonster","pageurl",VAR_SITE_URL)
      solver_property("capmonster","googlekey",VAR_SITEKEY)
      solve_base64_no_fail("capmonster", "")!
      VAR_SAVED_CONTENT = _result();
      

      
      
      _function_return(VAR_SAVED_CONTENT)
      

   }
   

function GoodXevilPaySolver_GXP_HcaptchaAutoSolver()
   {
   
      
      
      VAR_APIKEY = _function_argument("apikey")
      

      
      
      var regexp_result = native("regexp", "first", JSON.stringify({text: VAR_APIKEY,regexp:"([0-9A-Za-z]\u007b20,40\u007d)"}))
      if(regexp_result.length == 0)
      regexp_result = []
      else
      regexp_result = JSON.parse(regexp_result)
      VAR_ALL_MATCH = regexp_result.pop()
      if(typeof(VAR_ALL_MATCH) == 'undefined' || !VAR_ALL_MATCH)
      VAR_ALL_MATCH = ""
      VAR_APIKEY = regexp_result[0]
      if(typeof(VAR_APIKEY) == 'undefined' || !VAR_APIKEY)
      VAR_APIKEY = ""
      if(regexp_result.length == 0)
      {
      VAR_APIKEY = VAR_ALL_MATCH
      }
      

      
      
      VAR_TEMP_DATA2 = ""
      

      
      
      VAR_TEMP_DATA = ""
      

      
      
      _do(function(){
      _set_action_info({ name: "While" });
      VAR_CYCLE_INDEX = _iterator() - 1
      BREAK_CONDITION = VAR_TEMP_DATA == "";
      if(!BREAK_CONDITION)_break();
      
         
         
         _set_if_expression("W1tDWUNMRV9JTkRFWF1dICE9IDA=");
         _if(VAR_CYCLE_INDEX != 0,function(){
         
            
            
            sleep(500)!
            

         })!
         

         
         
         _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gMzA=");
         _if(VAR_CYCLE_INDEX > 30,function(){
         
            
            
            fail((_K==="en" ? "Hcaptcha is not detected on the page" : "Hcaptcha не обнаружена на странице"));
            

         })!
         

         
         
         _call(function()
         {
         _on_fail(function(){
         VAR_LAST_ERROR = _result()
         VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
         VAR_WAS_ERROR = false
         _break(1,true)
         })
         CYCLES.Current().RemoveLabel("function")
         
            
            
            page().script2("[[TEMP_DATA]] = window.captchaInfoh;",JSON.stringify(_read_variables(["VAR_TEMP_DATA"])))!
            var _parse_result = JSON.parse(_result())
            _write_variables(JSON.parse(_parse_result.variables))
            if(!_parse_result.is_success)
            fail(_parse_result.error)
            

         },null)!
         

         
         
         _set_if_expression("W1tURU1QX0RBVEFdXSA9PSAiIg==");
         _if(VAR_TEMP_DATA == "",function(){
         
            
            
            _call(function()
            {
            _on_fail(function(){
            VAR_LAST_ERROR = _result()
            VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
            VAR_WAS_ERROR = false
            _break(1,true)
            })
            CYCLES.Current().RemoveLabel("function")
            
               
               
               page().script2("[[TEMP_DATA2]] = window.captchaInfohtwo;",JSON.stringify(_read_variables(["VAR_TEMP_DATA2"])))!
               var _parse_result = JSON.parse(_result())
               _write_variables(JSON.parse(_parse_result.variables))
               if(!_parse_result.is_success)
               fail(_parse_result.error)
               

            },null)!
            

            
            
            _set_if_expression("W1tURU1QX0RBVEEyXV0gIT0gIiI=");
            _if(VAR_TEMP_DATA2 != "",function(){
            
               
               
               _call(function()
               {
               _on_fail(function(){
               VAR_LAST_ERROR = _result()
               VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
               VAR_WAS_ERROR = false
               _break(1,true)
               })
               CYCLES.Current().RemoveLabel("function")
               
                  
                  
                  page().script2("[[TEMP_DATA]] = window.captchaInfoh;",JSON.stringify(_read_variables(["VAR_TEMP_DATA"])))!
                  var _parse_result = JSON.parse(_result())
                  _write_variables(JSON.parse(_parse_result.variables))
                  if(!_parse_result.is_success)
                  fail(_parse_result.error)
                  

               },null)!
               

               
               
               _set_if_expression("W1tURU1QX0RBVEFdXSA9PSAiIg==");
               _if(VAR_TEMP_DATA == "",function(){
               
                  
                  
                  VAR_TEMP_DATA = VAR_TEMP_DATA2
                  

               })!
               

            })!
            

         })!
         

      })!
      

      
      
      /*Browser*/
      url()!
      VAR_SITE_URL = _result()
      

      
      
      VAR_SAVED_CONTENT = "ERROR"
      

      
      
      _do(function(){
      _set_action_info({ name: "For" });
      VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(0)
      if(VAR_CYCLE_INDEX > parseInt(3))_break();
      
         
         
         _set_if_expression("W1tDWUNMRV9JTkRFWF1dID49IDI=");
         _if(VAR_CYCLE_INDEX >= 2,function(){
         
            
            
            fail((_K==="en" ? "Error when solving captcha: " + VAR_SAVED_CONTENT : "Ошибка при решении капчи: " + VAR_SAVED_CONTENT));
            

         })!
         

         
         
         _call(function()
         {
         _on_fail(function(){
         VAR_LAST_ERROR = _result()
         VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
         VAR_WAS_ERROR = false
         _break(1,true)
         })
         CYCLES.Current().RemoveLabel("function")
         
            
            
            solver_properties_clear("capmonster")
            solver_property("capmonster","serverurl","http://goodxevilpay.pp.ua")
            solver_property("capmonster","key",VAR_APIKEY)
            solver_property("capmonster","method","hcaptcha")
            solver_property("capmonster","pageurl",VAR_SITE_URL)
            solver_property("capmonster","sitekey",VAR_TEMP_DATA["sitekey"])
            solve_base64_no_fail("capmonster", "")!
            VAR_SAVED_CONTENT = _result();
            

         },null)!
         

         
         
         VAR_STRING_MATCHES = Boolean(native("regexp", "ismatch", JSON.stringify({text: VAR_SAVED_CONTENT,regexp:"(ERROR)"})) == "true")
         

         
         
         VAR_STRING_MATCHES2 = Boolean(native("regexp", "ismatch", JSON.stringify({text: VAR_SAVED_CONTENT,regexp:"(_FAIL)"})) == "true")
         

         
         
         _set_if_expression("W1tTVFJJTkdfTUFUQ0hFU11dIHx8IFtbU1RSSU5HX01BVENIRVMyXV0=");
         _if(VAR_STRING_MATCHES || VAR_STRING_MATCHES2,function(){
         
            
            
            sleep(1000)!
            

            
            
            _next("function")
            

         })!
         

         
         
         _break("function")
         

      })!
      

      
      
      VAR_ERROR_ID = 0
      

      
      
      _call(function()
      {
      _on_fail(function(){
      VAR_LAST_ERROR = _result()
      VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
      VAR_WAS_ERROR = false
      _break(1,true)
      })
      CYCLES.Current().RemoveLabel("function")
      
         
         
         page().script2("let container = document.querySelector('#'+window.captchaInfohtwo.containerId);\r\n  for(let area of container.querySelectorAll(\"textarea\")){\r\n    area.value = [[SAVED_CONTENT]];\r\n  }\r\n  for(let frame of container.querySelectorAll(\"iframe\")){\r\n    frame.setAttribute(\"data-hcaptcha-response\", [[SAVED_CONTENT]]);\r\n  }\r\n  if(window.captchaInfohtwo.callback != null){\r\n    let textarea = document.createElement('textarea');\r\n    textarea.id = 'callback-trigger';\r\n    textarea.setAttribute('data-function', window.captchaInfohtwo.callback);\r\n    textarea.value = [[SAVED_CONTENT]];\r\n    document.body.appendChild(textarea);\r\n    textarea = document.querySelector('textarea[id=callback-trigger]');\r\n    let func = textarea.getAttribute('data-function');\r\n    let data = textarea.value;\r\n    textarea.remove();\r\n    window[func](data);\r\n  }",JSON.stringify(_read_variables(["VAR_SAVED_CONTENT"])))!
         var _parse_result = JSON.parse(_result())
         _write_variables(JSON.parse(_parse_result.variables))
         if(!_parse_result.is_success)
         fail(_parse_result.error)
         

      },null)!
      

      
      
      _set_if_expression("W1tXQVNfRVJST1JdXQ==");
      _if(typeof(VAR_WAS_ERROR) !== "undefined" ? (VAR_WAS_ERROR) : undefined,function(){
      
         
         
         VAR_ERROR_ID = parseInt(VAR_ERROR_ID) + parseInt(1)
         

      })!
      

      
      
      _call(function()
      {
      _on_fail(function(){
      VAR_LAST_ERROR = _result()
      VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
      VAR_WAS_ERROR = false
      _break(1,true)
      })
      CYCLES.Current().RemoveLabel("function")
      
         
         
         page().script2("let container = document.querySelector('#'+window.captchaInfoh.containerId);\r\n  for(let area of container.querySelectorAll(\"textarea\")){\r\n    area.value = [[SAVED_CONTENT]];\r\n  }\r\n  for(let frame of container.querySelectorAll(\"iframe\")){\r\n    frame.setAttribute(\"data-hcaptcha-response\", [[SAVED_CONTENT]]);\r\n  }\r\n  if(window.captchaInfoh.callback != null){\r\n    let textarea = document.createElement('textarea');\r\n    textarea.id = 'callback-trigger';\r\n    textarea.setAttribute('data-function', window.captchaInfoh.callback);\r\n    textarea.value = [[SAVED_CONTENT]];\r\n    document.body.appendChild(textarea);\r\n    textarea = document.querySelector('textarea[id=callback-trigger]');\r\n    let func = textarea.getAttribute('data-function');\r\n    let data = textarea.value;\r\n    textarea.remove();\r\n    window[func](data);\r\n  }",JSON.stringify(_read_variables(["VAR_SAVED_CONTENT"])))!
         var _parse_result = JSON.parse(_result())
         _write_variables(JSON.parse(_parse_result.variables))
         if(!_parse_result.is_success)
         fail(_parse_result.error)
         

      },null)!
      

      
      
      _call(function()
      {
      _on_fail(function(){
      VAR_LAST_ERROR = _result()
      VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
      VAR_WAS_ERROR = false
      _break(1,true)
      })
      CYCLES.Current().RemoveLabel("function")
      
         
         
         _set_if_expression("ZmFsc2U=");
         _if(false,function(){
         
            
            
            page().script2("var xpath = '//textarea[@name=\"g-recaptcha-response\"]';\r\nvar result = document.evaluate(xpath, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null);\r\nvar element = result.singleNodeValue;\r\n\r\nif (element) {\r\n  element.innerText = [[SAVED_CONTENT]];\r\n}\r\n\r\nvar xpath = '//textarea[@name=\"h-captcha-response\"]';\r\nvar result = document.evaluate(xpath, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null);\r\nvar element = result.singleNodeValue;\r\n\r\nif (element) {\r\n  element.innerText = [[SAVED_CONTENT]];\r\n}\r\n",JSON.stringify(_read_variables(["VAR_SAVED_CONTENT"])))!
            var _parse_result = JSON.parse(_result())
            _write_variables(JSON.parse(_parse_result.variables))
            if(!_parse_result.is_success)
            fail(_parse_result.error)
            

         })!
         

      },null)!
      

      
      
      _set_if_expression("W1tXQVNfRVJST1JdXQ==");
      _if(typeof(VAR_WAS_ERROR) !== "undefined" ? (VAR_WAS_ERROR) : undefined,function(){
      
         
         
         VAR_ERROR_ID = parseInt(VAR_ERROR_ID) + parseInt(1)
         

      })!
      

      
      
      _set_if_expression("W1tFUlJPUl9JRF1dID09IDI=");
      _if(VAR_ERROR_ID == 2,function(){
      
         
         
         fail((_K==="en" ? "Hcaptcha is not solved" : "Hcaptcha не решена"));
         

      })!
      

   }
   

function GoodXevilPaySolver_GXP_HcaptchaTakeToken()
   {
   
      
      
      VAR_APIKEY = _function_argument("APIKEY")
      

      
      
      VAR_SITE_URL = _function_argument("site_url")
      

      
      
      VAR_SITEKEY = _function_argument("sitekey")
      

      
      
      var regexp_result = native("regexp", "first", JSON.stringify({text: VAR_APIKEY,regexp:"([0-9A-Za-z]\u007b20,40\u007d)"}))
      if(regexp_result.length == 0)
      regexp_result = []
      else
      regexp_result = JSON.parse(regexp_result)
      VAR_ALL_MATCH = regexp_result.pop()
      if(typeof(VAR_ALL_MATCH) == 'undefined' || !VAR_ALL_MATCH)
      VAR_ALL_MATCH = ""
      VAR_APIKEY = regexp_result[0]
      if(typeof(VAR_APIKEY) == 'undefined' || !VAR_APIKEY)
      VAR_APIKEY = ""
      if(regexp_result.length == 0)
      {
      VAR_APIKEY = VAR_ALL_MATCH
      }
      

      
      
      solver_properties_clear("capmonster")
      solver_property("capmonster","serverurl","http://goodxevilpay.pp.ua")
      solver_property("capmonster","key",VAR_APIKEY)
      solver_property("capmonster","method","hcaptcha")
      solver_property("capmonster","pageurl",VAR_SITE_URL)
      solver_property("capmonster","sitekey",VAR_SITEKEY)
      solve_base64_no_fail("capmonster", "")!
      VAR_SAVED_CONTENT = _result();
      

      
      
      _function_return(VAR_SAVED_CONTENT)
      

   }
   

function GoodXevilPaySolver_GXP_GetBalance()
   {
   
      
      
      VAR_APIKEY = _function_argument("APIKEY")
      

      
      
      var regexp_result = native("regexp", "first", JSON.stringify({text: VAR_APIKEY,regexp:"([0-9A-Za-z]\u007b20,40\u007d)"}))
      if(regexp_result.length == 0)
      regexp_result = []
      else
      regexp_result = JSON.parse(regexp_result)
      VAR_ALL_MATCH = regexp_result.pop()
      if(typeof(VAR_ALL_MATCH) == 'undefined' || !VAR_ALL_MATCH)
      VAR_ALL_MATCH = ""
      VAR_APIKEY = regexp_result[0]
      if(typeof(VAR_APIKEY) == 'undefined' || !VAR_APIKEY)
      VAR_APIKEY = ""
      if(regexp_result.length == 0)
      {
      VAR_APIKEY = VAR_ALL_MATCH
      }
      

      
      
      _switch_http_client_main()
      http_client_get2("http://goodxevilpay.pp.ua/res.php?action=getbalance\u0026key=" + VAR_APIKEY,{method:("GET"),headers:("")})!
      

      
      
      _switch_http_client_main()
      VAR_SAVED_CONTENT = http_client_encoded_content("utf-8")
      

      
      
      _set_if_expression("W1tTQVZFRF9DT05URU5UXV0ubGVuZ3RoID09IDA=");
      _if(VAR_SAVED_CONTENT.length == 0,function(){
      
         
         
         fail((_K==="en" ? "Couldn't figure out the balance" : "Не получилось узнать баланс"));
         

      })!
      

      
      
      _function_return(VAR_SAVED_CONTENT)
      

   }
   

