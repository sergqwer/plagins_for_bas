var mudexzov = GetInputConstructorValue("mudexzov", loader);
                 if(mudexzov["original"].length == 0)
                 {
                   Invalid("arrow_id" + " is empty");
                   return;
                 }
var omgnwpug = GetInputConstructorValue("omgnwpug", loader);
                 if(omgnwpug["original"].length == 0)
                 {
                   Invalid("avtoupdate" + " is empty");
                   return;
                 }
var xidliuii = GetInputConstructorValue("xidliuii", loader);
                 if(xidliuii["original"].length == 0)
                 {
                   Invalid("button_id" + " is empty");
                   return;
                 }
var uzkshpow = GetInputConstructorValue("uzkshpow", loader);
                 if(uzkshpow["original"].length == 0)
                 {
                   Invalid("coef" + " is empty");
                   return;
                 }
var arkxcqts = GetInputConstructorValue("arkxcqts", loader);
                 if(arkxcqts["original"].length == 0)
                 {
                   Invalid("image id" + " is empty");
                   return;
                 }
var dulvkhup = GetInputConstructorValue("dulvkhup", loader);
                 if(dulvkhup["original"].length == 0)
                 {
                   Invalid("key" + " is empty");
                   return;
                 }
var yvhbitpw = GetInputConstructorValue("yvhbitpw", loader);
                 if(yvhbitpw["original"].length == 0)
                 {
                   Invalid("pixel_koef" + " is empty");
                   return;
                 }
var vvqizjlc = GetInputConstructorValue("vvqizjlc", loader);
                 if(vvqizjlc["original"].length == 0)
                 {
                   Invalid("reload_id" + " is empty");
                   return;
                 }
var sdielvxo = GetInputConstructorValue("sdielvxo", loader);
                 if(sdielvxo["original"].length == 0)
                 {
                   Invalid("speed" + " is empty");
                   return;
                 }
var jvanmier = GetInputConstructorValue("jvanmier", loader);
                 if(jvanmier["original"].length == 0)
                 {
                   Invalid("type_slide" + " is empty");
                   return;
                 }
var pdpllbgp = GetInputConstructorValue("pdpllbgp", loader);
                 if(pdpllbgp["original"].length == 0)
                 {
                   Invalid("type_swipe" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SliderSolver_code").html())({"mudexzov": mudexzov["updated"],"omgnwpug": omgnwpug["updated"],"xidliuii": xidliuii["updated"],"uzkshpow": uzkshpow["updated"],"arkxcqts": arkxcqts["updated"],"dulvkhup": dulvkhup["updated"],"yvhbitpw": yvhbitpw["updated"],"vvqizjlc": vvqizjlc["updated"],"sdielvxo": sdielvxo["updated"],"jvanmier": jvanmier["updated"],"pdpllbgp": pdpllbgp["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
