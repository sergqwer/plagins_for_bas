var ckjhtant = GetInputConstructorValue("ckjhtant", loader);
                 if(ckjhtant["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var avtmngzv = GetInputConstructorValue("avtmngzv", loader);
                 if(avtmngzv["original"].length == 0)
                 {
                   Invalid("mouse" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_Antibot_code").html())({"ckjhtant": ckjhtant["updated"],"avtmngzv": avtmngzv["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
