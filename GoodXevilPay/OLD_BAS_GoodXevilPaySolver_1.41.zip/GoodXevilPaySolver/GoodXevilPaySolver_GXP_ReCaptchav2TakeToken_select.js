var ixxypntf = GetInputConstructorValue("ixxypntf", loader);
                 if(ixxypntf["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var wfewbajq = GetInputConstructorValue("wfewbajq", loader);
                 if(wfewbajq["original"].length == 0)
                 {
                   Invalid("site_url" + " is empty");
                   return;
                 }
var gbdybena = GetInputConstructorValue("gbdybena", loader);
                 if(gbdybena["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_ReCaptchav2TakeToken_code").html())({"ixxypntf": ixxypntf["updated"],"wfewbajq": wfewbajq["updated"],"gbdybena": gbdybena["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
