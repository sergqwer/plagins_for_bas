_call_function(GoodXevilPaySolver_GXP_IMAGE_BASE64,{ "APIKEY": (<%= htvvvnhy %>),"IMAGE_BASE64": (<%= wsqjfyhy %>) })!
<%= variable %> = _result_function()
