var qdwjfpuq = GetInputConstructorValue("qdwjfpuq", loader);
                 if(qdwjfpuq["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_ProtonMail_code").html())({"qdwjfpuq": qdwjfpuq["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
