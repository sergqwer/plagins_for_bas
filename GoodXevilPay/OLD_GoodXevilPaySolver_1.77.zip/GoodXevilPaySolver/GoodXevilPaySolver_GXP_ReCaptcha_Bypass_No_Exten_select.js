var qtysfcxx = GetInputConstructorValue("qtysfcxx", loader);
                 if(qtysfcxx["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var wofkenjz = GetInputConstructorValue("wofkenjz", loader);
                 if(wofkenjz["original"].length == 0)
                 {
                   Invalid("enterprise" + " is empty");
                   return;
                 }
var daxgvpem = GetInputConstructorValue("daxgvpem", loader);
                 if(daxgvpem["original"].length == 0)
                 {
                   Invalid("index" + " is empty");
                   return;
                 }
var kcivdcpx = GetInputConstructorValue("kcivdcpx", loader);
                 if(kcivdcpx["original"].length == 0)
                 {
                   Invalid("invisible" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_ReCaptcha_Bypass_No_Exten_code").html())({"qtysfcxx": qtysfcxx["updated"],"wofkenjz": wofkenjz["updated"],"daxgvpem": daxgvpem["updated"],"kcivdcpx": kcivdcpx["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
