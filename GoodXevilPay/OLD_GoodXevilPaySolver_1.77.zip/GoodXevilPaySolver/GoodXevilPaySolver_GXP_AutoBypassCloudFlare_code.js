_call_function(GoodXevilPaySolver_GXP_AutoBypassCloudFlare,{ "custom_button": (<%= yfwedfvc %>),"max_time": (<%= ffuibeug %>),"whait_element": (<%= rydneqiu %>) })!
