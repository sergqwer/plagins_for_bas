var thwyoiff = GetInputConstructorValue("thwyoiff", loader);
                 if(thwyoiff["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var bnuegsis = GetInputConstructorValue("bnuegsis", loader);
                 if(bnuegsis["original"].length == 0)
                 {
                   Invalid("images_button" + " is empty");
                   return;
                 }
var xawtrwhx = GetInputConstructorValue("xawtrwhx", loader);
                 if(xawtrwhx["original"].length == 0)
                 {
                   Invalid("reload_button" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_GeeTestImages_code").html())({"thwyoiff": thwyoiff["updated"],"bnuegsis": bnuegsis["updated"],"xawtrwhx": xawtrwhx["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
