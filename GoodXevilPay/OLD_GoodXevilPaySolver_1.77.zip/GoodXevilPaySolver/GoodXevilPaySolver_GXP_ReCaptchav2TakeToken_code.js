_call_function(GoodXevilPaySolver_GXP_ReCaptchav2TakeToken,{ "APIKEY": (<%= whzdyozu %>),"site_url": (<%= tmfplnld %>),"sitekey": (<%= iicjyoll %>) })!
<%= variable %> = _result_function()
