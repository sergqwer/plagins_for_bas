var orweftdn = GetInputConstructorValue("orweftdn", loader);
                 if(orweftdn["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var ujfmtgyn = GetInputConstructorValue("ujfmtgyn", loader);
                 if(ujfmtgyn["original"].length == 0)
                 {
                   Invalid("CaptchaSelector" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_Yandex_code").html())({"orweftdn": orweftdn["updated"],"ujfmtgyn": ujfmtgyn["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
