var speghuxp = GetInputConstructorValue("speghuxp", loader);
                 if(speghuxp["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var tqcahpuz = GetInputConstructorValue("tqcahpuz", loader);
                 if(tqcahpuz["original"].length == 0)
                 {
                   Invalid("arab_fix" + " is empty");
                   return;
                 }
var michyusx = GetInputConstructorValue("michyusx", loader);
                 if(michyusx["original"].length == 0)
                 {
                   Invalid("captcha_submit" + " is empty");
                   return;
                 }
var orpljvea = GetInputConstructorValue("orpljvea", loader);
                 if(orpljvea["original"].length == 0)
                 {
                   Invalid("foto_captcha" + " is empty");
                   return;
                 }
var viygahto = GetInputConstructorValue("viygahto", loader);
                 if(viygahto["original"].length == 0)
                 {
                   Invalid("pixel_coef" + " is empty");
                   return;
                 }
var lzivwaag = GetInputConstructorValue("lzivwaag", loader);
                 if(lzivwaag["original"].length == 0)
                 {
                   Invalid("reload_captcha" + " is empty");
                   return;
                 }
var vctispir = GetInputConstructorValue("vctispir", loader);
                 if(vctispir["original"].length == 0)
                 {
                   Invalid("type_data" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SolverGeetestIcon_code").html())({"speghuxp": speghuxp["updated"],"tqcahpuz": tqcahpuz["updated"],"michyusx": michyusx["updated"],"orpljvea": orpljvea["updated"],"viygahto": viygahto["updated"],"lzivwaag": lzivwaag["updated"],"vctispir": vctispir["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
