var dfzpbabl = GetInputConstructorValue("dfzpbabl", loader);
                 if(dfzpbabl["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_HcaptchaAutoSolver_code").html())({"dfzpbabl": dfzpbabl["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
