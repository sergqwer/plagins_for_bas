<div class="container-fluid">
<%= _.template($('#input_constructor').html())({id:"thwyoiff", description:"apikey", default_selector: "string", disable_int:true, value_string: "", help: {description: "apikey с сервиса https://t.me/Xevil_check_bot\n\napikey from https://t.me/Xevil_check_bot"} }) %>
<%= _.template($('#input_constructor').html())({id:"bnuegsis", description:"images_button", default_selector: "string", disable_int:true, value_string: " >CSS> .geetest_window", help: {description: "Идентификатор поля с картинками\n\nID of the field with pictures"} }) %>
<%= _.template($('#input_constructor').html())({id:"xawtrwhx", description:"reload_button", default_selector: "string", disable_expression:true, disable_int:true, value_string: " >CSS> .geetest_refresh", help: {description: "Идентификатор кнопки для обновления капчи\n\nIdentifier of the button to update captcha"} }) %>
</div>
<div class="tooltipinternal">
<div class="tr tooltip-paragraph-first-fold">Автоматически решает Geetest Images на странице</div>
<div class="tr tooltip-paragraph-last-fold">Automatically resolves the Geetest Images on the page</div>
</div>
<%= _.template($('#back').html())({action:"executeandadd", visible:true}) %>
