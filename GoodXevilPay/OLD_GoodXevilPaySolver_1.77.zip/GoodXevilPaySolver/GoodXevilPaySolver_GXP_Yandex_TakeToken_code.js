_call_function(GoodXevilPaySolver_GXP_Yandex_TakeToken,{ "apikey": (<%= qafdlscp %>),"pageurl": (<%= pqdeolij %>),"sitekey": (<%= jzeziasn %>) })!
<%= variable %> = _result_function()
