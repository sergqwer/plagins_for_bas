var yfwedfvc = GetInputConstructorValue("yfwedfvc", loader);
                 if(yfwedfvc["original"].length == 0)
                 {
                   Invalid("custom_button" + " is empty");
                   return;
                 }
var ffuibeug = GetInputConstructorValue("ffuibeug", loader);
                 if(ffuibeug["original"].length == 0)
                 {
                   Invalid("max_time" + " is empty");
                   return;
                 }
var rydneqiu = GetInputConstructorValue("rydneqiu", loader);
                 if(rydneqiu["original"].length == 0)
                 {
                   Invalid("whait_element" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_AutoBypassCloudFlare_code").html())({"yfwedfvc": yfwedfvc["updated"],"ffuibeug": ffuibeug["updated"],"rydneqiu": rydneqiu["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
