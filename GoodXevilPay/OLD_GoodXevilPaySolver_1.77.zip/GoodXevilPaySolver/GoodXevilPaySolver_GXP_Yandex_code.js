_call_function(GoodXevilPaySolver_GXP_Yandex,{ "apikey": (<%= orweftdn %>),"CaptchaSelector": (<%= ujfmtgyn %>) })!
