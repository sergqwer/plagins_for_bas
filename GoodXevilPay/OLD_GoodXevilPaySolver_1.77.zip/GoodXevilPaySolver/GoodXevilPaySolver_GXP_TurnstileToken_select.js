var mlelhlmx = GetInputConstructorValue("mlelhlmx", loader);
                 if(mlelhlmx["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var qxmloouh = GetInputConstructorValue("qxmloouh", loader);
                 if(qxmloouh["original"].length == 0)
                 {
                   Invalid("site_url" + " is empty");
                   return;
                 }
var pkjlofkj = GetInputConstructorValue("pkjlofkj", loader);
                 if(pkjlofkj["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_TurnstileToken_code").html())({"mlelhlmx": mlelhlmx["updated"],"qxmloouh": qxmloouh["updated"],"pkjlofkj": pkjlofkj["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
