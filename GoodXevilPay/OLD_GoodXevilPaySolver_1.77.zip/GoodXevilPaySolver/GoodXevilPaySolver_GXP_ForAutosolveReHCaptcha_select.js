var sszgjpgb = GetInputConstructorValue("sszgjpgb", loader);
                 if(sszgjpgb["original"].length == 0)
                 {
                   Invalid("hCaptcha_USE" + " is empty");
                   return;
                 }
var rhqcpbtw = GetInputConstructorValue("rhqcpbtw", loader);
                 if(rhqcpbtw["original"].length == 0)
                 {
                   Invalid("ReCaptcha_USE" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_ForAutosolveReHCaptcha_code").html())({"sszgjpgb": sszgjpgb["updated"],"rhqcpbtw": rhqcpbtw["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
