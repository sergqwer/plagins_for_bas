_call_function(GoodXevilPaySolver_GXP_AuthKongToken,{ "APIKEY": (<%= dtpwflwl %>),"site_url": (<%= irosujbo %>),"sitekey": (<%= bjaowyvu %>) })!
<%= variable %> = _result_function()
