var dtpwflwl = GetInputConstructorValue("dtpwflwl", loader);
                 if(dtpwflwl["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var irosujbo = GetInputConstructorValue("irosujbo", loader);
                 if(irosujbo["original"].length == 0)
                 {
                   Invalid("site_url" + " is empty");
                   return;
                 }
var bjaowyvu = GetInputConstructorValue("bjaowyvu", loader);
                 if(bjaowyvu["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_AuthKongToken_code").html())({"dtpwflwl": dtpwflwl["updated"],"irosujbo": irosujbo["updated"],"bjaowyvu": bjaowyvu["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
