_call_function(GoodXevilPaySolver_GXP_ReCaptcha_Bypass_No_Exten,{ "apikey": (<%= qtysfcxx %>),"enterprise": (<%= wofkenjz %>),"index": (<%= daxgvpem %>),"invisible": (<%= kcivdcpx %>) })!
<%= variable %> = _result_function()
