<div class="container-fluid">
<%= _.template($('#input_constructor').html())({id:"azuoejwh", description:"apikey", default_selector: "string", disable_expression:true, disable_int:true, value_string: "", help: {description: "apikey с сервиса https://t.me/Xevil_check_bot\n\napikey from https://t.me/Xevil_check_bot"} }) %>
</div>
<div class="tooltipinternal">
<div class="tr tooltip-paragraph-first-fold">Автоматически решает капчу при входе на сайтах viefaucet.com | coinpayz.xyz, для работы надо запустить функцию на странице с капчей</div>
<div class="tr tooltip-paragraph-last-fold">Automatically solves captcha when logging in to viefaucet.com | coinpayz.xyz, to work you need to run the function on the page with captcha.</div>
</div>
<%= _.template($('#back').html())({action:"executeandadd", visible:true}) %>
