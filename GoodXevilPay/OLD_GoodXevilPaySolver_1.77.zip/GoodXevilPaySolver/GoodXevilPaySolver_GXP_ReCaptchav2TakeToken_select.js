var whzdyozu = GetInputConstructorValue("whzdyozu", loader);
                 if(whzdyozu["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var tmfplnld = GetInputConstructorValue("tmfplnld", loader);
                 if(tmfplnld["original"].length == 0)
                 {
                   Invalid("site_url" + " is empty");
                   return;
                 }
var iicjyoll = GetInputConstructorValue("iicjyoll", loader);
                 if(iicjyoll["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_ReCaptchav2TakeToken_code").html())({"whzdyozu": whzdyozu["updated"],"tmfplnld": tmfplnld["updated"],"iicjyoll": iicjyoll["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
