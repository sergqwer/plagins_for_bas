_call_function(GoodXevilPaySolver_GXP_IMAGE_BASE64,{ "APIKEY": (<%= ptzzomgm %>),"IMAGE_BASE64": (<%= bgdzowly %>) })!
<%= variable %> = _result_function()
