var qafdlscp = GetInputConstructorValue("qafdlscp", loader);
                 if(qafdlscp["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var pqdeolij = GetInputConstructorValue("pqdeolij", loader);
                 if(pqdeolij["original"].length == 0)
                 {
                   Invalid("pageurl" + " is empty");
                   return;
                 }
var jzeziasn = GetInputConstructorValue("jzeziasn", loader);
                 if(jzeziasn["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_Yandex_TakeToken_code").html())({"qafdlscp": qafdlscp["updated"],"pqdeolij": pqdeolij["updated"],"jzeziasn": jzeziasn["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
