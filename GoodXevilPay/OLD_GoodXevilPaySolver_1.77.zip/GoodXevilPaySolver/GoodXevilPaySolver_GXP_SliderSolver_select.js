var zjetytgb = GetInputConstructorValue("zjetytgb", loader);
                 if(zjetytgb["original"].length == 0)
                 {
                   Invalid("arrow_id" + " is empty");
                   return;
                 }
var hjwgvlih = GetInputConstructorValue("hjwgvlih", loader);
                 if(hjwgvlih["original"].length == 0)
                 {
                   Invalid("Attempts" + " is empty");
                   return;
                 }
var dklqobmr = GetInputConstructorValue("dklqobmr", loader);
                 if(dklqobmr["original"].length == 0)
                 {
                   Invalid("avtoupdate" + " is empty");
                   return;
                 }
var mtaocxuv = GetInputConstructorValue("mtaocxuv", loader);
                 if(mtaocxuv["original"].length == 0)
                 {
                   Invalid("button_id" + " is empty");
                   return;
                 }
var kzexlbow = GetInputConstructorValue("kzexlbow", loader);
                 if(kzexlbow["original"].length == 0)
                 {
                   Invalid("coef" + " is empty");
                   return;
                 }
var pxkazero = GetInputConstructorValue("pxkazero", loader);
                 if(pxkazero["original"].length == 0)
                 {
                   Invalid("image id" + " is empty");
                   return;
                 }
var mhbrimbj = GetInputConstructorValue("mhbrimbj", loader);
                 if(mhbrimbj["original"].length == 0)
                 {
                   Invalid("key" + " is empty");
                   return;
                 }
var hnjdrkpl = GetInputConstructorValue("hnjdrkpl", loader);
                 if(hnjdrkpl["original"].length == 0)
                 {
                   Invalid("pixel_koef" + " is empty");
                   return;
                 }
var lamarbkl = GetInputConstructorValue("lamarbkl", loader);
                 if(lamarbkl["original"].length == 0)
                 {
                   Invalid("reload_id" + " is empty");
                   return;
                 }
var vlsathdd = GetInputConstructorValue("vlsathdd", loader);
                 if(vlsathdd["original"].length == 0)
                 {
                   Invalid("slider_type" + " is empty");
                   return;
                 }
var nztlaode = GetInputConstructorValue("nztlaode", loader);
                 if(nztlaode["original"].length == 0)
                 {
                   Invalid("speed" + " is empty");
                   return;
                 }
var cuuugfrf = GetInputConstructorValue("cuuugfrf", loader);
                 if(cuuugfrf["original"].length == 0)
                 {
                   Invalid("type_slide" + " is empty");
                   return;
                 }
var wlbjccuy = GetInputConstructorValue("wlbjccuy", loader);
                 if(wlbjccuy["original"].length == 0)
                 {
                   Invalid("type_swipe" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SliderSolver_code").html())({"zjetytgb": zjetytgb["updated"],"hjwgvlih": hjwgvlih["updated"],"dklqobmr": dklqobmr["updated"],"mtaocxuv": mtaocxuv["updated"],"kzexlbow": kzexlbow["updated"],"pxkazero": pxkazero["updated"],"mhbrimbj": mhbrimbj["updated"],"hnjdrkpl": hnjdrkpl["updated"],"lamarbkl": lamarbkl["updated"],"vlsathdd": vlsathdd["updated"],"nztlaode": nztlaode["updated"],"cuuugfrf": cuuugfrf["updated"],"wlbjccuy": wlbjccuy["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
