var uikolyes = GetInputConstructorValue("uikolyes", loader);
                 if(uikolyes["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var jxjomcfz = GetInputConstructorValue("jxjomcfz", loader);
                 if(jxjomcfz["original"].length == 0)
                 {
                   Invalid("mouse" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_Antibot_code").html())({"uikolyes": uikolyes["updated"],"jxjomcfz": jxjomcfz["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
