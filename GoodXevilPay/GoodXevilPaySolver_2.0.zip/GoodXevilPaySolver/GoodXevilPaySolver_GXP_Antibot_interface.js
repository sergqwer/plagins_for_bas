<div class="container-fluid">
<%= _.template($('#input_constructor').html())({id:"vreuafak", description:"Solve Service", default_selector: "string", variants: ["SCTG", "Multibot"], disable_expression:true, disable_int:true, value_string: "SCTG", help: {description: "<div>Выберите нужный вам сервис для решения капчи</div><div>Choose the service you need to solve captcha</div>"} }) %>
<%= _.template($('#input_constructor').html())({id:"zjkniblq", description:"ApiKey", default_selector: "string", disable_int:true, value_string: "", help: {description: "<div>apikey с сервиса https://t.me/Xevil_check_bot или https://multibot.in/</div><div>apikey from https://t.me/Xevil_check_bot or https://multibot.in/</div>"} }) %>
<%= _.template($('#input_constructor').html())({id:"xrobmesm", description:"Enable mouse", default_selector: "expression", variants: ["true", "false"], disable_int:true, disable_string:true, value_string: "true", help: {description: "<div>Включить емуляцию движения миши: true - включить, false - отключить</div><div>Enable mouse movement imulation: true - enable, false - disable</div>"} }) %>
</div>
<div class="tooltipinternal">
<div class="tr tooltip-paragraph-first-fold">Эта функция решает капчу AntiBot через сервис решения капчи https://t.me/Xevil_check_bot или https://multibot.in/</div>
<div class="tr tooltip-paragraph-last-fold">This function solves captcha AntiBot through the captcha solving service https://t.me/Xevil_check_bot or https://multibot.in/</div>
</div>
<%= _.template($('#back').html())({action:"executeandadd", visible:true}) %>
