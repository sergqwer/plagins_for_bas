<div class="container-fluid">
<%= _.template($('#input_constructor').html())({id:"bmsmmtqx", description:"ApiKey", default_selector: "string", disable_int:true, value_string: "", help: {description: "<div>apikey с сервиса https://t.me/Xevil_check_bot</div><div>apikey from https://t.me/Xevil_check_bot</div>"} }) %>
<%= _.template($('#input_constructor').html())({id:"gzgbxpld", description:"Images Selector", default_selector: "string", disable_int:true, value_string: " >CSS> .geetest_window", help: {description: "<div>Идентификатор поля с картинками</div><div>ID of the field with pictures</div>"} }) %>
<%= _.template($('#input_constructor').html())({id:"dzinglup", description:"Reload Button", default_selector: "string", disable_expression:true, disable_int:true, value_string: " >CSS> .geetest_refresh", help: {description: "<div>Идентификатор кнопки для обновления капчи\</div><div>Identifier of the button to update captcha</div>"} }) %>
</div>
<div class="tooltipinternal">
<div class="tr tooltip-paragraph-first-fold">Автоматически решает Geetest Images на странице. Для работы требуется функция "GeeTestImages CacheAllow"</div>
<div class="tr tooltip-paragraph-last-fold">Automatically resolves the Geetest Images on the page. The function “GeeTestImages CacheAllow” is required for operation</div>
</div>
<%= _.template($('#back').html())({action:"executeandadd", visible:true}) %>
