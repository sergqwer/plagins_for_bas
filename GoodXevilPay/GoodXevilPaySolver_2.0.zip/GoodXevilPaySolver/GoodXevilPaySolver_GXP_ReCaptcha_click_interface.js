<div class="container-fluid">
<%= _.template($('#input_constructor').html())({id:"tkgnljtj", description:"ApiKey", default_selector: "string", disable_int:true, value_string: "", help: {description: "<div>apikey с сервиса https://t.me/Xevil_check_bot</div><div>apikey from https://t.me/Xevil_check_bot</div>"} }) %>
<%= _.template($('#input_constructor').html())({id:"xbvgvkyi", description:"Selector ReCaptcha", default_selector: "string", disable_int:true, value_string: ">CSS>iframe[src*='anchor']>FRAME> >CSS> #recaptcha-anchor-label", help: {description: "<div>Селектор ReCaptcha</div><div>The ReCaptcha selector</div>"} }) %>
<%= _.template($('#input_constructor').html())({id:"mmqunkyp", description:"InvisibleCaptcha", default_selector: "expression", disable_int:true, variants: ["false", "true"], disable_string:true, value_string: "false", help: {description: "<div>Это невидимая капча? false - нет true - да Если капча невидимая, для ее решения надо разрешить кеш</div><div>Is it an invisible captcha? false - no true - yes If the captcha is invisible, you must enable cache to solve it</div>"} }) %>
<%= _.template($('#input_constructor').html())({id:"zicdjxjj", description:"Number of tries", default_selector: "int", disable_string:true, value_number: 20, min_number:-999999, max_number:999999, help: {description: "<div>Количество попыток решения капчи</div><div>Number of attempts to solve captcha</div>"} }) %>
</div>
<div class="tooltipinternal">
<div class="tr tooltip-paragraph-first-fold">Решает кликами ReCaptcha через сервис https://t.me/Xevil_check_bot, оплачивается каждое изображение. Для работы требуется функция "ReCaptcha CacheAllow"</div>
<div class="tr tooltip-paragraph-last-fold">Resolves by ReCaptcha clicks through the service https://t.me/Xevil_check_bot, paid per image. The function “ReCaptcha CacheAllow” is required for operation</div>
</div>
<%= _.template($('#back').html())({action:"executeandadd", visible:true}) %>
