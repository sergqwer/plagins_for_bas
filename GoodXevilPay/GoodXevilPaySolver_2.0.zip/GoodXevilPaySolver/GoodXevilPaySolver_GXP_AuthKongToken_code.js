_call_function(GoodXevilPaySolver_GXP_AuthKongToken,{ "APIKEY": (<%= ucjdzkws %>),"Service_Solver": (<%= oimzudqm %>),"site_url": (<%= sgrowysz %>),"sitekey": (<%= jlsxtmbm %>) })!
<%= variable %> = _result_function()
