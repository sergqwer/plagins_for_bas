var pvrcfrkq = GetInputConstructorValue("pvrcfrkq", loader);
                 if(pvrcfrkq["original"].length == 0)
                 {
                   Invalid("APIKey" + " is empty");
                   return;
                 }
var wempqvoi = GetInputConstructorValue("wempqvoi", loader);
                 if(wempqvoi["original"].length == 0)
                 {
                   Invalid("CaptchaNumber" + " is empty");
                   return;
                 }
var kfhfnlry = GetInputConstructorValue("kfhfnlry", loader);
                 if(kfhfnlry["original"].length == 0)
                 {
                   Invalid("CaptchaSelector" + " is empty");
                   return;
                 }
var npwabztl = GetInputConstructorValue("npwabztl", loader);
                 if(npwabztl["original"].length == 0)
                 {
                   Invalid("MaxLimitTask" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_Solve_Funcaptcha_code").html())({"pvrcfrkq": pvrcfrkq["updated"],"wempqvoi": wempqvoi["updated"],"kfhfnlry": kfhfnlry["updated"],"npwabztl": npwabztl["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
