<div class="container-fluid">
<%= _.template($('#input_constructor').html())({id:"vbimkmvl", description:"ApiKey", default_selector: "string", disable_int:true, value_string: "", help: {description: "<div>apikey с сервиса https://t.me/Xevil_check_bot</div><div>apikey from https://t.me/Xevil_check_bot</div>"} }) %>
<%= _.template($('#input_constructor').html())({id:"bzbrhlyh", description:"FRAME_PATH", default_selector: "string", disable_expression:true, disable_int:true, value_string: " ", help: {description: "<div>Путь к фрейму с капчей, именно к фрейму</div><div>The path to the captcha frame, exactly the frame</div>"} }) %>
</div>
<div class="tooltipinternal">
<div class="tr tooltip-paragraph-first-fold">Автоматически решает капчу на сайте Taobao, для работы требуется функция TaoBao AllowCache</div>
<div class="tr tooltip-paragraph-last-fold">Automatically solves captcha on Taobao site, TaoBao AllowCache function is required for operation</div>
</div>
<%= _.template($('#back').html())({action:"executeandadd", visible:true}) %>
