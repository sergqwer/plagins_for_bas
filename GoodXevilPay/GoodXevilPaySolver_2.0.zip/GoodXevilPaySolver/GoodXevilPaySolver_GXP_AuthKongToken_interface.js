<div class="container-fluid">
<%= _.template($('#input_constructor').html())({id:"oimzudqm", description:"Solve Service", default_selector: "string", variants: ["SCTG", "Multibot"], disable_expression:true, disable_int:true, value_string: "SCTG", help: {description: "<div>Выберите нужный вам сервис для решения капчи</div><div>Choose the service you need to solve captcha</div>"} }) %>
<%= _.template($('#input_constructor').html())({id:"ucjdzkws", description:"ApiKey", default_selector: "string", disable_int:true, value_string: "", help: {description: "<div>apikey с сервиса https://t.me/Xevil_check_bot или https://multibot.in/</div><div>apikey from https://t.me/Xevil_check_bot or https://multibot.in/</div>"} }) %>
<%= _.template($('#input_constructor').html())({id:"sgrowysz", description:"URL", default_selector: "string", disable_int:true, value_string: "https://onlyfaucet.com/", help: {description: "<div>Полный URL страницы где находится AuthKong</div><div>Full URL of the page where the AuthKong is located</div>"} }) %>
<%= _.template($('#input_constructor').html())({id:"jlsxtmbm", description:"data-sitekey", default_selector: "string", disable_int:true, value_string: "08f2c2d465d09d4dfd64eeb53f8b579f135b15abf170407747312a066f88b2a1", help: {description: "<div>Значение параметра data-sitekey AuthKong</div><div>AuthKong data-sitekey parameter value</div>"} }) %>
<%= _.template($('#variable_constructor').html())({id:"Save", description:"Result", default_variable: "AUTHKONG_RESULT", help: {description: ""}}) %>
</div>
<div class="tooltipinternal">
<div class="tr tooltip-paragraph-first-fold">Эта функция получает токен AuthKong через сервис https://t.me/Xevil_check_bot или https://multibot.in/</div>
<div class="tr tooltip-paragraph-last-fold">This feature receives a AuthKong token through the service https://t.me/Xevil_check_bot or https://multibot.in/</div>
</div>
<%= _.template($('#back').html())({action:"executeandadd", visible:true}) %>
