<div class="container-fluid">
<%= _.template($('#input_constructor').html())({id:"pnbxhoyg", description:"Solve Service", default_selector: "string", variants: ["SCTG", "Multibot"], disable_expression:true, disable_int:true, value_string: "SCTG", help: {description: "<div>Выберите нужный вам сервис для решения капчи</div><div>Choose the service you need to solve captcha</div>"} }) %>
<%= _.template($('#input_constructor').html())({id:"ppwvkztp", description:"ApiKey", default_selector: "string", disable_int:true, value_string: "", help: {description: "<div>apikey с сервиса https://t.me/Xevil_check_bot или https://multibot.in/</div><div>apikey from https://t.me/Xevil_check_bot or https://multibot.in/</div>"} }) %>
<%= _.template($('#input_constructor').html())({id:"rcyhfjxn", description:"URL", default_selector: "string", disable_int:true, value_string: "", help: {description: "<div>Полный URL страницы где находится hCaptcha</div><div>Full URL of the page where the hCaptcha is located</div>"} }) %>
<%= _.template($('#input_constructor').html())({id:"fmpctygk", description:"data-sitekey", default_selector: "string", disable_int:true, value_string: "", help: {description: "<div>Значение параметра data-sitekey hCaptcha</div><div>hCaptcha data-sitekey parameter value</div>"} }) %>
<%= _.template($('#variable_constructor').html())({id:"Save", description:"Result", default_variable: "HCAPTCHA_TOKEN", help: {description: "Токен hcaptcha"}}) %>
</div>
<div class="tooltipinternal">
<div class="tr tooltip-paragraph-first-fold">Эта функция получает токен hCaptcha через сервис решения капчи https://t.me/Xevil_check_bot или https://multibot.in/</div>
<div class="tr tooltip-paragraph-last-fold">This function receives the hCaptcha token through the captcha solving service https://t.me/Xevil_check_bot or https://multibot.in/</div>
</div>
<%= _.template($('#back').html())({action:"executeandadd", visible:true}) %>
