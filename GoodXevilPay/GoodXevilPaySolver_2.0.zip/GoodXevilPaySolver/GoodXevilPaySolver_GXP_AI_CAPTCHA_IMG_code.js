_call_function(GoodXevilPaySolver_GXP_AI_CAPTCHA_IMG,{ "apikey": (<%= ilcfpeuq %>),"IMAGE_IN_BASE64": (<%= gmcmdcgm %>),"REGEXTM": (<%= dsymrlya %>),"text_task": (<%= pmngrprv %>) })!
<%= variable %> = _result_function()
