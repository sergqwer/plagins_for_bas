var lbnqdqxc = GetInputConstructorValue("lbnqdqxc", loader);
                 if(lbnqdqxc["original"].length == 0)
                 {
                   Invalid("custom_button" + " is empty");
                   return;
                 }
var kgmbvzhn = GetInputConstructorValue("kgmbvzhn", loader);
                 if(kgmbvzhn["original"].length == 0)
                 {
                   Invalid("max_time" + " is empty");
                   return;
                 }
var mdseqlnl = GetInputConstructorValue("mdseqlnl", loader);
                 if(mdseqlnl["original"].length == 0)
                 {
                   Invalid("whait_element" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_AutoBypassCloudFlare_code").html())({"lbnqdqxc": lbnqdqxc["updated"],"kgmbvzhn": kgmbvzhn["updated"],"mdseqlnl": mdseqlnl["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
