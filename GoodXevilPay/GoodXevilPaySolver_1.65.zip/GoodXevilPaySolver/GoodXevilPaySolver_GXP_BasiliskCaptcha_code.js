_call_function(GoodXevilPaySolver_GXP_BasiliskCaptcha,{ "apikey": (<%= kpfflyam %>),"sitekey": (<%= iflswwqb %>),"siteurl": (<%= liawnhab %>) })!
