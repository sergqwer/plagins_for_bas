var uqxqlytd = GetInputConstructorValue("uqxqlytd", loader);
                 if(uqxqlytd["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var tgtweadb = GetInputConstructorValue("tgtweadb", loader);
                 if(tgtweadb["original"].length == 0)
                 {
                   Invalid("index" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_ReCaptcha_Bypass_No_Exten_code").html())({"uqxqlytd": uqxqlytd["updated"],"tgtweadb": tgtweadb["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
