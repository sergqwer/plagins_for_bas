var yxwmjuke = GetInputConstructorValue("yxwmjuke", loader);
                 if(yxwmjuke["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var yayeyplr = GetInputConstructorValue("yayeyplr", loader);
                 if(yayeyplr["original"].length == 0)
                 {
                   Invalid("captcha_submit" + " is empty");
                   return;
                 }
var fqkcwryl = GetInputConstructorValue("fqkcwryl", loader);
                 if(fqkcwryl["original"].length == 0)
                 {
                   Invalid("foto_captcha" + " is empty");
                   return;
                 }
var bfhhckto = GetInputConstructorValue("bfhhckto", loader);
                 if(bfhhckto["original"].length == 0)
                 {
                   Invalid("pixel_coef" + " is empty");
                   return;
                 }
var qcsjviwo = GetInputConstructorValue("qcsjviwo", loader);
                 if(qcsjviwo["original"].length == 0)
                 {
                   Invalid("reload_captcha" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SolverGeetestIcon_code").html())({"yxwmjuke": yxwmjuke["updated"],"yayeyplr": yayeyplr["updated"],"fqkcwryl": fqkcwryl["updated"],"bfhhckto": bfhhckto["updated"],"qcsjviwo": qcsjviwo["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
