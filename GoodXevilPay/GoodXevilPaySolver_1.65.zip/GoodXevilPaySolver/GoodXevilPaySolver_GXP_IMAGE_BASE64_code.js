_call_function(GoodXevilPaySolver_GXP_IMAGE_BASE64,{ "APIKEY": (<%= okcahfft %>),"IMAGE_BASE64": (<%= uuahwsum %>) })!
<%= variable %> = _result_function()
