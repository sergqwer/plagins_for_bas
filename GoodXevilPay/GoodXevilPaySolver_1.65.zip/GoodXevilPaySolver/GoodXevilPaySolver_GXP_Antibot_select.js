var jxjaawvv = GetInputConstructorValue("jxjaawvv", loader);
                 if(jxjaawvv["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var jlqcbybw = GetInputConstructorValue("jlqcbybw", loader);
                 if(jlqcbybw["original"].length == 0)
                 {
                   Invalid("mouse" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_Antibot_code").html())({"jxjaawvv": jxjaawvv["updated"],"jlqcbybw": jlqcbybw["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
