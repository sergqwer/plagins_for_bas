<div class="container-fluid">
<%= _.template($('#input_constructor').html())({id:"xayuuntv", description:"apikey", default_selector: "string", disable_int:true, value_string: "", help: {description: "apikey с бота в телеграмме https://t.me/Xevil_check_bot\n\napikey from telegram bot https://t.me/Xevil_check_bot"} }) %>
</div>
<div class="tooltipinternal">
<div class="tr tooltip-paragraph-first-fold">Решает капчу на сайтe seotime.biz с помощью сервиса https://t.me/Xevil_check_bot, для того чтобы решить капчу, запустите функцию на странице с капчей, если скрипт не смог решить капчу за 5 раз, он вернет ошибку которую можно обработать дейстиваем "Игнорировать ошибки"</div>
<div class="tr tooltip-paragraph-last-fold">Solves captcha on the site seotime.biz using the service https://t.me/Xevil_check_bot, in order to solve the captcha, run the function on the page with the captcha, if the script could not solve the captcha for 5 times, it will return an error that can be handled by the action "Ignore errors".</div>
</div>
<%= _.template($('#back').html())({action:"executeandadd", visible:true}) %>
