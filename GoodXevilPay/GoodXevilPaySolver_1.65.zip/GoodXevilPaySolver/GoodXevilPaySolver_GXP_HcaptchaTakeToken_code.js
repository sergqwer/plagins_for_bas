_call_function(GoodXevilPaySolver_GXP_HcaptchaTakeToken,{ "APIKEY": (<%= jkvdkmzq %>),"site_url": (<%= rfczkvch %>),"sitekey": (<%= mivggqjr %>) })!
<%= variable %> = _result_function()
