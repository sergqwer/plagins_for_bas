_call_function(GoodXevilPaySolver_GXP_ReCaptchav2TakeToken,{ "APIKEY": (<%= tpbdyuwa %>),"site_url": (<%= vpwlsqrv %>),"sitekey": (<%= rwfxtubx %>) })!
<%= variable %> = _result_function()
