<div class="container-fluid">
<%= _.template($('#input_constructor').html())({id:"knlkzxzu", description:"token", default_selector: "string", disable_int:true, value_string: "", help: {description: "Токен hcaptcha полученый, например, через CaptchaCustom\n\nThe hcaptcha token obtained, for example, via CaptchaCustom"} }) %>
</div>
<div class="tooltipinternal">
<div class="tr tooltip-paragraph-first-fold">Данная функция автоматически применит ваш токен hcaptcha, для работы требуется функция For Autosolve ReHCaptcha</div>
<div class="tr tooltip-paragraph-last-fold">This function will automatically apply your hcaptcha token, For Autosolve ReHCaptcha is required to work</div>
</div>
<%= _.template($('#back').html())({action:"executeandadd", visible:true}) %>
