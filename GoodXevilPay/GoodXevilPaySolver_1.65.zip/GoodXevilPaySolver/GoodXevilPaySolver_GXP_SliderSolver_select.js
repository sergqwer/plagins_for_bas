var zmwugvpr = GetInputConstructorValue("zmwugvpr", loader);
                 if(zmwugvpr["original"].length == 0)
                 {
                   Invalid("arrow_id" + " is empty");
                   return;
                 }
var xqvspoih = GetInputConstructorValue("xqvspoih", loader);
                 if(xqvspoih["original"].length == 0)
                 {
                   Invalid("avtoupdate" + " is empty");
                   return;
                 }
var glfivvkm = GetInputConstructorValue("glfivvkm", loader);
                 if(glfivvkm["original"].length == 0)
                 {
                   Invalid("button_id" + " is empty");
                   return;
                 }
var fzkwglam = GetInputConstructorValue("fzkwglam", loader);
                 if(fzkwglam["original"].length == 0)
                 {
                   Invalid("coef" + " is empty");
                   return;
                 }
var apwipchh = GetInputConstructorValue("apwipchh", loader);
                 if(apwipchh["original"].length == 0)
                 {
                   Invalid("image id" + " is empty");
                   return;
                 }
var btflnxwp = GetInputConstructorValue("btflnxwp", loader);
                 if(btflnxwp["original"].length == 0)
                 {
                   Invalid("key" + " is empty");
                   return;
                 }
var rkuickji = GetInputConstructorValue("rkuickji", loader);
                 if(rkuickji["original"].length == 0)
                 {
                   Invalid("pixel_koef" + " is empty");
                   return;
                 }
var mzurhgbw = GetInputConstructorValue("mzurhgbw", loader);
                 if(mzurhgbw["original"].length == 0)
                 {
                   Invalid("reload_id" + " is empty");
                   return;
                 }
var hbiivvgu = GetInputConstructorValue("hbiivvgu", loader);
                 if(hbiivvgu["original"].length == 0)
                 {
                   Invalid("slider_type" + " is empty");
                   return;
                 }
var qwhlynij = GetInputConstructorValue("qwhlynij", loader);
                 if(qwhlynij["original"].length == 0)
                 {
                   Invalid("speed" + " is empty");
                   return;
                 }
var qclyhyuf = GetInputConstructorValue("qclyhyuf", loader);
                 if(qclyhyuf["original"].length == 0)
                 {
                   Invalid("type_slide" + " is empty");
                   return;
                 }
var zwksxevi = GetInputConstructorValue("zwksxevi", loader);
                 if(zwksxevi["original"].length == 0)
                 {
                   Invalid("type_swipe" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SliderSolver_code").html())({"zmwugvpr": zmwugvpr["updated"],"xqvspoih": xqvspoih["updated"],"glfivvkm": glfivvkm["updated"],"fzkwglam": fzkwglam["updated"],"apwipchh": apwipchh["updated"],"btflnxwp": btflnxwp["updated"],"rkuickji": rkuickji["updated"],"mzurhgbw": mzurhgbw["updated"],"hbiivvgu": hbiivvgu["updated"],"qwhlynij": qwhlynij["updated"],"qclyhyuf": qclyhyuf["updated"],"zwksxevi": zwksxevi["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
