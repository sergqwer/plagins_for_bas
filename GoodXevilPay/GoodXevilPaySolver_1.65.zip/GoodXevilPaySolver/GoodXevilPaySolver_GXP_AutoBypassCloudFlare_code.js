_call_function(GoodXevilPaySolver_GXP_AutoBypassCloudFlare,{ "custom_button": (<%= lbnqdqxc %>),"max_time": (<%= kgmbvzhn %>),"whait_element": (<%= mdseqlnl %>) })!
