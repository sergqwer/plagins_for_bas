var kpfflyam = GetInputConstructorValue("kpfflyam", loader);
                 if(kpfflyam["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var iflswwqb = GetInputConstructorValue("iflswwqb", loader);
                 if(iflswwqb["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var liawnhab = GetInputConstructorValue("liawnhab", loader);
                 if(liawnhab["original"].length == 0)
                 {
                   Invalid("siteurl" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_BasiliskCaptcha_code").html())({"kpfflyam": kpfflyam["updated"],"iflswwqb": iflswwqb["updated"],"liawnhab": liawnhab["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
