_call_function(GoodXevilPaySolver_ReCaptchav2TakeToken,{ "APIKEY": (<%= wkcsrzsc %>),"site_url": (<%= sajrvwdr %>),"sitekey": (<%= vlnqauyq %>) })!
<%= variable %> = _result_function()
