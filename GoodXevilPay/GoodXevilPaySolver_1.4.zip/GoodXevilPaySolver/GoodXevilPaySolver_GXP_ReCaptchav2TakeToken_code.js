_call_function(GoodXevilPaySolver_GXP_ReCaptchav2TakeToken,{ "APIKEY": (<%= qnwgbzex %>),"site_url": (<%= moqmzmzo %>),"sitekey": (<%= gqmucrys %>) })!
<%= variable %> = _result_function()
