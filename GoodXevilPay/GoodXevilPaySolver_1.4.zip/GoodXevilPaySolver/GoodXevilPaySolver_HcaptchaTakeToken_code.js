_call_function(GoodXevilPaySolver_HcaptchaTakeToken,{ "APIKEY": (<%= afclftsw %>),"site_url": (<%= pkrnigvz %>),"sitekey": (<%= ztscnpki %>) })!
<%= variable %> = _result_function()
