var sfqewpom = GetInputConstructorValue("sfqewpom", loader);
                 if(sfqewpom["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var qwqblbbj = GetInputConstructorValue("qwqblbbj", loader);
                 if(qwqblbbj["original"].length == 0)
                 {
                   Invalid("mouse" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_Antibot_code").html())({"sfqewpom": sfqewpom["updated"],"qwqblbbj": qwqblbbj["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
