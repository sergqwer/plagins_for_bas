var qnwgbzex = GetInputConstructorValue("qnwgbzex", loader);
                 if(qnwgbzex["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var moqmzmzo = GetInputConstructorValue("moqmzmzo", loader);
                 if(moqmzmzo["original"].length == 0)
                 {
                   Invalid("site_url" + " is empty");
                   return;
                 }
var gqmucrys = GetInputConstructorValue("gqmucrys", loader);
                 if(gqmucrys["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_ReCaptchav2TakeToken_code").html())({"qnwgbzex": qnwgbzex["updated"],"moqmzmzo": moqmzmzo["updated"],"gqmucrys": gqmucrys["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
