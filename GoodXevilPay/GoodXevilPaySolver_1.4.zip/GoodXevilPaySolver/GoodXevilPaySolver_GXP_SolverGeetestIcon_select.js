var oeymoorv = GetInputConstructorValue("oeymoorv", loader);
                 if(oeymoorv["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var quzyqqzu = GetInputConstructorValue("quzyqqzu", loader);
                 if(quzyqqzu["original"].length == 0)
                 {
                   Invalid("button_capthca" + " is empty");
                   return;
                 }
var knhggebt = GetInputConstructorValue("knhggebt", loader);
                 if(knhggebt["original"].length == 0)
                 {
                   Invalid("captcha_submit" + " is empty");
                   return;
                 }
var tdjsilrv = GetInputConstructorValue("tdjsilrv", loader);
                 if(tdjsilrv["original"].length == 0)
                 {
                   Invalid("foto_captcha" + " is empty");
                   return;
                 }
var hcvmwiws = GetInputConstructorValue("hcvmwiws", loader);
                 if(hcvmwiws["original"].length == 0)
                 {
                   Invalid("reload_captcha" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SolverGeetestIcon_code").html())({"oeymoorv": oeymoorv["updated"],"quzyqqzu": quzyqqzu["updated"],"knhggebt": knhggebt["updated"],"tdjsilrv": tdjsilrv["updated"],"hcvmwiws": hcvmwiws["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
