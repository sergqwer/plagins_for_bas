var wkcsrzsc = GetInputConstructorValue("wkcsrzsc", loader);
                 if(wkcsrzsc["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var sajrvwdr = GetInputConstructorValue("sajrvwdr", loader);
                 if(sajrvwdr["original"].length == 0)
                 {
                   Invalid("site_url" + " is empty");
                   return;
                 }
var vlnqauyq = GetInputConstructorValue("vlnqauyq", loader);
                 if(vlnqauyq["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_ReCaptchav2TakeToken_code").html())({"wkcsrzsc": wkcsrzsc["updated"],"sajrvwdr": sajrvwdr["updated"],"vlnqauyq": vlnqauyq["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
