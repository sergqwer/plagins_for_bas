_call_function(GoodXevilPaySolver_GetBalance,{ "APIKEY": (<%= gtezyjyd %>) })!
<%= variable %> = _result_function()
