var pczbgyqg = GetInputConstructorValue("pczbgyqg", loader);
                 if(pczbgyqg["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var nhwdindj = GetInputConstructorValue("nhwdindj", loader);
                 if(nhwdindj["original"].length == 0)
                 {
                   Invalid("timer" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_BuxMoney_PayupVideo_code").html())({"pczbgyqg": pczbgyqg["updated"],"nhwdindj": nhwdindj["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
