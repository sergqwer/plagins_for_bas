_call_function(GoodXevilPaySolver_GXP_HcaptchaTakeToken,{ "APIKEY": (<%= rjkhxilu %>),"site_url": (<%= chxwxtob %>),"sitekey": (<%= wredhklg %>) })!
<%= variable %> = _result_function()
