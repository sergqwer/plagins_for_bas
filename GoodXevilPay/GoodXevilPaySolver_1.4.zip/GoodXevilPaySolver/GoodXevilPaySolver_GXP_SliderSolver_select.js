var ehcnkset = GetInputConstructorValue("ehcnkset", loader);
                 if(ehcnkset["original"].length == 0)
                 {
                   Invalid("arrow_id" + " is empty");
                   return;
                 }
var sistcgvm = GetInputConstructorValue("sistcgvm", loader);
                 if(sistcgvm["original"].length == 0)
                 {
                   Invalid("avtoupdate" + " is empty");
                   return;
                 }
var cvjakaiw = GetInputConstructorValue("cvjakaiw", loader);
                 if(cvjakaiw["original"].length == 0)
                 {
                   Invalid("button_id" + " is empty");
                   return;
                 }
var mcpkgrop = GetInputConstructorValue("mcpkgrop", loader);
                 if(mcpkgrop["original"].length == 0)
                 {
                   Invalid("coef" + " is empty");
                   return;
                 }
var tgkcahmh = GetInputConstructorValue("tgkcahmh", loader);
                 if(tgkcahmh["original"].length == 0)
                 {
                   Invalid("image id" + " is empty");
                   return;
                 }
var bexfgdkw = GetInputConstructorValue("bexfgdkw", loader);
                 if(bexfgdkw["original"].length == 0)
                 {
                   Invalid("key" + " is empty");
                   return;
                 }
var ownbrpch = GetInputConstructorValue("ownbrpch", loader);
                 if(ownbrpch["original"].length == 0)
                 {
                   Invalid("pixel_koef" + " is empty");
                   return;
                 }
var ucadjwyp = GetInputConstructorValue("ucadjwyp", loader);
                 if(ucadjwyp["original"].length == 0)
                 {
                   Invalid("reload_id" + " is empty");
                   return;
                 }
var ehndlhzy = GetInputConstructorValue("ehndlhzy", loader);
                 if(ehndlhzy["original"].length == 0)
                 {
                   Invalid("speed" + " is empty");
                   return;
                 }
var atyhzzud = GetInputConstructorValue("atyhzzud", loader);
                 if(atyhzzud["original"].length == 0)
                 {
                   Invalid("type_slide" + " is empty");
                   return;
                 }
var bibkhsyf = GetInputConstructorValue("bibkhsyf", loader);
                 if(bibkhsyf["original"].length == 0)
                 {
                   Invalid("type_swipe" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SliderSolver_code").html())({"ehcnkset": ehcnkset["updated"],"sistcgvm": sistcgvm["updated"],"cvjakaiw": cvjakaiw["updated"],"mcpkgrop": mcpkgrop["updated"],"tgkcahmh": tgkcahmh["updated"],"bexfgdkw": bexfgdkw["updated"],"ownbrpch": ownbrpch["updated"],"ucadjwyp": ucadjwyp["updated"],"ehndlhzy": ehndlhzy["updated"],"atyhzzud": atyhzzud["updated"],"bibkhsyf": bibkhsyf["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
