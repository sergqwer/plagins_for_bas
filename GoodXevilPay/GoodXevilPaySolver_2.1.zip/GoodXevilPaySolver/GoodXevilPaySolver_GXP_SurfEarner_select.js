var zwdwwbjw = GetInputConstructorValue("zwdwwbjw", loader);
                 if(zwdwwbjw["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SurfEarner_code").html())({"zwdwwbjw": zwdwwbjw["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
