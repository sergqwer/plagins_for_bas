_call_function(GoodXevilPaySolver_GXP_TurnstileToken,{ "APIKEY": (<%= ziwfqscp %>),"Service_Solver": (<%= fufnkwsy %>),"site_url": (<%= euysqnqe %>),"sitekey": (<%= avscbhca %>) })!
<%= variable %> = _result_function()
