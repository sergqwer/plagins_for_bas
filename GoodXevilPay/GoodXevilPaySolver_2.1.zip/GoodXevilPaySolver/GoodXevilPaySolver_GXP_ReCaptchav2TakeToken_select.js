var hyzodkwq = GetInputConstructorValue("hyzodkwq", loader);
                 if(hyzodkwq["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var highpcra = GetInputConstructorValue("highpcra", loader);
                 if(highpcra["original"].length == 0)
                 {
                   Invalid("Service_Solver" + " is empty");
                   return;
                 }
var pxqyxuli = GetInputConstructorValue("pxqyxuli", loader);
                 if(pxqyxuli["original"].length == 0)
                 {
                   Invalid("site_url" + " is empty");
                   return;
                 }
var uzeowkvg = GetInputConstructorValue("uzeowkvg", loader);
                 if(uzeowkvg["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_ReCaptchav2TakeToken_code").html())({"hyzodkwq": hyzodkwq["updated"],"highpcra": highpcra["updated"],"pxqyxuli": pxqyxuli["updated"],"uzeowkvg": uzeowkvg["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
