_call_function(GoodXevilPaySolver_GXP_Antibot,{ "apikey": (<%= zjkniblq %>),"mouse": (<%= xrobmesm %>),"Service_Solver": (<%= vreuafak %>) })!
