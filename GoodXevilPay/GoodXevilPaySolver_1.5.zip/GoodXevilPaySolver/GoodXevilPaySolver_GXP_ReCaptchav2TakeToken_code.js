_call_function(GoodXevilPaySolver_GXP_ReCaptchav2TakeToken,{ "APIKEY": (<%= gxevtrha %>),"site_url": (<%= gpcevtbv %>),"sitekey": (<%= gzlceqoy %>) })!
<%= variable %> = _result_function()
