_call_function(GoodXevilPaySolver_ReCaptchav2TakeToken,{ "APIKEY": (<%= zvtmvtad %>),"site_url": (<%= jmqibhhy %>),"sitekey": (<%= bkreegpw %>) })!
<%= variable %> = _result_function()
