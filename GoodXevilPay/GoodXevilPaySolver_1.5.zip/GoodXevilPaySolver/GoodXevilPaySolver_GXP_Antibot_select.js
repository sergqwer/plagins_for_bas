var hclitqjy = GetInputConstructorValue("hclitqjy", loader);
                 if(hclitqjy["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var majmidxi = GetInputConstructorValue("majmidxi", loader);
                 if(majmidxi["original"].length == 0)
                 {
                   Invalid("mouse" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_Antibot_code").html())({"hclitqjy": hclitqjy["updated"],"majmidxi": majmidxi["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
