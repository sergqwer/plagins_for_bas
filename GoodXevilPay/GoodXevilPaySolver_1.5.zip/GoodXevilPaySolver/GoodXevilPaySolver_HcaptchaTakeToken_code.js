_call_function(GoodXevilPaySolver_HcaptchaTakeToken,{ "APIKEY": (<%= ejkclrcq %>),"site_url": (<%= aioeplkn %>),"sitekey": (<%= nnltlfkp %>) })!
<%= variable %> = _result_function()
