<div class="container-fluid">
</div>
<div class="tooltipinternal">
<div class="tr tooltip-paragraph-first-fold">Автоматически проходит CloudFlare на любом сайте в браузере, просто небольшой удобный скрипт, ставить после загрузки страницы, ждать полной загрузки страницы не надо</div>
</div>
<%= _.template($('#back').html())({action:"executeandadd", visible:true}) %>
