_call_function(GoodXevilPaySolver_GXP_IMAGE_BASE64,{ "APIKEY": (<%= cyfcdosq %>),"IMAGE_BASE64": (<%= pkwohfkf %>) })!
<%= variable %> = _result_function()
