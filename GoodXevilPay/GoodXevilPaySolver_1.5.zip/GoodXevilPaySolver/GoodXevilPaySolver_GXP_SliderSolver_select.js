var wyyxujks = GetInputConstructorValue("wyyxujks", loader);
                 if(wyyxujks["original"].length == 0)
                 {
                   Invalid("arrow_id" + " is empty");
                   return;
                 }
var aorkneok = GetInputConstructorValue("aorkneok", loader);
                 if(aorkneok["original"].length == 0)
                 {
                   Invalid("avtoupdate" + " is empty");
                   return;
                 }
var wosdabmm = GetInputConstructorValue("wosdabmm", loader);
                 if(wosdabmm["original"].length == 0)
                 {
                   Invalid("button_id" + " is empty");
                   return;
                 }
var rsflfedu = GetInputConstructorValue("rsflfedu", loader);
                 if(rsflfedu["original"].length == 0)
                 {
                   Invalid("coef" + " is empty");
                   return;
                 }
var giuopsun = GetInputConstructorValue("giuopsun", loader);
                 if(giuopsun["original"].length == 0)
                 {
                   Invalid("image id" + " is empty");
                   return;
                 }
var lvoqnzxw = GetInputConstructorValue("lvoqnzxw", loader);
                 if(lvoqnzxw["original"].length == 0)
                 {
                   Invalid("key" + " is empty");
                   return;
                 }
var immzkaug = GetInputConstructorValue("immzkaug", loader);
                 if(immzkaug["original"].length == 0)
                 {
                   Invalid("pixel_koef" + " is empty");
                   return;
                 }
var wtvjerql = GetInputConstructorValue("wtvjerql", loader);
                 if(wtvjerql["original"].length == 0)
                 {
                   Invalid("reload_id" + " is empty");
                   return;
                 }
var wtxbwiza = GetInputConstructorValue("wtxbwiza", loader);
                 if(wtxbwiza["original"].length == 0)
                 {
                   Invalid("speed" + " is empty");
                   return;
                 }
var couwangv = GetInputConstructorValue("couwangv", loader);
                 if(couwangv["original"].length == 0)
                 {
                   Invalid("type_slide" + " is empty");
                   return;
                 }
var vvmfefzr = GetInputConstructorValue("vvmfefzr", loader);
                 if(vvmfefzr["original"].length == 0)
                 {
                   Invalid("type_swipe" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SliderSolver_code").html())({"wyyxujks": wyyxujks["updated"],"aorkneok": aorkneok["updated"],"wosdabmm": wosdabmm["updated"],"rsflfedu": rsflfedu["updated"],"giuopsun": giuopsun["updated"],"lvoqnzxw": lvoqnzxw["updated"],"immzkaug": immzkaug["updated"],"wtvjerql": wtvjerql["updated"],"wtxbwiza": wtxbwiza["updated"],"couwangv": couwangv["updated"],"vvmfefzr": vvmfefzr["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
