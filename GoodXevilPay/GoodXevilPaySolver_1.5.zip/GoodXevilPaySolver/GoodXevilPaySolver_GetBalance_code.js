_call_function(GoodXevilPaySolver_GetBalance,{ "APIKEY": (<%= izkyyxcp %>) })!
<%= variable %> = _result_function()
