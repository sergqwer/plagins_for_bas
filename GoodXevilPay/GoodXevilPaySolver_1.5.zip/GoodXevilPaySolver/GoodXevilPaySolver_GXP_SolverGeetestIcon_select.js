var cbvabetv = GetInputConstructorValue("cbvabetv", loader);
                 if(cbvabetv["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var nnkdarpq = GetInputConstructorValue("nnkdarpq", loader);
                 if(nnkdarpq["original"].length == 0)
                 {
                   Invalid("button_capthca" + " is empty");
                   return;
                 }
var zqjfbutq = GetInputConstructorValue("zqjfbutq", loader);
                 if(zqjfbutq["original"].length == 0)
                 {
                   Invalid("captcha_submit" + " is empty");
                   return;
                 }
var xpewacxu = GetInputConstructorValue("xpewacxu", loader);
                 if(xpewacxu["original"].length == 0)
                 {
                   Invalid("foto_captcha" + " is empty");
                   return;
                 }
var urbryohc = GetInputConstructorValue("urbryohc", loader);
                 if(urbryohc["original"].length == 0)
                 {
                   Invalid("reload_captcha" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SolverGeetestIcon_code").html())({"cbvabetv": cbvabetv["updated"],"nnkdarpq": nnkdarpq["updated"],"zqjfbutq": zqjfbutq["updated"],"xpewacxu": xpewacxu["updated"],"urbryohc": urbryohc["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
