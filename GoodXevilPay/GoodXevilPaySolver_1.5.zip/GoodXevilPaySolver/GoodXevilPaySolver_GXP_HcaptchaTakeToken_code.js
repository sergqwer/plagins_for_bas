_call_function(GoodXevilPaySolver_GXP_HcaptchaTakeToken,{ "APIKEY": (<%= miinscch %>),"site_url": (<%= pgascocs %>),"sitekey": (<%= bhaumoeo %>) })!
<%= variable %> = _result_function()
