var wzexqcbc = GetInputConstructorValue("wzexqcbc", loader);
                 if(wzexqcbc["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var liychnjp = GetInputConstructorValue("liychnjp", loader);
                 if(liychnjp["original"].length == 0)
                 {
                   Invalid("timer" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_BuxMoney_PayupVideo_code").html())({"wzexqcbc": wzexqcbc["updated"],"liychnjp": liychnjp["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
