_call_function(GoodXevilPaySolver_ReCaptchav2TakeToken,{ "APIKEY": (<%= nzoknmhi %>),"site_url": (<%= txgvqcvk %>),"sitekey": (<%= hxxuutyj %>) })!
<%= variable %> = _result_function()
