_call_function(GoodXevilPaySolver_ReCaptchav2TakeToken,{ "APIKEY": (<%= jebykcum %>),"site_url": (<%= lnpniwdz %>),"sitekey": (<%= xpvuopyq %>) })!
<%= variable %> = _result_function()
