var nzdkbtat = GetInputConstructorValue("nzdkbtat", loader);
                 if(nzdkbtat["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var twzdnoih = GetInputConstructorValue("twzdnoih", loader);
                 if(twzdnoih["original"].length == 0)
                 {
                   Invalid("site_url" + " is empty");
                   return;
                 }
var jzhjxoqk = GetInputConstructorValue("jzhjxoqk", loader);
                 if(jzhjxoqk["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_ReCaptchav2TakeToken_code").html())({"nzdkbtat": nzdkbtat["updated"],"twzdnoih": twzdnoih["updated"],"jzhjxoqk": jzhjxoqk["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
