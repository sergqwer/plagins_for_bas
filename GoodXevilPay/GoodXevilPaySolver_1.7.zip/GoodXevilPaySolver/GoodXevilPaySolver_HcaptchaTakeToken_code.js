_call_function(GoodXevilPaySolver_HcaptchaTakeToken,{ "APIKEY": (<%= furbrthy %>),"site_url": (<%= sjjcuqrv %>),"sitekey": (<%= iwhbscvo %>) })!
<%= variable %> = _result_function()
