_call_function(GoodXevilPaySolver_HcaptchaTakeToken,{ "APIKEY": (<%= yhbrsqwe %>),"site_url": (<%= jkomtrmf %>),"sitekey": (<%= tsjkyurb %>) })!
<%= variable %> = _result_function()
