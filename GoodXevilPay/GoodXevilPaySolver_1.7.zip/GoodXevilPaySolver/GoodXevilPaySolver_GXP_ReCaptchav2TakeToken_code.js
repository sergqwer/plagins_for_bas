_call_function(GoodXevilPaySolver_GXP_ReCaptchav2TakeToken,{ "APIKEY": (<%= nzdkbtat %>),"site_url": (<%= twzdnoih %>),"sitekey": (<%= jzhjxoqk %>) })!
<%= variable %> = _result_function()
