var fmzecshl = GetInputConstructorValue("fmzecshl", loader);
                 if(fmzecshl["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var guortbwa = GetInputConstructorValue("guortbwa", loader);
                 if(guortbwa["original"].length == 0)
                 {
                   Invalid("mouse" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_Antibot_code").html())({"fmzecshl": fmzecshl["updated"],"guortbwa": guortbwa["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
