var furbrthy = GetInputConstructorValue("furbrthy", loader);
                 if(furbrthy["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var sjjcuqrv = GetInputConstructorValue("sjjcuqrv", loader);
                 if(sjjcuqrv["original"].length == 0)
                 {
                   Invalid("site_url" + " is empty");
                   return;
                 }
var iwhbscvo = GetInputConstructorValue("iwhbscvo", loader);
                 if(iwhbscvo["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_HcaptchaTakeToken_code").html())({"furbrthy": furbrthy["updated"],"sjjcuqrv": sjjcuqrv["updated"],"iwhbscvo": iwhbscvo["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
