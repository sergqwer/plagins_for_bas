var yonfgcwe = GetInputConstructorValue("yonfgcwe", loader);
                 if(yonfgcwe["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var ooifqogc = GetInputConstructorValue("ooifqogc", loader);
                 if(ooifqogc["original"].length == 0)
                 {
                   Invalid("site_url" + " is empty");
                   return;
                 }
var sjibsfbr = GetInputConstructorValue("sjibsfbr", loader);
                 if(sjibsfbr["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_HcaptchaTakeToken_code").html())({"yonfgcwe": yonfgcwe["updated"],"ooifqogc": ooifqogc["updated"],"sjibsfbr": sjibsfbr["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
