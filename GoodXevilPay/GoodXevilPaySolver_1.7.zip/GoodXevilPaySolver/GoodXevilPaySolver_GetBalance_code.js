_call_function(GoodXevilPaySolver_GetBalance,{ "APIKEY": (<%= ezbzpons %>) })!
<%= variable %> = _result_function()
