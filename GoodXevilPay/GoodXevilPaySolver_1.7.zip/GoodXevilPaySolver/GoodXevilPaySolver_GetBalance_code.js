_call_function(GoodXevilPaySolver_GetBalance,{ "APIKEY": (<%= uiioxjtd %>) })!
<%= variable %> = _result_function()
