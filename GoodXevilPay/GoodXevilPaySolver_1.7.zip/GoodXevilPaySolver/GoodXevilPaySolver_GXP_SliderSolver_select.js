var naxltbeu = GetInputConstructorValue("naxltbeu", loader);
                 if(naxltbeu["original"].length == 0)
                 {
                   Invalid("arrow_id" + " is empty");
                   return;
                 }
var lneoasrf = GetInputConstructorValue("lneoasrf", loader);
                 if(lneoasrf["original"].length == 0)
                 {
                   Invalid("avtoupdate" + " is empty");
                   return;
                 }
var srjooghw = GetInputConstructorValue("srjooghw", loader);
                 if(srjooghw["original"].length == 0)
                 {
                   Invalid("button_id" + " is empty");
                   return;
                 }
var ekawirqb = GetInputConstructorValue("ekawirqb", loader);
                 if(ekawirqb["original"].length == 0)
                 {
                   Invalid("coef" + " is empty");
                   return;
                 }
var fuakivsd = GetInputConstructorValue("fuakivsd", loader);
                 if(fuakivsd["original"].length == 0)
                 {
                   Invalid("image id" + " is empty");
                   return;
                 }
var rfcmtpbj = GetInputConstructorValue("rfcmtpbj", loader);
                 if(rfcmtpbj["original"].length == 0)
                 {
                   Invalid("key" + " is empty");
                   return;
                 }
var dhhxhiet = GetInputConstructorValue("dhhxhiet", loader);
                 if(dhhxhiet["original"].length == 0)
                 {
                   Invalid("pixel_koef" + " is empty");
                   return;
                 }
var nirqwnsq = GetInputConstructorValue("nirqwnsq", loader);
                 if(nirqwnsq["original"].length == 0)
                 {
                   Invalid("reload_id" + " is empty");
                   return;
                 }
var rndtqwog = GetInputConstructorValue("rndtqwog", loader);
                 if(rndtqwog["original"].length == 0)
                 {
                   Invalid("speed" + " is empty");
                   return;
                 }
var dtfzdaom = GetInputConstructorValue("dtfzdaom", loader);
                 if(dtfzdaom["original"].length == 0)
                 {
                   Invalid("type_slide" + " is empty");
                   return;
                 }
var eejptvqo = GetInputConstructorValue("eejptvqo", loader);
                 if(eejptvqo["original"].length == 0)
                 {
                   Invalid("type_swipe" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SliderSolver_code").html())({"naxltbeu": naxltbeu["updated"],"lneoasrf": lneoasrf["updated"],"srjooghw": srjooghw["updated"],"ekawirqb": ekawirqb["updated"],"fuakivsd": fuakivsd["updated"],"rfcmtpbj": rfcmtpbj["updated"],"dhhxhiet": dhhxhiet["updated"],"nirqwnsq": nirqwnsq["updated"],"rndtqwog": rndtqwog["updated"],"dtfzdaom": dtfzdaom["updated"],"eejptvqo": eejptvqo["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
