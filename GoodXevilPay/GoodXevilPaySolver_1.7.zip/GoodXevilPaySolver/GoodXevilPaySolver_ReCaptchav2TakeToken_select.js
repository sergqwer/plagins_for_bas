var jebykcum = GetInputConstructorValue("jebykcum", loader);
                 if(jebykcum["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var lnpniwdz = GetInputConstructorValue("lnpniwdz", loader);
                 if(lnpniwdz["original"].length == 0)
                 {
                   Invalid("site_url" + " is empty");
                   return;
                 }
var xpvuopyq = GetInputConstructorValue("xpvuopyq", loader);
                 if(xpvuopyq["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_ReCaptchav2TakeToken_code").html())({"jebykcum": jebykcum["updated"],"lnpniwdz": lnpniwdz["updated"],"xpvuopyq": xpvuopyq["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
