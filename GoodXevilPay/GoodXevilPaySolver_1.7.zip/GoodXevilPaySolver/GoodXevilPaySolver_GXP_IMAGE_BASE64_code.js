_call_function(GoodXevilPaySolver_GXP_IMAGE_BASE64,{ "APIKEY": (<%= pfrbiaxy %>),"IMAGE_BASE64": (<%= txycppta %>) })!
<%= variable %> = _result_function()
