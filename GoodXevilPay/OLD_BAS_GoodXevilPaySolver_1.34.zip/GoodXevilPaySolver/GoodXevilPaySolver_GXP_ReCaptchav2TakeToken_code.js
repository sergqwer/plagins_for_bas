_call_function(GoodXevilPaySolver_GXP_ReCaptchav2TakeToken,{ "APIKEY": (<%= ttlafyba %>),"site_url": (<%= jvqgejnn %>),"sitekey": (<%= vfvsqbzh %>) })!
<%= variable %> = _result_function()
