var fnujcpgu = GetInputConstructorValue("fnujcpgu", loader);
                 if(fnujcpgu["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var uswlyney = GetInputConstructorValue("uswlyney", loader);
                 if(uswlyney["original"].length == 0)
                 {
                   Invalid("mouse" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_Antibot_code").html())({"fnujcpgu": fnujcpgu["updated"],"uswlyney": uswlyney["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
