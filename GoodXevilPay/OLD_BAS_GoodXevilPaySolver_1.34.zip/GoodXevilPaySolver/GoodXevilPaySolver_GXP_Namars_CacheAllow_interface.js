<div class="container-fluid">
</div>
<div class="tooltipinternal">
<div class="tr tooltip-paragraph-first-fold">Надо для правильной работы GXP_Namars</div>
<div class="tr tooltip-paragraph-last-fold">Запускать надо до загрузки страницы с капчей</div>
</div>
<%= _.template($('#back').html())({action:"executeandadd", visible:true}) %>
