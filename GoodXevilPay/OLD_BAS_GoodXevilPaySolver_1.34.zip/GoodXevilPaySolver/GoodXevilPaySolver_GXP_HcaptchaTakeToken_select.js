var mqtxtapn = GetInputConstructorValue("mqtxtapn", loader);
                 if(mqtxtapn["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var oxcxpqbq = GetInputConstructorValue("oxcxpqbq", loader);
                 if(oxcxpqbq["original"].length == 0)
                 {
                   Invalid("site_url" + " is empty");
                   return;
                 }
var gccxcnvs = GetInputConstructorValue("gccxcnvs", loader);
                 if(gccxcnvs["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_HcaptchaTakeToken_code").html())({"mqtxtapn": mqtxtapn["updated"],"oxcxpqbq": oxcxpqbq["updated"],"gccxcnvs": gccxcnvs["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
