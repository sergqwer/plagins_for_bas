_call_function(GoodXevilPaySolver_GXP_GetBalance,{ "APIKEY": (<%= zyrjslvi %>) })!
<%= variable %> = _result_function()
