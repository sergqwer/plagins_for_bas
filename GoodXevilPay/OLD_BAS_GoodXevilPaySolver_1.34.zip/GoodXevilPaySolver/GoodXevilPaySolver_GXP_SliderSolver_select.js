var zxivfdua = GetInputConstructorValue("zxivfdua", loader);
                 if(zxivfdua["original"].length == 0)
                 {
                   Invalid("arrow_id" + " is empty");
                   return;
                 }
var xcrmyren = GetInputConstructorValue("xcrmyren", loader);
                 if(xcrmyren["original"].length == 0)
                 {
                   Invalid("avtoupdate" + " is empty");
                   return;
                 }
var ouubbkld = GetInputConstructorValue("ouubbkld", loader);
                 if(ouubbkld["original"].length == 0)
                 {
                   Invalid("button_id" + " is empty");
                   return;
                 }
var ttefmxrm = GetInputConstructorValue("ttefmxrm", loader);
                 if(ttefmxrm["original"].length == 0)
                 {
                   Invalid("coef" + " is empty");
                   return;
                 }
var qvdzoffj = GetInputConstructorValue("qvdzoffj", loader);
                 if(qvdzoffj["original"].length == 0)
                 {
                   Invalid("image id" + " is empty");
                   return;
                 }
var cdtzqpds = GetInputConstructorValue("cdtzqpds", loader);
                 if(cdtzqpds["original"].length == 0)
                 {
                   Invalid("key" + " is empty");
                   return;
                 }
var xnxvojqs = GetInputConstructorValue("xnxvojqs", loader);
                 if(xnxvojqs["original"].length == 0)
                 {
                   Invalid("pixel_koef" + " is empty");
                   return;
                 }
var tqwnvdbr = GetInputConstructorValue("tqwnvdbr", loader);
                 if(tqwnvdbr["original"].length == 0)
                 {
                   Invalid("reload_id" + " is empty");
                   return;
                 }
var xpkkensr = GetInputConstructorValue("xpkkensr", loader);
                 if(xpkkensr["original"].length == 0)
                 {
                   Invalid("speed" + " is empty");
                   return;
                 }
var aiuroemy = GetInputConstructorValue("aiuroemy", loader);
                 if(aiuroemy["original"].length == 0)
                 {
                   Invalid("type_slide" + " is empty");
                   return;
                 }
var mpkaeigf = GetInputConstructorValue("mpkaeigf", loader);
                 if(mpkaeigf["original"].length == 0)
                 {
                   Invalid("type_swipe" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SliderSolver_code").html())({"zxivfdua": zxivfdua["updated"],"xcrmyren": xcrmyren["updated"],"ouubbkld": ouubbkld["updated"],"ttefmxrm": ttefmxrm["updated"],"qvdzoffj": qvdzoffj["updated"],"cdtzqpds": cdtzqpds["updated"],"xnxvojqs": xnxvojqs["updated"],"tqwnvdbr": tqwnvdbr["updated"],"xpkkensr": xpkkensr["updated"],"aiuroemy": aiuroemy["updated"],"mpkaeigf": mpkaeigf["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
