_call_function(GoodXevilPaySolver_GXP_IMAGE_BASE64,{ "APIKEY": (<%= vhsiitpk %>),"IMAGE_BASE64": (<%= jonelsxk %>) })!
<%= variable %> = _result_function()
