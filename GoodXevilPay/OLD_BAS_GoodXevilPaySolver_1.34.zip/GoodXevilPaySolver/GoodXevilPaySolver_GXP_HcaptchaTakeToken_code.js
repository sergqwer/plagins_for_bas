_call_function(GoodXevilPaySolver_GXP_HcaptchaTakeToken,{ "APIKEY": (<%= mqtxtapn %>),"site_url": (<%= oxcxpqbq %>),"sitekey": (<%= gccxcnvs %>) })!
<%= variable %> = _result_function()
