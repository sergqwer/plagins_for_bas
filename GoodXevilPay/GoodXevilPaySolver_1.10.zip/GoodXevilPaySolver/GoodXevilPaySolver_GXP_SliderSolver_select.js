var ftgxziuv = GetInputConstructorValue("ftgxziuv", loader);
                 if(ftgxziuv["original"].length == 0)
                 {
                   Invalid("arrow_id" + " is empty");
                   return;
                 }
var ueopcgaa = GetInputConstructorValue("ueopcgaa", loader);
                 if(ueopcgaa["original"].length == 0)
                 {
                   Invalid("avtoupdate" + " is empty");
                   return;
                 }
var tttyarkb = GetInputConstructorValue("tttyarkb", loader);
                 if(tttyarkb["original"].length == 0)
                 {
                   Invalid("button_id" + " is empty");
                   return;
                 }
var fvudvimd = GetInputConstructorValue("fvudvimd", loader);
                 if(fvudvimd["original"].length == 0)
                 {
                   Invalid("coef" + " is empty");
                   return;
                 }
var tbfqokxq = GetInputConstructorValue("tbfqokxq", loader);
                 if(tbfqokxq["original"].length == 0)
                 {
                   Invalid("image id" + " is empty");
                   return;
                 }
var ccqngdcs = GetInputConstructorValue("ccqngdcs", loader);
                 if(ccqngdcs["original"].length == 0)
                 {
                   Invalid("key" + " is empty");
                   return;
                 }
var dboyxvgc = GetInputConstructorValue("dboyxvgc", loader);
                 if(dboyxvgc["original"].length == 0)
                 {
                   Invalid("pixel_koef" + " is empty");
                   return;
                 }
var kbfnstdt = GetInputConstructorValue("kbfnstdt", loader);
                 if(kbfnstdt["original"].length == 0)
                 {
                   Invalid("reload_id" + " is empty");
                   return;
                 }
var iyjnrxqq = GetInputConstructorValue("iyjnrxqq", loader);
                 if(iyjnrxqq["original"].length == 0)
                 {
                   Invalid("speed" + " is empty");
                   return;
                 }
var nattpwwo = GetInputConstructorValue("nattpwwo", loader);
                 if(nattpwwo["original"].length == 0)
                 {
                   Invalid("type_slide" + " is empty");
                   return;
                 }
var knrduucf = GetInputConstructorValue("knrduucf", loader);
                 if(knrduucf["original"].length == 0)
                 {
                   Invalid("type_swipe" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SliderSolver_code").html())({"ftgxziuv": ftgxziuv["updated"],"ueopcgaa": ueopcgaa["updated"],"tttyarkb": tttyarkb["updated"],"fvudvimd": fvudvimd["updated"],"tbfqokxq": tbfqokxq["updated"],"ccqngdcs": ccqngdcs["updated"],"dboyxvgc": dboyxvgc["updated"],"kbfnstdt": kbfnstdt["updated"],"iyjnrxqq": iyjnrxqq["updated"],"nattpwwo": nattpwwo["updated"],"knrduucf": knrduucf["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
