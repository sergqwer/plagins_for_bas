_call_function(GoodXevilPaySolver_GXP_HcaptchaTakeToken,{ "APIKEY": (<%= xyfbbpxv %>),"site_url": (<%= kylvrevz %>),"sitekey": (<%= wjowmvhz %>) })!
<%= variable %> = _result_function()
