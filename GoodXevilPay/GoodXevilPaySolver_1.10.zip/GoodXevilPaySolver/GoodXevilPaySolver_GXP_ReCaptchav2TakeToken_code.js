_call_function(GoodXevilPaySolver_GXP_ReCaptchav2TakeToken,{ "APIKEY": (<%= phjmxrpn %>),"site_url": (<%= uuzrobdx %>),"sitekey": (<%= bbfdthww %>) })!
<%= variable %> = _result_function()
