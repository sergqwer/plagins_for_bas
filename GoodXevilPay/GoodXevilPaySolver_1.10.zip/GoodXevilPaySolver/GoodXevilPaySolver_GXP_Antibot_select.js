var qtlbqehc = GetInputConstructorValue("qtlbqehc", loader);
                 if(qtlbqehc["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var mpujbmab = GetInputConstructorValue("mpujbmab", loader);
                 if(mpujbmab["original"].length == 0)
                 {
                   Invalid("mouse" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_Antibot_code").html())({"qtlbqehc": qtlbqehc["updated"],"mpujbmab": mpujbmab["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
