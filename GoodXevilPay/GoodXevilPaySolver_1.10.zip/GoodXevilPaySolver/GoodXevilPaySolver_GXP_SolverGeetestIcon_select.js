var lxacuubw = GetInputConstructorValue("lxacuubw", loader);
                 if(lxacuubw["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var xofjxlsn = GetInputConstructorValue("xofjxlsn", loader);
                 if(xofjxlsn["original"].length == 0)
                 {
                   Invalid("button_capthca" + " is empty");
                   return;
                 }
var tfjmffir = GetInputConstructorValue("tfjmffir", loader);
                 if(tfjmffir["original"].length == 0)
                 {
                   Invalid("captcha_submit" + " is empty");
                   return;
                 }
var uxooranc = GetInputConstructorValue("uxooranc", loader);
                 if(uxooranc["original"].length == 0)
                 {
                   Invalid("foto_captcha" + " is empty");
                   return;
                 }
var orndtuwh = GetInputConstructorValue("orndtuwh", loader);
                 if(orndtuwh["original"].length == 0)
                 {
                   Invalid("reload_captcha" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SolverGeetestIcon_code").html())({"lxacuubw": lxacuubw["updated"],"xofjxlsn": xofjxlsn["updated"],"tfjmffir": tfjmffir["updated"],"uxooranc": uxooranc["updated"],"orndtuwh": orndtuwh["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
