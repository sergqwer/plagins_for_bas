var yxlvghrx = GetInputConstructorValue("yxlvghrx", loader);
                 if(yxlvghrx["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var furwvlji = GetInputConstructorValue("furwvlji", loader);
                 if(furwvlji["original"].length == 0)
                 {
                   Invalid("timer" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_BuxMoney_PayupVideo_code").html())({"yxlvghrx": yxlvghrx["updated"],"furwvlji": furwvlji["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
