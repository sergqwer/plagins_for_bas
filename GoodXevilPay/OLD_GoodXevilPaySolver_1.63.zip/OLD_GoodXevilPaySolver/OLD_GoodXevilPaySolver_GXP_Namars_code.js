_call_function(OLD_GoodXevilPaySolver_GXP_Namars,{ "apikey": (<%= elbizlkh %>) })!
<%= variable %> = _result_function()
