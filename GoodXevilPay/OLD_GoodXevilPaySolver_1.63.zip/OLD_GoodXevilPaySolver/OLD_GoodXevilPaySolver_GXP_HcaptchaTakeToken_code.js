_call_function(OLD_GoodXevilPaySolver_GXP_HcaptchaTakeToken,{ "APIKEY": (<%= rkarmxxu %>),"site_url": (<%= xsljzssv %>),"sitekey": (<%= fknulvle %>) })!
<%= variable %> = _result_function()
