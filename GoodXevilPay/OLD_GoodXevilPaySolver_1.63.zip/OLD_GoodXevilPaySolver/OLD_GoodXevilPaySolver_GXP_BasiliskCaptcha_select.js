var wsyhijvv = GetInputConstructorValue("wsyhijvv", loader);
                 if(wsyhijvv["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var byqoltsj = GetInputConstructorValue("byqoltsj", loader);
                 if(byqoltsj["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var qvqfmdua = GetInputConstructorValue("qvqfmdua", loader);
                 if(qvqfmdua["original"].length == 0)
                 {
                   Invalid("siteurl" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#OLD_GoodXevilPaySolver_GXP_BasiliskCaptcha_code").html())({"wsyhijvv": wsyhijvv["updated"],"byqoltsj": byqoltsj["updated"],"qvqfmdua": qvqfmdua["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
