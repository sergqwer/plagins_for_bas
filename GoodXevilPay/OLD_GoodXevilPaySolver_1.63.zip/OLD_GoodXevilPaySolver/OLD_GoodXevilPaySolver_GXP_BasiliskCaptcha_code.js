_call_function(OLD_GoodXevilPaySolver_GXP_BasiliskCaptcha,{ "apikey": (<%= wsyhijvv %>),"sitekey": (<%= byqoltsj %>),"siteurl": (<%= qvqfmdua %>) })!
