var uyepcpzy = GetInputConstructorValue("uyepcpzy", loader);
                 if(uyepcpzy["original"].length == 0)
                 {
                   Invalid("arrow_id" + " is empty");
                   return;
                 }
var ltoucfgl = GetInputConstructorValue("ltoucfgl", loader);
                 if(ltoucfgl["original"].length == 0)
                 {
                   Invalid("avtoupdate" + " is empty");
                   return;
                 }
var wussnkwn = GetInputConstructorValue("wussnkwn", loader);
                 if(wussnkwn["original"].length == 0)
                 {
                   Invalid("button_id" + " is empty");
                   return;
                 }
var hidaxwqm = GetInputConstructorValue("hidaxwqm", loader);
                 if(hidaxwqm["original"].length == 0)
                 {
                   Invalid("coef" + " is empty");
                   return;
                 }
var iepcdgcu = GetInputConstructorValue("iepcdgcu", loader);
                 if(iepcdgcu["original"].length == 0)
                 {
                   Invalid("image id" + " is empty");
                   return;
                 }
var euvzmpwl = GetInputConstructorValue("euvzmpwl", loader);
                 if(euvzmpwl["original"].length == 0)
                 {
                   Invalid("key" + " is empty");
                   return;
                 }
var kxgvnllv = GetInputConstructorValue("kxgvnllv", loader);
                 if(kxgvnllv["original"].length == 0)
                 {
                   Invalid("pixel_koef" + " is empty");
                   return;
                 }
var fzezatir = GetInputConstructorValue("fzezatir", loader);
                 if(fzezatir["original"].length == 0)
                 {
                   Invalid("reload_id" + " is empty");
                   return;
                 }
var hkyaxnhb = GetInputConstructorValue("hkyaxnhb", loader);
                 if(hkyaxnhb["original"].length == 0)
                 {
                   Invalid("speed" + " is empty");
                   return;
                 }
var xpugxhtn = GetInputConstructorValue("xpugxhtn", loader);
                 if(xpugxhtn["original"].length == 0)
                 {
                   Invalid("type_slide" + " is empty");
                   return;
                 }
var egtkmvri = GetInputConstructorValue("egtkmvri", loader);
                 if(egtkmvri["original"].length == 0)
                 {
                   Invalid("type_swipe" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#OLD_GoodXevilPaySolver_GXP_SliderSolver_code").html())({"uyepcpzy": uyepcpzy["updated"],"ltoucfgl": ltoucfgl["updated"],"wussnkwn": wussnkwn["updated"],"hidaxwqm": hidaxwqm["updated"],"iepcdgcu": iepcdgcu["updated"],"euvzmpwl": euvzmpwl["updated"],"kxgvnllv": kxgvnllv["updated"],"fzezatir": fzezatir["updated"],"hkyaxnhb": hkyaxnhb["updated"],"xpugxhtn": xpugxhtn["updated"],"egtkmvri": egtkmvri["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
