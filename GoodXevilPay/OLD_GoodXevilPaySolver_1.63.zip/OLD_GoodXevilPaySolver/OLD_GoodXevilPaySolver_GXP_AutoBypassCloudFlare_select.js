var yvjywyag = GetInputConstructorValue("yvjywyag", loader);
                 if(yvjywyag["original"].length == 0)
                 {
                   Invalid("custom_button" + " is empty");
                   return;
                 }
var vsvhzqxj = GetInputConstructorValue("vsvhzqxj", loader);
                 if(vsvhzqxj["original"].length == 0)
                 {
                   Invalid("max_time" + " is empty");
                   return;
                 }
var cbakshkz = GetInputConstructorValue("cbakshkz", loader);
                 if(cbakshkz["original"].length == 0)
                 {
                   Invalid("whait_element" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#OLD_GoodXevilPaySolver_GXP_AutoBypassCloudFlare_code").html())({"yvjywyag": yvjywyag["updated"],"vsvhzqxj": vsvhzqxj["updated"],"cbakshkz": cbakshkz["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
