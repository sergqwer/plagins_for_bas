var jqkszwpm = GetInputConstructorValue("jqkszwpm", loader);
                 if(jqkszwpm["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var yubiycms = GetInputConstructorValue("yubiycms", loader);
                 if(yubiycms["original"].length == 0)
                 {
                   Invalid("timer" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#OLD_GoodXevilPaySolver_GXP_BuxMoney_PayupVideo_code").html())({"jqkszwpm": jqkszwpm["updated"],"yubiycms": yubiycms["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
