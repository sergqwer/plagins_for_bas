_call_function(OLD_GoodXevilPaySolver_GXP_ReCaptchav2TakeToken,{ "APIKEY": (<%= cfbpuwbz %>),"site_url": (<%= lnpplkak %>),"sitekey": (<%= vovqhbee %>) })!
<%= variable %> = _result_function()
