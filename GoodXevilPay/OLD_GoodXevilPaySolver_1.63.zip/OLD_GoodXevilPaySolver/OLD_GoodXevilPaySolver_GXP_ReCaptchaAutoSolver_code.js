_call_function(OLD_GoodXevilPaySolver_GXP_ReCaptchaAutoSolver,{ "apikey": (<%= lokqmvld %>) })!
