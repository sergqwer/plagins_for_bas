var ieumyald = GetInputConstructorValue("ieumyald", loader);
                 if(ieumyald["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var jlfkygck = GetInputConstructorValue("jlfkygck", loader);
                 if(jlfkygck["original"].length == 0)
                 {
                   Invalid("index" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#OLD_GoodXevilPaySolver_GXP_ReCaptcha_Bypass_No_Exten_code").html())({"ieumyald": ieumyald["updated"],"jlfkygck": jlfkygck["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
