var cfbpuwbz = GetInputConstructorValue("cfbpuwbz", loader);
                 if(cfbpuwbz["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var lnpplkak = GetInputConstructorValue("lnpplkak", loader);
                 if(lnpplkak["original"].length == 0)
                 {
                   Invalid("site_url" + " is empty");
                   return;
                 }
var vovqhbee = GetInputConstructorValue("vovqhbee", loader);
                 if(vovqhbee["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#OLD_GoodXevilPaySolver_GXP_ReCaptchav2TakeToken_code").html())({"cfbpuwbz": cfbpuwbz["updated"],"lnpplkak": lnpplkak["updated"],"vovqhbee": vovqhbee["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
