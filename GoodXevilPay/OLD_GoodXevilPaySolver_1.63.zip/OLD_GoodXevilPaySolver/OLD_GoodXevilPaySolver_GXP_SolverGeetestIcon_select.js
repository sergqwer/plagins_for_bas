var cptjejhm = GetInputConstructorValue("cptjejhm", loader);
                 if(cptjejhm["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var xsdlkpsg = GetInputConstructorValue("xsdlkpsg", loader);
                 if(xsdlkpsg["original"].length == 0)
                 {
                   Invalid("captcha_submit" + " is empty");
                   return;
                 }
var mejgdnql = GetInputConstructorValue("mejgdnql", loader);
                 if(mejgdnql["original"].length == 0)
                 {
                   Invalid("foto_captcha" + " is empty");
                   return;
                 }
var gphwttqp = GetInputConstructorValue("gphwttqp", loader);
                 if(gphwttqp["original"].length == 0)
                 {
                   Invalid("pixel_coef" + " is empty");
                   return;
                 }
var ckuxwirf = GetInputConstructorValue("ckuxwirf", loader);
                 if(ckuxwirf["original"].length == 0)
                 {
                   Invalid("reload_captcha" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#OLD_GoodXevilPaySolver_GXP_SolverGeetestIcon_code").html())({"cptjejhm": cptjejhm["updated"],"xsdlkpsg": xsdlkpsg["updated"],"mejgdnql": mejgdnql["updated"],"gphwttqp": gphwttqp["updated"],"ckuxwirf": ckuxwirf["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
