_call_function(OLD_GoodXevilPaySolver_GXP_AutoBypassCloudFlare,{ "custom_button": (<%= yvjywyag %>),"max_time": (<%= vsvhzqxj %>),"whait_element": (<%= cbakshkz %>) })!
