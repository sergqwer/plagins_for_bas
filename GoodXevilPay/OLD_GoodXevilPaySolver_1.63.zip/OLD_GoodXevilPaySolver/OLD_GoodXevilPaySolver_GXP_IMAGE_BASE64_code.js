_call_function(OLD_GoodXevilPaySolver_GXP_IMAGE_BASE64,{ "APIKEY": (<%= pbhophdy %>),"IMAGE_BASE64": (<%= xhvstvqj %>) })!
<%= variable %> = _result_function()
