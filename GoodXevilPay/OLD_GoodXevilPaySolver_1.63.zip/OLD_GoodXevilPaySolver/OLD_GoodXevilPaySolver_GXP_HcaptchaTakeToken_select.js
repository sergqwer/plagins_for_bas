var rkarmxxu = GetInputConstructorValue("rkarmxxu", loader);
                 if(rkarmxxu["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var xsljzssv = GetInputConstructorValue("xsljzssv", loader);
                 if(xsljzssv["original"].length == 0)
                 {
                   Invalid("site_url" + " is empty");
                   return;
                 }
var fknulvle = GetInputConstructorValue("fknulvle", loader);
                 if(fknulvle["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#OLD_GoodXevilPaySolver_GXP_HcaptchaTakeToken_code").html())({"rkarmxxu": rkarmxxu["updated"],"xsljzssv": xsljzssv["updated"],"fknulvle": fknulvle["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
