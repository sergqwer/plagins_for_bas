_call_function(GoodXevilPaySolver_GXP_AutoBypassCloudFlare,{ "custom_button": (<%= snghuavu %>),"max_time": (<%= lqwqlqvz %>),"whait_element": (<%= elvrmofw %>) })!
