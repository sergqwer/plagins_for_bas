var serigmpd = GetInputConstructorValue("serigmpd", loader);
                 if(serigmpd["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var oghpzjjh = GetInputConstructorValue("oghpzjjh", loader);
                 if(oghpzjjh["original"].length == 0)
                 {
                   Invalid("site_url" + " is empty");
                   return;
                 }
var nmtbxltc = GetInputConstructorValue("nmtbxltc", loader);
                 if(nmtbxltc["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_HcaptchaTakeToken_code").html())({"serigmpd": serigmpd["updated"],"oghpzjjh": oghpzjjh["updated"],"nmtbxltc": nmtbxltc["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
