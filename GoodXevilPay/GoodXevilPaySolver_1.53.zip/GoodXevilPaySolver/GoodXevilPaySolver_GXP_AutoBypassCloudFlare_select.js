var snghuavu = GetInputConstructorValue("snghuavu", loader);
                 if(snghuavu["original"].length == 0)
                 {
                   Invalid("custom_button" + " is empty");
                   return;
                 }
var lqwqlqvz = GetInputConstructorValue("lqwqlqvz", loader);
                 if(lqwqlqvz["original"].length == 0)
                 {
                   Invalid("max_time" + " is empty");
                   return;
                 }
var elvrmofw = GetInputConstructorValue("elvrmofw", loader);
                 if(elvrmofw["original"].length == 0)
                 {
                   Invalid("whait_element" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_AutoBypassCloudFlare_code").html())({"snghuavu": snghuavu["updated"],"lqwqlqvz": lqwqlqvz["updated"],"elvrmofw": elvrmofw["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
