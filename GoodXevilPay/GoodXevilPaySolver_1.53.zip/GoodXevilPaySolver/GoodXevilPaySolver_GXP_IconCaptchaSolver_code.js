_call_function(GoodXevilPaySolver_GXP_IconCaptchaSolver,{ "apikey": (<%= nwhxaaiy %>) })!
