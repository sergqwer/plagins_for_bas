_call_function(GoodXevilPaySolver_GXP_IMAGE_BASE64,{ "APIKEY": (<%= trxjdlln %>),"IMAGE_BASE64": (<%= jlzlkfcz %>) })!
<%= variable %> = _result_function()
