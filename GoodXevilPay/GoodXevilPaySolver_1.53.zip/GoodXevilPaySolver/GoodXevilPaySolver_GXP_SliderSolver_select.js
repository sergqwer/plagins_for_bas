var kazxlzni = GetInputConstructorValue("kazxlzni", loader);
                 if(kazxlzni["original"].length == 0)
                 {
                   Invalid("arrow_id" + " is empty");
                   return;
                 }
var oaftenms = GetInputConstructorValue("oaftenms", loader);
                 if(oaftenms["original"].length == 0)
                 {
                   Invalid("avtoupdate" + " is empty");
                   return;
                 }
var cdonsttw = GetInputConstructorValue("cdonsttw", loader);
                 if(cdonsttw["original"].length == 0)
                 {
                   Invalid("button_id" + " is empty");
                   return;
                 }
var jswgpijb = GetInputConstructorValue("jswgpijb", loader);
                 if(jswgpijb["original"].length == 0)
                 {
                   Invalid("coef" + " is empty");
                   return;
                 }
var sbuzugjm = GetInputConstructorValue("sbuzugjm", loader);
                 if(sbuzugjm["original"].length == 0)
                 {
                   Invalid("image id" + " is empty");
                   return;
                 }
var udoiclix = GetInputConstructorValue("udoiclix", loader);
                 if(udoiclix["original"].length == 0)
                 {
                   Invalid("key" + " is empty");
                   return;
                 }
var zmoojwdh = GetInputConstructorValue("zmoojwdh", loader);
                 if(zmoojwdh["original"].length == 0)
                 {
                   Invalid("pixel_koef" + " is empty");
                   return;
                 }
var aycrvuie = GetInputConstructorValue("aycrvuie", loader);
                 if(aycrvuie["original"].length == 0)
                 {
                   Invalid("reload_id" + " is empty");
                   return;
                 }
var jdxucxgj = GetInputConstructorValue("jdxucxgj", loader);
                 if(jdxucxgj["original"].length == 0)
                 {
                   Invalid("speed" + " is empty");
                   return;
                 }
var sspwkbwr = GetInputConstructorValue("sspwkbwr", loader);
                 if(sspwkbwr["original"].length == 0)
                 {
                   Invalid("type_slide" + " is empty");
                   return;
                 }
var hpcqwavp = GetInputConstructorValue("hpcqwavp", loader);
                 if(hpcqwavp["original"].length == 0)
                 {
                   Invalid("type_swipe" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SliderSolver_code").html())({"kazxlzni": kazxlzni["updated"],"oaftenms": oaftenms["updated"],"cdonsttw": cdonsttw["updated"],"jswgpijb": jswgpijb["updated"],"sbuzugjm": sbuzugjm["updated"],"udoiclix": udoiclix["updated"],"zmoojwdh": zmoojwdh["updated"],"aycrvuie": aycrvuie["updated"],"jdxucxgj": jdxucxgj["updated"],"sspwkbwr": sspwkbwr["updated"],"hpcqwavp": hpcqwavp["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
