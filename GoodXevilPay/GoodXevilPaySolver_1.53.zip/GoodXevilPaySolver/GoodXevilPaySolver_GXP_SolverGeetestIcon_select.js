var ubtmgdnb = GetInputConstructorValue("ubtmgdnb", loader);
                 if(ubtmgdnb["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var huqaebhk = GetInputConstructorValue("huqaebhk", loader);
                 if(huqaebhk["original"].length == 0)
                 {
                   Invalid("captcha_submit" + " is empty");
                   return;
                 }
var rzcpvxey = GetInputConstructorValue("rzcpvxey", loader);
                 if(rzcpvxey["original"].length == 0)
                 {
                   Invalid("foto_captcha" + " is empty");
                   return;
                 }
var dmoxztdm = GetInputConstructorValue("dmoxztdm", loader);
                 if(dmoxztdm["original"].length == 0)
                 {
                   Invalid("pixel_coef" + " is empty");
                   return;
                 }
var azecxnpo = GetInputConstructorValue("azecxnpo", loader);
                 if(azecxnpo["original"].length == 0)
                 {
                   Invalid("reload_captcha" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_SolverGeetestIcon_code").html())({"ubtmgdnb": ubtmgdnb["updated"],"huqaebhk": huqaebhk["updated"],"rzcpvxey": rzcpvxey["updated"],"dmoxztdm": dmoxztdm["updated"],"azecxnpo": azecxnpo["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
