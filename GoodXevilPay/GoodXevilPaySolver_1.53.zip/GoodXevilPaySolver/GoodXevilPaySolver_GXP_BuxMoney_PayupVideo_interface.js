<div class="container-fluid">
<%= _.template($('#input_constructor').html())({id:"kxyslpug", description:"apikey", default_selector: "string", disable_int:true, value_string: "", help: {description: "apikey с сервиса \nhttps://t.me/Xevil_check_bot"} }) %>
<%= _.template($('#input_constructor').html())({id:"hlsnirgv", description:"timer", default_selector: "int", disable_expression:true, disable_string:true, value_number: 4, min_number:-999999, max_number:999999, help: {description: "Сколько секунд ждать появление капчи"} }) %>
</div>
<div class="tooltipinternal">
<div class="tr tooltip-paragraph-first-fold">Данный модуль решает капчу с сайтов BuxMoney/PayupVideo через сервис https://t.me/Xevil_check_bot</div>
</div>
<%= _.template($('#back').html())({action:"executeandadd", visible:true}) %>
