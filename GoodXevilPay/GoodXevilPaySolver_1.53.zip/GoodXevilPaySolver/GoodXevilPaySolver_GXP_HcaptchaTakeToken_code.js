_call_function(GoodXevilPaySolver_GXP_HcaptchaTakeToken,{ "APIKEY": (<%= serigmpd %>),"site_url": (<%= oghpzjjh %>),"sitekey": (<%= nmtbxltc %>) })!
<%= variable %> = _result_function()
