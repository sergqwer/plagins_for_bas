var dbmnqrwq = GetInputConstructorValue("dbmnqrwq", loader);
                 if(dbmnqrwq["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var vodxugrv = GetInputConstructorValue("vodxugrv", loader);
                 if(vodxugrv["original"].length == 0)
                 {
                   Invalid("site_url" + " is empty");
                   return;
                 }
var jbhhljsh = GetInputConstructorValue("jbhhljsh", loader);
                 if(jbhhljsh["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#GoodXevilPaySolver_GXP_ReCaptchav2TakeToken_code").html())({"dbmnqrwq": dbmnqrwq["updated"],"vodxugrv": vodxugrv["updated"],"jbhhljsh": jbhhljsh["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
