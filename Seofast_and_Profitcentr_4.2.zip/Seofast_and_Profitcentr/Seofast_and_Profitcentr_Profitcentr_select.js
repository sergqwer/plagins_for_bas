var lhkhdqpz = GetInputConstructorValue("lhkhdqpz", loader);
                 if(lhkhdqpz["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#Seofast_and_Profitcentr_Profitcentr_code").html())({"lhkhdqpz": lhkhdqpz["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
