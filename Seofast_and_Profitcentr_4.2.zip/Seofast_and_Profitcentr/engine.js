function Seofast_and_Profitcentr_Profitcentr()
   {
   
      
      
      VAR_APIKEY = _function_argument("apikey")
      

      
      
      VAR_ERROR_FATAL = 0
      

      
      
      _do(function(){
      _set_action_info({ name: "For" });
      VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
      if(VAR_CYCLE_INDEX > parseInt(6))_break();
      
         
         
         _set_if_expression("W1tDWUNMRV9JTkRFWF1dID49IDY=");
         _if(VAR_CYCLE_INDEX >= 6,function(){
         
            
            
            fail_user("Не получилось решить капчу за 6 раз",false)
            

         })!
         

         
         
         _call(function()
         {
         _on_fail(function(){
         VAR_LAST_ERROR = _result()
         VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
         VAR_WAS_ERROR = false
         _break(1,true)
         })
         CYCLES.Current().RemoveLabel("function")
         
            
            
            VAR_LIST_SCREENSHOTS = []
            

            
            
            /*Browser*/
            page().script("document.documentElement.outerHTML")!
            VAR_SAVED_PAGE_HTML = _result()
            

            
            
            html_parser_xpath_parse(VAR_SAVED_PAGE_HTML)
            VAR_XPATH_XML_LIST = html_parser_xpath_xml_list("//*[contains(@class,\u0027out-capcha-lab\u0027)]")
            

            
            
            VAR_LIST_LENGTH = (VAR_XPATH_XML_LIST).length
            

            
            
            _do(function(){
            _set_action_info({ name: "While" });
            VAR_CYCLE_INDEX = _iterator() - 1
            BREAK_CONDITION = VAR_LIST_LENGTH == 0;
            if(!BREAK_CONDITION)_break();
            
               
               
               _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gMzA=");
               _if(VAR_CYCLE_INDEX > 30,function(){
               
                  
                  
                  fail_user("Не дождался капчи за 30 секунд",false)
                  

               })!
               

               
               
               sleep(1000)!
               

               
               
               /*Browser*/
               page().script("document.documentElement.outerHTML")!
               VAR_SAVED_PAGE_HTML = _result()
               

               
               
               html_parser_xpath_parse(VAR_SAVED_PAGE_HTML)
               VAR_XPATH_XML_LIST = html_parser_xpath_xml_list("//*[contains(@class,\u0027out-capcha-lab\u0027)]")
               

               
               
               VAR_LIST_LENGTH = (VAR_XPATH_XML_LIST).length
               

            })!
            

            
            
            VAR_XPATH_XML_LIST = (function(){var seen = {}; return (VAR_XPATH_XML_LIST).filter(function(item) { return seen.hasOwnProperty(item) ? false : (seen[item] = true); });})();
            

            
            
            _do_with_params({"foreach_data":(VAR_XPATH_XML_LIST)},function(){
            _set_action_info({ name: "Foreach" });
            VAR_CYCLE_INDEX = _iterator() - 1
            if(VAR_CYCLE_INDEX > _cycle_param("foreach_data").length - 1)_break();
            VAR_FOREACH_DATA = _cycle_param("foreach_data")[VAR_CYCLE_INDEX]
            
               
               
               VAR_SCREENSHOT_BASE64 = VAR_FOREACH_DATA.split("base64,")[1].split(")")[0]
               

               
               
               VAR_LIST_SCREENSHOTS.push(VAR_SCREENSHOT_BASE64)
               

            })!
            

            
            
            html_parser_xpath_parse(VAR_SAVED_PAGE_HTML)
            if((true) && !html_parser_xpath_exist("//*[contains(@class,\u0027out-capcha-title\u0027)]"))
            fail("Can't resolve query " + "//*[contains(@class,\u0027out-capcha-title\u0027)]");
            VAR_CAPTCHA_TEXT = html_parser_xpath_text("//*[contains(@class,\u0027out-capcha-title\u0027)]")
            

            
            
            VAR_CAPTCHA_TEXT = _clean(VAR_CAPTCHA_TEXT, "\\t\\v", "\\r\\n\\f", true);
            

            
            
            _switch_http_client_main()
            general_timeout_next(15000)
            http_client_post("http://goodxevilpay.shop/in.php", ["method","profit","body_1",VAR_LIST_SCREENSHOTS[0],"body_2",VAR_LIST_SCREENSHOTS[1],"body_3",VAR_LIST_SCREENSHOTS[2],"body_4",VAR_LIST_SCREENSHOTS[3],"body_5",VAR_LIST_SCREENSHOTS[4],"body_6",VAR_LIST_SCREENSHOTS[5],"textinstructions",VAR_CAPTCHA_TEXT,"key",VAR_APIKEY], {"content-type":("multipart"), "encoding":("UTF-8"), "method":("POST"),headers:("")})!
            

            
            
            _switch_http_client_main()
            VAR_SAVED_CONTENT = http_client_encoded_content("utf-8")
            

            
            
            VAR_STRING_CONTAINS = Boolean(native("regexp", "ismatch", JSON.stringify({text: VAR_SAVED_CONTENT,regexp:"(ERROR)"})) == "true")
            

            
            
            _set_if_expression("W1tTVFJJTkdfQ09OVEFJTlNdXQ==");
            _if(typeof(VAR_STRING_CONTAINS) !== "undefined" ? (VAR_STRING_CONTAINS) : undefined,function(){
            
               
               
               fail_user("Произошла ошибка при распознавании капчи ",false)
               

            })!
            

            
            
            VAR_ID = VAR_SAVED_CONTENT.split("|")[1]
            

            
            
            _do(function(){
            _set_action_info({ name: "While" });
            VAR_CYCLE_INDEX = _iterator() - 1
            BREAK_CONDITION = true;
            if(!BREAK_CONDITION)_break();
            
               
               
               _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gMzA=");
               _if(VAR_CYCLE_INDEX > 30,function(){
               
                  
                  
                  fail_user("Сервис не распознал капчу за 30 секунд",false)
                  

               })!
               

               
               
               sleep(1000)!
               

               
               
               _switch_http_client_main()
               http_client_get2("http://goodxevilpay.shop/res.php?key=" + VAR_APIKEY + "\u0026id=" + VAR_ID,{method:("GET"),headers:("")})!
               

               
               
               _switch_http_client_main()
               VAR_SAVED_CONTENT = http_client_encoded_content("utf-8")
               

               
               
               _set_if_expression("W1tTQVZFRF9DT05URU5UXV0gIT0gIkNBUENIQV9OT1RfUkVBRFki");
               _if(VAR_SAVED_CONTENT != "CAPCHA_NOT_READY",function(){
               
                  
                  
                  _break("function")
                  

               })!
               

            })!
            

            
            
            VAR_STRING_CONTAINS = Boolean(native("regexp", "ismatch", JSON.stringify({text: VAR_SAVED_CONTENT,regexp:"(ERROR)"})) == "true")
            

            
            
            _set_if_expression("W1tTVFJJTkdfQ09OVEFJTlNdXQ==");
            _if(typeof(VAR_STRING_CONTAINS) !== "undefined" ? (VAR_STRING_CONTAINS) : undefined,function(){
            
               
               
               fail_user("Произошла ошибка при распознавании капчи ",false)
               

            })!
            

            
            
            VAR_IMAGES = VAR_SAVED_CONTENT.split("|")[1]
            

            
            
            VAR_IMAGES = VAR_IMAGES.split(",")
            

            
            
            _do_with_params({"foreach_data":(VAR_IMAGES)},function(){
            _set_action_info({ name: "Foreach" });
            VAR_CYCLE_INDEX = _iterator() - 1
            if(VAR_CYCLE_INDEX > _cycle_param("foreach_data").length - 1)_break();
            VAR_FOREACH_DATA = _cycle_param("foreach_data")[VAR_CYCLE_INDEX]
            
               
               
               VAR_ID = VAR_FOREACH_DATA - 1
               

               
               
               /*Browser*/
               _SELECTOR = " \u003eXPATH\u003e //label[@class=\u0022out-capcha-lab\u0022]\u003eAT\u003e" + VAR_ID;
               wait_element_visible(_SELECTOR)!
               _call(_random_point, {})!
               _if(_result().length > 0, function(){
               X = parseInt(_result().split(",")[0])
               Y = parseInt(_result().split(",")[1])
               mouse(X,Y)!
               })!
               

            })!
            

            
            
            _break("function")
            

         },null)!
         

         
         
         _set_if_expression("W1tXQVNfRVJST1JdXQ==");
         _if(typeof(VAR_WAS_ERROR) !== "undefined" ? (VAR_WAS_ERROR) : undefined,function(){
         
            
            
            page().script2("re_load_capcha();",JSON.stringify(_read_variables([])))!
            var _parse_result = JSON.parse(_result())
            _write_variables(JSON.parse(_parse_result.variables))
            if(!_parse_result.is_success)
            fail(_parse_result.error)
            

            
            
            sleep(1000)!
            

         })!
         

      })!
      

   }
   

function Seofast_and_Profitcentr_SeoFast()
   {
   
      
      
      VAR_APIKEY = _function_argument("apikey")
      

      
      
      VAR_ERROR_FATAL = 0
      

      
      
      _do(function(){
      _set_action_info({ name: "For" });
      VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
      if(VAR_CYCLE_INDEX > parseInt(6))_break();
      
         
         
         _set_if_expression("W1tDWUNMRV9JTkRFWF1dID49IDY=");
         _if(VAR_CYCLE_INDEX >= 6,function(){
         
            
            
            fail_user("Не получилось решить капчу за 6 раз",false)
            

         })!
         

         
         
         _call(function()
         {
         _on_fail(function(){
         VAR_LAST_ERROR = _result()
         VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
         VAR_WAS_ERROR = false
         _break(1,true)
         })
         CYCLES.Current().RemoveLabel("function")
         
            
            
            VAR_LIST_SCREENSHOTS = []
            

            
            
            /*Browser*/
            page().script("document.documentElement.outerHTML")!
            VAR_SAVED_PAGE_HTML = _result()
            

            
            
            html_parser_xpath_parse(VAR_SAVED_PAGE_HTML)
            VAR_XPATH_XML_LIST = html_parser_xpath_xml_list("//*[contains(@class,\u0027out-capcha-lab\u0027)]")
            

            
            
            VAR_LIST_LENGTH = (VAR_XPATH_XML_LIST).length
            

            
            
            _do(function(){
            _set_action_info({ name: "While" });
            VAR_CYCLE_INDEX = _iterator() - 1
            BREAK_CONDITION = VAR_LIST_LENGTH == 0;
            if(!BREAK_CONDITION)_break();
            
               
               
               _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gMzA=");
               _if(VAR_CYCLE_INDEX > 30,function(){
               
                  
                  
                  fail_user("Не дождался капчи за 30 секунд",false)
                  

               })!
               

               
               
               sleep(1000)!
               

               
               
               /*Browser*/
               page().script("document.documentElement.outerHTML")!
               VAR_SAVED_PAGE_HTML = _result()
               

               
               
               html_parser_xpath_parse(VAR_SAVED_PAGE_HTML)
               VAR_XPATH_XML_LIST = html_parser_xpath_xml_list("//*[contains(@class,\u0027out-capcha-lab\u0027)]")
               

               
               
               VAR_LIST_LENGTH = (VAR_XPATH_XML_LIST).length
               

            })!
            

            
            
            VAR_XPATH_XML_LIST = (function(){var seen = {}; return (VAR_XPATH_XML_LIST).filter(function(item) { return seen.hasOwnProperty(item) ? false : (seen[item] = true); });})();
            

            
            
            _do_with_params({"foreach_data":(VAR_XPATH_XML_LIST)},function(){
            _set_action_info({ name: "Foreach" });
            VAR_CYCLE_INDEX = _iterator() - 1
            if(VAR_CYCLE_INDEX > _cycle_param("foreach_data").length - 1)_break();
            VAR_FOREACH_DATA = _cycle_param("foreach_data")[VAR_CYCLE_INDEX]
            
               
               
               VAR_SCREENSHOT_BASE64 = VAR_FOREACH_DATA.split("base64,")[1].split(")")[0]
               

               
               
               VAR_LIST_SCREENSHOTS.push(VAR_SCREENSHOT_BASE64)
               

            })!
            

            
            
            html_parser_xpath_parse(VAR_SAVED_PAGE_HTML)
            if((true) && !html_parser_xpath_exist("//*[contains(@class,\u0027out-capcha-title\u0027)]"))
            fail("Can't resolve query " + "//*[contains(@class,\u0027out-capcha-title\u0027)]");
            VAR_CAPTCHA_TEXT = html_parser_xpath_text("//*[contains(@class,\u0027out-capcha-title\u0027)]")
            

            
            
            VAR_CAPTCHA_TEXT = _clean(VAR_CAPTCHA_TEXT, "\\t\\v", "\\r\\n\\f", true);
            

            
            
            _switch_http_client_main()
            general_timeout_next(15000)
            http_client_post("http://goodxevilpay.shop/in.php", ["method","seofast","body_1",VAR_LIST_SCREENSHOTS[0],"body_2",VAR_LIST_SCREENSHOTS[1],"body_3",VAR_LIST_SCREENSHOTS[2],"body_4",VAR_LIST_SCREENSHOTS[3],"body_5",VAR_LIST_SCREENSHOTS[4],"textinstructions",VAR_CAPTCHA_TEXT,"key",VAR_APIKEY], {"content-type":("multipart"), "encoding":("UTF-8"), "method":("POST"),headers:("")})!
            

            
            
            _switch_http_client_main()
            VAR_SAVED_CONTENT = http_client_encoded_content("utf-8")
            

            
            
            VAR_STRING_CONTAINS = Boolean(native("regexp", "ismatch", JSON.stringify({text: VAR_SAVED_CONTENT,regexp:"(ERROR)"})) == "true")
            

            
            
            _set_if_expression("W1tTVFJJTkdfQ09OVEFJTlNdXQ==");
            _if(typeof(VAR_STRING_CONTAINS) !== "undefined" ? (VAR_STRING_CONTAINS) : undefined,function(){
            
               
               
               fail_user("Произошла ошибка при распознавании капчи ",false)
               

            })!
            

            
            
            VAR_ID = VAR_SAVED_CONTENT.split("|")[1]
            

            
            
            _do(function(){
            _set_action_info({ name: "While" });
            VAR_CYCLE_INDEX = _iterator() - 1
            BREAK_CONDITION = true;
            if(!BREAK_CONDITION)_break();
            
               
               
               _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gMzA=");
               _if(VAR_CYCLE_INDEX > 30,function(){
               
                  
                  
                  fail_user("Сервис не распознал капчу за 30 секунд",false)
                  

               })!
               

               
               
               sleep(1000)!
               

               
               
               _switch_http_client_main()
               http_client_get2("http://goodxevilpay.shop/res.php?key=" + VAR_APIKEY + "\u0026id=" + VAR_ID,{method:("GET"),headers:("")})!
               

               
               
               _switch_http_client_main()
               VAR_SAVED_CONTENT = http_client_encoded_content("utf-8")
               

               
               
               _set_if_expression("W1tTQVZFRF9DT05URU5UXV0gIT0gIkNBUENIQV9OT1RfUkVBRFki");
               _if(VAR_SAVED_CONTENT != "CAPCHA_NOT_READY",function(){
               
                  
                  
                  _break("function")
                  

               })!
               

            })!
            

            
            
            VAR_STRING_CONTAINS = Boolean(native("regexp", "ismatch", JSON.stringify({text: VAR_SAVED_CONTENT,regexp:"(ERROR)"})) == "true")
            

            
            
            _set_if_expression("W1tTVFJJTkdfQ09OVEFJTlNdXQ==");
            _if(typeof(VAR_STRING_CONTAINS) !== "undefined" ? (VAR_STRING_CONTAINS) : undefined,function(){
            
               
               
               fail_user("Произошла ошибка при распознавании капчи ",false)
               

            })!
            

            
            
            VAR_IMAGES = VAR_SAVED_CONTENT.split("|")[1]
            

            
            
            VAR_IMAGES = VAR_IMAGES.split(",")
            

            
            
            _do_with_params({"foreach_data":(VAR_IMAGES)},function(){
            _set_action_info({ name: "Foreach" });
            VAR_CYCLE_INDEX = _iterator() - 1
            if(VAR_CYCLE_INDEX > _cycle_param("foreach_data").length - 1)_break();
            VAR_FOREACH_DATA = _cycle_param("foreach_data")[VAR_CYCLE_INDEX]
            
               
               
               VAR_ID = VAR_FOREACH_DATA - 1
               

               
               
               /*Browser*/
               _SELECTOR = " \u003eXPATH\u003e //label[@class=\u0022out-capcha-lab\u0022]\u003eAT\u003e" + VAR_ID;
               wait_element_visible(_SELECTOR)!
               _call(_random_point, {})!
               _if(_result().length > 0, function(){
               X = parseInt(_result().split(",")[0])
               Y = parseInt(_result().split(",")[1])
               mouse(X,Y)!
               })!
               

            })!
            

            
            
            _break("function")
            

         },null)!
         

         
         
         _set_if_expression("W1tXQVNfRVJST1JdXQ==");
         _if(typeof(VAR_WAS_ERROR) !== "undefined" ? (VAR_WAS_ERROR) : undefined,function(){
         
            
            
            page().script2("reload_capcha();",JSON.stringify(_read_variables([])))!
            var _parse_result = JSON.parse(_result())
            _write_variables(JSON.parse(_parse_result.variables))
            if(!_parse_result.is_success)
            fail(_parse_result.error)
            

            
            
            sleep(1000)!
            

         })!
         

      })!
      

   }
   

