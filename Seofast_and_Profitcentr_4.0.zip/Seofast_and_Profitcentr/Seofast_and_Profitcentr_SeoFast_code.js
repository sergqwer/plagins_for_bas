_call_function(Seofast_and_Profitcentr_SeoFast,{ "apikey": (<%= mlyyfsfy %>) })!
