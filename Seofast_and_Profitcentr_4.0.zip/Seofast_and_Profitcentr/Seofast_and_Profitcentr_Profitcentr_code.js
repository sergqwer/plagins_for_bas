_call_function(Seofast_and_Profitcentr_Profitcentr,{ "apikey": (<%= kntgzldd %>) })!
