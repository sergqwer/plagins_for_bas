function Seofast_and_Profitcentr_Profitcentr()
   {
   
      
      
      VAR_APIKEY = _function_argument("apikey")
      

      
      
      VAR_ERROR_FATAL = 0
      

      
      
      _do(function(){
      _set_action_info({ name: "For" });
      VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
      if(VAR_CYCLE_INDEX > parseInt(6))_break();
      
         
         
         _set_if_expression("W1tDWUNMRV9JTkRFWF1dID49IDY=");
         _if(VAR_CYCLE_INDEX >= 6,function(){
         
            
            
            fail_user("ERROR",false)
            

         })!
         

         
         
         _call(function()
         {
         _on_fail(function(){
         VAR_LAST_ERROR = _result()
         VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
         VAR_WAS_ERROR = false
         _break(1,true)
         })
         CYCLES.Current().RemoveLabel("function")
         
            
            
            VAR_LIST_SCREENSHOTS = []
            

            
            
            _do(function(){
            _set_action_info({ name: "For" });
            VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(0)
            if(VAR_CYCLE_INDEX > parseInt(5))_break();
            
               
               
               /*Browser*/
               _SELECTOR = " \u003eXPATH\u003e //label[@class=\u0022out-capcha-lab\u0022]\u003eAT\u003e" + VAR_CYCLE_INDEX;
               wait_element(_SELECTOR)!
               get_element_selector(_SELECTOR, false).exist()!
               _if(_result() == "1", function(){
               get_element_selector(_SELECTOR, false).render_base64()!
               VAR_SCREENSHOT_BASE64 = _result()
               })!
               

               
               
               VAR_LIST_SCREENSHOTS.push(VAR_SCREENSHOT_BASE64)
               

            })!
            

            
            
            /*Browser*/
            _SELECTOR = " \u003eCSS\u003e .out-capcha-title";
            wait_element(_SELECTOR)!
            get_element_selector(_SELECTOR, false).text()!
            VAR_CAPTCHA_TEXT = _result()
            

            
            
            VAR_CAPTCHA_TEXT = _clean(VAR_CAPTCHA_TEXT, "\\t\\v", "\\r\\n\\f", true);
            

            
            
            _switch_http_client_main()
            general_timeout_next(15000)
            http_client_post("http://goodxevilpay.shop/in.php", ["method","profit","body_1",VAR_LIST_SCREENSHOTS[0],"body_2",VAR_LIST_SCREENSHOTS[1],"body_3",VAR_LIST_SCREENSHOTS[2],"body_4",VAR_LIST_SCREENSHOTS[3],"body_5",VAR_LIST_SCREENSHOTS[4],"body_6",VAR_LIST_SCREENSHOTS[5],"textinstructions",VAR_CAPTCHA_TEXT,"key",VAR_APIKEY], {"content-type":("multipart"), "encoding":("UTF-8"), "method":("POST"),headers:("")})!
            

            
            
            _switch_http_client_main()
            VAR_SAVED_CONTENT = http_client_encoded_content("utf-8")
            

            
            
            VAR_ID = VAR_SAVED_CONTENT.split("|")[1]
            

            
            
            sleep(1000)!
            

            
            
            _switch_http_client_main()
            http_client_get2("http://goodxevilpay.shop/res.php?key=" + VAR_APIKEY + "\u0026id=" + VAR_ID,{method:("GET"),headers:("")})!
            

            
            
            _switch_http_client_main()
            VAR_SAVED_CONTENT = http_client_encoded_content("utf-8")
            

            
            
            VAR_IMAGES = VAR_SAVED_CONTENT.split("|")[1]
            

            
            
            VAR_IMAGES = VAR_IMAGES.split(",")
            

            
            
            _do_with_params({"foreach_data":(VAR_IMAGES)},function(){
            _set_action_info({ name: "Foreach" });
            VAR_CYCLE_INDEX = _iterator() - 1
            if(VAR_CYCLE_INDEX > _cycle_param("foreach_data").length - 1)_break();
            VAR_FOREACH_DATA = _cycle_param("foreach_data")[VAR_CYCLE_INDEX]
            
               
               
               VAR_ID = VAR_FOREACH_DATA - 1
               

               
               
               /*Browser*/
               _SELECTOR = " \u003eXPATH\u003e //label[@class=\u0022out-capcha-lab\u0022]\u003eAT\u003e" + VAR_ID;
               wait_element_visible(_SELECTOR)!
               _call(_random_point, {})!
               _if(_result().length > 0, function(){
               X = parseInt(_result().split(",")[0])
               Y = parseInt(_result().split(",")[1])
               mouse(X,Y)!
               })!
               

            })!
            

            
            
            _break("function")
            

         },null)!
         

         
         
         _set_if_expression("W1tXQVNfRVJST1JdXQ==");
         _if(typeof(VAR_WAS_ERROR) !== "undefined" ? (VAR_WAS_ERROR) : undefined,function(){
         
            
            
            /*Browser*/
            _SELECTOR = " \u003eXPATH\u003e //span[@class=\u0022out-reload\u0022]";
            wait_element_visible(_SELECTOR)!
            _call(_random_point, {})!
            _if(_result().length > 0, function(){
            X = parseInt(_result().split(",")[0])
            Y = parseInt(_result().split(",")[1])
            mouse(X,Y)!
            })!
            

            
            
            _call(function()
            {
            _on_fail(function(){
            VAR_LAST_ERROR = _result()
            VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
            VAR_WAS_ERROR = false
            _break(1,true)
            })
            CYCLES.Current().RemoveLabel("function")
            
               
               
               /*Browser*/
               waiter_timeout_next(30000)
               wait_async_load()!
               

            },null)!
            

         })!
         

      })!
      

   }
   

function Seofast_and_Profitcentr_SeoFast()
   {
   
      
      
      VAR_APIKEY = _function_argument("apikey")
      

      
      
      VAR_ERROR_FATAL = 0
      

      
      
      _do(function(){
      _set_action_info({ name: "For" });
      VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
      if(VAR_CYCLE_INDEX > parseInt(6))_break();
      
         
         
         _set_if_expression("W1tDWUNMRV9JTkRFWF1dID49IDY=");
         _if(VAR_CYCLE_INDEX >= 6,function(){
         
            
            
            fail_user("ERROR",false)
            

         })!
         

         
         
         _call(function()
         {
         _on_fail(function(){
         VAR_LAST_ERROR = _result()
         VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
         VAR_WAS_ERROR = false
         _break(1,true)
         })
         CYCLES.Current().RemoveLabel("function")
         
            
            
            VAR_LIST_SCREENSHOTS = []
            

            
            
            _do(function(){
            _set_action_info({ name: "For" });
            VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(0)
            if(VAR_CYCLE_INDEX > parseInt(4))_break();
            
               
               
               /*Browser*/
               _SELECTOR = " \u003eXPATH\u003e //label[@class=\u0022out-capcha-lab\u0022]\u003eAT\u003e" + VAR_CYCLE_INDEX;
               wait_element(_SELECTOR)!
               get_element_selector(_SELECTOR, false).exist()!
               _if(_result() == "1", function(){
               get_element_selector(_SELECTOR, false).render_base64()!
               VAR_SCREENSHOT_BASE64 = _result()
               })!
               

               
               
               VAR_LIST_SCREENSHOTS.push(VAR_SCREENSHOT_BASE64)
               

               
               
               /*Browser*/
               ;_SELECTOR=" \u003eXPATH\u003e //label[@class=\u0022out-capcha-lab\u0022]\u003eAT\u003e" + VAR_CYCLE_INDEX;
               get_element_selector(_SELECTOR, false).nowait().exist()!
               VAR_IS_EXISTS = _result() == 1
               

            })!
            

            
            
            /*Browser*/
            _SELECTOR = " \u003eCSS\u003e .out-capcha-title";
            wait_element(_SELECTOR)!
            get_element_selector(_SELECTOR, false).text()!
            VAR_CAPTCHA_TEXT = _result()
            

            
            
            VAR_CAPTCHA_TEXT = _clean(VAR_CAPTCHA_TEXT, "\\t\\v", "\\r\\n\\f", true);
            

            
            
            _switch_http_client_main()
            general_timeout_next(15000)
            http_client_post("http://goodxevilpay.shop/in.php", ["method","seofast","body_1",VAR_LIST_SCREENSHOTS[0],"body_2",VAR_LIST_SCREENSHOTS[1],"body_3",VAR_LIST_SCREENSHOTS[2],"body_4",VAR_LIST_SCREENSHOTS[3],"body_5",VAR_LIST_SCREENSHOTS[4],"textinstructions",VAR_CAPTCHA_TEXT,"key",VAR_APIKEY], {"content-type":("multipart"), "encoding":("UTF-8"), "method":("POST"),headers:("")})!
            

            
            
            _switch_http_client_main()
            VAR_SAVED_CONTENT = http_client_encoded_content("utf-8")
            

            
            
            VAR_ID = VAR_SAVED_CONTENT.split("|")[1]
            

            
            
            sleep(1000)!
            

            
            
            _switch_http_client_main()
            http_client_get2("http://goodxevilpay.shop/res.php?key=" + VAR_APIKEY + "\u0026id=" + VAR_ID,{method:("GET"),headers:("")})!
            

            
            
            _switch_http_client_main()
            VAR_SAVED_CONTENT = http_client_encoded_content("utf-8")
            

            
            
            VAR_IMAGES = VAR_SAVED_CONTENT.split("|")[1]
            

            
            
            VAR_IMAGES = VAR_IMAGES.split(",")
            

            
            
            _do_with_params({"foreach_data":(VAR_IMAGES)},function(){
            _set_action_info({ name: "Foreach" });
            VAR_CYCLE_INDEX = _iterator() - 1
            if(VAR_CYCLE_INDEX > _cycle_param("foreach_data").length - 1)_break();
            VAR_FOREACH_DATA = _cycle_param("foreach_data")[VAR_CYCLE_INDEX]
            
               
               
               VAR_ID = VAR_FOREACH_DATA - 1
               

               
               
               /*Browser*/
               _SELECTOR = " \u003eXPATH\u003e //label[@class=\u0022out-capcha-lab\u0022]\u003eAT\u003e" + VAR_ID;
               wait_element_visible(_SELECTOR)!
               _call(_random_point, {})!
               _if(_result().length > 0, function(){
               X = parseInt(_result().split(",")[0])
               Y = parseInt(_result().split(",")[1])
               mouse(X,Y)!
               })!
               

            })!
            

         },null)!
         

         
         
         _set_if_expression("W1tXQVNfRVJST1JdXQ==");
         _if(typeof(VAR_WAS_ERROR) !== "undefined" ? (VAR_WAS_ERROR) : undefined,function(){
         
            
            
            /*Browser*/
            _SELECTOR = " \u003eXPATH\u003e //a[@class=\u0022fa fa-refresh\u0022]";
            wait_element_visible(_SELECTOR)!
            _call(_random_point, {})!
            _if(_result().length > 0, function(){
            X = parseInt(_result().split(",")[0])
            Y = parseInt(_result().split(",")[1])
            mouse(X,Y)!
            })!
            

            
            
            _call(function()
            {
            _on_fail(function(){
            VAR_LAST_ERROR = _result()
            VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
            VAR_WAS_ERROR = false
            _break(1,true)
            })
            CYCLES.Current().RemoveLabel("function")
            
               
               
               /*Browser*/
               waiter_timeout_next(30000)
               wait_async_load()!
               

            },null)!
            

         })!
         

      })!
      

   }
   

