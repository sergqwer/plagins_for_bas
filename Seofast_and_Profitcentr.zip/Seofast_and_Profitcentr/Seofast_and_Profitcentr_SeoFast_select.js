var qqwfolbl = GetInputConstructorValue("qqwfolbl", loader);
                 if(qqwfolbl["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#Seofast_and_Profitcentr_SeoFast_code").html())({"qqwfolbl": qqwfolbl["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
