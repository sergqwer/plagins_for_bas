var iodepnsd = GetInputConstructorValue("iodepnsd", loader);
                 if(iodepnsd["original"].length == 0)
                 {
                   Invalid("KEY" + " is empty");
                   return;
                 }
var dooglasb = GetInputConstructorValue("dooglasb", loader);
                 if(dooglasb["original"].length == 0)
                 {
                   Invalid("METHOD" + " is empty");
                   return;
                 }
var jkcqszxl = GetInputConstructorValue("jkcqszxl", loader);
                 if(jkcqszxl["original"].length == 0)
                 {
                   Invalid("SPEED_MOUSE" + " is empty");
                   return;
                 }
var ldsvthug = GetInputConstructorValue("ldsvthug", loader);
                 if(ldsvthug["original"].length == 0)
                 {
                   Invalid("TRY_MAX_CAPTCHA_PICTURE" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#CaptchaImageClick_TikTok_code").html())({"iodepnsd": iodepnsd["updated"],"dooglasb": dooglasb["updated"],"jkcqszxl": jkcqszxl["updated"],"ldsvthug": ldsvthug["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
