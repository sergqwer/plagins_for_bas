_call_function(Wait_Solver_Captcha_wait_solver_captcha,{  })!
