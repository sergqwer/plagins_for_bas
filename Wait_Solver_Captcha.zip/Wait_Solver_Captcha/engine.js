function Wait_Solver_Captcha_wait_solver_captcha()
   {
   
      
      
      VAR_IS_ERROR = 0
      

      
      
      _do(function(){
      _set_action_info({ name: "While" });
      VAR_CYCLE_INDEX = _iterator() - 1
      BREAK_CONDITION = true;
      if(!BREAK_CONDITION)_break();
      
         
         
         _set_if_expression("W1tJU19FUlJPUl1dID4gMTA=");
         _if(VAR_IS_ERROR > 10,function(){
         
            
            
            fail_user("Капча не решена",false)
            

         })!
         

         
         
         _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gMzAw");
         _if(VAR_CYCLE_INDEX > 300,function(){
         
            
            
            fail_user("Капча не решена за 3 минуты",false)
            

         })!
         

         
         
         /*Browser*/
         page().script("document.documentElement.outerHTML")!
         VAR_SAVED_PAGE_HTML = _result()
         

         
         
         html_parser_xpath_parse(VAR_SAVED_PAGE_HTML)
         VAR_CAPTCHA_SOLVED = html_parser_xpath_exist("//div[@class=\u0027captcha-solver-info\u0027 and text()=\u0027Captcha solved!\u0027]")
         

         
         
         _set_if_expression("W1tDQVBUQ0hBX1NPTFZFRF1d");
         _if(typeof(VAR_CAPTCHA_SOLVED) !== "undefined" ? (VAR_CAPTCHA_SOLVED) : undefined,function(){
         
            
            
            _break("function")
            

         })!
         

         
         
         html_parser_xpath_parse(VAR_SAVED_PAGE_HTML)
         VAR_CAPTCHA_IS = html_parser_xpath_exist("//div[@class=\u0027captcha-solver-info\u0027]")
         

         
         
         _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gMTAgJiYgW1tDQVBUQ0hBX0lTXV0gPT0gZmFsc2U=");
         _if(VAR_CYCLE_INDEX > 10 && VAR_CAPTCHA_IS == false,function(){
         
            
            
            _break("function")
            

         })!
         

         
         
         _set_if_expression("W1tDQVBUQ0hBX0lTXV0=");
         _if(typeof(VAR_CAPTCHA_IS) !== "undefined" ? (VAR_CAPTCHA_IS) : undefined,function(){
         
            
            
            html_parser_xpath_parse(VAR_SAVED_PAGE_HTML)
            if((false) && !html_parser_xpath_exist("//div[@class=\u0027captcha-solver-info\u0027]"))
            fail("Can't resolve query " + "//div[@class=\u0027captcha-solver-info\u0027]");
            VAR_XPATH_TEXT = html_parser_xpath_text("//div[@class=\u0027captcha-solver-info\u0027]")
            

            
            
            VAR_STRING_MATCHES = Boolean(native("regexp", "ismatch", JSON.stringify({text: VAR_XPATH_TEXT,regexp:"(ERROR)"})) == "true")
            

            
            
            _set_if_expression("W1tTVFJJTkdfTUFUQ0hFU11d");
            _if(typeof(VAR_STRING_MATCHES) !== "undefined" ? (VAR_STRING_MATCHES) : undefined,function(){
            
               
               
               VAR_IS_ERROR = parseInt(VAR_IS_ERROR) + parseInt(1)
               

            })!
            

            
            
            html_parser_xpath_parse(VAR_SAVED_PAGE_HTML)
            if((false) && !html_parser_xpath_exist("//div[@class=\u0027captcha-solver-info\u0027]"))
            fail("Can't resolve query " + "//div[@class=\u0027captcha-solver-info\u0027]");
            VAR_XPATH_TEXT = html_parser_xpath_text("//div[@class=\u0027captcha-solver-info\u0027]")
            

            
            
            VAR_STRING_MATCHES = Boolean(native("regexp", "ismatch", JSON.stringify({text: VAR_XPATH_TEXT,regexp:"(API)"})) == "true")
            

            
            
            _set_if_expression("W1tTVFJJTkdfTUFUQ0hFU11d");
            _if(typeof(VAR_STRING_MATCHES) !== "undefined" ? (VAR_STRING_MATCHES) : undefined,function(){
            
               
               
               VAR_IS_ERROR = parseInt(VAR_IS_ERROR) + parseInt(1)
               

            })!
            

         })!
         

         
         
         sleep(1000)!
         

      })!
      

   }
   

