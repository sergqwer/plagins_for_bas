try{
          var code = loader.GetAdditionalData() + _.template($("#Wait_Solver_Captcha_wait_solver_captcha_code").html())({});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
