var drsmsyww = GetInputConstructorValue("drsmsyww", loader);
                 if(drsmsyww["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var bterwmyr = GetInputConstructorValue("bterwmyr", loader);
                 if(bterwmyr["original"].length == 0)
                 {
                   Invalid("timer" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#BuxMoney_Solve_solve_captcha_code").html())({"drsmsyww": drsmsyww["updated"],"bterwmyr": bterwmyr["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
