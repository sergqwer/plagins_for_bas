function BuxMoney_Solve_solve_captcha()
   {
   
      
      
      VAR_TIMER = _function_argument("timer")
      

      
      
      VAR_APIKEY = _function_argument("apikey")
      

      
      
      VAR_URL = "127.0.0.1:10000"
      

      
      
      /*Browser*/
      ;_SELECTOR=" \u003eXPATH\u003e id(\u0022captcha\u0022)";
      get_element_selector(_SELECTOR, false).nowait().exist()!
      VAR_IS_EXISTS = _result() == 1
      _if(VAR_IS_EXISTS, function(){
      get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
      VAR_IS_EXISTS = _result().indexOf("true")>=0
      })!
      

      
      
      VAR_GOOD_SOLVE = "0"
      

      
      
      _do(function(){
      _set_action_info({ name: "While" });
      VAR_CYCLE_INDEX = _iterator() - 1
      BREAK_CONDITION = VAR_IS_EXISTS == false;
      if(!BREAK_CONDITION)_break();
      
         
         
         _set_if_expression("W1tDWUNMRV9JTkRFWF1dID49IFtbVElNRVJdXQ==");
         _if(VAR_CYCLE_INDEX >= VAR_TIMER,function(){
         
            
            
            fail_user("Капча не найдена",false)
            

         })!
         

         
         
         sleep(1000)!
         

         
         
         /*Browser*/
         ;_SELECTOR=" \u003eXPATH\u003e id(\u0022captcha\u0022)";
         get_element_selector(_SELECTOR, false).nowait().exist()!
         VAR_IS_EXISTS = _result() == 1
         _if(VAR_IS_EXISTS, function(){
         get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
         VAR_IS_EXISTS = _result().indexOf("true")>=0
         })!
         

      })!
      

      
      
      _do(function(){
      _set_action_info({ name: "While" });
      VAR_CYCLE_INDEX = _iterator() - 1
      BREAK_CONDITION = true;
      if(!BREAK_CONDITION)_break();
      
         
         
         _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gNCAmJiBbW0dPT0RfU09MVkVdXSAhPSAiMSI=");
         _if(VAR_CYCLE_INDEX > 4 && VAR_GOOD_SOLVE != "1",function(){
         
            
            
            fail_user("Капча не решена за 4 попытки",false)
            

         })!
         

         
         
         _set_if_expression("W1tDWUNMRV9JTkRFWF1dICE9IDA=");
         _if(VAR_CYCLE_INDEX != 0,function(){
         
            
            
            sleep(3000)!
            

         })!
         

         
         
         /*Browser*/
         ;_SELECTOR=" \u003eXPATH\u003e id(\u0022captcha\u0022)";
         get_element_selector(_SELECTOR, false).nowait().exist()!
         VAR_IS_EXISTS = _result() == 1
         _if(VAR_IS_EXISTS, function(){
         get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
         VAR_IS_EXISTS = _result().indexOf("true")>=0
         })!
         

         
         
         _set_if_expression("W1tJU19FWElTVFNdXSA9PSBmYWxzZQ==");
         _if(VAR_IS_EXISTS == false,function(){
         
            
            
            _set_if_expression("W1tHT09EX1NPTFZFXV0gPT0gIjEi");
            _if(VAR_GOOD_SOLVE == "1",function(){
            
               
               
               _break("function")
               

            })!
            

            
            
            sleep(4000)!
            

            
            
            _next("function")
            

         })!
         

         
         
         VAR_GOOD_SOLVE = "0"
         

         
         
         /*Browser*/
         ;_SELECTOR=" \u003eXPATH\u003e id(\u0022captcha\u0022)";
         get_element_selector(_SELECTOR, false).nowait().exist()!
         VAR_IS_EXISTS = _result() == 1
         _if(VAR_IS_EXISTS, function(){
         get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
         VAR_IS_EXISTS = _result().indexOf("true")>=0
         })!
         

         
         
         _set_if_expression("W1tJU19FWElTVFNdXSA9PSBmYWxzZQ==");
         _if(VAR_IS_EXISTS == false,function(){
         
            
            
            _next("function")
            

         })!
         

         
         
         /*Browser*/
         ;_SELECTOR=" \u003eCSS\u003e #captcha-alert";
         get_element_selector(_SELECTOR, false).nowait().exist()!
         VAR_IS_EXISTS = _result() == 1
         _if(VAR_IS_EXISTS, function(){
         get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
         VAR_IS_EXISTS = _result().indexOf("true")>=0
         })!
         

         
         
         _set_if_expression("W1tJU19FWElTVFNdXQ==");
         _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
         
            
            
            fail_user("Капча не решена, время решения истекло",false)
            

         })!
         

         
         
         /*Browser*/
         page().script("document.documentElement.outerHTML")!
         VAR_SAVED_PAGE_HTML = _result()
         

         
         
         html_parser_xpath_parse(VAR_SAVED_PAGE_HTML)
         if((false) && !html_parser_xpath_exist("//*[contains(@class,\u0027captcha-box\u0027) and @id=\u0027captcha\u0027]"))
         fail("Can't resolve query " + "//*[contains(@class,\u0027captcha-box\u0027) and @id=\u0027captcha\u0027]");
         VAR_SCREENSHOT_BASE64 = html_parser_xpath_xml("//*[contains(@class,\u0027captcha-box\u0027) and @id=\u0027captcha\u0027]")
         

         
         
         var regexp_result = native("regexp", "first", JSON.stringify({text: VAR_SCREENSHOT_BASE64,regexp:"\u0026quot;data:image/png;base64\u005c,([\u005cs\u005cS]+?)\u0026quot;"}))
         if(regexp_result.length == 0)
         regexp_result = []
         else
         regexp_result = JSON.parse(regexp_result)
         VAR_ALL_MATCH = regexp_result.pop()
         if(typeof(VAR_ALL_MATCH) == 'undefined' || !VAR_ALL_MATCH)
         VAR_ALL_MATCH = ""
         VAR_SCREENSHOT_BASE64 = regexp_result[0]
         if(typeof(VAR_SCREENSHOT_BASE64) == 'undefined' || !VAR_SCREENSHOT_BASE64)
         VAR_SCREENSHOT_BASE64 = ""
         if(regexp_result.length == 0)
         {
         VAR_SCREENSHOT_BASE64 = VAR_ALL_MATCH
         }
         

         
         
         _call(function()
         {
         _on_fail(function(){
         VAR_LAST_ERROR = _result()
         VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
         VAR_WAS_ERROR = false
         _break(1,true)
         })
         CYCLES.Current().RemoveLabel("function")
         
            
            
            _switch_http_client_main()
            http_client_post("http://" + VAR_URL + "/in.php", ["method","post","key",VAR_APIKEY,"method","buxmoney","body",VAR_SCREENSHOT_BASE64], {"content-type":("multipart"), "encoding":("UTF-8"), "method":("POST"),headers:("")})!
            

         },null)!
         

         
         
         _set_if_expression("W1tXQVNfRVJST1JdXQ==");
         _if(VAR_WAS_ERROR,function(){
         
            
            
            _next("function")
            

         })!
         

         
         
         /*Browser*/
         _SELECTOR = " \u003eXPATH\u003e id(\u0022captcha\u0022)";
         wait_element(_SELECTOR)!
         get_element_selector(_SELECTOR, false).script("(function(){var rect = self.getBoundingClientRect();return (rect.left + positionx).toString() + '|' + (rect.top + positiony).toString() + '|' + (rect.right - rect.left).toString() + '|' + (rect.bottom - rect.top).toString()})();")!
         if(_result().length > 0)
         {
         var split = _result().split("|")
         VAR_X = parseInt(split[0])
         VAR_Y = parseInt(split[1])
         VAR_WIDTH = parseInt(split[2])
         VAR_HEIGHT = parseInt(split[3])
         }
         

         
         
         _switch_http_client_main()
         VAR_SAVED_CONTENT = http_client_encoded_content("auto")
         

         
         
         VAR_STRING_CONTAINS = Boolean(native("regexp", "ismatch", JSON.stringify({text: VAR_SAVED_CONTENT,regexp:"(\u005c|)"})) == "true")
         

         
         
         _set_if_expression("W1tTVFJJTkdfQ09OVEFJTlNdXQ==");
         _if(typeof(VAR_STRING_CONTAINS) !== "undefined" ? (VAR_STRING_CONTAINS) : undefined,function(){
         
            
            
            sleep(1000)!
            

            
            
            VAR_ID = VAR_SAVED_CONTENT.split("|")[1]
            

            
            
            _switch_http_client_main()
            http_client_get2("http://" + VAR_URL + "/res.php?key=" + VAR_APIKEY + "\u0026id=" + VAR_ID,{method:("GET"),headers:("")})!
            

            
            
            _switch_http_client_main()
            VAR_SAVED_CONTENT = http_client_encoded_content("auto")
            

            
            
            _do(function(){
            _set_action_info({ name: "While" });
            VAR_CYCLE_INDEX = _iterator() - 1
            BREAK_CONDITION = VAR_SAVED_CONTENT == "CAPCHA_NOT_READY";
            if(!BREAK_CONDITION)_break();
            
               
               
               _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gMTU=");
               _if(VAR_CYCLE_INDEX > 15,function(){
               
                  
                  
                  fail_user("Сервис не решил капчу за 15 секунд",false)
                  

               })!
               

               
               
               sleep(1000)!
               

               
               
               _call(function()
               {
               _on_fail(function(){
               VAR_LAST_ERROR = _result()
               VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
               VAR_WAS_ERROR = false
               _break(1,true)
               })
               CYCLES.Current().RemoveLabel("function")
               
                  
                  
                  _switch_http_client_main()
                  http_client_get2("http://" + VAR_URL + "/res.php?key=" + VAR_APIKEY + "\u0026id=" + VAR_ID,{method:("GET"),headers:("")})!
                  

               },null)!
               

               
               
               _switch_http_client_main()
               VAR_SAVED_CONTENT = http_client_encoded_content("auto")
               

            })!
            

            
            
            VAR_STRING_CONTAINS = Boolean(native("regexp", "ismatch", JSON.stringify({text: VAR_SAVED_CONTENT,regexp:"(\u005c|)"})) == "true")
            

            
            
            _set_if_expression("W1tTVFJJTkdfQ09OVEFJTlNdXQ==");
            _if(typeof(VAR_STRING_CONTAINS) !== "undefined" ? (VAR_STRING_CONTAINS) : undefined,function(){
            
               
               
               VAR_SCAN_RESULT_LIST = native("regexp", "scan", JSON.stringify({text: VAR_SAVED_CONTENT,regexp:"(\u005cd+)"}))
               if(VAR_SCAN_RESULT_LIST.length == 0)
               VAR_SCAN_RESULT_LIST = []
               else
               VAR_SCAN_RESULT_LIST = JSON.parse(VAR_SCAN_RESULT_LIST)
               

               
               
               VAR_LIST_LENGTH = (VAR_SCAN_RESULT_LIST).length
               

               
               
               _set_if_expression("W1tMSVNUX0xFTkdUSF1dICE9IDI=");
               _if(VAR_LIST_LENGTH != 2,function(){
               
                  
                  
                  _next("function")
                  

               })!
               

               
               
               VAR_XIMG = parseInt(VAR_SCAN_RESULT_LIST[0]);
               VAR_YIMG = parseInt(VAR_SCAN_RESULT_LIST[1]);
               

               
               
               /*Browser*/
               ;_SELECTOR=" \u003eCSS\u003e #captcha-alert";
               get_element_selector(_SELECTOR, false).nowait().exist()!
               VAR_IS_EXISTS = _result() == 1
               _if(VAR_IS_EXISTS, function(){
               get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
               VAR_IS_EXISTS = _result().indexOf("true")>=0
               })!
               

               
               
               _set_if_expression("W1tJU19FWElTVFNdXQ==");
               _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
               
                  
                  
                  fail_user("Капча не решена, время решения истекло",false)
                  

               })!
               

               
               
               /*Browser*/
               move(VAR_X+VAR_XIMG,VAR_Y+VAR_YIMG,  {} )!
               mouse(VAR_X+VAR_XIMG,VAR_Y+VAR_YIMG)!
               

               
               
               VAR_GOOD_SOLVE = "1"
               

               
               
               sleep(4000)!
               

            })!
            

         })!
         

      })!
      

   }
   

