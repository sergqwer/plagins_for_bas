_call_function(BuxMoney_Solve_solve_captcha,{ "apikey": (<%= drsmsyww %>),"timer": (<%= bterwmyr %>) })!
