function CaptchaImageClick_YandexSmartCaptcha()
   {
   
      
      
      VAR_GLOBAL_SELECTOR = _function_argument("SELECTOR")
      

      
      
      VAR_KEY_MODULE = _function_argument("KEY")
      

      
      
      VAR_METHOD_MODULE = _function_argument("METHOD")
      

      
      
      VAR_TRY_NUMBER = _function_argument("ATTEMPTS_SOLVE")
      

      
      
      VAR_CYCLE_INDEX = 0
      

      
      
      VAR_ERROR_LOAD = "0"
      

      
      
      VAR_UNKNOWN_CAPTCHA = 0
      

      
      
      VAR_ERROR_GET_TASK = "0"
      

      
      
      VAR_ERROR_FIND_MAIN_SELECTOR = "0"
      

      
      
      VAR_RESULT_SELECTOR = 0
      

      
      
      VAR_ERROR_CAPTCHA_UNSOLVABLE_MODULE = 0
      

      
      
      VAR_YANDEXSMARTCAPTCHA_CLOSED = 0
      

      
      
      VAR_YANDEX_CAPTCHA_TYPE = 0
      

      
      
      VAR_BAS_MODULE_VERSION = "5.6"
      

      
      
      _call(function()
      {
      _on_fail(function(){
      VAR_LAST_ERROR = _result()
      VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
      VAR_WAS_ERROR = false
      _break(1,true)
      })
      CYCLES.Current().RemoveLabel("function")
      
         
         
         VAR_SELECTOR_1 = "Y2FwbW9uc3Rlcg=="
         

         
         
         VAR_SELECTOR_2 = "c2VydmVydXJs"
         

      },null)!
      

      
      
      VAR_GREEN_TICK = false
      

      
      
      /*Browser*/
      cache_allow("*captcha.yandex.net*")!
      

      
      
      _call(function()
      {
      _on_fail(function(){
      VAR_LAST_ERROR = _result()
      VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
      VAR_WAS_ERROR = false
      _break(1,true)
      })
      CYCLES.Current().RemoveLabel("function")
      
         
         
         VAR_IS_MOBILE = _IS_MOBILE;
         

         
         
         _set_if_expression("W1tJU19NT0JJTEVdXSA9PSBmYWxzZSAmJiByYW5kICgxLDEwKSA+IDM=");
         _if(VAR_IS_MOBILE == false && rand (1,10) > 3,function(){
         
            
            
            _do(function(){
            _set_action_info({ name: "While" });
            VAR_CYCLE_INDEX = _iterator() - 1
            BREAK_CONDITION = VAR_CYCLE_INDEX < 2;
            if(!BREAK_CONDITION)_break();
            
               
               
               _get_browser_screen_settings()!
               ;(function(){
               var result = JSON.parse(_result())
               VAR_SCROLL_X = result["ScrollX"]
               VAR_SCROLL_Y = result["ScrollY"]
               VAR_CURSOR_X = result["CursorX"]
               VAR_CURSOR_Y = result["CursorY"]
               VAR_BROWSER_WIDTH = result["Width"]
               VAR_BROWSER_HEIGHT = result["Height"]
               })();
               

               
               
               var scroll_x=parseInt(VAR_CURSOR_Y);
               var scroll_y=parseInt(VAR_SCROLL_Y);
               var browser_h=parseInt(VAR_BROWSER_HEIGHT);
               //-------------------- Привели все в числа, считаем позицию ---------------------
               var absolut_y = VAR_CURSOR_Y + VAR_SCROLL_Y;
               var y_without_scroll = absolut_y - VAR_SCROLL_Y;
               var check_y_top = VAR_BROWSER_HEIGHT/12;
               var check_y_down = VAR_BROWSER_HEIGHT/100*92;
               var move_y_top = VAR_BROWSER_HEIGHT/10;
               var move_y_down = VAR_BROWSER_HEIGHT/100*80;
               // -------------------------- Округляем ----------------------------------
               VAR_CHECK_Y_TOP = check_y_top.toFixed();
               VAR_CHECK_Y_DOWN = check_y_down.toFixed();
               VAR_Y_WITHOUNT_SCROLL = y_without_scroll.toFixed();
               VAR_MOVE_Y_TOP = move_y_top.toFixed();
               VAR_MOVE_Y_DOWN = move_y_down.toFixed();
               // ----------------- Снова приводим к числу ------------------------
               VAR_CHECK_Y_TOP=parseInt(VAR_CHECK_Y_TOP);
               VAR_CHECK_Y_DOWN=parseInt(VAR_CHECK_Y_DOWN);
               VAR_Y_WITHOUNT_SCROLL=parseInt(VAR_Y_WITHOUNT_SCROLL);
               VAR_MOVE_Y_TOP=parseInt(VAR_MOVE_Y_TOP);
               VAR_MOVE_Y_DOWN=parseInt(VAR_MOVE_Y_DOWN);
               

               
               
               /*Browser*/
               move(rand(VAR_BROWSER_WIDTH/5,VAR_BROWSER_WIDTH/1.3),rand(VAR_MOVE_Y_TOP + VAR_SCROLL_Y,VAR_MOVE_Y_DOWN + VAR_SCROLL_Y),  {} )!
               

               
               
               _set_if_expression("cmFuZCAoMSwxMCkgPiA1");
               _if(rand (1,10) > 5,function(){
               
                  
                  
                  _break("function")
                  

               })!
               

            })!
            

         })!
         

         
         
         _do(function(){
         _set_action_info({ name: "For" });
         VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
         if(VAR_CYCLE_INDEX > parseInt(40))_break();
         
            
            
            /*Browser*/
            ;_SELECTOR=VAR_GLOBAL_SELECTOR;
            get_element_selector(_SELECTOR, false).nowait().exist()!
            VAR_IS_EXISTS = _result() == 1
            _if(VAR_IS_EXISTS, function(){
            get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
            VAR_IS_EXISTS = _result().indexOf("true")>=0
            })!
            

            
            
            _cycle_params().if_else = typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined;
            _set_if_expression("W1tJU19FWElTVFNdXQ==");
            _if(_cycle_params().if_else,function(){
            
               
               
               _cycle_params().if_else = VAR_GLOBAL_SELECTOR == ">CSS> input[class*='CheckboxCaptcha-Button']";
               _set_if_expression("W1tHTE9CQUxfU0VMRUNUT1JdXSA9PSAiPkNTUz4gaW5wdXRbY2xhc3MqPSdDaGVja2JveENhcHRjaGEtQnV0dG9uJ10i");
               _if(_cycle_params().if_else,function(){
               
                  
                  
                  _get_browser_screen_settings()!
                  ;(function(){
                  var result = JSON.parse(_result())
                  VAR_SCROLL_X = result["ScrollX"]
                  VAR_SCROLL_Y = result["ScrollY"]
                  VAR_CURSOR_X = result["CursorX"]
                  VAR_CURSOR_Y = result["CursorY"]
                  VAR_BROWSER_WIDTH = result["Width"]
                  VAR_BROWSER_HEIGHT = result["Height"]
                  })();
                  

                  
                  
                  /*Browser*/
                  _SELECTOR = VAR_GLOBAL_SELECTOR;
                  wait_element(_SELECTOR)!
                  get_element_selector(_SELECTOR, false).script("(function(){var rect = _BAS_HIDE(BrowserAutomationStudio_GetBoundingClientRect)(self);return (rect.left + positionx) + '|' + (rect.top + positiony) + '|' + (rect.right - rect.left) + '|' + (rect.bottom - rect.top)})();")!
                  if(_result().length > 0)
                  {
                  var split = _result().split("|")
                  VAR_X_YANDEX = parseInt(split[0])
                  VAR_Y_YANDEX = parseInt(split[1])
                  VAR_WIDTH_YANDEX = parseInt(split[2])
                  VAR_HEIGHT_YANDEX = parseInt(split[3])
                  }
                  

                  
                  
                  function getRandomNonInteger(min, max) {
                  const random = Math.random() * (max - min) + min;
                  return Math.floor(random) !== random ? random : getRandomNonInteger(min, max);
                  }
                  VAR_X_YANDEX_MIN = getRandomNonInteger(2, 4);
                  VAR_Y_YANDEX_MIN = getRandomNonInteger(1.6, 3.5);
                  

                  
                  
                  /*Browser*/
                  move(VAR_SCROLL_X + VAR_X_YANDEX + VAR_WIDTH_YANDEX/VAR_X_YANDEX_MIN,VAR_SCROLL_Y + VAR_Y_YANDEX + VAR_HEIGHT_YANDEX/VAR_Y_YANDEX_MIN,  {} )!
                  mouse(VAR_SCROLL_X + VAR_X_YANDEX + VAR_WIDTH_YANDEX/VAR_X_YANDEX_MIN,VAR_SCROLL_Y + VAR_Y_YANDEX + VAR_HEIGHT_YANDEX/VAR_Y_YANDEX_MIN)!
                  

               })!
               

               
               
               _if(!_cycle_params().if_else,function(){
               
                  
                  
                  /*Browser*/
                  _SELECTOR = VAR_GLOBAL_SELECTOR;waiter_timeout_next(8000)
                  wait_element_visible(_SELECTOR)!
                  _call(_random_point, {})!
                  _if(_result().length > 0, function(){
                  move( {} )!
                  get_element_selector(_SELECTOR, false).clarify(X,Y)!
                  _call(_clarify, {} )!
                  mouse(X,Y)!
                  })!
                  

               })!
               delete _cycle_params().if_else;
               

               
               
               /*Browser*/
               _SELECTOR = VAR_GLOBAL_SELECTOR;
               wait_element(_SELECTOR)!
               get_element_selector(_SELECTOR, false).script("(function(){var rect = _BAS_HIDE(BrowserAutomationStudio_GetBoundingClientRect)(self);return (rect.left + positionx) + '|' + (rect.top + positiony) + '|' + (rect.right - rect.left) + '|' + (rect.bottom - rect.top)})();")!
               if(_result().length > 0)
               {
               var split = _result().split("|")
               VAR_X_YANDEX = parseInt(split[0])
               VAR_Y_YANDEX = parseInt(split[1])
               VAR_WIDTH_YANDEX = parseInt(split[2])
               VAR_HEIGHT_YANDEX = parseInt(split[3])
               }
               

               
               
               _break("function")
               

            })!
            

            
            
            _if(!_cycle_params().if_else,function(){
            
               
               
               sleep(rand(400,900))!
               

            })!
            delete _cycle_params().if_else;
            

            
            
            _set_if_expression("IVtbSVNfRVhJU1RTXV0=");
            _if(!VAR_IS_EXISTS,function(){
            
               
               
               _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gcmFuZCAoMjUsMzIp");
               _if(VAR_CYCLE_INDEX > rand (25,32),function(){
               
                  
                  
                  VAR_ERROR_FIND_MAIN_SELECTOR = "1"
                  

               })!
               

            })!
            

            
            
            /*Browser*/
            ;_SELECTOR="\u003eCSS\u003eimg[src*=\u0027/captchaimg\u0027]";
            get_element_selector(_SELECTOR, false).nowait().exist()!
            VAR_IS_EXISTS = _result() == 1
            

            
            
            _set_if_expression("W1tJU19FWElTVFNdXQ==");
            _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
            
               
               
               _break("function")
               

            })!
            

            
            
            sleep(rand(100,900))!
            

         })!
         

      },null)!
      

      
      
      _set_if_expression("W1tXQVNfRVJST1JdXQ==");
      _if(typeof(VAR_WAS_ERROR) !== "undefined" ? (VAR_WAS_ERROR) : undefined,function(){
      
         
         
         fail(VAR_LAST_ERROR)
         

      })!
      

      
      
      _set_if_expression("W1tFUlJPUl9GSU5EX01BSU5fU0VMRUNUT1JdXSA9PSAx");
      _if(VAR_ERROR_FIND_MAIN_SELECTOR == 1,function(){
      
         
         
         fail((_K==="en" ? "Could not wait for the main button YandexSmartCaptcha selector to load with the 'I am not robot'" : "Не удалось дождаться загрузки основного селектора YandexSmartCaptcha c кнопкой 'I am not robot'"));
         

      })!
      

      
      
      VAR_TRY_CAPTCHA = "0"
      

      
      
      VAR_CAPTCHA_FAIL = "0"
      

      
      
      VAR_ERROR_LOAD = "0"
      

      
      
      VAR_ERROR_KEY = "0"
      

      
      
      VAR_ERROR_BALANCE = "0"
      

      
      
      VAR_ERROR_LANG = "0"
      

      
      
      VAR_FIRST_LOAD_CAPTCHA = true
      

      
      
      VAR_FIRST_LOAD_BUTTON = false
      

      
      
      /// Селектор который передал юзер модулю приведем в нормальный вид
      get_selector_normal = function(s) {
      var e={},i,b=0,c,x,l=0,a,r='',w=String.fromCharCode,L=s.length;
      var A="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
      for(i=0;i<64;i++){e[A.charAt(i)]=i;}
      for(x=0;x<L;x++){
      c=e[s.charAt(x)];b=(b<<6)+c;l+=6;
      while(l>=8){((a=(b>>>(l-=8))&0xff)||(x<(L-2)))&&(r+=w(a));}
      }
      return r;
      };
      VAR_SELECTOR_1 = get_selector_normal(VAR_SELECTOR_1);
      VAR_SELECTOR_2 = get_selector_normal(VAR_SELECTOR_2);
      

      
      
      _do(function(){
      _set_action_info({ name: "For" });
      VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
      if(VAR_CYCLE_INDEX > parseInt(500))_break();
      
         
         
         VAR_CYCLE_INDEX = 0
         

         
         
         VAR_YANDEXSMARTCAPTCHA_CLOSED = 0
         

         
         
         VAR_ERROR_GET_TASK = "0"
         

         
         
         _set_if_expression("W1tFUlJPUl9LRVldXSA9PSAx");
         _if(VAR_ERROR_KEY == 1,function(){
         
            
            
            fail((_K==="en" ? "API secret key from captcha recognition service is wrong ERROR_WRONG_USER_KEY" : "Секретный ключ API от сервиса распознавания капчи неправильный ERROR_WRONG_USER_KEY"));
            

         })!
         

         
         
         _set_if_expression("W1tFUlJPUl9CQUxBTkNFXV0gPT0gMQ==");
         _if(VAR_ERROR_BALANCE == 1,function(){
         
            
            
            fail((_K==="en" ? "The balance on the captcha service has ended - ERROR_ZERO_BALANCE" : "Закончился баланс на сервисе распознавания капчи - ERROR_ZERO_BALANCE"));
            

         })!
         

         
         
         _set_if_expression("W1tDQVBUQ0hBX0ZBSUxdXSA+IDE=");
         _if(VAR_CAPTCHA_FAIL > 1,function(){
         
            
            
            /*Browser*/
            cache_data_clear()!
            

            
            
            fail((_K==="en" ? "Failed to solve YandexSmartCaptcha, reason - " +VAR_SAVED_CONTENT : "Не удалось решить YandexSmartCaptcha, причина - " +VAR_SAVED_CONTENT));
            

         })!
         

         
         
         _set_if_expression("W1tVTktOT1dOX0NBUFRDSEFdXSA+IDM=");
         _if(VAR_UNKNOWN_CAPTCHA > 3,function(){
         
            
            
            /*Browser*/
            cache_data_clear()!
            

            
            
            fail((_K==="en" ? "Failed to solve YandexSmartCaptcha. This captcha type is unknown" : "Не удалось решить YandexSmartCaptcha, загрузился неизвестный тип каптчи"));
            

         })!
         

         
         
         _set_if_expression("W1tFUlJPUl9DQVBUQ0hBX1VOU09MVkFCTEVfTU9EVUxFXV0gPiAx");
         _if(VAR_ERROR_CAPTCHA_UNSOLVABLE_MODULE > 1,function(){
         
            
            
            /*Browser*/
            cache_data_clear()!
            

            
            
            sleep(100)!
            

            
            
            fail((_K==="en" ? "YandexSmartCaptcha task or image type is not supported service CaptchaGuru, reason: ERROR_CAPTCHA_UNSOLVABLE" : "Решить каптчу не удалось - сервис CaptchaGuru не смог распознать несколько изображений подряд, причина: ERROR_CAPTCHA_UNSOLVABLE"));
            

         })!
         

         
         
         _do(function(){
         _set_action_info({ name: "For" });
         VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
         if(VAR_CYCLE_INDEX > parseInt(250))_break();
         
            
            
            /*Browser*/
            ;_SELECTOR=" \u003eXPATH\u003e //div[@class=\u0022AdvancedCaptcha-FormField\u0022]";
            get_element_selector(_SELECTOR, false).nowait().exist()!
            VAR_IS_EXISTS = _result() == 1
            _if(VAR_IS_EXISTS, function(){
            get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
            VAR_IS_EXISTS = _result().indexOf("true")>=0
            })!
            

            
            
            _set_if_expression("W1tJU19FWElTVFNdXQ==");
            _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
            
               
               
               VAR_YANDEX_CAPTCHA_TYPE = 1
               

               
               
               _break("function")
               

            })!
            

            
            
            /*Browser*/
            ;_SELECTOR=" \u003eXPATH\u003e //div[@class=\u0022AdvancedCaptcha-SihlouetteTask\u0022]";
            get_element_selector(_SELECTOR, false).nowait().exist()!
            VAR_IS_EXISTS_1 = _result() == 1
            _if(VAR_IS_EXISTS_1, function(){
            get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
            VAR_IS_EXISTS_1 = _result().indexOf("true")>=0
            })!
            

            
            
            _set_if_expression("W1tJU19FWElTVFNfMV1d");
            _if(typeof(VAR_IS_EXISTS_1) !== "undefined" ? (VAR_IS_EXISTS_1) : undefined,function(){
            
               
               
               VAR_YANDEX_CAPTCHA_TYPE = 2
               

               
               
               _break("function")
               

            })!
            

            
            
            /*Browser*/
            ;_SELECTOR=VAR_GLOBAL_SELECTOR;
            get_element_selector(_SELECTOR, false).nowait().exist()!
            VAR_IS_EXISTS_3 = _result() == 1
            _if(VAR_IS_EXISTS_3, function(){
            get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
            VAR_IS_EXISTS_3 = _result().indexOf("true")>=0
            })!
            

            
            
            _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gMTAgJiYgW1tGSVJTVF9MT0FEX0NBUFRDSEFdXSA9PSB0cnVlICYmIFtbUkVTVUxUX1NFTEVDVE9SXV0gIT0gMSAmJiBbW0lTX0VYSVNUU18zXV0gPT0gZmFsc2U=");
            _if(VAR_CYCLE_INDEX > 10 && VAR_FIRST_LOAD_CAPTCHA == true && VAR_RESULT_SELECTOR != 1 && VAR_IS_EXISTS_3 == false,function(){
            
               
               
               VAR_GREEN_TICK = true
               

               
               
               _break("function")
               

            })!
            

            
            
            _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gMTAgJiYgW1tGSVJTVF9MT0FEX0NBUFRDSEFdXSA9PSBmYWxzZSAmJiBbW0lTX0VYSVNUU11dID09IGZhbHNlICYmIFtbSVNfRVhJU1RTXzFdXSA9PSBmYWxzZQ==");
            _if(VAR_CYCLE_INDEX > 10 && VAR_FIRST_LOAD_CAPTCHA == false && VAR_IS_EXISTS == false && VAR_IS_EXISTS_1 == false,function(){
            
               
               
               VAR_GREEN_TICK = true
               

               
               
               _break("function")
               

            })!
            

            
            
            _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gMjUgJiYgW1tGSVJTVF9MT0FEX0JVVFRPTl1dID09IHRydWUgJiYgW1tSRVNVTFRfU0VMRUNUT1JdXSAhPSAx");
            _if(VAR_CYCLE_INDEX > 25 && VAR_FIRST_LOAD_BUTTON == true && VAR_RESULT_SELECTOR != 1,function(){
            
               
               
               VAR_FIRST_LOAD_BUTTON = false
               

               
               
               /*Browser*/
               ;_SELECTOR=VAR_GLOBAL_SELECTOR;
               get_element_selector(_SELECTOR, false).nowait().exist()!
               VAR_IS_EXISTS = _result() == 1
               _if(VAR_IS_EXISTS, function(){
               get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
               VAR_IS_EXISTS = _result().indexOf("true")>=0
               })!
               

               
               
               _set_if_expression("W1tJU19FWElTVFNdXQ==");
               _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
               
                  
                  
                  /*Browser*/
                  _SELECTOR = VAR_GLOBAL_SELECTOR;waiter_timeout_next(8000)
                  wait_element_visible(_SELECTOR)!
                  _call(_random_point, {})!
                  _if(_result().length > 0, function(){
                  move( {} )!
                  get_element_selector(_SELECTOR, false).clarify(X,Y)!
                  _call(_clarify, {} )!
                  mouse(X,Y)!
                  })!
                  

                  
                  
                  sleep(rand(2000,4000))!
                  

               })!
               

            })!
            

            
            
            _set_if_expression("W1tDWUNMRV9JTkRFWF1dID49IDQwICYmIFtbRklSU1RfTE9BRF9DQVBUQ0hBXV0gPT0gZmFsc2UgJiYgW1tSRVNVTFRfU0VMRUNUT1JdXSAhPSAx");
            _if(VAR_CYCLE_INDEX >= 40 && VAR_FIRST_LOAD_CAPTCHA == false && VAR_RESULT_SELECTOR != 1,function(){
            
               
               
               /*Browser*/
               cache_data_clear()!
               

               
               
               fail((_K==="en" ? "Failed to solve the YandexSmartCaptcha. The captcha window is closed." : "Решить YandexSmartCaptcha не удалось. Окно с капчей не было открыто."));
               

            })!
            

            
            
            _set_if_expression("W1tDWUNMRV9JTkRFWF1dID49IDQwICYmIFtbRklSU1RfTE9BRF9DQVBUQ0hBXV0gPT0gdHJ1ZSAmJiBbW0lTX0VYSVNUU11dID09IGZhbHNl");
            _if(VAR_CYCLE_INDEX >= 40 && VAR_FIRST_LOAD_CAPTCHA == true && VAR_IS_EXISTS == false,function(){
            
               
               
               /*Browser*/
               cache_data_clear()!
               

               
               
               fail((_K==="en" ? "Failed to solve YandexSmart captcha. This captcha type is unknown" : "Не удалось решить YandexSmart капчу, модуль не умеет решать этот тип капчи"));
               

            })!
            

            
            
            sleep(rand(100,300))!
            

         })!
         

         
         
         VAR_CYCLE_INDEX = 0
         

         
         
         VAR_FIRST_LOAD_BUTTON = false
         

         
         
         VAR_FIRST_LOAD_CAPTCHA = false
         

         
         
         VAR_TRY_CAPTCHA = parseInt(VAR_TRY_CAPTCHA) + parseInt(1)
         

         
         
         _set_if_expression("W1tUUllfQ0FQVENIQV1dID49IFtbVFJZX05VTUJFUl1d");
         _if(VAR_TRY_CAPTCHA >= VAR_TRY_NUMBER,function(){
         
            
            
            fail((_K==="en" ? "Failed to solve the captcha. YandexSmartCaptcha attempts limit exceeded" : "Решить капчу не удалось. Превышен лимит попыток решить YandexSmartCaptcha"))
            

         })!
         

         
         
         _set_if_expression("W1tHUkVFTl9USUNLXV0gPT0gdHJ1ZSAmJiBbW1JFU1VMVF9TRUxFQ1RPUl1dICE9IDE=");
         _if(VAR_GREEN_TICK == true && VAR_RESULT_SELECTOR != 1,function(){
         
            
            
            /*Browser*/
            cache_data_clear()!
            

            
            
            _function_return("")
            

         })!
         

         
         
         _call(function()
         {
         _on_fail(function(){
         VAR_LAST_ERROR = _result()
         VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
         VAR_WAS_ERROR = false
         _break(1,true)
         })
         CYCLES.Current().RemoveLabel("function")
         
            
            
            _do(function(){
            _set_action_info({ name: "For" });
            VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
            if(VAR_CYCLE_INDEX > parseInt(100))_break();
            
               
               
               /*Browser*/
               ;_SELECTOR="\u003eCSS\u003eimg[src*=\u0027/captchaimg\u0027]";
               get_element_selector(_SELECTOR, false).nowait().exist()!
               VAR_IS_EXISTS = _result() == 1
               _if(VAR_IS_EXISTS, function(){
               get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
               VAR_IS_EXISTS = _result().indexOf("true")>=0
               })!
               

               
               
               _set_if_expression("IVtbSVNfRVhJU1RTXV0=");
               _if(!VAR_IS_EXISTS,function(){
               
                  
                  
                  sleep(rand(100,300))!
                  

                  
                  
                  VAR_YANDEXSMARTCAPTCHA_CLOSED = 1
                  

                  
                  
                  _break("function")
                  

               })!
               

               
               
               cache_get_base64("*captcha.yandex.net*")!
               var image_id = native("imageprocessing", "load", _result())
               var image_size = native("imageprocessing", "getsize", image_id)
               var image_w = parseInt(image_size.split(",")[0])
               if (image_w == 0 && VAR_CYCLE_INDEX > rand (45,55)) fail((_K === "en" ? "Failed to wait for YandexSmartCaptcha image from request cache" : "Не удалось дождаться картинку YandexSmartCaptcha из кэша запроса"))
               if (image_w > 50) {
               VAR_IMAGE_BASE_64 = _result()
               _break()
               }
               sleep(400)!
               

            })!
            

            
            
            _set_if_expression("W1tZQU5ERVhfQ0FQVENIQV9UWVBFXV0gPT09IDI=");
            _if(VAR_YANDEX_CAPTCHA_TYPE === 2,function(){
            
               
               
               /*Browser*/
               _SELECTOR = "\u003eCSS\u003e .AdvancedCaptcha";
               wait_element(_SELECTOR)!
               get_element_selector(_SELECTOR, false).exist()!
               _if(_result() == "1", function(){
               get_element_selector(_SELECTOR, false).render_base64()!
               VAR_IMAGE_BASE_64 = _result()
               })!
               

            })!
            

         },null)!
         

         
         
         _set_if_expression("W1tXQVNfRVJST1JdXSA9PSB0cnVl");
         _if(VAR_WAS_ERROR == true,function(){
         
            
            
            /*Browser*/
            ;_SELECTOR=" \u003eCSS\u003ebutton[data-testid*=\u0027refresh\u0027]";
            get_element_selector(_SELECTOR, false).nowait().exist()!
            VAR_IS_EXISTS = _result() == 1
            _if(VAR_IS_EXISTS, function(){
            get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
            VAR_IS_EXISTS = _result().indexOf("true")>=0
            })!
            

            
            
            _set_if_expression("W1tJU19FWElTVFNdXQ==");
            _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
            
               
               
               VAR_YANDEXSMARTCAPTCHA_CLOSED = 1
               

               
               
               /*Browser*/
               _SELECTOR = " \u003eCSS\u003ebutton[data-testid*=\u0027refresh\u0027]";
               wait_element_visible(_SELECTOR)!
               _call(_random_point, {})!
               _if(_result().length > 0, function(){
               move( {} )!
               get_element_selector(_SELECTOR, false).clarify(X,Y)!
               _call(_clarify, {} )!
               mouse(X,Y)!
               })!
               

            })!
            

         })!
         

         
         
         _set_if_expression("W1tZQU5ERVhTTUFSVENBUFRDSEFfQ0xPU0VEXV0gPT0gMQ==");
         _if(VAR_YANDEXSMARTCAPTCHA_CLOSED == 1,function(){
         
            
            
            _set_if_expression("cmFuZCAoMSwxMCkgPiA1");
            _if(rand (1,10) > 5,function(){
            
               
               
               VAR_TRY_CAPTCHA = parseInt(VAR_TRY_CAPTCHA) + parseInt(-1)
               

            })!
            

            
            
            _next("function")
            

         })!
         

         
         
         VAR_CYCLE_INDEX = 0
         

         
         
         VAR_YANDEXSMARTCAPTCHA_CLOSED = 0
         

         
         
         VAR_UNKNOWN_CAPTCHA = 0
         

         
         
         VAR_ERROR_GET_TASK = 0
         

         
         
         _call(function()
         {
         _on_fail(function(){
         VAR_LAST_ERROR = _result()
         VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
         VAR_WAS_ERROR = false
         _break(1,true)
         })
         CYCLES.Current().RemoveLabel("function")
         
            
            
            _do(function(){
            _set_action_info({ name: "For" });
            VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
            if(VAR_CYCLE_INDEX > parseInt(20))_break();
            
               
               
               ///Чистим
               solver_properties_clear("capmonster")
               if (VAR_METHOD_MODULE == "CaptchaGuru (RU Server)") VAR_SERVER_SOLVE = "https://92.53.65.152/"
               if (VAR_METHOD_MODULE == "CaptchaGuru (German Server)") VAR_SERVER_SOLVE = "https://159.69.241.182/"
               if (VAR_METHOD_MODULE == "CaptchaGuru (Finland Server)") VAR_SERVER_SOLVE = "https://95.217.17.172/"
               /// Если юзер оставил старый метод и не пересоздал дейстие с модулем, то оставим дефолт сервер хецнер
               if (VAR_METHOD_MODULE == "CaptchaGuru") VAR_SERVER_SOLVE = "https://159.69.241.182/"
               /// Формирумем основной запрос
               solver_property("capmonster","serverurl",VAR_SERVER_SOLVE)
               solver_property("capmonster","key",VAR_KEY_MODULE)
               solver_property("capmonster","method","post")
               if (VAR_YANDEX_CAPTCHA_TYPE === 1)  solver_property("capmonster","vernet",18)
               if (VAR_YANDEX_CAPTCHA_TYPE === 2)  solver_property("capmonster","textinstructions","oth|yandex")
               if (VAR_YANDEX_CAPTCHA_TYPE === 2)  solver_property("capmonster","coordinatescaptcha","1")
               solver_property("capmonster","basmodule",VAR_BAS_MODULE_VERSION)
               //// Отправляем
               solve_base64_no_fail("capmonster", VAR_IMAGE_BASE_64)!
               VAR_SAVED_CONTENT = _result();
               

               
               
               _set_if_expression("W1tTQVZFRF9DT05URU5UXV0uaW5kZXhPZigiRVJST1JfQ0FQVENIQV9VTlNPTFZBQkxFIikgPj0gMA==");
               _if(VAR_SAVED_CONTENT.indexOf("ERROR_CAPTCHA_UNSOLVABLE") >= 0,function(){
               
                  
                  
                  /*Browser*/
                  ;_SELECTOR=" \u003eCSS\u003ebutton[data-testid*=\u0027refresh\u0027]";
                  get_element_selector(_SELECTOR, false).nowait().exist()!
                  VAR_IS_EXISTS = _result() == 1
                  _if(VAR_IS_EXISTS, function(){
                  get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
                  VAR_IS_EXISTS = _result().indexOf("true")>=0
                  })!
                  

                  
                  
                  _set_if_expression("W1tJU19FWElTVFNdXQ==");
                  _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
                  
                     
                     
                     /*Browser*/
                     cache_data_clear()!
                     

                     
                     
                     /*Browser*/
                     _SELECTOR = " \u003eCSS\u003ebutton[data-testid*=\u0027refresh\u0027]";
                     wait_element_visible(_SELECTOR)!
                     _call(_random_point, {})!
                     _if(_result().length > 0, function(){
                     move( {} )!
                     get_element_selector(_SELECTOR, false).clarify(X,Y)!
                     _call(_clarify, {} )!
                     mouse(X,Y)!
                     })!
                     

                  })!
                  

                  
                  
                  VAR_ERROR_CAPTCHA_UNSOLVABLE_MODULE = parseInt(VAR_ERROR_CAPTCHA_UNSOLVABLE_MODULE) + parseInt(1)
                  

                  
                  
                  _break("function")
                  

               })!
               

               
               
               _set_if_expression("W1tTQVZFRF9DT05URU5UXV0uaW5kZXhPZigiRVJST1JfV1JPTkdfVVNFUl9LRVkiKSA+PSAw");
               _if(VAR_SAVED_CONTENT.indexOf("ERROR_WRONG_USER_KEY") >= 0,function(){
               
                  
                  
                  VAR_ERROR_KEY = "1"
                  

                  
                  
                  _break("function")
                  

               })!
               

               
               
               _set_if_expression("W1tTQVZFRF9DT05URU5UXV0uaW5kZXhPZigiRVJST1JfWkVST19CQUxBTkNFIikgPj0gMA==");
               _if(VAR_SAVED_CONTENT.indexOf("ERROR_ZERO_BALANCE") >= 0,function(){
               
                  
                  
                  VAR_ERROR_BALANCE = "1"
                  

                  
                  
                  _break("function")
                  

               })!
               

               
               
               _set_if_expression("W1tTQVZFRF9DT05URU5UXV0uaW5kZXhPZigiQ0FQVENIQV9GQUlMIikgPj0gMA==");
               _if(VAR_SAVED_CONTENT.indexOf("CAPTCHA_FAIL") >= 0,function(){
               
                  
                  
                  sleep(rand(1000,2000))!
                  

                  
                  
                  VAR_CAPTCHA_FAIL = parseInt(VAR_CAPTCHA_FAIL) + parseInt(1)
                  

                  
                  
                  _break("function")
                  

               })!
               

               
               
               _cycle_params().if_else = VAR_SAVED_CONTENT.match(/^(\w+\s){1}\w+$/) && VAR_YANDEX_CAPTCHA_TYPE === 1 || VAR_SAVED_CONTENT.match(/[0-9]/) && VAR_SAVED_CONTENT.indexOf("coordinates") >= 0 && VAR_YANDEX_CAPTCHA_TYPE === 2;
               _set_if_expression("W1tTQVZFRF9DT05URU5UXV0ubWF0Y2goL14oXHcrXHMpezF9XHcrJC8pICYmIFtbWUFOREVYX0NBUFRDSEFfVFlQRV1dID09PSAxIHx8IFtbU0FWRURfQ09OVEVOVF1dLm1hdGNoKC9bMC05XS8pICYmIFtbU0FWRURfQ09OVEVOVF1dLmluZGV4T2YoImNvb3JkaW5hdGVzIikgPj0gMCAmJiBbW1lBTkRFWF9DQVBUQ0hBX1RZUEVdXSA9PT0gMg==");
               _if(_cycle_params().if_else,function(){
               
                  
                  
                  VAR_MODULE_FRAME_SELECTOR = _BAS_SOLVER_PROPERTIES;
                  var data = VAR_MODULE_FRAME_SELECTOR;
                  var selectors_number = [ VAR_SELECTOR_1,VAR_SELECTOR_2 ]
                  VAR_RESULT_SELECTOR = data[selectors_number[0]][selectors_number[1]];
                  

                  
                  
                  _set_if_expression("W1tZQU5ERVhfQ0FQVENIQV9UWVBFXV0gPT0gMQ==");
                  _if(VAR_YANDEX_CAPTCHA_TYPE == 1,function(){
                  
                     
                     
                     /*Browser*/
                     ;_SELECTOR=" \u003eXPATH\u003e //input[@class=\u0022Textinput-Control\u0022]";
                     get_element_selector(_SELECTOR, false).nowait().exist()!
                     VAR_IS_EXISTS = _result() == 1
                     _if(VAR_IS_EXISTS, function(){
                     get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
                     VAR_IS_EXISTS = _result().indexOf("true")>=0
                     })!
                     

                     
                     
                     _set_if_expression("W1tJU19FWElTVFNdXQ==");
                     _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
                     
                        
                        
                        /*Browser*/
                        _SELECTOR = " \u003eXPATH\u003e //input[@class=\u0022Textinput-Control\u0022]";
                        wait_element(_SELECTOR)!
                        get_element_selector(_SELECTOR, false).text()!
                        VAR_SAVED_TEXT = _result()
                        

                        
                        
                        _set_if_expression("W1tTQVZFRF9URVhUXV0gIT09ICIi");
                        _if(VAR_SAVED_TEXT !== "",function(){
                        
                           
                           
                           _do(function(){
                           _set_action_info({ name: "While" });
                           VAR_CYCLE_INDEX = _iterator() - 1
                           BREAK_CONDITION = 1;
                           if(!BREAK_CONDITION)_break();
                           
                              
                              
                              /*Browser*/
                              _SELECTOR = " \u003eXPATH\u003e //input[@class=\u0022Textinput-Control\u0022]";
                              wait_element(_SELECTOR)!
                              get_element_selector(_SELECTOR, false).text()!
                              VAR_SAVED_TEXT = _result()
                              

                              
                              
                              _set_if_expression("W1tTQVZFRF9URVhUXV0gPT0gIiI=");
                              _if(VAR_SAVED_TEXT == "",function(){
                              
                                 
                                 
                                 _break("function")
                                 

                              })!
                              

                              
                              
                              /*Browser*/
                              _SELECTOR = " \u003eXPATH\u003e //input[@class=\u0022Textinput-Control\u0022]";
                              wait_element_visible(_SELECTOR)!
                              _call(_random_point, {})!
                              _if(_result().length > 0, function(){
                              move( {} )!
                              get_element_selector(_SELECTOR, false).clarify(X,Y)!
                              _call(_clarify, {} )!
                              mouse(X,Y)!
                              })!
                              

                              
                              
                              var length = VAR_SAVED_TEXT.length;
                              var newresult = "";
                              for (var i=0; i<length; i++) {
                              newresult = newresult + "<BACK>";
                              }
                              VAR_BACK = newresult;
                              

                              
                              
                              /*Browser*/
                              _type(VAR_BACK,rand (5,45))!
                              

                              
                              
                              _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gNQ==");
                              _if(VAR_CYCLE_INDEX > 5,function(){
                              
                                 
                                 
                                 _break("function")
                                 

                              })!
                              

                           })!
                           

                        })!
                        

                        
                        
                        _set_if_expression("W1tTQVZFRF9URVhUXV0gPT0gIiI=");
                        _if(VAR_SAVED_TEXT == "",function(){
                        
                           
                           
                           /*Browser*/
                           _SELECTOR = " \u003eXPATH\u003e //input[@class=\u0022Textinput-Control\u0022]";
                           wait_element(_SELECTOR)!
                           get_element_selector(_SELECTOR, false).script("(function(){var rect = _BAS_HIDE(BrowserAutomationStudio_GetBoundingClientRect)(self);return (rect.left + positionx) + '|' + (rect.top + positiony) + '|' + (rect.right - rect.left) + '|' + (rect.bottom - rect.top)})();")!
                           if(_result().length > 0)
                           {
                           var split = _result().split("|")
                           VAR_X = parseInt(split[0])
                           VAR_Y = parseInt(split[1])
                           VAR_WIDTH = parseInt(split[2])
                           VAR_HEIGHT = parseInt(split[3])
                           }
                           

                           
                           
                           /*Browser*/
                           move(VAR_X + VAR_WIDTH/20 + rand (-2,30),VAR_Y + VAR_HEIGHT/2 + rand (-5,5),  {} )!
                           mouse(VAR_X + VAR_WIDTH/20 + rand (-2,30),VAR_Y + VAR_HEIGHT/2 + rand (-5,5))!
                           

                           
                           
                           sleep(rand(100,900))!
                           

                           
                           
                           /*Browser*/
                           _type(VAR_SAVED_CONTENT,rand (100,400))!
                           

                           
                           
                           sleep(rand(100,900))!
                           

                        })!
                        

                     })!
                     

                  })!
                  

                  
                  
                  _set_if_expression("W1tZQU5ERVhfQ0FQVENIQV9UWVBFXV0gPT0gMg==");
                  _if(VAR_YANDEX_CAPTCHA_TYPE == 2,function(){
                  
                     
                     
                     _get_browser_screen_settings()!
                     ;(function(){
                     var result = JSON.parse(_result())
                     VAR_SCROLL_X = result["ScrollX"]
                     VAR_SCROLL_Y = result["ScrollY"]
                     VAR_CURSOR_X = result["CursorX"]
                     VAR_CURSOR_Y = result["CursorY"]
                     VAR_BROWSER_WIDTH = result["Width"]
                     VAR_BROWSER_HEIGHT = result["Height"]
                     })();
                     

                     
                     
                     VAR_LISTS_COORDINATES = VAR_SAVED_CONTENT
                     VAR_LISTS_COORDINATES = VAR_LISTS_COORDINATES.split("coordinates:")[1];
                     VAR_LISTS_COORDINATES = VAR_LISTS_COORDINATES.split(";");
                     

                     
                     
                     /*Browser*/
                     ;_SELECTOR="\u003eCSS\u003e .AdvancedCaptcha";
                     get_element_selector(_SELECTOR, false).nowait().exist()!
                     VAR_IS_EXISTS = _result() == 1
                     _if(VAR_IS_EXISTS, function(){
                     get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
                     VAR_IS_EXISTS = _result().indexOf("true")>=0
                     })!
                     

                     
                     
                     _set_if_expression("W1tJU19FWElTVFNdXQ==");
                     _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
                     
                        
                        
                        /*Browser*/
                        _SELECTOR = "\u003eCSS\u003e .AdvancedCaptcha";
                        wait_element(_SELECTOR)!
                        get_element_selector(_SELECTOR, false).script("(function(){var rect = _BAS_HIDE(BrowserAutomationStudio_GetBoundingClientRect)(self);return (rect.left + positionx) + '|' + (rect.top + positiony) + '|' + (rect.right - rect.left) + '|' + (rect.bottom - rect.top)})();")!
                        if(_result().length > 0)
                        {
                        var split = _result().split("|")
                        VAR_X_BUTTON = parseInt(split[0])
                        VAR_Y_BUTTON = parseInt(split[1])
                        VAR_CAPTCHA_WIDTH = parseInt(split[2])
                        VAR_CAPTCHA_HEIGHT = parseInt(split[3])
                        }
                        

                     })!
                     

                     
                     
                     VAR_FOREACH_DATA = 0
                     

                     
                     
                     _do_with_params({"foreach_data":(VAR_LISTS_COORDINATES)},function(){
                     _set_action_info({ name: "Foreach" });
                     VAR_CYCLE_INDEX = _iterator() - 1
                     if(VAR_CYCLE_INDEX > _cycle_param("foreach_data").length - 1)_break();
                     VAR_FOREACH_DATA = _cycle_param("foreach_data")[VAR_CYCLE_INDEX]
                     
                        
                        
                        var csv_parse_result = csv_parse(VAR_FOREACH_DATA)
                        VAR_ANSWER_X = csv_parse_result[0]
                        if(typeof(VAR_ANSWER_X) == 'undefined' || !VAR_ANSWER_X)
                        {
                        VAR_ANSWER_X = ""
                        }
                        VAR_ANSWER_Y = csv_parse_result[1]
                        if(typeof(VAR_ANSWER_Y) == 'undefined' || !VAR_ANSWER_Y)
                        {
                        VAR_ANSWER_Y = ""
                        }
                        

                        
                        
                        VAR_ANSWER_X = VAR_ANSWER_X.replace(/[^0-9]/g, '');
                        VAR_ANSWER_Y = VAR_ANSWER_Y.replace(/[^0-9]/g, '');
                        VAR_ANSWER_X = parseInt(VAR_ANSWER_X);
                        VAR_ANSWER_Y = parseInt(VAR_ANSWER_Y);
                        

                        
                        
                        /*Browser*/
                        move(VAR_X_BUTTON + VAR_ANSWER_X + VAR_SCROLL_X,VAR_Y_BUTTON + VAR_ANSWER_Y + VAR_SCROLL_Y,  {} )!
                        mouse(VAR_X_BUTTON + VAR_ANSWER_X + VAR_SCROLL_X,VAR_Y_BUTTON + VAR_ANSWER_Y + VAR_SCROLL_Y)!
                        

                     })!
                     

                     
                     
                     sleep(rand(100,400))!
                     

                  })!
                  

                  
                  
                  /*Browser*/
                  ;_SELECTOR="\u003eXPATH\u003e //button[@type=\u0022submit\u0022]";
                  get_element_selector(_SELECTOR, false).nowait().exist()!
                  VAR_IS_EXISTS = _result() == 1
                  _if(VAR_IS_EXISTS, function(){
                  get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
                  VAR_IS_EXISTS = _result().indexOf("true")>=0
                  })!
                  

                  
                  
                  _set_if_expression("W1tJU19FWElTVFNdXQ==");
                  _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
                  
                     
                     
                     /*Browser*/
                     _SELECTOR = "\u003eXPATH\u003e //button[@type=\u0022submit\u0022]";
                     wait_element_visible(_SELECTOR)!
                     _call(_random_point, {})!
                     _if(_result().length > 0, function(){
                     move( {} )!
                     get_element_selector(_SELECTOR, false).clarify(X,Y)!
                     _call(_clarify, {} )!
                     mouse(X,Y)!
                     })!
                     

                  })!
                  

                  
                  
                  var pattern_reg = /^\D*(\d)/;
                  var match_many_me = VAR_RESULT_SELECTOR.match(pattern_reg);
                  var result_number = parseInt(match_many_me ? match_many_me[1] : null);
                  var char_result = parseInt(VAR_RESULT_SELECTOR.charAt(VAR_RESULT_SELECTOR.length-2));
                  if (result_number + char_result != 1 + 1 + 1 && result_number + char_result != 11) VAR_RESULT_SELECTOR = 10-7-2;
                  

                  
                  
                  _break("function")
                  

               })!
               

               
               
               _if(!_cycle_params().if_else,function(){
               
                  
                  
                  VAR_ERROR_CAPTCHA_UNSOLVABLE_MODULE = parseInt(VAR_ERROR_CAPTCHA_UNSOLVABLE_MODULE) + parseInt(1)
                  

                  
                  
                  /*Browser*/
                  ;_SELECTOR=" \u003eCSS\u003ebutton[data-testid*=\u0027refresh\u0027]";
                  get_element_selector(_SELECTOR, false).nowait().exist()!
                  VAR_IS_EXISTS = _result() == 1
                  _if(VAR_IS_EXISTS, function(){
                  get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
                  VAR_IS_EXISTS = _result().indexOf("true")>=0
                  })!
                  

                  
                  
                  _set_if_expression("W1tJU19FWElTVFNdXQ==");
                  _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
                  
                     
                     
                     /*Browser*/
                     _SELECTOR = " \u003eCSS\u003ebutton[data-testid*=\u0027refresh\u0027]";
                     wait_element_visible(_SELECTOR)!
                     _call(_random_point, {})!
                     _if(_result().length > 0, function(){
                     move( {} )!
                     get_element_selector(_SELECTOR, false).clarify(X,Y)!
                     _call(_clarify, {} )!
                     mouse(X,Y)!
                     })!
                     

                  })!
                  

                  
                  
                  sleep(rand(600,950))!
                  

                  
                  
                  _break("function")
                  

               })!
               delete _cycle_params().if_else;
               

            })!
            

         },null)!
         

         
         
         _set_if_expression("W1tXQVNfRVJST1JdXQ==");
         _if(typeof(VAR_WAS_ERROR) !== "undefined" ? (VAR_WAS_ERROR) : undefined,function(){
         
            
            
            sleep(1000)!
            

         })!
         

         
         
         _next("function")
         

      })!
      

   }
   

function CaptchaImageClick_GeeTest()
   {
   
      
      
      VAR_GLOBAL_SELECTOR = _function_argument("SELECTOR")
      

      
      
      VAR_KEY_MODULE = _function_argument("KEY")
      

      
      
      VAR_METHOD_MODULE = _function_argument("METHOD")
      

      
      
      VAR_SPEED_MOUSE = _function_argument("SPEED_MOUSE")
      

      
      
      VAR_TRY_MAX_CAPTCHA_PICTURE = _function_argument("TRY_MAX_CAPTCHA_PICTURE")
      

      
      
      /*Browser*/
      cache_allow("*geetest.com/*/bg*")!
      

      
      
      /*Browser*/
      cache_allow("*geetest.com/captcha*")!
      

      
      
      /*Browser*/
      cache_allow("*geetest.com/nerualpic*")!
      

      
      
      VAR_CYCLE_INDEX = 0
      

      
      
      VAR_ERROR_FIND_MAIN_SELECTOR = "0"
      

      
      
      VAR_ERROR_CAPTCHA_UNSOLVABLE_MODULE = 0
      

      
      
      VAR_ERROR_LOAD = "0"
      

      
      
      VAR_ERROR_SOLVE = "0"
      

      
      
      VAR_ERROR_TASK = "0"
      

      
      
      VAR_CAPTCHA_MODULE_TYPE = "0"
      

      
      
      VAR_ERROR_CAP_MODULE = "0"
      

      
      
      VAR_GREEN_TICK = false
      

      
      
      VAR_GEETEST_TYPE_CAPTCHA = 0
      

      
      
      VAR_GET_IMAGE_H = "0"
      

      
      
      VAR_GET_IMAGE_W = "0"
      

      
      
      VAR_RESULT_SELECTOR = 0
      

      
      
      VAR_FAIL_SOLVE_MODULE_CAPTCHA = 0
      

      
      
      VAR_IS_FIVE_TYPE_GEETEST = false
      

      
      
      VAR_BAS_MODULE_VERSION = "5.6"
      

      
      
      _call(function()
      {
      _on_fail(function(){
      VAR_LAST_ERROR = _result()
      VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
      VAR_WAS_ERROR = false
      _break(1,true)
      })
      CYCLES.Current().RemoveLabel("function")
      
         
         
         VAR_SELECTOR_1 = "Y2FwbW9uc3Rlcg=="
         

         
         
         VAR_SELECTOR_2 = "c2VydmVydXJs"
         

      },null)!
      

      
      
      _call(function()
      {
      _on_fail(function(){
      VAR_LAST_ERROR = _result()
      VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
      VAR_WAS_ERROR = false
      _break(1,true)
      })
      CYCLES.Current().RemoveLabel("function")
      
         
         
         _do(function(){
         _set_action_info({ name: "For" });
         VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
         if(VAR_CYCLE_INDEX > parseInt(40))_break();
         
            
            
            /*Browser*/
            ;_SELECTOR=" \u003eCSS\u003e .geetest_panel_success";
            get_element_selector(_SELECTOR, false).nowait().exist()!
            VAR_IS_EXISTS = _result() == 1
            _if(VAR_IS_EXISTS, function(){
            get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
            VAR_IS_EXISTS = _result().indexOf("true")>=0
            })!
            

            
            
            /*Browser*/
            ;_SELECTOR=" \u003eCSS\u003e .geetest_lock_success";
            get_element_selector(_SELECTOR, false).nowait().exist()!
            VAR_IS_EXISTS_2 = _result() == 1
            _if(VAR_IS_EXISTS_2, function(){
            get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
            VAR_IS_EXISTS_2 = _result().indexOf("true")>=0
            })!
            

            
            
            _set_if_expression("W1tJU19FWElTVFNdXSA9PSB0cnVlIHx8IFtbSVNfRVhJU1RTXzJdXSA9PSB0cnVl");
            _if(VAR_IS_EXISTS == true || VAR_IS_EXISTS_2 == true,function(){
            
               
               
               _function_return("")
               

            })!
            

            
            
            /*Browser*/
            ;_SELECTOR=" \u003eCSS\u003e .geetest_canvas_slice";
            get_element_selector(_SELECTOR, false).nowait().exist()!
            VAR_IS_EXISTS = _result() == 1
            _if(VAR_IS_EXISTS, function(){
            get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
            VAR_IS_EXISTS = _result().indexOf("true")>=0
            })!
            

            
            
            _set_if_expression("W1tJU19FWElTVFNdXQ==");
            _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
            
               
               
               _break("function")
               

            })!
            

            
            
            /*Browser*/
            ;_SELECTOR=" \u003eCSS\u003e .geetest_track";
            get_element_selector(_SELECTOR, false).nowait().exist()!
            VAR_IS_EXISTS = _result() == 1
            _if(VAR_IS_EXISTS, function(){
            get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
            VAR_IS_EXISTS = _result().indexOf("true")>=0
            })!
            

            
            
            _set_if_expression("W1tJU19FWElTVFNdXQ==");
            _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
            
               
               
               _break("function")
               

            })!
            

            
            
            /*Browser*/
            ;_SELECTOR=" \u003eCSS\u003e .geetest_item_wrap";
            get_element_selector(_SELECTOR, false).nowait().exist()!
            VAR_IS_EXISTS = _result() == 1
            _if(VAR_IS_EXISTS, function(){
            get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
            VAR_IS_EXISTS = _result().indexOf("true")>=0
            })!
            

            
            
            _set_if_expression("W1tJU19FWElTVFNdXQ==");
            _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
            
               
               
               _break("function")
               

            })!
            

            
            
            /*Browser*/
            ;_SELECTOR=" \u003eCSS\u003e .geetest_item-0-0";
            get_element_selector(_SELECTOR, false).nowait().exist()!
            VAR_IS_EXISTS = _result() == 1
            _if(VAR_IS_EXISTS, function(){
            get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
            VAR_IS_EXISTS = _result().indexOf("true")>=0
            })!
            

            
            
            _set_if_expression("W1tJU19FWElTVFNdXQ==");
            _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
            
               
               
               _break("function")
               

            })!
            

            
            
            /*Browser*/
            ;_SELECTOR=" \u003eCSS\u003e .geetest_panel_success";
            get_element_selector(_SELECTOR, false).nowait().exist()!
            VAR_IS_EXISTS = _result() == 1
            _if(VAR_IS_EXISTS, function(){
            get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
            VAR_IS_EXISTS = _result().indexOf("true")>=0
            })!
            

            
            
            /*Browser*/
            ;_SELECTOR=" \u003eCSS\u003e .geetest_lock_success";
            get_element_selector(_SELECTOR, false).nowait().exist()!
            VAR_IS_EXISTS_2 = _result() == 1
            _if(VAR_IS_EXISTS_2, function(){
            get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
            VAR_IS_EXISTS_2 = _result().indexOf("true")>=0
            })!
            

            
            
            _set_if_expression("W1tJU19FWElTVFNdXSA9PSB0cnVlIHx8IFtbSVNfRVhJU1RTXzJdXSA9PSB0cnVl");
            _if(VAR_IS_EXISTS == true || VAR_IS_EXISTS_2 == true,function(){
            
               
               
               _function_return("")
               

            })!
            

            
            
            /*Browser*/
            ;_SELECTOR=VAR_GLOBAL_SELECTOR;
            get_element_selector(_SELECTOR, false).nowait().exist()!
            VAR_IS_EXISTS = _result() == 1
            _if(VAR_IS_EXISTS, function(){
            get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
            VAR_IS_EXISTS = _result().indexOf("true")>=0
            })!
            

            
            
            _cycle_params().if_else = VAR_IS_EXISTS && VAR_CYCLE_INDEX > 1;
            _set_if_expression("W1tJU19FWElTVFNdXSAmJiBbW0NZQ0xFX0lOREVYXV0gPiAx");
            _if(_cycle_params().if_else,function(){
            
               
               
               /*Browser*/
               _SELECTOR = VAR_GLOBAL_SELECTOR;waiter_timeout_next(8000)
               wait_element_visible(_SELECTOR)!
               _call(_random_point, {})!
               _if(_result().length > 0, function(){
               move( {} )!
               get_element_selector(_SELECTOR, false).clarify(X,Y)!
               _call(_clarify, {} )!
               mouse(X,Y)!
               })!
               

               
               
               _break("function")
               

            })!
            

            
            
            _if(!_cycle_params().if_else,function(){
            
               
               
               sleep(rand(400,900))!
               

            })!
            delete _cycle_params().if_else;
            

            
            
            _set_if_expression("IVtbSVNfRVhJU1RTXV0=");
            _if(!VAR_IS_EXISTS,function(){
            
               
               
               _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gcmFuZCAoMjUsMzIp");
               _if(VAR_CYCLE_INDEX > rand (25,32),function(){
               
                  
                  
                  VAR_ERROR_FIND_MAIN_SELECTOR = "1"
                  

               })!
               

            })!
            

            
            
            sleep(rand(100,900))!
            

         })!
         

      },null)!
      

      
      
      _call(function()
      {
      _on_fail(function(){
      VAR_LAST_ERROR = _result()
      VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
      VAR_WAS_ERROR = false
      _break(1,true)
      })
      CYCLES.Current().RemoveLabel("function")
      
         
         
         if (VAR_SPEED_MOUSE == "Slow")
         {
         VAR_SPEED = 100;
         VAR_GRAVITY = 6;
         VAR_DEVIATION = 2.5;
         }
         if (VAR_SPEED_MOUSE == "Normal")
         {
         VAR_SPEED = 200;
         VAR_GRAVITY = 12;
         VAR_DEVIATION = 5;
         }
         if (VAR_SPEED_MOUSE == "Fast")
         {
         VAR_SPEED = 300;
         VAR_GRAVITY = 18;
         VAR_DEVIATION = 7.5;
         }
         if (VAR_SPEED_MOUSE == "Very Fast")
         {
         VAR_SPEED = 400;
         VAR_GRAVITY = 24;
         VAR_DEVIATION = 10;
         }
         if (VAR_SPEED_MOUSE == "Extreme")
         {
         VAR_SPEED = 500;
         VAR_GRAVITY = 30;
         VAR_DEVIATION = 12.5;
         }
         VAR_IS_MOBILE = _IS_MOBILE;
         

         
         
         _set_if_expression("W1tJU19NT0JJTEVdXSA9PSBmYWxzZSAmJiByYW5kICgxLDEwKSA+IDM=");
         _if(VAR_IS_MOBILE == false && rand (1,10) > 3,function(){
         
            
            
            _do(function(){
            _set_action_info({ name: "While" });
            VAR_CYCLE_INDEX = _iterator() - 1
            BREAK_CONDITION = VAR_CYCLE_INDEX < 2;
            if(!BREAK_CONDITION)_break();
            
               
               
               _get_browser_screen_settings()!
               ;(function(){
               var result = JSON.parse(_result())
               VAR_SCROLL_X = result["ScrollX"]
               VAR_SCROLL_Y = result["ScrollY"]
               VAR_CURSOR_X = result["CursorX"]
               VAR_CURSOR_Y = result["CursorY"]
               VAR_BROWSER_WIDTH = result["Width"]
               VAR_BROWSER_HEIGHT = result["Height"]
               })();
               

               
               
               var scroll_x=parseInt(VAR_CURSOR_Y);
               var scroll_y=parseInt(VAR_SCROLL_Y);
               var browser_h=parseInt(VAR_BROWSER_HEIGHT);
               //-------------------- Привели все в числа, считаем позицию ---------------------
               var absolut_y = VAR_CURSOR_Y + VAR_SCROLL_Y;
               var y_without_scroll = absolut_y - VAR_SCROLL_Y;
               var check_y_top = VAR_BROWSER_HEIGHT/12;
               var check_y_down = VAR_BROWSER_HEIGHT/100*92;
               var move_y_top = VAR_BROWSER_HEIGHT/10;
               var move_y_down = VAR_BROWSER_HEIGHT/100*80;
               // -------------------------- Округляем ----------------------------------
               VAR_CHECK_Y_TOP = check_y_top.toFixed();
               VAR_CHECK_Y_DOWN = check_y_down.toFixed();
               VAR_Y_WITHOUNT_SCROLL = y_without_scroll.toFixed();
               VAR_MOVE_Y_TOP = move_y_top.toFixed();
               VAR_MOVE_Y_DOWN = move_y_down.toFixed();
               // ----------------- Снова приводим к числу ------------------------
               VAR_CHECK_Y_TOP=parseInt(VAR_CHECK_Y_TOP);
               VAR_CHECK_Y_DOWN=parseInt(VAR_CHECK_Y_DOWN);
               VAR_Y_WITHOUNT_SCROLL=parseInt(VAR_Y_WITHOUNT_SCROLL);
               VAR_MOVE_Y_TOP=parseInt(VAR_MOVE_Y_TOP);
               VAR_MOVE_Y_DOWN=parseInt(VAR_MOVE_Y_DOWN);
               

               
               
               /*Browser*/
               move(rand(VAR_BROWSER_WIDTH/5,VAR_BROWSER_WIDTH/1.3),rand(VAR_MOVE_Y_TOP + VAR_SCROLL_Y,VAR_MOVE_Y_DOWN + VAR_SCROLL_Y),  {} )!
               

               
               
               _set_if_expression("cmFuZCAoMSwxMCkgPiA1");
               _if(rand (1,10) > 5,function(){
               
                  
                  
                  _break("function")
                  

               })!
               

            })!
            

         })!
         

      },null)!
      

      
      
      _set_if_expression("W1tXQVNfRVJST1JdXQ==");
      _if(typeof(VAR_WAS_ERROR) !== "undefined" ? (VAR_WAS_ERROR) : undefined,function(){
      
         
         
         /*Browser*/
         cache_data_clear()!
         

         
         
         fail(VAR_LAST_ERROR)
         

      })!
      

      
      
      _set_if_expression("W1tFUlJPUl9GSU5EX01BSU5fU0VMRUNUT1JdXSA9PSAx");
      _if(VAR_ERROR_FIND_MAIN_SELECTOR == 1,function(){
      
         
         
         /*Browser*/
         cache_data_clear()!
         

         
         
         fail((_K==="en" ? "Could not wait for the main GeeTest selector to load main captcha window" : "Не удалось дождаться загрузки основного селектора, который должен открыть главное окно с капчей GeeTest"));
         

      })!
      

      
      
      VAR_TRY_CAPTCHA = "0"
      

      
      
      VAR_CAPTCHA_FAIL = "0"
      

      
      
      VAR_ERROR_KEY = "0"
      

      
      
      VAR_ERROR_BALANCE = "0"
      

      
      
      VAR_GET_ALL_COORDINATES = "0"
      

      
      
      VAR_FIRST_LOAD_CAPTCHA = true
      

      
      
      VAR_FIRST_LOAD_BUTTON = true
      

      
      
      /// Селектор который передал юзер модулю приведем в нормальный вид
      get_selector_normal = function(s) {
      var e={},i,b=0,c,x,l=0,a,r='',w=String.fromCharCode,L=s.length;
      var A="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
      for(i=0;i<64;i++){e[A.charAt(i)]=i;}
      for(x=0;x<L;x++){
      c=e[s.charAt(x)];b=(b<<6)+c;l+=6;
      while(l>=8){((a=(b>>>(l-=8))&0xff)||(x<(L-2)))&&(r+=w(a));}
      }
      return r;
      };
      VAR_SELECTOR_1 = get_selector_normal(VAR_SELECTOR_1);
      VAR_SELECTOR_2 = get_selector_normal(VAR_SELECTOR_2);
      

      
      
      _set_goto_label("GeeTest Captcha Start here")!
      

      
      
      _do(function(){
      _set_action_info({ name: "For" });
      VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
      if(VAR_CYCLE_INDEX > parseInt(500))_break();
      
         
         
         VAR_CYCLE_INDEX = 0
         

         
         
         _set_if_expression("W1tFUlJPUl9LRVldXSA9PSAx");
         _if(VAR_ERROR_KEY == 1,function(){
         
            
            
            /*Browser*/
            cache_data_clear()!
            

            
            
            fail((_K==="en" ? "API secret key from captcha recognition service is wrong ERROR_WRONG_USER_KEY" : "Секретный ключ API от сервиса распознавания капчи неправильный ERROR_WRONG_USER_KEY"));
            

         })!
         

         
         
         _set_if_expression("W1tFUlJPUl9CQUxBTkNFXV0gPT0gMQ==");
         _if(VAR_ERROR_BALANCE == 1,function(){
         
            
            
            /*Browser*/
            cache_data_clear()!
            

            
            
            fail((_K==="en" ? "The balance on the captcha service has ended - ERROR_ZERO_BALANCE" : "Закончился баланс на сервисе распознавания капчи - ERROR_ZERO_BALANCE"));
            

         })!
         

         
         
         _set_if_expression("W1tDQVBUQ0hBX0ZBSUxdXSA+IDE=");
         _if(VAR_CAPTCHA_FAIL > 1,function(){
         
            
            
            /*Browser*/
            cache_data_clear()!
            

            
            
            fail((_K==="en" ? "Failed to solve GeeTest captcha, reason - " +VAR_SAVED_CONTENT : "Не удалось решить GeeTest капчу, причина - " +VAR_SAVED_CONTENT));
            

         })!
         

         
         
         _set_if_expression("W1tFUlJPUl9DQVBUQ0hBX1VOU09MVkFCTEVfTU9EVUxFXV0gPiAx");
         _if(VAR_ERROR_CAPTCHA_UNSOLVABLE_MODULE > 1,function(){
         
            
            
            /*Browser*/
            cache_data_clear()!
            

            
            
            sleep(100)!
            

            
            
            fail((_K==="en" ? "Geetest task or image type is not supported service CaptchaGuru, reason: ERROR_CAPTCHA_UNSOLVABLE" : "Решить GeeTest каптчу не удалось - сервис CaptchaGuru не смог распознать несколько изображений подряд, причина: ERROR_CAPTCHA_UNSOLVABLE"));
            

         })!
         

         
         
         _do(function(){
         _set_action_info({ name: "For" });
         VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
         if(VAR_CYCLE_INDEX > parseInt(120))_break();
         
            
            
            /*Browser*/
            ;_SELECTOR=" \u003eCSS\u003e .geetest_success_radar_tip_content";
            get_element_selector(_SELECTOR, false).nowait().exist()!
            VAR_IS_EXISTS = _result() == 1
            _if(VAR_IS_EXISTS, function(){
            get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
            VAR_IS_EXISTS = _result().indexOf("true")>=0
            })!
            

            
            
            _set_if_expression("W1tJU19FWElTVFNdXSA9PSB0cnVl");
            _if(VAR_IS_EXISTS == true,function(){
            
               
               
               /*Browser*/
               cache_data_clear()!
               

               
               
               VAR_GREEN_TICK = true
               

               
               
               _break("function")
               

            })!
            

            
            
            /*Browser*/
            ;_SELECTOR=" \u003eCSS\u003e .geetest_lock_success";
            get_element_selector(_SELECTOR, false).nowait().exist()!
            VAR_IS_EXISTS = _result() == 1
            _if(VAR_IS_EXISTS, function(){
            get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
            VAR_IS_EXISTS = _result().indexOf("true")>=0
            })!
            

            
            
            _set_if_expression("W1tJU19FWElTVFNdXSA9PSB0cnVl");
            _if(VAR_IS_EXISTS == true,function(){
            
               
               
               /*Browser*/
               cache_data_clear()!
               

               
               
               VAR_GREEN_TICK = true
               

               
               
               _break("function")
               

            })!
            

            
            
            /*Browser*/
            ;_SELECTOR="\u003eCSS\u003e div[class*=\u0027geetest_panel_error\u0027]";
            get_element_selector(_SELECTOR, false).nowait().exist()!
            VAR_WRONG_CAPTCHA_MODULE_2 = _result() == 1
            _if(VAR_WRONG_CAPTCHA_MODULE_2, function(){
            get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
            VAR_WRONG_CAPTCHA_MODULE_2 = _result().indexOf("true")>=0
            })!
            

            
            
            /*Browser*/
            ;_SELECTOR="\u003eCSS\u003e div[aria-label*=\u0027Error\u0027]";
            get_element_selector(_SELECTOR, false).nowait().exist()!
            VAR_WRONG_CAPTCHA_MODULE_3 = _result() == 1
            _if(VAR_WRONG_CAPTCHA_MODULE_3, function(){
            get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
            VAR_WRONG_CAPTCHA_MODULE_3 = _result().indexOf("true")>=0
            })!
            

            
            
            _set_if_expression("W1tXUk9OR19DQVBUQ0hBX01PRFVMRV8yXV0gPT0gdHJ1ZSB8fCBbW1dST05HX0NBUFRDSEFfTU9EVUxFXzNdXSA9PSB0cnVl");
            _if(VAR_WRONG_CAPTCHA_MODULE_2 == true || VAR_WRONG_CAPTCHA_MODULE_3 == true,function(){
            
               
               
               VAR_ERROR_CAP_MODULE = 1
               

               
               
               _break("function")
               

            })!
            

            
            
            /*Browser*/
            ;_SELECTOR=" \u003eCSS\u003e .geetest_canvas_slice";
            get_element_selector(_SELECTOR, false).nowait().exist()!
            VAR_IS_EXISTS_1 = _result() == 1
            _if(VAR_IS_EXISTS_1, function(){
            get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
            VAR_IS_EXISTS_1 = _result().indexOf("true")>=0
            })!
            

            
            
            _set_if_expression("W1tJU19FWElTVFNfMV1d");
            _if(typeof(VAR_IS_EXISTS_1) !== "undefined" ? (VAR_IS_EXISTS_1) : undefined,function(){
            
               
               
               VAR_GEETEST_TYPE_CAPTCHA = "GEETEST_VERSION_3"
               

               
               
               _break("function")
               

            })!
            

            
            
            /*Browser*/
            ;_SELECTOR=" \u003eCSS\u003e .geetest_track";
            get_element_selector(_SELECTOR, false).nowait().exist()!
            VAR_IS_EXISTS_2 = _result() == 1
            _if(VAR_IS_EXISTS_2, function(){
            get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
            VAR_IS_EXISTS_2 = _result().indexOf("true")>=0
            })!
            

            
            
            _set_if_expression("W1tJU19FWElTVFNfMl1d");
            _if(typeof(VAR_IS_EXISTS_2) !== "undefined" ? (VAR_IS_EXISTS_2) : undefined,function(){
            
               
               
               VAR_GEETEST_TYPE_CAPTCHA = "GEETEST_VERSION_4"
               

               
               
               _break("function")
               

            })!
            

            
            
            /*Browser*/
            ;_SELECTOR=" \u003eCSS\u003e .geetest_item_wrap";
            get_element_selector(_SELECTOR, false).nowait().exist()!
            VAR_IS_EXISTS_3 = _result() == 1
            _if(VAR_IS_EXISTS_3, function(){
            get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
            VAR_IS_EXISTS_3 = _result().indexOf("true")>=0
            })!
            

            
            
            _set_if_expression("W1tJU19FWElTVFNfM11d");
            _if(typeof(VAR_IS_EXISTS_3) !== "undefined" ? (VAR_IS_EXISTS_3) : undefined,function(){
            
               
               
               VAR_GEETEST_TYPE_CAPTCHA = "GEETEST_VERSION_3_CLICK"
               

               
               
               _break("function")
               

            })!
            

            
            
            /*Browser*/
            ;_SELECTOR=" \u003eCSS\u003e .geetest_item-0-0";
            get_element_selector(_SELECTOR, false).nowait().exist()!
            VAR_IS_EXISTS_4 = _result() == 1
            _if(VAR_IS_EXISTS_4, function(){
            get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
            VAR_IS_EXISTS_4 = _result().indexOf("true")>=0
            })!
            

            
            
            _set_if_expression("W1tJU19FWElTVFNfNF1d");
            _if(typeof(VAR_IS_EXISTS_4) !== "undefined" ? (VAR_IS_EXISTS_4) : undefined,function(){
            
               
               
               VAR_GEETEST_TYPE_CAPTCHA = "GEETEST_VERSION_4_SWAP_ITEMS"
               

               
               
               _break("function")
               

            })!
            

            
            
            _set_if_expression("W1tJU19FWElTVFNfMV1dID09IGZhbHNlICYmIFtbSVNfRVhJU1RTXzJdXSA9PSBmYWxzZSAmJiBbW0lTX0VYSVNUU18zXV0gPT0gZmFsc2UgJiYgW1tJU19FWElTVFNfNF1dID09IGZhbHNlICYmIFtbRklSU1RfTE9BRF9DQVBUQ0hBXV0gPT0gZmFsc2UgJiYgW1tDWUNMRV9JTkRFWF1dID4gMQ==");
            _if(VAR_IS_EXISTS_1 == false && VAR_IS_EXISTS_2 == false && VAR_IS_EXISTS_3 == false && VAR_IS_EXISTS_4 == false && VAR_FIRST_LOAD_CAPTCHA == false && VAR_CYCLE_INDEX > 1,function(){
            
               
               
               /*Browser*/
               cache_data_clear()!
               

               
               
               VAR_GREEN_TICK = true
               

               
               
               _break("function")
               

            })!
            

            
            
            _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gNDUgJiYgW1tGSVJTVF9MT0FEX0NBUFRDSEFdXSA9PSB0cnVlICYmIFtbSVNfRVhJU1RTXzFdXSA9PSBmYWxzZSAmJiBbW0lTX0VYSVNUU18yXV0gPT0gZmFsc2UgJiYgW1tJU19FWElTVFNfM11dID09IGZhbHNlICYmIFtbSVNfRVhJU1RTXzRdXSA9PSBmYWxzZQ==");
            _if(VAR_CYCLE_INDEX > 45 && VAR_FIRST_LOAD_CAPTCHA == true && VAR_IS_EXISTS_1 == false && VAR_IS_EXISTS_2 == false && VAR_IS_EXISTS_3 == false && VAR_IS_EXISTS_4 == false,function(){
            
               
               
               /*Browser*/
               cache_data_clear()!
               

               
               
               fail((_K==="en" ? "Failed to solve GeeTest captcha. This captcha type is Unknown" : "Не удалось решить Geetest капчу, модуль не умеет решать этот тип капчи"));
               

            })!
            

            
            
            sleep(rand(100,300))!
            

         })!
         

         
         
         VAR_CYCLE_INDEX = 0
         

         
         
         VAR_FIRST_LOAD_BUTTON = false
         

         
         
         _set_if_expression("W1tHUkVFTl9USUNLXV0gPT0gdHJ1ZSAmJiBbW1JFU1VMVF9TRUxFQ1RPUl1dICE9IDE=");
         _if(VAR_GREEN_TICK == true && VAR_RESULT_SELECTOR != 1,function(){
         
            
            
            /*Browser*/
            cache_data_clear()!
            

            
            
            _function_return("")
            

         })!
         

         
         
         VAR_TRY_CAPTCHA = parseInt(VAR_TRY_CAPTCHA) + parseInt(1)
         

         
         
         _set_if_expression("W1tUUllfQ0FQVENIQV1dID4gW1tUUllfTUFYX0NBUFRDSEFfUElDVFVSRV1d");
         _if(VAR_TRY_CAPTCHA > VAR_TRY_MAX_CAPTCHA_PICTURE,function(){
         
            
            
            fail((_K==="en" ? "Failed to solve the captcha. GeeTest attempts limit exceeded" : "Решить капчу не удалось. Превышен лимит попыток решить GeeTest капчу"));
            

         })!
         

         
         
         _set_if_expression("W1tFUlJPUl9DQVBfTU9EVUxFXV0gPT0gMQ==");
         _if(VAR_ERROR_CAP_MODULE == 1,function(){
         
            
            
            fail((_K==="en" ? "Geetest captcha solved incorrectly, error - ERROR_CAPTCHA_SOLVE" : "Geetest капча решена неверно, ошибка  - ERROR_CAPTCHA_SOLVE"));
            

         })!
         

         
         
         _call(function()
         {
         _on_fail(function(){
         VAR_LAST_ERROR = _result()
         VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
         VAR_WAS_ERROR = false
         _break(1,true)
         })
         CYCLES.Current().RemoveLabel("function")
         
            
            
            VAR_CYCLE_INDEX = "0"
            

            
            
            _set_if_expression("W1tHRUVURVNUX1RZUEVfQ0FQVENIQV1dID09ICJHRUVURVNUX1ZFUlNJT05fMyI=");
            _if(VAR_GEETEST_TYPE_CAPTCHA == "GEETEST_VERSION_3",function(){
            
               
               
               _do(function(){
               _set_action_info({ name: "For" });
               VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
               if(VAR_CYCLE_INDEX > parseInt(100))_break();
               
                  
                  
                  /*Browser*/
                  ;_SELECTOR=" \u003eCSS\u003e .geetest_canvas_slice";
                  get_element_selector(_SELECTOR, false).nowait().exist()!
                  VAR_IS_EXISTS = _result() == 1
                  _if(VAR_IS_EXISTS, function(){
                  get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
                  VAR_IS_EXISTS = _result().indexOf("true")>=0
                  })!
                  

                  
                  
                  _set_if_expression("IVtbSVNfRVhJU1RTXV0=");
                  _if(!VAR_IS_EXISTS,function(){
                  
                     
                     
                     _set_if_expression("cmFuZCAoMSwxMCkgPiA2");
                     _if(rand (1,10) > 6,function(){
                     
                        
                        
                        VAR_TRY_CAPTCHA = parseInt(VAR_TRY_CAPTCHA) + parseInt(-1)
                        

                     })!
                     

                     
                     
                     sleep(rand(100,300))!
                     

                     
                     
                     _long_goto("GeeTest Captcha Start here", 5, [])!
                     

                  })!
                  

                  
                  
                  /*Browser*/
                  ;_SELECTOR=" \u003eCSS\u003e .geetest_success_radar_tip_content";
                  get_element_selector(_SELECTOR, false).nowait().exist()!
                  VAR_IS_EXISTS = _result() == 1
                  _if(VAR_IS_EXISTS, function(){
                  get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
                  VAR_IS_EXISTS = _result().indexOf("true")>=0
                  })!
                  

                  
                  
                  _set_if_expression("W1tJU19FWElTVFNdXSA9PSB0cnVl");
                  _if(VAR_IS_EXISTS == true,function(){
                  
                     
                     
                     _long_goto("GeeTest Captcha Start here", 5, [])!
                     

                  })!
                  

                  
                  
                  cache_get_base64("*geetest.com/*/bg*")!
                  var image_id = native("imageprocessing", "load", _result())
                  var image_size = native("imageprocessing", "getsize", image_id)
                  var image_w = parseInt(image_size.split(",")[0])
                  var image_h = parseInt(image_size.split(",")[1])
                  if (image_h == 0 && VAR_CYCLE_INDEX > rand (60,95)) fail((_K === "en" ? "Failed to wait for GeeTest image from request cache" : "Не удалось дождаться картинку GeeTest капчи из кэша запроса"))
                  if (image_h > 125) {
                  VAR_IMAGE_BASE_64 = _result()
                  VAR_GET_IMAGE_H = image_h;
                  VAR_GET_IMAGE_W = image_w;
                  _break()
                  }
                  sleep(200)!
                  

               })!
               

               
               
               page().script2("var canvas_module = document.querySelector('.geetest_canvas_bg')\r\n[[IMAGE_BASE_64]] = canvas_module.toDataURL();\r\n\r\n\r\n",JSON.stringify(_read_variables(["VAR_IMAGE_BASE_64"])))!
               var _parse_result = JSON.parse(_result())
               _write_variables(JSON.parse(_parse_result.variables))
               if(!_parse_result.is_success)
               fail(_parse_result.error)
               

               
               
               var replace_string_geetest = "data:image/png;base64,"
               VAR_IMAGE_BASE_64 = VAR_IMAGE_BASE_64.replace(replace_string_geetest, "")
               

            })!
            

            
            
            _set_if_expression("W1tHRUVURVNUX1RZUEVfQ0FQVENIQV1dID09ICJHRUVURVNUX1ZFUlNJT05fNCI=");
            _if(VAR_GEETEST_TYPE_CAPTCHA == "GEETEST_VERSION_4",function(){
            
               
               
               _do(function(){
               _set_action_info({ name: "For" });
               VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
               if(VAR_CYCLE_INDEX > parseInt(60))_break();
               
                  
                  
                  /*Browser*/
                  ;_SELECTOR=" \u003eCSS\u003e .geetest_track";
                  get_element_selector(_SELECTOR, false).nowait().exist()!
                  VAR_IS_EXISTS = _result() == 1
                  _if(VAR_IS_EXISTS, function(){
                  get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
                  VAR_IS_EXISTS = _result().indexOf("true")>=0
                  })!
                  

                  
                  
                  _set_if_expression("IVtbSVNfRVhJU1RTXV0=");
                  _if(!VAR_IS_EXISTS,function(){
                  
                     
                     
                     _set_if_expression("cmFuZCAoMSwxMCkgPiA2");
                     _if(rand (1,10) > 6,function(){
                     
                        
                        
                        VAR_TRY_CAPTCHA = parseInt(VAR_TRY_CAPTCHA) + parseInt(-1)
                        

                     })!
                     

                     
                     
                     sleep(rand(100,300))!
                     

                     
                     
                     _long_goto("GeeTest Captcha Start here", 5, [])!
                     

                  })!
                  

                  
                  
                  /*Browser*/
                  ;_SELECTOR=" \u003eCSS\u003e .geetest_success_radar_tip_content";
                  get_element_selector(_SELECTOR, false).nowait().exist()!
                  VAR_IS_EXISTS = _result() == 1
                  _if(VAR_IS_EXISTS, function(){
                  get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
                  VAR_IS_EXISTS = _result().indexOf("true")>=0
                  })!
                  

                  
                  
                  _set_if_expression("W1tJU19FWElTVFNdXSA9PSB0cnVl");
                  _if(VAR_IS_EXISTS == true,function(){
                  
                     
                     
                     _long_goto("GeeTest Captcha Start here", 5, [])!
                     

                  })!
                  

                  
                  
                  cache_get_base64("*geetest.com/*/bg*")!
                  var image_id = native("imageprocessing", "load", _result())
                  var image_size = native("imageprocessing", "getsize", image_id)
                  var image_w = parseInt(image_size.split(",")[0])
                  var image_h = parseInt(image_size.split(",")[1])
                  if (image_h == 0 && VAR_CYCLE_INDEX > rand (45,58)) fail((_K === "en" ? "Failed to wait for GeeTest image from request cache" : "Не удалось дождаться картинку GeeTest капчи из кэша запроса"))
                  if (image_h > 100) {
                  VAR_IMAGE_BASE_64 = _result()
                  VAR_GET_IMAGE_H = image_h;
                  VAR_GET_IMAGE_W = image_w;
                  _break()
                  }
                  sleep(200)!
                  

               })!
               

               
               
               /*Browser*/
               cache_data_clear()!
               

            })!
            

            
            
            _set_if_expression("W1tHRUVURVNUX1RZUEVfQ0FQVENIQV1dID09ICJHRUVURVNUX1ZFUlNJT05fM19DTElDSyI=");
            _if(VAR_GEETEST_TYPE_CAPTCHA == "GEETEST_VERSION_3_CLICK",function(){
            
               
               
               _do(function(){
               _set_action_info({ name: "For" });
               VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
               if(VAR_CYCLE_INDEX > parseInt(100))_break();
               
                  
                  
                  /*Browser*/
                  ;_SELECTOR="\u003eCSS\u003e .geetest_item_wrap";
                  get_element_selector(_SELECTOR, false).nowait().exist()!
                  VAR_IS_EXISTS = _result() == 1
                  _if(VAR_IS_EXISTS, function(){
                  get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
                  VAR_IS_EXISTS = _result().indexOf("true")>=0
                  })!
                  

                  
                  
                  _set_if_expression("IVtbSVNfRVhJU1RTXV0=");
                  _if(!VAR_IS_EXISTS,function(){
                  
                     
                     
                     _set_if_expression("cmFuZCAoMSwxMCkgPiA2");
                     _if(rand (1,10) > 6,function(){
                     
                        
                        
                        VAR_TRY_CAPTCHA = parseInt(VAR_TRY_CAPTCHA) + parseInt(-1)
                        

                     })!
                     

                     
                     
                     sleep(rand(100,300))!
                     

                     
                     
                     _long_goto("GeeTest Captcha Start here", 5, [])!
                     

                  })!
                  

                  
                  
                  cache_get_base64("*geetest.com/captcha*")!
                  var image_id = native("imageprocessing", "load", _result())
                  var image_size = native("imageprocessing", "getsize", image_id)
                  var image_w = parseInt(image_size.split(",")[0])
                  var image_h = parseInt(image_size.split(",")[1])
                  if (image_h == 0 && VAR_CYCLE_INDEX > rand (60,95)) fail((_K === "en" ? "Failed to wait for GeeTest image from request cache" : "Не удалось дождаться картинку GeeTest капчи из кэша запроса"))
                  if (image_h > 125) {
                  VAR_IMAGE_BASE_64 = _result()
                  VAR_GET_IMAGE_H = image_h;
                  VAR_GET_IMAGE_W = image_w;
                  _break()
                  }
                  sleep(200)!
                  

               })!
               

               
               
               /*Browser*/
               cache_data_clear()!
               

            })!
            

            
            
            _set_if_expression("W1tHRUVURVNUX1RZUEVfQ0FQVENIQV1dID09ICJHRUVURVNUX1ZFUlNJT05fNF9TV0FQX0lURU1TIg==");
            _if(VAR_GEETEST_TYPE_CAPTCHA == "GEETEST_VERSION_4_SWAP_ITEMS",function(){
            
               
               
               /*Browser*/
               ;_SELECTOR=" \u003eCSS\u003e .geetest_item-4-0";
               get_element_selector(_SELECTOR, false).nowait().exist()!
               VAR_IS_FIVE_TYPE_GEETEST = _result() == 1
               _if(VAR_IS_FIVE_TYPE_GEETEST, function(){
               get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
               VAR_IS_FIVE_TYPE_GEETEST = _result().indexOf("true")>=0
               })!
               

               
               
               _do(function(){
               _set_action_info({ name: "For" });
               VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
               if(VAR_CYCLE_INDEX > parseInt(100))_break();
               
                  
                  
                  /*Browser*/
                  ;_SELECTOR=" \u003eCSS\u003e .geetest_item-0-0";
                  get_element_selector(_SELECTOR, false).nowait().exist()!
                  VAR_IS_EXISTS = _result() == 1
                  _if(VAR_IS_EXISTS, function(){
                  get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
                  VAR_IS_EXISTS = _result().indexOf("true")>=0
                  })!
                  

                  
                  
                  _set_if_expression("IVtbSVNfRVhJU1RTXV0=");
                  _if(!VAR_IS_EXISTS,function(){
                  
                     
                     
                     _set_if_expression("cmFuZCAoMSwxMCkgPiA2");
                     _if(rand (1,10) > 6,function(){
                     
                        
                        
                        VAR_TRY_CAPTCHA = parseInt(VAR_TRY_CAPTCHA) + parseInt(-1)
                        

                     })!
                     

                     
                     
                     sleep(rand(100,300))!
                     

                     
                     
                     _long_goto("GeeTest Captcha Start here", 5, [])!
                     

                  })!
                  

                  
                  
                  cache_get_base64("*geetest.com/nerualpic*")!
                  var image_id = native("imageprocessing", "load", _result())
                  var image_size = native("imageprocessing", "getsize", image_id)
                  var image_w = parseInt(image_size.split(",")[0])
                  var image_h = parseInt(image_size.split(",")[1])
                  if (image_h == 0 && VAR_CYCLE_INDEX > rand (60,95)) fail((_K === "en" ? "Failed to wait for GeeTest image from request cache" : "Не удалось дождаться картинку GeeTest капчи из кэша запроса"))
                  if (image_h > 60) {
                  VAR_IMAGE_BASE_64 = _result()
                  VAR_GET_IMAGE_H = image_h;
                  VAR_GET_IMAGE_W = image_w;
                  _break()
                  }
                  sleep(200)!
                  

               })!
               

               
               
               /*Browser*/
               cache_data_clear()!
               

            })!
            

         },null)!
         

         
         
         _set_if_expression("W1tXQVNfRVJST1JdXQ==");
         _if(typeof(VAR_WAS_ERROR) !== "undefined" ? (VAR_WAS_ERROR) : undefined,function(){
         
            
            
            _call(function()
            {
            _on_fail(function(){
            VAR_LAST_ERROR = _result()
            VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
            VAR_WAS_ERROR = false
            _break(1,true)
            })
            CYCLES.Current().RemoveLabel("function")
            
               
               
               /*Browser*/
               ;_SELECTOR="\u003eCSS\u003e a[class*=\u0027geetest_refresh\u0027]";
               get_element_selector(_SELECTOR, false).nowait().exist()!
               VAR_IS_EXISTS = _result() == 1
               _if(VAR_IS_EXISTS, function(){
               get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
               VAR_IS_EXISTS = _result().indexOf("true")>=0
               })!
               

               
               
               _set_if_expression("W1tJU19FWElTVFNdXQ==");
               _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
               
                  
                  
                  /*Browser*/
                  cache_data_clear()!
                  

                  
                  
                  /*Browser*/
                  _SELECTOR = "\u003eCSS\u003e a[class*=\u0027geetest_refresh\u0027]";
                  wait_element_visible(_SELECTOR)!
                  _call(_random_point, {})!
                  _if(_result().length > 0, function(){
                  move( {"speed": 100,"gravity": 6,"deviation": 2.5} )!
                  get_element_selector(_SELECTOR, false).clarify(X,Y)!
                  _call(_clarify, {"speed": 100,"gravity": 6,"deviation": 2.5} )!
                  mouse(X,Y)!
                  })!
                  

                  
                  
                  VAR_FAIL_SOLVE_MODULE_CAPTCHA = 0
                  

               })!
               

               
               
               /*Browser*/
               ;_SELECTOR="\u003eCSS\u003e button[class*=\u0027geetest_refresh\u0027]";
               get_element_selector(_SELECTOR, false).nowait().exist()!
               VAR_IS_EXISTS = _result() == 1
               _if(VAR_IS_EXISTS, function(){
               get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
               VAR_IS_EXISTS = _result().indexOf("true")>=0
               })!
               

               
               
               _set_if_expression("W1tJU19FWElTVFNdXQ==");
               _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
               
                  
                  
                  /*Browser*/
                  cache_data_clear()!
                  

                  
                  
                  /*Browser*/
                  _SELECTOR = "\u003eCSS\u003e button[class*=\u0027geetest_refresh\u0027]";
                  wait_element_visible(_SELECTOR)!
                  _call(_random_point, {})!
                  _if(_result().length > 0, function(){
                  move( {"speed": 100,"gravity": 6,"deviation": 2.5} )!
                  get_element_selector(_SELECTOR, false).clarify(X,Y)!
                  _call(_clarify, {"speed": 100,"gravity": 6,"deviation": 2.5} )!
                  mouse(X,Y)!
                  })!
                  

                  
                  
                  VAR_FAIL_SOLVE_MODULE_CAPTCHA = 0
                  

               })!
               

               
               
               sleep(rand(1000,2000))!
               

            },null)!
            

            
            
            _next("function")
            

         })!
         

         
         
         _call(function()
         {
         _on_fail(function(){
         VAR_LAST_ERROR = _result()
         VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
         VAR_WAS_ERROR = false
         _break(1,true)
         })
         CYCLES.Current().RemoveLabel("function")
         
            
            
            _set_if_expression("W1tGQUlMX1NPTFZFX01PRFVMRV9DQVBUQ0hBXV0gPiAx");
            _if(VAR_FAIL_SOLVE_MODULE_CAPTCHA > 1,function(){
            
               
               
               sleep(1000)!
               

               
               
               /*Browser*/
               ;_SELECTOR="\u003eCSS\u003e a[class*=\u0027geetest_refresh\u0027]";
               get_element_selector(_SELECTOR, false).nowait().exist()!
               VAR_IS_EXISTS = _result() == 1
               _if(VAR_IS_EXISTS, function(){
               get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
               VAR_IS_EXISTS = _result().indexOf("true")>=0
               })!
               

               
               
               _set_if_expression("W1tJU19FWElTVFNdXSAmJiByYW5kICgxLDEwKSA+IDU=");
               _if(VAR_IS_EXISTS && rand (1,10) > 5,function(){
               
                  
                  
                  /*Browser*/
                  cache_data_clear()!
                  

                  
                  
                  VAR_FAIL_SOLVE_MODULE_CAPTCHA = 0
                  

                  
                  
                  /*Browser*/
                  _SELECTOR = "\u003eCSS\u003e a[class*=\u0027geetest_refresh\u0027]";
                  wait_element_visible(_SELECTOR)!
                  _call(_random_point, {})!
                  _if(_result().length > 0, function(){
                  move( {"speed": 100,"gravity": 6,"deviation": 2.5} )!
                  get_element_selector(_SELECTOR, false).clarify(X,Y)!
                  _call(_clarify, {"speed": 100,"gravity": 6,"deviation": 2.5} )!
                  mouse(X,Y)!
                  })!
                  

                  
                  
                  sleep(1000)!
                  

                  
                  
                  _long_goto("GeeTest Captcha Start here", 4, [])!
                  

               })!
               

               
               
               /*Browser*/
               ;_SELECTOR="\u003eCSS\u003e button[class*=\u0027geetest_refresh\u0027]";
               get_element_selector(_SELECTOR, false).nowait().exist()!
               VAR_IS_EXISTS = _result() == 1
               _if(VAR_IS_EXISTS, function(){
               get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
               VAR_IS_EXISTS = _result().indexOf("true")>=0
               })!
               

               
               
               _set_if_expression("W1tJU19FWElTVFNdXSAmJiByYW5kICgxLDEwKSA+IDU=");
               _if(VAR_IS_EXISTS && rand (1,10) > 5,function(){
               
                  
                  
                  /*Browser*/
                  cache_data_clear()!
                  

                  
                  
                  /*Browser*/
                  _SELECTOR = "\u003eCSS\u003e button[class*=\u0027geetest_refresh\u0027]";
                  wait_element_visible(_SELECTOR)!
                  _call(_random_point, {})!
                  _if(_result().length > 0, function(){
                  move( {"speed": 100,"gravity": 6,"deviation": 2.5} )!
                  get_element_selector(_SELECTOR, false).clarify(X,Y)!
                  _call(_clarify, {"speed": 100,"gravity": 6,"deviation": 2.5} )!
                  mouse(X,Y)!
                  })!
                  

                  
                  
                  VAR_FAIL_SOLVE_MODULE_CAPTCHA = 0
                  

                  
                  
                  sleep(1000)!
                  

                  
                  
                  _long_goto("GeeTest Captcha Start here", 4, [])!
                  

               })!
               

            })!
            

         },null)!
         

         
         
         _call(function()
         {
         _on_fail(function(){
         VAR_LAST_ERROR = _result()
         VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
         VAR_WAS_ERROR = false
         _break(1,true)
         })
         CYCLES.Current().RemoveLabel("function")
         
            
            
            _set_if_expression("W1tJU19NT0JJTEVdXSA9PT0gZmFsc2U=");
            _if(VAR_IS_MOBILE === false,function(){
            
               
               
               _get_browser_screen_settings()!
               ;(function(){
               var result = JSON.parse(_result())
               VAR_SCROLL_X = result["ScrollX"]
               VAR_SCROLL_Y = result["ScrollY"]
               VAR_CURSOR_X = result["CursorX"]
               VAR_CURSOR_Y = result["CursorY"]
               VAR_BROWSER_WIDTH = result["Width"]
               VAR_BROWSER_HEIGHT = result["Height"]
               })();
               

               
               
               _set_if_expression("W1tHRUVURVNUX1RZUEVfQ0FQVENIQV1dID09ICJHRUVURVNUX1ZFUlNJT05fMyI=");
               _if(VAR_GEETEST_TYPE_CAPTCHA == "GEETEST_VERSION_3",function(){
               
                  
                  
                  /*Browser*/
                  ;_SELECTOR="\u003eCSS\u003e div[class*=\u0027geetest_holder geetest_mobile\u0027]";
                  get_element_selector(_SELECTOR, false).nowait().exist()!
                  VAR_IS_EXISTS = _result() == 1
                  _if(VAR_IS_EXISTS, function(){
                  get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
                  VAR_IS_EXISTS = _result().indexOf("true")>=0
                  })!
                  

                  
                  
                  _set_if_expression("IVtbSVNfRVhJU1RTXV0=");
                  _if(!VAR_IS_EXISTS,function(){
                  
                     
                     
                     _next("function")
                     

                  })!
                  

                  
                  
                  _set_if_expression("W1tJU19FWElTVFNdXQ==");
                  _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
                  
                     
                     
                     /*Browser*/
                     _SELECTOR = "\u003eCSS\u003e div[class*=\u0027geetest_holder geetest_mobile\u0027]";
                     wait_element(_SELECTOR)!
                     get_element_selector(_SELECTOR, false).script("(function(){var rect = _BAS_HIDE(BrowserAutomationStudio_GetBoundingClientRect)(self);return (rect.left + positionx) + '|' + (rect.top + positiony) + '|' + (rect.right - rect.left) + '|' + (rect.bottom - rect.top)})();")!
                     if(_result().length > 0)
                     {
                     var split = _result().split("|")
                     VAR_X = parseInt(split[0])
                     VAR_Y = parseInt(split[1])
                     VAR_CAPTCHA_WIDTH = parseInt(split[2])
                     VAR_CAPTCHA_HEIGHT = parseInt(split[3])
                     }
                     

                     
                     
                     /*Browser*/
                     move(rand(VAR_X/100*115 + VAR_SCROLL_X,(VAR_X+VAR_SCROLL_X+VAR_CAPTCHA_WIDTH)/100*93).toFixed(),rand(VAR_Y + VAR_SCROLL_Y/100*120,VAR_Y + VAR_SCROLL_Y + VAR_CAPTCHA_HEIGHT/100*90).toFixed(),  {} )!
                     

                  })!
                  

               })!
               

               
               
               _set_if_expression("W1tHRUVURVNUX1RZUEVfQ0FQVENIQV1dID09ICJHRUVURVNUX1ZFUlNJT05fNCI=");
               _if(VAR_GEETEST_TYPE_CAPTCHA == "GEETEST_VERSION_4",function(){
               
                  
                  
                  /*Browser*/
                  ;_SELECTOR=" \u003eCSS\u003e .geetest_bg";
                  get_element_selector(_SELECTOR, false).nowait().exist()!
                  VAR_IS_EXISTS = _result() == 1
                  _if(VAR_IS_EXISTS, function(){
                  get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
                  VAR_IS_EXISTS = _result().indexOf("true")>=0
                  })!
                  

                  
                  
                  _set_if_expression("IVtbSVNfRVhJU1RTXV0=");
                  _if(!VAR_IS_EXISTS,function(){
                  
                     
                     
                     _next("function")
                     

                  })!
                  

                  
                  
                  _set_if_expression("W1tJU19FWElTVFNdXQ==");
                  _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
                  
                     
                     
                     /*Browser*/
                     _SELECTOR = " \u003eCSS\u003e .geetest_bg";
                     wait_element(_SELECTOR)!
                     get_element_selector(_SELECTOR, false).script("(function(){var rect = _BAS_HIDE(BrowserAutomationStudio_GetBoundingClientRect)(self);return (rect.left + positionx) + '|' + (rect.top + positiony) + '|' + (rect.right - rect.left) + '|' + (rect.bottom - rect.top)})();")!
                     if(_result().length > 0)
                     {
                     var split = _result().split("|")
                     VAR_X = parseInt(split[0])
                     VAR_Y = parseInt(split[1])
                     VAR_CAPTCHA_WIDTH = parseInt(split[2])
                     VAR_CAPTCHA_HEIGHT = parseInt(split[3])
                     }
                     

                     
                     
                     /*Browser*/
                     move(rand(VAR_X/100*115,(VAR_X+VAR_CAPTCHA_WIDTH)/100*93).toFixed(),rand(VAR_Y + VAR_SCROLL_Y/100*120,VAR_Y + VAR_SCROLL_Y + VAR_CAPTCHA_HEIGHT/100*90).toFixed(),  {} )!
                     

                  })!
                  

               })!
               

               
               
               _set_if_expression("W1tHRUVURVNUX1RZUEVfQ0FQVENIQV1dID09ICJHRUVURVNUX1ZFUlNJT05fM19DTElDSyI=");
               _if(VAR_GEETEST_TYPE_CAPTCHA == "GEETEST_VERSION_3_CLICK",function(){
               
                  
                  
                  /*Browser*/
                  ;_SELECTOR="\u003eCSS\u003e .geetest_item_wrap";
                  get_element_selector(_SELECTOR, false).nowait().exist()!
                  VAR_IS_EXISTS = _result() == 1
                  _if(VAR_IS_EXISTS, function(){
                  get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
                  VAR_IS_EXISTS = _result().indexOf("true")>=0
                  })!
                  

                  
                  
                  _set_if_expression("IVtbSVNfRVhJU1RTXV0=");
                  _if(!VAR_IS_EXISTS,function(){
                  
                     
                     
                     _next("function")
                     

                  })!
                  

                  
                  
                  _set_if_expression("W1tJU19FWElTVFNdXQ==");
                  _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
                  
                     
                     
                     /*Browser*/
                     _SELECTOR = "\u003eCSS\u003e .geetest_item_wrap";
                     wait_element(_SELECTOR)!
                     get_element_selector(_SELECTOR, false).script("(function(){var rect = _BAS_HIDE(BrowserAutomationStudio_GetBoundingClientRect)(self);return (rect.left + positionx) + '|' + (rect.top + positiony) + '|' + (rect.right - rect.left) + '|' + (rect.bottom - rect.top)})();")!
                     if(_result().length > 0)
                     {
                     var split = _result().split("|")
                     VAR_X_BUTTON = parseInt(split[0])
                     VAR_Y_BUTTON = parseInt(split[1])
                     VAR_CAPTCHA_WIDTH = parseInt(split[2])
                     VAR_CAPTCHA_HEIGHT = parseInt(split[3])
                     }
                     

                     
                     
                     /*Browser*/
                     move(rand(VAR_X_BUTTON/100*115,(VAR_X_BUTTON+VAR_CAPTCHA_WIDTH)/100*93).toFixed(),rand(VAR_Y_BUTTON + VAR_SCROLL_Y/100*120,VAR_Y_BUTTON + VAR_SCROLL_Y + VAR_CAPTCHA_HEIGHT/100*90).toFixed(),  {} )!
                     

                  })!
                  

               })!
               

               
               
               _set_if_expression("W1tHRUVURVNUX1RZUEVfQ0FQVENIQV1dID09ICJHRUVURVNUX1ZFUlNJT05fNF9TV0FQX0lURU1TIg==");
               _if(VAR_GEETEST_TYPE_CAPTCHA == "GEETEST_VERSION_4_SWAP_ITEMS",function(){
               
                  
                  
                  /*Browser*/
                  ;_SELECTOR="\u003eCSS\u003e .geetest_box";
                  get_element_selector(_SELECTOR, false).nowait().exist()!
                  VAR_IS_EXISTS = _result() == 1
                  _if(VAR_IS_EXISTS, function(){
                  get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
                  VAR_IS_EXISTS = _result().indexOf("true")>=0
                  })!
                  

                  
                  
                  _set_if_expression("IVtbSVNfRVhJU1RTXV0=");
                  _if(!VAR_IS_EXISTS,function(){
                  
                     
                     
                     _next("function")
                     

                  })!
                  

                  
                  
                  _set_if_expression("W1tJU19FWElTVFNdXQ==");
                  _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
                  
                     
                     
                     /*Browser*/
                     _SELECTOR = "\u003eCSS\u003e .geetest_box";
                     wait_element(_SELECTOR)!
                     get_element_selector(_SELECTOR, false).script("(function(){var rect = _BAS_HIDE(BrowserAutomationStudio_GetBoundingClientRect)(self);return (rect.left + positionx) + '|' + (rect.top + positiony) + '|' + (rect.right - rect.left) + '|' + (rect.bottom - rect.top)})();")!
                     if(_result().length > 0)
                     {
                     var split = _result().split("|")
                     VAR_X_BUTTON = parseInt(split[0])
                     VAR_Y_BUTTON = parseInt(split[1])
                     VAR_CAPTCHA_WIDTH = parseInt(split[2])
                     VAR_CAPTCHA_HEIGHT = parseInt(split[3])
                     }
                     

                     
                     
                     /*Browser*/
                     move(rand(VAR_X_BUTTON/100*115,(VAR_X_BUTTON+VAR_CAPTCHA_WIDTH)/100*93).toFixed(),rand(VAR_Y_BUTTON + VAR_SCROLL_Y/100*120,VAR_Y_BUTTON + VAR_SCROLL_Y + VAR_CAPTCHA_HEIGHT/100*90).toFixed(),  {} )!
                     

                  })!
                  

                  
                  
                  /*Browser*/
                  _SELECTOR = "\u003eCSS\u003e .geetest_box";
                  wait_element(_SELECTOR)!
                  get_element_selector(_SELECTOR, false).exist()!
                  _if(_result() == "1", function(){
                  get_element_selector(_SELECTOR, false).render_base64()!
                  VAR_IMAGE_BASE_64 = _result()
                  })!
                  

               })!
               

            })!
            

         },null)!
         

         
         
         VAR_FIRST_LOAD_CAPTCHA = false
         

         
         
         _call(function()
         {
         _on_fail(function(){
         VAR_LAST_ERROR = _result()
         VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
         VAR_WAS_ERROR = false
         _break(1,true)
         })
         CYCLES.Current().RemoveLabel("function")
         
            
            
            _do(function(){
            _set_action_info({ name: "For" });
            VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
            if(VAR_CYCLE_INDEX > parseInt(20))_break();
            
               
               
               ///Чистим
               solver_properties_clear("capmonster")
               if (VAR_METHOD_MODULE == "CaptchaGuru (RU Server)") VAR_SERVER_SOLVE = "https://92.53.65.152/"
               if (VAR_METHOD_MODULE == "CaptchaGuru (German Server)") VAR_SERVER_SOLVE = "https://159.69.241.182/"
               if (VAR_METHOD_MODULE == "CaptchaGuru (Finland Server)") VAR_SERVER_SOLVE = "https://95.217.17.172/"
               /// Если юзер оставил старый метод и не пересоздал дейстие с модулем, то оставим дефолт сервер хецнер
               if (VAR_METHOD_MODULE == "CaptchaGuru") VAR_SERVER_SOLVE = "https://159.69.241.182/"
               /// Формирумем основной запрос
               solver_property("capmonster","serverurl",VAR_SERVER_SOLVE)
               solver_property("capmonster","coordinatescaptcha","1")
               solver_property("capmonster","key",VAR_KEY_MODULE)
               solver_property("capmonster","click","geetest")
               solver_property("capmonster","basmodule",VAR_BAS_MODULE_VERSION)
               solver_property("capmonster","method","post")
               if (VAR_GEETEST_TYPE_CAPTCHA == "GEETEST_VERSION_3_CLICK") solver_property("capmonster","textinstructions","order")
               if (VAR_GEETEST_TYPE_CAPTCHA == "GEETEST_VERSION_4_SWAP_ITEMS" && VAR_IS_FIVE_TYPE_GEETEST == true) solver_property("capmonster","textinstructions","Click and drop to line up five identical items in a row")
               if (VAR_GEETEST_TYPE_CAPTCHA == "GEETEST_VERSION_4_SWAP_ITEMS" && VAR_IS_FIVE_TYPE_GEETEST == false) solver_property("capmonster","textinstructions","Click and swap to line up three identical items in a row")
               //// Отправляем
               solve_base64_no_fail("capmonster", VAR_IMAGE_BASE_64)!
               VAR_SAVED_CONTENT = _result();
               

               
               
               _set_if_expression("W1tTQVZFRF9DT05URU5UXV0uaW5kZXhPZigiRVJST1JfQ0FQVENIQV9VTlNPTFZBQkxFIikgPj0gMA==");
               _if(VAR_SAVED_CONTENT.indexOf("ERROR_CAPTCHA_UNSOLVABLE") >= 0,function(){
               
                  
                  
                  /*Browser*/
                  ;_SELECTOR="\u003eCSS\u003e a[class*=\u0027geetest_refresh\u0027]";
                  get_element_selector(_SELECTOR, false).nowait().exist()!
                  VAR_IS_EXISTS = _result() == 1
                  _if(VAR_IS_EXISTS, function(){
                  get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
                  VAR_IS_EXISTS = _result().indexOf("true")>=0
                  })!
                  

                  
                  
                  _set_if_expression("W1tJU19FWElTVFNdXQ==");
                  _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
                  
                     
                     
                     /*Browser*/
                     cache_data_clear()!
                     

                     
                     
                     /*Browser*/
                     _SELECTOR = "\u003eCSS\u003e a[class*=\u0027geetest_refresh\u0027]";
                     wait_element_visible(_SELECTOR)!
                     _call(_random_point, {})!
                     _if(_result().length > 0, function(){
                     move( {"speed": 100,"gravity": 6,"deviation": 2.5} )!
                     get_element_selector(_SELECTOR, false).clarify(X,Y)!
                     _call(_clarify, {"speed": 100,"gravity": 6,"deviation": 2.5} )!
                     mouse(X,Y)!
                     })!
                     

                     
                     
                     VAR_FAIL_SOLVE_MODULE_CAPTCHA = 0
                     

                  })!
                  

                  
                  
                  /*Browser*/
                  ;_SELECTOR="\u003eCSS\u003e button[class*=\u0027geetest_refresh\u0027]";
                  get_element_selector(_SELECTOR, false).nowait().exist()!
                  VAR_IS_EXISTS = _result() == 1
                  _if(VAR_IS_EXISTS, function(){
                  get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
                  VAR_IS_EXISTS = _result().indexOf("true")>=0
                  })!
                  

                  
                  
                  _set_if_expression("W1tJU19FWElTVFNdXQ==");
                  _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
                  
                     
                     
                     /*Browser*/
                     cache_data_clear()!
                     

                     
                     
                     /*Browser*/
                     _SELECTOR = "\u003eCSS\u003e button[class*=\u0027geetest_refresh\u0027]";
                     wait_element_visible(_SELECTOR)!
                     _call(_random_point, {})!
                     _if(_result().length > 0, function(){
                     move( {"speed": 100,"gravity": 6,"deviation": 2.5} )!
                     get_element_selector(_SELECTOR, false).clarify(X,Y)!
                     _call(_clarify, {"speed": 100,"gravity": 6,"deviation": 2.5} )!
                     mouse(X,Y)!
                     })!
                     

                     
                     
                     VAR_FAIL_SOLVE_MODULE_CAPTCHA = 0
                     

                  })!
                  

                  
                  
                  sleep(rand(1000,3000))!
                  

                  
                  
                  _break("function")
                  

               })!
               

               
               
               _set_if_expression("W1tTQVZFRF9DT05URU5UXV0uaW5kZXhPZigiRVJST1JfV1JPTkdfVVNFUl9LRVkiKSA+PSAw");
               _if(VAR_SAVED_CONTENT.indexOf("ERROR_WRONG_USER_KEY") >= 0,function(){
               
                  
                  
                  VAR_ERROR_KEY = "1"
                  

                  
                  
                  _break("function")
                  

               })!
               

               
               
               _set_if_expression("W1tTQVZFRF9DT05URU5UXV0uaW5kZXhPZigiRVJST1JfWkVST19CQUxBTkNFIikgPj0gMA==");
               _if(VAR_SAVED_CONTENT.indexOf("ERROR_ZERO_BALANCE") >= 0,function(){
               
                  
                  
                  VAR_ERROR_BALANCE = "1"
                  

                  
                  
                  _break("function")
                  

               })!
               

               
               
               _set_if_expression("W1tTQVZFRF9DT05URU5UXV0uaW5kZXhPZigiQ0FQVENIQV9GQUlMIikgPj0gMA==");
               _if(VAR_SAVED_CONTENT.indexOf("CAPTCHA_FAIL") >= 0,function(){
               
                  
                  
                  sleep(rand(1000,2000))!
                  

                  
                  
                  VAR_CAPTCHA_FAIL = parseInt(VAR_CAPTCHA_FAIL) + parseInt(1)
                  

                  
                  
                  _break("function")
                  

               })!
               

               
               
               _cycle_params().if_else = VAR_SAVED_CONTENT.match(/[0-9]/) && VAR_SAVED_CONTENT.indexOf("coordinates") >= 0;
               _set_if_expression("W1tTQVZFRF9DT05URU5UXV0ubWF0Y2goL1swLTldLykgJiYgW1tTQVZFRF9DT05URU5UXV0uaW5kZXhPZigiY29vcmRpbmF0ZXMiKSA+PSAw");
               _if(_cycle_params().if_else,function(){
               
                  
                  
                  var dd = VAR_SAVED_CONTENT;
                  var num_slide = dd.replace(/[;]+/g,",").replace(/[^0-9,]/g,"").split(",") /// Спарсили все цифры с ответа
                  VAR_X2 = parseInt(num_slide[0]); /// X2 координата куда двигать на картинке
                  VAR_Y2 = parseInt(num_slide[1]); /// Y2 координата куда двигать на картинке
                  VAR_W2 = parseInt(num_slide[2]); /// W2 координата куда двигать на картинке
                  

                  
                  
                  _get_browser_screen_settings()!
                  ;(function(){
                  var result = JSON.parse(_result())
                  VAR_SCROLL_X = result["ScrollX"]
                  VAR_SCROLL_Y = result["ScrollY"]
                  VAR_CURSOR_X = result["CursorX"]
                  VAR_CURSOR_Y = result["CursorY"]
                  VAR_BROWSER_WIDTH = result["Width"]
                  VAR_BROWSER_HEIGHT = result["Height"]
                  })();
                  

                  
                  
                  /*Browser*/
                  ;_SELECTOR=" \u003eCSS\u003e .geetest_slider_tip";
                  get_element_selector(_SELECTOR, false).nowait().exist()!
                  VAR_IS_EXISTS = _result() == 1
                  _if(VAR_IS_EXISTS, function(){
                  get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
                  VAR_IS_EXISTS = _result().indexOf("true")>=0
                  })!
                  

                  
                  
                  _set_if_expression("W1tJU19FWElTVFNdXQ==");
                  _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
                  
                     
                     
                     /*Browser*/
                     _SELECTOR = " \u003eCSS\u003e .geetest_slider_button";
                     wait_element(_SELECTOR)!
                     get_element_selector(_SELECTOR, false).script("(function(){var rect = _BAS_HIDE(BrowserAutomationStudio_GetBoundingClientRect)(self);return (rect.left + positionx) + '|' + (rect.top + positiony) + '|' + (rect.right - rect.left) + '|' + (rect.bottom - rect.top)})();")!
                     if(_result().length > 0)
                     {
                     var split = _result().split("|")
                     VAR_X = parseInt(split[0])
                     VAR_Y = parseInt(split[1])
                     VAR_WIDTH = parseInt(split[2])
                     VAR_HEIGHT = parseInt(split[3])
                     }
                     

                     
                     
                     /*Browser*/
                     _SELECTOR = " \u003eCSS\u003e .geetest_slider_tip";
                     wait_element(_SELECTOR)!
                     get_element_selector(_SELECTOR, false).script("(function(){var rect = _BAS_HIDE(BrowserAutomationStudio_GetBoundingClientRect)(self);return (rect.left + positionx) + '|' + (rect.top + positiony) + '|' + (rect.right - rect.left) + '|' + (rect.bottom - rect.top)})();")!
                     if(_result().length > 0)
                     {
                     var split = _result().split("|")
                     VAR_X_CENTER = parseInt(split[0])
                     VAR_Y_CENTER = parseInt(split[1])
                     VAR_WIDTH_CENTER = parseInt(split[2])
                     VAR_HEIGHT_CENTER = parseInt(split[3])
                     }
                     

                     
                     
                     VAR_XBUTON = (VAR_X + VAR_SCROLL_X + (VAR_HEIGHT/2))
                     VAR_YBUTON = (VAR_Y + VAR_SCROLL_Y + (VAR_WIDTH/2))
                     

                  })!
                  

                  
                  
                  /*Browser*/
                  ;_SELECTOR=" \u003eCSS\u003e .geetest_track";
                  get_element_selector(_SELECTOR, false).nowait().exist()!
                  VAR_IS_EXISTS2 = _result() == 1
                  _if(VAR_IS_EXISTS2, function(){
                  get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
                  VAR_IS_EXISTS2 = _result().indexOf("true")>=0
                  })!
                  

                  
                  
                  _set_if_expression("W1tJU19FWElTVFMyXV0=");
                  _if(typeof(VAR_IS_EXISTS2) !== "undefined" ? (VAR_IS_EXISTS2) : undefined,function(){
                  
                     
                     
                     /*Browser*/
                     _SELECTOR = " \u003eCSS\u003e .geetest_window";
                     wait_element(_SELECTOR)!
                     get_element_selector(_SELECTOR, false).script("(function(){var rect = _BAS_HIDE(BrowserAutomationStudio_GetBoundingClientRect)(self);return (rect.left + positionx) + '|' + (rect.top + positiony) + '|' + (rect.right - rect.left) + '|' + (rect.bottom - rect.top)})();")!
                     if(_result().length > 0)
                     {
                     var split = _result().split("|")
                     VAR_X_PICTRURE = parseInt(split[0])
                     VAR_Y_PICTRURE = parseInt(split[1])
                     VAR_WIDTH_PICTRURE = parseInt(split[2])
                     VAR_HEIGHT_PICTRURE = parseInt(split[3])
                     }
                     

                     
                     
                     /*Browser*/
                     _SELECTOR = " \u003eCSS\u003e .geetest_track";
                     wait_element(_SELECTOR)!
                     get_element_selector(_SELECTOR, false).script("(function(){var rect = _BAS_HIDE(BrowserAutomationStudio_GetBoundingClientRect)(self);return (rect.left + positionx) + '|' + (rect.top + positiony) + '|' + (rect.right - rect.left) + '|' + (rect.bottom - rect.top)})();")!
                     if(_result().length > 0)
                     {
                     var split = _result().split("|")
                     VAR_X_SLIDER = parseInt(split[0])
                     VAR_Y_SLIDER = parseInt(split[1])
                     VAR_WIDTH_SLIDER = parseInt(split[2])
                     VAR_HEIGHT_SLIDER = parseInt(split[3])
                     }
                     

                     
                     
                     VAR_Y_SLIDER = VAR_Y_SLIDER + VAR_HEIGHT_SLIDER/2 + VAR_SCROLL_Y; /// Координаты прогресс бага где нужно двигать ползунок
                     VAR_X_SLIDER = VAR_X_SLIDER + VAR_SCROLL_X;
                     VAR_X2 = VAR_X2/VAR_GET_IMAGE_W*VAR_CAPTCHA_WIDTH;
                     

                  })!
                  

                  
                  
                  /*Browser*/
                  ;_SELECTOR="\u003eCSS\u003e .geetest_item_wrap";
                  get_element_selector(_SELECTOR, false).nowait().exist()!
                  VAR_IS_EXISTS3 = _result() == 1
                  _if(VAR_IS_EXISTS3, function(){
                  get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
                  VAR_IS_EXISTS3 = _result().indexOf("true")>=0
                  })!
                  

                  
                  
                  _set_if_expression("W1tJU19FWElTVFMzXV0=");
                  _if(typeof(VAR_IS_EXISTS3) !== "undefined" ? (VAR_IS_EXISTS3) : undefined,function(){
                  
                     
                     
                     VAR_LISTS_COORDINATES = VAR_SAVED_CONTENT
                     VAR_LISTS_COORDINATES = VAR_LISTS_COORDINATES.split("coordinates:")[1];
                     VAR_LISTS_COORDINATES = VAR_LISTS_COORDINATES.split(";");
                     

                  })!
                  

                  
                  
                  /*Browser*/
                  ;_SELECTOR=" \u003eCSS\u003e .geetest_item-0-0";
                  get_element_selector(_SELECTOR, false).nowait().exist()!
                  VAR_IS_EXISTS4 = _result() == 1
                  _if(VAR_IS_EXISTS4, function(){
                  get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
                  VAR_IS_EXISTS4 = _result().indexOf("true")>=0
                  })!
                  

                  
                  
                  _set_if_expression("W1tJU19FWElTVFM0XV0=");
                  _if(typeof(VAR_IS_EXISTS4) !== "undefined" ? (VAR_IS_EXISTS4) : undefined,function(){
                  
                     
                     
                     VAR_LISTS_COORDINATES = VAR_SAVED_CONTENT
                     VAR_LISTS_COORDINATES = VAR_LISTS_COORDINATES.split("coordinates:")[1];
                     VAR_LISTS_COORDINATES = VAR_LISTS_COORDINATES.split(";");
                     

                  })!
                  

                  
                  
                  _set_if_expression("W1tJU19FWElTVFNdXSA9PSBmYWxzZSAmJiBbW0lTX0VYSVNUUzJdXSA9PSBmYWxzZSAmJiBbW0lTX0VYSVNUUzNdXSA9PSBmYWxzZSAmJiBbW0lTX0VYSVNUUzRdXSA9PSBmYWxzZQ==");
                  _if(VAR_IS_EXISTS == false && VAR_IS_EXISTS2 == false && VAR_IS_EXISTS3 == false && VAR_IS_EXISTS4 == false,function(){
                  
                     
                     
                     _break("function")
                     

                  })!
                  

                  
                  
                  VAR_MODULE_FRAME_SELECTOR = _BAS_SOLVER_PROPERTIES;
                  var data = VAR_MODULE_FRAME_SELECTOR;
                  var selectors_number = [ VAR_SELECTOR_1,VAR_SELECTOR_2 ]
                  VAR_RESULT_SELECTOR = data[selectors_number[0]][selectors_number[1]];
                  

                  
                  
                  _set_if_expression("W1tHRUVURVNUX1RZUEVfQ0FQVENIQV1dID09ICJHRUVURVNUX1ZFUlNJT05fMyI=");
                  _if(VAR_GEETEST_TYPE_CAPTCHA == "GEETEST_VERSION_3",function(){
                  
                     
                     
                     /*Browser*/
                     move(VAR_XBUTON + rand (-4,4),VAR_YBUTON + rand (-4,4),  {"speed": 20,"gravity": 1.4,"deviation": 2} )!
                     mouse_down(VAR_XBUTON + rand (-4,4),VAR_YBUTON + rand (-4,4))!
                     

                     
                     
                     sleep(rand(100,900))!
                     

                     
                     
                     _set_if_expression("cmFuZCAoMSwxMCkgPiA0IHx8IFtbRkFJTF9TT0xWRV9NT0RVTEVfQ0FQVENIQV1dID4gMQ==");
                     _if(rand (1,10) > 4 || VAR_FAIL_SOLVE_MODULE_CAPTCHA > 1,function(){
                     
                        
                        
                        /*Browser*/
                        move(VAR_X_CENTER+ VAR_WIDTH_CENTER/2 + rand (-9,9) + VAR_SCROLL_X,VAR_Y_CENTER + VAR_HEIGHT_CENTER/2 + VAR_SCROLL_Y + rand (12,23),  {"speed": 30,"gravity": 1.4,"deviation": 2} )!
                        

                     })!
                     

                     
                     
                     sleep(rand(100,900))!
                     

                     
                     
                     /*Browser*/
                     var move_settings =  {"speed": 30,"gravity": 1.2,"deviation": 2} ;
                     move_settings["do_mouse_up"] = "true"
                     move(VAR_X+VAR_X2+(VAR_WIDTH/2) + VAR_SCROLL_X,VAR_Y + VAR_SCROLL_Y + rand (12,23), move_settings)!
                     

                     
                     
                     VAR_FAIL_SOLVE_MODULE_CAPTCHA = parseInt(VAR_FAIL_SOLVE_MODULE_CAPTCHA) + parseInt(1)
                     

                  })!
                  

                  
                  
                  _set_if_expression("W1tHRUVURVNUX1RZUEVfQ0FQVENIQV1dID09ICJHRUVURVNUX1ZFUlNJT05fNCI=");
                  _if(VAR_GEETEST_TYPE_CAPTCHA == "GEETEST_VERSION_4",function(){
                  
                     
                     
                     _set_if_expression("W1tHRUVURVNUX1RZUEVfQ0FQVENIQV1dID09ICI5OTk5OTki");
                     _if(VAR_GEETEST_TYPE_CAPTCHA == "999999",function(){
                     
                        
                        
                        /*Browser*/
                        move(VAR_X_PICTRURE + VAR_X2,VAR_Y_PICTRURE + VAR_Y2,  {} )!
                        

                     })!
                     

                     
                     
                     sleep(rand(300,900))!
                     

                     
                     
                     /*Browser*/
                     _SELECTOR = " \u003eCSS\u003e .geetest_btn";
                     wait_element_visible(_SELECTOR)!
                     _call(_random_point, {})!
                     _if(_result().length > 0, function(){
                     move( {} )!
                     get_element_selector(_SELECTOR, false).clarify(X,Y)!
                     _call(_clarify, {} )!
                     mouse_down(X,Y)!
                     })!
                     

                     
                     
                     sleep(rand(100,400))!
                     

                     
                     
                     /*Browser*/
                     move(VAR_X_SLIDER + VAR_WIDTH_SLIDER/2 + rand (-8,8),VAR_Y_SLIDER + rand (-3,3),  {} )!
                     

                     
                     
                     sleep(rand(300,900))!
                     

                     
                     
                     /*Browser*/
                     var move_settings =  {} ;
                     move_settings["do_mouse_up"] = "true"
                     move(VAR_X_PICTRURE + VAR_X2 + VAR_W2/2.3 + VAR_SCROLL_X,VAR_Y_SLIDER + rand (-3,3), move_settings)!
                     

                     
                     
                     VAR_FAIL_SOLVE_MODULE_CAPTCHA = parseInt(VAR_FAIL_SOLVE_MODULE_CAPTCHA) + parseInt(1)
                     

                  })!
                  

                  
                  
                  _set_if_expression("W1tHRUVURVNUX1RZUEVfQ0FQVENIQV1dID09ICJHRUVURVNUX1ZFUlNJT05fM19DTElDSyI=");
                  _if(VAR_GEETEST_TYPE_CAPTCHA == "GEETEST_VERSION_3_CLICK",function(){
                  
                     
                     
                     _set_if_expression("dHlwZW9mKFtbQ0FQVENIQV9XSURUSF1dKSA9PSAidW5kZWZpbmVkIg==");
                     _if(typeof(VAR_CAPTCHA_WIDTH) == "undefined",function(){
                     
                        
                        
                        /*Browser*/
                        ;_SELECTOR="\u003eCSS\u003e .geetest_item_wrap";
                        get_element_selector(_SELECTOR, false).nowait().exist()!
                        VAR_IS_EXISTS = _result() == 1
                        _if(VAR_IS_EXISTS, function(){
                        get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
                        VAR_IS_EXISTS = _result().indexOf("true")>=0
                        })!
                        

                        
                        
                        _set_if_expression("W1tJU19FWElTVFNdXQ==");
                        _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
                        
                           
                           
                           /*Browser*/
                           _SELECTOR = "\u003eCSS\u003e .geetest_item_wrap";
                           wait_element(_SELECTOR)!
                           get_element_selector(_SELECTOR, false).script("(function(){var rect = _BAS_HIDE(BrowserAutomationStudio_GetBoundingClientRect)(self);return (rect.left + positionx) + '|' + (rect.top + positiony) + '|' + (rect.right - rect.left) + '|' + (rect.bottom - rect.top)})();")!
                           if(_result().length > 0)
                           {
                           var split = _result().split("|")
                           VAR_X_BUTTON = parseInt(split[0])
                           VAR_Y_BUTTON = parseInt(split[1])
                           VAR_CAPTCHA_WIDTH = parseInt(split[2])
                           VAR_CAPTCHA_HEIGHT = parseInt(split[3])
                           }
                           

                        })!
                        

                     })!
                     

                     
                     
                     VAR_FOREACH_DATA = 0
                     

                     
                     
                     _do_with_params({"foreach_data":(VAR_LISTS_COORDINATES)},function(){
                     _set_action_info({ name: "Foreach" });
                     VAR_CYCLE_INDEX = _iterator() - 1
                     if(VAR_CYCLE_INDEX > _cycle_param("foreach_data").length - 1)_break();
                     VAR_FOREACH_DATA = _cycle_param("foreach_data")[VAR_CYCLE_INDEX]
                     
                        
                        
                        var csv_parse_result = csv_parse(VAR_FOREACH_DATA)
                        VAR_ANSWER_X = csv_parse_result[0]
                        if(typeof(VAR_ANSWER_X) == 'undefined' || !VAR_ANSWER_X)
                        {
                        VAR_ANSWER_X = ""
                        }
                        VAR_ANSWER_Y = csv_parse_result[1]
                        if(typeof(VAR_ANSWER_Y) == 'undefined' || !VAR_ANSWER_Y)
                        {
                        VAR_ANSWER_Y = ""
                        }
                        

                        
                        
                        VAR_ANSWER_X = VAR_ANSWER_X.replace(/[^0-9]/g, '');
                        VAR_ANSWER_Y = VAR_ANSWER_Y.replace(/[^0-9]/g, '');
                        VAR_ANSWER_X = parseInt(VAR_ANSWER_X)
                        VAR_ANSWER_Y = parseInt(VAR_ANSWER_Y)
                        //// Посчитать новые координаты
                        VAR_ANSWER_X = VAR_ANSWER_X/VAR_GET_IMAGE_W*VAR_CAPTCHA_WIDTH;
                        VAR_ANSWER_Y = VAR_ANSWER_Y/VAR_GET_IMAGE_W*VAR_CAPTCHA_HEIGHT;
                        

                        
                        
                        /*Browser*/
                        move(VAR_X_BUTTON + VAR_ANSWER_X + VAR_SCROLL_X,VAR_Y_BUTTON + VAR_ANSWER_Y + VAR_SCROLL_Y,  {} )!
                        mouse(VAR_X_BUTTON + VAR_ANSWER_X + VAR_SCROLL_X,VAR_Y_BUTTON + VAR_ANSWER_Y + VAR_SCROLL_Y)!
                        

                     })!
                     

                     
                     
                     /*Browser*/
                     _SELECTOR = " \u003eCSS\u003e .geetest_commit_tip";
                     wait_element_visible(_SELECTOR)!
                     _call(_random_point, {})!
                     _if(_result().length > 0, function(){
                     move( {} )!
                     get_element_selector(_SELECTOR, false).clarify(X,Y)!
                     _call(_clarify, {} )!
                     mouse(X,Y)!
                     })!
                     

                  })!
                  

                  
                  
                  _set_if_expression("W1tHRUVURVNUX1RZUEVfQ0FQVENIQV1dID09ICJHRUVURVNUX1ZFUlNJT05fNF9TV0FQX0lURU1TIg==");
                  _if(VAR_GEETEST_TYPE_CAPTCHA == "GEETEST_VERSION_4_SWAP_ITEMS",function(){
                  
                     
                     
                     VAR_FOREACH_DATA = 0
                     

                     
                     
                     _do_with_params({"foreach_data":(VAR_LISTS_COORDINATES)},function(){
                     _set_action_info({ name: "Foreach" });
                     VAR_CYCLE_INDEX = _iterator() - 1
                     if(VAR_CYCLE_INDEX > _cycle_param("foreach_data").length - 1)_break();
                     VAR_FOREACH_DATA = _cycle_param("foreach_data")[VAR_CYCLE_INDEX]
                     
                        
                        
                        var csv_parse_result = csv_parse(VAR_FOREACH_DATA)
                        VAR_ANSWER_X = csv_parse_result[0]
                        if(typeof(VAR_ANSWER_X) == 'undefined' || !VAR_ANSWER_X)
                        {
                        VAR_ANSWER_X = ""
                        }
                        VAR_ANSWER_Y = csv_parse_result[1]
                        if(typeof(VAR_ANSWER_Y) == 'undefined' || !VAR_ANSWER_Y)
                        {
                        VAR_ANSWER_Y = ""
                        }
                        

                        
                        
                        VAR_ANSWER_X = VAR_ANSWER_X.replace(/[^0-9]/g, '');
                        VAR_ANSWER_Y = VAR_ANSWER_Y.replace(/[^0-9]/g, '');
                        VAR_ANSWER_X = parseInt(VAR_ANSWER_X)
                        VAR_ANSWER_Y = parseInt(VAR_ANSWER_Y)
                        

                        
                        
                        /*Browser*/
                        move(VAR_X_BUTTON + VAR_ANSWER_X,VAR_Y_BUTTON + VAR_ANSWER_Y + VAR_SCROLL_Y,  {} )!
                        mouse(VAR_X_BUTTON + VAR_ANSWER_X,VAR_Y_BUTTON + VAR_ANSWER_Y + VAR_SCROLL_Y)!
                        

                     })!
                     

                  })!
                  

                  
                  
                  VAR_ERROR_CAP_MODULE = "0"
                  

                  
                  
                  var pattern_reg = /^\D*(\d)/;
                  var match_many_me = VAR_RESULT_SELECTOR.match(pattern_reg);
                  var result_number = parseInt(match_many_me ? match_many_me[1] : null);
                  var char_result = parseInt(VAR_RESULT_SELECTOR.charAt(VAR_RESULT_SELECTOR.length-2));
                  if (result_number + char_result != 1 + 1 + 1 && result_number + char_result != 11) VAR_RESULT_SELECTOR = 10-7-2;
                  

                  
                  
                  sleep(200)!
                  

                  
                  
                  /*Browser*/
                  ;_SELECTOR="\u003eCSS\u003e div[class*=\u0027geetest_slider geetest_fail\u0027]";
                  get_element_selector(_SELECTOR, false).nowait().exist()!
                  VAR_IS_EXISTS = _result() == 1
                  _if(VAR_IS_EXISTS, function(){
                  get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
                  VAR_IS_EXISTS = _result().indexOf("true")>=0
                  })!
                  

                  
                  
                  _set_if_expression("W1tJU19FWElTVFNdXQ==");
                  _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
                  
                     
                     
                     VAR_ERROR_CAP_MODULE = 1
                     

                  })!
                  

                  
                  
                  sleep(rand(100,200))!
                  

                  
                  
                  _break("function")
                  

               })!
               

               
               
               _if(!_cycle_params().if_else,function(){
               
                  
                  
                  sleep(rand(1000,2000))!
                  

                  
                  
                  /*Browser*/
                  ;_SELECTOR="\u003eCSS\u003e a[class*=\u0027geetest_refresh\u0027]";
                  get_element_selector(_SELECTOR, false).nowait().exist()!
                  VAR_IS_EXISTS = _result() == 1
                  _if(VAR_IS_EXISTS, function(){
                  get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
                  VAR_IS_EXISTS = _result().indexOf("true")>=0
                  })!
                  

                  
                  
                  _set_if_expression("W1tJU19FWElTVFNdXQ==");
                  _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
                  
                     
                     
                     /*Browser*/
                     cache_data_clear()!
                     

                     
                     
                     /*Browser*/
                     _SELECTOR = "\u003eCSS\u003e a[class*=\u0027geetest_refresh\u0027]";
                     wait_element_visible(_SELECTOR)!
                     _call(_random_point, {})!
                     _if(_result().length > 0, function(){
                     move( {"speed": 100,"gravity": 6,"deviation": 2.5} )!
                     get_element_selector(_SELECTOR, false).clarify(X,Y)!
                     _call(_clarify, {"speed": 100,"gravity": 6,"deviation": 2.5} )!
                     mouse(X,Y)!
                     })!
                     

                     
                     
                     VAR_FAIL_SOLVE_MODULE_CAPTCHA = 0
                     

                  })!
                  

                  
                  
                  /*Browser*/
                  ;_SELECTOR="\u003eCSS\u003e button[class*=\u0027geetest_refresh\u0027]";
                  get_element_selector(_SELECTOR, false).nowait().exist()!
                  VAR_IS_EXISTS = _result() == 1
                  _if(VAR_IS_EXISTS, function(){
                  get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
                  VAR_IS_EXISTS = _result().indexOf("true")>=0
                  })!
                  

                  
                  
                  _set_if_expression("W1tJU19FWElTVFNdXQ==");
                  _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
                  
                     
                     
                     /*Browser*/
                     cache_data_clear()!
                     

                     
                     
                     /*Browser*/
                     _SELECTOR = "\u003eCSS\u003e button[class*=\u0027geetest_refresh\u0027]";
                     wait_element_visible(_SELECTOR)!
                     _call(_random_point, {})!
                     _if(_result().length > 0, function(){
                     move( {"speed": 100,"gravity": 6,"deviation": 2.5} )!
                     get_element_selector(_SELECTOR, false).clarify(X,Y)!
                     _call(_clarify, {"speed": 100,"gravity": 6,"deviation": 2.5} )!
                     mouse(X,Y)!
                     })!
                     

                     
                     
                     VAR_FAIL_SOLVE_MODULE_CAPTCHA = 0
                     

                  })!
                  

                  
                  
                  sleep(rand(1000,2000))!
                  

                  
                  
                  VAR_ERROR_CAPTCHA_UNSOLVABLE_MODULE = parseInt(VAR_ERROR_CAPTCHA_UNSOLVABLE_MODULE) + parseInt(1)
                  

                  
                  
                  _break("function")
                  

               })!
               delete _cycle_params().if_else;
               

            })!
            

            
            
            _next("function")
            

         },null)!
         

         
         
         _set_if_expression("W1tXQVNfRVJST1JdXQ==");
         _if(typeof(VAR_WAS_ERROR) !== "undefined" ? (VAR_WAS_ERROR) : undefined,function(){
         
            
            
            sleep(1000)!
            

            
            
            _next("function")
            

         })!
         

      })!
      

   }
   

function CaptchaImageClick_TikTok()
   {
   
      
      
      VAR_KEY_MODULE = _function_argument("KEY")
      

      
      
      VAR_METHOD_MODULE = _function_argument("METHOD")
      

      
      
      VAR_SPEED_MOUSE = _function_argument("SPEED_MOUSE")
      

      
      
      VAR_TRY_MAX_CAPTCHA_PICTURE = _function_argument("TRY_MAX_CAPTCHA_PICTURE")
      

      
      
      VAR_ERROR_CAPTCHA_UNSOLVABLE_MODULE = 0
      

      
      
      VAR_CYCLE_INDEX = 0
      

      
      
      VAR_ERROR_LOAD = "0"
      

      
      
      VAR_ERROR_SOLVE = "0"
      

      
      
      VAR_ERROR_TASK = "0"
      

      
      
      VAR_CAPTCHA_MODULE_TYPE = "0"
      

      
      
      VAR_IMG1_MODULE = "0"
      

      
      
      VAR_RESULT_SELECTOR = 0
      

      
      
      VAR_IMG2_MODULE = "0"
      

      
      
      VAR_GREEN_TICK = false
      

      
      
      VAR_BAS_MODULE_VERSION = "5.6"
      

      
      
      _call(function()
      {
      _on_fail(function(){
      VAR_LAST_ERROR = _result()
      VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
      VAR_WAS_ERROR = false
      _break(1,true)
      })
      CYCLES.Current().RemoveLabel("function")
      
         
         
         VAR_SELECTOR_1 = "Y2FwbW9uc3Rlcg=="
         

         
         
         VAR_SELECTOR_2 = "c2VydmVydXJs"
         

      },null)!
      

      
      
      /*Browser*/
      cache_allow("*ibyteimg.com*")!
      

      
      
      /*Browser*/
      cache_allow("*ibytedtos.com*")!
      

      
      
      /*Browser*/
      cache_allow("*captcha*")!
      

      
      
      _call(function()
      {
      _on_fail(function(){
      VAR_LAST_ERROR = _result()
      VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
      VAR_WAS_ERROR = false
      _break(1,true)
      })
      CYCLES.Current().RemoveLabel("function")
      
         
         
         if (VAR_SPEED_MOUSE == "Slow")
         {
         VAR_SPEED = 100;
         VAR_GRAVITY = 6;
         VAR_DEVIATION = 2.5;
         }
         if (VAR_SPEED_MOUSE == "Normal")
         {
         VAR_SPEED = 200;
         VAR_GRAVITY = 12;
         VAR_DEVIATION = 5;
         }
         if (VAR_SPEED_MOUSE == "Fast")
         {
         VAR_SPEED = 300;
         VAR_GRAVITY = 18;
         VAR_DEVIATION = 7.5;
         }
         if (VAR_SPEED_MOUSE == "Very Fast")
         {
         VAR_SPEED = 400;
         VAR_GRAVITY = 24;
         VAR_DEVIATION = 10;
         }
         if (VAR_SPEED_MOUSE == "Extreme")
         {
         VAR_SPEED = 500;
         VAR_GRAVITY = 30;
         VAR_DEVIATION = 12.5;
         }
         VAR_IS_MOBILE = _IS_MOBILE;
         

         
         
         _set_if_expression("W1tJU19NT0JJTEVdXSA9PSBmYWxzZSAmJiByYW5kICgxLDEwKSA+IDM=");
         _if(VAR_IS_MOBILE == false && rand (1,10) > 3,function(){
         
            
            
            _do(function(){
            _set_action_info({ name: "While" });
            VAR_CYCLE_INDEX = _iterator() - 1
            BREAK_CONDITION = VAR_CYCLE_INDEX < 2;
            if(!BREAK_CONDITION)_break();
            
               
               
               _get_browser_screen_settings()!
               ;(function(){
               var result = JSON.parse(_result())
               VAR_SCROLL_X = result["ScrollX"]
               VAR_SCROLL_Y = result["ScrollY"]
               VAR_CURSOR_X = result["CursorX"]
               VAR_CURSOR_Y = result["CursorY"]
               VAR_BROWSER_WIDTH = result["Width"]
               VAR_BROWSER_HEIGHT = result["Height"]
               })();
               

               
               
               var scroll_x=parseInt(VAR_CURSOR_Y);
               var scroll_y=parseInt(VAR_SCROLL_Y);
               var browser_h=parseInt(VAR_BROWSER_HEIGHT);
               //-------------------- Привели все в числа, считаем позицию ---------------------
               var absolut_y = VAR_CURSOR_Y + VAR_SCROLL_Y;
               var y_without_scroll = absolut_y - VAR_SCROLL_Y;
               var check_y_top = VAR_BROWSER_HEIGHT/12;
               var check_y_down = VAR_BROWSER_HEIGHT/100*92;
               var move_y_top = VAR_BROWSER_HEIGHT/10;
               var move_y_down = VAR_BROWSER_HEIGHT/100*80;
               // -------------------------- Округляем ----------------------------------
               VAR_CHECK_Y_TOP = check_y_top.toFixed();
               VAR_CHECK_Y_DOWN = check_y_down.toFixed();
               VAR_Y_WITHOUNT_SCROLL = y_without_scroll.toFixed();
               VAR_MOVE_Y_TOP = move_y_top.toFixed();
               VAR_MOVE_Y_DOWN = move_y_down.toFixed();
               // ----------------- Снова приводим к числу ------------------------
               VAR_CHECK_Y_TOP=parseInt(VAR_CHECK_Y_TOP);
               VAR_CHECK_Y_DOWN=parseInt(VAR_CHECK_Y_DOWN);
               VAR_Y_WITHOUNT_SCROLL=parseInt(VAR_Y_WITHOUNT_SCROLL);
               VAR_MOVE_Y_TOP=parseInt(VAR_MOVE_Y_TOP);
               VAR_MOVE_Y_DOWN=parseInt(VAR_MOVE_Y_DOWN);
               

               
               
               /*Browser*/
               move(rand(VAR_BROWSER_WIDTH/5,VAR_BROWSER_WIDTH/1.3),rand(VAR_MOVE_Y_TOP + VAR_SCROLL_Y,VAR_MOVE_Y_DOWN + VAR_SCROLL_Y),  {} )!
               

               
               
               _set_if_expression("cmFuZCAoMSwxMCkgPiA1");
               _if(rand (1,10) > 5,function(){
               
                  
                  
                  _break("function")
                  

               })!
               

            })!
            

         })!
         

      },null)!
      

      
      
      VAR_TRY_CAPTCHA = "0"
      

      
      
      VAR_CAPTCHA_FAIL = "0"
      

      
      
      VAR_ERROR_KEY = "0"
      

      
      
      VAR_ERROR_BALANCE = "0"
      

      
      
      VAR_GET_ALL_COORDINATES = "0"
      

      
      
      VAR_FIRST_LOAD_CAPTCHA = true
      

      
      
      /// Селектор который передал юзер модулю приведем в нормальный вид
      get_selector_normal = function(s) {
      var e={},i,b=0,c,x,l=0,a,r='',w=String.fromCharCode,L=s.length;
      var A="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
      for(i=0;i<64;i++){e[A.charAt(i)]=i;}
      for(x=0;x<L;x++){
      c=e[s.charAt(x)];b=(b<<6)+c;l+=6;
      while(l>=8){((a=(b>>>(l-=8))&0xff)||(x<(L-2)))&&(r+=w(a));}
      }
      return r;
      };
      VAR_SELECTOR_1 = get_selector_normal(VAR_SELECTOR_1);
      VAR_SELECTOR_2 = get_selector_normal(VAR_SELECTOR_2);
      

      
      
      _set_goto_label("Tiktok Captcha Start here")!
      

      
      
      _do(function(){
      _set_action_info({ name: "For" });
      VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
      if(VAR_CYCLE_INDEX > parseInt(500))_break();
      
         
         
         VAR_CYCLE_INDEX = 0
         

         
         
         VAR_SAVED_IS_LOADED = 0
         

         
         
         VAR_SAVED_IS_LOADED_1 = 0
         

         
         
         _set_if_expression("W1tFUlJPUl9LRVldXSA9PSAx");
         _if(VAR_ERROR_KEY == 1,function(){
         
            
            
            /*Browser*/
            cache_data_clear()!
            

            
            
            fail((_K==="en" ? "API secret key from captcha recognition service is wrong ERROR_WRONG_USER_KEY" : "Секретный ключ API от сервиса распознавания капчи неправильный ERROR_WRONG_USER_KEY"));
            

         })!
         

         
         
         _set_if_expression("W1tFUlJPUl9CQUxBTkNFXV0gPT0gMQ==");
         _if(VAR_ERROR_BALANCE == 1,function(){
         
            
            
            /*Browser*/
            cache_data_clear()!
            

            
            
            fail((_K==="en" ? "The balance on the captcha service has ended - ERROR_ZERO_BALANCE" : "Закончился баланс на сервисе распознавания капчи - ERROR_ZERO_BALANCE"));
            

         })!
         

         
         
         _set_if_expression("W1tDQVBUQ0hBX0ZBSUxdXSA+IDE=");
         _if(VAR_CAPTCHA_FAIL > 1,function(){
         
            
            
            /*Browser*/
            cache_data_clear()!
            

            
            
            fail((_K==="en" ? "Failed to solve tiktok captcha, reason - " +VAR_SAVED_CONTENT : "Не удалось решить тикток капчу, причина - " +VAR_SAVED_CONTENT));
            

         })!
         

         
         
         _set_if_expression("W1tFUlJPUl9DQVBUQ0hBX1VOU09MVkFCTEVfTU9EVUxFXV0gPiAx");
         _if(VAR_ERROR_CAPTCHA_UNSOLVABLE_MODULE > 1,function(){
         
            
            
            /*Browser*/
            cache_data_clear()!
            

            
            
            sleep(100)!
            

            
            
            fail((_K==="en" ? "TikTok task or image type is not supported service CaptchaGuru, reason: ERROR_CAPTCHA_UNSOLVABLE" : "Решить Тикток каптчу не удалось - сервис CaptchaGuru не смог распознать несколько изображений подряд, причина: ERROR_CAPTCHA_UNSOLVABLE"));
            

         })!
         

         
         
         _do(function(){
         _set_action_info({ name: "For" });
         VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
         if(VAR_CYCLE_INDEX > parseInt(120))_break();
         
            
            
            /*Browser*/
            ;_SELECTOR=" \u003eCSS\u003e .captcha_verify_message";
            get_element_selector(_SELECTOR, false).nowait().exist()!
            VAR_IS_EXISTS = _result() == 1
            _if(VAR_IS_EXISTS, function(){
            get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
            VAR_IS_EXISTS = _result().indexOf("true")>=0
            })!
            

            
            
            _set_if_expression("W1tJU19FWElTVFNdXSA9PSB0cnVlICYmIFtbUkVTVUxUX1NFTEVDVE9SXV0gIT0gMQ==");
            _if(VAR_IS_EXISTS == true && VAR_RESULT_SELECTOR != 1,function(){
            
               
               
               sleep(rand(100,500))!
               

               
               
               _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gODU=");
               _if(VAR_CYCLE_INDEX > 85,function(){
               
                  
                  
                  /*Browser*/
                  cache_data_clear()!
                  

                  
                  
                  fail((_K==="en" ? "Failed to solve the captcha. The captcha too many try check solve." : "Решить капчу не удалось. Много попыток проверить верификацию капчи."));
                  

               })!
               

               
               
               _next("function")
               

            })!
            

            
            
            /*Browser*/
            ;_SELECTOR=" \u003eCSS\u003e .captcha_verify_message-pass";
            get_element_selector(_SELECTOR, false).nowait().exist()!
            VAR_IS_EXISTS = _result() == 1
            _if(VAR_IS_EXISTS, function(){
            get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
            VAR_IS_EXISTS = _result().indexOf("true")>=0
            })!
            

            
            
            _set_if_expression("W1tJU19FWElTVFNdXSA9PSB0cnVlICYmIFtbUkVTVUxUX1NFTEVDVE9SXV0gIT0gMQ==");
            _if(VAR_IS_EXISTS == true && VAR_RESULT_SELECTOR != 1,function(){
            
               
               
               /*Browser*/
               cache_data_clear()!
               

               
               
               VAR_GREEN_TICK = true
               

               
               
               _break("function")
               

            })!
            

            
            
            /*Browser*/
            ;_SELECTOR="\u003eCSS\u003e img.captcha_verify_img_slide.react-draggable";
            get_element_selector(_SELECTOR, false).nowait().exist()!
            VAR_IS_EXISTS_1 = _result() == 1
            

            
            
            _set_if_expression("W1tJU19FWElTVFNfMV1d");
            _if(typeof(VAR_IS_EXISTS_1) !== "undefined" ? (VAR_IS_EXISTS_1) : undefined,function(){
            
               
               
               VAR_CAPTCHA_MODULE_TYPE = "pazl"
               

               
               
               _break("function")
               

            })!
            

            
            
            /*Browser*/
            ;_SELECTOR=" \u003eCSS\u003e #verify-points";
            get_element_selector(_SELECTOR, false).nowait().exist()!
            VAR_IS_EXISTS_2 = _result() == 1
            

            
            
            _set_if_expression("W1tJU19FWElTVFNfMl1d");
            _if(typeof(VAR_IS_EXISTS_2) !== "undefined" ? (VAR_IS_EXISTS_2) : undefined,function(){
            
               
               
               VAR_CAPTCHA_MODULE_TYPE = "abc1"
               

               
               
               _break("function")
               

            })!
            

            
            
            /*Browser*/
            ;_SELECTOR=" \u003eXPATH\u003e //*[@id=\u0022captcha_container\u0022]//img[2][@draggable=\u0022false\u0022]";
            get_element_selector(_SELECTOR, false).nowait().exist()!
            VAR_IS_EXISTS_3 = _result() == 1
            _if(VAR_IS_EXISTS_3, function(){
            get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
            VAR_IS_EXISTS_3 = _result().indexOf("true")>=0
            })!
            

            
            
            /*Browser*/
            ;_SELECTOR=" \u003eCSS\u003e #tiktok-verify-ele";
            get_element_selector(_SELECTOR, false).nowait().exist()!
            VAR_IS_EXISTS_4 = _result() == 1
            _if(VAR_IS_EXISTS_4, function(){
            get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
            VAR_IS_EXISTS_4 = _result().indexOf("true")>=0
            })!
            

            
            
            _set_if_expression("W1tJU19FWElTVFNfM11dIHx8IFtbSVNfRVhJU1RTXzRdXQ==");
            _if(VAR_IS_EXISTS_3 || VAR_IS_EXISTS_4,function(){
            
               
               
               VAR_CAPTCHA_MODULE_TYPE = "koleso"
               

               
               
               _break("function")
               

            })!
            

            
            
            _set_if_expression("W1tJU19FWElTVFNfMV1dID09IGZhbHNlICYmIFtbSVNfRVhJU1RTXzJdXSA9PSBmYWxzZSAmJiBbW0lTX0VYSVNUU18zXV0gPT0gZmFsc2UgJiYgW1tJU19FWElTVFNfNF1dID09IGZhbHNlICYmIFtbRklSU1RfTE9BRF9DQVBUQ0hBXV0gPT0gZmFsc2UgJiYgW1tDWUNMRV9JTkRFWF1dID4gMSAmJiBbW1JFU1VMVF9TRUxFQ1RPUl1dICE9IDE=");
            _if(VAR_IS_EXISTS_1 == false && VAR_IS_EXISTS_2 == false && VAR_IS_EXISTS_3 == false && VAR_IS_EXISTS_4 == false && VAR_FIRST_LOAD_CAPTCHA == false && VAR_CYCLE_INDEX > 1 && VAR_RESULT_SELECTOR != 1,function(){
            
               
               
               /*Browser*/
               cache_data_clear()!
               

               
               
               VAR_GREEN_TICK = true
               

               
               
               _break("function")
               

            })!
            

            
            
            _set_if_expression("W1tJU19FWElTVFNfMV1dID09IGZhbHNlICYmIFtbSVNfRVhJU1RTXzJdXSA9PSBmYWxzZSAmJiBbW0lTX0VYSVNUU18zXV0gPT0gZmFsc2UgJiYgW1tJU19FWElTVFNfNF1dID09IGZhbHNlICYmIFtbRklSU1RfTE9BRF9DQVBUQ0hBXV0gPT0gdHJ1ZSAmJiBbW0NZQ0xFX0lOREVYXV0gPiA0NQ==");
            _if(VAR_IS_EXISTS_1 == false && VAR_IS_EXISTS_2 == false && VAR_IS_EXISTS_3 == false && VAR_IS_EXISTS_4 == false && VAR_FIRST_LOAD_CAPTCHA == true && VAR_CYCLE_INDEX > 45,function(){
            
               
               
               /*Browser*/
               cache_data_clear()!
               

               
               
               fail((_K==="en" ? "Failed to solve TikTok captcha. This captcha type is Unknown" : "Не удалось решить TikTok капчу, загрузился неизвестный тип каптчи"));
               

            })!
            

            
            
            sleep(rand(100,300))!
            

         })!
         

         
         
         VAR_CYCLE_INDEX = 0
         

         
         
         _set_if_expression("W1tHUkVFTl9USUNLXV0gPT0gdHJ1ZQ==");
         _if(VAR_GREEN_TICK == true,function(){
         
            
            
            /*Browser*/
            cache_data_clear()!
            

            
            
            _function_return("")
            

         })!
         

         
         
         VAR_TRY_CAPTCHA = parseInt(VAR_TRY_CAPTCHA) + parseInt(1)
         

         
         
         _set_if_expression("W1tUUllfQ0FQVENIQV1dID4gW1tUUllfTUFYX0NBUFRDSEFfUElDVFVSRV1d");
         _if(VAR_TRY_CAPTCHA > VAR_TRY_MAX_CAPTCHA_PICTURE,function(){
         
            
            
            fail((_K==="en" ? "Failed to solve the captcha. TikTok attempts limit exceeded" : "Решить капчу не удалось. Превышен лимит попыток решить TikTok капчу"));
            

         })!
         

         
         
         _call(function()
         {
         _on_fail(function(){
         VAR_LAST_ERROR = _result()
         VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
         VAR_WAS_ERROR = false
         _break(1,true)
         })
         CYCLES.Current().RemoveLabel("function")
         
            
            
            _set_if_expression("W1tJU19NT0JJTEVdXSA9PT0gZmFsc2U=");
            _if(VAR_IS_MOBILE === false,function(){
            
               
               
               _get_browser_screen_settings()!
               ;(function(){
               var result = JSON.parse(_result())
               VAR_SCROLL_X = result["ScrollX"]
               VAR_SCROLL_Y = result["ScrollY"]
               VAR_CURSOR_X = result["CursorX"]
               VAR_CURSOR_Y = result["CursorY"]
               VAR_BROWSER_WIDTH = result["Width"]
               VAR_BROWSER_HEIGHT = result["Height"]
               })();
               

               
               
               _set_if_expression("W1tDQVBUQ0hBX01PRFVMRV9UWVBFXV0gPT0gImFiYzEi");
               _if(VAR_CAPTCHA_MODULE_TYPE == "abc1",function(){
               
                  
                  
                  /*Browser*/
                  ;_SELECTOR=" \u003eCSS\u003e #verify-points";
                  get_element_selector(_SELECTOR, false).nowait().exist()!
                  VAR_IS_EXISTS = _result() == 1
                  

                  
                  
                  _set_if_expression("IVtbSVNfRVhJU1RTXV0=");
                  _if(!VAR_IS_EXISTS,function(){
                  
                     
                     
                     _set_if_expression("cmFuZCAoMSwxMCkgPiA2");
                     _if(rand (1,10) > 6,function(){
                     
                        
                        
                        VAR_TRY_CAPTCHA = parseInt(VAR_TRY_CAPTCHA) + parseInt(-1)
                        

                     })!
                     

                     
                     
                     sleep(1000)!
                     

                     
                     
                     _next("function")
                     

                  })!
                  

                  
                  
                  /*Browser*/
                  _SELECTOR = " \u003eCSS\u003e .captcha_verify_container";
                  wait_element_visible(_SELECTOR)!
                  _call(_random_point, {})!
                  _if(_result().length > 0, function(){
                  move( {} )!
                  get_element_selector(_SELECTOR, false).clarify(X,Y)!
                  _call(_clarify, {} )!
                  })!
                  

               })!
               

               
               
               _set_if_expression("W1tDQVBUQ0hBX01PRFVMRV9UWVBFXV0gPT0gImtvbGVzbyI=");
               _if(VAR_CAPTCHA_MODULE_TYPE == "koleso",function(){
               
                  
                  
                  /*Browser*/
                  ;_SELECTOR=" \u003eCSS\u003e .captcha_verify_container";
                  get_element_selector(_SELECTOR, false).nowait().exist()!
                  VAR_IS_EXISTS = _result() == 1
                  _if(VAR_IS_EXISTS, function(){
                  get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
                  VAR_IS_EXISTS = _result().indexOf("true")>=0
                  })!
                  

                  
                  
                  _set_if_expression("IVtbSVNfRVhJU1RTXV0=");
                  _if(!VAR_IS_EXISTS,function(){
                  
                     
                     
                     _set_if_expression("cmFuZCAoMSwxMCkgPiA2");
                     _if(rand (1,10) > 6,function(){
                     
                        
                        
                        VAR_TRY_CAPTCHA = parseInt(VAR_TRY_CAPTCHA) + parseInt(-1)
                        

                     })!
                     

                     
                     
                     sleep(1000)!
                     

                     
                     
                     _next("function")
                     

                  })!
                  

                  
                  
                  _set_if_expression("W1tGSVJTVF9MT0FEX0NBUFRDSEFdXSA9PSB0cnVl");
                  _if(VAR_FIRST_LOAD_CAPTCHA == true,function(){
                  
                     
                     
                     /*Browser*/
                     _SELECTOR = " \u003eCSS\u003e .captcha_verify_container";
                     wait_element_visible(_SELECTOR)!
                     _call(_random_point, {})!
                     _if(_result().length > 0, function(){
                     move( {} )!
                     get_element_selector(_SELECTOR, false).clarify(X,Y)!
                     _call(_clarify, {} )!
                     })!
                     

                  })!
                  

               })!
               

               
               
               _set_if_expression("W1tDQVBUQ0hBX01PRFVMRV9UWVBFXV0gPT0gInBhemwi");
               _if(VAR_CAPTCHA_MODULE_TYPE == "pazl",function(){
               
                  
                  
                  /*Browser*/
                  ;_SELECTOR=" \u003eCSS\u003e #captcha-verify-image";
                  get_element_selector(_SELECTOR, false).nowait().exist()!
                  VAR_IS_EXISTS = _result() == 1
                  _if(VAR_IS_EXISTS, function(){
                  get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
                  VAR_IS_EXISTS = _result().indexOf("true")>=0
                  })!
                  

                  
                  
                  _set_if_expression("IVtbSVNfRVhJU1RTXV0=");
                  _if(!VAR_IS_EXISTS,function(){
                  
                     
                     
                     _set_if_expression("cmFuZCAoMSwxMCkgPiA2");
                     _if(rand (1,10) > 6,function(){
                     
                        
                        
                        VAR_TRY_CAPTCHA = parseInt(VAR_TRY_CAPTCHA) + parseInt(-1)
                        

                     })!
                     

                     
                     
                     sleep(1000)!
                     

                     
                     
                     _next("function")
                     

                  })!
                  

                  
                  
                  _set_if_expression("W1tGSVJTVF9MT0FEX0NBUFRDSEFdXSA9PSB0cnVl");
                  _if(VAR_FIRST_LOAD_CAPTCHA == true,function(){
                  
                     
                     
                     /*Browser*/
                     _SELECTOR = " \u003eCSS\u003e #captcha-verify-image";
                     wait_element_visible(_SELECTOR)!
                     _call(_random_point, {})!
                     _if(_result().length > 0, function(){
                     move( {} )!
                     get_element_selector(_SELECTOR, false).clarify(X,Y)!
                     _call(_clarify, {} )!
                     })!
                     

                  })!
                  

               })!
               

            })!
            

         },null)!
         

         
         
         _set_if_expression("W1tXQVNfRVJST1JdXQ==");
         _if(typeof(VAR_WAS_ERROR) !== "undefined" ? (VAR_WAS_ERROR) : undefined,function(){
         
            
            
            /*Browser*/
            cache_data_clear()!
            

            
            
            fail(VAR_LAST_ERROR)
            

         })!
         

         
         
         _call(function()
         {
         _on_fail(function(){
         VAR_LAST_ERROR = _result()
         VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
         VAR_WAS_ERROR = false
         _break(1,true)
         })
         CYCLES.Current().RemoveLabel("function")
         
            
            
            _set_if_expression("W1tDQVBUQ0hBX01PRFVMRV9UWVBFXV0gPT0gImFiYzEi");
            _if(VAR_CAPTCHA_MODULE_TYPE == "abc1",function(){
            
               
               
               VAR_CYCLE_INDEX = "0"
               

               
               
               _do(function(){
               _set_action_info({ name: "For" });
               VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
               if(VAR_CYCLE_INDEX > parseInt(100))_break();
               
                  
                  
                  /*Browser*/
                  ;_SELECTOR=" \u003eCSS\u003e #verify-points";
                  get_element_selector(_SELECTOR, false).nowait().exist()!
                  VAR_IS_EXISTS = _result() == 1
                  

                  
                  
                  _set_if_expression("IVtbSVNfRVhJU1RTXV0=");
                  _if(!VAR_IS_EXISTS,function(){
                  
                     
                     
                     _set_if_expression("cmFuZCAoMSwxMCkgPiA2");
                     _if(rand (1,10) > 6,function(){
                     
                        
                        
                        VAR_TRY_CAPTCHA = parseInt(VAR_TRY_CAPTCHA) + parseInt(-1)
                        

                     })!
                     

                     
                     
                     sleep(1000)!
                     

                     
                     
                     _long_goto("Tiktok Captcha Start here", 5, [])!
                     

                  })!
                  

                  
                  
                  /*Browser*/
                  ;_SELECTOR=" \u003eCSS\u003e .captcha_verify_message";
                  get_element_selector(_SELECTOR, false).nowait().exist()!
                  VAR_IS_EXISTS = _result() == 1
                  _if(VAR_IS_EXISTS, function(){
                  get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
                  VAR_IS_EXISTS = _result().indexOf("true")>=0
                  })!
                  

                  
                  
                  _set_if_expression("W1tJU19FWElTVFNdXSA9PSB0cnVl");
                  _if(VAR_IS_EXISTS == true,function(){
                  
                     
                     
                     sleep(2000)!
                     

                     
                     
                     _long_goto("Tiktok Captcha Start here", 5, [])!
                     

                  })!
                  

                  
                  
                  cache_get_base64("*captcha*")!
                  var image_id = native("imageprocessing", "load", _result())
                  var image_size = native("imageprocessing", "getsize", image_id)
                  var image_w = parseInt(image_size.split(",")[0])
                  var image_h = parseInt(image_size.split(",")[1])
                  if (image_h == 0 && VAR_CYCLE_INDEX > rand (75,95)) fail((_K === "en" ? "Failed to wait for TikTok image from request cache" : "Не удалось дождаться картинку TikTok капчи из кэша запроса"))
                  if (image_h > 150) {
                  VAR_IMAGE_BASE_64 = _result()
                  _break()
                  }
                  sleep(200)!
                  

               })!
               

               
               
               VAR_SET_TASK = "geetest|abc1"
               

               
               
               _get_browser_screen_settings()!
               ;(function(){
               var result = JSON.parse(_result())
               VAR_SCROLL_X = result["ScrollX"]
               VAR_SCROLL_Y = result["ScrollY"]
               VAR_CURSOR_X = result["CursorX"]
               VAR_CURSOR_Y = result["CursorY"]
               VAR_BROWSER_WIDTH = result["Width"]
               VAR_BROWSER_HEIGHT = result["Height"]
               })();
               

               
               
               _set_if_expression("W1tHRVRfQUxMX0NPT1JESU5BVEVTXV0gPT0gMCB8fCAhKFtbSVNfQ0hBTkdFRF9TQ1JPTExfWV1dIDw9IFtbU0NST0xMX1ldXSArIDQgJiYgW1tJU19DSEFOR0VEX1NDUk9MTF9ZXV0gPj0gW1tTQ1JPTExfWV1dIC0gNCk=");
               _if(VAR_GET_ALL_COORDINATES == 0 || !(VAR_IS_CHANGED_SCROLL_Y <= VAR_SCROLL_Y + 4 && VAR_IS_CHANGED_SCROLL_Y >= VAR_SCROLL_Y - 4),function(){
               
                  
                  
                  VAR_IS_CHANGED_SCROLL_Y = VAR_SCROLL_Y
                  

                  
                  
                  VAR_ELEMENT_SELECTOR = " \u003eCSS\u003e #captcha-verify-image"
                  

                  
                  
                  _SELECTOR = VAR_ELEMENT_SELECTOR;
                  get_element_selector(_SELECTOR, false).script("(function(){var rect = self.getBoundingClientRect();return (rect.left + positionx).toString() + '|' + (rect.top + positiony).toString() + '|' + (rect.right - rect.left).toString() + '|' + (rect.bottom - rect.top).toString()})();")!
                  var split = _result().split("|");
                  var x = parseInt(split[0]), y = parseInt(split[1]), w = parseInt(split[2]), h = parseInt(split[3]);
                  /// Первый квадрат
                  VAR_SQUARE_BUTTON_X = parseInt(x) + VAR_SCROLL_X;
                  VAR_SQUARE_BUTTON_Y = parseInt(y) + VAR_SCROLL_Y;
                  VAR_SQUARE_WIDTH = parseInt(w);
                  VAR_SQUARE_HEIGHT = parseInt(h);
                  

                  
                  
                  VAR_GET_ALL_COORDINATES = "1"
                  

               })!
               

               
               
               VAR_IMAGE_BASE_64 = native("imageprocessing", "load", VAR_IMAGE_BASE_64)
               

               
               
               native("imageprocessing", "resize", (VAR_IMAGE_BASE_64) + "," + (VAR_SQUARE_WIDTH) + "," + (VAR_SQUARE_HEIGHT))
               

               
               
               VAR_IMAGE_BASE_64 = native("imageprocessing", "getdata", VAR_IMAGE_BASE_64)
               

               
               
               native("imageprocessing", "delete", VAR_IMAGE_BASE_64)
               

               
               
               /*Browser*/
               cache_data_clear()!
               

            })!
            

            
            
            _set_if_expression("W1tDQVBUQ0hBX01PRFVMRV9UWVBFXV0gPT0gImtvbGVzbyI=");
            _if(VAR_CAPTCHA_MODULE_TYPE == "koleso",function(){
            
               
               
               VAR_CYCLE_INDEX = "0"
               

               
               
               _do(function(){
               _set_action_info({ name: "For" });
               VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
               if(VAR_CYCLE_INDEX > parseInt(100))_break();
               
                  
                  
                  /*Browser*/
                  ;_SELECTOR=" \u003eCSS\u003e .captcha_verify_container";
                  get_element_selector(_SELECTOR, false).nowait().exist()!
                  VAR_IS_EXISTS = _result() == 1
                  _if(VAR_IS_EXISTS, function(){
                  get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
                  VAR_IS_EXISTS = _result().indexOf("true")>=0
                  })!
                  

                  
                  
                  _set_if_expression("IVtbSVNfRVhJU1RTXV0=");
                  _if(!VAR_IS_EXISTS,function(){
                  
                     
                     
                     _set_if_expression("cmFuZCAoMSwxMCkgPiA2");
                     _if(rand (1,10) > 6,function(){
                     
                        
                        
                        VAR_TRY_CAPTCHA = parseInt(VAR_TRY_CAPTCHA) + parseInt(-1)
                        

                     })!
                     

                     
                     
                     sleep(1000)!
                     

                     
                     
                     _long_goto("Tiktok Captcha Start here", 5, [])!
                     

                  })!
                  

                  
                  
                  /*Browser*/
                  ;_SELECTOR=" \u003eCSS\u003e .captcha_verify_message";
                  get_element_selector(_SELECTOR, false).nowait().exist()!
                  VAR_IS_EXISTS = _result() == 1
                  _if(VAR_IS_EXISTS, function(){
                  get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
                  VAR_IS_EXISTS = _result().indexOf("true")>=0
                  })!
                  

                  
                  
                  _set_if_expression("W1tJU19FWElTVFNdXSA9PSB0cnVl");
                  _if(VAR_IS_EXISTS == true,function(){
                  
                     
                     
                     sleep(2000)!
                     

                     
                     
                     _long_goto("Tiktok Captcha Start here", 5, [])!
                     

                  })!
                  

                  
                  
                  cache_get_base64("*ibyteimg.com*")!
                  var image_id = native("imageprocessing", "load", _result())
                  var image_size = native("imageprocessing", "getsize", image_id)
                  var image_w = parseInt(image_size.split(",")[0])
                  var image_h = parseInt(image_size.split(",")[1])
                  if (image_h == 0 && VAR_CYCLE_INDEX > rand (75,95)) fail((_K === "en" ? "Failed to wait for TikTok image from request cache" : "Не удалось дождаться картинку TikTok капчи из кэша запроса"))
                  if (image_h > 50) {
                  VAR_IMAGE_BASE_64 = _result()
                  _break()
                  }
                  sleep(200)!
                  

               })!
               

               
               
               VAR_SET_TASK = "koleso"
               

               
               
               /*Browser*/
               ;_SELECTOR=" \u003eCSS\u003e #tiktok-verify-ele";
               get_element_selector(_SELECTOR, false).nowait().exist()!
               VAR_IS_EXISTS = _result() == 1
               _if(VAR_IS_EXISTS, function(){
               get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
               VAR_IS_EXISTS = _result().indexOf("true")>=0
               })!
               

               
               
               _set_if_expression("W1tJU19FWElTVFNdXQ==");
               _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
               
                  
                  
                  /*Browser*/
                  _SELECTOR = " \u003eCSS\u003e #tiktok-verify-ele img \u003eAT\u003e 0";
                  wait_element(_SELECTOR)!
                  get_element_selector(_SELECTOR, false).attr("src")!
                  VAR_TIKTOK_IMAGE_KOLESO_MODULE_1 = _result()
                  

                  
                  
                  /*Browser*/
                  _SELECTOR = " \u003eCSS\u003e #tiktok-verify-ele img \u003eAT\u003e 1";
                  wait_element(_SELECTOR)!
                  get_element_selector(_SELECTOR, false).attr("src")!
                  VAR_TIKTOK_IMAGE_KOLESO_MODULE_2 = _result()
                  

                  
                  
                  VAR_TIKTOK_IMAGE_KOLESO_MODULE_1 = base64_encode(VAR_TIKTOK_IMAGE_KOLESO_MODULE_1)
                  

                  
                  
                  VAR_TIKTOK_IMAGE_KOLESO_MODULE_2 = base64_encode(VAR_TIKTOK_IMAGE_KOLESO_MODULE_2)
                  

               })!
               

               
               
               /*Browser*/
               ;_SELECTOR=" \u003eCSS\u003e #captcha_container";
               get_element_selector(_SELECTOR, false).nowait().exist()!
               VAR_IS_EXISTS = _result() == 1
               _if(VAR_IS_EXISTS, function(){
               get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
               VAR_IS_EXISTS = _result().indexOf("true")>=0
               })!
               

               
               
               _set_if_expression("W1tJU19FWElTVFNdXQ==");
               _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
               
                  
                  
                  /*Browser*/
                  _SELECTOR = " \u003eCSS\u003e #captcha_container img \u003eAT\u003e 0";
                  wait_element(_SELECTOR)!
                  get_element_selector(_SELECTOR, false).attr("src")!
                  VAR_TIKTOK_IMAGE_KOLESO_MODULE_1 = _result()
                  

                  
                  
                  /*Browser*/
                  _SELECTOR = " \u003eCSS\u003e #captcha_container img \u003eAT\u003e 1";
                  wait_element(_SELECTOR)!
                  get_element_selector(_SELECTOR, false).attr("src")!
                  VAR_TIKTOK_IMAGE_KOLESO_MODULE_2 = _result()
                  

                  
                  
                  VAR_TIKTOK_IMAGE_KOLESO_MODULE_1 = base64_encode(VAR_TIKTOK_IMAGE_KOLESO_MODULE_1)
                  

                  
                  
                  VAR_TIKTOK_IMAGE_KOLESO_MODULE_2 = base64_encode(VAR_TIKTOK_IMAGE_KOLESO_MODULE_2)
                  

               })!
               

            })!
            

            
            
            _set_if_expression("W1tDQVBUQ0hBX01PRFVMRV9UWVBFXV0gPT0gInBhemwi");
            _if(VAR_CAPTCHA_MODULE_TYPE == "pazl",function(){
            
               
               
               VAR_CYCLE_INDEX = "0"
               

               
               
               _do(function(){
               _set_action_info({ name: "For" });
               VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
               if(VAR_CYCLE_INDEX > parseInt(100))_break();
               
                  
                  
                  /*Browser*/
                  ;_SELECTOR=" \u003eCSS\u003e #captcha-verify-image";
                  get_element_selector(_SELECTOR, false).nowait().exist()!
                  VAR_IS_EXISTS = _result() == 1
                  _if(VAR_IS_EXISTS, function(){
                  get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
                  VAR_IS_EXISTS = _result().indexOf("true")>=0
                  })!
                  

                  
                  
                  _set_if_expression("IVtbSVNfRVhJU1RTXV0=");
                  _if(!VAR_IS_EXISTS,function(){
                  
                     
                     
                     _set_if_expression("cmFuZCAoMSwxMCkgPiA2");
                     _if(rand (1,10) > 6,function(){
                     
                        
                        
                        VAR_TRY_CAPTCHA = parseInt(VAR_TRY_CAPTCHA) + parseInt(-1)
                        

                     })!
                     

                     
                     
                     _long_goto("Tiktok Captcha Start here", 5, [])!
                     

                  })!
                  

                  
                  
                  /*Browser*/
                  is_load("*ibyteimg*")!
                  VAR_SAVED_IS_LOADED = _result()
                  

                  
                  
                  /*Browser*/
                  is_load("*ibytedtos.com*")!
                  VAR_SAVED_IS_LOADED_1 = _result()
                  

                  
                  
                  _set_if_expression("W1tTQVZFRF9JU19MT0FERURdXSA9PSAxIHx8IFtbU0FWRURfSVNfTE9BREVEXzFdXSA9PSAx");
                  _if(VAR_SAVED_IS_LOADED == 1 || VAR_SAVED_IS_LOADED_1 == 1,function(){
                  
                     
                     
                     _break("function")
                     

                  })!
                  

                  
                  
                  _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gOTA=");
                  _if(VAR_CYCLE_INDEX > 90,function(){
                  
                     
                     
                     fail((_K === "en" ? "Failed to wait for TikTok image from request cache" : "Не удалось дождаться картинку TikTok капчи из кэша запроса"))
                     

                  })!
                  

                  
                  
                  sleep(rand(200,400))!
                  

               })!
               

               
               
               VAR_SET_TASK = "slider"
               

               
               
               _get_browser_screen_settings()!
               ;(function(){
               var result = JSON.parse(_result())
               VAR_SCROLL_X = result["ScrollX"]
               VAR_SCROLL_Y = result["ScrollY"]
               VAR_CURSOR_X = result["CursorX"]
               VAR_CURSOR_Y = result["CursorY"]
               VAR_BROWSER_WIDTH = result["Width"]
               VAR_BROWSER_HEIGHT = result["Height"]
               })();
               

               
               
               /*Browser*/
               _SELECTOR = " \u003eCSS\u003e #captcha-verify-image";
               wait_element(_SELECTOR)!
               get_element_selector(_SELECTOR, false).exist()!
               _if(_result() == "1", function(){
               get_element_selector(_SELECTOR, false).render_base64()!
               VAR_IMAGE_BASE_64 = _result()
               })!
               

            })!
            

            
            
            sleep(200)!
            

         },null)!
         

         
         
         _set_if_expression("W1tXQVNfRVJST1JdXQ==");
         _if(typeof(VAR_WAS_ERROR) !== "undefined" ? (VAR_WAS_ERROR) : undefined,function(){
         
            
            
            _call(function()
            {
            _on_fail(function(){
            VAR_LAST_ERROR = _result()
            VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
            VAR_WAS_ERROR = false
            _break(1,true)
            })
            CYCLES.Current().RemoveLabel("function")
            
               
               
               /*Browser*/
               ;_SELECTOR="\u003eCSS\u003e span[class*=\u0027captcha_refresh--text\u0027]";
               get_element_selector(_SELECTOR, false).nowait().exist()!
               VAR_IS_EXISTS = _result() == 1
               _if(VAR_IS_EXISTS, function(){
               get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
               VAR_IS_EXISTS = _result().indexOf("true")>=0
               })!
               

               
               
               _set_if_expression("W1tJU19FWElTVFNdXQ==");
               _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
               
                  
                  
                  /*Browser*/
                  cache_data_clear()!
                  

                  
                  
                  /*Browser*/
                  _SELECTOR = "\u003eCSS\u003e span[class*=\u0027captcha_refresh--text\u0027]";
                  wait_element_visible(_SELECTOR)!
                  _call(_random_point, {})!
                  _if(_result().length > 0, function(){
                  move( {"speed": VAR_SPEED,"gravity": VAR_GRAVITY,"deviation": VAR_DEVIATION} )!
                  get_element_selector(_SELECTOR, false).clarify(X,Y)!
                  _call(_clarify, {"speed": VAR_SPEED,"gravity": VAR_GRAVITY,"deviation": VAR_DEVIATION} )!
                  mouse(X,Y)!
                  })!
                  

               })!
               

            },null)!
            

            
            
            _next("function")
            

         })!
         

         
         
         VAR_FIRST_LOAD_CAPTCHA = false
         

         
         
         _call(function()
         {
         _on_fail(function(){
         VAR_LAST_ERROR = _result()
         VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
         VAR_WAS_ERROR = false
         _break(1,true)
         })
         CYCLES.Current().RemoveLabel("function")
         
            
            
            _do(function(){
            _set_action_info({ name: "For" });
            VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
            if(VAR_CYCLE_INDEX > parseInt(20))_break();
            
               
               
               ///Чистим
               solver_properties_clear("capmonster")
               if (VAR_METHOD_MODULE == "CaptchaGuru (RU Server)") VAR_SERVER_SOLVE = "https://92.53.65.152/"
               if (VAR_METHOD_MODULE == "CaptchaGuru (German Server)") VAR_SERVER_SOLVE = "https://159.69.241.182/"
               if (VAR_METHOD_MODULE == "CaptchaGuru (Finland Server)") VAR_SERVER_SOLVE = "https://95.217.17.172/"
               /// Если юзер оставил старый метод и не пересоздал дейстие с модулем, то оставим дефолт сервер хецнер
               if (VAR_METHOD_MODULE == "CaptchaGuru") VAR_SERVER_SOLVE = "https://159.69.241.182/"
               /// Формирумем основной запрос
               solver_property("capmonster","serverurl",VAR_SERVER_SOLVE)
               solver_property("capmonster","coordinatescaptcha","1")
               solver_property("capmonster","key",VAR_KEY_MODULE)
               solver_property("capmonster","textinstructions",VAR_SET_TASK)
               solver_property("capmonster","click","geetest")
               solver_property("capmonster","basmodule",VAR_BAS_MODULE_VERSION)
               solver_property("capmonster","method","post")
               if (VAR_CAPTCHA_MODULE_TYPE == "koleso")
               {
               solver_property("capmonster","body1",VAR_TIKTOK_IMAGE_KOLESO_MODULE_1)
               solver_property("capmonster","body2",VAR_TIKTOK_IMAGE_KOLESO_MODULE_2)
               }
               //// Отправляем
               solve_base64_no_fail("capmonster", VAR_IMAGE_BASE_64)!
               VAR_SAVED_CONTENT = _result();
               

               
               
               _set_if_expression("W1tTQVZFRF9DT05URU5UXV0uaW5kZXhPZigiRVJST1JfQ0FQVENIQV9VTlNPTFZBQkxFIikgPj0gMA==");
               _if(VAR_SAVED_CONTENT.indexOf("ERROR_CAPTCHA_UNSOLVABLE") >= 0,function(){
               
                  
                  
                  /*Browser*/
                  ;_SELECTOR="\u003eCSS\u003e span[class*=\u0027captcha_refresh--text\u0027]";
                  get_element_selector(_SELECTOR, false).nowait().exist()!
                  VAR_IS_EXISTS = _result() == 1
                  _if(VAR_IS_EXISTS, function(){
                  get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
                  VAR_IS_EXISTS = _result().indexOf("true")>=0
                  })!
                  

                  
                  
                  _set_if_expression("W1tJU19FWElTVFNdXQ==");
                  _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
                  
                     
                     
                     /*Browser*/
                     cache_data_clear()!
                     

                     
                     
                     /*Browser*/
                     _SELECTOR = "\u003eCSS\u003e span[class*=\u0027captcha_refresh--text\u0027]";
                     wait_element_visible(_SELECTOR)!
                     _call(_random_point, {})!
                     _if(_result().length > 0, function(){
                     move( {"speed": VAR_SPEED,"gravity": VAR_GRAVITY,"deviation": VAR_DEVIATION} )!
                     get_element_selector(_SELECTOR, false).clarify(X,Y)!
                     _call(_clarify, {"speed": VAR_SPEED,"gravity": VAR_GRAVITY,"deviation": VAR_DEVIATION} )!
                     mouse(X,Y)!
                     })!
                     

                  })!
                  

                  
                  
                  sleep(rand(1000,3000))!
                  

                  
                  
                  _break("function")
                  

               })!
               

               
               
               _set_if_expression("W1tTQVZFRF9DT05URU5UXV0uaW5kZXhPZigiRVJST1JfV1JPTkdfVVNFUl9LRVkiKSA+PSAw");
               _if(VAR_SAVED_CONTENT.indexOf("ERROR_WRONG_USER_KEY") >= 0,function(){
               
                  
                  
                  VAR_ERROR_KEY = "1"
                  

                  
                  
                  _break("function")
                  

               })!
               

               
               
               _set_if_expression("W1tTQVZFRF9DT05URU5UXV0uaW5kZXhPZigiRVJST1JfWkVST19CQUxBTkNFIikgPj0gMA==");
               _if(VAR_SAVED_CONTENT.indexOf("ERROR_ZERO_BALANCE") >= 0,function(){
               
                  
                  
                  VAR_ERROR_BALANCE = "1"
                  

                  
                  
                  _break("function")
                  

               })!
               

               
               
               _set_if_expression("W1tTQVZFRF9DT05URU5UXV0uaW5kZXhPZigiQ0FQVENIQV9GQUlMIikgPj0gMA==");
               _if(VAR_SAVED_CONTENT.indexOf("CAPTCHA_FAIL") >= 0,function(){
               
                  
                  
                  sleep(rand(1000,2000))!
                  

                  
                  
                  VAR_CAPTCHA_FAIL = parseInt(VAR_CAPTCHA_FAIL) + parseInt(1)
                  

                  
                  
                  _break("function")
                  

               })!
               

               
               
               _cycle_params().if_else = VAR_SAVED_CONTENT.match(/[0-9]/) && VAR_SAVED_CONTENT.indexOf("coordinates") >= 0;
               _set_if_expression("W1tTQVZFRF9DT05URU5UXV0ubWF0Y2goL1swLTldLykgJiYgW1tTQVZFRF9DT05URU5UXV0uaW5kZXhPZigiY29vcmRpbmF0ZXMiKSA+PSAw");
               _if(_cycle_params().if_else,function(){
               
                  
                  
                  VAR_MODULE_FRAME_SELECTOR = _BAS_SOLVER_PROPERTIES;
                  var data = VAR_MODULE_FRAME_SELECTOR;
                  var selectors_number = [ VAR_SELECTOR_1,VAR_SELECTOR_2 ]
                  VAR_RESULT_SELECTOR = data[selectors_number[0]][selectors_number[1]];
                  

                  
                  
                  _set_if_expression("W1tDQVBUQ0hBX01PRFVMRV9UWVBFXV0gPT0gImtvbGVzbyI=");
                  _if(VAR_CAPTCHA_MODULE_TYPE == "koleso",function(){
                  
                     
                     
                     /*Browser*/
                     ;_SELECTOR=" \u003eCSS\u003e .secsdk-captcha-drag-icon";
                     get_element_selector(_SELECTOR, false).nowait().exist()!
                     VAR_IS_EXISTS = _result() == 1
                     

                     
                     
                     _cycle_params().if_else = typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined;
                     _set_if_expression("W1tJU19FWElTVFNdXQ==");
                     _if(_cycle_params().if_else,function(){
                     
                        
                        
                        /*Browser*/
                        _SELECTOR = " \u003eCSS\u003e .secsdk-captcha-drag-icon";
                        wait_element(_SELECTOR)!
                        get_element_selector(_SELECTOR, false).script("(function(){var rect = _BAS_HIDE(BrowserAutomationStudio_GetBoundingClientRect)(self);return (rect.left + positionx) + '|' + (rect.top + positiony) + '|' + (rect.right - rect.left) + '|' + (rect.bottom - rect.top)})();")!
                        if(_result().length > 0)
                        {
                        var split = _result().split("|")
                        VAR_X = parseInt(split[0])
                        VAR_Y = parseInt(split[1])
                        VAR_WIDTH = parseInt(split[2])
                        VAR_HEIGHT = parseInt(split[3])
                        }
                        

                        
                        
                        _get_browser_screen_settings()!
                        ;(function(){
                        var result = JSON.parse(_result())
                        VAR_SCROLL_X = result["ScrollX"]
                        VAR_SCROLL_Y = result["ScrollY"]
                        VAR_CURSOR_X = result["CursorX"]
                        VAR_CURSOR_Y = result["CursorY"]
                        VAR_BROWSER_WIDTH = result["Width"]
                        VAR_BROWSER_HEIGHT = result["Height"]
                        })();
                        

                     })!
                     

                     
                     
                     _if(!_cycle_params().if_else,function(){
                     
                        
                        
                        _break("function")
                        

                     })!
                     delete _cycle_params().if_else;
                     

                     
                     
                     var dd = VAR_SAVED_CONTENT;
                     var num_slide = dd.replace(/[^0-9,]/g,"").split(",")
                     VAR_X2 = parseInt(num_slide[1]);
                     VAR_XBUTON = (VAR_X + VAR_SCROLL_X + (VAR_HEIGHT/2) + rand (-4,4))
                     VAR_YBUTON = (VAR_Y + VAR_SCROLL_Y + (VAR_WIDTH/2) + rand (-3,3))
                     

                     
                     
                     /*Browser*/
                     move(VAR_XBUTON,VAR_YBUTON,  {} )!
                     mouse_down(VAR_XBUTON,VAR_YBUTON)!
                     

                     
                     
                     sleep(rand(100,600))!
                     

                     
                     
                     /*Browser*/
                     var move_settings =  {} ;
                     move_settings["do_mouse_up"] = "true"
                     move(VAR_X + VAR_X2 + 20 + VAR_SCROLL_X,VAR_Y + VAR_SCROLL_Y + rand (3,7), move_settings)!
                     

                  })!
                  

                  
                  
                  _set_if_expression("W1tDQVBUQ0hBX01PRFVMRV9UWVBFXV0gPT0gImFiYzEi");
                  _if(VAR_CAPTCHA_MODULE_TYPE == "abc1",function(){
                  
                     
                     
                     VAR_LISTS_COORDINATES = VAR_SAVED_CONTENT
                     VAR_LISTS_COORDINATES = VAR_LISTS_COORDINATES.split("coordinates:")[1];
                     VAR_LISTS_COORDINATES = VAR_LISTS_COORDINATES.split(";");
                     

                     
                     
                     ;(function (a) {var j, x, i;for (i = a.length; i; i--) {j = Math.floor(Math.random() * i);x = a[i - 1]; a[i - 1] = a[j];a[j] = x;}})(VAR_LISTS_COORDINATES)
                     

                     
                     
                     _do_with_params({"foreach_data":(VAR_LISTS_COORDINATES)},function(){
                     _set_action_info({ name: "Foreach" });
                     VAR_CYCLE_INDEX = _iterator() - 1
                     if(VAR_CYCLE_INDEX > _cycle_param("foreach_data").length - 1)_break();
                     VAR_FOREACH_DATA = _cycle_param("foreach_data")[VAR_CYCLE_INDEX]
                     
                        
                        
                        var csv_parse_result = csv_parse(VAR_FOREACH_DATA)
                        VAR_ANSWER_X = csv_parse_result[0]
                        if(typeof(VAR_ANSWER_X) == 'undefined' || !VAR_ANSWER_X)
                        {
                        VAR_ANSWER_X = ""
                        }
                        VAR_ANSWER_Y = csv_parse_result[1]
                        if(typeof(VAR_ANSWER_Y) == 'undefined' || !VAR_ANSWER_Y)
                        {
                        VAR_ANSWER_Y = ""
                        }
                        

                        
                        
                        VAR_ANSWER_X = VAR_ANSWER_X.replace(/[^0-9]/g, '');
                        VAR_ANSWER_Y = VAR_ANSWER_Y.replace(/[^0-9]/g, '');
                        VAR_ANSWER_X = parseInt(VAR_ANSWER_X)
                        VAR_ANSWER_Y = parseInt(VAR_ANSWER_Y)
                        

                        
                        
                        /*Browser*/
                        move(VAR_SQUARE_BUTTON_X + VAR_ANSWER_X,VAR_SQUARE_BUTTON_Y + VAR_ANSWER_Y,  {"speed": VAR_SPEED,"gravity": VAR_GRAVITY,"deviation": VAR_DEVIATION} )!
                        mouse(VAR_SQUARE_BUTTON_X + VAR_ANSWER_X,VAR_SQUARE_BUTTON_Y + VAR_ANSWER_Y)!
                        

                     })!
                     

                     
                     
                     /*Browser*/
                     _SELECTOR = " \u003eCSS\u003e .verify-captcha-submit-button";
                     wait_element_visible(_SELECTOR)!
                     _call(_random_point, {})!
                     _if(_result().length > 0, function(){
                     move( {} )!
                     get_element_selector(_SELECTOR, false).clarify(X,Y)!
                     _call(_clarify, {} )!
                     mouse(X,Y)!
                     })!
                     

                  })!
                  

                  
                  
                  _set_if_expression("W1tDQVBUQ0hBX01PRFVMRV9UWVBFXV0gPT0gInBhemwi");
                  _if(VAR_CAPTCHA_MODULE_TYPE == "pazl",function(){
                  
                     
                     
                     var dd = VAR_SAVED_CONTENT;
                     var num_slide = dd.replace(/[;]+/g,",").replace(/[^0-9,]/g,"").split(",")
                     VAR_X2 = parseInt(num_slide[0]);
                     VAR_W2 = parseInt(num_slide[2]);
                     

                     
                     
                     /*Browser*/
                     ;_SELECTOR=" \u003eCSS\u003e .secsdk-captcha-drag-icon";
                     get_element_selector(_SELECTOR, false).nowait().exist()!
                     VAR_IS_EXISTS = _result() == 1
                     

                     
                     
                     _cycle_params().if_else = typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined;
                     _set_if_expression("W1tJU19FWElTVFNdXQ==");
                     _if(_cycle_params().if_else,function(){
                     
                        
                        
                        /*Browser*/
                        _SELECTOR = " \u003eCSS\u003e #captcha-verify-image";
                        wait_element(_SELECTOR)!
                        get_element_selector(_SELECTOR, false).script("(function(){var rect = _BAS_HIDE(BrowserAutomationStudio_GetBoundingClientRect)(self);return (rect.left + positionx) + '|' + (rect.top + positiony) + '|' + (rect.right - rect.left) + '|' + (rect.bottom - rect.top)})();")!
                        if(_result().length > 0)
                        {
                        var split = _result().split("|")
                        VAR_X = parseInt(split[0])
                        VAR_Y = parseInt(split[1])
                        VAR_WIDTH_MAIN_PAZL = parseInt(split[2])
                        VAR_HEIGHT = parseInt(split[3])
                        }
                        

                        
                        
                        /*Browser*/
                        _SELECTOR = " \u003eCSS\u003e .secsdk-captcha-drag-icon";
                        wait_element(_SELECTOR)!
                        get_element_selector(_SELECTOR, false).script("(function(){var rect = _BAS_HIDE(BrowserAutomationStudio_GetBoundingClientRect)(self);return (rect.left + positionx) + '|' + (rect.top + positiony) + '|' + (rect.right - rect.left) + '|' + (rect.bottom - rect.top)})();")!
                        if(_result().length > 0)
                        {
                        var split = _result().split("|")
                        VAR_X = parseInt(split[0])
                        VAR_Y = parseInt(split[1])
                        VAR_WIDTH = parseInt(split[2])
                        VAR_HEIGHT = parseInt(split[3])
                        }
                        

                        
                        
                        _get_browser_screen_settings()!
                        ;(function(){
                        var result = JSON.parse(_result())
                        VAR_SCROLL_X = result["ScrollX"]
                        VAR_SCROLL_Y = result["ScrollY"]
                        VAR_CURSOR_X = result["CursorX"]
                        VAR_CURSOR_Y = result["CursorY"]
                        VAR_BROWSER_WIDTH = result["Width"]
                        VAR_BROWSER_HEIGHT = result["Height"]
                        })();
                        

                     })!
                     

                     
                     
                     _if(!_cycle_params().if_else,function(){
                     
                        
                        
                        _break("function")
                        

                     })!
                     delete _cycle_params().if_else;
                     

                     
                     
                     /*Browser*/
                     move(VAR_X + VAR_WIDTH/2 + rand (-5,5) + VAR_SCROLL_X,VAR_Y + VAR_HEIGHT/2 + rand (-3,7) + VAR_SCROLL_Y,  {} )!
                     mouse_down(VAR_X + VAR_WIDTH/2 + rand (-5,5) + VAR_SCROLL_X,VAR_Y + VAR_HEIGHT/2 + rand (-3,7) + VAR_SCROLL_Y)!
                     

                     
                     
                     sleep(rand(100,700))!
                     

                     
                     
                     /*Browser*/
                     move(VAR_X + VAR_WIDTH_MAIN_PAZL/2 + rand (-8,8) + VAR_SCROLL_X,VAR_Y + VAR_HEIGHT/2 + VAR_SCROLL_Y,  {} )!
                     

                     
                     
                     /*Browser*/
                     var move_settings =  {} ;
                     move_settings["do_mouse_up"] = "true"
                     move(VAR_X+VAR_X2+(VAR_W2/2) + VAR_SCROLL_X,VAR_Y + VAR_HEIGHT/2 + rand (-3,7) + VAR_SCROLL_Y, move_settings)!
                     

                  })!
                  

                  
                  
                  var pattern_reg = /^\D*(\d)/;
                  var match_many_me = VAR_RESULT_SELECTOR.match(pattern_reg);
                  var result_number = parseInt(match_many_me ? match_many_me[1] : null);
                  var char_result = parseInt(VAR_RESULT_SELECTOR.charAt(VAR_RESULT_SELECTOR.length-2));
                  if (result_number + char_result != 1 + 1 + 1 && result_number + char_result != 11) VAR_RESULT_SELECTOR = 10-7-2;
                  

                  
                  
                  sleep(800)!
                  

                  
                  
                  _break("function")
                  

               })!
               

               
               
               _if(!_cycle_params().if_else,function(){
               
                  
                  
                  sleep(1000)!
                  

                  
                  
                  /*Browser*/
                  ;_SELECTOR="\u003eCSS\u003e span[class*=\u0027captcha_refresh--text\u0027]";
                  get_element_selector(_SELECTOR, false).nowait().exist()!
                  VAR_IS_EXISTS = _result() == 1
                  _if(VAR_IS_EXISTS, function(){
                  get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
                  VAR_IS_EXISTS = _result().indexOf("true")>=0
                  })!
                  

                  
                  
                  _set_if_expression("W1tJU19FWElTVFNdXQ==");
                  _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
                  
                     
                     
                     /*Browser*/
                     cache_data_clear()!
                     

                     
                     
                     /*Browser*/
                     _SELECTOR = "\u003eCSS\u003e span[class*=\u0027captcha_refresh--text\u0027]";
                     wait_element_visible(_SELECTOR)!
                     _call(_random_point, {})!
                     _if(_result().length > 0, function(){
                     move( {"speed": VAR_SPEED,"gravity": VAR_GRAVITY,"deviation": VAR_DEVIATION} )!
                     get_element_selector(_SELECTOR, false).clarify(X,Y)!
                     _call(_clarify, {"speed": VAR_SPEED,"gravity": VAR_GRAVITY,"deviation": VAR_DEVIATION} )!
                     mouse(X,Y)!
                     })!
                     

                  })!
                  

                  
                  
                  VAR_ERROR_CAPTCHA_UNSOLVABLE_MODULE = parseInt(VAR_ERROR_CAPTCHA_UNSOLVABLE_MODULE) + parseInt(1)
                  

                  
                  
                  _break("function")
                  

               })!
               delete _cycle_params().if_else;
               

            })!
            

            
            
            _next("function")
            

         },null)!
         

         
         
         _set_if_expression("W1tXQVNfRVJST1JdXQ==");
         _if(typeof(VAR_WAS_ERROR) !== "undefined" ? (VAR_WAS_ERROR) : undefined,function(){
         
            
            
            sleep(1000)!
            

            
            
            _next("function")
            

         })!
         

      })!
      

   }
   

function CaptchaImageClick_FunCaptcha()
   {
   
      
      
      VAR_GLOBAL_SELECTOR = _function_argument("SELECTOR")
      

      
      
      VAR_SPEED_MOUSE = _function_argument("SPEED_MOUSE")
      

      
      
      VAR_KEY_MODULE = _function_argument("KEY")
      

      
      
      VAR_METHOD_MODULE = _function_argument("METHOD")
      

      
      
      VAR_TRY_MAX_CAPTCHA_PICTURE = _function_argument("TRY_MAX_CAPTCHA_PICTURE")
      

      
      
      VAR_NUMBER_CAPTCHA_MODULE = _function_argument("NUMBER_CAPTCHA")
      

      
      
      VAR_SAVED_FAILED_IMAGES = _function_argument("SAVED_FAILED_IMAGES")
      

      
      
      VAR_CYCLE_INDEX = 0
      

      
      
      VAR_NUMBER_FOLDER = rand (1,1000000)
      

      
      
      VAR_FUNCAPTCHA_TYPE = "0"
      

      
      
      VAR_ERROR_LOAD = "0"
      

      
      
      VAR_CACHE_ERROR = "0"
      

      
      
      VAR_ERROR_SOLVE = "0"
      

      
      
      VAR_ERROR_TASK = "0"
      

      
      
      VAR_ERROR_FIND_MAIN_SELECTOR = "0"
      

      
      
      VAR_ERROR_CAPTCHA_UNSOLVABLE_MODULE = 0
      

      
      
      VAR_FUNCAPTCHA_PREFIX_SECOND_FRAME = ""
      

      
      
      VAR_RECAPTCHA_MODULE_ENABLED = 0
      

      
      
      VAR_HCAPTCHA_MODULE_ENABLED = 0
      

      
      
      VAR_FUNCAPTCHA_MODULE_ENABLED = 0
      

      
      
      VAR_NAME_MODULE_AUTOSUBMIT = "NaN"
      

      
      
      VAR_SQUARE_NUMBER_3 = 0
      

      
      
      VAR_RESULT_SELECTOR = 0
      

      
      
      VAR_TILE_NORMAL_VIEW = 0
      

      
      
      VAR_SET_TASK = ""
      

      
      
      VAR_CURRENT_TASK_NUMBER_SOLVE = 0
      

      
      
      VAR_BAS_MODULE_VERSION = "5.6"
      

      
      
      _call(function()
      {
      _on_fail(function(){
      VAR_LAST_ERROR = _result()
      VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
      VAR_WAS_ERROR = false
      _break(1,true)
      })
      CYCLES.Current().RemoveLabel("function")
      
         
         
         //// Проверить установлены ли модули с автосабмитом.
         if (typeof NumbersParseRecaptcha2 === 'function') VAR_RECAPTCHA_MODULE_ENABLED = 1, VAR_NAME_MODULE_AUTOSUBMIT = "ReCaptcha 2 Autosubmit";
         if (typeof BASCaptchaSolver.helpers.HCaptchaHelper === 'function') VAR_HCAPTCHA_MODULE_ENABLED = 1, VAR_NAME_MODULE_AUTOSUBMIT = "hCaptcha Autosubmit";
         if (typeof BASCaptchaSolver.helpers.FunCaptchaHelper === 'function') VAR_FUNCAPTCHA_MODULE_ENABLED = 1, VAR_NAME_MODULE_AUTOSUBMIT = "FunCaptcha Autosubmit";
         

      },null)!
      

      
      
      _set_if_expression("W1tGVU5DQVBUQ0hBX01PRFVMRV9FTkFCTEVEXV0gPT0gMSB8fCBbW1JFQ0FQVENIQV9NT0RVTEVfRU5BQkxFRF1dID09IDEgfHwgW1tIQ0FQVENIQV9NT0RVTEVfRU5BQkxFRF1dID09IDE=");
      _if(VAR_FUNCAPTCHA_MODULE_ENABLED == 1 || VAR_RECAPTCHA_MODULE_ENABLED == 1 || VAR_HCAPTCHA_MODULE_ENABLED == 1,function(){
      
         
         
         fail((_K==="en" ? "Solve the captcha failed, to continue solving captchas by clicks requires to disable module " +VAR_NAME_MODULE_AUTOSUBMIT + " and also remove all actions from the script associated with it and retry solve captcha again" : "Решить капчу не удалось, для продолжения решения капчи кликами требуется отключить сторонний встроенный модуль в BAS: " +VAR_NAME_MODULE_AUTOSUBMIT + ", а также удалить все действия из шаблона связанные с ним и повторить попытку"));
         

      })!
      

      
      
      VAR_GREEN_TICK = false
      

      
      
      VAR_RAND_MODULE_IMAGE = "0"
      

      
      
      VAR_RETURN_TYPE = ""
      

      
      
      _call(function()
      {
      _on_fail(function(){
      VAR_LAST_ERROR = _result()
      VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
      VAR_WAS_ERROR = false
      _break(1,true)
      })
      CYCLES.Current().RemoveLabel("function")
      
         
         
         VAR_SELECTOR_1 = "Y2FwbW9uc3Rlcg=="
         

         
         
         VAR_SELECTOR_2 = "c2VydmVydXJs"
         

      },null)!
      

      
      
      /*Browser*/
      waiter_timeout_next(50000)
      wait_load("*/fc/gfc*")!
      

      
      
      _call(function()
      {
      _on_fail(function(){
      VAR_LAST_ERROR = _result()
      VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
      VAR_WAS_ERROR = false
      _break(1,true)
      })
      CYCLES.Current().RemoveLabel("function")
      
         
         
         /*Browser*/
         wait_load("*/fc/gfc*")!
         cache_get_string("*/fc/gfc*")!
         VAR_SAVED_CACHE = _result()
         

         
         
         _cycle_params().if_else = VAR_SAVED_CACHE != '';
         _set_if_expression("W1tTQVZFRF9DQUNIRV1dICE9ICcn");
         _if(_cycle_params().if_else,function(){
         
            
            
            /// Парсим задание
            VAR_SAVED_CACHE = JSON.parse(VAR_SAVED_CACHE);
            ///Game Item
            if (VAR_SAVED_CACHE.hasOwnProperty("game_data") &&
            VAR_SAVED_CACHE.game_data.hasOwnProperty("game_variant")){
            VAR_SET_TASK = VAR_SAVED_CACHE.game_data.game_variant
            VAR_CURRENT_TASK_NUMBERS = VAR_SAVED_CACHE.game_data.waves;
            }
            /// GameBox и GameTile
            if (VAR_SAVED_CACHE.hasOwnProperty("game_data") &&
            VAR_SAVED_CACHE.game_data.hasOwnProperty("instruction_string")){
            VAR_SET_TASK = VAR_SAVED_CACHE.game_data.instruction_string
            VAR_CURRENT_TASK_NUMBERS = VAR_SAVED_CACHE.game_data.waves;
            }
            

            
            
            _set_if_expression("W1tTRVRfVEFTS11dID09ICIi");
            _if(VAR_SET_TASK == "",function(){
            
               
               
               VAR_CACHE_ERROR = "2"
               

            })!
            

         })!
         

         
         
         _if(!_cycle_params().if_else,function(){
         
            
            
            VAR_CACHE_ERROR = "1"
            

         })!
         delete _cycle_params().if_else;
         

      },null)!
      

      
      
      _set_if_expression("W1tXQVNfRVJST1JdXQ==");
      _if(typeof(VAR_WAS_ERROR) !== "undefined" ? (VAR_WAS_ERROR) : undefined,function(){
      
         
         
         fail((_K==="en" ? "Error parsing cache: */fc/gfc*" : "Произошла неизвестная ошибка парсинга кэша - */fc/gfc*"));
         

      })!
      

      
      
      VAR_SAVED_CACHE = ""
      

      
      
      _call(function()
      {
      _on_fail(function(){
      VAR_LAST_ERROR = _result()
      VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
      VAR_WAS_ERROR = false
      _break(1,true)
      })
      CYCLES.Current().RemoveLabel("function")
      
         
         
         if (VAR_SPEED_MOUSE == "Slow")
         {
         VAR_SPEED = 100;
         VAR_GRAVITY = 6;
         VAR_DEVIATION = 2.5;
         }
         if (VAR_SPEED_MOUSE == "Normal")
         {
         VAR_SPEED = 200;
         VAR_GRAVITY = 12;
         VAR_DEVIATION = 5;
         }
         if (VAR_SPEED_MOUSE == "Fast")
         {
         VAR_SPEED = 300;
         VAR_GRAVITY = 18;
         VAR_DEVIATION = 7.5;
         }
         if (VAR_SPEED_MOUSE == "Very Fast")
         {
         VAR_SPEED = 400;
         VAR_GRAVITY = 24;
         VAR_DEVIATION = 10;
         }
         if (VAR_SPEED_MOUSE == "Extreme")
         {
         VAR_SPEED = 500;
         VAR_GRAVITY = 30;
         VAR_DEVIATION = 12.5;
         }
         VAR_IS_MOBILE = _IS_MOBILE;
         

         
         
         _set_if_expression("W1tJU19NT0JJTEVdXSA9PSBmYWxzZSAmJiByYW5kICgxLDEwKSA+IDM=");
         _if(VAR_IS_MOBILE == false && rand (1,10) > 3,function(){
         
            
            
            _do(function(){
            _set_action_info({ name: "While" });
            VAR_CYCLE_INDEX = _iterator() - 1
            BREAK_CONDITION = VAR_CYCLE_INDEX < 2;
            if(!BREAK_CONDITION)_break();
            
               
               
               _get_browser_screen_settings()!
               ;(function(){
               var result = JSON.parse(_result())
               VAR_SCROLL_X = result["ScrollX"]
               VAR_SCROLL_Y = result["ScrollY"]
               VAR_CURSOR_X = result["CursorX"]
               VAR_CURSOR_Y = result["CursorY"]
               VAR_BROWSER_WIDTH = result["Width"]
               VAR_BROWSER_HEIGHT = result["Height"]
               })();
               

               
               
               var scroll_x=parseInt(VAR_CURSOR_Y);
               var scroll_y=parseInt(VAR_SCROLL_Y);
               var browser_h=parseInt(VAR_BROWSER_HEIGHT);
               //-------------------- Привели все в числа, считаем позицию ---------------------
               var absolut_y = VAR_CURSOR_Y + VAR_SCROLL_Y;
               var y_without_scroll = absolut_y - VAR_SCROLL_Y;
               var check_y_top = VAR_BROWSER_HEIGHT/12;
               var check_y_down = VAR_BROWSER_HEIGHT/100*92;
               var move_y_top = VAR_BROWSER_HEIGHT/10;
               var move_y_down = VAR_BROWSER_HEIGHT/100*80;
               // -------------------------- Округляем ----------------------------------
               VAR_CHECK_Y_TOP = check_y_top.toFixed();
               VAR_CHECK_Y_DOWN = check_y_down.toFixed();
               VAR_Y_WITHOUNT_SCROLL = y_without_scroll.toFixed();
               VAR_MOVE_Y_TOP = move_y_top.toFixed();
               VAR_MOVE_Y_DOWN = move_y_down.toFixed();
               // ----------------- Снова приводим к числу ------------------------
               VAR_CHECK_Y_TOP=parseInt(VAR_CHECK_Y_TOP);
               VAR_CHECK_Y_DOWN=parseInt(VAR_CHECK_Y_DOWN);
               VAR_Y_WITHOUNT_SCROLL=parseInt(VAR_Y_WITHOUNT_SCROLL);
               VAR_MOVE_Y_TOP=parseInt(VAR_MOVE_Y_TOP);
               VAR_MOVE_Y_DOWN=parseInt(VAR_MOVE_Y_DOWN);
               

               
               
               /*Browser*/
               move(rand(VAR_BROWSER_WIDTH/5,VAR_BROWSER_WIDTH/1.3),rand(VAR_MOVE_Y_TOP + VAR_SCROLL_Y,VAR_MOVE_Y_DOWN + VAR_SCROLL_Y),  {} )!
               

               
               
               _set_if_expression("cmFuZCAoMSwxMCkgPiA1");
               _if(rand (1,10) > 5,function(){
               
                  
                  
                  _break("function")
                  

               })!
               

            })!
            

         })!
         

         
         
         VAR_FUNCAPTCHA_PREFIX = VAR_GLOBAL_SELECTOR;
         VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME = VAR_FUNCAPTCHA_PREFIX;
         {
         var index = VAR_FUNCAPTCHA_PREFIX.toString().lastIndexOf(">FRAME>")
         if(index >= 0)
         VAR_FUNCAPTCHA_PREFIX = VAR_FUNCAPTCHA_PREFIX.substring(0,index)
         VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME = VAR_FUNCAPTCHA_PREFIX
         index = VAR_FUNCAPTCHA_PREFIX.toString().lastIndexOf(">FRAME>")
         if(index >= 0)
         VAR_FUNCAPTCHA_PREFIX = VAR_FUNCAPTCHA_PREFIX.substring(0,index + ">FRAME>".length)
         else
         VAR_FUNCAPTCHA_PREFIX = ""
         index = VAR_FUNCAPTCHA_PREFIX.toString().lastIndexOf(">FRAME>")
         if(index >= 0)
         VAR_FUNCAPTCHA_PREFIX = VAR_FUNCAPTCHA_PREFIX.substring(0,index + ">FRAME>".length)
         else
         VAR_FUNCAPTCHA_PREFIX = ""
         }
         

         
         
         _set_if_expression("W1tGVU5DQVBUQ0hBX1BSRUZJWF9TRUNPTkRfRlJBTUVdXSA9PSAiIg==");
         _if(VAR_FUNCAPTCHA_PREFIX_SECOND_FRAME == "",function(){
         
            
            
            _do(function(){
            _set_action_info({ name: "For" });
            VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
            if(VAR_CYCLE_INDEX > parseInt(40))_break();
            
               
               
               /*Browser*/
               ;_SELECTOR=VAR_GLOBAL_SELECTOR;
               get_element_selector(_SELECTOR, false).nowait().exist()!
               VAR_IS_EXISTS = _result() == 1
               _if(VAR_IS_EXISTS, function(){
               get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
               VAR_IS_EXISTS = _result().indexOf("true")>=0
               })!
               

               
               
               _cycle_params().if_else = typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined;
               _set_if_expression("W1tJU19FWElTVFNdXQ==");
               _if(_cycle_params().if_else,function(){
               
                  
                  
                  /*Browser*/
                  _SELECTOR = VAR_GLOBAL_SELECTOR;waiter_timeout_next(8000)
                  wait_element_visible(_SELECTOR)!
                  _call(_random_point, {})!
                  _if(_result().length > 0, function(){
                  move( {} )!
                  get_element_selector(_SELECTOR, false).clarify(X,Y)!
                  _call(_clarify, {} )!
                  mouse(X,Y)!
                  })!
                  

                  
                  
                  _break("function")
                  

               })!
               

               
               
               _if(!_cycle_params().if_else,function(){
               
                  
                  
                  sleep(rand(500,1000))!
                  

               })!
               delete _cycle_params().if_else;
               

               
               
               _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gcmFuZCAoMzAsMzgp");
               _if(VAR_CYCLE_INDEX > rand (30,38),function(){
               
                  
                  
                  VAR_ERROR_FIND_MAIN_SELECTOR = "1"
                  

               })!
               

            })!
            

         })!
         

      },null)!
      

      
      
      _set_if_expression("W1tDQUNIRV9FUlJPUl1dID09IDE=");
      _if(VAR_CACHE_ERROR == 1,function(){
      
         
         
         fail((_K==="en" ? "Warning! Before load FunCaptcha you need allow cache by mask by 3 type url: *rtig/image*, */fc/gfc* and *blob*" : "Внимание! Перед решением FunCaptcha необходимо разрешить кэш по маске 3 видами url: *rtig/image* и */fc/gfc*, а также *blob*"));
         

      })!
      

      
      
      _set_if_expression("W1tDQUNIRV9FUlJPUl1dID09IDI=");
      _if(VAR_CACHE_ERROR == 2,function(){
      
         
         
         fail((_K==="en" ? "FunCaptcha was not solved, could not find the task from the request cache: */fc/gfc*" : "Funcaptcha не была решена, не удалось получить задание из кэша запроса - */fc/gfc*"));
         

      })!
      

      
      
      _set_if_expression("W1tDVVJSRU5UX1RBU0tfTlVNQkVSU11dID4gW1tUUllfTUFYX0NBUFRDSEFfUElDVFVSRV1d");
      _if(VAR_CURRENT_TASK_NUMBERS > VAR_TRY_MAX_CAPTCHA_PICTURE,function(){
      
         
         
         fail((_K==="en" ? "The capctha could not be resolved. The maximum number of tasks Funcaptcha has been exceeded " +VAR_CURRENT_TASK_NUMBERS + ". Check the quality of the browser and proxy." : "Каптчу решить не удалось, превышен лимит на максимально допустимое число заданий у FunCaptcha: " +VAR_CURRENT_TASK_NUMBERS + ". Проверьте качество браузера или прокси."));
         

      })!
      

      
      
      _set_if_expression("W1tFUlJPUl9GSU5EX01BSU5fU0VMRUNUT1JdXSA9PSAx");
      _if(VAR_ERROR_FIND_MAIN_SELECTOR == 1,function(){
      
         
         
         /*Browser*/
         cache_data_clear()!
         

         
         
         fail((_K==="en" ? "Could not wait for the main FunCaptcha selector to load main captcha window" : "Не удалось дождаться загрузки основного селектора, который должен открыть главное окно с FunCaptcha"));
         

      })!
      

      
      
      _set_if_expression("W1tXQVNfRVJST1JdXQ==");
      _if(typeof(VAR_WAS_ERROR) !== "undefined" ? (VAR_WAS_ERROR) : undefined,function(){
      
         
         
         fail(VAR_LAST_ERROR)
         

      })!
      

      
      
      VAR_TRY_CAPTCHA = "0"
      

      
      
      VAR_CAPTCHA_FAIL = "0"
      

      
      
      VAR_ERROR_KEY = "0"
      

      
      
      VAR_ERROR_BALANCE = "0"
      

      
      
      VAR_ERROR_LANG = "0"
      

      
      
      VAR_GET_ALL_COORDINATES = "0"
      

      
      
      VAR_FIRST_LOAD_CAPTCHA = true
      

      
      
      VAR_FIRST_LOAD_BUTTON = true
      

      
      
      /// Селектор который передал юзер модулю приведем в нормальный вид
      get_selector_normal = function(s) {
      var e={},i,b=0,c,x,l=0,a,r='',w=String.fromCharCode,L=s.length;
      var A="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
      for(i=0;i<64;i++){e[A.charAt(i)]=i;}
      for(x=0;x<L;x++){
      c=e[s.charAt(x)];b=(b<<6)+c;l+=6;
      while(l>=8){((a=(b>>>(l-=8))&0xff)||(x<(L-2)))&&(r+=w(a));}
      }
      return r;
      };
      VAR_SELECTOR_1 = get_selector_normal(VAR_SELECTOR_1);
      VAR_SELECTOR_2 = get_selector_normal(VAR_SELECTOR_2);
      

      
      
      _do(function(){
      _set_action_info({ name: "For" });
      VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
      if(VAR_CYCLE_INDEX > parseInt(500))_break();
      
         
         
         VAR_CYCLE_INDEX = 0
         

         
         
         _set_if_expression("W1tFUlJPUl9LRVldXSA9PSAx");
         _if(VAR_ERROR_KEY == 1,function(){
         
            
            
            /*Browser*/
            cache_data_clear()!
            

            
            
            fail((_K==="en" ? "API secret key from captcha recognition service is wrong ERROR_WRONG_USER_KEY" : "Секретный ключ API от сервиса распознавания капчи неправильный ERROR_WRONG_USER_KEY"));
            

         })!
         

         
         
         _set_if_expression("W1tFUlJPUl9CQUxBTkNFXV0gPT0gMQ==");
         _if(VAR_ERROR_BALANCE == 1,function(){
         
            
            
            /*Browser*/
            cache_data_clear()!
            

            
            
            fail((_K==="en" ? "The balance on the captcha service has ended - ERROR_ZERO_BALANCE" : "Закончился баланс на сервисе распознавания капчи - ERROR_ZERO_BALANCE"));
            

         })!
         

         
         
         _set_if_expression("W1tFUlJPUl9UQVNLXV0gPiAx");
         _if(VAR_ERROR_TASK > 1,function(){
         
            
            
            _set_if_expression("W1tTQVZFRF9GQUlMRURfSU1BR0VTXV0gPT0gdHJ1ZQ==");
            _if(VAR_SAVED_FAILED_IMAGES == true,function(){
            
               
               
               VAR_RAND_IMAGE = rand(1,100000)
               

               
               
               _info((_K==="en" ? "Saved image in folder C:/Images/FunCaptcha/ERROR_CAPTCHA_UNSOLVABLE/" +VAR_SET_TASK +"/" +VAR_RAND_IMAGE +".jpg. Task: " +VAR_SET_TASK+ ". Type Captcha: " +VAR_FUNCAPTCHA_TYPE: "Сохранили картинку в папку C:/Images/FunCaptcha/ERROR_CAPTCHA_UNSOLVABLE/" +VAR_SET_TASK +"/" +VAR_RAND_IMAGE +".jpg. Задание: " +VAR_SET_TASK+ ". Тип капчи: " +VAR_FUNCAPTCHA_TYPE));
               

               
               
               native("filesystem", "writefile", JSON.stringify({path: "C:\u005cImages\u005cFunCaptcha\u005cERROR_CAPTCHA_UNSOLVABLE\u005c" + VAR_SET_TASK + "\u005c" + VAR_RAND_IMAGE + ".jpeg",value: (VAR_IMAGE_BASE_64).toString(),base64:true,append:false}))
               

            })!
            

            
            
            /*Browser*/
            cache_data_clear()!
            

            
            
            fail((_K==="en" ? "This Funcaptcha task or image type is not supported service " +VAR_METHOD_MODULE + ": " +VAR_SET_TASK : "Каптча не была решена, " +VAR_METHOD_MODULE + " не смог распознать или не умеет решать это изображение с таким заданием: " +VAR_SET_TASK));
            

         })!
         

         
         
         _set_if_expression("W1tDQVBUQ0hBX0ZBSUxdXSA+IDE=");
         _if(VAR_CAPTCHA_FAIL > 1,function(){
         
            
            
            /*Browser*/
            cache_data_clear()!
            

            
            
            fail((_K==="en" ? "Failed to solve FunCaptcha, reason - " +VAR_SAVED_CONTENT : "Не удалось решить FunCaptcha, причина - " +VAR_SAVED_CONTENT));
            

         })!
         

         
         
         _set_if_expression("W1tDQUNIRV9FUlJPUl1dID09IDE=");
         _if(VAR_CACHE_ERROR == 1,function(){
         
            
            
            fail((_K==="en" ? "Warning! Before load FunCaptcha you need allow cache by mask by 3 type url: *rtig/image*, */fc/gfc* and *blob*" : "Внимание! Перед решением FunCaptcha необходимо разрешить кэш по маске 3 видами url: *rtig/image* и */fc/gfc*, а также *blob*"));
            

         })!
         

         
         
         _set_if_expression("W1tFUlJPUl9DQVBUQ0hBX1VOU09MVkFCTEVfTU9EVUxFXV0gPiAx");
         _if(VAR_ERROR_CAPTCHA_UNSOLVABLE_MODULE > 1,function(){
         
            
            
            _set_if_expression("W1tTQVZFRF9GQUlMRURfSU1BR0VTXV0gPT0gdHJ1ZQ==");
            _if(VAR_SAVED_FAILED_IMAGES == true,function(){
            
               
               
               VAR_RAND_IMAGE = rand(1,100000)
               

               
               
               _info((_K==="en" ? "Saved image in folder C:/Images/FunCaptcha/ERROR_CAPTCHA_UNSOLVABLE/" +VAR_SET_TASK +"/" +VAR_RAND_IMAGE +".jpg. Task: " +VAR_SET_TASK+ ". Type Captcha: " +VAR_FUNCAPTCHA_TYPE: "Сохранили картинку в папку C:/Images/FunCaptcha/ERROR_CAPTCHA_UNSOLVABLE/" +VAR_SET_TASK +"/" +VAR_RAND_IMAGE +".jpg. Задание: " +VAR_SET_TASK+ ". Тип капчи: " +VAR_FUNCAPTCHA_TYPE));
               

               
               
               native("filesystem", "writefile", JSON.stringify({path: "C:\u005cImages\u005cFunCaptcha\u005cERROR_CAPTCHA_UNSOLVABLE\u005c" + VAR_SET_TASK + "\u005c" + VAR_RAND_IMAGE + ".jpeg",value: (VAR_IMAGE_BASE_64).toString(),base64:true,append:false}))
               

            })!
            

            
            
            /*Browser*/
            cache_data_clear()!
            

            
            
            sleep(100)!
            

            
            
            fail((_K==="en" ? "FunCaptcha task or image type is not supported service CaptchaGuru, reason: ERROR_CAPTCHA_UNSOLVABLE" : "Решить FunCaptcha не удалось - сервис CaptchaGuru не смог распознать несколько изображений подряд, причина: ERROR_CAPTCHA_UNSOLVABLE"));
            

         })!
         

         
         
         _do(function(){
         _set_action_info({ name: "For" });
         VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
         if(VAR_CYCLE_INDEX > parseInt(65))_break();
         
            
            
            /*Browser*/
            ;_SELECTOR=VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e #verifyButton";
            get_element_selector(_SELECTOR, false).nowait().exist()!
            VAR_IS_EXISTS = _result() == 1
            

            
            
            _set_if_expression("W1tJU19FWElTVFNdXQ==");
            _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
            
               
               
               /*Browser*/
               _SELECTOR = VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e #verifyButton";
               wait_element_visible(_SELECTOR)!
               _call(_random_point, {})!
               _if(_result().length > 0, function(){
               move( {} )!
               get_element_selector(_SELECTOR, false).clarify(X,Y)!
               _call(_clarify, {} )!
               mouse(X,Y)!
               })!
               

            })!
            

            
            
            /*Browser*/
            ;_SELECTOR=VAR_FUNCAPTCHA_PREFIX + " \u003eCSS\u003e #verifyButton";
            get_element_selector(_SELECTOR, false).nowait().exist()!
            VAR_IS_EXISTS = _result() == 1
            

            
            
            _set_if_expression("W1tJU19FWElTVFNdXQ==");
            _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
            
               
               
               /*Browser*/
               _SELECTOR = VAR_FUNCAPTCHA_PREFIX + " \u003eCSS\u003e #verifyButton";
               wait_element_visible(_SELECTOR)!
               _call(_random_point, {})!
               _if(_result().length > 0, function(){
               move( {} )!
               get_element_selector(_SELECTOR, false).clarify(X,Y)!
               _call(_clarify, {} )!
               mouse(X,Y)!
               })!
               

            })!
            

            
            /*Browser*/
            ;_SELECTOR=VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e #wrong_children_exclamation";
            get_element_selector(_SELECTOR, false).nowait().exist()!
            VAR_WRONG_CAPTCHA_SOLVE_1 = _result() == 1
            

            
            
            /*Browser*/
            ;_SELECTOR=VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e div[class*=\u0027match-game-fail\u0027]";
            get_element_selector(_SELECTOR, false).nowait().exist()!
            VAR_WRONG_CAPTCHA_SOLVE_2 = _result() == 1
            

            
            
            /*Browser*/
            ;_SELECTOR=VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e div[class*=\u0027tile-game-fail\u0027]";
            get_element_selector(_SELECTOR, false).nowait().exist()!
            VAR_WRONG_CAPTCHA_SOLVE_3 = _result() == 1
            

            
            
            /*Browser*/
            ;_SELECTOR=VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e div[id*=\u0027descriptionTryAgain\u0027]";
            get_element_selector(_SELECTOR, false).nowait().exist()!
            VAR_WRONG_CAPTCHA_SOLVE_4 = _result() == 1
            

            
            
            _set_if_expression("W1tXUk9OR19DQVBUQ0hBX1NPTFZFXzFdXSA9PSB0cnVlIHx8IFtbV1JPTkdfQ0FQVENIQV9TT0xWRV8yXV0gPT0gdHJ1ZSB8fCBbW1dST05HX0NBUFRDSEFfU09MVkVfM11dID09IHRydWUgfHwgW1tXUk9OR19DQVBUQ0hBX1NPTFZFXzRdXSA9PSB0cnVl");
            _if(VAR_WRONG_CAPTCHA_SOLVE_1 == true || VAR_WRONG_CAPTCHA_SOLVE_2 == true || VAR_WRONG_CAPTCHA_SOLVE_3 == true || VAR_WRONG_CAPTCHA_SOLVE_4 == true,function(){
            
               
               
               VAR_ERROR_SOLVE = "1"
               

               
               
               _break("function")
               

            })!
            

            
            
            /*Browser*/
            ;_SELECTOR=VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e div[class*=\u0027error box screen\u0027]";
            get_element_selector(_SELECTOR, false).nowait().exist()!
            VAR_UNKNOWN_ERROR_1 = _result() == 1
            

            
            
            /*Browser*/
            ;_SELECTOR=VAR_FUNCAPTCHA_PREFIX + " \u003eCSS\u003e #sub-frame-error";
            get_element_selector(_SELECTOR, false).nowait().exist()!
            VAR_UNKNOWN_ERROR_2 = _result() == 1
            

            
            
            /*Browser*/
            ;_SELECTOR=VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e #sub-frame-error";
            get_element_selector(_SELECTOR, false).nowait().exist()!
            VAR_UNKNOWN_ERROR_3 = _result() == 1
            

            
            
            _set_if_expression("W1tVTktOT1dOX0VSUk9SXzFdXSA9PSB0cnVlIHx8IFtbVU5LTk9XTl9FUlJPUl8yXV0gPT0gdHJ1ZSB8fCBbW1VOS05PV05fRVJST1JfM11dID09IHRydWU=");
            _if(VAR_UNKNOWN_ERROR_1 == true || VAR_UNKNOWN_ERROR_2 == true || VAR_UNKNOWN_ERROR_3 == true,function(){
            
               
               
               VAR_ERROR_LOAD = "1"
               

               
               
               _break("function")
               

            })!
            

            
            
            /*Browser*/
            ;_SELECTOR=VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e #game_challengeItem";
            get_element_selector(_SELECTOR, false).nowait().exist()!
            VAR_IS_EXISTS = _result() == 1
            _if(VAR_IS_EXISTS, function(){
            get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
            VAR_IS_EXISTS = _result().indexOf("true")>=0
            })!
            

            
            
            /*Browser*/
            ;_SELECTOR=VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e div[class*=\u0027match-game box screen\u0027]";
            get_element_selector(_SELECTOR, false).nowait().exist()!
            VAR_IS_EXISTS_2 = _result() == 1
            _if(VAR_IS_EXISTS_2, function(){
            get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
            VAR_IS_EXISTS_2 = _result().indexOf("true")>=0
            })!
            

            
            
            /*Browser*/
            ;_SELECTOR=VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e div[class*=\u0027tile-game box screen\u0027]";
            get_element_selector(_SELECTOR, false).nowait().exist()!
            VAR_IS_EXISTS_3 = _result() == 1
            _if(VAR_IS_EXISTS_3, function(){
            get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
            VAR_IS_EXISTS_3 = _result().indexOf("true")>=0
            })!
            

            
            
            /*Browser*/
            ;_SELECTOR=VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e legend[id*=\u0027game-header\u0027]";
            get_element_selector(_SELECTOR, false).nowait().exist()!
            VAR_IS_EXISTS_4 = _result() == 1
            _if(VAR_IS_EXISTS_4, function(){
            get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
            VAR_IS_EXISTS_4 = _result().indexOf("true")>=0
            })!
            

            
            
            /*Browser*/
            ;_SELECTOR=VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e a[id*=\u0027Frame_children_arrow\u0027]";
            get_element_selector(_SELECTOR, false).nowait().exist()!
            VAR_IS_EXISTS_5 = _result() == 1
            _if(VAR_IS_EXISTS_5, function(){
            get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
            VAR_IS_EXISTS_5 = _result().indexOf("true")>=0
            })!
            

            
            
            _set_if_expression("W1tJU19FWElTVFNdXSA9PSB0cnVlIHx8IFtbSVNfRVhJU1RTXzJdXSA9PSB0cnVlIHx8IFtbSVNfRVhJU1RTXzNdXSA9PSB0cnVlIHx8IFtbSVNfRVhJU1RTXzRdXSA9PSB0cnVlIHx8IFtbSVNfRVhJU1RTXzVdXSA9PSB0cnVl");
            _if(VAR_IS_EXISTS == true || VAR_IS_EXISTS_2 == true || VAR_IS_EXISTS_3 == true || VAR_IS_EXISTS_4 == true || VAR_IS_EXISTS_5 == true,function(){
            
               
               
               _set_if_expression("W1tJU19FWElTVFNdXQ==");
               _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
               
                  
                  
                  VAR_FUNCAPTCHA_TYPE = "Game_Item"
                  

               })!
               

               
               
               _set_if_expression("W1tJU19FWElTVFNfMl1d");
               _if(typeof(VAR_IS_EXISTS_2) !== "undefined" ? (VAR_IS_EXISTS_2) : undefined,function(){
               
                  
                  
                  VAR_FUNCAPTCHA_TYPE = "Game_Box"
                  

               })!
               

               
               
               _set_if_expression("W1tJU19FWElTVFNfM11d");
               _if(typeof(VAR_IS_EXISTS_3) !== "undefined" ? (VAR_IS_EXISTS_3) : undefined,function(){
               
                  
                  
                  VAR_FUNCAPTCHA_TYPE = "Game_Tile"
                  

               })!
               

               
               
               _set_if_expression("W1tJU19FWElTVFNfNF1d");
               _if(typeof(VAR_IS_EXISTS_4) !== "undefined" ? (VAR_IS_EXISTS_4) : undefined,function(){
               
                  
                  
                  VAR_FUNCAPTCHA_TYPE = "Game_Header"
                  

               })!
               

               
               
               _set_if_expression("W1tJU19FWElTVFNfNV1d");
               _if(typeof(VAR_IS_EXISTS_5) !== "undefined" ? (VAR_IS_EXISTS_5) : undefined,function(){
               
                  
                  
                  VAR_FUNCAPTCHA_TYPE = "Game_Children"
                  

               })!
               

               
               
               _break("function")
               

            })!
            

            
            
            _set_if_expression("W1tJU19FWElTVFNdXSA9PSBmYWxzZSAmJiBbW0lTX0VYSVNUU18yXV0gPT0gZmFsc2UgJiYgW1tJU19FWElTVFNfM11dID09IGZhbHNlICYmIFtbSVNfRVhJU1RTXzRdXSA9PSBmYWxzZSAmJiBbW0lTX0VYSVNUU181XV0gPT0gZmFsc2UgJiYgW1tGSVJTVF9MT0FEX0NBUFRDSEFdXSA9PSBmYWxzZSAmJiBbW0NZQ0xFX0lOREVYXV0gPiAxICYmIFtbUkVTVUxUX1NFTEVDVE9SXV0gIT0gMQ==");
            _if(VAR_IS_EXISTS == false && VAR_IS_EXISTS_2 == false && VAR_IS_EXISTS_3 == false && VAR_IS_EXISTS_4 == false && VAR_IS_EXISTS_5 == false && VAR_FIRST_LOAD_CAPTCHA == false && VAR_CYCLE_INDEX > 1 && VAR_RESULT_SELECTOR != 1,function(){
            
               
               
               /*Browser*/
               cache_data_clear()!
               

               
               
               VAR_GREEN_TICK = true
               

               
               
               _break("function")
               

            })!
            

            
            
            _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gMjUgJiYgW1tGSVJTVF9MT0FEX0JVVFRPTl1dID09IHRydWUgJiYgW1tSRVNVTFRfU0VMRUNUT1JdXSAhPSAx");
            _if(VAR_CYCLE_INDEX > 25 && VAR_FIRST_LOAD_BUTTON == true && VAR_RESULT_SELECTOR != 1,function(){
            
               
               
               VAR_FIRST_LOAD_BUTTON = false
               

               
               
               sleep(rand(1000,2000))!
               

               
               
               /*Browser*/
               ;_SELECTOR=VAR_GLOBAL_SELECTOR;
               get_element_selector(_SELECTOR, false).nowait().exist()!
               VAR_IS_EXISTS = _result() == 1
               _if(VAR_IS_EXISTS, function(){
               get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
               VAR_IS_EXISTS = _result().indexOf("true")>=0
               })!
               

               
               
               _set_if_expression("W1tJU19FWElTVFNdXQ==");
               _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
               
                  
                  
                  /*Browser*/
                  _SELECTOR = VAR_GLOBAL_SELECTOR;waiter_timeout_next(8000)
                  wait_element_visible(_SELECTOR)!
                  _call(_random_point, {})!
                  _if(_result().length > 0, function(){
                  move( {} )!
                  get_element_selector(_SELECTOR, false).clarify(X,Y)!
                  _call(_clarify, {} )!
                  mouse(X,Y)!
                  })!
                  

                  
                  
                  sleep(rand(2000,4000))!
                  

               })!
               

            })!
            

            
            
            _set_if_expression("dHlwZW9mKFtbU0hPUlRfVEFTS11dKSAhPSAidW5kZWZpbmVkIiAmJiByYW5kICgxLDEwKSA+IDc=");
            _if(typeof(VAR_SHORT_TASK) != "undefined" && rand (1,10) > 7,function(){
            
               
               
               sleep(rand(20000,60000))!
               

            })!
            

            
            
            _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gNDAgJiYgW1tGSVJTVF9MT0FEX0NBUFRDSEFdXSA9PSB0cnVlICYmIFtbUkVTVUxUX1NFTEVDVE9SXV0gIT0gMQ==");
            _if(VAR_CYCLE_INDEX > 40 && VAR_FIRST_LOAD_CAPTCHA == true && VAR_RESULT_SELECTOR != 1,function(){
            
               
               
               /*Browser*/
               cache_data_clear()!
               

               
               
               fail((_K==="en" ? "Failed to solve FunCaptcha. This captcha type is unknown for current module solve method" : "Не удалось решить FunCaptcha, модуль не умеет решать такой тип капчи"));
               

            })!
            

            
            
            _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gNjAgJiYgW1tGSVJTVF9MT0FEX0NBUFRDSEFdXSA9PSBmYWxzZSAmJiBbW1JFU1VMVF9TRUxFQ1RPUl1dICE9IDE=");
            _if(VAR_CYCLE_INDEX > 60 && VAR_FIRST_LOAD_CAPTCHA == false && VAR_RESULT_SELECTOR != 1,function(){
            
               
               
               /*Browser*/
               cache_data_clear()!
               

               
               
               fail((_K==="en" ? "Failed to solve the captcha. The captcha window is closed." : "Решить капчу не удалось. Окно с капчей не было открыто."));
               

            })!
            

         })!
         

         
         
         VAR_CYCLE_INDEX = 0
         

         
         
         VAR_FIRST_LOAD_BUTTON = false
         

         
         
         _set_if_expression("W1tHUkVFTl9USUNLXV0gPT0gdHJ1ZSAmJiBbW1JFU1VMVF9TRUxFQ1RPUl1dICE9IDE=");
         _if(VAR_GREEN_TICK == true && VAR_RESULT_SELECTOR != 1,function(){
         
            
            
            /*Browser*/
            cache_data_clear()!
            

            
            
            _function_return("")
            

         })!
         

         
         
         _set_if_expression("W1tFUlJPUl9TT0xWRV1dID09IDE=");
         _if(VAR_ERROR_SOLVE == 1,function(){
         
            
            
            /*Browser*/
            cache_data_clear()!
            

            
            
            fail((_K==="en" ? "FunCaptcha solved incorrectly, error - ERROR_CAPTCHA_SOLVE. FunCaptcha type " + VAR_FUNCAPTCHA_TYPE + ". Short task: " + VAR_SET_TASK : "FunCaptcha решена неверно, ошибка  - ERROR_CAPTCHA_SOLVE. Тип каптчи: " + VAR_FUNCAPTCHA_TYPE + ". Задание: " + VAR_SET_TASK));
            

         })!
         

         
         
         _set_if_expression("W1tFUlJPUl9MT0FEXV0gPT0gMQ==");
         _if(VAR_ERROR_LOAD == 1,function(){
         
            
            
            fail((_K==="en" ? "Solving FunCaptcha failed, an unknown error occurred - ERROR_CAPTCHA_UNKNOWN" : "Решить FunCaptcha не удалось, произошла неизвестная ошибка - ERROR_CAPTCHA_UNKNOWN"));
            

         })!
         

         
         
         VAR_TRY_CAPTCHA = parseInt(VAR_TRY_CAPTCHA) + parseInt(1)
         

         
         
         _set_if_expression("W1tUUllfQ0FQVENIQV1dID4gMjM=");
         _if(VAR_TRY_CAPTCHA > 23,function(){
         
            
            
            fail((_K==="en" ? "Failed to solve the captcha. FunCaptcha attempts limit exceeded" : "Решить капчу не удалось. Превышен лимит попыток решить FunCaptcha"));
            

         })!
         

         
         
         _call(function()
         {
         _on_fail(function(){
         VAR_LAST_ERROR = _result()
         VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
         VAR_WAS_ERROR = false
         _break(1,true)
         })
         CYCLES.Current().RemoveLabel("function")
         
            
            
            _get_browser_screen_settings()!
            ;(function(){
            var result = JSON.parse(_result())
            VAR_SCROLL_X = result["ScrollX"]
            VAR_SCROLL_Y = result["ScrollY"]
            VAR_CURSOR_X = result["CursorX"]
            VAR_CURSOR_Y = result["CursorY"]
            VAR_BROWSER_WIDTH = result["Width"]
            VAR_BROWSER_HEIGHT = result["Height"]
            })();
            

            
            
            _set_if_expression("W1tGVU5DQVBUQ0hBX1RZUEVdXSA9PSAiR2FtZV9JdGVtIg==");
            _if(VAR_FUNCAPTCHA_TYPE == "Game_Item",function(){
            
               
               
               /*Browser*/
               ;_SELECTOR=VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e #game_challengeItem";
               get_element_selector(_SELECTOR, false).nowait().exist()!
               VAR_IS_EXISTS = _result() == 1
               

               
               
               _set_if_expression("IVtbSVNfRVhJU1RTXV0=");
               _if(!VAR_IS_EXISTS,function(){
               
                  
                  
                  sleep(rand(100,300))!
                  

                  
                  
                  _next("function")
                  

               })!
               

               
               
               /*Browser*/
               _SELECTOR = VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e #game_challengeItem";
               wait_element(_SELECTOR)!
               get_element_selector(_SELECTOR, false).script("(function(){var rect = _BAS_HIDE(BrowserAutomationStudio_GetBoundingClientRect)(self);return (rect.left + positionx) + '|' + (rect.top + positiony) + '|' + (rect.right - rect.left) + '|' + (rect.bottom - rect.top)})();")!
               if(_result().length > 0)
               {
               var split = _result().split("|")
               VAR_X = parseInt(split[0])
               VAR_Y = parseInt(split[1])
               VAR_CAPTCHA_WIDTH = parseInt(split[2])
               VAR_CAPTCHA_HEIGHT = parseInt(split[3])
               }
               

               
               
               _set_if_expression("cmFuZCAoMSwxMCkgPiA1");
               _if(rand (1,10) > 5,function(){
               
                  
                  
                  /*Browser*/
                  move(rand(VAR_X/100*115,(VAR_X+VAR_CAPTCHA_WIDTH)/100*93).toFixed(),rand(VAR_Y + VAR_SCROLL_Y/100*120,VAR_Y + VAR_SCROLL_Y + VAR_CAPTCHA_HEIGHT/100*90).toFixed(),  {} )!
                  

               })!
               

            })!
            

            
            
            _set_if_expression("W1tGVU5DQVBUQ0hBX1RZUEVdXSA9PSAiR2FtZV9UaWxlIg==");
            _if(VAR_FUNCAPTCHA_TYPE == "Game_Tile",function(){
            
               
               
               /*Browser*/
               ;_SELECTOR=VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e div[class*=\u0027tile-game box screen\u0027]";
               get_element_selector(_SELECTOR, false).nowait().exist()!
               VAR_IS_EXISTS = _result() == 1
               

               
               
               _set_if_expression("IVtbSVNfRVhJU1RTXV0=");
               _if(!VAR_IS_EXISTS,function(){
               
                  
                  
                  sleep(rand(100,300))!
                  

                  
                  
                  _next("function")
                  

               })!
               

               
               
               /*Browser*/
               _SELECTOR = VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e div[class*=\u0027tile-game box screen\u0027]";
               wait_element(_SELECTOR)!
               get_element_selector(_SELECTOR, false).script("(function(){var rect = _BAS_HIDE(BrowserAutomationStudio_GetBoundingClientRect)(self);return (rect.left + positionx) + '|' + (rect.top + positiony) + '|' + (rect.right - rect.left) + '|' + (rect.bottom - rect.top)})();")!
               if(_result().length > 0)
               {
               var split = _result().split("|")
               VAR_X = parseInt(split[0])
               VAR_Y = parseInt(split[1])
               VAR_CAPTCHA_WIDTH = parseInt(split[2])
               VAR_CAPTCHA_HEIGHT = parseInt(split[3])
               }
               

               
               
               _set_if_expression("cmFuZCAoMSwxMCkgPiA1");
               _if(rand (1,10) > 5,function(){
               
                  
                  
                  /*Browser*/
                  move(rand(VAR_X/100*115,(VAR_X+VAR_CAPTCHA_WIDTH)/100*93).toFixed(),rand(VAR_Y + VAR_SCROLL_Y/100*120,VAR_Y + VAR_SCROLL_Y + VAR_CAPTCHA_HEIGHT/100*90).toFixed(),  {} )!
                  

               })!
               

            })!
            

            
            
            _set_if_expression("W1tGVU5DQVBUQ0hBX1RZUEVdXSA9PSAiR2FtZV9Cb3gi");
            _if(VAR_FUNCAPTCHA_TYPE == "Game_Box",function(){
            
               
               
               /*Browser*/
               ;_SELECTOR=VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e img[aria-label*=\u00271\u0027]";
               get_element_selector(_SELECTOR, false).nowait().exist()!
               VAR_IS_EXISTS = _result() == 1
               

               
               
               _set_if_expression("IVtbSVNfRVhJU1RTXV0=");
               _if(!VAR_IS_EXISTS,function(){
               
                  
                  
                  sleep(rand(100,300))!
                  

                  
                  
                  _next("function")
                  

               })!
               

               
               
               _set_if_expression("W1tJU19FWElTVFNdXQ==");
               _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
               
                  
                  
                  /*Browser*/
                  _SELECTOR = VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e a[class*=\u0027right-arrow\u0027]";
                  wait_element_visible(_SELECTOR)!
                  _call(_random_point, {})!
                  _if(_result().length > 0, function(){
                  move( {} )!
                  get_element_selector(_SELECTOR, false).clarify(X,Y)!
                  _call(_clarify, {} )!
                  })!
                  

               })!
               

            })!
            

            
            
            _set_if_expression("W1tGVU5DQVBUQ0hBX1RZUEVdXSA9PSAiR2FtZV9IZWFkZXIi");
            _if(VAR_FUNCAPTCHA_TYPE == "Game_Header",function(){
            
               
               
               /*Browser*/
               ;_SELECTOR=VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e img[id*=\u0027challenge-image\u0027]";
               get_element_selector(_SELECTOR, false).nowait().exist()!
               VAR_IS_EXISTS = _result() == 1
               

               
               
               _set_if_expression("IVtbSVNfRVhJU1RTXV0=");
               _if(!VAR_IS_EXISTS,function(){
               
                  
                  
                  sleep(rand(100,300))!
                  

                  
                  
                  _next("function")
                  

               })!
               

               
               
               /*Browser*/
               _SELECTOR = VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e img[id*=\u0027challenge-image\u0027]";
               wait_element(_SELECTOR)!
               get_element_selector(_SELECTOR, false).script("(function(){var rect = _BAS_HIDE(BrowserAutomationStudio_GetBoundingClientRect)(self);return (rect.left + positionx) + '|' + (rect.top + positiony) + '|' + (rect.right - rect.left) + '|' + (rect.bottom - rect.top)})();")!
               if(_result().length > 0)
               {
               var split = _result().split("|")
               VAR_X = parseInt(split[0])
               VAR_Y = parseInt(split[1])
               VAR_CAPTCHA_WIDTH = parseInt(split[2])
               VAR_CAPTCHA_HEIGHT = parseInt(split[3])
               }
               

               
               
               _set_if_expression("cmFuZCAoMSwxMCkgPiA1");
               _if(rand (1,10) > 5,function(){
               
                  
                  
                  /*Browser*/
                  move(rand(VAR_X/100*115,(VAR_X+VAR_CAPTCHA_WIDTH)/100*93).toFixed(),rand(VAR_Y + VAR_SCROLL_Y/100*120,VAR_Y + VAR_SCROLL_Y + VAR_CAPTCHA_HEIGHT/100*90).toFixed(),  {} )!
                  

               })!
               

            })!
            

            
            
            _set_if_expression("W1tGVU5DQVBUQ0hBX1RZUEVdXSA9PSAiR2FtZV9DaGlsZHJlbiI=");
            _if(VAR_FUNCAPTCHA_TYPE == "Game_Children",function(){
            
               
               
               /*Browser*/
               ;_SELECTOR=VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e a[id*=\u0027children_arrowRight\u0027]";
               get_element_selector(_SELECTOR, false).nowait().exist()!
               VAR_IS_EXISTS = _result() == 1
               

               
               
               _set_if_expression("IVtbSVNfRVhJU1RTXV0=");
               _if(!VAR_IS_EXISTS,function(){
               
                  
                  
                  sleep(rand(100,300))!
                  

                  
                  
                  _next("function")
                  

               })!
               

               
               
               _set_if_expression("W1tJU19FWElTVFNdXQ==");
               _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
               
                  
                  
                  /*Browser*/
                  _SELECTOR = VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e a[id*=\u0027children_arrowRight\u0027]";
                  wait_element_visible(_SELECTOR)!
                  _call(_random_point, {})!
                  _if(_result().length > 0, function(){
                  move( {} )!
                  get_element_selector(_SELECTOR, false).clarify(X,Y)!
                  _call(_clarify, {} )!
                  })!
                  

               })!
               

            })!
            

         },null)!
         

         
         
         _call(function()
         {
         _on_fail(function(){
         VAR_LAST_ERROR = _result()
         VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
         VAR_WAS_ERROR = false
         _break(1,true)
         })
         CYCLES.Current().RemoveLabel("function")
         
            
            
            _get_browser_screen_settings()!
            ;(function(){
            var result = JSON.parse(_result())
            VAR_SCROLL_X = result["ScrollX"]
            VAR_SCROLL_Y = result["ScrollY"]
            VAR_CURSOR_X = result["CursorX"]
            VAR_CURSOR_Y = result["CursorY"]
            VAR_BROWSER_WIDTH = result["Width"]
            VAR_BROWSER_HEIGHT = result["Height"]
            })();
            

            
            
            _set_if_expression("W1tHRVRfQUxMX0NPT1JESU5BVEVTXV0gPT0gMCB8fCAhKFtbSVNfQ0hBTkdFRF9TQ1JPTExfWV1dIDw9IFtbU0NST0xMX1ldXSArIDQgJiYgW1tJU19DSEFOR0VEX1NDUk9MTF9ZXV0gPj0gW1tTQ1JPTExfWV1dIC0gNCk=");
            _if(VAR_GET_ALL_COORDINATES == 0 || !(VAR_IS_CHANGED_SCROLL_Y <= VAR_SCROLL_Y + 4 && VAR_IS_CHANGED_SCROLL_Y >= VAR_SCROLL_Y - 4),function(){
            
               
               
               VAR_IS_CHANGED_SCROLL_Y = VAR_SCROLL_Y
               

               
               
               _set_if_expression("W1tGVU5DQVBUQ0hBX1RZUEVdXSA9PSAiR2FtZV9JdGVtIg==");
               _if(VAR_FUNCAPTCHA_TYPE == "Game_Item",function(){
               
                  
                  
                  VAR_ELEMENT_SELECTOR = VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e #image1 \u003e a"
                  

                  
                  
                  _SELECTOR = VAR_ELEMENT_SELECTOR;
                  get_element_selector(_SELECTOR, false).script("(function(){var rect = self.getBoundingClientRect();return (rect.left + positionx).toString() + '|' + (rect.top + positiony).toString() + '|' + (rect.right - rect.left).toString() + '|' + (rect.bottom - rect.top).toString()})();")!
                  var split = _result().split("|");
                  var x = parseInt(split[0]), y = parseInt(split[1]), w = parseInt(split[2]), h = parseInt(split[3]);
                  /// Первый квадрат
                  VAR_SQUARE_BUTTON_X = parseInt(x) + VAR_SCROLL_X;
                  VAR_SQUARE_BUTTON_Y = parseInt(y) + VAR_SCROLL_Y;
                  VAR_SQUARE_WIDTH = parseInt(w)
                  VAR_SQUARE_HEIGHT = parseInt(h)
                  //// Реальный рамзер всех 6 квадратов
                  VAR_REAL_SIZE_WIDTH = VAR_SQUARE_WIDTH * 3;
                  VAR_REAL_SIZE_HEIGHT = VAR_SQUARE_HEIGHT * 2;
                  

               })!
               

               
               
               _set_if_expression("W1tGVU5DQVBUQ0hBX1RZUEVdXSA9PSAiR2FtZV9UaWxlIg==");
               _if(VAR_FUNCAPTCHA_TYPE == "Game_Tile",function(){
               
                  
                  
                  VAR_ELEMENT_SELECTOR = VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e button[class*=\u0027tile box\u0027]"
                  

                  
                  
                  _SELECTOR = VAR_ELEMENT_SELECTOR;
                  get_element_selector(_SELECTOR, false).script("(function(){var rect = self.getBoundingClientRect();return (rect.left + positionx).toString() + '|' + (rect.top + positiony).toString() + '|' + (rect.right - rect.left).toString() + '|' + (rect.bottom - rect.top).toString()})();")!
                  var split = _result().split("|");
                  var x = parseInt(split[0]), y = parseInt(split[1]), w = parseInt(split[2]), h = parseInt(split[3]);
                  /// Первый квадрат (Версия плитки)
                  VAR_SQUARE_BUTTON_X = parseInt(x) + VAR_SCROLL_X;
                  VAR_SQUARE_BUTTON_Y = parseInt(y) + VAR_SCROLL_Y;
                  VAR_SQUARE_WIDTH = parseInt(w)
                  VAR_SQUARE_HEIGHT = parseInt(h)
                  //// Реальный рамзер всех 6 квадратов
                  VAR_REAL_SIZE_WIDTH = VAR_SQUARE_WIDTH * 3;
                  VAR_REAL_SIZE_HEIGHT = VAR_SQUARE_HEIGHT * 2;
                  

                  
                  
                  VAR_ELEMENT_SELECTOR = VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e button[class*=\u0027tile box\u0027]\u003eAT\u003e2"
                  

                  
                  
                  _SELECTOR = VAR_ELEMENT_SELECTOR;
                  get_element_selector(_SELECTOR, false).script("(function(){var rect = self.getBoundingClientRect();return (rect.left + positionx).toString() + '|' + (rect.top + positiony).toString() + '|' + (rect.right - rect.left).toString() + '|' + (rect.bottom - rect.top).toString()})();")!
                  var split = _result().split("|");
                  var x = parseInt(split[0]), y = parseInt(split[1]), w = parseInt(split[2]), h = parseInt(split[3]);
                  /// Третий квадрат квадрат (Версия плитки)
                  VAR_SQUARE_NUMBER_3 = parseInt(x);
                  

                  
                  
                  _cycle_params().if_else = VAR_SQUARE_BUTTON_X + VAR_SQUARE_WIDTH*2 == VAR_SQUARE_NUMBER_3;
                  _set_if_expression("W1tTUVVBUkVfQlVUVE9OX1hdXSArIFtbU1FVQVJFX1dJRFRIXV0qMiA9PSBbW1NRVUFSRV9OVU1CRVJfM11d");
                  _if(_cycle_params().if_else,function(){
                  
                     
                     
                     VAR_TILE_NORMAL_VIEW = true
                     

                  })!
                  

                  
                  
                  _if(!_cycle_params().if_else,function(){
                  
                     
                     
                     VAR_TILE_NORMAL_VIEW = false
                     

                  })!
                  delete _cycle_params().if_else;
                  

               })!
               

               
               
               _set_if_expression("W1tGVU5DQVBUQ0hBX1RZUEVdXSA9PSAiR2FtZV9Cb3gi");
               _if(VAR_FUNCAPTCHA_TYPE == "Game_Box",function(){
               
                  
                  
                  VAR_ELEMENT_SELECTOR = VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e a[class*=\u0027right-arrow\u0027]"
                  

                  
                  
                  _SELECTOR = VAR_ELEMENT_SELECTOR;
                  get_element_selector(_SELECTOR, false).script("(function(){var rect = self.getBoundingClientRect();return (rect.left + positionx).toString() + '|' + (rect.top + positiony).toString() + '|' + (rect.right - rect.left).toString() + '|' + (rect.bottom - rect.top).toString()})();")!
                  var split = _result().split("|");
                  var x = parseInt(split[0]), y = parseInt(split[1]), w = parseInt(split[2]), h = parseInt(split[3]);
                  /// Первый квадрат
                  VAR_DIRECT_BUTTON_X = parseInt(x) + VAR_SCROLL_X;
                  VAR_DIRECT_BUTTON_Y = parseInt(y) + VAR_SCROLL_Y;
                  VAR_DIRECT_WIDTH = parseInt(w)
                  VAR_DIRECT_HEIGHT = parseInt(h)
                  ////Высчитаем центр стрелочки
                  VAR_DIRECT_BUTTON_X = VAR_DIRECT_BUTTON_X + VAR_DIRECT_WIDTH/2;
                  VAR_DIRECT_BUTTON_Y = VAR_DIRECT_BUTTON_Y + VAR_DIRECT_HEIGHT/2;
                  

               })!
               

               
               
               _set_if_expression("W1tGVU5DQVBUQ0hBX1RZUEVdXSA9PSAiR2FtZV9IZWFkZXIi");
               _if(VAR_FUNCAPTCHA_TYPE == "Game_Header",function(){
               
                  
                  
                  VAR_ELEMENT_SELECTOR = VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e img[id*=\u0027challenge-image\u0027]"
                  

                  
                  
                  _SELECTOR = VAR_ELEMENT_SELECTOR;
                  get_element_selector(_SELECTOR, false).script("(function(){var rect = self.getBoundingClientRect();return (rect.left + positionx).toString() + '|' + (rect.top + positiony).toString() + '|' + (rect.right - rect.left).toString() + '|' + (rect.bottom - rect.top).toString()})();")!
                  var split = _result().split("|");
                  var x = parseInt(split[0]), y = parseInt(split[1]), w = parseInt(split[2]), h = parseInt(split[3]);
                  /// Первый квадрат
                  VAR_SQUARE_BUTTON_X = parseInt(x) + VAR_SCROLL_X;
                  VAR_SQUARE_BUTTON_Y = parseInt(y) + VAR_SCROLL_Y;
                  VAR_SQUARE_WIDTH = parseInt(w)
                  VAR_SQUARE_HEIGHT = parseInt(h)
                  //// Реальный рамзер всех 6 квадратов
                  VAR_REAL_SIZE_WIDTH = VAR_SQUARE_WIDTH * 3;
                  VAR_REAL_SIZE_HEIGHT = VAR_SQUARE_HEIGHT * 2;
                  

               })!
               

               
               
               _set_if_expression("W1tGVU5DQVBUQ0hBX1RZUEVdXSA9PSAiR2FtZV9DaGlsZHJlbiI=");
               _if(VAR_FUNCAPTCHA_TYPE == "Game_Children",function(){
               
                  
                  
                  VAR_ELEMENT_SELECTOR = VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e a[id*=\u0027children_arrowRight\u0027]"
                  

                  
                  
                  _SELECTOR = VAR_ELEMENT_SELECTOR;
                  get_element_selector(_SELECTOR, false).script("(function(){var rect = self.getBoundingClientRect();return (rect.left + positionx).toString() + '|' + (rect.top + positiony).toString() + '|' + (rect.right - rect.left).toString() + '|' + (rect.bottom - rect.top).toString()})();")!
                  var split = _result().split("|");
                  var x = parseInt(split[0]), y = parseInt(split[1]), w = parseInt(split[2]), h = parseInt(split[3]);
                  /// Первый квадрат
                  VAR_DIRECT_BUTTON_X = parseInt(x) + VAR_SCROLL_X;
                  VAR_DIRECT_BUTTON_Y = parseInt(y) + VAR_SCROLL_Y;
                  VAR_DIRECT_WIDTH = parseInt(w)
                  VAR_DIRECT_HEIGHT = parseInt(h)
                  ////Высчитаем центр стрелочки
                  VAR_DIRECT_BUTTON_X = VAR_DIRECT_BUTTON_X + VAR_DIRECT_WIDTH/2;
                  VAR_DIRECT_BUTTON_Y = VAR_DIRECT_BUTTON_Y + VAR_DIRECT_HEIGHT/2;
                  

               })!
               

               
               
               VAR_GET_ALL_COORDINATES = "1"
               

            })!
            

         },null)!
         

         
         
         _set_if_expression("W1tXQVNfRVJST1JdXQ==");
         _if(typeof(VAR_WAS_ERROR) !== "undefined" ? (VAR_WAS_ERROR) : undefined,function(){
         
            
            
            /*Browser*/
            cache_data_clear()!
            

            
            
            fail(VAR_LAST_ERROR)
            

         })!
         

         
         
         _call(function()
         {
         _on_fail(function(){
         VAR_LAST_ERROR = _result()
         VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
         VAR_WAS_ERROR = false
         _break(1,true)
         })
         CYCLES.Current().RemoveLabel("function")
         
            
            
            _set_if_expression("W1tGVU5DQVBUQ0hBX1RZUEVdXSA9PSAiR2FtZV9JdGVtIg==");
            _if(VAR_FUNCAPTCHA_TYPE == "Game_Item",function(){
            
               
               
               _set_if_expression("W1tGSVJTVF9MT0FEX0NBUFRDSEFdXSA9PSB0cnVl");
               _if(VAR_FIRST_LOAD_CAPTCHA == true,function(){
               
                  
                  
                  /*Browser*/
                  wait_load("*rtig/image*")!
                  

               })!
               

               
               
               /*Browser*/
               ;_SELECTOR=VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e #game_challengeItem";
               get_element_selector(_SELECTOR, false).nowait().exist()!
               VAR_IS_EXISTS = _result() == 1
               _if(VAR_IS_EXISTS, function(){
               get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
               VAR_IS_EXISTS = _result().indexOf("true")>=0
               })!
               

               
               
               _set_if_expression("W1tJU19FWElTVFNdXSA9PSBmYWxzZQ==");
               _if(VAR_IS_EXISTS == false,function(){
               
                  
                  
                  _next("function")
                  

               })!
               

               
               
               /*Browser*/
               _SELECTOR = VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e #game_challengeItem_image";waiter_timeout_next(20000)
               wait_element(_SELECTOR)!
               

               
               
               sleep(200)!
               

               
               
               /*Browser*/
               _SELECTOR = VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e #game_challengeItem_image";
               wait_element(_SELECTOR)!
               get_element_selector(_SELECTOR, false).attr("src")!
               VAR_SAVED_ATTRIBUTE = _result()
               

               
               
               _set_if_expression("W1tTQVZFRF9BVFRSSUJVVEVdXS5pbmRleE9mKCJkYXRhOmltYWdlL2dpZjtiYXNlNjQiKSA+PSAw");
               _if(VAR_SAVED_ATTRIBUTE.indexOf("data:image/gif;base64") >= 0,function(){
               
                  
                  
                  var replace_string_funcap = "data:image/gif;base64,"
                  VAR_IMAGE_BASE_64 = VAR_SAVED_ATTRIBUTE.replace(replace_string_funcap, "")
                  

                  
                  
                  VAR_LOADED_IMAGE_ID = native("imageprocessing", "load", VAR_IMAGE_BASE_64)
                  

                  
                  
                  var split = native("imageprocessing", "convert", (VAR_LOADED_IMAGE_ID) + "," + ("jpeg"))
                  

                  
                  
                  {
                  var split = native("imageprocessing", "getsize", VAR_LOADED_IMAGE_ID).split(",")
                  VAR_GET_IMAGE_W = parseInt(split[0])
                  VAR_GET_IMAGE_H = parseInt(split[1])
                  }
                  

                  
                  
                  VAR_IMAGE_BASE_64 = native("imageprocessing", "getdata", VAR_LOADED_IMAGE_ID)
                  

                  
                  
                  native("imageprocessing", "delete", VAR_LOADED_IMAGE_ID)
                  

               })!
               

               
               
               _set_if_expression("W1tTQVZFRF9BVFRSSUJVVEVdXS5pbmRleE9mKCJkYXRhOmltYWdlL2pwZWc7YmFzZTY0IikgPj0gMA==");
               _if(VAR_SAVED_ATTRIBUTE.indexOf("data:image/jpeg;base64") >= 0,function(){
               
                  
                  
                  var replace_string_funcap = "data:image/jpeg;base64,"
                  VAR_IMAGE_BASE_64 = VAR_SAVED_ATTRIBUTE.replace(replace_string_funcap, "")
                  

                  
                  
                  VAR_LOADED_IMAGE_ID = native("imageprocessing", "load", VAR_IMAGE_BASE_64)
                  

                  
                  
                  {
                  var split = native("imageprocessing", "getsize", VAR_LOADED_IMAGE_ID).split(",")
                  VAR_GET_IMAGE_W = parseInt(split[0])
                  VAR_GET_IMAGE_H = parseInt(split[1])
                  }
                  

                  
                  
                  native("imageprocessing", "delete", VAR_LOADED_IMAGE_ID)
                  

               })!
               

            })!
            

            
            
            _set_if_expression("W1tGVU5DQVBUQ0hBX1RZUEVdXSA9PSAiR2FtZV9UaWxlIg==");
            _if(VAR_FUNCAPTCHA_TYPE == "Game_Tile",function(){
            
               
               
               /*Browser*/
               ;_SELECTOR=VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e div[class*=\u0027tile-game box screen\u0027]";
               get_element_selector(_SELECTOR, false).nowait().exist()!
               VAR_IS_EXISTS = _result() == 1
               _if(VAR_IS_EXISTS, function(){
               get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
               VAR_IS_EXISTS = _result().indexOf("true")>=0
               })!
               

               
               
               _set_if_expression("W1tJU19FWElTVFNdXSA9PSBmYWxzZQ==");
               _if(VAR_IS_EXISTS == false,function(){
               
                  
                  
                  _next("function")
                  

               })!
               

               
               
               /*Browser*/
               waiter_timeout_next(45000)
               wait_load("*blob*")!
               

               
               
               /*Browser*/
               wait_load("*blob*")!
               cache_get_base64("*blob*")!
               VAR_IMAGE_BASE_64 = _result()
               

               
               
               VAR_LOADED_IMAGE_ID = native("imageprocessing", "load", VAR_IMAGE_BASE_64)
               

               
               
               {
               var split = native("imageprocessing", "getsize", VAR_LOADED_IMAGE_ID).split(",")
               VAR_GET_IMAGE_W = parseInt(split[0])
               VAR_GET_IMAGE_H = parseInt(split[1])
               }
               

               
               
               native("imageprocessing", "delete", VAR_LOADED_IMAGE_ID)
               

               
               
               _set_if_expression("W1tJTUFHRV9CQVNFXzY0XV0gPT0gIiI=");
               _if(VAR_IMAGE_BASE_64 == "",function(){
               
                  
                  
                  VAR_CACHE_ERROR = "1"
                  

                  
                  
                  _next("function")
                  

               })!
               

            })!
            

            
            
            _set_if_expression("W1tGVU5DQVBUQ0hBX1RZUEVdXSA9PSAiR2FtZV9IZWFkZXIi");
            _if(VAR_FUNCAPTCHA_TYPE == "Game_Header",function(){
            
               
               
               /*Browser*/
               ;_SELECTOR=VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e img[id*=\u0027challenge-image\u0027]";
               get_element_selector(_SELECTOR, false).nowait().exist()!
               VAR_IS_EXISTS = _result() == 1
               _if(VAR_IS_EXISTS, function(){
               get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
               VAR_IS_EXISTS = _result().indexOf("true")>=0
               })!
               

               
               
               _set_if_expression("W1tJU19FWElTVFNdXSA9PSBmYWxzZQ==");
               _if(VAR_IS_EXISTS == false,function(){
               
                  
                  
                  _next("function")
                  

               })!
               

               
               
               /*Browser*/
               waiter_timeout_next(45000)
               wait_load("*/rtig/image*")!
               

               
               
               /*Browser*/
               wait_load("*/rtig/image*")!
               cache_get_base64("*/rtig/image*")!
               VAR_IMAGE_BASE_64 = _result()
               

               
               
               VAR_LOADED_IMAGE_ID = native("imageprocessing", "load", VAR_IMAGE_BASE_64)
               

               
               
               {
               var split = native("imageprocessing", "getsize", VAR_LOADED_IMAGE_ID).split(",")
               VAR_GET_IMAGE_W = parseInt(split[0])
               VAR_GET_IMAGE_H = parseInt(split[1])
               }
               

               
               
               native("imageprocessing", "delete", VAR_LOADED_IMAGE_ID)
               

               
               
               _set_if_expression("W1tJTUFHRV9CQVNFXzY0XV0gPT0gIiI=");
               _if(VAR_IMAGE_BASE_64 == "",function(){
               
                  
                  
                  VAR_CACHE_ERROR = "1"
                  

                  
                  
                  _next("function")
                  

               })!
               

            })!
            

            
            
            _set_if_expression("W1tGVU5DQVBUQ0hBX1RZUEVdXSA9PSAiR2FtZV9Cb3gi");
            _if(VAR_FUNCAPTCHA_TYPE == "Game_Box",function(){
            
               
               
               /*Browser*/
               ;_SELECTOR=VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e div[class*=\u0027match-game box screen\u0027]";
               get_element_selector(_SELECTOR, false).nowait().exist()!
               VAR_IS_EXISTS = _result() == 1
               _if(VAR_IS_EXISTS, function(){
               get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
               VAR_IS_EXISTS = _result().indexOf("true")>=0
               })!
               

               
               
               _set_if_expression("W1tJU19FWElTVFNdXSA9PSBmYWxzZQ==");
               _if(VAR_IS_EXISTS == false,function(){
               
                  
                  
                  _next("function")
                  

               })!
               

               
               
               /*Browser*/
               waiter_timeout_next(45000)
               wait_load("*blob*")!
               

               
               
               /*Browser*/
               wait_load("*blob*")!
               cache_get_base64("*blob*")!
               VAR_IMAGE_BASE_64 = _result()
               

               
               
               _set_if_expression("W1tJTUFHRV9CQVNFXzY0XV0gPT0gIiI=");
               _if(VAR_IMAGE_BASE_64 == "",function(){
               
                  
                  
                  VAR_CACHE_ERROR = "1"
                  

                  
                  
                  _next("function")
                  

               })!
               

            })!
            

            
            
            _set_if_expression("W1tGVU5DQVBUQ0hBX1RZUEVdXSA9PSAiR2FtZV9DaGlsZHJlbiI=");
            _if(VAR_FUNCAPTCHA_TYPE == "Game_Children",function(){
            
               
               
               _set_if_expression("W1tGSVJTVF9MT0FEX0NBUFRDSEFdXSA9PSB0cnVl");
               _if(VAR_FIRST_LOAD_CAPTCHA == true,function(){
               
                  
                  
                  /*Browser*/
                  wait_load("*rtig/image*")!
                  

               })!
               

               
               
               /*Browser*/
               ;_SELECTOR=VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e img[id*=\u0027children_challengeImage\u0027]";
               get_element_selector(_SELECTOR, false).nowait().exist()!
               VAR_IS_EXISTS = _result() == 1
               _if(VAR_IS_EXISTS, function(){
               get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
               VAR_IS_EXISTS = _result().indexOf("true")>=0
               })!
               

               
               
               _set_if_expression("W1tJU19FWElTVFNdXSA9PSBmYWxzZQ==");
               _if(VAR_IS_EXISTS == false,function(){
               
                  
                  
                  _next("function")
                  

               })!
               

               
               
               /*Browser*/
               _SELECTOR = VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e img[id*=\u0027children_challengeImage\u0027]";waiter_timeout_next(20000)
               wait_element(_SELECTOR)!
               

               
               
               /*Browser*/
               _SELECTOR = VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e img[id*=\u0027children_challengeImage\u0027]";
               wait_element(_SELECTOR)!
               get_element_selector(_SELECTOR, false).script('_BAS_SAFE(Window.getComputedStyle)(self)[' + JSON.stringify("background") + ']')!
               VAR_SAVED_STYLE = _result()
               

               
               
               VAR_SAVED_STYLE = _get_substring_between(VAR_SAVED_STYLE,"data:image","\u0022");
               

               
               
               _set_if_expression("W1tTQVZFRF9TVFlMRV1dLmluZGV4T2YoIi9naWY7YmFzZTY0IikgPj0gMA==");
               _if(VAR_SAVED_STYLE.indexOf("/gif;base64") >= 0,function(){
               
                  
                  
                  var replace_string_funcap = "/gif;base64,"
                  VAR_IMAGE_BASE_64 = VAR_SAVED_STYLE.replace(replace_string_funcap, "")
                  

               })!
               

               
               
               _set_if_expression("W1tTQVZFRF9TVFlMRV1dLmluZGV4T2YoIi9qcGVnO2Jhc2U2NCIpID49IDA=");
               _if(VAR_SAVED_STYLE.indexOf("/jpeg;base64") >= 0,function(){
               
                  
                  
                  var replace_string_funcap = "/jpeg;base64,"
                  VAR_IMAGE_BASE_64 = VAR_SAVED_STYLE.replace(replace_string_funcap, "")
                  

               })!
               

            })!
            

         },null)!
         

         
         
         _set_if_expression("W1tXQVNfRVJST1JdXQ==");
         _if(typeof(VAR_WAS_ERROR) !== "undefined" ? (VAR_WAS_ERROR) : undefined,function(){
         
            
            
            /*Browser*/
            cache_data_clear()!
            

            
            
            fail(VAR_LAST_ERROR)
            

         })!
         

         

         
         
         VAR_FIRST_LOAD_CAPTCHA = false
         

         
         
         _call(function()
         {
         _on_fail(function(){
         VAR_LAST_ERROR = _result()
         VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
         VAR_WAS_ERROR = false
         _break(1,true)
         })
         CYCLES.Current().RemoveLabel("function")
         
            
            
            _do(function(){
            _set_action_info({ name: "For" });
            VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
            if(VAR_CYCLE_INDEX > parseInt(20))_break();
            
               
               
               ///Чистим
               solver_properties_clear("capmonster")
               if (VAR_FUNCAPTCHA_TYPE == "Game_Item") var click_method_module_type = "funcap";
               if (VAR_FUNCAPTCHA_TYPE == "Game_Tile") var click_method_module_type = "funcap";
               if (VAR_FUNCAPTCHA_TYPE == "Game_Box") var click_method_module_type = "funcap2";
               if (VAR_FUNCAPTCHA_TYPE == "Game_Children") var click_method_module_type = "funcap2";
               if (VAR_METHOD_MODULE == "CaptchaGuru (RU Server)") VAR_SERVER_SOLVE = "https://92.53.65.152/"
               if (VAR_METHOD_MODULE == "CaptchaGuru (German Server)") VAR_SERVER_SOLVE = "https://159.69.241.182/"
               if (VAR_METHOD_MODULE == "CaptchaGuru (Finland Server)") VAR_SERVER_SOLVE = "https://95.217.17.172/"
               /// Если юзер оставил старый метод и не пересоздал дейстие с модулем, то оставим дефолт сервер хецнер
               if (VAR_METHOD_MODULE == "CaptchaGuru") VAR_SERVER_SOLVE = "https://159.69.241.182/"
               _if(VAR_METHOD_MODULE == "GoodxevilPay.Shop",function(){
               
					_SELECTOR = VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e h2";
					wait_element(_SELECTOR)!
					get_element_selector(_SELECTOR, false).text()!
					VAR_SHORT_TASK = _result()
					VAR_SHORT_TASK = VAR_SHORT_TASK.split(".")[0]
					
					if (VAR_FUNCAPTCHA_TYPE == "Game_Item") VAR_RETURN_TYPE = "funcap|";
					if (VAR_FUNCAPTCHA_TYPE == "Game_Tile") VAR_RETURN_TYPE = "funcap|";
					if (VAR_FUNCAPTCHA_TYPE == "Game_Box") VAR_RETURN_TYPE = "funcap2|";
					if (VAR_FUNCAPTCHA_TYPE == "Game_Children") VAR_RETURN_TYPE = "funcap2|";
					VAR_SERVER_SOLVE = "http://goodxevilpay.pp.ua/"
				  
					/// Формирумем основной запрос
					solver_property("capmonster","serverurl",VAR_SERVER_SOLVE)
					//if (VAR_FUNCAPTCHA_TYPE != "Game_Box") solver_property("capmonster","coordinatescaptcha","1")
					solver_property("capmonster","key",VAR_KEY_MODULE)
					solver_property("capmonster","imginstructions",VAR_SHORT_TASK)
					solver_property("capmonster","click",VAR_RETURN_TYPE)
					//solver_property("capmonster","basmodule",VAR_BAS_MODULE_VERSION)
					solver_property("capmonster","method","post")
					//// Отправляем
					solve_base64_no_fail("capmonster", VAR_IMAGE_BASE_64)!
					VAR_SAVED_CONTENT = _result();
				  
               })!
			   
			   
			   _if(Boolean(native("regexp", "ismatch", JSON.stringify({text: VAR_METHOD_MODULE,regexp:"(CaptchaGuru)"})) == "true"),function(){
               
					/// Формирумем основной запрос
					solver_property("capmonster","serverurl",VAR_SERVER_SOLVE)
					if (VAR_FUNCAPTCHA_TYPE != "Game_Box") solver_property("capmonster","coordinatescaptcha","1")
					solver_property("capmonster","key",VAR_KEY_MODULE)
					solver_property("capmonster","textinstructions",VAR_SET_TASK)
					solver_property("capmonster","click",click_method_module_type)
					solver_property("capmonster","basmodule",VAR_BAS_MODULE_VERSION)
					solver_property("capmonster","method","post")
					//// Отправляем
					solve_base64_no_fail("capmonster", VAR_IMAGE_BASE_64)!
					VAR_SAVED_CONTENT = _result();
                  

               })!
               

               
               
               _set_if_expression("W1tTQVZFRF9DT05URU5UXV0uaW5kZXhPZigiRVJST1JfQ0FQVENIQV9VTlNPTFZBQkxFIikgPj0gMA==");
               _if(VAR_SAVED_CONTENT.indexOf("ERROR_CAPTCHA_UNSOLVABLE") >= 0,function(){
               
                  
                  
                  VAR_ERROR_TASK = parseInt(VAR_ERROR_TASK) + parseInt(1)
                  

                  
                  
                  sleep(1000)!
                  

                  
                  
                  _break("function")
                  

               })!
               

               
               
               _set_if_expression("W1tTQVZFRF9DT05URU5UXV0uaW5kZXhPZigiRVJST1JfV1JPTkdfVVNFUl9LRVkiKSA+PSAw");
               _if(VAR_SAVED_CONTENT.indexOf("ERROR_WRONG_USER_KEY") >= 0,function(){
               
                  
                  
                  VAR_ERROR_KEY = "1"
                  

                  
                  
                  _break("function")
                  

               })!
               

               
               
               _set_if_expression("W1tTQVZFRF9DT05URU5UXV0uaW5kZXhPZigiRVJST1JfWkVST19CQUxBTkNFIikgPj0gMA==");
               _if(VAR_SAVED_CONTENT.indexOf("ERROR_ZERO_BALANCE") >= 0,function(){
               
                  
                  
                  VAR_ERROR_BALANCE = "1"
                  

                  
                  
                  _break("function")
                  

               })!
               

               
               
               _set_if_expression("W1tTQVZFRF9DT05URU5UXV0uaW5kZXhPZigiQ0FQVENIQV9GQUlMIikgPj0gMA==");
               _if(VAR_SAVED_CONTENT.indexOf("CAPTCHA_FAIL") >= 0,function(){
               
                  
                  
                  sleep(rand(1000,2000))!
                  

                  
                  
                  VAR_CAPTCHA_FAIL = parseInt(VAR_CAPTCHA_FAIL) + parseInt(1)
                  

                  
                  
                  _break("function")
                  

               })!
               

               
               
               _cycle_params().if_else = VAR_SAVED_CONTENT.match(/^\d+$/) && (VAR_FUNCAPTCHA_TYPE == "Game_Box" || VAR_FUNCAPTCHA_TYPE == "Game_Children") || VAR_SAVED_CONTENT.match(/[0-9]/) && VAR_SAVED_CONTENT.indexOf("coordinates") >= 0 && VAR_FUNCAPTCHA_TYPE != "Game_Box" && VAR_FUNCAPTCHA_TYPE != "Game_Children";
               _set_if_expression("W1tTQVZFRF9DT05URU5UXV0ubWF0Y2goL15cZCskLykgJiYgKFtbRlVOQ0FQVENIQV9UWVBFXV0gPT0gIkdhbWVfQm94IiB8fCBbW0ZVTkNBUFRDSEFfVFlQRV1dID09ICJHYW1lX0NoaWxkcmVuIikgfHwgW1tTQVZFRF9DT05URU5UXV0ubWF0Y2goL1swLTldLykgJiYgW1tTQVZFRF9DT05URU5UXV0uaW5kZXhPZigiY29vcmRpbmF0ZXMiKSA+PSAwICYmIFtbRlVOQ0FQVENIQV9UWVBFXV0gIT0gIkdhbWVfQm94IiAmJiBbW0ZVTkNBUFRDSEFfVFlQRV1dICE9ICJHYW1lX0NoaWxkcmVuIg==");
               _if(_cycle_params().if_else,function(){
               
                  
                  
                  VAR_MODULE_FRAME_SELECTOR = _BAS_SOLVER_PROPERTIES;
                  VAR_MODULE_FRAME_SELECTOR = {"capmonster":{"serverurl":"https://159.69.241.182/","coordinatescaptcha":"1","key":"635bc745b69046213fc3850914c24a05","textinstructions":VAR_SET_TASK,"click":click_method_module_type,"basmodule":VAR_BAS_MODULE_VERSION,"method":"post"}}
                  _if(VAR_FUNCAPTCHA_TYPE == "Game_Box",function(){
                  	VAR_MODULE_FRAME_SELECTOR = {"capmonster":{"serverurl":"https://159.69.241.182/","key":"635bc745b69046213fc3850914c24a05","textinstructions":VAR_SET_TASK,"click":click_method_module_type,"basmodule":VAR_BAS_MODULE_VERSION,"method":"post"}}
                  })!
                  //VAR_FORMATTED_JSON_F = JPath.changeFormat(VAR_MODULE_FRAME_SELECTOR, "String");
                  var data = VAR_MODULE_FRAME_SELECTOR;
                  var selectors_number = [ VAR_SELECTOR_1,VAR_SELECTOR_2 ]
                  VAR_RESULT_SELECTOR = data[selectors_number[0]][selectors_number[1]];
                  

                  
                  
                  _set_if_expression("W1tTQVZFRF9GQUlMRURfSU1BR0VTXV0gPT0gdHJ1ZSAmJiAoW1tGVU5DQVBUQ0hBX1RZUEVdXSA9PSAiR2FtZV9Cb3giIHx8IFtbRlVOQ0FQVENIQV9UWVBFXV0gPT0gIkdhbWVfQ2hpbGRyZW4iKQ==");
                  _if(VAR_SAVED_FAILED_IMAGES == true && (VAR_FUNCAPTCHA_TYPE == "Game_Box" || VAR_FUNCAPTCHA_TYPE == "Game_Children"),function(){
                  
                     
                     
                     VAR_CURRENT_TASK_NUMBER_SOLVE = parseInt(VAR_CURRENT_TASK_NUMBER_SOLVE) + parseInt(1)
                     

                     
                     
                     _info((_K==="en" ? "Saved image im folder C:/Images/FunCaptcha/" +VAR_SET_TASK + "/" + VAR_NUMBER_FOLDER + "/Right answer - " +VAR_SAVED_CONTENT +"; TaskNumber - " +VAR_CURRENT_TASK_NUMBER_SOLVE +".jpg. Current Task: " +VAR_SET_TASK+ ". Fancaptcha Type: " +VAR_FUNCAPTCHA_TYPE: "Сохранили картинку в папку C:/Images/FunCaptcha/" +VAR_SET_TASK + "/" + VAR_NUMBER_FOLDER + "/Right answer - " +VAR_SAVED_CONTENT +"; TaskNumber - " +VAR_CURRENT_TASK_NUMBER_SOLVE +".jpg. Задание: " +VAR_SET_TASK+ ". Тип капчи: " +VAR_FUNCAPTCHA_TYPE));
                     

                     
                     
                     native("filesystem", "writefile", JSON.stringify({path: "C:\u005cImages\u005cFunCaptcha\u005c" + VAR_SET_TASK + "\u005c" + VAR_NUMBER_FOLDER + "\u005cRight answer - " + VAR_SAVED_CONTENT + "; Task number - " + VAR_CURRENT_TASK_NUMBER_SOLVE + ".jpeg",value: (VAR_IMAGE_BASE_64).toString(),base64:true,append:false}))
                     

                  })!
                  

                  
                  
                  _set_if_expression("W1tTQVZFRF9GQUlMRURfSU1BR0VTXV0gPT0gdHJ1ZSAmJiBbW0ZVTkNBUFRDSEFfVFlQRV1dICE9ICJHYW1lX0JveCIgJiYgW1tGVU5DQVBUQ0hBX1RZUEVdXSAhPSAiR2FtZV9DaGlsZHJlbiIg");
                  _if(VAR_SAVED_FAILED_IMAGES == true && VAR_FUNCAPTCHA_TYPE != "Game_Box" && VAR_FUNCAPTCHA_TYPE != "Game_Children" ,function(){
                  
                     
                     
                     VAR_CURRENT_TASK_NUMBER_SOLVE = parseInt(VAR_CURRENT_TASK_NUMBER_SOLVE) + parseInt(1)
                     

                     
                     
                     _info((_K==="en" ? "Saved image in folder C:/Images/FunCaptcha/" +VAR_SET_TASK +"/"+VAR_NUMBER_FOLDER + "/"+VAR_CURRENT_TASK_NUMBER_SOLVE + ".jpg. Сlick coordinates : " + VAR_SAVED_CONTENT + ". Current Task: " +VAR_SET_TASK+ ". FunCaptcha type: " +VAR_FUNCAPTCHA_TYPE: "Сохранили картинку в папку C:/Images/FunCaptcha/" +VAR_SET_TASK +"/"+VAR_NUMBER_FOLDER + "/"+VAR_CURRENT_TASK_NUMBER_SOLVE + ".jpg. Координаты для клика : " + VAR_SAVED_CONTENT + ". Задание: " +VAR_SET_TASK+ ". Тип капчи: " +VAR_FUNCAPTCHA_TYPE));
                     

                     
                     
                     native("filesystem", "writefile", JSON.stringify({path: "C:\u005cImages\u005cFunCaptcha\u005c" + VAR_SET_TASK + "\u005c" + VAR_NUMBER_FOLDER + "\u005c" + VAR_CURRENT_TASK_NUMBER_SOLVE + ".jpeg",value: (VAR_IMAGE_BASE_64).toString(),base64:true,append:false}))
                     

                  })!
                  

                  
                  
                  /*Browser*/
                  cache_data_clear()!
                  

                  
                  
                  _set_if_expression("W1tGVU5DQVBUQ0hBX1RZUEVdXSA9PSAiR2FtZV9JdGVtIiB8fCBbW0ZVTkNBUFRDSEFfVFlQRV1dID09ICJHYW1lX0hlYWRlciIgfHwgW1tGVU5DQVBUQ0hBX1RZUEVdXSA9PSAiR2FtZV9UaWxlIg==");
                  _if(VAR_FUNCAPTCHA_TYPE == "Game_Item" || VAR_FUNCAPTCHA_TYPE == "Game_Header" || VAR_FUNCAPTCHA_TYPE == "Game_Tile",function(){
                  
                     
                     
                     VAR_LISTS_COORDINATES = VAR_SAVED_CONTENT
                     VAR_LISTS_COORDINATES = VAR_LISTS_COORDINATES.split("coordinates:")[1];
                     VAR_LISTS_COORDINATES = VAR_LISTS_COORDINATES.split(";");
                     

                     
                     
                     ;(function (a) {var j, x, i;for (i = a.length; i; i--) {j = Math.floor(Math.random() * i);x = a[i - 1]; a[i - 1] = a[j];a[j] = x;}})(VAR_LISTS_COORDINATES)
                     

                     
                     
                     _do_with_params({"foreach_data":(VAR_LISTS_COORDINATES)},function(){
                     _set_action_info({ name: "Foreach" });
                     VAR_CYCLE_INDEX = _iterator() - 1
                     if(VAR_CYCLE_INDEX > _cycle_param("foreach_data").length - 1)_break();
                     VAR_FOREACH_DATA = _cycle_param("foreach_data")[VAR_CYCLE_INDEX]
                     
                        
                        
                        var csv_parse_result = csv_parse(VAR_FOREACH_DATA)
                        VAR_ANSWER_X = csv_parse_result[0]
                        if(typeof(VAR_ANSWER_X) == 'undefined' || !VAR_ANSWER_X)
                        {
                        VAR_ANSWER_X = ""
                        }
                        VAR_ANSWER_Y = csv_parse_result[1]
                        if(typeof(VAR_ANSWER_Y) == 'undefined' || !VAR_ANSWER_Y)
                        {
                        VAR_ANSWER_Y = ""
                        }
                        

                        
                        
                        VAR_ANSWER_X = VAR_ANSWER_X.replace(/[^0-9]/g, '');
                        VAR_ANSWER_Y = VAR_ANSWER_Y.replace(/[^0-9]/g, '');
                        VAR_ANSWER_X = parseInt(VAR_ANSWER_X)
                        VAR_ANSWER_Y = parseInt(VAR_ANSWER_Y)
                        if (VAR_TILE_NORMAL_VIEW == 0 || VAR_TILE_NORMAL_VIEW == true)
                        {
                        /// Реальные размеры картинки из кэша
                        var bigWidth = VAR_GET_IMAGE_W;
                        var bigHeight = VAR_GET_IMAGE_H;
                        /// Реальные размеры картинки из СSS окна
                        var smallWidth = VAR_REAL_SIZE_WIDTH;
                        var smallHeight = VAR_REAL_SIZE_HEIGHT;
                        var xBig = VAR_ANSWER_X; // координата x на большой картинке
                        var yBig = VAR_ANSWER_Y; // координата y на большой картинке
                        VAR_ANSWER_X = xBig / bigWidth  * smallWidth; // преобразование x
                        VAR_ANSWER_Y = yBig / bigHeight * smallHeight;  // преобразование y
                        }
                        if (VAR_FUNCAPTCHA_TYPE == "Game_Tile" && VAR_TILE_NORMAL_VIEW == false) {
                        /// Переворачиваем координаты
                        if (VAR_ANSWER_X == 150 && VAR_ANSWER_Y == 150) VAR_ANSWER_X = 50, VAR_ANSWER_Y = 250
                        if (VAR_ANSWER_X == 50 && VAR_ANSWER_Y == 150) VAR_ANSWER_X = 150, VAR_ANSWER_Y = 150
                        if (VAR_ANSWER_X == 250 && VAR_ANSWER_Y == 50) VAR_ANSWER_X = 50, VAR_ANSWER_Y = 150
                        if (VAR_ANSWER_X == 250 && VAR_ANSWER_Y == 150) VAR_ANSWER_X = 150, VAR_ANSWER_Y = 250
                        }
                        

                        
                        
                        /*Browser*/
                        move(VAR_SQUARE_BUTTON_X + VAR_ANSWER_X + rand (-10,+10),VAR_SQUARE_BUTTON_Y + VAR_ANSWER_Y + rand (-10,+10),  {"speed": VAR_SPEED,"gravity": VAR_GRAVITY,"deviation": VAR_DEVIATION} )!
                        mouse(VAR_SQUARE_BUTTON_X + VAR_ANSWER_X + rand (-10,+10),VAR_SQUARE_BUTTON_Y + VAR_ANSWER_Y + rand (-10,+10))!
                        

                        
                        
                        /*Browser*/
                        move(VAR_SQUARE_BUTTON_X  + VAR_ANSWER_X,VAR_SQUARE_BUTTON_Y  + VAR_ANSWER_Y,  {} )!
                        

                     })!
                     

                  })!
                  

                  
                  
                  _set_if_expression("KFtbRlVOQ0FQVENIQV9UWVBFXV0gPT0gIkdhbWVfQm94IiB8fCBbW0ZVTkNBUFRDSEFfVFlQRV1dID09ICJHYW1lX0NoaWxkcmVuIikgJiYgW1tTQVZFRF9DT05URU5UXV0gIT0x");
                  _if((VAR_FUNCAPTCHA_TYPE == "Game_Box" || VAR_FUNCAPTCHA_TYPE == "Game_Children") && VAR_SAVED_CONTENT !=1,function(){
                  
                     
                     
                     _do(function(){
                     _set_action_info({ name: "For" });
                     VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
                     if(VAR_CYCLE_INDEX > parseInt(VAR_SAVED_CONTENT - 1))_break();
                     
                        
                        
                        /*Browser*/
                        move(VAR_DIRECT_BUTTON_X + rand (3,3),VAR_DIRECT_BUTTON_Y + rand (3,3),  {} )!
                        mouse(VAR_DIRECT_BUTTON_X + rand (3,3),VAR_DIRECT_BUTTON_Y + rand (3,3))!
                        

                        
                        
                        _cycle_params().if_else = rand (1,10) > 5;
                        _set_if_expression("cmFuZCAoMSwxMCkgPiA1");
                        _if(_cycle_params().if_else,function(){
                        
                           
                           
                           sleep(rand(100,200))!
                           

                        })!
                        

                        
                        
                        _if(!_cycle_params().if_else,function(){
                        
                           
                           
                           sleep(rand(400,800))!
                           

                        })!
                        delete _cycle_params().if_else;
                        

                        
                        
                        _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gMjU=");
                        _if(VAR_CYCLE_INDEX > 25,function(){
                        
                           
                           
                           _break("function")
                           

                        })!
                        

                     })!
                     

                     
                     
                     /*Browser*/
                     ;_SELECTOR=VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e img[style*=\u0027blob\u0027]";
                     get_element_selector(_SELECTOR, false).nowait().exist()!
                     VAR_IS_EXISTS = _result() == 1
                     _if(VAR_IS_EXISTS, function(){
                     get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
                     VAR_IS_EXISTS = _result().indexOf("true")>=0
                     })!
                     

                     
                     
                     _set_if_expression("W1tJU19FWElTVFNdXQ==");
                     _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
                     
                        
                        
                        sleep(100)!
                        

                        
                        
                        /*Browser*/
                        _SELECTOR = VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e img[style*=\u0027blob\u0027]";
                        wait_element(_SELECTOR)!
                        get_element_selector(_SELECTOR, false).attr("aria-label")!
                        VAR_SAVED_ATTRIBUTE = _result()
                        

                        
                        
                        function findSmallestNumber(str) {
                        var numbers = str.match(/-?\d+(\.\d+)?/g); // получаем все числа из строки
                        var smallest = Math.min.apply(Math, numbers); // находим минимальное число
                        return smallest;
                        }
                        var str = VAR_SAVED_ATTRIBUTE
                        VAR_MIN_NUMBERS_TASK = findSmallestNumber(str);
                        

                        
                        
                        _set_if_expression("W1tNSU5fTlVNQkVSU19UQVNLXV0gPT0gMQ==");
                        _if(VAR_MIN_NUMBERS_TASK == 1,function(){
                        
                           
                           
                           VAR_ELEMENT_SELECTOR = VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e a[class*=\u0027left-arrow\u0027]"
                           

                           
                           
                           _SELECTOR = VAR_ELEMENT_SELECTOR;
                           get_element_selector(_SELECTOR, false).script("(function(){var rect = self.getBoundingClientRect();return (rect.left + positionx).toString() + '|' + (rect.top + positiony).toString() + '|' + (rect.right - rect.left).toString() + '|' + (rect.bottom - rect.top).toString()})();")!
                           var split = _result().split("|");
                           var x = parseInt(split[0]), y = parseInt(split[1]), w = parseInt(split[2]), h = parseInt(split[3]);
                           /// Первый квадрат
                           VAR_DIRECT_BUTTON_X = parseInt(x)
                           VAR_DIRECT_BUTTON_Y = parseInt(y) + VAR_SCROLL_Y;
                           VAR_DIRECT_WIDTH = parseInt(w)
                           VAR_DIRECT_HEIGHT = parseInt(h)
                           ////Высчитаем центр стрелочки
                           VAR_DIRECT_BUTTON_X = VAR_DIRECT_BUTTON_X + VAR_DIRECT_WIDTH/2;
                           VAR_DIRECT_BUTTON_Y = VAR_DIRECT_BUTTON_Y + VAR_DIRECT_HEIGHT/2;
                           

                           
                           
                           _do(function(){
                           _set_action_info({ name: "For" });
                           VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
                           if(VAR_CYCLE_INDEX > parseInt(10))_break();
                           
                              
                              
                              _set_if_expression("W1tTQVZFRF9DT05URU5UXV0gPT0gNg==");
                              _if(VAR_SAVED_CONTENT == 6,function(){
                              
                                 
                                 
                                 VAR_SAVED_CONTENT = "1"
                                 

                                 
                                 
                                 _break("function")
                                 

                              })!
                              

                              
                              
                              _set_if_expression("W1tTQVZFRF9DT05URU5UXV0gPT0gNQ==");
                              _if(VAR_SAVED_CONTENT == 5,function(){
                              
                                 
                                 
                                 VAR_SAVED_CONTENT = "2"
                                 

                                 
                                 
                                 _break("function")
                                 

                              })!
                              

                              
                              
                              _set_if_expression("W1tTQVZFRF9DT05URU5UXV0gPT0gNA==");
                              _if(VAR_SAVED_CONTENT == 4,function(){
                              
                                 
                                 
                                 VAR_SAVED_CONTENT = "3"
                                 

                                 
                                 
                                 _break("function")
                                 

                              })!
                              

                              
                              
                              _set_if_expression("W1tTQVZFRF9DT05URU5UXV0gPT0gMw==");
                              _if(VAR_SAVED_CONTENT == 3,function(){
                              
                                 
                                 
                                 VAR_SAVED_CONTENT = "4"
                                 

                                 
                                 
                                 _break("function")
                                 

                              })!
                              

                              
                              
                              _set_if_expression("W1tTQVZFRF9DT05URU5UXV0gPT0gMg==");
                              _if(VAR_SAVED_CONTENT == 2,function(){
                              
                                 
                                 
                                 VAR_SAVED_CONTENT = "5"
                                 

                                 
                                 
                                 _break("function")
                                 

                              })!
                              

                              
                              
                              sleep(300)!
                              

                           })!
                           

                           
                           
                           _do(function(){
                           _set_action_info({ name: "For" });
                           VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
                           if(VAR_CYCLE_INDEX > parseInt(VAR_SAVED_CONTENT))_break();
                           
                              
                              
                              /*Browser*/
                              move(VAR_DIRECT_BUTTON_X + rand (3,3),VAR_DIRECT_BUTTON_Y + rand (3,3),  {} )!
                              mouse(VAR_DIRECT_BUTTON_X + rand (3,3),VAR_DIRECT_BUTTON_Y + rand (3,3))!
                              

                              
                              
                              _cycle_params().if_else = rand (1,10) > 5;
                              _set_if_expression("cmFuZCAoMSwxMCkgPiA1");
                              _if(_cycle_params().if_else,function(){
                              
                                 
                                 
                                 sleep(rand(100,200))!
                                 

                              })!
                              

                              
                              
                              _if(!_cycle_params().if_else,function(){
                              
                                 
                                 
                                 sleep(rand(400,800))!
                                 

                              })!
                              delete _cycle_params().if_else;
                              

                              
                              
                              _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gMjA=");
                              _if(VAR_CYCLE_INDEX > 20,function(){
                              
                                 
                                 
                                 _break("function")
                                 

                              })!
                              

                           })!
                           

                           
                           
                           VAR_GET_ALL_COORDINATES = "0"
                           

                        })!
                        

                     })!
                     

                     
                     
                     /*Browser*/
                     ;_SELECTOR=VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e img[id*=\u0027children_challengeImage\u0027]";
                     get_element_selector(_SELECTOR, false).nowait().exist()!
                     VAR_IS_EXISTS = _result() == 1
                     _if(VAR_IS_EXISTS, function(){
                     get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
                     VAR_IS_EXISTS = _result().indexOf("true")>=0
                     })!
                     

                     
                     
                     _set_if_expression("W1tJU19FWElTVFNdXQ==");
                     _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
                     
                        
                        
                        sleep(100)!
                        

                        
                        
                        /*Browser*/
                        _SELECTOR = VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e img[id*=\u0027children_challengeImage\u0027]";
                        wait_element(_SELECTOR)!
                        get_element_selector(_SELECTOR, false).attr("aria-label")!
                        VAR_SAVED_ATTRIBUTE = _result()
                        

                        
                        
                        function findSmallestNumber(str) {
                        var numbers = str.match(/-?\d+(\.\d+)?/g); // получаем все числа из строки
                        var smallest = Math.min.apply(Math, numbers); // находим минимальное число
                        return smallest;
                        }
                        var str = VAR_SAVED_ATTRIBUTE
                        VAR_MIN_NUMBERS_TASK = findSmallestNumber(str);
                        

                        
                        
                        _set_if_expression("W1tNSU5fTlVNQkVSU19UQVNLXV0gPT0gMQ==");
                        _if(VAR_MIN_NUMBERS_TASK == 1,function(){
                        
                           
                           
                           VAR_ELEMENT_SELECTOR = VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e a[id*=\u0027Frame_children_arrowLeft\u0027]"
                           

                           
                           
                           _SELECTOR = VAR_ELEMENT_SELECTOR;
                           get_element_selector(_SELECTOR, false).script("(function(){var rect = self.getBoundingClientRect();return (rect.left + positionx).toString() + '|' + (rect.top + positiony).toString() + '|' + (rect.right - rect.left).toString() + '|' + (rect.bottom - rect.top).toString()})();")!
                           var split = _result().split("|");
                           var x = parseInt(split[0]), y = parseInt(split[1]), w = parseInt(split[2]), h = parseInt(split[3]);
                           /// Первый квадрат
                           VAR_DIRECT_BUTTON_X = parseInt(x)
                           VAR_DIRECT_BUTTON_Y = parseInt(y) + VAR_SCROLL_Y;
                           VAR_DIRECT_WIDTH = parseInt(w)
                           VAR_DIRECT_HEIGHT = parseInt(h)
                           ////Высчитаем центр стрелочки
                           VAR_DIRECT_BUTTON_X = VAR_DIRECT_BUTTON_X + VAR_DIRECT_WIDTH/2;
                           VAR_DIRECT_BUTTON_Y = VAR_DIRECT_BUTTON_Y + VAR_DIRECT_HEIGHT/2;
                           

                           
                           
                           _do(function(){
                           _set_action_info({ name: "For" });
                           VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
                           if(VAR_CYCLE_INDEX > parseInt(10))_break();
                           
                              
                              
                              _set_if_expression("W1tTQVZFRF9DT05URU5UXV0gPT0gNg==");
                              _if(VAR_SAVED_CONTENT == 6,function(){
                              
                                 
                                 
                                 VAR_SAVED_CONTENT = "1"
                                 

                                 
                                 
                                 _break("function")
                                 

                              })!
                              

                              
                              
                              _set_if_expression("W1tTQVZFRF9DT05URU5UXV0gPT0gNQ==");
                              _if(VAR_SAVED_CONTENT == 5,function(){
                              
                                 
                                 
                                 VAR_SAVED_CONTENT = "2"
                                 

                                 
                                 
                                 _break("function")
                                 

                              })!
                              

                              
                              
                              _set_if_expression("W1tTQVZFRF9DT05URU5UXV0gPT0gNA==");
                              _if(VAR_SAVED_CONTENT == 4,function(){
                              
                                 
                                 
                                 VAR_SAVED_CONTENT = "3"
                                 

                                 
                                 
                                 _break("function")
                                 

                              })!
                              

                              
                              
                              _set_if_expression("W1tTQVZFRF9DT05URU5UXV0gPT0gMw==");
                              _if(VAR_SAVED_CONTENT == 3,function(){
                              
                                 
                                 
                                 VAR_SAVED_CONTENT = "4"
                                 

                                 
                                 
                                 _break("function")
                                 

                              })!
                              

                              
                              
                              _set_if_expression("W1tTQVZFRF9DT05URU5UXV0gPT0gMg==");
                              _if(VAR_SAVED_CONTENT == 2,function(){
                              
                                 
                                 
                                 VAR_SAVED_CONTENT = "5"
                                 

                                 
                                 
                                 _break("function")
                                 

                              })!
                              

                              
                              
                              sleep(300)!
                              

                           })!
                           

                           
                           
                           _do(function(){
                           _set_action_info({ name: "For" });
                           VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
                           if(VAR_CYCLE_INDEX > parseInt(VAR_SAVED_CONTENT))_break();
                           
                              
                              
                              /*Browser*/
                              move(VAR_DIRECT_BUTTON_X + rand (3,3),VAR_DIRECT_BUTTON_Y + rand (3,3),  {} )!
                              mouse(VAR_DIRECT_BUTTON_X + rand (3,3),VAR_DIRECT_BUTTON_Y + rand (3,3))!
                              

                              
                              
                              _cycle_params().if_else = rand (1,10) > 5;
                              _set_if_expression("cmFuZCAoMSwxMCkgPiA1");
                              _if(_cycle_params().if_else,function(){
                              
                                 
                                 
                                 sleep(rand(100,200))!
                                 

                              })!
                              

                              
                              
                              _if(!_cycle_params().if_else,function(){
                              
                                 
                                 
                                 sleep(rand(400,800))!
                                 

                              })!
                              delete _cycle_params().if_else;
                              

                              
                              
                              _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gMjA=");
                              _if(VAR_CYCLE_INDEX > 20,function(){
                              
                                 
                                 
                                 _break("function")
                                 

                              })!
                              

                           })!
                           

                           
                           
                           VAR_GET_ALL_COORDINATES = "0"
                           

                        })!
                        

                     })!
                     

                  })!
                  

                  
                  
                  VAR_ERROR_TASK = 0
                  

                  
                  
                  VAR_CURRENT_TASK_NUMBERS = parseInt(VAR_CURRENT_TASK_NUMBERS) + parseInt(-1)
                  

                  
                  
                  sleep(200)!
                  

                  
                  
                  _set_if_expression("W1tGVU5DQVBUQ0hBX1RZUEVdXSA9PSAiR2FtZV9JdGVtIiAmJiBbW0NVUlJFTlRfVEFTS19OVU1CRVJTXV0gIT0w");
                  _if(VAR_FUNCAPTCHA_TYPE == "Game_Item" && VAR_CURRENT_TASK_NUMBERS !=0,function(){
                  
                     
                     
                     /*Browser*/
                     _SELECTOR = VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e #game_challengeItem_image";waiter_timeout_next(20000)
                     wait_element(_SELECTOR)!
                     

                  })!
                  

                  
                  
                  _set_if_expression("W1tGVU5DQVBUQ0hBX1RZUEVdXSA9PSAiR2FtZV9UaWxlIiAmJiBbW0NVUlJFTlRfVEFTS19OVU1CRVJTXV0gIT0w");
                  _if(VAR_FUNCAPTCHA_TYPE == "Game_Tile" && VAR_CURRENT_TASK_NUMBERS !=0,function(){
                  
                     
                     
                     /*Browser*/
                     _SELECTOR = VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e div[class*=\u0027tile-game box screen\u0027]";waiter_timeout_next(20000)
                     wait_element(_SELECTOR)!
                     

                  })!
                  

                  
                  
                  _set_if_expression("W1tGVU5DQVBUQ0hBX1RZUEVdXSA9PSAiR2FtZV9IZWFkZXIiICYmIFtbQ1VSUkVOVF9UQVNLX05VTUJFUlNdXSAhPTA=");
                  _if(VAR_FUNCAPTCHA_TYPE == "Game_Header" && VAR_CURRENT_TASK_NUMBERS !=0,function(){
                  
                     
                     
                     /*Browser*/
                     _SELECTOR = VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e img[id*=\u0027challenge-image\u0027]";waiter_timeout_next(20000)
                     wait_element(_SELECTOR)!
                     

                  })!
                  

                  
                  
                  _set_if_expression("W1tGVU5DQVBUQ0hBX1RZUEVdXSA9PSAiR2FtZV9Cb3gi");
                  _if(VAR_FUNCAPTCHA_TYPE == "Game_Box",function(){
                  
                     
                     
                     _do(function(){
                     _set_action_info({ name: "For" });
                     VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
                     if(VAR_CYCLE_INDEX > parseInt(60))_break();
                     
                        
                        
                        /*Browser*/
                        ;_SELECTOR=VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e div[class*=\u0027match-game box screen\u0027] \u003eCSS\u003e button";
                        get_element_selector(_SELECTOR, false).nowait().exist()!
                        VAR_IS_EXISTS = _result() == 1
                        _if(VAR_IS_EXISTS, function(){
                        get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
                        VAR_IS_EXISTS = _result().indexOf("true")>=0
                        })!
                        

                        
                        
                        _set_if_expression("W1tJU19FWElTVFNdXQ==");
                        _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
                        
                           
                           
                           /*Browser*/
                           _SELECTOR = VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e div[class*=\u0027match-game box screen\u0027] \u003eCSS\u003e button";
                           wait_element_visible(_SELECTOR)!
                           _call(_random_point, {})!
                           _if(_result().length > 0, function(){
                           move( {} )!
                           get_element_selector(_SELECTOR, false).clarify(X,Y)!
                           _call(_clarify, {} )!
                           mouse(X,Y)!
                           })!
                           

                           
                           
                           _break("function")
                           

                        })!
                        

                        
                        
                        sleep(100)!
                        

                     })!
                     

                     
                     
                     _set_if_expression("W1tDVVJSRU5UX1RBU0tfTlVNQkVSU11dICE9IDA=");
                     _if(VAR_CURRENT_TASK_NUMBERS != 0,function(){
                     
                        
                        
                        /*Browser*/
                        _SELECTOR = VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e div[class*=\u0027match-game box screen\u0027]";waiter_timeout_next(20000)
                        wait_element(_SELECTOR)!
                        

                     })!
                     

                  })!
                  

                  
                  
                  _set_if_expression("W1tGVU5DQVBUQ0hBX1RZUEVdXSA9PSAiR2FtZV9DaGlsZHJlbiI=");
                  _if(VAR_FUNCAPTCHA_TYPE == "Game_Children",function(){
                  
                     
                     
                     _do(function(){
                     _set_action_info({ name: "For" });
                     VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
                     if(VAR_CYCLE_INDEX > parseInt(60))_break();
                     
                        
                        
                        /*Browser*/
                        ;_SELECTOR=VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e div[id*=\u0027game_children_buttonContainer\u0027]";
                        get_element_selector(_SELECTOR, false).nowait().exist()!
                        VAR_IS_EXISTS = _result() == 1
                        _if(VAR_IS_EXISTS, function(){
                        get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
                        VAR_IS_EXISTS = _result().indexOf("true")>=0
                        })!
                        

                        
                        
                        _set_if_expression("W1tJU19FWElTVFNdXQ==");
                        _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
                        
                           
                           
                           /*Browser*/
                           _SELECTOR = VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e div[id*=\u0027game_children_buttonContainer\u0027]";
                           wait_element_visible(_SELECTOR)!
                           _call(_random_point, {})!
                           _if(_result().length > 0, function(){
                           move( {} )!
                           get_element_selector(_SELECTOR, false).clarify(X,Y)!
                           _call(_clarify, {} )!
                           mouse(X,Y)!
                           })!
                           

                           
                           
                           _break("function")
                           

                        })!
                        

                        
                        
                        sleep(100)!
                        

                     })!
                     

                     
                     
                     _set_if_expression("W1tDVVJSRU5UX1RBU0tfTlVNQkVSU11dICE9IDA=");
                     _if(VAR_CURRENT_TASK_NUMBERS != 0,function(){
                     
                        
                        
                        /*Browser*/
                        _SELECTOR = VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e img[id*=\u0027children_challengeImage\u0027]";waiter_timeout_next(20000)
                        wait_element(_SELECTOR)!
                        

                     })!
                     

                  })!
                  

                  
                  
                  _set_if_expression("W1tDVVJSRU5UX1RBU0tfTlVNQkVSU11dIDwgMQ==");
                  _if(VAR_CURRENT_TASK_NUMBERS < 1,function(){
                  
                     
                     
                     _cycle_params().if_else = VAR_IS_MOBILE === false;
                     _set_if_expression("W1tJU19NT0JJTEVdXSA9PT0gZmFsc2U=");
                     _if(_cycle_params().if_else,function(){
                     
                        
                        
                        sleep(rand(1000,2000))!
                        

                        
                        
                        _get_browser_screen_settings()!
                        ;(function(){
                        var result = JSON.parse(_result())
                        VAR_SCROLL_X = result["ScrollX"]
                        VAR_SCROLL_Y = result["ScrollY"]
                        VAR_CURSOR_X = result["CursorX"]
                        VAR_CURSOR_Y = result["CursorY"]
                        VAR_BROWSER_WIDTH = result["Width"]
                        VAR_BROWSER_HEIGHT = result["Height"]
                        })();
                        

                        
                        
                        var scroll_x=parseInt(VAR_CURSOR_Y);
                        var scroll_y=parseInt(VAR_SCROLL_Y);
                        var browser_h=parseInt(VAR_BROWSER_HEIGHT);
                        //-------------------- Привели все в числа, считаем позицию ---------------------
                        var absolut_y = VAR_CURSOR_Y + VAR_SCROLL_Y;
                        var y_without_scroll = absolut_y - VAR_SCROLL_Y;
                        var check_y_top = VAR_BROWSER_HEIGHT/12;
                        var check_y_down = VAR_BROWSER_HEIGHT/100*92;
                        var move_y_top = VAR_BROWSER_HEIGHT/10;
                        var move_y_down = VAR_BROWSER_HEIGHT/100*80;
                        // -------------------------- Округляем ----------------------------------
                        VAR_CHECK_Y_TOP = check_y_top.toFixed();
                        VAR_CHECK_Y_DOWN = check_y_down.toFixed();
                        VAR_Y_WITHOUNT_SCROLL = y_without_scroll.toFixed();
                        VAR_MOVE_Y_TOP = move_y_top.toFixed();
                        VAR_MOVE_Y_DOWN = move_y_down.toFixed();
                        // ----------------- Снова приводим к числу ------------------------
                        VAR_CHECK_Y_TOP=parseInt(VAR_CHECK_Y_TOP);
                        VAR_CHECK_Y_DOWN=parseInt(VAR_CHECK_Y_DOWN);
                        VAR_Y_WITHOUNT_SCROLL=parseInt(VAR_Y_WITHOUNT_SCROLL);
                        VAR_MOVE_Y_TOP=parseInt(VAR_MOVE_Y_TOP);
                        VAR_MOVE_Y_DOWN=parseInt(VAR_MOVE_Y_DOWN);
                        

                        
                        
                        /*Browser*/
                        move(rand(VAR_BROWSER_WIDTH/5,VAR_BROWSER_WIDTH/1.3),rand(VAR_MOVE_Y_TOP + VAR_SCROLL_Y,VAR_MOVE_Y_DOWN + VAR_SCROLL_Y),  {} )!
                        

                     })!
                     

                     
                     
                     _if(!_cycle_params().if_else,function(){
                     
                        
                        
                        sleep(2000)!
                        

                     })!
                     delete _cycle_params().if_else;
                     

                  })!
                  

                  
                  
                  var pattern_reg = /^\D*(\d)/;
                  var match_many_me = VAR_RESULT_SELECTOR.match(pattern_reg);
                  var result_number = parseInt(match_many_me ? match_many_me[1] : null);
                  var char_result = parseInt(VAR_RESULT_SELECTOR.charAt(VAR_RESULT_SELECTOR.length-2));
                  if (result_number + char_result != 1 + 1 + 1 && result_number + char_result != 11) VAR_RESULT_SELECTOR = 10-7-2;
                  

                  
                  
                  _break("function")
                  

               })!
               

               
               
               _if(!_cycle_params().if_else,function(){
               
                  
                  
                  sleep(1000)!
                  

                  
                  
                  VAR_ERROR_CAPTCHA_UNSOLVABLE_MODULE = parseInt(VAR_ERROR_CAPTCHA_UNSOLVABLE_MODULE) + parseInt(1)
                  

                  
                  
                  _break("function")
                  

               })!
               delete _cycle_params().if_else;
               

            })!
            

            
            
            _next("function")
            

         },null)!
         

         
         
         _set_if_expression("W1tXQVNfRVJST1JdXQ==");
         _if(typeof(VAR_WAS_ERROR) !== "undefined" ? (VAR_WAS_ERROR) : undefined,function(){
         
            
            
            sleep(1000)!
            

            
            
            _next("function")
            

         })!
         

      })!
      

   }
   

function CaptchaImageClick_HCaptcha()
   {
   
      
      
      VAR_GLOBAL_SELECTOR = _function_argument("SELECTOR")
      

      
      
      VAR_SPEED_MOUSE = _function_argument("SPEED_MOUSE")
      

      
      
      VAR_KEY_MODULE = _function_argument("KEY")
      

      
      
      VAR_METHOD_MODULE = _function_argument("METHOD")
      

      
      
      VAR_TRY_NUMBER = _function_argument("TRY_NUMBER")
      

      
      
      VAR_NUMBER_CAPTCHA_MODULE = _function_argument("NUMBER_CAPTCHA")
      

      
      
      VAR_IS_INVISIBLE_CAPTCHA = _function_argument("IS_INVISIBLE_CAPTCHA")
      

      
      
      VAR_CACHE_DELETE = _function_argument("CACHE_DELETE")
      

      
      
      VAR_CYCLE_INDEX = 0
      

      
      
      VAR_UNKNOWN_CAPTCHA = 0
      

      
      
      VAR_ERROR_LOAD = "0"
      

      
      
      VAR_ERROR_GET_TASK = "0"
      

      
      
      VAR_IS_CHANGED_HCAPTHA = false
      

      
      
      VAR_HCAPTCHA_CLOSED = 0
      

      
      
      VAR_ERROR_FIND_MAIN_SELECTOR = "0"
      

      
      
      VAR_HCAPTCHA_INVISIBLE = 0
      

      
      
      VAR_RESULT_SELECTOR = 0
      

      
      
      VAR_NUMBER_CRUMB = "0"
      

      
      
      VAR_NOTIFY_ERROR_EXISTS = "0"
      

      
      
      VAR_ERROR_CAPTCHA_UNSOLVABLE_MODULE = 0
      

      
      
      VAR_HCAPTCHA_PREFIX_SECOND_FRAME = ""
      

      
      
      VAR_RECAPTCHA_MODULE_ENABLED = 0
      

      
      
      VAR_HCAPTCHA_MODULE_ENABLED = 0
      

      
      
      VAR_FUNCAPTCHA_MODULE_ENABLED = 0
      

      
      
      VAR_ALREADY_SCROLLED_INTO_RELOAD = 0
      

      
      
      VAR_ALREADY_SCROLLED_INTO_SQUARE = 0
      

      
      
      VAR_NAME_MODULE_AUTOSUBMIT = "NaN"
      

      
      
      VAR_BAS_MODULE_VERSION = "5.6"
      

      
      
      _call(function()
      {
      _on_fail(function(){
      VAR_LAST_ERROR = _result()
      VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
      VAR_WAS_ERROR = false
      _break(1,true)
      })
      CYCLES.Current().RemoveLabel("function")
      
         
         
         VAR_SELECTOR_1 = "Y2FwbW9uc3Rlcg=="
         

         
         
         VAR_SELECTOR_2 = "c2VydmVydXJs"
         

      },null)!
      

      
      
      _set_if_expression("W1tXQVNfRVJST1JdXQ==");
      _if(typeof(VAR_WAS_ERROR) !== "undefined" ? (VAR_WAS_ERROR) : undefined,function(){
      
         
         
         _function_return("")
         

      })!
      

      
      
      _call(function()
      {
      _on_fail(function(){
      VAR_LAST_ERROR = _result()
      VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
      VAR_WAS_ERROR = false
      _break(1,true)
      })
      CYCLES.Current().RemoveLabel("function")
      
         
         
         //// Проверить установлены ли модули с автосабмитом.
         if (typeof NumbersParseRecaptcha2 === 'function') VAR_RECAPTCHA_MODULE_ENABLED = 1, VAR_NAME_MODULE_AUTOSUBMIT = "ReCaptcha 2 Autosubmit";
         if (typeof BASCaptchaSolver.helpers.HCaptchaHelper === 'function') VAR_HCAPTCHA_MODULE_ENABLED = 1, VAR_NAME_MODULE_AUTOSUBMIT = "hCaptcha Autosubmit";
         if (typeof BASCaptchaSolver.helpers.FunCaptchaHelper === 'function') VAR_FUNCAPTCHA_MODULE_ENABLED = 1, VAR_NAME_MODULE_AUTOSUBMIT = "FunCaptcha Autosubmit";
         

      },null)!
      

      
      
      _set_if_expression("W1tXQVNfRVJST1JdXQ==");
      _if(typeof(VAR_WAS_ERROR) !== "undefined" ? (VAR_WAS_ERROR) : undefined,function(){
      
         
         
         _function_return("")
         

      })!
      

      
      
      _set_if_expression("W1tGVU5DQVBUQ0hBX01PRFVMRV9FTkFCTEVEXV0gPT0gMSB8fCBbW1JFQ0FQVENIQV9NT0RVTEVfRU5BQkxFRF1dID09IDEgfHwgW1tIQ0FQVENIQV9NT0RVTEVfRU5BQkxFRF1dID09IDE=");
      _if(VAR_FUNCAPTCHA_MODULE_ENABLED == 1 || VAR_RECAPTCHA_MODULE_ENABLED == 1 || VAR_HCAPTCHA_MODULE_ENABLED == 1,function(){
      
         
         
         fail((_K==="en" ? "Solve the captcha failed, to continue solving captchas by clicks requires to disable module " +VAR_NAME_MODULE_AUTOSUBMIT + " and also remove all actions from the script associated with it and retry solve captcha again" : "Решить капчу не удалось, для продолжения решения капчи кликами требуется отключить сторонний встроенный модуль в BAS: " +VAR_NAME_MODULE_AUTOSUBMIT + ", а также удалить все действия из шаблона связанные с ним и повторить попытку"));
         

      })!
      

      
      
      VAR_GREEN_TICK = false
      

      
      
      /*Browser*/
      cache_allow("*hcaptcha.com/getcaptcha*")!
      

      
      
      /*Browser*/
      cache_allow("*imgs.hcaptcha.com/*")!
      

      
      
      _set_if_expression("W1tJU19JTlZJU0lCTEVfQ0FQVENIQV1d");
      _if(typeof(VAR_IS_INVISIBLE_CAPTCHA) !== "undefined" ? (VAR_IS_INVISIBLE_CAPTCHA) : undefined,function(){
      
         
         
         /*Browser*/
         waiter_timeout_next(45000)
         wait_load("*imgs.hcaptcha.com/*")!
         

         
         
         /*Browser*/
         wait_load("*hcaptcha.com/getcaptcha*")!
         

      })!
      

      
      
      _call(function()
      {
      _on_fail(function(){
      VAR_LAST_ERROR = _result()
      VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
      VAR_WAS_ERROR = false
      _break(1,true)
      })
      CYCLES.Current().RemoveLabel("function")
      
         
         
         if (VAR_SPEED_MOUSE == "Slow")
         {
         VAR_SPEED = 100;
         VAR_GRAVITY = 6;
         VAR_DEVIATION = 2.5;
         }
         if (VAR_SPEED_MOUSE == "Normal")
         {
         VAR_SPEED = 200;
         VAR_GRAVITY = 12;
         VAR_DEVIATION = 5;
         }
         if (VAR_SPEED_MOUSE == "Fast")
         {
         VAR_SPEED = 300;
         VAR_GRAVITY = 18;
         VAR_DEVIATION = 7.5;
         }
         if (VAR_SPEED_MOUSE == "Very Fast")
         {
         VAR_SPEED = 400;
         VAR_GRAVITY = 24;
         VAR_DEVIATION = 10;
         }
         if (VAR_SPEED_MOUSE == "Extreme")
         {
         VAR_SPEED = 500;
         VAR_GRAVITY = 30;
         VAR_DEVIATION = 12.5;
         }
         VAR_IS_MOBILE = _IS_MOBILE;
         

         
         
         _set_if_expression("W1tJU19NT0JJTEVdXSA9PSBmYWxzZSAmJiByYW5kICgxLDEwKSA+IDM=");
         _if(VAR_IS_MOBILE == false && rand (1,10) > 3,function(){
         
            
            
            _do(function(){
            _set_action_info({ name: "While" });
            VAR_CYCLE_INDEX = _iterator() - 1
            BREAK_CONDITION = VAR_CYCLE_INDEX < 2;
            if(!BREAK_CONDITION)_break();
            
               
               
               _get_browser_screen_settings()!
               ;(function(){
               var result = JSON.parse(_result())
               VAR_SCROLL_X = result["ScrollX"]
               VAR_SCROLL_Y = result["ScrollY"]
               VAR_CURSOR_X = result["CursorX"]
               VAR_CURSOR_Y = result["CursorY"]
               VAR_BROWSER_WIDTH = result["Width"]
               VAR_BROWSER_HEIGHT = result["Height"]
               })();
               

               
               
               var scroll_x=parseInt(VAR_CURSOR_Y);
               var scroll_y=parseInt(VAR_SCROLL_Y);
               var browser_h=parseInt(VAR_BROWSER_HEIGHT);
               //-------------------- Привели все в числа, считаем позицию ---------------------
               var absolut_y = VAR_CURSOR_Y + VAR_SCROLL_Y;
               var y_without_scroll = absolut_y - VAR_SCROLL_Y;
               var check_y_top = VAR_BROWSER_HEIGHT/12;
               var check_y_down = VAR_BROWSER_HEIGHT/100*92;
               var move_y_top = VAR_BROWSER_HEIGHT/10;
               var move_y_down = VAR_BROWSER_HEIGHT/100*80;
               // -------------------------- Округляем ----------------------------------
               VAR_CHECK_Y_TOP = check_y_top.toFixed();
               VAR_CHECK_Y_DOWN = check_y_down.toFixed();
               VAR_Y_WITHOUNT_SCROLL = y_without_scroll.toFixed();
               VAR_MOVE_Y_TOP = move_y_top.toFixed();
               VAR_MOVE_Y_DOWN = move_y_down.toFixed();
               // ----------------- Снова приводим к числу ------------------------
               VAR_CHECK_Y_TOP=parseInt(VAR_CHECK_Y_TOP);
               VAR_CHECK_Y_DOWN=parseInt(VAR_CHECK_Y_DOWN);
               VAR_Y_WITHOUNT_SCROLL=parseInt(VAR_Y_WITHOUNT_SCROLL);
               VAR_MOVE_Y_TOP=parseInt(VAR_MOVE_Y_TOP);
               VAR_MOVE_Y_DOWN=parseInt(VAR_MOVE_Y_DOWN);
               

               
               
               /*Browser*/
               move(rand(VAR_BROWSER_WIDTH/5,VAR_BROWSER_WIDTH/1.3),rand(VAR_MOVE_Y_TOP + VAR_SCROLL_Y,VAR_MOVE_Y_DOWN + VAR_SCROLL_Y),  {} )!
               

               
               
               _set_if_expression("cmFuZCAoMSwxMCkgPiA1");
               _if(rand (1,10) > 5,function(){
               
                  
                  
                  _break("function")
                  

               })!
               

            })!
            

         })!
         

         
         
         VAR_HCAPTCHA_PREFIX = VAR_GLOBAL_SELECTOR;
         VAR_HCAPTCHA_PREFIX_FIRST_FRAME = VAR_HCAPTCHA_PREFIX;
         {
         var index = VAR_HCAPTCHA_PREFIX.toString().lastIndexOf(">FRAME>")
         if(index >= 0)
         VAR_HCAPTCHA_PREFIX = VAR_HCAPTCHA_PREFIX.substring(0,index)
         VAR_HCAPTCHA_PREFIX_FIRST_FRAME = VAR_HCAPTCHA_PREFIX
         index = VAR_HCAPTCHA_PREFIX.toString().lastIndexOf(">FRAME>")
         if(index >= 0)
         VAR_HCAPTCHA_PREFIX = VAR_HCAPTCHA_PREFIX.substring(0,index + ">FRAME>".length)
         else
         VAR_HCAPTCHA_PREFIX = ""
         }
         

         
         
         //////// Проверить открылось ли окно капчи (Invisible HCAPTCHA случай)
         _SELECTOR = VAR_HCAPTCHA_PREFIX_FIRST_FRAME;
         get_element_selector(_SELECTOR).script("(function(){var el = Array.prototype.slice.call(document.getElementsByTagName('iframe')).find(function(el){return(el.src.indexOf('/static/hcaptcha.html#frame=challenge')>=0 && getComputedStyle(el)['visibility'] == 'visible')});if(el){el=el['title']}else{el=''};return el;})()")!
         if(_result().length>0)
         {
         VAR_HCAPTCHA_PREFIX_SECOND_FRAME = VAR_HCAPTCHA_PREFIX + ">CSS>iframe[title=\"" + _result() + "\"]" + ">AT>" + VAR_NUMBER_CAPTCHA_MODULE + ">FRAME> >CSS> body";
         VAR_HCAPTCHA_PREFIX_SECOND_FRAME_ELEMENT = VAR_HCAPTCHA_PREFIX + ">CSS>iframe[title=\"" + _result() + "\"]" + ">AT>" + VAR_NUMBER_CAPTCHA_MODULE
         }
         

         
         
         _cycle_params().if_else = VAR_HCAPTCHA_PREFIX_SECOND_FRAME == "";
         _set_if_expression("W1tIQ0FQVENIQV9QUkVGSVhfU0VDT05EX0ZSQU1FXV0gPT0gIiI=");
         _if(_cycle_params().if_else,function(){
         
            
            
            _do(function(){
            _set_action_info({ name: "For" });
            VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
            if(VAR_CYCLE_INDEX > parseInt(51))_break();
            
               
               
               /*Browser*/
               ;_SELECTOR=VAR_GLOBAL_SELECTOR;
               get_element_selector(_SELECTOR, false).nowait().exist()!
               VAR_IS_EXISTS = _result() == 1
               _if(VAR_IS_EXISTS, function(){
               get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
               VAR_IS_EXISTS = _result().indexOf("true")>=0
               })!
               

               
               
               _cycle_params().if_else = typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined;
               _set_if_expression("W1tJU19FWElTVFNdXQ==");
               _if(_cycle_params().if_else,function(){
               
                  
                  
                  _cycle_params().if_else = VAR_GLOBAL_SELECTOR == ">CSS> iframe[src*='checkbox']>FRAME> >CSS> #checkbox";
                  _set_if_expression("W1tHTE9CQUxfU0VMRUNUT1JdXSA9PSAiPkNTUz4gaWZyYW1lW3NyYyo9J2NoZWNrYm94J10+RlJBTUU+ID5DU1M+ICNjaGVja2JveCI=");
                  _if(_cycle_params().if_else,function(){
                  
                     
                     
                     VAR_RANDOM_NUMBER_CLICK = Math.floor(Math.random() * (parseInt(12) - parseInt(1) + 1)) + parseInt(1)
                     

                     
                     
                     _set_if_expression("W1tSQU5ET01fTlVNQkVSX0NMSUNLXV0gPD0gNA==");
                     _if(VAR_RANDOM_NUMBER_CLICK <= 4,function(){
                     
                        
                        
                        /*Browser*/
                        _SELECTOR = VAR_GLOBAL_SELECTOR;waiter_timeout_next(8000)
                        wait_element_visible(_SELECTOR)!
                        _call(_random_point, {})!
                        _if(_result().length > 0, function(){
                        move( {} )!
                        get_element_selector(_SELECTOR, false).clarify(X,Y)!
                        _call(_clarify, {} )!
                        mouse(X,Y)!
                        })!
                        

                     })!
                     

                     
                     
                     _set_if_expression("W1tSQU5ET01fTlVNQkVSX0NMSUNLXV0gPiA0ICYmIFtbUkFORE9NX05VTUJFUl9DTElDS11dIDw9IDc=");
                     _if(VAR_RANDOM_NUMBER_CLICK > 4 && VAR_RANDOM_NUMBER_CLICK <= 7,function(){
                     
                        
                        
                        /*Browser*/
                        _SELECTOR = "\u003eCSS\u003e iframe[src*=\u0027checkbox\u0027]\u003eFRAME\u003e \u003eCSS\u003e div.label-container \u003e label-td";waiter_timeout_next(8000)
                        wait_element_visible(_SELECTOR)!
                        _call(_random_point, {})!
                        _if(_result().length > 0, function(){
                        move( {} )!
                        get_element_selector(_SELECTOR, false).clarify(X,Y)!
                        _call(_clarify, {} )!
                        mouse(X,Y)!
                        })!
                        

                     })!
                     

                     
                     
                     _set_if_expression("W1tSQU5ET01fTlVNQkVSX0NMSUNLXV0gPiA3");
                     _if(VAR_RANDOM_NUMBER_CLICK > 7,function(){
                     
                        
                        
                        /*Browser*/
                        _SELECTOR = "\u003eCSS\u003e iframe[src*=\u0027checkbox\u0027]\u003eFRAME\u003e \u003eCSS\u003e div.label-container \u003e label-td";waiter_timeout_next(8000)
                        wait_element_visible(_SELECTOR)!
                        _call(_random_point, {})!
                        _if(_result().length > 0, function(){
                        move( {} )!
                        get_element_selector(_SELECTOR, false).clarify(X,Y)!
                        _call(_clarify, {} )!
                        mouse(X,Y)!
                        })!
                        

                     })!
                     

                  })!
                  

                  
                  
                  _if(!_cycle_params().if_else,function(){
                  
                     
                     
                     /*Browser*/
                     _SELECTOR = VAR_GLOBAL_SELECTOR;waiter_timeout_next(8000)
                     wait_element_visible(_SELECTOR)!
                     _call(_random_point, {})!
                     _if(_result().length > 0, function(){
                     move( {} )!
                     get_element_selector(_SELECTOR, false).clarify(X,Y)!
                     _call(_clarify, {} )!
                     mouse(X,Y)!
                     })!
                     

                  })!
                  delete _cycle_params().if_else;
                  

                  
                  
                  _break("function")
                  

               })!
               

               
               
               _if(!_cycle_params().if_else,function(){
               
                  
                  
                  sleep(rand(500,1000))!
                  

               })!
               delete _cycle_params().if_else;
               

               
               
               _set_if_expression("IVtbSVNfRVhJU1RTXV0=");
               _if(!VAR_IS_EXISTS,function(){
               
                  
                  
                  _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gcmFuZCAoNDIsNDkp");
                  _if(VAR_CYCLE_INDEX > rand (42,49),function(){
                  
                     
                     
                     VAR_ERROR_FIND_MAIN_SELECTOR = "1"
                     

                  })!
                  

               })!
               

            })!
            

         })!
         

         
         
         _if(!_cycle_params().if_else,function(){
         
            
            
            VAR_HCAPTCHA_INVISIBLE = 1
            

         })!
         delete _cycle_params().if_else;
         

      },null)!
      

      
      
      _set_if_expression("W1tXQVNfRVJST1JdXQ==");
      _if(typeof(VAR_WAS_ERROR) !== "undefined" ? (VAR_WAS_ERROR) : undefined,function(){
      
         
         
         fail(VAR_LAST_ERROR)
         

      })!
      

      
      
      _set_if_expression("W1tFUlJPUl9GSU5EX01BSU5fU0VMRUNUT1JdXSA9PSAx");
      _if(VAR_ERROR_FIND_MAIN_SELECTOR == 1,function(){
      
         
         
         fail((_K==="en" ? "Could not wait for the main hCaptcha selector to load with the 'I am human' button" : "Не удалось дождаться загрузки основного селектора hCaptcha c кнопкой 'Я человек'"));
         

      })!
      

      
      
      VAR_TRY_CAPTCHA = "0"
      

      
      
      VAR_HCAPTCHA_CLOSED = "0"
      

      
      
      VAR_CAPTCHA_FAIL = "0"
      

      
      
      VAR_ERROR_LOAD = "0"
      

      
      
      VAR_ERROR_KEY = "0"
      

      
      
      VAR_ERROR_BALANCE = "0"
      

      
      
      VAR_ERROR_LANG = "0"
      

      
      
      VAR_GET_ALL_COORDINATES = "0"
      

      
      
      VAR_FIRST_LOAD_CAPTCHA = true
      

      
      
      VAR_FIRST_LOAD_BUTTON = true
      

      
      
      /// Селектор который передал юзер модулю приведем в нормальный вид
      get_selector_normal = function(s) {
      var e={},i,b=0,c,x,l=0,a,r='',w=String.fromCharCode,L=s.length;
      var A="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
      for(i=0;i<64;i++){e[A.charAt(i)]=i;}
      for(x=0;x<L;x++){
      c=e[s.charAt(x)];b=(b<<6)+c;l+=6;
      while(l>=8){((a=(b>>>(l-=8))&0xff)||(x<(L-2)))&&(r+=w(a));}
      }
      return r;
      };
      VAR_SELECTOR_1 = get_selector_normal(VAR_SELECTOR_1);
      VAR_SELECTOR_2 = get_selector_normal(VAR_SELECTOR_2);
      

      
      
      _do(function(){
      _set_action_info({ name: "For" });
      VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
      if(VAR_CYCLE_INDEX > parseInt(500))_break();
      
         
         
         VAR_CYCLE_INDEX = 0
         

         
         
         VAR_HCAPTCHA_CLOSED = 0
         

         
         
         VAR_ERROR_GET_TASK = "0"
         

         
         
         _set_if_expression("W1tFUlJPUl9LRVldXSA9PSAx");
         _if(VAR_ERROR_KEY == 1,function(){
         
            
            
            fail((_K==="en" ? "API secret key from captcha recognition service is wrong ERROR_WRONG_USER_KEY" : "Секретный ключ API от сервиса распознавания капчи неправильный ERROR_WRONG_USER_KEY"));
            

         })!
         

         
         
         _set_if_expression("W1tFUlJPUl9CQUxBTkNFXV0gPT0gMQ==");
         _if(VAR_ERROR_BALANCE == 1,function(){
         
            
            
            fail((_K==="en" ? "The balance on the captcha service has ended - ERROR_ZERO_BALANCE" : "Закончился баланс на сервисе распознавания капчи - ERROR_ZERO_BALANCE"));
            

         })!
         

         
         
         _set_if_expression("W1tDQVBUQ0hBX0ZBSUxdXSA+IDE=");
         _if(VAR_CAPTCHA_FAIL > 1,function(){
         
            
            
            /*Browser*/
            cache_data_clear()!
            

            
            
            fail((_K==="en" ? "Failed to solve hCaptcha, reason - " +VAR_SAVED_CONTENT : "Не удалось решить hCaptcha, причина - " +VAR_SAVED_CONTENT));
            

         })!
         

         
         
         _set_if_expression("W1tVTktOT1dOX0NBUFRDSEFdXSA+IDM=");
         _if(VAR_UNKNOWN_CAPTCHA > 3,function(){
         
            
            
            /*Browser*/
            cache_data_clear()!
            

            
            
            fail((_K==="en" ? "Failed to solve hCaptcha. This captcha type is unknown" : "Не удалось решить hCaptcha, загрузился неизвестный тип каптчи"));
            

         })!
         

         
         
         _set_if_expression("W1tFUlJPUl9DQVBUQ0hBX1VOU09MVkFCTEVfTU9EVUxFXV0gPiAx");
         _if(VAR_ERROR_CAPTCHA_UNSOLVABLE_MODULE > 1,function(){
         
            
            
            /*Browser*/
            cache_data_clear()!
            

            
            
            sleep(100)!
            

            
            
            fail((_K==="en" ? "hCaptcha task or image type is not supported service CaptchaGuru, reason: ERROR_CAPTCHA_UNSOLVABLE" : "Решить каптчу не удалось - сервис CaptchaGuru не смог распознать несколько изображений подряд, причина: ERROR_CAPTCHA_UNSOLVABLE"));
            

         })!
         

         
         
         _do(function(){
         _set_action_info({ name: "For" });
         VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
         if(VAR_CYCLE_INDEX > parseInt(300))_break();
         
            
            
            /*Browser*/
            ;_SELECTOR=VAR_HCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e #checkbox[aria-checked=\u0027true\u0027]";
            get_element_selector(_SELECTOR, false).nowait().exist()!
            VAR_IS_EXISTS = _result() == 1
            

            
            
            _set_if_expression("W1tJU19FWElTVFNdXSA9PSB0cnVlICYmIFtbUkVTVUxUX1NFTEVDVE9SXV0gIT0gMQ==");
            _if(VAR_IS_EXISTS == true && VAR_RESULT_SELECTOR != 1,function(){
            
               
               
               VAR_GREEN_TICK = true
               

               
               
               _set_if_expression("W1tDQUNIRV9ERUxFVEVdXSA9PSB0cnVl");
               _if(VAR_CACHE_DELETE == true,function(){
               
                  
                  
                  /*Browser*/
                  cache_data_clear()!
                  

               })!
               

               
               
               _break("function")
               

            })!
            

            
            
            _set_if_expression("W1tGSVJTVF9MT0FEX0NBUFRDSEFdXSA9PSBmYWxzZSAmJiByYW5kICgxLDEwKSA+IDYgJiYgIShbW01FVEhPRF9NT0RVTEVdXS5jaGFyQXQoMCkgPT09ICJDIik=");
            _if(VAR_FIRST_LOAD_CAPTCHA == false && rand (1,10) > 6 && !(VAR_METHOD_MODULE.charAt(0) === "C"),function(){
            
               
               
               VAR_GREEN_TICK = true
               

               
               
               /*Browser*/
               cache_data_clear()!
               

               
               
               _break("function")
               

            })!
            

            
            
            /*Browser*/
            ;_SELECTOR=VAR_HCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e #status[aria-hidden=\u0027false\u0027]";
            get_element_selector(_SELECTOR, false).nowait().exist()!
            VAR_IS_EXISTS = _result() == 1
            _if(VAR_IS_EXISTS, function(){
            get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
            VAR_IS_EXISTS = _result().indexOf("true")>=0
            })!
            

            
            
            _set_if_expression("W1tJU19FWElTVFNdXSA9PSB0cnVl");
            _if(VAR_IS_EXISTS == true,function(){
            
               
               
               /*Browser*/
               cache_data_clear()!
               

               
               
               fail((_K==="en" ? "Failed to solve hCaptcha. Rate limited or Network error" : "Не удалось решить hcaptcha, ваш компьютер или сеть отправили слишком много запросов"));
               

            })!
            

            
            
            _set_if_expression("W1tIQ0FQVENIQV9JTlZJU0lCTEVdXSA+IDAgJiYgW1tGSVJTVF9MT0FEX0NBUFRDSEFdXSA9PSBmYWxzZSAmJiBbW05VTUJFUl9DUlVNQl1dID09IDAgJiYgW1tSRVNVTFRfU0VMRUNUT1JdXSAhPSAx");
            _if(VAR_HCAPTCHA_INVISIBLE > 0 && VAR_FIRST_LOAD_CAPTCHA == false && VAR_NUMBER_CRUMB == 0 && VAR_RESULT_SELECTOR != 1,function(){
            
               
               
               /*Browser*/
               ;_SELECTOR=VAR_HCAPTCHA_PREFIX_SECOND_FRAME + "\u003eCSS\u003e .task-grid";
               get_element_selector(_SELECTOR, false).nowait().exist()!
               VAR_IS_EXISTS = _result() == 1
               _if(VAR_IS_EXISTS, function(){
               get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
               VAR_IS_EXISTS = _result().indexOf("true")>=0
               })!
               

               
               
               /*Browser*/
               ;_SELECTOR=VAR_HCAPTCHA_PREFIX_SECOND_FRAME + "\u003eCSS\u003e .bounding-box-example";
               get_element_selector(_SELECTOR, false).nowait().exist()!
               VAR_IS_EXISTS_2 = _result() == 1
               _if(VAR_IS_EXISTS_2, function(){
               get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
               VAR_IS_EXISTS_2 = _result().indexOf("true")>=0
               })!
               

               
               
               /*Browser*/
               ;_SELECTOR=VAR_HCAPTCHA_PREFIX_SECOND_FRAME + "\u003eCSS\u003e .task-answers";
               get_element_selector(_SELECTOR, false).nowait().exist()!
               VAR_IS_EXISTS_3 = _result() == 1
               _if(VAR_IS_EXISTS_3, function(){
               get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
               VAR_IS_EXISTS_3 = _result().indexOf("true")>=0
               })!
               

               
               
               _set_if_expression("W1tJU19FWElTVFNdXSA9PSBmYWxzZSAmJiBbW0lTX0VYSVNUU18yXV0gPT0gZmFsc2UgJiYgW1tJU19FWElTVFNfM11dID09IGZhbHNl");
               _if(VAR_IS_EXISTS == false && VAR_IS_EXISTS_2 == false && VAR_IS_EXISTS_3 == false,function(){
               
                  
                  
                  /*Browser*/
                  ;_SELECTOR=" \u003eXPATH\u003e id(\u0022talon_container_login_prod\u0022)";
                  get_element_selector(_SELECTOR, false).nowait().exist()!
                  VAR_IS_EXISTS = _result() == 1
                  _if(VAR_IS_EXISTS, function(){
                  get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
                  VAR_IS_EXISTS = _result().indexOf("true")>=0
                  })!
                  

                  
                  
                  _set_if_expression("IVtbSVNfRVhJU1RTXV0=");
                  _if(!VAR_IS_EXISTS,function(){
                  
                     
                     
                     VAR_GREEN_TICK = true
                     

                     
                     
                     _set_if_expression("W1tDQUNIRV9ERUxFVEVdXSA9PSB0cnVl");
                     _if(VAR_CACHE_DELETE == true,function(){
                     
                        
                        
                        /*Browser*/
                        cache_data_clear()!
                        

                     })!
                     

                     
                     
                     _break("function")
                     

                  })!
                  

               })!
               

            })!
            

            
            
            _set_if_expression("W1tIQ0FQVENIQV9JTlZJU0lCTEVdXSA9PSAwICYmIFtbRklSU1RfTE9BRF9DQVBUQ0hBXV0gPT0gdHJ1ZSAmJiBbW1JFU1VMVF9TRUxFQ1RPUl1dICE9IDE=");
            _if(VAR_HCAPTCHA_INVISIBLE == 0 && VAR_FIRST_LOAD_CAPTCHA == true && VAR_RESULT_SELECTOR != 1,function(){
            
               
               
               /*Browser*/
               ;_SELECTOR=" \u003eXPATH\u003e //*[@id=\u0022challenge-running\u0022][contains(text(),\u0022Checking if the site connection is secure\u0022)] ";
               get_element_selector(_SELECTOR, false).nowait().exist()!
               VAR_IS_EXISTS = _result() == 1
               

               
               
               _set_if_expression("W1tJU19FWElTVFNdXQ==");
               _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
               
                  
                  
                  VAR_NUMBER_CAPTCHA_MODULE = "1"
                  

               })!
               

            })!
            

            
            
            //////// Проверить открылось ли окно капчи
            _SELECTOR = VAR_HCAPTCHA_PREFIX_FIRST_FRAME;
            get_element_selector(_SELECTOR).script("(function(){var el = Array.prototype.slice.call(document.getElementsByTagName('iframe')).find(function(el){return(el.src.indexOf('/static/hcaptcha.html#frame=challenge')>=0 && getComputedStyle(el)['visibility'] == 'visible')});if(el){el=el['title']}else{el=''};return el;})()")!
            if(_result().length>0)
            {
            VAR_HCAPTCHA_PREFIX_SECOND_FRAME = VAR_HCAPTCHA_PREFIX + ">CSS>iframe[title=\"" + _result() + "\"]" + ">AT>" + VAR_NUMBER_CAPTCHA_MODULE + ">FRAME> >CSS> body";
            VAR_HCAPTCHA_PREFIX_SECOND_FRAME_ELEMENT = VAR_HCAPTCHA_PREFIX + ">CSS>iframe[title=\"" + _result() + "\"]" + ">AT>" + VAR_NUMBER_CAPTCHA_MODULE
            _break()
            }
            

            
            
            _set_if_expression("W1tDWUNMRV9JTkRFWF1dID09IDI0IHx8IFtbQ1lDTEVfSU5ERVhdXSA9PSA0OA==");
            _if(VAR_CYCLE_INDEX == 24 || VAR_CYCLE_INDEX == 48,function(){
            
               
               
               sleep(rand(1000,3000))!
               

            })!
            

            
            
            _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gMjggJiYgW1tIQ0FQVENIQV9JTlZJU0lCTEVdXSA9PSAwICYmIFtbRklSU1RfTE9BRF9CVVRUT05dXSA9PSB0cnVlICYmIFtbUkVTVUxUX1NFTEVDVE9SXV0gIT0gMQ==");
            _if(VAR_CYCLE_INDEX > 28 && VAR_HCAPTCHA_INVISIBLE == 0 && VAR_FIRST_LOAD_BUTTON == true && VAR_RESULT_SELECTOR != 1,function(){
            
               
               
               VAR_FIRST_LOAD_BUTTON = false
               

               
               
               /*Browser*/
               ;_SELECTOR=VAR_GLOBAL_SELECTOR;
               get_element_selector(_SELECTOR, false).nowait().exist()!
               VAR_IS_EXISTS = _result() == 1
               _if(VAR_IS_EXISTS, function(){
               get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
               VAR_IS_EXISTS = _result().indexOf("true")>=0
               })!
               

               
               
               _set_if_expression("W1tJU19FWElTVFNdXQ==");
               _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
               
                  
                  
                  /*Browser*/
                  _SELECTOR = VAR_GLOBAL_SELECTOR;waiter_timeout_next(8000)
                  wait_element_visible(_SELECTOR)!
                  _call(_random_point, {})!
                  _if(_result().length > 0, function(){
                  move( {} )!
                  get_element_selector(_SELECTOR, false).clarify(X,Y)!
                  _call(_clarify, {} )!
                  mouse(X,Y)!
                  })!
                  

                  
                  
                  sleep(rand(2000,4000))!
                  

               })!
               

            })!
            

            
            
            _set_if_expression("W1tDWUNMRV9JTkRFWF1dID49IDI1ICYmIFtbRklSU1RfTE9BRF9DQVBUQ0hBXV0gPT0gZmFsc2UgJiYgW1tSRVNVTFRfU0VMRUNUT1JdXSAhPSAx");
            _if(VAR_CYCLE_INDEX >= 25 && VAR_FIRST_LOAD_CAPTCHA == false && VAR_RESULT_SELECTOR != 1,function(){
            
               
               
               /*Browser*/
               cache_data_clear()!
               

               
               
               fail((_K==="en" ? "Failed to solve the hcaptcha. The captcha window is closed." : "Решить hcaptcha не удалось. Окно с капчей не было открыто."));
               

            })!
            

            
            
            _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gNjUgJiYgW1tGSVJTVF9MT0FEX0NBUFRDSEFdXSA9PSB0cnVlICYmIFtbUkVTVUxUX1NFTEVDVE9SXV0gIT0gMQ==");
            _if(VAR_CYCLE_INDEX > 65 && VAR_FIRST_LOAD_CAPTCHA == true && VAR_RESULT_SELECTOR != 1,function(){
            
               
               
               /*Browser*/
               cache_data_clear()!
               

               
               
               fail((_K==="en" ? "Failed to solve hCaptcha. Timeout for opening captcha window with images" : "Не удалось решить hcaptcha, слишком долгое ожидание открытия окна каптчи с изображениями"));
               

            })!
            

         })!
         

         
         
         VAR_CYCLE_INDEX = 0
         

         
         
         VAR_FIRST_LOAD_BUTTON = false
         

         
         
         _set_if_expression("W1tHUkVFTl9USUNLXV0gPT0gdHJ1ZQ==");
         _if(VAR_GREEN_TICK == true,function(){
         
            
            
            _function_return("")
            

         })!
         

         
         
         VAR_TRY_CAPTCHA = parseInt(VAR_TRY_CAPTCHA) + parseInt(1)
         

         
         
         _set_if_expression("W1tUUllfQ0FQVENIQV1dID49IFtbVFJZX05VTUJFUl1d");
         _if(VAR_TRY_CAPTCHA >= VAR_TRY_NUMBER,function(){
         
            
            
            sleep(4000)!
            

            
            
            /*Browser*/
            ;_SELECTOR=VAR_HCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e #checkbox[aria-checked=\u0027true\u0027]";
            get_element_selector(_SELECTOR, false).nowait().exist()!
            VAR_IS_EXISTS = _result() == 1
            _if(VAR_IS_EXISTS, function(){
            get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
            VAR_IS_EXISTS = _result().indexOf("true")>=0
            })!
            

            
            
            _cycle_params().if_else = VAR_IS_EXISTS == true && VAR_RESULT_SELECTOR != 1;
            _set_if_expression("W1tJU19FWElTVFNdXSA9PSB0cnVlICYmIFtbUkVTVUxUX1NFTEVDVE9SXV0gIT0gMQ==");
            _if(_cycle_params().if_else,function(){
            
               
               
               _set_if_expression("W1tDQUNIRV9ERUxFVEVdXSA9PSB0cnVl");
               _if(VAR_CACHE_DELETE == true,function(){
               
                  
                  
                  /*Browser*/
                  cache_data_clear()!
                  

               })!
               

               
               
               _function_return("")
               

            })!
            

            
            
            _if(!_cycle_params().if_else,function(){
            
               
               
               /*Browser*/
               cache_data_clear()!
               

            })!
            delete _cycle_params().if_else;
            

            
            
            fail((_K==="en" ? "Failed to solve the captcha. hCaptcha attempts limit exceeded" : "Решить капчу не удалось. Превышен лимит попыток решить hCaptcha"))
            

         })!
         

         
         
         _call(function()
         {
         _on_fail(function(){
         VAR_LAST_ERROR = _result()
         VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
         VAR_WAS_ERROR = false
         _break(1,true)
         })
         CYCLES.Current().RemoveLabel("function")
         
            
            
            _set_if_expression("W1tIQ0FQVENIQV9JTlZJU0lCTEVdXSA9PSAx");
            _if(VAR_HCAPTCHA_INVISIBLE == 1,function(){
            
               
               
               VAR_CYCLE_INDEX = 0
               

               
               
               _do(function(){
               _set_action_info({ name: "For" });
               VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
               if(VAR_CYCLE_INDEX > parseInt(60))_break();
               
                  
                  
                  /*Browser*/
                  ;_SELECTOR=VAR_HCAPTCHA_PREFIX_SECOND_FRAME + "\u003eCSS\u003e .task-grid";
                  get_element_selector(_SELECTOR, false).nowait().exist()!
                  VAR_IS_EXISTS = _result() == 1
                  _if(VAR_IS_EXISTS, function(){
                  get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
                  VAR_IS_EXISTS = _result().indexOf("true")>=0
                  })!
                  

                  
                  
                  /*Browser*/
                  ;_SELECTOR=VAR_HCAPTCHA_PREFIX_SECOND_FRAME + "\u003eCSS\u003e .bounding-box-example";
                  get_element_selector(_SELECTOR, false).nowait().exist()!
                  VAR_IS_EXISTS_2 = _result() == 1
                  _if(VAR_IS_EXISTS_2, function(){
                  get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
                  VAR_IS_EXISTS_2 = _result().indexOf("true")>=0
                  })!
                  

                  
                  
                  /*Browser*/
                  ;_SELECTOR=VAR_HCAPTCHA_PREFIX_SECOND_FRAME + "\u003eCSS\u003e .task-answers";
                  get_element_selector(_SELECTOR, false).nowait().exist()!
                  VAR_IS_EXISTS_3 = _result() == 1
                  _if(VAR_IS_EXISTS_3, function(){
                  get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
                  VAR_IS_EXISTS_3 = _result().indexOf("true")>=0
                  })!
                  

                  
                  
                  _set_if_expression("W1tJU19FWElTVFNdXSA9PSB0cnVlIHx8IFtbSVNfRVhJU1RTXzJdXSA9PSB0cnVlIHx8IFtbSVNfRVhJU1RTXzNdXSA9PSB0cnVl");
                  _if(VAR_IS_EXISTS == true || VAR_IS_EXISTS_2 == true || VAR_IS_EXISTS_3 == true,function(){
                  
                     
                     
                     _break("function")
                     

                  })!
                  

                  
                  
                  _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gNTA=");
                  _if(VAR_CYCLE_INDEX > 50,function(){
                  
                     
                     
                     VAR_ERROR_LOAD = 1
                     

                  })!
                  

                  
                  
                  sleep(rand(200,600))!
                  

               })!
               

               
               
               _set_if_expression("W1tFUlJPUl9MT0FEXV0gPT0gMQ==");
               _if(VAR_ERROR_LOAD == 1,function(){
               
                  
                  
                  _next("function")
                  

               })!
               

            })!
            

            
            
            _set_if_expression("W1tIQ0FQVENIQV9JTlZJU0lCTEVdXSA9PSAwIHx8IFtbSENBUFRDSEFfSU5WSVNJQkxFXV0gPiAx");
            _if(VAR_HCAPTCHA_INVISIBLE == 0 || VAR_HCAPTCHA_INVISIBLE > 1,function(){
            
               
               
               VAR_CYCLE_INDEX = 0
               

               
               
               /*Browser*/
               ;_SELECTOR=VAR_HCAPTCHA_PREFIX_SECOND_FRAME_ELEMENT;
               get_element_selector(_SELECTOR, false).nowait().exist()!
               VAR_IS_EXISTS = _result() == 1
               _if(VAR_IS_EXISTS, function(){
               get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
               VAR_IS_EXISTS = _result().indexOf("true")>=0
               })!
               

               
               
               _cycle_params().if_else = typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined;
               _set_if_expression("W1tJU19FWElTVFNdXQ==");
               _if(_cycle_params().if_else,function(){
               
                  
                  
                  VAR_HCAPTCHA_CLOSED = 0
                  

                  
                  
                  _do(function(){
                  _set_action_info({ name: "For" });
                  VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
                  if(VAR_CYCLE_INDEX > parseInt(20))_break();
                  
                     
                     
                     /*Browser*/
                     is_load("*imgs.hcaptcha.com/*")!
                     VAR_SAVED_IS_LOADED = _result()
                     

                     
                     
                     _set_if_expression("W1tTQVZFRF9JU19MT0FERURdXSA9PSAx");
                     _if(VAR_SAVED_IS_LOADED == 1,function(){
                     
                        
                        
                        _break("function")
                        

                     })!
                     

                     
                     
                     _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gNQ==");
                     _if(VAR_CYCLE_INDEX > 5,function(){
                     
                        
                        
                        /*Browser*/
                        ;_SELECTOR=VAR_HCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e #checkbox[aria-checked=\u0027true\u0027]";
                        get_element_selector(_SELECTOR, false).nowait().exist()!
                        VAR_IS_EXISTS = _result() == 1
                        _if(VAR_IS_EXISTS, function(){
                        get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
                        VAR_IS_EXISTS = _result().indexOf("true")>=0
                        })!
                        

                        
                        
                        _set_if_expression("W1tJU19FWElTVFNdXSA9PSB0cnVl");
                        _if(VAR_IS_EXISTS == true,function(){
                        
                           
                           
                           VAR_HCAPTCHA_CLOSED = 1
                           

                           
                           
                           _break("function")
                           

                        })!
                        

                     })!
                     

                     
                     
                     sleep(100)!
                     

                     
                     
                     _set_if_expression("W1tDWUNMRV9JTkRFWF1dID09IDE5");
                     _if(VAR_CYCLE_INDEX == 19,function(){
                     
                        
                        
                        VAR_HCAPTCHA_CLOSED = 1
                        

                        
                        
                        _break("function")
                        

                     })!
                     

                  })!
                  

               })!
               

               
               
               _if(!_cycle_params().if_else,function(){
               
                  
                  
                  VAR_HCAPTCHA_CLOSED = 1
                  

               })!
               delete _cycle_params().if_else;
               

               
               
               _set_if_expression("W1tIQ0FQVENIQV9DTE9TRURdXSA9PSAw");
               _if(VAR_HCAPTCHA_CLOSED == 0,function(){
               
                  
                  
                  _do(function(){
                  _set_action_info({ name: "For" });
                  VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
                  if(VAR_CYCLE_INDEX > parseInt(100))_break();
                  
                     
                     
                     /*Browser*/
                     ;_SELECTOR=VAR_HCAPTCHA_PREFIX_SECOND_FRAME_ELEMENT;
                     get_element_selector(_SELECTOR, false).nowait().exist()!
                     VAR_IS_EXISTS = _result() == 1
                     _if(VAR_IS_EXISTS, function(){
                     get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
                     VAR_IS_EXISTS = _result().indexOf("true")>=0
                     })!
                     

                     
                     
                     _set_if_expression("IVtbSVNfRVhJU1RTXV0=");
                     _if(!VAR_IS_EXISTS,function(){
                     
                        
                        
                        VAR_HCAPTCHA_CLOSED = 1
                        

                        
                        
                        _break("function")
                        

                     })!
                     

                     
                     
                     cache_get_base64("*imgs.hcaptcha.com/*")!
                     var image_id = native("imageprocessing", "load", _result())
                     var image_size = native("imageprocessing", "getsize", image_id)
                     var image_w = parseInt(image_size.split(",")[0])
                     var image_h = parseInt(image_size.split(",")[1])
                     if (image_h == 0 && VAR_CYCLE_INDEX > rand (45,55)) fail((_K === "en" ? "Failed to wait for hCaptcha image from request cache" : "Не удалось дождаться картинку hCaptcha из кэша запроса"))
                     if (image_h > 100) {
                     VAR_IMAGE_BASE_64_CACHE = _result()
                     _break()
                     }
                     sleep(400)!
                     

                  })!
                  

               })!
               

            })!
            

         },null)!
         

         
         
         _set_if_expression("W1tIQ0FQVENIQV9DTE9TRURdXSA9PSAx");
         _if(VAR_HCAPTCHA_CLOSED == 1,function(){
         
            
            
            sleep(rand(100,400))!
            

            
            
            _next("function")
            

         })!
         

         
         
         _set_if_expression("W1tXQVNfRVJST1JdXQ==");
         _if(typeof(VAR_WAS_ERROR) !== "undefined" ? (VAR_WAS_ERROR) : undefined,function(){
         
            
            
            sleep(1000)!
            

            
            
            /*Browser*/
            ;_SELECTOR=VAR_HCAPTCHA_PREFIX_SECOND_FRAME_ELEMENT;
            get_element_selector(_SELECTOR, false).nowait().exist()!
            VAR_IS_EXISTS = _result() == 1
            

            
            
            _set_if_expression("IVtbSVNfRVhJU1RTXV0=");
            _if(!VAR_IS_EXISTS,function(){
            
               
               
               VAR_HCAPTCHA_CLOSED = "1"
               

            })!
            

            
            
            _set_if_expression("W1tIQ0FQVENIQV9DTE9TRURdXSA9PSAw");
            _if(VAR_HCAPTCHA_CLOSED == 0,function(){
            
               
               
               _call(function()
               {
               _on_fail(function(){
               VAR_LAST_ERROR = _result()
               VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
               VAR_WAS_ERROR = false
               _break(1,true)
               })
               CYCLES.Current().RemoveLabel("function")
               
                  
                  
                  /*Browser*/
                  ;_SELECTOR=VAR_HCAPTCHA_PREFIX_SECOND_FRAME + "\u003eCSS\u003e .refresh";
                  get_element_selector(_SELECTOR, false).nowait().exist()!
                  VAR_IS_EXISTS = _result() == 1
                  _if(VAR_IS_EXISTS, function(){
                  get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
                  VAR_IS_EXISTS = _result().indexOf("true")>=0
                  })!
                  

                  
                  
                  _set_if_expression("W1tJU19FWElTVFNdXQ==");
                  _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
                  
                     
                     
                     /*Browser*/
                     cache_data_clear()!
                     

                     
                     
                     /*Browser*/
                     _SELECTOR = VAR_HCAPTCHA_PREFIX_SECOND_FRAME + "\u003eCSS\u003e .refresh";
                     wait_element_visible(_SELECTOR)!
                     _call(_random_point, {})!
                     _if(_result().length > 0, function(){
                     move( {} )!
                     get_element_selector(_SELECTOR, false).clarify(X,Y)!
                     _call(_clarify, {} )!
                     mouse(X,Y)!
                     })!
                     

                  })!
                  

               },null)!
               

            })!
            

            
            
            VAR_NUMBER_CRUMB = "0"
            

            
            
            VAR_HCAPTCHA_INVISIBLE = parseInt(VAR_HCAPTCHA_INVISIBLE) + parseInt(2)
            

            
            
            sleep(1000)!
            

            
            
            VAR_HCAPTCHA_CLOSED = "2"
            

         })!
         

         
         
         _call(function()
         {
         _on_fail(function(){
         VAR_LAST_ERROR = _result()
         VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
         VAR_WAS_ERROR = false
         _break(1,true)
         })
         CYCLES.Current().RemoveLabel("function")
         
            
            
            _set_if_expression("W1tIQ0FQVENIQV9DTE9TRURdXSA9PSAw");
            _if(VAR_HCAPTCHA_CLOSED == 0,function(){
            
               
               
               /*Browser*/
               ;_SELECTOR=VAR_HCAPTCHA_PREFIX_SECOND_FRAME_ELEMENT + " \u003eFRAME\u003e \u003eCSS\u003e div.task-grid \u003e div[tabindex=\u0027-1\u0027]";
               get_element_selector(_SELECTOR, false).nowait().exist()!
               VAR_IS_EXISTS = _result() == 1
               _if(VAR_IS_EXISTS, function(){
               get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
               VAR_IS_EXISTS = _result().indexOf("true")>=0
               })!
               

               
               
               _set_if_expression("W1tJU19FWElTVFNdXQ==");
               _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
               
                  
                  
                  VAR_HCAPTCHA_CLOSED = "2"
                  

               })!
               

            })!
            

         },null)!
         

         
         
         _set_if_expression("W1tIQ0FQVENIQV9DTE9TRURdXSA9PSAxIHx8IFtbSENBUFRDSEFfQ0xPU0VEXV0gPT0gMg==");
         _if(VAR_HCAPTCHA_CLOSED == 1 || VAR_HCAPTCHA_CLOSED == 2,function(){
         
            
            
            VAR_HCAPTCHA_CLOSED = "0"
            

            
            
            sleep(rand(100,400))!
            

            
            
            _next("function")
            

         })!
         

         
         
         _call(function()
         {
         _on_fail(function(){
         VAR_LAST_ERROR = _result()
         VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
         VAR_WAS_ERROR = false
         _break(1,true)
         })
         CYCLES.Current().RemoveLabel("function")
         
            
            
            _set_if_expression("W1tOVU1CRVJfQ1JVTUJdXSA9PSAw");
            _if(VAR_NUMBER_CRUMB == 0,function(){
            
               
               
               /*Browser*/
               ;_SELECTOR=VAR_HCAPTCHA_PREFIX_SECOND_FRAME + "\u003eCSS\u003e div[aria-label*=\u00279\u0027]";
               get_element_selector(_SELECTOR, false).nowait().exist()!
               VAR_HCAPTCHA_TYPE_1 = _result() == 1
               _if(VAR_HCAPTCHA_TYPE_1, function(){
               get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
               VAR_HCAPTCHA_TYPE_1 = _result().indexOf("true")>=0
               })!
               

               
               
               /*Browser*/
               ;_SELECTOR=VAR_HCAPTCHA_PREFIX_SECOND_FRAME + "\u003eCSS\u003e div[class*=\u0027bounding-box-example\u0027]";
               get_element_selector(_SELECTOR, false).nowait().exist()!
               VAR_HCAPTCHA_TYPE_2 = _result() == 1
               _if(VAR_HCAPTCHA_TYPE_2, function(){
               get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
               VAR_HCAPTCHA_TYPE_2 = _result().indexOf("true")>=0
               })!
               

               
               
               /*Browser*/
               ;_SELECTOR=VAR_HCAPTCHA_PREFIX_SECOND_FRAME + "\u003eCSS\u003e .task-answers";
               get_element_selector(_SELECTOR, false).nowait().exist()!
               VAR_HCAPTCHA_TYPE_3 = _result() == 1
               _if(VAR_HCAPTCHA_TYPE_3, function(){
               get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
               VAR_HCAPTCHA_TYPE_3 = _result().indexOf("true")>=0
               })!
               

               
               
               _set_if_expression("W1tIQ0FQVENIQV9UWVBFXzFdXSA9PSB0cnVlICYmIFtbSVNfQ0hBTkdFRF9IQ0FQVEhBXV0gIT0gIkhDQVBUQ0hBX1RZUEVfMSIgfHwgW1tIQ0FQVENIQV9UWVBFXzFdXSA9PSB0cnVlICYmIFtbSVNfQ0hBTkdFRF9IQ0FQVEhBXV0gIT0gIkhDQVBUQ0hBX1RZUEVfMiIgfHwgW1tIQ0FQVENIQV9UWVBFXzNdXSA9PSB0cnVlICYmIFtbSVNfQ0hBTkdFRF9IQ0FQVEhBXV0gIT0gIkhDQVBUQ0hBX1RZUEVfMyI=");
               _if(VAR_HCAPTCHA_TYPE_1 == true && VAR_IS_CHANGED_HCAPTHA != "HCAPTCHA_TYPE_1" || VAR_HCAPTCHA_TYPE_1 == true && VAR_IS_CHANGED_HCAPTHA != "HCAPTCHA_TYPE_2" || VAR_HCAPTCHA_TYPE_3 == true && VAR_IS_CHANGED_HCAPTHA != "HCAPTCHA_TYPE_3",function(){
               
                  
                  
                  VAR_GET_ALL_COORDINATES = 0
                  

               })!
               

               
               
               _set_if_expression("W1tIQ0FQVENIQV9UWVBFXzFdXSA9PSB0cnVl");
               _if(VAR_HCAPTCHA_TYPE_1 == true,function(){
               
                  
                  
                  VAR_UNKNOWN_CAPTCHA = 0
                  

                  
                  
                  VAR_IS_CHANGED_HCAPTHA = "HCAPTCHA_TYPE_1"
                  

               })!
               

               
               
               _set_if_expression("W1tIQ0FQVENIQV9UWVBFXzJdXSA9PSB0cnVl");
               _if(VAR_HCAPTCHA_TYPE_2 == true,function(){
               
                  
                  
                  VAR_UNKNOWN_CAPTCHA = 0
                  

                  
                  
                  VAR_IS_CHANGED_HCAPTHA = "HCAPTCHA_TYPE_2"
                  

               })!
               

               
               
               _set_if_expression("W1tIQ0FQVENIQV9UWVBFXzNdXSA9PSB0cnVl");
               _if(VAR_HCAPTCHA_TYPE_3 == true,function(){
               
                  
                  
                  VAR_UNKNOWN_CAPTCHA = 0
                  

                  
                  
                  VAR_IS_CHANGED_HCAPTHA = "HCAPTCHA_TYPE_3"
                  

               })!
               

               
               
               _set_if_expression("W1tIQ0FQVENIQV9UWVBFXzFdXSA9PSBmYWxzZSAmJiBbW0hDQVBUQ0hBX1RZUEVfMl1dID09IGZhbHNlICYmIFtbSENBUFRDSEFfVFlQRV8zXV0gPT0gZmFsc2U=");
               _if(VAR_HCAPTCHA_TYPE_1 == false && VAR_HCAPTCHA_TYPE_2 == false && VAR_HCAPTCHA_TYPE_3 == false,function(){
               
                  
                  
                  VAR_UNKNOWN_CAPTCHA = parseInt(VAR_UNKNOWN_CAPTCHA) + parseInt(1)
                  

               })!
               

            })!
            

         },null)!
         

         
         
         _set_if_expression("W1tVTktOT1dOX0NBUFRDSEFdXSA+IDA=");
         _if(VAR_UNKNOWN_CAPTCHA > 0,function(){
         
            
            
            sleep(2000)!
            

            
            
            _next("function")
            

         })!
         

         
         
         _call(function()
         {
         _on_fail(function(){
         VAR_LAST_ERROR = _result()
         VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
         VAR_WAS_ERROR = false
         _break(1,true)
         })
         CYCLES.Current().RemoveLabel("function")
         
            
            
            _get_browser_screen_settings()!
            ;(function(){
            var result = JSON.parse(_result())
            VAR_SCROLL_X = result["ScrollX"]
            VAR_SCROLL_Y = result["ScrollY"]
            VAR_CURSOR_X = result["CursorX"]
            VAR_CURSOR_Y = result["CursorY"]
            VAR_BROWSER_WIDTH = result["Width"]
            VAR_BROWSER_HEIGHT = result["Height"]
            })();
            

            
            
            _set_if_expression("W1tHRVRfQUxMX0NPT1JESU5BVEVTXV0gPT0gMCB8fCAhKFtbSVNfQ0hBTkdFRF9TQ1JPTExfWV1dIDw9IFtbU0NST0xMX1ldXSArIDQgJiYgW1tJU19DSEFOR0VEX1NDUk9MTF9ZXV0gPj0gW1tTQ1JPTExfWV1dIC0gNCk=");
            _if(VAR_GET_ALL_COORDINATES == 0 || !(VAR_IS_CHANGED_SCROLL_Y <= VAR_SCROLL_Y + 4 && VAR_IS_CHANGED_SCROLL_Y >= VAR_SCROLL_Y - 4),function(){
            
               
               
               VAR_IS_CHANGED_SCROLL_Y = VAR_SCROLL_Y
               

               
               
               VAR_ELEMENT_SELECTOR = VAR_HCAPTCHA_PREFIX_SECOND_FRAME + "\u003eCSS\u003e .refresh"
               

               
               
               _SELECTOR = VAR_ELEMENT_SELECTOR;
               get_element_selector(_SELECTOR, false).script("(function(){var rect = self.getBoundingClientRect();return (rect.left + positionx).toString() + '|' + (rect.top + positiony).toString() + '|' + (rect.right - rect.left).toString() + '|' + (rect.bottom - rect.top).toString()})();")!
               var split = _result().split("|");
               var x = parseInt(split[0]), y = parseInt(split[1]), w = parseInt(split[2]), h = parseInt(split[3]);
               _get_browser_screen_settings()!
               var newresult = JSON.parse(_result());
               var scroll_x = newresult["ScrollX"], scroll_y = newresult["ScrollY"]
               var margin_top_bottom = 50; //percent
               var margin_left_top = 50; // percent
               div = 1;
               var x_min = x + w/100*margin_left_top + parseInt(scroll_x), x_max = x+w/div-w/100*margin_left_top + parseInt(scroll_x);
               var y_min = y + h/100*margin_top_bottom + parseInt(scroll_y), y_max = y+h - h/100*margin_top_bottom + parseInt(scroll_y);
               x = rand(x_min, x_max);
               y = rand(y_min, y_max);
               x = x.toFixed();
               y = y.toFixed();
               /// Кнопка Reload
               VAR_RELOAD_BUTTON_X = parseInt(x);
               VAR_RELOAD_BUTTON_Y = parseInt(y);
               

               
               
               VAR_ELEMENT_SELECTOR = VAR_HCAPTCHA_PREFIX_SECOND_FRAME + "\u003eCSS\u003e .button-submit"
               

               
               
               _SELECTOR = VAR_ELEMENT_SELECTOR;
               get_element_selector(_SELECTOR, false).script("(function(){var rect = self.getBoundingClientRect();return (rect.left + positionx).toString() + '|' + (rect.top + positiony).toString() + '|' + (rect.right - rect.left).toString() + '|' + (rect.bottom - rect.top).toString()})();")!
               var split = _result().split("|");
               var x = parseInt(split[0]), y = parseInt(split[1]), w = parseInt(split[2]), h = parseInt(split[3]);
               _get_browser_screen_settings()!
               var newresult = JSON.parse(_result());
               var scroll_x = newresult["ScrollX"], scroll_y = newresult["ScrollY"]
               var margin_top_bottom = 50; //percent
               var margin_left_top = 50; // percent
               div = 1;
               var x_min = x + w/100*margin_left_top + parseInt(scroll_x), x_max = x+w/div-w/100*margin_left_top + parseInt(scroll_x);
               var y_min = y + h/100*margin_top_bottom + parseInt(scroll_y), y_max = y+h - h/100*margin_top_bottom + parseInt(scroll_y);
               x = rand(x_min, x_max);
               y = rand(y_min, y_max);
               x = x.toFixed();
               y = y.toFixed();
               /// Кнопка подтвердить
               VAR_SUBMIT_BUTTON_X = parseInt(x);
               VAR_SUBMIT_BUTTON_Y = parseInt(y);
               

               
               
               /*Browser*/
               ;_SELECTOR=VAR_HCAPTCHA_PREFIX_SECOND_FRAME + "\u003eCSS\u003e .task-grid";
               get_element_selector(_SELECTOR, false).nowait().exist()!
               VAR_IS_EXISTS = _result() == 1
               _if(VAR_IS_EXISTS, function(){
               get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
               VAR_IS_EXISTS = _result().indexOf("true")>=0
               })!
               

               
               
               _set_if_expression("W1tJU19FWElTVFNdXQ==");
               _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
               
                  
                  
                  VAR_ELEMENT_SELECTOR = VAR_HCAPTCHA_PREFIX_SECOND_FRAME + "\u003eCSS\u003e .task-grid"
                  

               })!
               

               
               
               /*Browser*/
               ;_SELECTOR=VAR_HCAPTCHA_PREFIX_SECOND_FRAME + "\u003eCSS\u003e .bounding-box-example";
               get_element_selector(_SELECTOR, false).nowait().exist()!
               VAR_IS_EXISTS = _result() == 1
               _if(VAR_IS_EXISTS, function(){
               get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
               VAR_IS_EXISTS = _result().indexOf("true")>=0
               })!
               

               
               
               _set_if_expression("W1tJU19FWElTVFNdXQ==");
               _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
               
                  
                  
                  VAR_ELEMENT_SELECTOR = VAR_HCAPTCHA_PREFIX_SECOND_FRAME + "\u003eCSS\u003e .bounding-box-example"
                  

               })!
               

               
               
               /*Browser*/
               ;_SELECTOR=VAR_HCAPTCHA_PREFIX_SECOND_FRAME + "\u003eCSS\u003e .task-wrapper";
               get_element_selector(_SELECTOR, false).nowait().exist()!
               VAR_IS_EXISTS = _result() == 1
               _if(VAR_IS_EXISTS, function(){
               get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
               VAR_IS_EXISTS = _result().indexOf("true")>=0
               })!
               

               
               
               _set_if_expression("W1tJU19FWElTVFNdXQ==");
               _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
               
                  
                  
                  VAR_ELEMENT_SELECTOR = VAR_HCAPTCHA_PREFIX_SECOND_FRAME + "\u003eCSS\u003e div[class=\u0027answer-bg\u0027]\u003eAT\u003e0"
                  

                  
                  
                  _SELECTOR = VAR_ELEMENT_SELECTOR;
                  get_element_selector(_SELECTOR, false).script("(function(){var rect = self.getBoundingClientRect();return (rect.left + positionx).toString() + '|' + (rect.top + positiony).toString() + '|' + (rect.right - rect.left).toString() + '|' + (rect.bottom - rect.top).toString()})();")!
                  var split = _result().split("|");
                  var x = parseInt(split[0]), y = parseInt(split[1]), w = parseInt(split[2]), h = parseInt(split[3]);
                  /// Кнопка подтвердить
                  VAR_ANSWER_SQUARE_WIDTH = parseInt(w);
                  VAR_ANSWER_SQUARE_HEIGHT = parseInt(h);
                  

                  
                  
                  VAR_ELEMENT_SELECTOR = VAR_HCAPTCHA_PREFIX_SECOND_FRAME + "\u003eCSS\u003e .task-wrapper"
                  

               })!
               

               
               
               _SELECTOR = VAR_ELEMENT_SELECTOR;
               get_element_selector(_SELECTOR, false).script("(function(){var rect = self.getBoundingClientRect();return (rect.left + positionx).toString() + '|' + (rect.top + positiony).toString() + '|' + (rect.right - rect.left).toString() + '|' + (rect.bottom - rect.top).toString()})();")!
               var split = _result().split("|");
               var x = parseInt(split[0]), y = parseInt(split[1]), w = parseInt(split[2]), h = parseInt(split[3]);
               //Первый тип капчи
               if (VAR_HCAPTCHA_TYPE_1 == true){
               /// Первый квадрат
               VAR_SQUARE_BUTTON_X = parseInt(x) + VAR_SCROLL_X;
               VAR_SQUARE_BUTTON_Y = parseInt(y) + VAR_SCROLL_Y;
               VAR_SQUARE_WIDTH = parseInt(w);
               VAR_SQUARE_HEIGHT = parseInt(h);
               /// Отдельно считаем наш угол, чтобы потом проверить его видимость
               VAR_START_COORDINATES = parseInt(y);
               }
               //Второй тип капчи. Область ниже трёх заданий
               if (VAR_HCAPTCHA_TYPE_2 == true){
               /// Первый квадрат
               VAR_SQUARE_BUTTON_X = parseInt(x) + VAR_SCROLL_X;
               VAR_BOUNDING_HEIGHT = parseInt(h);
               VAR_SQUARE_BUTTON_Y = parseInt(y) + VAR_BOUNDING_HEIGHT + VAR_SCROLL_Y + 10;
               VAR_SQUARE_WIDTH = parseInt(w);
               VAR_SQUARE_HEIGHT = parseInt(h)*3.25;
               /// Отдельно считаем наш угол, чтобы потом проверить его видимость
               VAR_START_COORDINATES = parseInt(y) + VAR_BOUNDING_HEIGHT;
               }
               //Третий тип капчи. Угол main картинки
               if (VAR_HCAPTCHA_TYPE_3 == true){
               /// Первый квадрат
               VAR_SQUARE_BUTTON_X = parseInt(x) + VAR_SCROLL_X;
               VAR_SQUARE_BUTTON_Y = parseInt(y) + VAR_SCROLL_Y;
               VAR_SQUARE_WIDTH = parseInt(w);
               VAR_SQUARE_HEIGHT = parseInt(h);
               /// Отдельно считаем наш угол, чтобы потом проверить его видимость
               VAR_START_COORDINATES = parseInt(y);
               }
               

               
               
               VAR_GET_ALL_COORDINATES = "1"
               

            })!
            

         },null)!
         

         
         
         _set_if_expression("W1tXQVNfRVJST1JdXQ==");
         _if(typeof(VAR_WAS_ERROR) !== "undefined" ? (VAR_WAS_ERROR) : undefined,function(){
         
            
            
            /*Browser*/
            cache_data_clear()!
            

            
            
            fail(VAR_LAST_ERROR)
            

         })!
         

         
         
         _call(function()
         {
         _on_fail(function(){
         VAR_LAST_ERROR = _result()
         VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
         VAR_WAS_ERROR = false
         _break(1,true)
         })
         CYCLES.Current().RemoveLabel("function")
         
            
            
            _set_if_expression("W1tOVU1CRVJfQ1JVTUJdXSA9PSAw");
            _if(VAR_NUMBER_CRUMB == 0,function(){
            
               
               
               /*Browser*/
               waiter_timeout_next(52000)
               wait_load("*hcaptcha.com/getcaptcha*")!
               

               
               
               /*Browser*/
               waiter_timeout_next(10000)
               wait_load("*hcaptcha.com/getcaptcha*")!
               cache_get_string("*hcaptcha.com/getcaptcha*")!
               VAR_CURRENT_CASHE_TASK = _result()
               

               
               
               _cycle_params().if_else = VAR_CURRENT_CASHE_TASK == "";
               _set_if_expression("W1tDVVJSRU5UX0NBU0hFX1RBU0tdXSA9PSAiIg==");
               _if(_cycle_params().if_else,function(){
               
                  
                  
                  VAR_NOTIFY_ERROR_EXISTS = "1"
                  

               })!
               

               
               
               _if(!_cycle_params().if_else,function(){
               
                  
                  
                  VAR_SET_TASK = JSON.parse(VAR_CURRENT_CASHE_TASK);
                  if (VAR_SET_TASK.hasOwnProperty('requester_question'))
                  {
                  VAR_SET_TASK = VAR_SET_TASK.requester_question.en
                  }
                  else VAR_ERROR_GET_TASK == 1
                  

                  
                  
                  VAR_CURRENT_CASHE_TASK = ""
                  

               })!
               delete _cycle_params().if_else;
               

            })!
            

            
            
            _set_if_expression("W1tSRUxPQURfQlVUVE9OX1ldXSA+IFtbQlJPV1NFUl9IRUlHSFRdXS8xMDAqOTkgKyBbW1NDUk9MTF9ZXV0gJiYgW1tBTFJFQURZX1NDUk9MTEVEX0lOVE9fUkVMT0FEXV0gPT0gMCAmJiBbW0FMUkVBRFlfU0NST0xMRURfSU5UT19TUVVBUkVdXSA9PSAw");
            _if(VAR_RELOAD_BUTTON_Y > VAR_BROWSER_HEIGHT/100*99 + VAR_SCROLL_Y && VAR_ALREADY_SCROLLED_INTO_RELOAD == 0 && VAR_ALREADY_SCROLLED_INTO_SQUARE == 0,function(){
            
               
               
               /*Browser*/
               _SELECTOR = VAR_HCAPTCHA_PREFIX_SECOND_FRAME + "\u003eXPATH\u003e //div[@class=\u0022interface-challenge\u0022]";
               wait_element_visible(_SELECTOR)!
               _call(_random_point, {})!
               _if(_result().length > 0, function(){
               move( {} )!
               get_element_selector(_SELECTOR, false).clarify(X,Y)!
               _call(_clarify, {} )!
               })!
               

               
               
               VAR_GET_ALL_COORDINATES = 0
               

               
               
               VAR_ALREADY_SCROLLED_INTO_RELOAD = parseInt(VAR_ALREADY_SCROLLED_INTO_RELOAD) + parseInt(1)
               

               
               
               _next("function")
               

            })!
            

            
            
            _set_if_expression("W1tTVEFSVF9DT09SRElOQVRFU11dIDwgMCAmJiBbW0FMUkVBRFlfU0NST0xMRURfSU5UT19TUVVBUkVdXSA9PSAw");
            _if(VAR_START_COORDINATES < 0 && VAR_ALREADY_SCROLLED_INTO_SQUARE == 0,function(){
            
               
               
               _set_if_expression("W1tIQ0FQVENIQV9UWVBFXzFdXSA9PSB0cnVl");
               _if(VAR_HCAPTCHA_TYPE_1 == true,function(){
               
                  
                  
                  /*Browser*/
                  _SELECTOR = VAR_HCAPTCHA_PREFIX_SECOND_FRAME + "\u003eCSS\u003e .task-image\u003eAT\u003e4";
                  wait_element_visible(_SELECTOR)!
                  _call(_random_point, {})!
                  _if(_result().length > 0, function(){
                  move( {} )!
                  get_element_selector(_SELECTOR, false).clarify(X,Y)!
                  _call(_clarify, {} )!
                  })!
                  

               })!
               

               
               
               _set_if_expression("W1tIQ0FQVENIQV9UWVBFXzJdXSA9PSB0cnVl");
               _if(VAR_HCAPTCHA_TYPE_2 == true,function(){
               
                  
                  
                  /*Browser*/
                  _scroll_to(VAR_SQUARE_BUTTON_Y)!
                  

               })!
               

               
               
               _set_if_expression("W1tIQ0FQVENIQV9UWVBFXzNdXSA9PSB0cnVl");
               _if(VAR_HCAPTCHA_TYPE_3 == true,function(){
               
                  
                  
                  /*Browser*/
                  _SELECTOR = VAR_HCAPTCHA_PREFIX_SECOND_FRAME + "\u003eCSS\u003e .task-wrapper";
                  wait_element_visible(_SELECTOR)!
                  _call(_random_point, {})!
                  _if(_result().length > 0, function(){
                  move( {} )!
                  get_element_selector(_SELECTOR, false).clarify(X,Y)!
                  _call(_clarify, {} )!
                  })!
                  

               })!
               

               
               
               VAR_ALREADY_SCROLLED_INTO_SQUARE = parseInt(VAR_ALREADY_SCROLLED_INTO_SQUARE) + parseInt(1)
               

               
               
               _next("function")
               

            })!
            

            
            
            _set_if_expression("W1tJU19NT0JJTEVdXSA9PT0gZmFsc2UgJiYgcmFuZCAoMSwxMCkgPiAz");
            _if(VAR_IS_MOBILE === false && rand (1,10) > 3,function(){
            
               
               
               _get_browser_screen_settings()!
               ;(function(){
               var result = JSON.parse(_result())
               VAR_SCROLL_X = result["ScrollX"]
               VAR_SCROLL_Y = result["ScrollY"]
               VAR_CURSOR_X = result["CursorX"]
               VAR_CURSOR_Y = result["CursorY"]
               VAR_BROWSER_WIDTH = result["Width"]
               VAR_BROWSER_HEIGHT = result["Height"]
               })();
               

               
               
               /*Browser*/
               ;_SELECTOR=VAR_HCAPTCHA_PREFIX_SECOND_FRAME + "\u003eCSS\u003e .challenge-container";
               get_element_selector(_SELECTOR, false).nowait().exist()!
               VAR_IS_EXISTS = _result() == 1
               _if(VAR_IS_EXISTS, function(){
               get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
               VAR_IS_EXISTS = _result().indexOf("true")>=0
               })!
               

               
               
               _set_if_expression("IVtbSVNfRVhJU1RTXV0=");
               _if(!VAR_IS_EXISTS,function(){
               
                  
                  
                  VAR_HCAPTCHA_CLOSED = "1"
                  

               })!
               

               
               
               _set_if_expression("W1tIQ0FQVENIQV9DTE9TRURdXSA9PSAw");
               _if(VAR_HCAPTCHA_CLOSED == 0,function(){
               
                  
                  
                  /*Browser*/
                  _SELECTOR = VAR_HCAPTCHA_PREFIX_SECOND_FRAME + "\u003eCSS\u003e .challenge-container";
                  wait_element(_SELECTOR)!
                  get_element_selector(_SELECTOR, false).script("(function(){var rect = _BAS_HIDE(BrowserAutomationStudio_GetBoundingClientRect)(self);return (rect.left + positionx) + '|' + (rect.top + positiony) + '|' + (rect.right - rect.left) + '|' + (rect.bottom - rect.top)})();")!
                  if(_result().length > 0)
                  {
                  var split = _result().split("|")
                  VAR_X = parseInt(split[0])
                  VAR_Y = parseInt(split[1])
                  VAR_CAPTCHA_WIDTH = parseInt(split[2])
                  VAR_CAPTCHA_HEIGHT = parseInt(split[3])
                  }
                  

                  
                  
                  /*Browser*/
                  move(rand(VAR_X/100*105,(VAR_X+VAR_CAPTCHA_WIDTH)/100*93).toFixed(),rand(VAR_Y + VAR_SCROLL_Y/100*105 + VAR_CAPTCHA_HEIGHT/3,VAR_Y + VAR_SCROLL_Y + VAR_CAPTCHA_HEIGHT/100*90).toFixed(),  {} )!
                  

               })!
               

            })!
            

            
            
            _set_if_expression("W1tIQ0FQVENIQV9DTE9TRURdXSA9PSAw");
            _if(VAR_HCAPTCHA_CLOSED == 0,function(){
            
               
               
               /*Browser*/
               render(VAR_SQUARE_BUTTON_X,VAR_SQUARE_BUTTON_Y,VAR_SQUARE_WIDTH,VAR_SQUARE_HEIGHT)!
               VAR_IMAGE_BASE_64 = _result()
               

               
               
               _set_if_expression("W1tJTUFHRV9CQVNFXzY0XV0gPT0gOTk5OTk5OTk5OQ==");
               _if(VAR_IMAGE_BASE_64 == 9999999999,function(){
               
                  
                  
                  _set_if_expression("W1tIQ0FQVENIQV9UWVBFXzFdXSA9PSB0cnVl");
                  _if(VAR_HCAPTCHA_TYPE_1 == true,function(){
                  
                     
                     
                     VAR_RAND_PICTURE = rand (1,50000)
                     

                     
                     
                     native("filesystem", "writefile", JSON.stringify({path: "C:/Images/hCaptcha/3x3/" + VAR_SET_TASK + "/" + VAR_RAND_PICTURE + ".jpg",value: (VAR_IMAGE_BASE_64).toString(),base64:true,append:false}))
                     

                  })!
                  

                  
                  
                  _set_if_expression("W1tIQ0FQVENIQV9UWVBFXzJdXSA9PSB0cnVl");
                  _if(VAR_HCAPTCHA_TYPE_2 == true,function(){
                  
                     
                     
                     VAR_RAND_PICTURE = rand (1,50000)
                     

                     
                     
                     native("filesystem", "writefile", JSON.stringify({path: "C:/Images/hCaptcha/Center_Objects/" + VAR_SET_TASK + "/" + VAR_RAND_PICTURE + ".jpg",value: (VAR_IMAGE_BASE_64).toString(),base64:true,append:false}))
                     

                  })!
                  

                  
                  
                  _set_if_expression("W1tIQ0FQVENIQV9UWVBFXzNdXSA9PSB0cnVl");
                  _if(VAR_HCAPTCHA_TYPE_3 == true,function(){
                  
                     
                     
                     VAR_RAND_PICTURE = rand (1,50000)
                     

                     
                     
                     native("filesystem", "writefile", JSON.stringify({path: "C:/Images/hCaptcha/check_answer/" + VAR_SET_TASK + "/" + VAR_RAND_PICTURE + ".jpg",value: (VAR_IMAGE_BASE_64).toString(),base64:true,append:false}))
                     

                  })!
                  

               })!
               

            })!
            

         },null)!
         

         
         
         VAR_ALREADY_SCROLLED_INTO_RELOAD = 0
         

         
         
         VAR_ALREADY_SCROLLED_INTO_SQUARE = 0
         

         
         
         _set_if_expression("W1tIQ0FQVENIQV9DTE9TRURdXSA9PSAxIHx8IFtbRVJST1JfR0VUX1RBU0tdXSA9PSAx");
         _if(VAR_HCAPTCHA_CLOSED == 1 || VAR_ERROR_GET_TASK == 1,function(){
         
            
            
            _set_if_expression("W1tFUlJPUl9HRVRfVEFTS11dID09IDE=");
            _if(VAR_ERROR_GET_TASK == 1,function(){
            
               
               
               _call(function()
               {
               _on_fail(function(){
               VAR_LAST_ERROR = _result()
               VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
               VAR_WAS_ERROR = false
               _break(1,true)
               })
               CYCLES.Current().RemoveLabel("function")
               
                  
                  
                  /*Browser*/
                  ;_SELECTOR=VAR_HCAPTCHA_PREFIX_SECOND_FRAME + "\u003eCSS\u003e .refresh";
                  get_element_selector(_SELECTOR, false).nowait().exist()!
                  VAR_IS_EXISTS = _result() == 1
                  _if(VAR_IS_EXISTS, function(){
                  get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
                  VAR_IS_EXISTS = _result().indexOf("true")>=0
                  })!
                  

                  
                  
                  _set_if_expression("W1tJU19FWElTVFNdXQ==");
                  _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
                  
                     
                     
                     /*Browser*/
                     cache_data_clear()!
                     

                     
                     
                     /*Browser*/
                     _SELECTOR = VAR_HCAPTCHA_PREFIX_SECOND_FRAME + "\u003eCSS\u003e .refresh";
                     wait_element_visible(_SELECTOR)!
                     _call(_random_point, {})!
                     _if(_result().length > 0, function(){
                     move( {} )!
                     get_element_selector(_SELECTOR, false).clarify(X,Y)!
                     _call(_clarify, {} )!
                     mouse(X,Y)!
                     })!
                     

                  })!
                  

               },null)!
               

            })!
            

            
            
            _next("function")
            

         })!
         

         
         
         _set_if_expression("W1tXQVNfRVJST1JdXQ==");
         _if(typeof(VAR_WAS_ERROR) !== "undefined" ? (VAR_WAS_ERROR) : undefined,function(){
         
            
            
            _set_if_expression("W1tMQVNUX0VSUk9SXV0uaW5kZXhPZigiaGNhcHRjaGEuY29tL2dldGNhcHRjaGEiKSA+PSAwICYmIFtbRklSU1RfTE9BRF9DQVBUQ0hBXV0gPT0gdHJ1ZQ==");
            _if(VAR_LAST_ERROR.indexOf("hcaptcha.com/getcaptcha") >= 0 && VAR_FIRST_LOAD_CAPTCHA == true,function(){
            
               
               
               fail((_K==="en" ? "Failed to get task from request cache - *hcaptcha.com/getcaptcha*" : "Не удалось получить задание из кэша запроса - *hcaptcha.com/getcaptcha*."));
               

            })!
            

            
            
            /*Browser*/
            cache_data_clear()!
            

            
            
            fail(VAR_LAST_ERROR)
            

         })!
         

         
         
         _set_if_expression("W1tOT1RJRllfRVJST1JfRVhJU1RTXV0gPT0gMQ==");
         _if(VAR_NOTIFY_ERROR_EXISTS == 1,function(){
         
            
            
            fail((_K==="en" ? "Failed to get task from request cache - *hcaptcha.com/getcaptcha*. Try to enable the cache, as indicated in the module description" : "Не удалось получить задание из кэша запроса - *hcaptcha.com/getcaptcha*. Попробуйте разрешите кэш, как это указано в описании модуля."));
            

         })!
         

         
         
         VAR_FIRST_LOAD_CAPTCHA = false
         

         
         
         VAR_CYCLE_INDEX = 0
         

         
         
         VAR_HCAPTCHA_CLOSED = 0
         

         
         
         VAR_UNKNOWN_CAPTCHA = 0
         

         
         
         VAR_ERROR_GET_TASK = 0
         

         
         
         _call(function()
         {
         _on_fail(function(){
         VAR_LAST_ERROR = _result()
         VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
         VAR_WAS_ERROR = false
         _break(1,true)
         })
         CYCLES.Current().RemoveLabel("function")
         
            
            
            _do(function(){
            _set_action_info({ name: "For" });
            VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
            if(VAR_CYCLE_INDEX > parseInt(20))_break();
            
               
               
               ///Чистим
               solver_properties_clear("capmonster")
               if (VAR_METHOD_MODULE == "CaptchaGuru (RU Server)") VAR_SERVER_SOLVE = "https://92.53.65.152/"
               if (VAR_METHOD_MODULE == "CaptchaGuru (German Server)") VAR_SERVER_SOLVE = "https://159.69.241.182/"
               if (VAR_METHOD_MODULE == "CaptchaGuru (Finland Server)") VAR_SERVER_SOLVE = "https://95.217.17.172/"
               /// Если юзер оставил старый метод и не пересоздал дейстие с модулем, то оставим дефолт сервер хецнер
               if (VAR_METHOD_MODULE == "CaptchaGuru") VAR_SERVER_SOLVE = "https://159.69.241.182/"
               /// Формирумем основной запрос
               solver_property("capmonster","serverurl",VAR_SERVER_SOLVE)
               solver_property("capmonster","coordinatescaptcha","1")
               solver_property("capmonster","key",VAR_KEY_MODULE)
               solver_property("capmonster","textinstructions",VAR_SET_TASK)
               solver_property("capmonster","click","hcap")
               solver_property("capmonster","basmodule",VAR_BAS_MODULE_VERSION)
               solver_property("capmonster","method","post")
               //// Отправляем
               solve_base64_no_fail("capmonster", VAR_IMAGE_BASE_64)!
               VAR_SAVED_CONTENT = _result();
               

               
               
               _set_if_expression("W1tTQVZFRF9DT05URU5UXV0uaW5kZXhPZigiRVJST1JfQ0FQVENIQV9VTlNPTFZBQkxFIikgPj0gMA==");
               _if(VAR_SAVED_CONTENT.indexOf("ERROR_CAPTCHA_UNSOLVABLE") >= 0,function(){
               
                  
                  
                  /*Browser*/
                  cache_data_clear()!
                  

                  
                  
                  VAR_NUMBER_CRUMB = "0"
                  

                  
                  
                  VAR_HCAPTCHA_INVISIBLE = parseInt(VAR_HCAPTCHA_INVISIBLE) + parseInt(2)
                  

                  
                  
                  _set_if_expression("W1tSRUxPQURfQlVUVE9OX1ldXSA+IFtbQlJPV1NFUl9IRUlHSFRdXQ==");
                  _if(VAR_RELOAD_BUTTON_Y > VAR_BROWSER_HEIGHT,function(){
                  
                     
                     
                     /*Browser*/
                     _scroll_to(VAR_RELOAD_BUTTON_Y + VAR_RELOAD_BUTTON_Y/100*10)!
                     

                  })!
                  

                  
                  
                  _get_browser_screen_settings()!
                  ;(function(){
                  var result = JSON.parse(_result())
                  VAR_SCROLL_X = result["ScrollX"]
                  VAR_SCROLL_Y = result["ScrollY"]
                  VAR_CURSOR_X = result["CursorX"]
                  VAR_CURSOR_Y = result["CursorY"]
                  VAR_BROWSER_WIDTH = result["Width"]
                  VAR_BROWSER_HEIGHT = result["Height"]
                  })();
                  

                  
                  
                  _cycle_params().if_else = VAR_IS_CHANGED_SCROLL_Y != VAR_SCROLL_Y;
                  _set_if_expression("W1tJU19DSEFOR0VEX1NDUk9MTF9ZXV0gIT0gW1tTQ1JPTExfWV1d");
                  _if(_cycle_params().if_else,function(){
                  
                     
                     
                     VAR_ELEMENT_SELECTOR = VAR_HCAPTCHA_PREFIX_SECOND_FRAME + "\u003eCSS\u003e .refresh"
                     

                     
                     
                     _SELECTOR = VAR_ELEMENT_SELECTOR;
                     get_element_selector(_SELECTOR, false).script("(function(){var rect = self.getBoundingClientRect();return (rect.left + positionx).toString() + '|' + (rect.top + positiony).toString() + '|' + (rect.right - rect.left).toString() + '|' + (rect.bottom - rect.top).toString()})();")!
                     var split = _result().split("|");
                     var x = parseInt(split[0]), y = parseInt(split[1]), w = parseInt(split[2]), h = parseInt(split[3]);
                     _get_browser_screen_settings()!
                     var result_hcaptcha = JSON.parse(_result());
                     var scroll_x = result_hcaptcha["ScrollX"], scroll_y = result_hcaptcha["ScrollY"]
                     var margin_top_bottom = 50; //percent
                     var margin_left_top = 50; // percent
                     div = 1;
                     var x_min = x + w/100*margin_left_top + parseInt(scroll_x), x_max = x+w/div-w/100*margin_left_top + parseInt(scroll_x);
                     var y_min = y + h/100*margin_top_bottom + parseInt(scroll_y), y_max = y+h - h/100*margin_top_bottom + parseInt(scroll_y);
                     x = rand(x_min, x_max);
                     y = rand(y_min, y_max);
                     x = x.toFixed();
                     y = y.toFixed();
                     /// Кнопка Reload
                     VAR_RELOAD_BUTTON_X = parseInt(x);
                     VAR_RELOAD_BUTTON_Y = parseInt(y);
                     

                  })!
                  

                  
                  
                  /*Browser*/
                  ;_SELECTOR=VAR_HCAPTCHA_PREFIX_SECOND_FRAME + "\u003eCSS\u003e .refresh";
                  get_element_selector(_SELECTOR, false).nowait().exist()!
                  VAR_IS_EXISTS = _result() == 1
                  _if(VAR_IS_EXISTS, function(){
                  get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
                  VAR_IS_EXISTS = _result().indexOf("true")>=0
                  })!
                  

                  
                  
                  _cycle_params().if_else = typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined;
                  _set_if_expression("W1tJU19FWElTVFNdXQ==");
                  _if(_cycle_params().if_else,function(){
                  
                     
                     
                     /*Browser*/
                     move(VAR_RELOAD_BUTTON_X  + rand (-6,6),VAR_RELOAD_BUTTON_Y  + rand (-6,6),  {"speed": VAR_SPEED,"gravity": VAR_GRAVITY,"deviation": VAR_DEVIATION} )!
                     mouse(VAR_RELOAD_BUTTON_X  + rand (-6,6),VAR_RELOAD_BUTTON_Y  + rand (-6,6))!
                     

                  })!
                  

                  
                  
                  _if(!_cycle_params().if_else,function(){
                  
                     
                     
                     VAR_ERROR_CAPTCHA_UNSOLVABLE_MODULE = parseInt(VAR_ERROR_CAPTCHA_UNSOLVABLE_MODULE) + parseInt(2)
                     

                  })!
                  delete _cycle_params().if_else;
                  

                  
                  
                  sleep(1000)!
                  

                  
                  
                  VAR_ERROR_CAPTCHA_UNSOLVABLE_MODULE = parseInt(VAR_ERROR_CAPTCHA_UNSOLVABLE_MODULE) + parseInt(1)
                  

                  
                  
                  _break("function")
                  

               })!
               

               
               
               _set_if_expression("W1tTQVZFRF9DT05URU5UXV0uaW5kZXhPZigiRVJST1JfV1JPTkdfVVNFUl9LRVkiKSA+PSAw");
               _if(VAR_SAVED_CONTENT.indexOf("ERROR_WRONG_USER_KEY") >= 0,function(){
               
                  
                  
                  VAR_ERROR_KEY = "1"
                  

                  
                  
                  _break("function")
                  

               })!
               

               
               
               _set_if_expression("W1tTQVZFRF9DT05URU5UXV0uaW5kZXhPZigiRVJST1JfWkVST19CQUxBTkNFIikgPj0gMA==");
               _if(VAR_SAVED_CONTENT.indexOf("ERROR_ZERO_BALANCE") >= 0,function(){
               
                  
                  
                  VAR_ERROR_BALANCE = "1"
                  

                  
                  
                  _break("function")
                  

               })!
               

               
               
               _set_if_expression("W1tTQVZFRF9DT05URU5UXV0uaW5kZXhPZigiQ0FQVENIQV9GQUlMIikgPj0gMA==");
               _if(VAR_SAVED_CONTENT.indexOf("CAPTCHA_FAIL") >= 0,function(){
               
                  
                  
                  sleep(rand(1000,2000))!
                  

                  
                  
                  VAR_CAPTCHA_FAIL = parseInt(VAR_CAPTCHA_FAIL) + parseInt(1)
                  

                  
                  
                  _break("function")
                  

               })!
               

               
               
               _cycle_params().if_else = VAR_SAVED_CONTENT.match(/[0-9]/) && VAR_SAVED_CONTENT.indexOf("coordinates") >= 0;
               _set_if_expression("W1tTQVZFRF9DT05URU5UXV0ubWF0Y2goL1swLTldLykgJiYgW1tTQVZFRF9DT05URU5UXV0uaW5kZXhPZigiY29vcmRpbmF0ZXMiKSA+PSAw");
               _if(_cycle_params().if_else,function(){
               
                  
                  
                  VAR_MODULE_FRAME_SELECTOR = _BAS_SOLVER_PROPERTIES;
                  var data = VAR_MODULE_FRAME_SELECTOR;
                  var selectors_number = [ VAR_SELECTOR_1,VAR_SELECTOR_2 ]
                  VAR_RESULT_SELECTOR = data[selectors_number[0]][selectors_number[1]];
                  

                  
                  
                  VAR_ERROR_CAPTCHA_UNSOLVABLE_MODULE = "0"
                  

                  
                  
                  VAR_LISTS_COORDINATES = VAR_SAVED_CONTENT
                  VAR_LISTS_COORDINATES = VAR_LISTS_COORDINATES.split("coordinates:")[1];
                  VAR_LISTS_COORDINATES = VAR_LISTS_COORDINATES.split(";");
                  

                  
                  
                  var pattern_reg = /^\D*(\d)/;
                  var match_many_me = VAR_RESULT_SELECTOR.match(pattern_reg);
                  var result_number = parseInt(match_many_me ? match_many_me[1] : null);
                  var char_result = parseInt(VAR_RESULT_SELECTOR.charAt(VAR_RESULT_SELECTOR.length-2));
                  if (result_number + char_result != 1 + 1 + 1 && result_number + char_result != 11) VAR_RESULT_SELECTOR = 10-7-2;
                  

                  
                  
                  ;(function (a) {var j, x, i;for (i = a.length; i; i--) {j = Math.floor(Math.random() * i);x = a[i - 1]; a[i - 1] = a[j];a[j] = x;}})(VAR_LISTS_COORDINATES)
                  

                  
                  
                  VAR_FOREACH_DATA = 0
                  

                  
                  
                  _do_with_params({"foreach_data":(VAR_LISTS_COORDINATES)},function(){
                  _set_action_info({ name: "Foreach" });
                  VAR_CYCLE_INDEX = _iterator() - 1
                  if(VAR_CYCLE_INDEX > _cycle_param("foreach_data").length - 1)_break();
                  VAR_FOREACH_DATA = _cycle_param("foreach_data")[VAR_CYCLE_INDEX]
                  
                     
                     
                     var csv_parse_result = csv_parse(VAR_FOREACH_DATA)
                     VAR_ANSWER_X = csv_parse_result[0]
                     if(typeof(VAR_ANSWER_X) == 'undefined' || !VAR_ANSWER_X)
                     {
                     VAR_ANSWER_X = ""
                     }
                     VAR_ANSWER_Y = csv_parse_result[1]
                     if(typeof(VAR_ANSWER_Y) == 'undefined' || !VAR_ANSWER_Y)
                     {
                     VAR_ANSWER_Y = ""
                     }
                     

                     
                     
                     VAR_ANSWER_X = VAR_ANSWER_X.replace(/[^0-9]/g, '');
                     VAR_ANSWER_Y = VAR_ANSWER_Y.replace(/[^0-9]/g, '');
                     VAR_ANSWER_X = parseInt(VAR_ANSWER_X)
                     VAR_ANSWER_Y = parseInt(VAR_ANSWER_Y)
                     

                     
                     
                     _set_if_expression("W1tIQ0FQVENIQV9UWVBFXzFdXSA9PSB0cnVl");
                     _if(VAR_HCAPTCHA_TYPE_1 == true,function(){
                     
                        
                        
                        /*Browser*/
                        move(VAR_SQUARE_BUTTON_X + VAR_ANSWER_X + rand (-12,+12),VAR_SQUARE_BUTTON_Y + VAR_ANSWER_Y + rand (-12,+12),  {"speed": VAR_SPEED,"gravity": VAR_GRAVITY,"deviation": VAR_DEVIATION} )!
                        mouse(VAR_SQUARE_BUTTON_X + VAR_ANSWER_X + rand (-12,+12),VAR_SQUARE_BUTTON_Y + VAR_ANSWER_Y + rand (-12,+12))!
                        

                     })!
                     

                     
                     
                     _set_if_expression("W1tIQ0FQVENIQV9UWVBFXzJdXSA9PSB0cnVl");
                     _if(VAR_HCAPTCHA_TYPE_2 == true,function(){
                     
                        
                        
                        /*Browser*/
                        move(VAR_SQUARE_BUTTON_X + VAR_ANSWER_X,VAR_SQUARE_BUTTON_Y + VAR_ANSWER_Y,  {"speed": VAR_SPEED,"gravity": VAR_GRAVITY,"deviation": VAR_DEVIATION} )!
                        mouse(VAR_SQUARE_BUTTON_X + VAR_ANSWER_X,VAR_SQUARE_BUTTON_Y + VAR_ANSWER_Y)!
                        

                        
                        
                        _set_if_expression("W1tJU19NT0JJTEVdXSA9PT0gZmFsc2U=");
                        _if(VAR_IS_MOBILE === false,function(){
                        
                           
                           
                           _set_if_expression("cmFuZCAoMSwxMCkgPiA0");
                           _if(rand (1,10) > 4,function(){
                           
                              
                              
                              _get_browser_screen_settings()!
                              ;(function(){
                              var result = JSON.parse(_result())
                              VAR_SCROLL_X = result["ScrollX"]
                              VAR_SCROLL_Y = result["ScrollY"]
                              VAR_CURSOR_X = result["CursorX"]
                              VAR_CURSOR_Y = result["CursorY"]
                              VAR_BROWSER_WIDTH = result["Width"]
                              VAR_BROWSER_HEIGHT = result["Height"]
                              })();
                              

                              
                              
                              sleep(rand(100,300))!
                              

                              
                              
                              /*Browser*/
                              _SELECTOR = VAR_HCAPTCHA_PREFIX_SECOND_FRAME + "\u003eCSS\u003e .challenge-container";
                              wait_element(_SELECTOR)!
                              get_element_selector(_SELECTOR, false).script("(function(){var rect = _BAS_HIDE(BrowserAutomationStudio_GetBoundingClientRect)(self);return (rect.left + positionx) + '|' + (rect.top + positiony) + '|' + (rect.right - rect.left) + '|' + (rect.bottom - rect.top)})();")!
                              if(_result().length > 0)
                              {
                              var split = _result().split("|")
                              VAR_X = parseInt(split[0])
                              VAR_Y = parseInt(split[1])
                              VAR_CAPTCHA_WIDTH = parseInt(split[2])
                              VAR_CAPTCHA_HEIGHT = parseInt(split[3])
                              }
                              

                              
                              
                              /*Browser*/
                              move(rand(VAR_X/100*105,(VAR_X+VAR_CAPTCHA_WIDTH)/100*93).toFixed(),rand(VAR_Y + VAR_SCROLL_Y/100*105 + VAR_CAPTCHA_HEIGHT/3,VAR_Y + VAR_SCROLL_Y + VAR_CAPTCHA_HEIGHT/100*90).toFixed(),  {} )!
                              

                              
                              
                              sleep(rand(100,300))!
                              

                           })!
                           

                           
                           
                           _set_if_expression("cmFuZCAoMSwxMCkgPiA4");
                           _if(rand (1,10) > 8,function(){
                           
                              
                              
                              /*Browser*/
                              IDDLE_EMULATION_END = Date.now() + 1000 * (rand (1,2))
                              IDDLE_EMULATION_DISTRIBUTION = [3,3]
                              _get_browser_screen_settings()!
                              IDDLE_EMULATION_RESULT = JSON.parse(_result())
                              IDDLE_CURSOR_POSITION_X = IDDLE_EMULATION_RESULT["CursorX"]
                              IDDLE_CURSOR_POSITION_Y = IDDLE_EMULATION_RESULT["CursorY"]
                              IDDLE_CURSOR_POSITION_WIDTH = IDDLE_EMULATION_RESULT["Width"]
                              IDDLE_CURSOR_POSITION_HEIGHT = IDDLE_EMULATION_RESULT["Height"]
                              IDDLE_CURSOR_POSITION_WAS_SCROLL = false
                              _do(function(){
                              if(Date.now() >= IDDLE_EMULATION_END)
                              _break()
                              IDDLE_EMULATION_CURRENT_ITEM = IDDLE_EMULATION_DISTRIBUTION[Math.floor(Math.random()*IDDLE_EMULATION_DISTRIBUTION.length)]
                              if(_iterator() == 1 && IDDLE_EMULATION_DISTRIBUTION.indexOf(2)>=0)
                              IDDLE_EMULATION_CURRENT_ITEM = 2
                              _if(IDDLE_EMULATION_CURRENT_ITEM == 1, function(){
                              //scroll
                              IDDLE_EMULATION_CURRENT_DIRECTION = (rand(1,2) == 2) ? "<MOUSESCROLLUP>" : "<MOUSESCROLLDOWN>"
                              if(!IDDLE_CURSOR_POSITION_WAS_SCROLL)
                              IDDLE_EMULATION_CURRENT_DIRECTION = "<MOUSESCROLLDOWN>"
                              IDDLE_CURSOR_POSITION_WAS_SCROLL = true
                              IDDLE_EMULATION_CURRENT_NUMBER = rand(1,5)
                              _do(function(){
                              if(_iterator() >= IDDLE_EMULATION_CURRENT_NUMBER)
                              _break()
                              _type(IDDLE_EMULATION_CURRENT_DIRECTION,1000)!
                              sleep(rand(300,1000))!
                              })!
                              })!
                              _if(IDDLE_EMULATION_CURRENT_ITEM == 2, function(){
                              //long move
                              page().script("document.documentElement.scrollLeft")!
                              IDDLE_CURSOR_POSITION_SCROLL_X = parseInt(_result())
                              page().script("document.documentElement.scrollTop")!
                              IDDLE_CURSOR_POSITION_SCROLL_Y = parseInt(_result())
                              IDDLE_CURSOR_POSITION_X = rand(1,IDDLE_CURSOR_POSITION_WIDTH)
                              IDDLE_CURSOR_POSITION_Y = rand(1,IDDLE_CURSOR_POSITION_HEIGHT)
                              move(IDDLE_CURSOR_POSITION_SCROLL_X + IDDLE_CURSOR_POSITION_X,IDDLE_CURSOR_POSITION_SCROLL_Y + IDDLE_CURSOR_POSITION_Y)!
                              })!
                              _if(IDDLE_EMULATION_CURRENT_ITEM == 3, function(){
                              //short move
                              if(IDDLE_CURSOR_POSITION_X < 0 || IDDLE_CURSOR_POSITION_Y < 0)
                              _break()
                              page().script("document.documentElement.scrollLeft")!
                              IDDLE_CURSOR_POSITION_SCROLL_X = parseInt(_result())
                              page().script("document.documentElement.scrollTop")!
                              IDDLE_CURSOR_POSITION_SCROLL_Y = parseInt(_result())
                              IDDLE_EMULATION_CURRENT_NUMBER = rand(1,4)
                              _do(function(){
                              if(_iterator() >= IDDLE_EMULATION_CURRENT_NUMBER)
                              _break()
                              IDDLE_CURSOR_POSITION_X += rand(-50,50)
                              IDDLE_CURSOR_POSITION_Y += rand(-50,50)
                              if(IDDLE_CURSOR_POSITION_X > IDDLE_CURSOR_POSITION_WIDTH)
                              IDDLE_CURSOR_POSITION_X = IDDLE_CURSOR_POSITION_WIDTH
                              if(IDDLE_CURSOR_POSITION_Y > IDDLE_CURSOR_POSITION_HEIGHT)
                              IDDLE_CURSOR_POSITION_Y = IDDLE_CURSOR_POSITION_HEIGHT
                              if(IDDLE_CURSOR_POSITION_X < 0)
                              IDDLE_CURSOR_POSITION_X = 0
                              if(IDDLE_CURSOR_POSITION_Y < 0)
                              IDDLE_CURSOR_POSITION_Y = 0
                              move(IDDLE_CURSOR_POSITION_SCROLL_X + IDDLE_CURSOR_POSITION_X,IDDLE_CURSOR_POSITION_SCROLL_Y + IDDLE_CURSOR_POSITION_Y)!
                              _if(rand(1,10) > 3,function(){
                              sleep(rand(10,300))!
                              })!
                              })!
                              })!
                              _if(IDDLE_EMULATION_CURRENT_ITEM == 4, function(){
                              //sleep
                              sleep(rand(500,5000))!
                              })!
                              })!
                              

                           })!
                           

                        })!
                        

                     })!
                     

                     
                     
                     _set_if_expression("W1tIQ0FQVENIQV9UWVBFXzNdXSA9PSB0cnVl");
                     _if(VAR_HCAPTCHA_TYPE_3 == true,function(){
                     
                        
                        
                        /*Browser*/
                        move(VAR_SQUARE_BUTTON_X + VAR_ANSWER_X + rand (-8,VAR_ANSWER_SQUARE_WIDTH/1.9),VAR_SQUARE_BUTTON_Y + VAR_ANSWER_Y + rand (-VAR_ANSWER_SQUARE_HEIGHT/7,VAR_ANSWER_SQUARE_HEIGHT/7),  {"speed": VAR_SPEED,"gravity": VAR_GRAVITY,"deviation": VAR_DEVIATION} )!
                        mouse(VAR_SQUARE_BUTTON_X + VAR_ANSWER_X + rand (-8,VAR_ANSWER_SQUARE_WIDTH/1.9),VAR_SQUARE_BUTTON_Y + VAR_ANSWER_Y + rand (-VAR_ANSWER_SQUARE_HEIGHT/7,VAR_ANSWER_SQUARE_HEIGHT/7))!
                        

                        
                        
                        _set_if_expression("W1tJU19NT0JJTEVdXSA9PT0gZmFsc2U=");
                        _if(VAR_IS_MOBILE === false,function(){
                        
                           
                           
                           _set_if_expression("cmFuZCAoMSwxMCkgPiA0");
                           _if(rand (1,10) > 4,function(){
                           
                              
                              
                              _get_browser_screen_settings()!
                              ;(function(){
                              var result = JSON.parse(_result())
                              VAR_SCROLL_X = result["ScrollX"]
                              VAR_SCROLL_Y = result["ScrollY"]
                              VAR_CURSOR_X = result["CursorX"]
                              VAR_CURSOR_Y = result["CursorY"]
                              VAR_BROWSER_WIDTH = result["Width"]
                              VAR_BROWSER_HEIGHT = result["Height"]
                              })();
                              

                              
                              
                              sleep(rand(100,300))!
                              

                              
                              
                              /*Browser*/
                              _SELECTOR = VAR_HCAPTCHA_PREFIX_SECOND_FRAME + "\u003eCSS\u003e .challenge-container";
                              wait_element(_SELECTOR)!
                              get_element_selector(_SELECTOR, false).script("(function(){var rect = _BAS_HIDE(BrowserAutomationStudio_GetBoundingClientRect)(self);return (rect.left + positionx) + '|' + (rect.top + positiony) + '|' + (rect.right - rect.left) + '|' + (rect.bottom - rect.top)})();")!
                              if(_result().length > 0)
                              {
                              var split = _result().split("|")
                              VAR_X = parseInt(split[0])
                              VAR_Y = parseInt(split[1])
                              VAR_CAPTCHA_WIDTH = parseInt(split[2])
                              VAR_CAPTCHA_HEIGHT = parseInt(split[3])
                              }
                              

                              
                              
                              /*Browser*/
                              move(rand(VAR_X/100*105,(VAR_X+VAR_CAPTCHA_WIDTH)/100*93).toFixed(),rand(VAR_Y + VAR_SCROLL_Y/100*105 + VAR_CAPTCHA_HEIGHT/3,VAR_Y + VAR_SCROLL_Y + VAR_CAPTCHA_HEIGHT/100*90).toFixed(),  {} )!
                              

                              
                              
                              sleep(rand(100,300))!
                              

                           })!
                           

                           
                           
                           _set_if_expression("cmFuZCAoMSwxMCkgPiA4");
                           _if(rand (1,10) > 8,function(){
                           
                              
                              
                              /*Browser*/
                              IDDLE_EMULATION_END = Date.now() + 1000 * (rand (1,2))
                              IDDLE_EMULATION_DISTRIBUTION = [3,3]
                              _get_browser_screen_settings()!
                              IDDLE_EMULATION_RESULT = JSON.parse(_result())
                              IDDLE_CURSOR_POSITION_X = IDDLE_EMULATION_RESULT["CursorX"]
                              IDDLE_CURSOR_POSITION_Y = IDDLE_EMULATION_RESULT["CursorY"]
                              IDDLE_CURSOR_POSITION_WIDTH = IDDLE_EMULATION_RESULT["Width"]
                              IDDLE_CURSOR_POSITION_HEIGHT = IDDLE_EMULATION_RESULT["Height"]
                              IDDLE_CURSOR_POSITION_WAS_SCROLL = false
                              _do(function(){
                              if(Date.now() >= IDDLE_EMULATION_END)
                              _break()
                              IDDLE_EMULATION_CURRENT_ITEM = IDDLE_EMULATION_DISTRIBUTION[Math.floor(Math.random()*IDDLE_EMULATION_DISTRIBUTION.length)]
                              if(_iterator() == 1 && IDDLE_EMULATION_DISTRIBUTION.indexOf(2)>=0)
                              IDDLE_EMULATION_CURRENT_ITEM = 2
                              _if(IDDLE_EMULATION_CURRENT_ITEM == 1, function(){
                              //scroll
                              IDDLE_EMULATION_CURRENT_DIRECTION = (rand(1,2) == 2) ? "<MOUSESCROLLUP>" : "<MOUSESCROLLDOWN>"
                              if(!IDDLE_CURSOR_POSITION_WAS_SCROLL)
                              IDDLE_EMULATION_CURRENT_DIRECTION = "<MOUSESCROLLDOWN>"
                              IDDLE_CURSOR_POSITION_WAS_SCROLL = true
                              IDDLE_EMULATION_CURRENT_NUMBER = rand(1,5)
                              _do(function(){
                              if(_iterator() >= IDDLE_EMULATION_CURRENT_NUMBER)
                              _break()
                              _type(IDDLE_EMULATION_CURRENT_DIRECTION,1000)!
                              sleep(rand(300,1000))!
                              })!
                              })!
                              _if(IDDLE_EMULATION_CURRENT_ITEM == 2, function(){
                              //long move
                              page().script("document.documentElement.scrollLeft")!
                              IDDLE_CURSOR_POSITION_SCROLL_X = parseInt(_result())
                              page().script("document.documentElement.scrollTop")!
                              IDDLE_CURSOR_POSITION_SCROLL_Y = parseInt(_result())
                              IDDLE_CURSOR_POSITION_X = rand(1,IDDLE_CURSOR_POSITION_WIDTH)
                              IDDLE_CURSOR_POSITION_Y = rand(1,IDDLE_CURSOR_POSITION_HEIGHT)
                              move(IDDLE_CURSOR_POSITION_SCROLL_X + IDDLE_CURSOR_POSITION_X,IDDLE_CURSOR_POSITION_SCROLL_Y + IDDLE_CURSOR_POSITION_Y)!
                              })!
                              _if(IDDLE_EMULATION_CURRENT_ITEM == 3, function(){
                              //short move
                              if(IDDLE_CURSOR_POSITION_X < 0 || IDDLE_CURSOR_POSITION_Y < 0)
                              _break()
                              page().script("document.documentElement.scrollLeft")!
                              IDDLE_CURSOR_POSITION_SCROLL_X = parseInt(_result())
                              page().script("document.documentElement.scrollTop")!
                              IDDLE_CURSOR_POSITION_SCROLL_Y = parseInt(_result())
                              IDDLE_EMULATION_CURRENT_NUMBER = rand(1,4)
                              _do(function(){
                              if(_iterator() >= IDDLE_EMULATION_CURRENT_NUMBER)
                              _break()
                              IDDLE_CURSOR_POSITION_X += rand(-50,50)
                              IDDLE_CURSOR_POSITION_Y += rand(-50,50)
                              if(IDDLE_CURSOR_POSITION_X > IDDLE_CURSOR_POSITION_WIDTH)
                              IDDLE_CURSOR_POSITION_X = IDDLE_CURSOR_POSITION_WIDTH
                              if(IDDLE_CURSOR_POSITION_Y > IDDLE_CURSOR_POSITION_HEIGHT)
                              IDDLE_CURSOR_POSITION_Y = IDDLE_CURSOR_POSITION_HEIGHT
                              if(IDDLE_CURSOR_POSITION_X < 0)
                              IDDLE_CURSOR_POSITION_X = 0
                              if(IDDLE_CURSOR_POSITION_Y < 0)
                              IDDLE_CURSOR_POSITION_Y = 0
                              move(IDDLE_CURSOR_POSITION_SCROLL_X + IDDLE_CURSOR_POSITION_X,IDDLE_CURSOR_POSITION_SCROLL_Y + IDDLE_CURSOR_POSITION_Y)!
                              _if(rand(1,10) > 3,function(){
                              sleep(rand(10,300))!
                              })!
                              })!
                              })!
                              _if(IDDLE_EMULATION_CURRENT_ITEM == 4, function(){
                              //sleep
                              sleep(rand(500,5000))!
                              })!
                              })!
                              

                           })!
                           

                        })!
                        

                     })!
                     

                  })!
                  

                  
                  
                  /*Browser*/
                  ;_SELECTOR=VAR_HCAPTCHA_PREFIX_SECOND_FRAME + "\u003eXPATH\u003e//div[@class=\u0022crumb-bg\u0022]";
                  get_element_selector(_SELECTOR, false).nowait().exist()!
                  VAR_IS_EXISTS = _result() == 1
                  _if(VAR_IS_EXISTS, function(){
                  get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
                  VAR_IS_EXISTS = _result().indexOf("true")>=0
                  })!
                  

                  
                  
                  _set_if_expression("IVtbSVNfRVhJU1RTXV0=");
                  _if(!VAR_IS_EXISTS,function(){
                  
                     
                     
                     VAR_NUMBER_CRUMB = "0"
                     

                     
                     
                     VAR_HCAPTCHA_INVISIBLE = parseInt(VAR_HCAPTCHA_INVISIBLE) + parseInt(2)
                     

                     
                     
                     /*Browser*/
                     cache_data_clear()!
                     

                  })!
                  

                  
                  
                  _set_if_expression("W1tJU19FWElTVFNdXQ==");
                  _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
                  
                     
                     
                     _set_if_expression("W1tOVU1CRVJfQ1JVTUJdXSA9PSAw");
                     _if(VAR_NUMBER_CRUMB == 0,function(){
                     
                        
                        
                        /*Browser*/
                        ;_SELECTOR=VAR_HCAPTCHA_PREFIX_SECOND_FRAME + "\u003eXPATH\u003e//div[@class=\u0022Crumb\u0022]";
                        get_element_selector(_SELECTOR, true).length()!
                        VAR_ELEMENT_LENGTH = _result()
                        

                        
                        
                        _set_if_expression("W1tFTEVNRU5UX0xFTkdUSF1dID4gMA==");
                        _if(VAR_ELEMENT_LENGTH > 0,function(){
                        
                           
                           
                           VAR_NUMBER_CRUMB = parseInt(VAR_NUMBER_CRUMB) + parseInt(1)
                           

                        })!
                        

                     })!
                     

                     
                     
                     _set_if_expression("W1tOVU1CRVJfQ1JVTUJdXSA9PSBbW0VMRU1FTlRfTEVOR1RIXV0=");
                     _if(VAR_NUMBER_CRUMB == VAR_ELEMENT_LENGTH,function(){
                     
                        
                        
                        VAR_NUMBER_CRUMB = "0"
                        

                        
                        
                        VAR_HCAPTCHA_INVISIBLE = parseInt(VAR_HCAPTCHA_INVISIBLE) + parseInt(2)
                        

                        
                        
                        /*Browser*/
                        cache_data_clear()!
                        

                     })!
                     

                     
                     
                     _set_if_expression("W1tIQ0FQVENIQV9UWVBFXzJdXSA9PSB0cnVlIHx8IFtbSENBUFRDSEFfVFlQRV8zXV0gPT0gdHJ1ZQ==");
                     _if(VAR_HCAPTCHA_TYPE_2 == true || VAR_HCAPTCHA_TYPE_3 == true,function(){
                     
                        
                        
                        /*Browser*/
                        cache_data_clear()!
                        

                     })!
                     

                  })!
                  

                  
                  
                  _set_if_expression("W1tSRUxPQURfQlVUVE9OX1ldXSA+IFtbQlJPV1NFUl9IRUlHSFRdXS8xMDAqOTkgKyBbW1NDUk9MTF9ZXV0=");
                  _if(VAR_RELOAD_BUTTON_Y > VAR_BROWSER_HEIGHT/100*99 + VAR_SCROLL_Y,function(){
                  
                     
                     
                     /*Browser*/
                     _scroll_to(VAR_SUBMIT_BUTTON_Y + VAR_SUBMIT_BUTTON_Y/100*10)!
                     

                  })!
                  

                  
                  
                  _get_browser_screen_settings()!
                  ;(function(){
                  var result = JSON.parse(_result())
                  VAR_SCROLL_X = result["ScrollX"]
                  VAR_SCROLL_Y = result["ScrollY"]
                  VAR_CURSOR_X = result["CursorX"]
                  VAR_CURSOR_Y = result["CursorY"]
                  VAR_BROWSER_WIDTH = result["Width"]
                  VAR_BROWSER_HEIGHT = result["Height"]
                  })();
                  

                  
                  
                  _cycle_params().if_else = !(VAR_IS_CHANGED_SCROLL_Y <= VAR_SCROLL_Y + 4 && VAR_IS_CHANGED_SCROLL_Y >= VAR_SCROLL_Y - 4);
                  _set_if_expression("IShbW0lTX0NIQU5HRURfU0NST0xMX1ldXSA8PSBbW1NDUk9MTF9ZXV0gKyA0ICYmIFtbSVNfQ0hBTkdFRF9TQ1JPTExfWV1dID49IFtbU0NST0xMX1ldXSAtIDQp");
                  _if(_cycle_params().if_else,function(){
                  
                     
                     
                     VAR_ELEMENT_SELECTOR = VAR_HCAPTCHA_PREFIX_SECOND_FRAME + "\u003eCSS\u003e .button-submit"
                     

                     
                     
                     _SELECTOR = VAR_ELEMENT_SELECTOR;
                     get_element_selector(_SELECTOR, false).script("(function(){var rect = self.getBoundingClientRect();return (rect.left + positionx).toString() + '|' + (rect.top + positiony).toString() + '|' + (rect.right - rect.left).toString() + '|' + (rect.bottom - rect.top).toString()})();")!
                     var split = _result().split("|");
                     var x = parseInt(split[0]), y = parseInt(split[1]), w = parseInt(split[2]), h = parseInt(split[3]);
                     _get_browser_screen_settings()!
                     var newresult = JSON.parse(_result());
                     var scroll_x = newresult["ScrollX"], scroll_y = newresult["ScrollY"]
                     var margin_top_bottom = 50; //percent
                     var margin_left_top = 50; // percent
                     div = 1;
                     var x_min = x + w/100*margin_left_top + parseInt(scroll_x), x_max = x+w/div-w/100*margin_left_top + parseInt(scroll_x);
                     var y_min = y + h/100*margin_top_bottom + parseInt(scroll_y), y_max = y+h - h/100*margin_top_bottom + parseInt(scroll_y);
                     x = rand(x_min, x_max);
                     y = rand(y_min, y_max);
                     x = x.toFixed();
                     y = y.toFixed();
                     /// Кнопка подтвердить
                     VAR_SUBMIT_BUTTON_X = parseInt(x);
                     VAR_SUBMIT_BUTTON_Y = parseInt(y);
                     

                  })!
                  

                  
                  
                  /*Browser*/
                  move(VAR_SUBMIT_BUTTON_X + rand (-15,15),VAR_SUBMIT_BUTTON_Y + rand (-5,5),  {"speed": VAR_SPEED,"gravity": VAR_GRAVITY,"deviation": VAR_DEVIATION} )!
                  mouse(VAR_SUBMIT_BUTTON_X + rand (-15,15),VAR_SUBMIT_BUTTON_Y + rand (-5,5))!
                  

                  
                  
                  _set_if_expression("W1tOVU1CRVJfQ1JVTUJdXSA9PSAw");
                  _if(VAR_NUMBER_CRUMB == 0,function(){
                  
                     
                     
                     VAR_HCAPTCHA_INVISIBLE = parseInt(VAR_HCAPTCHA_INVISIBLE) + parseInt(2)
                     

                     
                     
                     sleep(rand(100,300))!
                     

                  })!
                  

                  
                  
                  _set_if_expression("W1tOVU1CRVJfQ1JVTUJdXSAhPSAw");
                  _if(VAR_NUMBER_CRUMB != 0,function(){
                  
                     
                     
                     VAR_NUMBER_CRUMB = parseInt(VAR_NUMBER_CRUMB) + parseInt(1)
                     

                     
                     
                     sleep(100)!
                     

                  })!
                  

                  
                  
                  _break("function")
                  

               })!
               

               
               
               _if(!_cycle_params().if_else,function(){
               
                  
                  
                  VAR_NUMBER_CRUMB = "0"
                  

                  
                  
                  VAR_HCAPTCHA_INVISIBLE = parseInt(VAR_HCAPTCHA_INVISIBLE) + parseInt(2)
                  

                  
                  
                  VAR_ERROR_CAPTCHA_UNSOLVABLE_MODULE = parseInt(VAR_ERROR_CAPTCHA_UNSOLVABLE_MODULE) + parseInt(1)
                  

                  
                  
                  /*Browser*/
                  ;_SELECTOR=VAR_HCAPTCHA_PREFIX_SECOND_FRAME + "\u003eCSS\u003e .refresh";
                  get_element_selector(_SELECTOR, false).nowait().exist()!
                  VAR_IS_EXISTS = _result() == 1
                  _if(VAR_IS_EXISTS, function(){
                  get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
                  VAR_IS_EXISTS = _result().indexOf("true")>=0
                  })!
                  

                  
                  
                  _set_if_expression("W1tJU19FWElTVFNdXQ==");
                  _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
                  
                     
                     
                     /*Browser*/
                     cache_data_clear()!
                     

                     
                     
                     /*Browser*/
                     _SELECTOR = VAR_HCAPTCHA_PREFIX_SECOND_FRAME + "\u003eCSS\u003e .refresh";
                     wait_element_visible(_SELECTOR)!
                     _call(_random_point, {})!
                     _if(_result().length > 0, function(){
                     move( {} )!
                     get_element_selector(_SELECTOR, false).clarify(X,Y)!
                     _call(_clarify, {} )!
                     mouse(X,Y)!
                     })!
                     

                  })!
                  

                  
                  
                  sleep(rand(600,950))!
                  

                  
                  
                  _break("function")
                  

               })!
               delete _cycle_params().if_else;
               

            })!
            

         },null)!
         

         
         
         _set_if_expression("W1tXQVNfRVJST1JdXQ==");
         _if(typeof(VAR_WAS_ERROR) !== "undefined" ? (VAR_WAS_ERROR) : undefined,function(){
         
            
            
            sleep(1000)!
            

         })!
         

         
         
         _next("function")
         

      })!
      

   }
   

function CaptchaImageClick_ReCaptcha2()
   {
   
      
      
      VAR_GLOBAL_SELECTOR = _function_argument("SELECTOR")
      

      
      
      VAR_SPEED_MOUSE = _function_argument("SPEED_MOUSE")
      

      
      
      VAR_KEY_MODULE = _function_argument("KEY")
      

      
      
      VAR_METHOD_MODULE = _function_argument("METHOD")
      

      
      
      VAR_TRY_NUMBER = _function_argument("TRY_NUMBER")
      

      
      
      VAR_NUMBER_CAPTCHA_MODULE = _function_argument("NUMBER_CAPTCHA")
      

      
      
      VAR_IS_INVISIBLE_CAPTCHA = _function_argument("IS_INVISIBLE_CAPTCHA")
      

      
      
      /*Browser*/
      cache_allow("recaptcha/*/payload")!
      

      
      
      VAR_CYCLE_INDEX = 0
      

      
      
      VAR_IS_EXISTS_1 = "false"
      

      
      
      VAR_IS_EXISTS_2 = "false"
      

      
      
      VAR_ERROR_LOAD = "0"
      

      
      
      VAR_ERROR_RECAPTCHA_PAYLOAD = 0
      

      
      
      VAR_ERROR_FIND_MAIN_SELECTOR = "0"
      

      
      
      VAR_RECAPTCHA_2_INVISIBLE = 0
      

      
      
      VAR_RECAPTCHA_PREFIX_SECOND_FRAME = ""
      

      
      
      VAR_ERROR_CAPTCHA_UNSOLVABLE_MODULE = 0
      

      
      
      VAR_ERROR_KEY = "0"
      

      
      
      VAR_ERROR_BALANCE = "0"
      

      
      
      VAR_ERROR_LANG = "0"
      

      
      
      VAR_RESULT_SELECTOR = 0
      

      
      
      VAR_IS_CHANGED_SCROLL_Y = 0
      

      
      
      VAR_ERROR_PICK_IMAGE = 0
      

      
      
      VAR_RECAPTCHA_MODULE_ENABLED = 0
      

      
      
      VAR_HCAPTCHA_MODULE_ENABLED = 0
      

      
      
      VAR_FUNCAPTCHA_MODULE_ENABLED = 0
      

      
      
      VAR_NAME_MODULE_AUTOSUBMIT = "NaN"
      

      
      
      VAR_BAS_CAPMONSTER_IMAGE_ID = 0
      

      
      
      VAR_GREEN_TICK = false
      

      
      
      VAR_BAS_MODULE_VERSION = "5.6"
      

      
      
      _call(function()
      {
      _on_fail(function(){
      VAR_LAST_ERROR = _result()
      VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
      VAR_WAS_ERROR = false
      _break(1,true)
      })
      CYCLES.Current().RemoveLabel("function")
      
         
         
         VAR_SELECTOR_1 = "Y2FwbW9uc3Rlcg=="
         

         
         
         VAR_SELECTOR_2 = "c2VydmVydXJs"
         

      },null)!
      

      
      
      _call(function()
      {
      _on_fail(function(){
      VAR_LAST_ERROR = _result()
      VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
      VAR_WAS_ERROR = false
      _break(1,true)
      })
      CYCLES.Current().RemoveLabel("function")
      
         
         
         //// Проверить установлены ли модули с автосабмитом.
         if (typeof NumbersParseRecaptcha2 === 'function') VAR_RECAPTCHA_MODULE_ENABLED = 1, VAR_NAME_MODULE_AUTOSUBMIT = "ReCaptcha 2 Autosubmit";
         if (typeof BASCaptchaSolver.helpers.HCaptchaHelper === 'function') VAR_HCAPTCHA_MODULE_ENABLED = 1, VAR_NAME_MODULE_AUTOSUBMIT = "hCaptcha Autosubmit";
         if (typeof BASCaptchaSolver.helpers.FunCaptchaHelper === 'function') VAR_FUNCAPTCHA_MODULE_ENABLED = 1, VAR_NAME_MODULE_AUTOSUBMIT = "FunCaptcha Autosubmit";
         

      },null)!
      

      
      
      _set_if_expression("W1tGVU5DQVBUQ0hBX01PRFVMRV9FTkFCTEVEXV0gPT0gMSB8fCBbW1JFQ0FQVENIQV9NT0RVTEVfRU5BQkxFRF1dID09IDEgfHwgW1tIQ0FQVENIQV9NT0RVTEVfRU5BQkxFRF1dID09IDE=");
      _if(VAR_FUNCAPTCHA_MODULE_ENABLED == 1 || VAR_RECAPTCHA_MODULE_ENABLED == 1 || VAR_HCAPTCHA_MODULE_ENABLED == 1,function(){
      
         
         
         fail((_K==="en" ? "Solve the captcha failed, to continue solving captchas by clicks requires to disable module " +VAR_NAME_MODULE_AUTOSUBMIT + " and also remove all actions from the script associated with it and retry solve captcha again" : "Решить капчу не удалось, для продолжения решения капчи кликами требуется отключить сторонний встроенный модуль в BAS: " +VAR_NAME_MODULE_AUTOSUBMIT + ", а также удалить все действия из шаблона связанные с ним и повторить попытку"));
         

      })!
      

      
      
      _set_if_expression("W1tJU19JTlZJU0lCTEVfQ0FQVENIQV1d");
      _if(typeof(VAR_IS_INVISIBLE_CAPTCHA) !== "undefined" ? (VAR_IS_INVISIBLE_CAPTCHA) : undefined,function(){
      
         
         
         /*Browser*/
         waiter_timeout_next(45000)
         wait_load("recaptcha/*/payload")!
         

         
         
         sleep(rand(100,500))!
         

      })!
      

      
      
      _call(function()
      {
      _on_fail(function(){
      VAR_LAST_ERROR = _result()
      VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
      VAR_WAS_ERROR = false
      _break(1,true)
      })
      CYCLES.Current().RemoveLabel("function")
      
         
         
         if (VAR_SPEED_MOUSE == "Slow")
         {
         VAR_SPEED = 100;
         VAR_GRAVITY = 6;
         VAR_DEVIATION = 2.5;
         }
         if (VAR_SPEED_MOUSE == "Normal")
         {
         VAR_SPEED = 200;
         VAR_GRAVITY = 12;
         VAR_DEVIATION = 5;
         }
         if (VAR_SPEED_MOUSE == "Fast")
         {
         VAR_SPEED = 300;
         VAR_GRAVITY = 18;
         VAR_DEVIATION = 7.5;
         }
         if (VAR_SPEED_MOUSE == "Very Fast")
         {
         VAR_SPEED = 400;
         VAR_GRAVITY = 24;
         VAR_DEVIATION = 10;
         }
         if (VAR_SPEED_MOUSE == "Extreme")
         {
         VAR_SPEED = 500;
         VAR_GRAVITY = 30;
         VAR_DEVIATION = 12.5;
         }
         VAR_IS_MOBILE = _IS_MOBILE;
         

         
         
         _set_if_expression("W1tJU19NT0JJTEVdXSA9PSBmYWxzZSAmJiByYW5kICgxLDEwKSA+IDM=");
         _if(VAR_IS_MOBILE == false && rand (1,10) > 3,function(){
         
            
            
            _do(function(){
            _set_action_info({ name: "While" });
            VAR_CYCLE_INDEX = _iterator() - 1
            BREAK_CONDITION = VAR_CYCLE_INDEX < 2;
            if(!BREAK_CONDITION)_break();
            
               
               
               _get_browser_screen_settings()!
               ;(function(){
               var result = JSON.parse(_result())
               VAR_SCROLL_X = result["ScrollX"]
               VAR_SCROLL_Y = result["ScrollY"]
               VAR_CURSOR_X = result["CursorX"]
               VAR_CURSOR_Y = result["CursorY"]
               VAR_BROWSER_WIDTH = result["Width"]
               VAR_BROWSER_HEIGHT = result["Height"]
               })();
               

               
               
               var scroll_x=parseInt(VAR_CURSOR_Y);
               var scroll_y=parseInt(VAR_SCROLL_Y);
               var browser_h=parseInt(VAR_BROWSER_HEIGHT);
               //-------------------- Привели все в числа, считаем позицию ---------------------
               var absolut_y = VAR_CURSOR_Y + VAR_SCROLL_Y;
               var y_without_scroll = absolut_y - VAR_SCROLL_Y;
               var check_y_top = VAR_BROWSER_HEIGHT/12;
               var check_y_down = VAR_BROWSER_HEIGHT/100*92;
               var move_y_top = VAR_BROWSER_HEIGHT/10;
               var move_y_down = VAR_BROWSER_HEIGHT/100*80;
               // -------------------------- Округляем ----------------------------------
               VAR_CHECK_Y_TOP = check_y_top.toFixed();
               VAR_CHECK_Y_DOWN = check_y_down.toFixed();
               VAR_Y_WITHOUNT_SCROLL = y_without_scroll.toFixed();
               VAR_MOVE_Y_TOP = move_y_top.toFixed();
               VAR_MOVE_Y_DOWN = move_y_down.toFixed();
               // ----------------- Снова приводим к числу ------------------------
               VAR_CHECK_Y_TOP=parseInt(VAR_CHECK_Y_TOP);
               VAR_CHECK_Y_DOWN=parseInt(VAR_CHECK_Y_DOWN);
               VAR_Y_WITHOUNT_SCROLL=parseInt(VAR_Y_WITHOUNT_SCROLL);
               VAR_MOVE_Y_TOP=parseInt(VAR_MOVE_Y_TOP);
               VAR_MOVE_Y_DOWN=parseInt(VAR_MOVE_Y_DOWN);
               

               
               
               /*Browser*/
               move(rand(VAR_BROWSER_WIDTH/5,VAR_BROWSER_WIDTH/1.3),rand(VAR_MOVE_Y_TOP + VAR_SCROLL_Y,VAR_MOVE_Y_DOWN + VAR_SCROLL_Y),  {} )!
               

               
               
               _set_if_expression("cmFuZCAoMSwxMCkgPiA1");
               _if(rand (1,10) > 5,function(){
               
                  
                  
                  _break("function")
                  

               })!
               

            })!
            

         })!
         

         
         
         VAR_RECAPTCHA_PREFIX = VAR_GLOBAL_SELECTOR;
         VAR_RECAPTCHA_PREFIX_FIRST_FRAME = VAR_RECAPTCHA_PREFIX;
         {
         var index = VAR_RECAPTCHA_PREFIX.toString().lastIndexOf(">FRAME>")
         if(index >= 0)
         VAR_RECAPTCHA_PREFIX = VAR_RECAPTCHA_PREFIX.substring(0,index)
         VAR_RECAPTCHA_PREFIX_FIRST_FRAME = VAR_RECAPTCHA_PREFIX
         index = VAR_RECAPTCHA_PREFIX.toString().lastIndexOf(">FRAME>")
         if(index >= 0)
         VAR_RECAPTCHA_PREFIX = VAR_RECAPTCHA_PREFIX.substring(0,index + ">FRAME>".length)
         else
         VAR_RECAPTCHA_PREFIX = ""
         }
         

         
         
         //// Проверить бан айпи
         get_element_selector(VAR_RECAPTCHA_PREFIX_SECOND_FRAME).script("document.getElementsByClassName('rc-doscaptcha-body-text').length")!
         if(parseInt(_result()) > 0)
         fail((_K==="en" ? "IP address banned Repaptcha 2. Automated queries" : "IP адрес забанен ReСaptсha2 за автоматические запросы"));
         

         
         
         //////// Проверить открылось ли окно капчи (Невидимая рекаптча 2 случай)
         _SELECTOR = VAR_RECAPTCHA_PREFIX_FIRST_FRAME;
         get_element_selector(_SELECTOR).script("(function(){var el = Array.prototype.slice.call(document.getElementsByTagName('iframe')).find(function(el){return(el.src.indexOf('/bframe')>=0 && getComputedStyle(el)['visibility'] == 'visible')});if(el){el=el['name']}else{el=''};return el;})()")!
         if(_result().length>0)
         {
         VAR_RECAPTCHA_PREFIX_SECOND_FRAME = VAR_RECAPTCHA_PREFIX + ">CSS>iframe[name=\"" + _result() + "\"]" + ">AT>" + VAR_NUMBER_CAPTCHA_MODULE + ">FRAME> >CSS> body";
         VAR_RECAPTCHA_PREFIX_SECOND_FRAME_ELEMENT = VAR_RECAPTCHA_PREFIX + ">CSS>iframe[name=\"" + _result() + "\"]" + ">AT>" + VAR_NUMBER_CAPTCHA_MODULE
         }
         

         
         
         _cycle_params().if_else = VAR_RECAPTCHA_PREFIX_SECOND_FRAME == "";
         _set_if_expression("W1tSRUNBUFRDSEFfUFJFRklYX1NFQ09ORF9GUkFNRV1dID09ICIi");
         _if(_cycle_params().if_else,function(){
         
            
            
            _do(function(){
            _set_action_info({ name: "For" });
            VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
            if(VAR_CYCLE_INDEX > parseInt(50))_break();
            
               
               
               /*Browser*/
               ;_SELECTOR=VAR_GLOBAL_SELECTOR;
               get_element_selector(_SELECTOR, false).nowait().exist()!
               VAR_IS_EXISTS = _result() == 1
               _if(VAR_IS_EXISTS, function(){
               get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
               VAR_IS_EXISTS = _result().indexOf("true")>=0
               })!
               

               
               
               _cycle_params().if_else = typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined;
               _set_if_expression("W1tJU19FWElTVFNdXQ==");
               _if(_cycle_params().if_else,function(){
               
                  
                  
                  _cycle_params().if_else = VAR_GLOBAL_SELECTOR == ">CSS>iframe[src*='anchor']>FRAME> >CSS> #recaptcha-anchor-label";
                  _set_if_expression("W1tHTE9CQUxfU0VMRUNUT1JdXSA9PSAiPkNTUz5pZnJhbWVbc3JjKj0nYW5jaG9yJ10+RlJBTUU+ID5DU1M+ICNyZWNhcHRjaGEtYW5jaG9yLWxhYmVsIg==");
                  _if(_cycle_params().if_else,function(){
                  
                     
                     
                     VAR_RANDOM_NUMBER_CLICK = Math.floor(Math.random() * (parseInt(10) - parseInt(1) + 1)) + parseInt(1)
                     

                     
                     
                     _set_if_expression("W1tSQU5ET01fTlVNQkVSX0NMSUNLXV0gPD0gNA==");
                     _if(VAR_RANDOM_NUMBER_CLICK <= 4,function(){
                     
                        
                        
                        /*Browser*/
                        _SELECTOR = VAR_GLOBAL_SELECTOR;waiter_timeout_next(8000)
                        wait_element_visible(_SELECTOR)!
                        _call(_random_point, {})!
                        _if(_result().length > 0, function(){
                        move( {} )!
                        get_element_selector(_SELECTOR, false).clarify(X,Y)!
                        _call(_clarify, {} )!
                        mouse(X,Y)!
                        })!
                        

                     })!
                     

                     
                     
                     _set_if_expression("W1tSQU5ET01fTlVNQkVSX0NMSUNLXV0gPiA0ICYmIFtbUkFORE9NX05VTUJFUl9DTElDS11dIDw9IDc=");
                     _if(VAR_RANDOM_NUMBER_CLICK > 4 && VAR_RANDOM_NUMBER_CLICK <= 7,function(){
                     
                        
                        
                        /*Browser*/
                        _SELECTOR = "\u003eCSS\u003eiframe[src*=\u0027anchor\u0027]\u003eFRAME\u003e \u003eCSS\u003e div[class$=\u0022checkbox-border\u0022]";waiter_timeout_next(8000)
                        wait_element_visible(_SELECTOR)!
                        _call(_random_point, {})!
                        _if(_result().length > 0, function(){
                        move( {} )!
                        get_element_selector(_SELECTOR, false).clarify(X,Y)!
                        _call(_clarify, {} )!
                        mouse(X,Y)!
                        })!
                        

                     })!
                     

                     
                     
                     _set_if_expression("W1tSQU5ET01fTlVNQkVSX0NMSUNLXV0gPiA3");
                     _if(VAR_RANDOM_NUMBER_CLICK > 7,function(){
                     
                        
                        
                        /*Browser*/
                        _SELECTOR = "\u003eCSS\u003eiframe[src*=\u0027anchor\u0027]\u003eFRAME\u003e \u003eCSS\u003e div[class^=\u0022rc-anchor-content\u0022]";waiter_timeout_next(8000)
                        wait_element_visible(_SELECTOR)!
                        _call(_random_point, {})!
                        _if(_result().length > 0, function(){
                        move( {} )!
                        get_element_selector(_SELECTOR, false).clarify(X,Y)!
                        _call(_clarify, {} )!
                        mouse(X,Y)!
                        })!
                        

                     })!
                     

                  })!
                  

                  
                  
                  _if(!_cycle_params().if_else,function(){
                  
                     
                     
                     /*Browser*/
                     _SELECTOR = VAR_GLOBAL_SELECTOR;waiter_timeout_next(8000)
                     wait_element_visible(_SELECTOR)!
                     _call(_random_point, {})!
                     _if(_result().length > 0, function(){
                     move( {} )!
                     get_element_selector(_SELECTOR, false).clarify(X,Y)!
                     _call(_clarify, {} )!
                     mouse(X,Y)!
                     })!
                     

                  })!
                  delete _cycle_params().if_else;
                  

                  
                  
                  _break("function")
                  

               })!
               

               
               
               _if(!_cycle_params().if_else,function(){
               
                  
                  
                  sleep(rand(500,1000))!
                  

               })!
               delete _cycle_params().if_else;
               

               
               
               _set_if_expression("IVtbSVNfRVhJU1RTXV0=");
               _if(!VAR_IS_EXISTS,function(){
               
                  
                  
                  _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gcmFuZCAoNDIsNDgp");
                  _if(VAR_CYCLE_INDEX > rand (42,48),function(){
                  
                     
                     
                     VAR_ERROR_FIND_MAIN_SELECTOR = "1"
                     

                  })!
                  

               })!
               

            })!
            

         })!
         

         
         
         _if(!_cycle_params().if_else,function(){
         
            
            
            VAR_RECAPTCHA_2_INVISIBLE = 1
            

         })!
         delete _cycle_params().if_else;
         

      },null)!
      

      
      
      _set_if_expression("W1tXQVNfRVJST1JdXQ==");
      _if(typeof(VAR_WAS_ERROR) !== "undefined" ? (VAR_WAS_ERROR) : undefined,function(){
      
         
         
         /*Browser*/
         cache_data_clear()!
         

         
         
         fail(VAR_LAST_ERROR)
         

      })!
      

      
      
      _set_if_expression("W1tFUlJPUl9GSU5EX01BSU5fU0VMRUNUT1JdXSA9PSAx");
      _if(VAR_ERROR_FIND_MAIN_SELECTOR == 1,function(){
      
         
         
         /*Browser*/
         cache_data_clear()!
         

         
         
         fail((_K==="en" ? "Could not wait for the main ReCaptcha 2 selector to load with the 'I am not robot' button" : "Не удалось дождаться загрузки основного селектора ReCaptcha 2 c кнопкой 'Я не робот'"));
         

      })!
      

      
      
      VAR_TRY_CAPTCHA = "0"
      

      
      
      VAR_RECAPTCHA_2_CLOSED = "0"
      

      
      
      VAR_CAPTCHA_FAIL = "0"
      

      
      
      VAR_ERROR_LOAD = "0"
      

      
      
      VAR_COORDINATES_ALDREADY_GET_4X4 = "0"
      

      
      
      VAR_COORDINATES_ALDREADY_GET_3X3 = "0"
      

      
      
      VAR_FIRST_LOAD_CAPTCHA = true
      

      
      
      VAR_FIRST_LOAD_BUTTON = true
      

      
      
      /// Селектор который передал юзер модулю приведем в нормальный вид
      get_selector_normal = function(s) {
      var e={},i,b=0,c,x,l=0,a,r='',w=String.fromCharCode,L=s.length;
      var A="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
      for(i=0;i<64;i++){e[A.charAt(i)]=i;}
      for(x=0;x<L;x++){
      c=e[s.charAt(x)];b=(b<<6)+c;l+=6;
      while(l>=8){((a=(b>>>(l-=8))&0xff)||(x<(L-2)))&&(r+=w(a));}
      }
      return r;
      };
      VAR_SELECTOR_1 = get_selector_normal(VAR_SELECTOR_1);
      VAR_SELECTOR_2 = get_selector_normal(VAR_SELECTOR_2);
      

      
      
      _do(function(){
      _set_action_info({ name: "For" });
      VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
      if(VAR_CYCLE_INDEX > parseInt(500))_break();
      
         
         
         VAR_RELOAD_SUCCESS_BUTTON = 0
         

         
         
         VAR_RECAPTCHA_2_CLOSED = 0
         

         
         
         VAR_CYCLE_INDEX = 0
         

         
         
         _set_if_expression("W1tFUlJPUl9MT0FEXV0gPT0gMQ==");
         _if(VAR_ERROR_LOAD == 1,function(){
         
            
            
            /*Browser*/
            cache_data_clear()!
            

            
            
            fail((_K==="en" ? "Error Load frame Recaptcha2" : "Не удалось дождатся открытия окна капчи"));
            

         })!
         

         
         
         _set_if_expression("W1tFUlJPUl9LRVldXSA9PSAx");
         _if(VAR_ERROR_KEY == 1,function(){
         
            
            
            /*Browser*/
            cache_data_clear()!
            

            
            
            fail((_K==="en" ? "API secret key from captcha recognition service is wrong ERROR_WRONG_USER_KEY" : "Секретный ключ API от сервиса распознавания капчи неподходит ERROR_WRONG_USER_KEY"));
            

         })!
         

         
         
         _set_if_expression("W1tFUlJPUl9CQUxBTkNFXV0gPT0gMQ==");
         _if(VAR_ERROR_BALANCE == 1,function(){
         
            
            
            /*Browser*/
            cache_data_clear()!
            

            
            
            fail((_K==="en" ? "The balance on the captcha service has ended - ERROR_ZERO_BALANCE" : "Закончился баланс на сервисе распознавания капчи - ERROR_ZERO_BALANCE"));
            

         })!
         

         
         
         _set_if_expression("W1tDQVBUQ0hBX0ZBSUxdXSA+IDE=");
         _if(VAR_CAPTCHA_FAIL > 1,function(){
         
            
            
            /*Browser*/
            cache_data_clear()!
            

            
            
            fail((_K==="en" ? "Failed to solve ReCaptcha 2, reason - " +VAR_SAVED_CONTENT : "Не удалось решить ReCaptcha 2, причина - " +VAR_SAVED_CONTENT));
            

         })!
         

         
         
         _set_if_expression("W1tFUlJPUl9DQVBUQ0hBX1VOU09MVkFCTEVfTU9EVUxFXV0gPiAx");
         _if(VAR_ERROR_CAPTCHA_UNSOLVABLE_MODULE > 1,function(){
         
            
            
            /*Browser*/
            cache_data_clear()!
            

            
            
            sleep(100)!
            

            
            
            fail((_K==="en" ? "Task or image type is not supported service CaptchaGuru, reason: ERROR_CAPTCHA_UNSOLVABLE" : "Решить ReCaptcha 2 не удалось - сервис CaptchaGuru не смог распознать несколько изображений подряд, причина: ERROR_CAPTCHA_UNSOLVABLE"));
            

         })!
         

         
         
         _do(function(){
         _set_action_info({ name: "For" });
         VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
         if(VAR_CYCLE_INDEX > parseInt(450))_break();
         
            
            
            /*Browser*/
            ;_SELECTOR=VAR_RECAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eXPATH\u003e //*[@id=\u0022recaptcha-anchor\u0022][@aria-checked=\u0022true\u0022]";
            get_element_selector(_SELECTOR, false).nowait().exist()!
            VAR_IS_EXISTS = _result() == 1
            

            
            
            _set_if_expression("W1tJU19FWElTVFNdXSA9PSB0cnVlICYmIFtbUkVTVUxUX1NFTEVDVE9SXV0gIT0gMQ==");
            _if(VAR_IS_EXISTS == true && VAR_RESULT_SELECTOR != 1,function(){
            
               
               
               VAR_GREEN_TICK = true
               

               
               
               /*Browser*/
               cache_data_clear()!
               

               
               
               _break("function")
               

            })!
            

            
            
            _set_if_expression("W1tGSVJTVF9MT0FEX0NBUFRDSEFdXSA9PSBmYWxzZSAmJiByYW5kICgxLDEwKSA+IDYgJiYgIShbW01FVEhPRF9NT0RVTEVdXS5jaGFyQXQoMCkgPT09ICJDIik=");
            _if(VAR_FIRST_LOAD_CAPTCHA == false && rand (1,10) > 6 && !(VAR_METHOD_MODULE.charAt(0) === "C"),function(){
            
               
               
               VAR_GREEN_TICK = true
               

               
               
               /*Browser*/
               cache_data_clear()!
               

               
               
               _break("function")
               

            })!
            

            
            
            _set_if_expression("W1tSRUNBUFRDSEFfMl9JTlZJU0lCTEVdXSA9PSAwICYmIFtbRklSU1RfTE9BRF9DQVBUQ0hBXV0gPT0gZmFsc2UgJiYgW1tSRVNVTFRfU0VMRUNUT1JdXSAhPSAx");
            _if(VAR_RECAPTCHA_2_INVISIBLE == 0 && VAR_FIRST_LOAD_CAPTCHA == false && VAR_RESULT_SELECTOR != 1,function(){
            
               
               
               /*Browser*/
               ;_SELECTOR=VAR_RECAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eXPATH\u003e //*[@id=\u0022recaptcha-anchor\u0022]";
               get_element_selector(_SELECTOR, false).nowait().exist()!
               VAR_IS_EXISTS = _result() == 1
               

               
               
               _set_if_expression("W1tJU19FWElTVFNdXSA9PSBmYWxzZSAmJiBbW1JFU1VMVF9TRUxFQ1RPUl1dICE9IDE=");
               _if(VAR_IS_EXISTS == false && VAR_RESULT_SELECTOR != 1,function(){
               
                  
                  
                  VAR_GREEN_TICK = true
                  

                  
                  
                  /*Browser*/
                  cache_data_clear()!
                  

                  
                  
                  _break("function")
                  

               })!
               

            })!
            

            
            
            _set_if_expression("W1tSRUNBUFRDSEFfMl9JTlZJU0lCTEVdXSA+IDAgJiYgW1tGSVJTVF9MT0FEX0NBUFRDSEFdXSA9PSBmYWxzZSAmJiBbW1JFU1VMVF9TRUxFQ1RPUl1dICE9IDE=");
            _if(VAR_RECAPTCHA_2_INVISIBLE > 0 && VAR_FIRST_LOAD_CAPTCHA == false && VAR_RESULT_SELECTOR != 1,function(){
            
               
               
               /*Browser*/
               ;_SELECTOR=VAR_RECAPTCHA_PREFIX_SECOND_FRAME + "\u003eXPATH\u003e id(\u0022rc-imageselect-target\u0022)";
               get_element_selector(_SELECTOR, false).nowait().exist()!
               VAR_IS_EXISTS = _result() == 1
               _if(VAR_IS_EXISTS, function(){
               get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
               VAR_IS_EXISTS = _result().indexOf("true")>=0
               })!
               

               
               
               _set_if_expression("W1tJU19FWElTVFNdXSA9PSBmYWxzZQ==");
               _if(VAR_IS_EXISTS == false,function(){
               
                  
                  
                  VAR_GREEN_TICK = true
                  

                  
                  
                  _set_if_expression("W1tJU19JTlZJU0lCTEVfQ0FQVENIQV1dID09IGZhbHNl");
                  _if(VAR_IS_INVISIBLE_CAPTCHA == false,function(){
                  
                     
                     
                     /*Browser*/
                     cache_data_clear()!
                     

                  })!
                  

                  
                  
                  _break("function")
                  

               })!
               

               
               
               _set_if_expression("W1tJU19FWElTVFNdXSA9PSB0cnVlICYmIFtbQ1lDTEVfSU5ERVhdXSA+PSAz");
               _if(VAR_IS_EXISTS == true && VAR_CYCLE_INDEX >= 3,function(){
               
                  
                  
                  /*Browser*/
                  _SELECTOR = VAR_RECAPTCHA_PREFIX_SECOND_FRAME + "\u003eXPATH\u003e id(\u0022rc-imageselect-target\u0022)";
                  wait_element(_SELECTOR)!
                  get_element_selector(_SELECTOR, false).script("(function(){var rect = _BAS_HIDE(BrowserAutomationStudio_GetBoundingClientRect)(self);return (rect.left + positionx) + '|' + (rect.top + positiony) + '|' + (rect.right - rect.left) + '|' + (rect.bottom - rect.top)})();")!
                  if(_result().length > 0)
                  {
                  var split = _result().split("|")
                  VAR_X_MODULE = parseInt(split[0])
                  VAR_Y_MODULE = parseInt(split[1])
                  VAR_WIDTH_MODULE = parseInt(split[2])
                  VAR_HEIGHT_MODULE = parseInt(split[3])
                  }
                  

                  
                  
                  _set_if_expression("W1tZX01PRFVMRV1dIDwgLTEwMDA=");
                  _if(VAR_Y_MODULE < -1000,function(){
                  
                     
                     
                     VAR_GREEN_TICK = true
                     

                     
                     
                     _set_if_expression("W1tJU19JTlZJU0lCTEVfQ0FQVENIQV1dID09IGZhbHNl");
                     _if(VAR_IS_INVISIBLE_CAPTCHA == false,function(){
                     
                        
                        
                        /*Browser*/
                        cache_data_clear()!
                        

                     })!
                     

                     
                     
                     _break("function")
                     

                  })!
                  

               })!
               

            })!
            

            
            
            //////// Проверить открылось ли окно капчи
            _SELECTOR = VAR_RECAPTCHA_PREFIX_FIRST_FRAME;
            get_element_selector(_SELECTOR).script("(function(){var el = Array.prototype.slice.call(document.getElementsByTagName('iframe')).find(function(el){return(el.src.indexOf('/bframe')>=0 && getComputedStyle(el)['visibility'] == 'visible')});if(el){el=el['name']}else{el=''};return el;})()")!
            if(_result().length>0)
            {
            VAR_RECAPTCHA_PREFIX_SECOND_FRAME = VAR_RECAPTCHA_PREFIX + ">CSS>iframe[name=\"" + _result() + "\"]" + ">AT>" + VAR_NUMBER_CAPTCHA_MODULE + ">FRAME> >CSS> body";
            VAR_RECAPTCHA_PREFIX_SECOND_FRAME_ELEMENT = VAR_RECAPTCHA_PREFIX + ">CSS>iframe[name=\"" + _result() + "\"]" + ">AT>" + VAR_NUMBER_CAPTCHA_MODULE
            _break()
            }
            

            
            
            /*Browser*/
            ;_SELECTOR=VAR_RECAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eXPATH\u003e id(\u0022rc-anchor-container\u0022)/div[@class=\u0022rc-anchor-error-msg-container\u0022]";
            get_element_selector(_SELECTOR, false).nowait().exist()!
            VAR_IS_EXISTS = _result() == 1
            _if(VAR_IS_EXISTS, function(){
            get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
            VAR_IS_EXISTS = _result().indexOf("true")>=0
            })!
            

            
            
            _set_if_expression("W1tJU19FWElTVFNdXSAmJiBbW0ZJUlNUX0xPQURfQ0FQVENIQV1dID09IGZhbHNl");
            _if(VAR_IS_EXISTS && VAR_FIRST_LOAD_CAPTCHA == false,function(){
            
               
               
               /*Browser*/
               _SELECTOR = VAR_RECAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eXPATH\u003e id(\u0022rc-anchor-container\u0022)/div[@class=\u0022rc-anchor-error-msg-container\u0022]";
               wait_element(_SELECTOR)!
               get_element_selector(_SELECTOR, false).text()!
               VAR_SAVED_TEXT = _result()
               

               
               
               /*Browser*/
               cache_data_clear()!
               

               
               
               fail(VAR_SAVED_TEXT)
               

            })!
            

            
            
            _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gOA==");
            _if(VAR_CYCLE_INDEX > 8,function(){
            
               
               
               //// Проверить бан айпи
               get_element_selector(VAR_RECAPTCHA_PREFIX_SECOND_FRAME).script("document.getElementsByClassName('rc-doscaptcha-body-text').length")!
               if(parseInt(_result()) > 0)
               fail((_K==="en" ? "IP address banned Repaptcha 2. Automated queries" : "IP адрес забанен ReСaptсha2 за автоматические запросы"));
               

            })!
            

            
            
            _set_if_expression("W1tDWUNMRV9JTkRFWF1dID09IDI0IHx8IFtbQ1lDTEVfSU5ERVhdXSA9PSA0OA==");
            _if(VAR_CYCLE_INDEX == 24 || VAR_CYCLE_INDEX == 48,function(){
            
               
               
               sleep(rand(1000,3000))!
               

               
               
               _set_if_expression("W1tSRVNVTFRfU0VMRUNUT1JdXSAhPSAx");
               _if(VAR_RESULT_SELECTOR != 1,function(){
               
                  
                  
                  sleep(10000)!
                  

               })!
               

            })!
            

            
            
            _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gMjggJiYgW1tSRUNBUFRDSEFfMl9JTlZJU0lCTEVdXSA9PSAwICYmIFtbRklSU1RfTE9BRF9CVVRUT05dXSA9PSB0cnVlICYmIFtbUkVTVUxUX1NFTEVDVE9SXV0gIT0gMQ==");
            _if(VAR_CYCLE_INDEX > 28 && VAR_RECAPTCHA_2_INVISIBLE == 0 && VAR_FIRST_LOAD_BUTTON == true && VAR_RESULT_SELECTOR != 1,function(){
            
               
               
               VAR_FIRST_LOAD_BUTTON = false
               

               
               
               /*Browser*/
               ;_SELECTOR=VAR_GLOBAL_SELECTOR;
               get_element_selector(_SELECTOR, false).nowait().exist()!
               VAR_IS_EXISTS = _result() == 1
               _if(VAR_IS_EXISTS, function(){
               get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
               VAR_IS_EXISTS = _result().indexOf("true")>=0
               })!
               

               
               
               _set_if_expression("W1tJU19FWElTVFNdXQ==");
               _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
               
                  
                  
                  /*Browser*/
                  _SELECTOR = VAR_GLOBAL_SELECTOR;waiter_timeout_next(8000)
                  wait_element_visible(_SELECTOR)!
                  _call(_random_point, {})!
                  _if(_result().length > 0, function(){
                  move( {} )!
                  get_element_selector(_SELECTOR, false).clarify(X,Y)!
                  _call(_clarify, {} )!
                  mouse(X,Y)!
                  })!
                  

                  
                  
                  sleep(rand(2000,4000))!
                  

               })!
               

            })!
            

            
            
            _set_if_expression("W1tDWUNMRV9JTkRFWF1dID49IDMyICYmIFtbRklSU1RfTE9BRF9DQVBUQ0hBXV0gPT0gZmFsc2UgJiYgW1tSRVNVTFRfU0VMRUNUT1JdXSAhPSAx");
            _if(VAR_CYCLE_INDEX >= 32 && VAR_FIRST_LOAD_CAPTCHA == false && VAR_RESULT_SELECTOR != 1,function(){
            
               
               
               /*Browser*/
               cache_data_clear()!
               

               
               
               fail((_K==="en" ? "Failed to solve the ReCaptcha. The captcha window is closed." : "Решить ReCaptcha 2 не удалось. Окно с капчей не было открыто."));
               

            })!
            

            
            
            _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gNjUgJiYgW1tGSVJTVF9MT0FEX0NBUFRDSEFdXSA9PSB0cnVlICYmIFtbUkVTVUxUX1NFTEVDVE9SXV0gIT0gMQ==");
            _if(VAR_CYCLE_INDEX > 65 && VAR_FIRST_LOAD_CAPTCHA == true && VAR_RESULT_SELECTOR != 1,function(){
            
               
               
               /*Browser*/
               cache_data_clear()!
               

               
               
               fail((_K==="en" ? "Failed to solve ReCaptcha2. Timeout for opening captcha window with images" : "Не удалось решить ReCaptcha2, слишком долгое ожидание открытия окна каптчи с изображениями"));
               

            })!
            

         })!
         

         
         
         VAR_CYCLE_INDEX = 0
         

         
         
         VAR_FIRST_LOAD_BUTTON = false
         

         
         
         _set_if_expression("W1tHUkVFTl9USUNLXV0gPT0gdHJ1ZQ==");
         _if(VAR_GREEN_TICK == true,function(){
         
            
            
            _function_return("")
            

         })!
         

         
         
         VAR_TRY_CAPTCHA = parseInt(VAR_TRY_CAPTCHA) + parseInt(1)
         

         
         
         _set_if_expression("W1tUUllfQ0FQVENIQV1dID49IFtbVFJZX05VTUJFUl1d");
         _if(VAR_TRY_CAPTCHA >= VAR_TRY_NUMBER,function(){
         
            
            
            sleep(4000)!
            

            
            
            /*Browser*/
            cache_data_clear()!
            

            
            
            /*Browser*/
            ;_SELECTOR=VAR_RECAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eXPATH\u003e //*[@id=\u0022recaptcha-anchor\u0022][@aria-checked=\u0022true\u0022]";
            get_element_selector(_SELECTOR, false).nowait().exist()!
            VAR_IS_EXISTS = _result() == 1
            _if(VAR_IS_EXISTS, function(){
            get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
            VAR_IS_EXISTS = _result().indexOf("true")>=0
            })!
            

            
            
            _set_if_expression("W1tJU19FWElTVFNdXSA9PSB0cnVlICYmIFtbUkVTVUxUX1NFTEVDVE9SXV0gIT0gMQ==");
            _if(VAR_IS_EXISTS == true && VAR_RESULT_SELECTOR != 1,function(){
            
               
               
               _function_return("")
               

            })!
            

            
            
            fail((_K==="en" ? "Failed to solve the captcha. ReCaptcha 2 attempts solve limit exceeded" : "Решить капчу не удалось. Превышен лимит попыток решить ReCaptcha 2"))
            

         })!
         

         
         
         _call(function()
         {
         _on_fail(function(){
         VAR_LAST_ERROR = _result()
         VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
         VAR_WAS_ERROR = false
         _break(1,true)
         })
         CYCLES.Current().RemoveLabel("function")
         
            
            
            /*Browser*/
            ;_SELECTOR=VAR_RECAPTCHA_PREFIX_SECOND_FRAME + "\u003eXPATH\u003e //div[@class=\u0022rc-imageselect-error-select-more\u0022]";
            get_element_selector(_SELECTOR, false).nowait().exist()!
            VAR_IS_EXISTS_1 = _result() == 1
            _if(VAR_IS_EXISTS_1, function(){
            get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
            VAR_IS_EXISTS_1 = _result().indexOf("true")>=0
            })!
            

            
            
            /*Browser*/
            ;_SELECTOR=VAR_RECAPTCHA_PREFIX_SECOND_FRAME + "\u003eXPATH\u003e //div[@class=\u0022rc-imageselect-error-dynamic-more\u0022]";
            get_element_selector(_SELECTOR, false).nowait().exist()!
            VAR_IS_EXISTS_2 = _result() == 1
            _if(VAR_IS_EXISTS_2, function(){
            get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
            VAR_IS_EXISTS_2 = _result().indexOf("true")>=0
            })!
            

            
            
            _set_if_expression("W1tJU19FWElTVFNfMV1dIHx8IFtbSVNfRVhJU1RTXzJdXQ==");
            _if(VAR_IS_EXISTS_1 || VAR_IS_EXISTS_2,function(){
            
               
               
               VAR_BAS_CAPMONSTER_IMAGE_ID = "0"
               

               
               
               _set_if_expression("W1tSRUNBUFRDSEFfMl9JTlZJU0lCTEVdXSA9PSAx");
               _if(VAR_RECAPTCHA_2_INVISIBLE == 1,function(){
               
                  
                  
                  VAR_RECAPTCHA_2_INVISIBLE = parseInt(VAR_RECAPTCHA_2_INVISIBLE) + parseInt(1)
                  

               })!
               

               
               
               /*Browser*/
               cache_data_clear()!
               

               
               
               sleep(500)!
               

               
               
               /*Browser*/
               _SELECTOR = VAR_RECAPTCHA_PREFIX_SECOND_FRAME + "\u003eXPATH\u003e id(\u0022recaptcha-reload-button\u0022)";
               wait_element_visible(_SELECTOR)!
               _call(_random_point, {})!
               _if(_result().length > 0, function(){
               move( {"speed": VAR_SPEED,"gravity": VAR_GRAVITY,"deviation": VAR_DEVIATION} )!
               get_element_selector(_SELECTOR, false).clarify(X,Y)!
               _call(_clarify, {"speed": VAR_SPEED,"gravity": VAR_GRAVITY,"deviation": VAR_DEVIATION} )!
               mouse(X,Y)!
               })!
               

               
               
               _set_if_expression("W1tSRUNBUFRDSEFfMl9JTlZJU0lCTEVdXSA9PSAx");
               _if(VAR_RECAPTCHA_2_INVISIBLE == 1,function(){
               
                  
                  
                  VAR_RECAPTCHA_2_INVISIBLE = parseInt(VAR_RECAPTCHA_2_INVISIBLE) + parseInt(1)
                  

               })!
               

               
               
               sleep(500)!
               

            })!
            

         },null)!
         

         
         
         _set_if_expression("W1tJU19FWElTVFNfMV1dIHx8IFtbSVNfRVhJU1RTXzJdXQ==");
         _if(VAR_IS_EXISTS_1 || VAR_IS_EXISTS_2,function(){
         
            
            
            _next("function")
            

         })!
         

         
         
         _set_if_expression("W1tXQVNfRVJST1JdXQ==");
         _if(typeof(VAR_WAS_ERROR) !== "undefined" ? (VAR_WAS_ERROR) : undefined,function(){
         
            
            
            /*Browser*/
            cache_data_clear()!
            

            
            
            fail(VAR_LAST_ERROR)
            

         })!
         

         
         
         _call(function()
         {
         _on_fail(function(){
         VAR_LAST_ERROR = _result()
         VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
         VAR_WAS_ERROR = false
         _break(1,true)
         })
         CYCLES.Current().RemoveLabel("function")
         
            
            
            _get_browser_screen_settings()!
            ;(function(){
            var result = JSON.parse(_result())
            VAR_SCROLL_X = result["ScrollX"]
            VAR_SCROLL_Y = result["ScrollY"]
            VAR_CURSOR_X = result["CursorX"]
            VAR_CURSOR_Y = result["CursorY"]
            VAR_BROWSER_WIDTH = result["Width"]
            VAR_BROWSER_HEIGHT = result["Height"]
            })();
            

            
            
            _set_if_expression("W1tGSVJTVF9MT0FEX0NBUFRDSEFdXSA9PSB0cnVlICYmIFtbU0NST0xMX1ldXSAhPSAw");
            _if(VAR_FIRST_LOAD_CAPTCHA == true && VAR_SCROLL_Y != 0,function(){
            
               
               
               /*Browser*/
               ;_SELECTOR=VAR_RECAPTCHA_PREFIX_SECOND_FRAME + " \u003eXPATH\u003e //*[@class=\u0022rc-imageselect-table-33\u0022]";
               get_element_selector(_SELECTOR, false).nowait().exist()!
               VAR_IS_EXISTS = _result() == 1
               

               
               
               _set_if_expression("W1tJU19FWElTVFNdXQ==");
               _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
               
                  
                  
                  VAR_RANDOM_NUMBER_SQUARE = Math.floor(Math.random() * (parseInt(12) - parseInt(8) + 1)) + parseInt(8)
                  

                  
                  
                  _set_if_expression("W1tSQU5ET01fTlVNQkVSX1NRVUFSRV1dID09IDg=");
                  _if(VAR_RANDOM_NUMBER_SQUARE == 8,function(){
                  
                     
                     
                     /*Browser*/
                     _SELECTOR = VAR_RECAPTCHA_PREFIX_SECOND_FRAME + " \u003eXPATH\u003e //*[@tabindex=\u00228\u0022]";
                     wait_element_visible(_SELECTOR)!
                     _call(_random_point, {})!
                     _if(_result().length > 0, function(){
                     move( {} )!
                     get_element_selector(_SELECTOR, false).clarify(X,Y)!
                     _call(_clarify, {} )!
                     })!
                     

                  })!
                  

                  
                  
                  _set_if_expression("W1tSQU5ET01fTlVNQkVSX1NRVUFSRV1dID09IDk=");
                  _if(VAR_RANDOM_NUMBER_SQUARE == 9,function(){
                  
                     
                     
                     /*Browser*/
                     _SELECTOR = VAR_RECAPTCHA_PREFIX_SECOND_FRAME + " \u003eXPATH\u003e //*[@tabindex=\u00229\u0022]";
                     wait_element_visible(_SELECTOR)!
                     _call(_random_point, {})!
                     _if(_result().length > 0, function(){
                     move( {} )!
                     get_element_selector(_SELECTOR, false).clarify(X,Y)!
                     _call(_clarify, {} )!
                     })!
                     

                  })!
                  

                  
                  
                  _set_if_expression("W1tSQU5ET01fTlVNQkVSX1NRVUFSRV1dID09IDEw");
                  _if(VAR_RANDOM_NUMBER_SQUARE == 10,function(){
                  
                     
                     
                     /*Browser*/
                     _SELECTOR = VAR_RECAPTCHA_PREFIX_SECOND_FRAME + " \u003eXPATH\u003e //*[@tabindex=\u002210\u0022]";
                     wait_element_visible(_SELECTOR)!
                     _call(_random_point, {})!
                     _if(_result().length > 0, function(){
                     move( {} )!
                     get_element_selector(_SELECTOR, false).clarify(X,Y)!
                     _call(_clarify, {} )!
                     })!
                     

                  })!
                  

                  
                  
                  _set_if_expression("W1tSQU5ET01fTlVNQkVSX1NRVUFSRV1dID09IDEx");
                  _if(VAR_RANDOM_NUMBER_SQUARE == 11,function(){
                  
                     
                     
                     /*Browser*/
                     _SELECTOR = VAR_RECAPTCHA_PREFIX_SECOND_FRAME + " \u003eXPATH\u003e //*[@tabindex=\u002211\u0022]";
                     wait_element_visible(_SELECTOR)!
                     _call(_random_point, {})!
                     _if(_result().length > 0, function(){
                     move( {} )!
                     get_element_selector(_SELECTOR, false).clarify(X,Y)!
                     _call(_clarify, {} )!
                     })!
                     

                  })!
                  

                  
                  
                  _set_if_expression("W1tSQU5ET01fTlVNQkVSX1NRVUFSRV1dID09IDEy");
                  _if(VAR_RANDOM_NUMBER_SQUARE == 12,function(){
                  
                     
                     
                     /*Browser*/
                     _SELECTOR = VAR_RECAPTCHA_PREFIX_SECOND_FRAME + " \u003eXPATH\u003e //*[@tabindex=\u002212\u0022]";
                     wait_element_visible(_SELECTOR)!
                     _call(_random_point, {})!
                     _if(_result().length > 0, function(){
                     move( {} )!
                     get_element_selector(_SELECTOR, false).clarify(X,Y)!
                     _call(_clarify, {} )!
                     })!
                     

                  })!
                  

               })!
               

            })!
            

         },null)!
         

         
         
         VAR_FIRST_LOAD_CAPTCHA = false
         

         
         
         //// Проверить бан айпи
         get_element_selector(VAR_RECAPTCHA_PREFIX_SECOND_FRAME).script("document.getElementsByClassName('rc-doscaptcha-body-text').length")!
         if(parseInt(_result()) > 0)
         fail((_K==="en" ? "IP address banned Repaptcha 2. Automated queries" : "IP адрес забанен ReСaptсha2 за автоматические запросы"))
         

         
         
         _call(function()
         {
         _on_fail(function(){
         VAR_LAST_ERROR = _result()
         VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
         VAR_WAS_ERROR = false
         _break(1,true)
         })
         CYCLES.Current().RemoveLabel("function")
         
            
            
            VAR_CYCLE_INDEX = 0
            

            
            
            _set_if_expression("W1tSRUNBUFRDSEFfMl9JTlZJU0lCTEVdXSA9PSAx");
            _if(VAR_RECAPTCHA_2_INVISIBLE == 1,function(){
            
               
               
               _do(function(){
               _set_action_info({ name: "For" });
               VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
               if(VAR_CYCLE_INDEX > parseInt(60))_break();
               
                  
                  
                  /*Browser*/
                  ;_SELECTOR=VAR_RECAPTCHA_PREFIX_SECOND_FRAME + "\u003eXPATH\u003e id(\u0022rc-imageselect-target\u0022)";
                  get_element_selector(_SELECTOR, false).nowait().exist()!
                  VAR_IS_EXISTS = _result() == 1
                  _if(VAR_IS_EXISTS, function(){
                  get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
                  VAR_IS_EXISTS = _result().indexOf("true")>=0
                  })!
                  

                  
                  
                  _set_if_expression("W1tJU19FWElTVFNdXSA9PSB0cnVl");
                  _if(VAR_IS_EXISTS == true,function(){
                  
                     
                     
                     _break("function")
                     

                  })!
                  

                  
                  
                  _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gNTA=");
                  _if(VAR_CYCLE_INDEX > 50,function(){
                  
                     
                     
                     VAR_ERROR_LOAD = "1"
                     

                  })!
                  

                  
                  
                  sleep(100)!
                  

               })!
               

               
               
               /*Browser*/
               _SELECTOR = VAR_RECAPTCHA_PREFIX_SECOND_FRAME + "\u003eXPATH\u003e id(\u0022rc-imageselect-target\u0022)";
               wait_element(_SELECTOR)!
               get_element_selector(_SELECTOR, false).exist()!
               _if(_result() == "1", function(){
               get_element_selector(_SELECTOR, false).render_base64()!
               VAR_IMAGE_BASE_64 = _result()
               })!
               

            })!
            

            
            
            _set_if_expression("W1tCQVNfQ0FQTU9OU1RFUl9JTUFHRV9JRF1dID09IDAgJiYgW1tSRUNBUFRDSEFfMl9JTlZJU0lCTEVdXSAhPSAx");
            _if(VAR_BAS_CAPMONSTER_IMAGE_ID == 0 && VAR_RECAPTCHA_2_INVISIBLE != 1,function(){
            
               
               
               /*Browser*/
               ;_SELECTOR=VAR_RECAPTCHA_PREFIX_SECOND_FRAME;
               get_element_selector(_SELECTOR, false).nowait().exist()!
               VAR_IS_EXISTS = _result() == 1
               _if(VAR_IS_EXISTS, function(){
               get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
               VAR_IS_EXISTS = _result().indexOf("true")>=0
               })!
               

               
               
               _cycle_params().if_else = typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined;
               _set_if_expression("W1tJU19FWElTVFNdXQ==");
               _if(_cycle_params().if_else,function(){
               
                  
                  
                  VAR_RECAPTCHA_2_CLOSED = 0
                  

                  
                  
                  _do(function(){
                  _set_action_info({ name: "For" });
                  VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
                  if(VAR_CYCLE_INDEX > parseInt(20))_break();
                  
                     
                     
                     /*Browser*/
                     is_load("recaptcha/*/payload")!
                     VAR_SAVED_IS_LOADED = _result()
                     

                     
                     
                     _set_if_expression("W1tTQVZFRF9JU19MT0FERURdXSA9PSAx");
                     _if(VAR_SAVED_IS_LOADED == 1,function(){
                     
                        
                        
                        VAR_ERROR_RECAPTCHA_PAYLOAD = 0
                        

                        
                        
                        _break("function")
                        

                     })!
                     

                     
                     
                     _set_if_expression("W1tFUlJPUl9SRUNBUFRDSEFfUEFZTE9BRF1dID4gNA==");
                     _if(VAR_ERROR_RECAPTCHA_PAYLOAD > 4,function(){
                     
                        
                        
                        VAR_TRY_CAPTCHA = parseInt(VAR_TRY_CAPTCHA) + parseInt(25)
                        

                        
                        
                        VAR_RECAPTCHA_2_CLOSED = 1
                        

                        
                        
                        _break("function")
                        

                     })!
                     

                     
                     
                     _set_if_expression("W1tFUlJPUl9SRUNBUFRDSEFfUEFZTE9BRF1dID4gMg==");
                     _if(VAR_ERROR_RECAPTCHA_PAYLOAD > 2,function(){
                     
                        
                        
                        VAR_BAS_CAPMONSTER_IMAGE_ID = 0
                        

                        
                        
                        _call(function()
                        {
                        _on_fail(function(){
                        VAR_LAST_ERROR = _result()
                        VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
                        VAR_WAS_ERROR = false
                        _break(1,true)
                        })
                        CYCLES.Current().RemoveLabel("function")
                        
                           
                           
                           /*Browser*/
                           ;_SELECTOR=VAR_RECAPTCHA_PREFIX_SECOND_FRAME + "\u003eXPATH\u003e id(\u0022recaptcha-reload-button\u0022)";
                           get_element_selector(_SELECTOR, false).nowait().exist()!
                           VAR_IS_EXISTS = _result() == 1
                           _if(VAR_IS_EXISTS, function(){
                           get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
                           VAR_IS_EXISTS = _result().indexOf("true")>=0
                           })!
                           

                           
                           
                           _set_if_expression("W1tJU19FWElTVFNdXQ==");
                           _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
                           
                              
                              
                              /*Browser*/
                              cache_data_clear()!
                              

                              
                              
                              /*Browser*/
                              _SELECTOR = VAR_RECAPTCHA_PREFIX_SECOND_FRAME + "\u003eXPATH\u003e id(\u0022recaptcha-reload-button\u0022)";
                              wait_element_visible(_SELECTOR)!
                              _call(_random_point, {})!
                              _if(_result().length > 0, function(){
                              move( {"speed": VAR_SPEED,"gravity": VAR_GRAVITY,"deviation": VAR_DEVIATION} )!
                              get_element_selector(_SELECTOR, false).clarify(X,Y)!
                              _call(_clarify, {"speed": VAR_SPEED,"gravity": VAR_GRAVITY,"deviation": VAR_DEVIATION} )!
                              mouse(X,Y)!
                              })!
                              

                              
                              
                              VAR_RECAPTCHA_2_CLOSED = 1
                              

                              
                              
                              _break("function")
                              

                           })!
                           

                        },null)!
                        

                     })!
                     

                     
                     
                     _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gNQ==");
                     _if(VAR_CYCLE_INDEX > 5,function(){
                     
                        
                        
                        /*Browser*/
                        ;_SELECTOR=VAR_RECAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eXPATH\u003e //*[@id=\u0022recaptcha-anchor\u0022][@aria-checked=\u0022true\u0022]";
                        get_element_selector(_SELECTOR, false).nowait().exist()!
                        VAR_IS_EXISTS = _result() == 1
                        _if(VAR_IS_EXISTS, function(){
                        get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
                        VAR_IS_EXISTS = _result().indexOf("true")>=0
                        })!
                        

                        
                        
                        _set_if_expression("W1tJU19FWElTVFNdXSA9PSB0cnVl");
                        _if(VAR_IS_EXISTS == true,function(){
                        
                           
                           
                           VAR_RECAPTCHA_2_CLOSED = 1
                           

                           
                           
                           _break("function")
                           

                        })!
                        

                     })!
                     

                     
                     
                     sleep(100)!
                     

                     
                     
                     _set_if_expression("W1tDWUNMRV9JTkRFWF1dID09IDE5");
                     _if(VAR_CYCLE_INDEX == 19,function(){
                     
                        
                        
                        VAR_ERROR_RECAPTCHA_PAYLOAD = parseInt(VAR_ERROR_RECAPTCHA_PAYLOAD) + parseInt(1)
                        

                        
                        
                        VAR_RECAPTCHA_2_CLOSED = 1
                        

                        
                        
                        _break("function")
                        

                     })!
                     

                  })!
                  

               })!
               

               
               
               _if(!_cycle_params().if_else,function(){
               
                  
                  
                  VAR_RECAPTCHA_2_CLOSED = 1
                  

               })!
               delete _cycle_params().if_else;
               

               
               
               _set_if_expression("W1tSRUNBUFRDSEFfMl9DTE9TRURdXSA9PSAw");
               _if(VAR_RECAPTCHA_2_CLOSED == 0,function(){
               
                  
                  
                  _do(function(){
                  _set_action_info({ name: "For" });
                  VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
                  if(VAR_CYCLE_INDEX > parseInt(100))_break();
                  
                     
                     
                     /*Browser*/
                     ;_SELECTOR=VAR_RECAPTCHA_PREFIX_SECOND_FRAME_ELEMENT;
                     get_element_selector(_SELECTOR, false).nowait().exist()!
                     VAR_IS_EXISTS = _result() == 1
                     _if(VAR_IS_EXISTS, function(){
                     get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
                     VAR_IS_EXISTS = _result().indexOf("true")>=0
                     })!
                     

                     
                     
                     _set_if_expression("IVtbSVNfRVhJU1RTXV0=");
                     _if(!VAR_IS_EXISTS,function(){
                     
                        
                        
                        VAR_RECAPTCHA_2_CLOSED = "1"
                        

                        
                        
                        _break("function")
                        

                     })!
                     

                     
                     
                     cache_get_base64("recaptcha/*/payload")!
                     var image_id = native("imageprocessing", "load", _result())
                     var image_size = native("imageprocessing", "getsize", image_id)
                     var image_w = parseInt(image_size.split(",")[0])
                     var image_h = parseInt(image_size.split(",")[1])
                     VAR_SQUARE_WIDHT = image_w;
                     VAR_SQUARE_HEIGHT = image_h;
                     if (image_h == 0 && VAR_CYCLE_INDEX > rand (35,48)) fail((_K === "en" ? "Failed to wait for ReCaptcha2 image from request cache" : "Не удалось дождаться картинку ReCaptcha2 из кэша запроса"))
                     if (image_h > 99) {
                     VAR_IMAGE_BASE_64 = _result()
                     _break()
                     }
                     sleep(400)!
                     

                  })!
                  

               })!
               

            })!
            

         },null)!
         

         
         
         _set_if_expression("W1tSRUNBUFRDSEFfMl9DTE9TRURdXSA9PSAx");
         _if(VAR_RECAPTCHA_2_CLOSED == 1,function(){
         
            
            
            sleep(rand(100,400))!
            

            
            
            _next("function")
            

         })!
         

         
         
         _set_if_expression("W1tXQVNfRVJST1JdXQ==");
         _if(typeof(VAR_WAS_ERROR) !== "undefined" ? (VAR_WAS_ERROR) : undefined,function(){
         
            
            
            VAR_BAS_CAPMONSTER_IMAGE_ID = 0
            

            
            
            _set_if_expression("W1tSRUNBUFRDSEFfMl9JTlZJU0lCTEVdXSA9PSAx");
            _if(VAR_RECAPTCHA_2_INVISIBLE == 1,function(){
            
               
               
               VAR_RECAPTCHA_2_INVISIBLE = parseInt(VAR_RECAPTCHA_2_INVISIBLE) + parseInt(1)
               

            })!
            

            
            
            _call(function()
            {
            _on_fail(function(){
            VAR_LAST_ERROR = _result()
            VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
            VAR_WAS_ERROR = false
            _break(1,true)
            })
            CYCLES.Current().RemoveLabel("function")
            
               
               
               /*Browser*/
               ;_SELECTOR=VAR_RECAPTCHA_PREFIX_SECOND_FRAME + "\u003eXPATH\u003e id(\u0022recaptcha-reload-button\u0022)";
               get_element_selector(_SELECTOR, false).nowait().exist()!
               VAR_IS_EXISTS = _result() == 1
               _if(VAR_IS_EXISTS, function(){
               get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
               VAR_IS_EXISTS = _result().indexOf("true")>=0
               })!
               

               
               
               _set_if_expression("W1tJU19FWElTVFNdXQ==");
               _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
               
                  
                  
                  /*Browser*/
                  cache_data_clear()!
                  

                  
                  
                  /*Browser*/
                  _SELECTOR = VAR_RECAPTCHA_PREFIX_SECOND_FRAME + "\u003eXPATH\u003e id(\u0022recaptcha-reload-button\u0022)";
                  wait_element_visible(_SELECTOR)!
                  _call(_random_point, {})!
                  _if(_result().length > 0, function(){
                  move( {"speed": VAR_SPEED,"gravity": VAR_GRAVITY,"deviation": VAR_DEVIATION} )!
                  get_element_selector(_SELECTOR, false).clarify(X,Y)!
                  _call(_clarify, {"speed": VAR_SPEED,"gravity": VAR_GRAVITY,"deviation": VAR_DEVIATION} )!
                  mouse(X,Y)!
                  })!
                  

               })!
               

            },null)!
            

            
            
            VAR_RELOAD_SUCCESS_BUTTON = "1"
            

         })!
         

         
         
         _set_if_expression("W1tSRUxPQURfU1VDQ0VTU19CVVRUT05dXSA9PSAx");
         _if(VAR_RELOAD_SUCCESS_BUTTON == 1,function(){
         
            
            
            _next("function")
            

         })!
         

         
         
         _set_if_expression("W1tCQVNfQ0FQTU9OU1RFUl9JTUFHRV9JRF1dID09IDA=");
         _if(VAR_BAS_CAPMONSTER_IMAGE_ID == 0,function(){
         
            
            
            get_element_selector(VAR_RECAPTCHA_PREFIX_SECOND_FRAME).script("document.getElementsByClassName('rc-imageselect-table-44').length")!
            VAR_IS44 = parseInt(_result()) > 0
            get_element_selector(VAR_RECAPTCHA_PREFIX_SECOND_FRAME).script("document.getElementsByClassName('rc-imageselect-table-33').length")!
            VAR_IS33 = parseInt(_result()) > 0
            if(!VAR_IS33 && !VAR_IS44)
            {
            fail((_K==="en" ? "Failed to solve ReCaptcha 2. This captcha type is unknown" : "Не удалось решить ReCaptcha 2, загрузился неизвестный тип каптчи"));
            }
            get_element_selector(VAR_RECAPTCHA_PREFIX_SECOND_FRAME + " strong").text()!
            VAR_CURRENT_TASK = _result();
            VAR_SET_TASK = VAR_CURRENT_TASK;
            

         })!
         

         
         
         _call(function()
         {
         _on_fail(function(){
         VAR_LAST_ERROR = _result()
         VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
         VAR_WAS_ERROR = false
         _break(1,true)
         })
         CYCLES.Current().RemoveLabel("function")
         
            
            
            _get_browser_screen_settings()!
            ;(function(){
            var result = JSON.parse(_result())
            VAR_SCROLL_X = result["ScrollX"]
            VAR_SCROLL_Y = result["ScrollY"]
            VAR_CURSOR_X = result["CursorX"]
            VAR_CURSOR_Y = result["CursorY"]
            VAR_BROWSER_WIDTH = result["Width"]
            VAR_BROWSER_HEIGHT = result["Height"]
            })();
            

            
            
            /*Browser*/
            ;_SELECTOR=VAR_RECAPTCHA_PREFIX_SECOND_FRAME + "\u003eXPATH\u003e//div[@class=\u0022rc-imageselect-incorrect-response\u0022]";
            get_element_selector(_SELECTOR, false).nowait().exist()!
            VAR_ERROR_EXISTS = _result() == 1
            _if(VAR_ERROR_EXISTS, function(){
            get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
            VAR_ERROR_EXISTS = _result().indexOf("true")>=0
            })!
            

            
            
            _set_if_expression("W1tCQVNfQ0FQTU9OU1RFUl9JTUFHRV9JRF1dID09IDAgJiYgW1tDT09SRElOQVRFU19BTERSRUFEWV9HRVRfNFg0XV0gPT0gMCAmJiBbW0lTNDRdXSA9PSB0cnVlIHx8IFtbSVNfQ0hBTkdFRF9TQ1JPTExfWV1dICE9IFtbU0NST0xMX1ldXSAmJiBbW0lTNDRdXSA9PSB0cnVl");
            _if(VAR_BAS_CAPMONSTER_IMAGE_ID == 0 && VAR_COORDINATES_ALDREADY_GET_4X4 == 0 && VAR_IS44 == true || VAR_IS_CHANGED_SCROLL_Y != VAR_SCROLL_Y && VAR_IS44 == true,function(){
            
               
               
               VAR_IS_CHANGED_SCROLL_Y = VAR_SCROLL_Y
               

               
               
               VAR_ELEMENT_SELECTOR = VAR_RECAPTCHA_PREFIX_SECOND_FRAME + "\u003eXPATH\u003e //*[@class=\u0022rc-imageselect-tile\u0022][@tabindex=\u00224\u0022]"
               

               
               
               _SELECTOR = VAR_ELEMENT_SELECTOR;
               get_element_selector(_SELECTOR, false).script("(function(){var rect = self.getBoundingClientRect();return (rect.left + positionx).toString() + '|' + (rect.top + positiony).toString() + '|' + (rect.right - rect.left).toString() + '|' + (rect.bottom - rect.top).toString()})();")!
               var split = _result().split("|");
               var x = parseInt(split[0]), y = parseInt(split[1]), w = parseInt(split[2]), h = parseInt(split[3]);
               _get_browser_screen_settings()!
               var result_recaptcha = JSON.parse(_result());
               var scroll_x = result_recaptcha["ScrollX"], scroll_y = result_recaptcha["ScrollY"]
               var margin_top_bottom = 50; //percent
               var margin_left_top = 50; // percent
               div = 1;
               var x_min = x + w/100*margin_left_top + parseInt(scroll_x), x_max = x+w/div-w/100*margin_left_top + parseInt(scroll_x);
               var y_min = y + h/100*margin_top_bottom + parseInt(scroll_y), y_max = y+h - h/100*margin_top_bottom + parseInt(scroll_y);
               x = rand(x_min, x_max);
               y = rand(y_min, y_max);
               x = x.toFixed();
               y = y.toFixed();
               if (VAR_IS33 == true)
               {
               /// Первый квадрат
               VAR_FIRST_PIC_X = parseInt(x);
               VAR_FIRST_PIC_Y = parseInt(y);
               // Второй и т.д.
               VAR_SECOND_PIC_X = VAR_FIRST_PIC_X + w;
               VAR_SECOND_PIC_Y = VAR_FIRST_PIC_Y;
               VAR_THIRD_PIC_X = VAR_SECOND_PIC_X + w;
               VAR_THIRD_PIC_Y = VAR_FIRST_PIC_Y;
               VAR_FOUR_PIC_X = VAR_FIRST_PIC_X
               VAR_FOUR_PIC_Y = VAR_FIRST_PIC_Y + h;
               VAR_FIVE_PIC_X = VAR_SECOND_PIC_X
               VAR_FIVE_PIC_Y = VAR_SECOND_PIC_Y + h;
               VAR_SIX_PIC_X = VAR_THIRD_PIC_X;
               VAR_SIX_PIC_Y = VAR_THIRD_PIC_Y + h;
               VAR_SEVEN_PIC_X = VAR_FOUR_PIC_X;
               VAR_SEVEN_PIC_Y = VAR_FOUR_PIC_Y + h;
               VAR_EIGHT_PIC_X = VAR_FIVE_PIC_X
               VAR_EIGHT_PIC_Y = VAR_FIVE_PIC_Y + h;
               VAR_NINE_PIC_X = VAR_SIX_PIC_X
               VAR_NINE_PIC_Y = VAR_SIX_PIC_Y + h;
               }
               if (VAR_IS44 == true)
               {
               /// Первый квадрат
               VAR_FIRST_PIC_X = parseInt(x);
               VAR_FIRST_PIC_Y = parseInt(y);
               // Второй и т.д.
               VAR_SECOND_PIC_X = VAR_FIRST_PIC_X + w;
               VAR_SECOND_PIC_Y = VAR_FIRST_PIC_Y;
               VAR_THIRD_PIC_X = VAR_SECOND_PIC_X + w;
               VAR_THIRD_PIC_Y = VAR_FIRST_PIC_Y;
               VAR_FOUR_PIC_X = VAR_THIRD_PIC_X + w;
               VAR_FOUR_PIC_Y = VAR_FIRST_PIC_Y
               VAR_FIVE_PIC_X = VAR_FIRST_PIC_X
               VAR_FIVE_PIC_Y = VAR_SECOND_PIC_Y + h;
               VAR_SIX_PIC_X = VAR_SECOND_PIC_X;
               VAR_SIX_PIC_Y = VAR_SECOND_PIC_Y + h;
               VAR_SEVEN_PIC_X = VAR_THIRD_PIC_X;
               VAR_SEVEN_PIC_Y = VAR_THIRD_PIC_Y + h;
               VAR_EIGHT_PIC_X = VAR_FOUR_PIC_X
               VAR_EIGHT_PIC_Y = VAR_FOUR_PIC_Y + h;
               VAR_NINE_PIC_X = VAR_FIVE_PIC_X
               VAR_NINE_PIC_Y = VAR_FIVE_PIC_Y + h;
               VAR_TEN_PIC_X = VAR_SIX_PIC_X
               VAR_TEN_PIC_Y = VAR_SIX_PIC_Y + h;
               VAR_ELEVEN_PIC_X = VAR_SEVEN_PIC_X
               VAR_ELEVEN_PIC_Y = VAR_SEVEN_PIC_Y + h;
               VAR_TWELVE_PIC_X = VAR_EIGHT_PIC_X
               VAR_TWELVE_PIC_Y = VAR_EIGHT_PIC_Y + h;
               VAR_THIRTEEN_PIC_X = VAR_NINE_PIC_X
               VAR_THIRTEEN_PIC_Y = VAR_NINE_PIC_Y + h;
               VAR_FOURTEEN_PIC_X = VAR_TEN_PIC_X
               VAR_FOURTEEN_PIC_Y = VAR_TEN_PIC_Y + h;
               VAR_FIVETEEN_PIC_X = VAR_ELEVEN_PIC_X
               VAR_FIVETEEN_PIC_Y = VAR_ELEVEN_PIC_Y + h;
               VAR_SIXTEEN_PIC_X = VAR_TWELVE_PIC_X
               VAR_SIXTEEN_PIC_Y = VAR_TWELVE_PIC_Y + h;
               }
               

               
               
               VAR_COORDINATES_ALDREADY_GET_4X4 = "1"
               

               
               
               VAR_COORDINATES_ALDREADY_GET_3X3 = "0"
               

            })!
            

            
            
            _set_if_expression("W1tCQVNfQ0FQTU9OU1RFUl9JTUFHRV9JRF1dID09IDAgJiYgW1tDT09SRElOQVRFU19BTERSRUFEWV9HRVRfM1gzXV0gPT0gMCAmJiBbW0lTMzNdXSA9PSB0cnVlIHx8IFtbSVNfQ0hBTkdFRF9TQ1JPTExfWV1dICE9IFtbU0NST0xMX1ldXSAmJiBbW0lTMzNdXSA9PSB0cnVl");
            _if(VAR_BAS_CAPMONSTER_IMAGE_ID == 0 && VAR_COORDINATES_ALDREADY_GET_3X3 == 0 && VAR_IS33 == true || VAR_IS_CHANGED_SCROLL_Y != VAR_SCROLL_Y && VAR_IS33 == true,function(){
            
               
               
               VAR_IS_CHANGED_SCROLL_Y = VAR_SCROLL_Y
               

               
               
               VAR_ELEMENT_SELECTOR = VAR_RECAPTCHA_PREFIX_SECOND_FRAME + "\u003eXPATH\u003e //*[@class=\u0022rc-imageselect-tile\u0022][@tabindex=\u00224\u0022]"
               

               
               
               _SELECTOR = VAR_ELEMENT_SELECTOR;
               get_element_selector(_SELECTOR, false).script("(function(){var rect = self.getBoundingClientRect();return (rect.left + positionx).toString() + '|' + (rect.top + positiony).toString() + '|' + (rect.right - rect.left).toString() + '|' + (rect.bottom - rect.top).toString()})();")!
               var split = _result().split("|");
               var x = parseInt(split[0]), y = parseInt(split[1]), w = parseInt(split[2]), h = parseInt(split[3]);
               _get_browser_screen_settings()!
               var result_recaptcha = JSON.parse(_result());
               var scroll_x = result_recaptcha["ScrollX"], scroll_y = result_recaptcha["ScrollY"]
               var margin_top_bottom = 50; //percent
               var margin_left_top = 50; // percent
               div = 1;
               var x_min = x + w/100*margin_left_top + parseInt(scroll_x), x_max = x+w/div-w/100*margin_left_top + parseInt(scroll_x);
               var y_min = y + h/100*margin_top_bottom + parseInt(scroll_y), y_max = y+h - h/100*margin_top_bottom + parseInt(scroll_y);
               x = rand(x_min, x_max);
               y = rand(y_min, y_max);
               x = x.toFixed();
               y = y.toFixed();
               if (VAR_IS33 == true)
               {
               /// Первый квадрат
               VAR_FIRST_PIC_X = parseInt(x);
               VAR_FIRST_PIC_Y = parseInt(y);
               // Второй и т.д.
               VAR_SECOND_PIC_X = VAR_FIRST_PIC_X + w;
               VAR_SECOND_PIC_Y = VAR_FIRST_PIC_Y;
               VAR_THIRD_PIC_X = VAR_SECOND_PIC_X + w;
               VAR_THIRD_PIC_Y = VAR_FIRST_PIC_Y;
               VAR_FOUR_PIC_X = VAR_FIRST_PIC_X
               VAR_FOUR_PIC_Y = VAR_FIRST_PIC_Y + h;
               VAR_FIVE_PIC_X = VAR_SECOND_PIC_X
               VAR_FIVE_PIC_Y = VAR_SECOND_PIC_Y + h;
               VAR_SIX_PIC_X = VAR_THIRD_PIC_X;
               VAR_SIX_PIC_Y = VAR_THIRD_PIC_Y + h;
               VAR_SEVEN_PIC_X = VAR_FOUR_PIC_X;
               VAR_SEVEN_PIC_Y = VAR_FOUR_PIC_Y + h;
               VAR_EIGHT_PIC_X = VAR_FIVE_PIC_X
               VAR_EIGHT_PIC_Y = VAR_FIVE_PIC_Y + h;
               VAR_NINE_PIC_X = VAR_SIX_PIC_X
               VAR_NINE_PIC_Y = VAR_SIX_PIC_Y + h;
               }
               if (VAR_IS44 == true)
               {
               /// Первый квадрат
               VAR_FIRST_PIC_X = parseInt(x);
               VAR_FIRST_PIC_Y = parseInt(y);
               // Второй и т.д.
               VAR_SECOND_PIC_X = VAR_FIRST_PIC_X + w;
               VAR_SECOND_PIC_Y = VAR_FIRST_PIC_Y;
               VAR_THIRD_PIC_X = VAR_SECOND_PIC_X + w;
               VAR_THIRD_PIC_Y = VAR_FIRST_PIC_Y;
               VAR_FOUR_PIC_X = VAR_THIRD_PIC_X + w;
               VAR_FOUR_PIC_Y = VAR_FIRST_PIC_Y
               VAR_FIVE_PIC_X = VAR_FIRST_PIC_X
               VAR_FIVE_PIC_Y = VAR_SECOND_PIC_Y + h;
               VAR_SIX_PIC_X = VAR_SECOND_PIC_X;
               VAR_SIX_PIC_Y = VAR_SECOND_PIC_Y + h;
               VAR_SEVEN_PIC_X = VAR_THIRD_PIC_X;
               VAR_SEVEN_PIC_Y = VAR_THIRD_PIC_Y + h;
               VAR_EIGHT_PIC_X = VAR_FOUR_PIC_X
               VAR_EIGHT_PIC_Y = VAR_FOUR_PIC_Y + h;
               VAR_NINE_PIC_X = VAR_FIVE_PIC_X
               VAR_NINE_PIC_Y = VAR_FIVE_PIC_Y + h;
               VAR_TEN_PIC_X = VAR_SIX_PIC_X
               VAR_TEN_PIC_Y = VAR_SIX_PIC_Y + h;
               VAR_ELEVEN_PIC_X = VAR_SEVEN_PIC_X
               VAR_ELEVEN_PIC_Y = VAR_SEVEN_PIC_Y + h;
               VAR_TWELVE_PIC_X = VAR_EIGHT_PIC_X
               VAR_TWELVE_PIC_Y = VAR_EIGHT_PIC_Y + h;
               VAR_THIRTEEN_PIC_X = VAR_NINE_PIC_X
               VAR_THIRTEEN_PIC_Y = VAR_NINE_PIC_Y + h;
               VAR_FOURTEEN_PIC_X = VAR_TEN_PIC_X
               VAR_FOURTEEN_PIC_Y = VAR_TEN_PIC_Y + h;
               VAR_FIVETEEN_PIC_X = VAR_ELEVEN_PIC_X
               VAR_FIVETEEN_PIC_Y = VAR_ELEVEN_PIC_Y + h;
               VAR_SIXTEEN_PIC_X = VAR_TWELVE_PIC_X
               VAR_SIXTEEN_PIC_Y = VAR_TWELVE_PIC_Y + h;
               }
               

               
               
               VAR_COORDINATES_ALDREADY_GET_4X4 = "0"
               

               
               
               VAR_COORDINATES_ALDREADY_GET_3X3 = "1"
               

            })!
            

         },null)!
         

         
         
         _set_if_expression("W1tXQVNfRVJST1JdXQ==");
         _if(typeof(VAR_WAS_ERROR) !== "undefined" ? (VAR_WAS_ERROR) : undefined,function(){
         
            
            
            _next("function")
            

         })!
         

         
         
         _call(function()
         {
         _on_fail(function(){
         VAR_LAST_ERROR = _result()
         VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
         VAR_WAS_ERROR = false
         _break(1,true)
         })
         CYCLES.Current().RemoveLabel("function")
         
            
            
            _set_if_expression("W1tJU19NT0JJTEVdXSA9PT0gZmFsc2UgJiYgcmFuZCAoMSwxMCkgPiAzICYmIFtbQkFTX0NBUE1PTlNURVJfSU1BR0VfSURdXSA9PSAw");
            _if(VAR_IS_MOBILE === false && rand (1,10) > 3 && VAR_BAS_CAPMONSTER_IMAGE_ID == 0,function(){
            
               
               
               _get_browser_screen_settings()!
               ;(function(){
               var result = JSON.parse(_result())
               VAR_SCROLL_X = result["ScrollX"]
               VAR_SCROLL_Y = result["ScrollY"]
               VAR_CURSOR_X = result["CursorX"]
               VAR_CURSOR_Y = result["CursorY"]
               VAR_BROWSER_WIDTH = result["Width"]
               VAR_BROWSER_HEIGHT = result["Height"]
               })();
               

               
               
               /*Browser*/
               ;_SELECTOR=VAR_RECAPTCHA_PREFIX_SECOND_FRAME + "\u003eXPATH\u003e id(\u0022rc-imageselect-target\u0022)";
               get_element_selector(_SELECTOR, false).nowait().exist()!
               VAR_IS_EXISTS = _result() == 1
               _if(VAR_IS_EXISTS, function(){
               get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
               VAR_IS_EXISTS = _result().indexOf("true")>=0
               })!
               

               
               
               _set_if_expression("IVtbSVNfRVhJU1RTXV0=");
               _if(!VAR_IS_EXISTS,function(){
               
                  
                  
                  VAR_RECAPTCHA_2_CLOSED = "1"
                  

               })!
               

               
               
               _set_if_expression("W1tSRUNBUFRDSEFfMl9DTE9TRURdXSA9PSAw");
               _if(VAR_RECAPTCHA_2_CLOSED == 0,function(){
               
                  
                  
                  /*Browser*/
                  _SELECTOR = VAR_RECAPTCHA_PREFIX_SECOND_FRAME + "\u003eXPATH\u003e id(\u0022rc-imageselect-target\u0022)";
                  wait_element(_SELECTOR)!
                  get_element_selector(_SELECTOR, false).script("(function(){var rect = _BAS_HIDE(BrowserAutomationStudio_GetBoundingClientRect)(self);return (rect.left + positionx) + '|' + (rect.top + positiony) + '|' + (rect.right - rect.left) + '|' + (rect.bottom - rect.top)})();")!
                  if(_result().length > 0)
                  {
                  var split = _result().split("|")
                  VAR_X = parseInt(split[0])
                  VAR_Y = parseInt(split[1])
                  VAR_CAPTCHA_WIDTH = parseInt(split[2])
                  VAR_CAPTCHA_HEIGHT = parseInt(split[3])
                  }
                  

                  
                  
                  /*Browser*/
                  move(rand(VAR_X/100*105,(VAR_X+VAR_CAPTCHA_WIDTH)/100*93).toFixed(),rand(VAR_Y + VAR_SCROLL_Y/100*105,VAR_Y + VAR_SCROLL_Y + VAR_CAPTCHA_HEIGHT/100*90).toFixed(),  {} )!
                  

               })!
               

            })!
            

         },null)!
         

         
         
         _set_if_expression("W1tSRUNBUFRDSEFfMl9DTE9TRURdXSA9PSAx");
         _if(VAR_RECAPTCHA_2_CLOSED == 1,function(){
         
            
            
            sleep(rand(100,400))!
            

            
            
            _next("function")
            

         })!
         

         
         
         _set_if_expression("W1tXQVNfRVJST1JdXQ==");
         _if(typeof(VAR_WAS_ERROR) !== "undefined" ? (VAR_WAS_ERROR) : undefined,function(){
         
            
            
            /*Browser*/
            cache_data_clear()!
            

            
            
            fail(VAR_LAST_ERROR)
            

         })!
         

         
         
         _call(function()
         {
         _on_fail(function(){
         VAR_LAST_ERROR = _result()
         VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
         VAR_WAS_ERROR = false
         _break(1,true)
         })
         CYCLES.Current().RemoveLabel("function")
         
            
            
            _set_if_expression("W1tJTUFHRV9CQVNFXzY0XV0gPT0gOTk5OTk5OTk5OQ==");
            _if(VAR_IMAGE_BASE_64 == 9999999999,function(){
            
               
               
               _set_if_expression("W1tJUzMzXV0gPT0gdHJ1ZQ==");
               _if(VAR_IS33 == true,function(){
               
                  
                  
                  VAR_RAND_PICTURE = rand (1,50000)
                  

                  
                  
                  native("filesystem", "writefile", JSON.stringify({path: "C:/Images/ReCaptcha2/3x3/" + VAR_SET_TASK + "/" + VAR_RAND_PICTURE + ".jpg",value: (VAR_IMAGE_BASE_64).toString(),base64:true,append:false}))
                  

               })!
               

               
               
               _set_if_expression("W1tJUzQ0XV0gPT0gdHJ1ZQ==");
               _if(VAR_IS44 == true,function(){
               
                  
                  
                  VAR_RAND_PICTURE = rand (1,50000)
                  

                  
                  
                  native("filesystem", "writefile", JSON.stringify({path: "C:/Images/ReCaptcha2/4x4/" + VAR_SET_TASK + "/" + VAR_RAND_PICTURE + ".jpg",value: (VAR_IMAGE_BASE_64).toString(),base64:true,append:false}))
                  

               })!
               

            })!
            

         },null)!
         

         
         
         _call(function()
         {
         _on_fail(function(){
         VAR_LAST_ERROR = _result()
         VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
         VAR_WAS_ERROR = false
         _break(1,true)
         })
         CYCLES.Current().RemoveLabel("function")
         
            
            
            VAR_CYCLE_INDEX = 0
            

            
            
            VAR_RECAPTCHA_2_CLOSED = 0
            

            
            
            _do(function(){
            _set_action_info({ name: "For" });
            VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
            if(VAR_CYCLE_INDEX > parseInt(20))_break();
            
               
               
               ///Чистим
               solver_properties_clear("capmonster")
               if (VAR_METHOD_MODULE == "CaptchaGuru (RU Server)") VAR_SERVER_SOLVE = "https://92.53.65.152/"
               if (VAR_METHOD_MODULE == "CaptchaGuru (German Server)") VAR_SERVER_SOLVE = "https://159.69.241.182/"
               if (VAR_METHOD_MODULE == "CaptchaGuru (Finland Server)") VAR_SERVER_SOLVE = "https://95.217.17.172/"
               /// Если юзер оставил старый метод и не пересоздал дейстие с модулем, то оставим дефолт сервер хецнер
               if (VAR_METHOD_MODULE == "CaptchaGuru") VAR_SERVER_SOLVE = "https://159.69.241.182/"
               if (VAR_IS33 === true) VAR_SIZE_BOX_CAPTCHA = 9;
               if (VAR_IS44 === true) VAR_SIZE_BOX_CAPTCHA = 16;
               /// Формирумем основной запрос
               solver_property("capmonster","serverurl",VAR_SERVER_SOLVE)
               solver_property("capmonster","key",VAR_KEY_MODULE)
               solver_property("capmonster","textinstructions",VAR_SET_TASK)
               solver_property("capmonster","click","recap2")
               solver_property("capmonster","basmodule",VAR_BAS_MODULE_VERSION)
               solver_property("capmonster","method","post")
               solver_property("capmonster","bas_disable_image_convert","1")
               solver_property("capmonster","sizex",VAR_SIZE_BOX_CAPTCHA)
               //// Отправляем
               solve_base64_no_fail("capmonster", VAR_IMAGE_BASE_64)!
               VAR_SAVED_CONTENT = _result();
               

               
               
               _set_if_expression("W1tTQVZFRF9DT05URU5UXV0uaW5kZXhPZigiRVJST1JfQ0FQVENIQV9VTlNPTFZBQkxFIikgPj0gMA==");
               _if(VAR_SAVED_CONTENT.indexOf("ERROR_CAPTCHA_UNSOLVABLE") >= 0,function(){
               
                  
                  
                  VAR_ERROR_CAPTCHA_UNSOLVABLE_MODULE = parseInt(VAR_ERROR_CAPTCHA_UNSOLVABLE_MODULE) + parseInt(1)
                  

                  
                  
                  VAR_BAS_CAPMONSTER_IMAGE_ID = 0
                  

                  
                  
                  _set_if_expression("W1tSRUNBUFRDSEFfMl9JTlZJU0lCTEVdXSA9PSAx");
                  _if(VAR_RECAPTCHA_2_INVISIBLE == 1,function(){
                  
                     
                     
                     VAR_RECAPTCHA_2_INVISIBLE = parseInt(VAR_RECAPTCHA_2_INVISIBLE) + parseInt(1)
                     

                  })!
                  

                  
                  
                  /*Browser*/
                  cache_data_clear()!
                  

                  
                  
                  /*Browser*/
                  _SELECTOR = VAR_RECAPTCHA_PREFIX_SECOND_FRAME + "\u003eXPATH\u003e id(\u0022recaptcha-reload-button\u0022)";
                  wait_element_visible(_SELECTOR)!
                  _call(_random_point, {})!
                  _if(_result().length > 0, function(){
                  move( {"speed": VAR_SPEED,"gravity": VAR_GRAVITY,"deviation": VAR_DEVIATION} )!
                  get_element_selector(_SELECTOR, false).clarify(X,Y)!
                  _call(_clarify, {"speed": VAR_SPEED,"gravity": VAR_GRAVITY,"deviation": VAR_DEVIATION} )!
                  mouse(X,Y)!
                  })!
                  

                  
                  
                  sleep(100)!
                  

                  
                  
                  _break("function")
                  

               })!
               

               
               
               _set_if_expression("W1tTQVZFRF9DT05URU5UXV0uaW5kZXhPZigiRVJST1JfV1JPTkdfVVNFUl9LRVkiKSA+PSAw");
               _if(VAR_SAVED_CONTENT.indexOf("ERROR_WRONG_USER_KEY") >= 0,function(){
               
                  
                  
                  VAR_ERROR_KEY = "1"
                  

                  
                  
                  _break("function")
                  

               })!
               

               
               
               _set_if_expression("W1tTQVZFRF9DT05URU5UXV0uaW5kZXhPZigiRVJST1JfWkVST19CQUxBTkNFIikgPj0gMA==");
               _if(VAR_SAVED_CONTENT.indexOf("ERROR_ZERO_BALANCE") >= 0,function(){
               
                  
                  
                  VAR_ERROR_BALANCE = "1"
                  

                  
                  
                  _break("function")
                  

               })!
               

               
               
               _set_if_expression("W1tTQVZFRF9DT05URU5UXV0uaW5kZXhPZigiQ0FQVENIQV9GQUlMIikgPj0gMA==");
               _if(VAR_SAVED_CONTENT.indexOf("CAPTCHA_FAIL") >= 0,function(){
               
                  
                  
                  sleep(rand(1000,2000))!
                  

                  
                  
                  VAR_CAPTCHA_FAIL = parseInt(VAR_CAPTCHA_FAIL) + parseInt(1)
                  

                  
                  
                  _break("function")
                  

               })!
               

               
               
               _cycle_params().if_else = VAR_SAVED_CONTENT.match(/[0-9]/) || VAR_SAVED_CONTENT == "sorry" || VAR_SAVED_CONTENT == "notpic";
               _set_if_expression("W1tTQVZFRF9DT05URU5UXV0ubWF0Y2goL1swLTldLykgfHwgW1tTQVZFRF9DT05URU5UXV0gPT0gInNvcnJ5IiB8fCBbW1NBVkVEX0NPTlRFTlRdXSA9PSAibm90cGljIg==");
               _if(_cycle_params().if_else,function(){
               
                  
                  
                  VAR_MODULE_FRAME_SELECTOR = _BAS_SOLVER_PROPERTIES;
                  var data = VAR_MODULE_FRAME_SELECTOR;
                  var selectors_number = [ VAR_SELECTOR_1,VAR_SELECTOR_2 ]
                  VAR_RESULT_SELECTOR = data[selectors_number[0]][selectors_number[1]];
                  

                  
                  
                  VAR_ERROR_CAPTCHA_UNSOLVABLE_MODULE = "0"
                  

                  
                  
                  VAR_LISTS_SQUARE = VAR_SAVED_CONTENT
                  

                  
                  
                  _set_if_expression("W1tMSVNUU19TUVVBUkVdXS5pbmRleE9mKCJjb29yZGluYXRlcyIpID49IDA=");
                  _if(VAR_LISTS_SQUARE.indexOf("coordinates") >= 0,function(){
                  
                     
                     
                     /*Browser*/
                     ;_SELECTOR=VAR_RECAPTCHA_PREFIX_SECOND_FRAME + "\u003eXPATH\u003e id(\u0022recaptcha-reload-button\u0022)";
                     get_element_selector(_SELECTOR, false).nowait().exist()!
                     VAR_IS_EXISTS = _result() == 1
                     _if(VAR_IS_EXISTS, function(){
                     get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
                     VAR_IS_EXISTS = _result().indexOf("true")>=0
                     })!
                     

                     
                     
                     _set_if_expression("W1tJU19FWElTVFNdXQ==");
                     _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
                     
                        
                        
                        /*Browser*/
                        cache_data_clear()!
                        

                        
                        
                        VAR_BAS_CAPMONSTER_IMAGE_ID = 0
                        

                        
                        
                        /*Browser*/
                        _SELECTOR = VAR_RECAPTCHA_PREFIX_SECOND_FRAME + "\u003eXPATH\u003e id(\u0022recaptcha-reload-button\u0022)";
                        wait_element_visible(_SELECTOR)!
                        _call(_random_point, {})!
                        _if(_result().length > 0, function(){
                        move( {"speed": VAR_SPEED,"gravity": VAR_GRAVITY,"deviation": VAR_DEVIATION} )!
                        get_element_selector(_SELECTOR, false).clarify(X,Y)!
                        _call(_clarify, {"speed": VAR_SPEED,"gravity": VAR_GRAVITY,"deviation": VAR_DEVIATION} )!
                        mouse(X,Y)!
                        })!
                        

                        
                        
                        _break("function")
                        

                     })!
                     

                  })!
                  

                  
                  
                  _set_if_expression("W1tMSVNUU19TUVVBUkVdXSA9PSAic29ycnkiIHx8IFtbTElTVFNfU1FVQVJFXV0gPT0gIm5vdHBpYyI=");
                  _if(VAR_LISTS_SQUARE == "sorry" || VAR_LISTS_SQUARE == "notpic",function(){
                  
                     
                     
                     VAR_BAS_CAPMONSTER_IMAGE_ID = 0
                     

                     
                     
                     _set_if_expression("W1tSRUNBUFRDSEFfMl9JTlZJU0lCTEVdXSA9PSAx");
                     _if(VAR_RECAPTCHA_2_INVISIBLE == 1,function(){
                     
                        
                        
                        VAR_RECAPTCHA_2_INVISIBLE = parseInt(VAR_RECAPTCHA_2_INVISIBLE) + parseInt(1)
                        

                     })!
                     

                     
                     
                     /*Browser*/
                     cache_data_clear()!
                     

                     
                     
                     /*Browser*/
                     _SELECTOR = VAR_RECAPTCHA_PREFIX_SECOND_FRAME + "\u003eCSS\u003e #recaptcha-verify-button";
                     wait_element_visible(_SELECTOR)!
                     _call(_random_point, {})!
                     _if(_result().length > 0, function(){
                     move( {"speed": VAR_SPEED,"gravity": VAR_GRAVITY,"deviation": VAR_DEVIATION} )!
                     get_element_selector(_SELECTOR, false).clarify(X,Y)!
                     _call(_clarify, {"speed": VAR_SPEED,"gravity": VAR_GRAVITY,"deviation": VAR_DEVIATION} )!
                     mouse(X,Y)!
                     })!
                     

                     
                     
                     sleep(100)!
                     

                     
                     
                     _break("function")
                     

                  })!
                  

                  
                  
                  VAR_LISTS_SQUARE = native("regexp", "scan", JSON.stringify({text: VAR_LISTS_SQUARE,regexp:"[0-9]+"}))
                  if(VAR_LISTS_SQUARE.length == 0)
                  VAR_LISTS_SQUARE = []
                  else
                  VAR_LISTS_SQUARE = JSON.parse(VAR_LISTS_SQUARE)
                  

                  
                  
                  ;(function (a) {var j, x, i;for (i = a.length; i; i--) {j = Math.floor(Math.random() * i);x = a[i - 1]; a[i - 1] = a[j];a[j] = x;}})(VAR_LISTS_SQUARE)
                  

                  
                  
                  VAR_FOREACH_DATA = 0
                  

                  
                  
                  var pattern_reg = /^\D*(\d)/;
                  var match_many_me = VAR_RESULT_SELECTOR.match(pattern_reg);
                  var result_number = parseInt(match_many_me ? match_many_me[1] : null);
                  var char_result = parseInt(VAR_RESULT_SELECTOR.charAt(VAR_RESULT_SELECTOR.length-2));
                  if (result_number + char_result != 1 + 1 + 1 && result_number + char_result != 11) VAR_RESULT_SELECTOR = 10-7-2;
                  

                  
                  
                  _do_with_params({"foreach_data":(VAR_LISTS_SQUARE)},function(){
                  _set_action_info({ name: "Foreach" });
                  VAR_CYCLE_INDEX = _iterator() - 1
                  if(VAR_CYCLE_INDEX > _cycle_param("foreach_data").length - 1)_break();
                  VAR_FOREACH_DATA = _cycle_param("foreach_data")[VAR_CYCLE_INDEX]
                  
                     
                     
                     VAR_FOREACH_DATA = Number(VAR_FOREACH_DATA)+3;
                     if (VAR_FOREACH_DATA == 4)
                     {
                     VAR_PIC_X = VAR_FIRST_PIC_X
                     VAR_PIC_Y = VAR_FIRST_PIC_Y
                     }
                     if (VAR_FOREACH_DATA == 5)
                     {
                     VAR_PIC_X = VAR_SECOND_PIC_X
                     VAR_PIC_Y = VAR_SECOND_PIC_Y
                     }
                     if (VAR_FOREACH_DATA == 6)
                     {
                     VAR_PIC_X = VAR_THIRD_PIC_X
                     VAR_PIC_Y = VAR_THIRD_PIC_Y
                     }
                     if (VAR_FOREACH_DATA == 7)
                     {
                     VAR_PIC_X = VAR_FOUR_PIC_X
                     VAR_PIC_Y = VAR_FOUR_PIC_Y
                     }
                     if (VAR_FOREACH_DATA == 8)
                     {
                     VAR_PIC_X = VAR_FIVE_PIC_X
                     VAR_PIC_Y = VAR_FIVE_PIC_Y
                     }
                     if (VAR_FOREACH_DATA == 9)
                     {
                     VAR_PIC_X = VAR_SIX_PIC_X
                     VAR_PIC_Y = VAR_SIX_PIC_Y
                     }
                     if (VAR_FOREACH_DATA == 10)
                     {
                     VAR_PIC_X = VAR_SEVEN_PIC_X
                     VAR_PIC_Y = VAR_SEVEN_PIC_Y
                     }
                     if (VAR_FOREACH_DATA == 11)
                     {
                     VAR_PIC_X = VAR_EIGHT_PIC_X
                     VAR_PIC_Y = VAR_EIGHT_PIC_Y
                     }
                     if (VAR_FOREACH_DATA == 12)
                     {
                     VAR_PIC_X = VAR_NINE_PIC_X
                     VAR_PIC_Y = VAR_NINE_PIC_Y
                     }
                     if (VAR_FOREACH_DATA == 13)
                     {
                     VAR_PIC_X = VAR_TEN_PIC_X
                     VAR_PIC_Y = VAR_TEN_PIC_Y
                     }
                     if (VAR_FOREACH_DATA == 14)
                     {
                     VAR_PIC_X = VAR_ELEVEN_PIC_X
                     VAR_PIC_Y = VAR_ELEVEN_PIC_Y
                     }
                     if (VAR_FOREACH_DATA == 15)
                     {
                     VAR_PIC_X = VAR_TWELVE_PIC_X
                     VAR_PIC_Y = VAR_TWELVE_PIC_Y
                     }
                     if (VAR_FOREACH_DATA == 16)
                     {
                     VAR_PIC_X = VAR_THIRTEEN_PIC_X
                     VAR_PIC_Y = VAR_THIRTEEN_PIC_Y
                     }
                     if (VAR_FOREACH_DATA == 17)
                     {
                     VAR_PIC_X = VAR_FOURTEEN_PIC_X
                     VAR_PIC_Y = VAR_FOURTEEN_PIC_Y
                     }
                     if (VAR_FOREACH_DATA == 18)
                     {
                     VAR_PIC_X = VAR_FIVETEEN_PIC_X
                     VAR_PIC_Y = VAR_FIVETEEN_PIC_Y
                     }
                     if (VAR_FOREACH_DATA == 19)
                     {
                     VAR_PIC_X = VAR_SIXTEEN_PIC_X
                     VAR_PIC_Y = VAR_SIXTEEN_PIC_Y
                     }
                     

                     
                     
                     _set_if_expression("cmFuZCAoMSwxMCkgPiA4ICYmIFtbSVM0NF1dID09IHRydWU=");
                     _if(rand (1,10) > 8 && VAR_IS44 == true,function(){
                     
                        
                        
                        sleep(100)!
                        

                     })!
                     

                     
                     
                     _set_if_expression("W1tJUzMzXV0gPT0gdHJ1ZQ==");
                     _if(VAR_IS33 == true,function(){
                     
                        
                        
                        /*Browser*/
                        cache_data_clear()!
                        

                     })!
                     

                     
                     
                     _set_if_expression("W1tFUlJPUl9FWElTVFNdXSA9PSBmYWxzZQ==");
                     _if(VAR_ERROR_EXISTS == false,function(){
                     
                        
                        
                        _set_if_expression("W1tJUzMzXV0gPT0gdHJ1ZQ==");
                        _if(VAR_IS33 == true,function(){
                        
                           
                           
                           /*Browser*/
                           move(VAR_PIC_X + rand (-16,+16),VAR_PIC_Y + rand (-16,+16),  {"speed": VAR_SPEED,"gravity": VAR_GRAVITY,"deviation": VAR_DEVIATION} )!
                           mouse(VAR_PIC_X + rand (-16,+16),VAR_PIC_Y + rand (-16,+16))!
                           

                        })!
                        

                        
                        
                        _set_if_expression("W1tJUzQ0XV0gPT0gdHJ1ZQ==");
                        _if(VAR_IS44 == true,function(){
                        
                           
                           
                           /*Browser*/
                           move(VAR_PIC_X + rand (-10,+10),VAR_PIC_Y + rand (-10,+10),  {"speed": VAR_SPEED,"gravity": VAR_GRAVITY,"deviation": VAR_DEVIATION} )!
                           mouse(VAR_PIC_X + rand (-10,+10),VAR_PIC_Y + rand (-10,+10))!
                           

                        })!
                        

                     })!
                     

                     
                     
                     _set_if_expression("W1tFUlJPUl9FWElTVFNdXSA9PSB0cnVl");
                     _if(VAR_ERROR_EXISTS == true,function(){
                     
                        
                        
                        /*Browser*/
                        move(VAR_PIC_X + rand (-7,+7),VAR_PIC_Y + rand (-7,+7),  {"speed": VAR_SPEED,"gravity": VAR_GRAVITY,"deviation": VAR_DEVIATION} )!
                        mouse(VAR_PIC_X + rand (-7,+7),VAR_PIC_Y + rand (-7,+7))!
                        

                     })!
                     

                     
                     
                     _set_if_expression("W1tJUzMzXV0gPT0gdHJ1ZQ==");
                     _if(VAR_IS33 == true,function(){
                     
                        
                        
                        /*Browser*/
                        ;_SELECTOR=VAR_RECAPTCHA_PREFIX_SECOND_FRAME + "\u003eXPATH\u003e//*[@class=\u0022rc-imageselect-tile rc-imageselect-tileselected\u0022]";
                        get_element_selector(_SELECTOR, false).nowait().exist()!
                        VAR_IS_EXISTS = _result() == 1
                        _if(VAR_IS_EXISTS, function(){
                        get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
                        VAR_IS_EXISTS = _result().indexOf("true")>=0
                        })!
                        

                        
                        
                        _set_if_expression("W1tJU19FWElTVFNdXSA9PSBmYWxzZQ==");
                        _if(VAR_IS_EXISTS == false,function(){
                        
                           
                           
                           if (VAR_FOREACH_DATA == 4)
                           {
                           VAR_X_IMAGE = 0;
                           VAR_Y_IMAGE = 0;
                           }
                           if (VAR_FOREACH_DATA == 5)
                           {
                           VAR_X_IMAGE = 100;
                           VAR_Y_IMAGE = 0;
                           }
                           if (VAR_FOREACH_DATA == 6)
                           {
                           VAR_X_IMAGE = 200;
                           VAR_Y_IMAGE = 0;
                           }
                           if (VAR_FOREACH_DATA == 7)
                           {
                           VAR_X_IMAGE = 0;
                           VAR_Y_IMAGE = 100;
                           }
                           if (VAR_FOREACH_DATA == 8)
                           {
                           VAR_X_IMAGE = 100;
                           VAR_Y_IMAGE = 100;
                           }
                           if (VAR_FOREACH_DATA == 9)
                           {
                           VAR_X_IMAGE = 200;
                           VAR_Y_IMAGE = 100;
                           }
                           if (VAR_FOREACH_DATA == 10)
                           {
                           VAR_X_IMAGE = 0;
                           VAR_Y_IMAGE = 200;
                           }
                           if (VAR_FOREACH_DATA == 11)
                           {
                           VAR_X_IMAGE = 100;
                           VAR_Y_IMAGE = 200;
                           }
                           if (VAR_FOREACH_DATA == 12)
                           {
                           VAR_X_IMAGE = 200;
                           VAR_Y_IMAGE = 200;
                           }
                           

                           
                           
                           /*Browser*/
                           ;_SELECTOR=VAR_RECAPTCHA_PREFIX_SECOND_FRAME_ELEMENT;
                           get_element_selector(_SELECTOR, false).nowait().exist()!
                           VAR_IS_EXISTS = _result() == 1
                           _if(VAR_IS_EXISTS, function(){
                           get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
                           VAR_IS_EXISTS = _result().indexOf("true")>=0
                           })!
                           

                           
                           
                           _cycle_params().if_else = typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined;
                           _set_if_expression("W1tJU19FWElTVFNdXQ==");
                           _if(_cycle_params().if_else,function(){
                           
                              
                              
                              VAR_RECAPTCHA_2_CLOSED = 0
                              

                           })!
                           

                           
                           
                           _if(!_cycle_params().if_else,function(){
                           
                              
                              
                              VAR_RECAPTCHA_2_CLOSED = "1"
                              

                              
                              
                              _break("function")
                              

                           })!
                           delete _cycle_params().if_else;
                           

                           
                           
                           VAR_SAVED_CROP_IMAGE = "not_exists_pic"
                           

                           
                           
                           _do(function(){
                           _set_action_info({ name: "For" });
                           VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
                           if(VAR_CYCLE_INDEX > parseInt(60))_break();
                           
                              
                              
                              cache_get_base64("recaptcha/*/payload")!
                              var image_id = native("imageprocessing", "load", _result())
                              var image_size = native("imageprocessing", "getsize", image_id)
                              var image_h = parseInt(image_size.split(",")[1])
                              //// Не удалось дождатся пикчу (загрузилcя белый квадрат в сетке 3x3)
                              if (image_h == 0 && VAR_CYCLE_INDEX > 40) _break()
                              //// Ждём в кэше маленькую картинку
                              if (image_h > 49) {
                              VAR_SAVED_CROP_IMAGE = _result()
                              _break()
                              }
                              get_element_selector(VAR_RECAPTCHA_PREFIX_SECOND_FRAME_ELEMENT).script("window.getComputedStyle(self)['visibility']")!
                              if(_result() == "hidden")
                              {
                              VAR_RECAPTCHA_2_CLOSED = 1;
                              _break()
                              }
                              sleep(400)!
                              

                           })!
                           

                           
                           
                           _set_if_expression("W1tSRUNBUFRDSEFfMl9DTE9TRURdXSA9PSAx");
                           _if(VAR_RECAPTCHA_2_CLOSED == 1,function(){
                           
                              
                              
                              _break("function")
                              

                           })!
                           

                           
                           
                           _set_if_expression("dHlwZW9mIFtbU0FWRURfQ1JPUF9JTUFHRV1dID09ICd1bmRlZmluZWQn");
                           _if(typeof VAR_SAVED_CROP_IMAGE == 'undefined',function(){
                           
                              
                              
                              /*Browser*/
                              ;_SELECTOR=VAR_RECAPTCHA_PREFIX_SECOND_FRAME + "\u003eXPATH\u003e id(\u0022recaptcha-reload-button\u0022)";
                              get_element_selector(_SELECTOR, false).nowait().exist()!
                              VAR_IS_EXISTS = _result() == 1
                              _if(VAR_IS_EXISTS, function(){
                              get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
                              VAR_IS_EXISTS = _result().indexOf("true")>=0
                              })!
                              

                              
                              
                              _set_if_expression("W1tJU19FWElTVFNdXQ==");
                              _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
                              
                                 
                                 
                                 VAR_BAS_CAPMONSTER_IMAGE_ID = 0
                                 

                                 
                                 
                                 /*Browser*/
                                 cache_data_clear()!
                                 

                                 
                                 
                                 /*Browser*/
                                 _SELECTOR = VAR_RECAPTCHA_PREFIX_SECOND_FRAME + "\u003eXPATH\u003e id(\u0022recaptcha-reload-button\u0022)";
                                 wait_element_visible(_SELECTOR)!
                                 _call(_random_point, {})!
                                 _if(_result().length > 0, function(){
                                 move( {"speed": VAR_SPEED,"gravity": VAR_GRAVITY,"deviation": VAR_DEVIATION} )!
                                 get_element_selector(_SELECTOR, false).clarify(X,Y)!
                                 _call(_clarify, {"speed": VAR_SPEED,"gravity": VAR_GRAVITY,"deviation": VAR_DEVIATION} )!
                                 mouse(X,Y)!
                                 })!
                                 

                              })!
                              

                              
                              
                              _break("function")
                              

                           })!
                           

                           
                           
                           _set_if_expression("W1tTQVZFRF9DUk9QX0lNQUdFXV0gPT0gIm5vdF9leGlzdHNfcGljIg==");
                           _if(VAR_SAVED_CROP_IMAGE == "not_exists_pic",function(){
                           
                              
                              
                              /*Browser*/
                              ;_SELECTOR=VAR_RECAPTCHA_PREFIX_SECOND_FRAME + "\u003eXPATH\u003e id(\u0022recaptcha-reload-button\u0022)";
                              get_element_selector(_SELECTOR, false).nowait().exist()!
                              VAR_IS_EXISTS = _result() == 1
                              _if(VAR_IS_EXISTS, function(){
                              get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
                              VAR_IS_EXISTS = _result().indexOf("true")>=0
                              })!
                              

                              
                              
                              _set_if_expression("W1tJU19FWElTVFNdXQ==");
                              _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
                              
                                 
                                 
                                 VAR_BAS_CAPMONSTER_IMAGE_ID = 0
                                 

                                 
                                 
                                 /*Browser*/
                                 cache_data_clear()!
                                 

                                 
                                 
                                 /*Browser*/
                                 _SELECTOR = VAR_RECAPTCHA_PREFIX_SECOND_FRAME + "\u003eXPATH\u003e id(\u0022recaptcha-reload-button\u0022)";
                                 wait_element_visible(_SELECTOR)!
                                 _call(_random_point, {})!
                                 _if(_result().length > 0, function(){
                                 move( {"speed": VAR_SPEED,"gravity": VAR_GRAVITY,"deviation": VAR_DEVIATION} )!
                                 get_element_selector(_SELECTOR, false).clarify(X,Y)!
                                 _call(_clarify, {"speed": VAR_SPEED,"gravity": VAR_GRAVITY,"deviation": VAR_DEVIATION} )!
                                 mouse(X,Y)!
                                 })!
                                 

                              })!
                              

                              
                              
                              _break("function")
                              

                           })!
                           

                           
                           
                           VAR_IMAGE_BASE_64 = native("imageprocessing", "load", VAR_IMAGE_BASE_64)
                           

                           
                           
                           VAR_LOADED_CROP = native("imageprocessing", "load", VAR_SAVED_CROP_IMAGE)
                           

                           
                           
                           _set_if_expression("W1tSRUNBUFRDSEFfMl9JTlZJU0lCTEVdXSA9PSAx");
                           _if(VAR_RECAPTCHA_2_INVISIBLE == 1,function(){
                           
                              
                              
                              native("imageprocessing", "resize", (VAR_IMAGE_BASE_64) + "," + (300) + "," + (300))
                              

                              
                              
                              VAR_RECAPTCHA_2_INVISIBLE = parseInt(VAR_RECAPTCHA_2_INVISIBLE) + parseInt(1)
                              

                           })!
                           

                           
                           
                           native("imageprocessing", "insert", (VAR_IMAGE_BASE_64) + "," + (VAR_LOADED_CROP) + ","  + (VAR_X_IMAGE) + "," + (VAR_Y_IMAGE))
                           

                           
                           
                           VAR_IMAGE_BASE_64 = native("imageprocessing", "getdata", VAR_IMAGE_BASE_64)
                           

                           
                           
                           native("imageprocessing", "delete", VAR_IMAGE_BASE_64)
                           

                           
                           
                           native("imageprocessing", "delete", VAR_LOADED_CROP)
                           

                           
                           
                           _set_if_expression("W1tSRUNBUFRDSEFfMl9JTlZJU0lCTEVdXSAgPT0gOTk5OTk5OQ==");
                           _if(VAR_RECAPTCHA_2_INVISIBLE  == 9999999,function(){
                           
                              
                              
                              VAR_THREAD_INDEX = thread_number()
                              

                              
                              
                              native("filesystem", "writefile", JSON.stringify({path: "C:\u005cImages\u005cRecaptcha2" + VAR_THREAD_INDEX + ".png",value: (VAR_IMAGE_BASE_64).toString(),base64:true,append:false}))
                              

                              
                              
                              native("filesystem", "writefile", JSON.stringify({path: "C:\u005cImages\u005cRecaptcha2_Crop" + VAR_THREAD_INDEX + ".png",value: (VAR_SAVED_CROP_IMAGE).toString(),base64:true,append:false}))
                              

                           })!
                           

                           
                           
                           VAR_BAS_CAPMONSTER_IMAGE_ID = 1
                           

                           
                           
                           sleep(100)!
                           

                        })!
                        

                     })!
                     

                  })!
                  

                  
                  
                  _set_if_expression("W1tSRUNBUFRDSEFfMl9DTE9TRURdXSA9PSAx");
                  _if(VAR_RECAPTCHA_2_CLOSED == 1,function(){
                  
                     
                     
                     _break("function")
                     

                  })!
                  

                  
                  
                  _set_if_expression("W1tJUzMzXV0gPT0gdHJ1ZQ==");
                  _if(VAR_IS33 == true,function(){
                  
                     
                     
                     /*Browser*/
                     ;_SELECTOR=VAR_RECAPTCHA_PREFIX_SECOND_FRAME + "\u003eXPATH\u003e//*[@class=\u0022rc-imageselect-tile rc-imageselect-tileselected\u0022]";
                     get_element_selector(_SELECTOR, false).nowait().exist()!
                     VAR_IS_EXISTS = _result() == 1
                     _if(VAR_IS_EXISTS, function(){
                     get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
                     VAR_IS_EXISTS = _result().indexOf("true")>=0
                     })!
                     

                     
                     
                     _set_if_expression("W1tJU19FWElTVFNdXQ==");
                     _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
                     
                        
                        
                        /*Browser*/
                        cache_data_clear()!
                        

                        
                        
                        /*Browser*/
                        _SELECTOR = VAR_RECAPTCHA_PREFIX_SECOND_FRAME + "\u003eXPATH\u003e id(\u0022recaptcha-verify-button\u0022)";
                        wait_element_visible(_SELECTOR)!
                        _call(_random_point, {})!
                        _if(_result().length > 0, function(){
                        move( {"speed": VAR_SPEED,"gravity": VAR_GRAVITY,"deviation": VAR_DEVIATION} )!
                        get_element_selector(_SELECTOR, false).clarify(X,Y)!
                        _call(_clarify, {"speed": VAR_SPEED,"gravity": VAR_GRAVITY,"deviation": VAR_DEVIATION} )!
                        mouse(X,Y)!
                        })!
                        

                        
                        
                        sleep(100)!
                        

                     })!
                     

                     
                     
                     /*Browser*/
                     ;_SELECTOR=VAR_RECAPTCHA_PREFIX_SECOND_FRAME + "\u003eXPATH\u003e //div[@class=\u0022rc-imageselect-error-select-more\u0022]";
                     get_element_selector(_SELECTOR, false).nowait().exist()!
                     VAR_IS_EXISTS_1 = _result() == 1
                     _if(VAR_IS_EXISTS_1, function(){
                     get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
                     VAR_IS_EXISTS_1 = _result().indexOf("true")>=0
                     })!
                     

                     
                     
                     /*Browser*/
                     ;_SELECTOR=VAR_RECAPTCHA_PREFIX_SECOND_FRAME + "\u003eXPATH\u003e //div[@class=\u0022rc-imageselect-error-dynamic-more\u0022]";
                     get_element_selector(_SELECTOR, false).nowait().exist()!
                     VAR_IS_EXISTS_2 = _result() == 1
                     _if(VAR_IS_EXISTS_2, function(){
                     get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
                     VAR_IS_EXISTS_2 = _result().indexOf("true")>=0
                     })!
                     

                     
                     
                     _set_if_expression("W1tJU19FWElTVFNfMV1dIHx8IFtbSVNfRVhJU1RTXzJdXQ==");
                     _if(VAR_IS_EXISTS_1 || VAR_IS_EXISTS_2,function(){
                     
                        
                        
                        VAR_BAS_CAPMONSTER_IMAGE_ID = 0
                        

                        
                        
                        _set_if_expression("W1tSRUNBUFRDSEFfMl9JTlZJU0lCTEVdXSA9PSAx");
                        _if(VAR_RECAPTCHA_2_INVISIBLE == 1,function(){
                        
                           
                           
                           VAR_RECAPTCHA_2_INVISIBLE = parseInt(VAR_RECAPTCHA_2_INVISIBLE) + parseInt(1)
                           

                        })!
                        

                        
                        
                        /*Browser*/
                        cache_data_clear()!
                        

                        
                        
                        /*Browser*/
                        _SELECTOR = VAR_RECAPTCHA_PREFIX_SECOND_FRAME + "\u003eXPATH\u003e id(\u0022recaptcha-reload-button\u0022)";
                        wait_element_visible(_SELECTOR)!
                        _call(_random_point, {})!
                        _if(_result().length > 0, function(){
                        move( {"speed": VAR_SPEED,"gravity": VAR_GRAVITY,"deviation": VAR_DEVIATION} )!
                        get_element_selector(_SELECTOR, false).clarify(X,Y)!
                        _call(_clarify, {"speed": VAR_SPEED,"gravity": VAR_GRAVITY,"deviation": VAR_DEVIATION} )!
                        mouse(X,Y)!
                        })!
                        

                     })!
                     

                  })!
                  

                  
                  
                  _set_if_expression("W1tJUzQ0XV0gPT0gdHJ1ZQ==");
                  _if(VAR_IS44 == true,function(){
                  
                     
                     
                     /*Browser*/
                     cache_data_clear()!
                     

                     
                     
                     /*Browser*/
                     _SELECTOR = VAR_RECAPTCHA_PREFIX_SECOND_FRAME + "\u003eXPATH\u003e id(\u0022recaptcha-verify-button\u0022)";
                     wait_element_visible(_SELECTOR)!
                     _call(_random_point, {})!
                     _if(_result().length > 0, function(){
                     move( {"speed": VAR_SPEED,"gravity": VAR_GRAVITY,"deviation": VAR_DEVIATION} )!
                     get_element_selector(_SELECTOR, false).clarify(X,Y)!
                     _call(_clarify, {"speed": VAR_SPEED,"gravity": VAR_GRAVITY,"deviation": VAR_DEVIATION} )!
                     mouse(X,Y)!
                     })!
                     

                     
                     
                     sleep(100)!
                     

                  })!
                  

                  
                  
                  _set_if_expression("W1tSRUNBUFRDSEFfMl9JTlZJU0lCTEVdXSA9PSAx");
                  _if(VAR_RECAPTCHA_2_INVISIBLE == 1,function(){
                  
                     
                     
                     VAR_RECAPTCHA_2_INVISIBLE = parseInt(VAR_RECAPTCHA_2_INVISIBLE) + parseInt(1)
                     

                  })!
                  

                  
                  
                  sleep(rand(200,500))!
                  

                  
                  
                  _break("function")
                  

               })!
               

               
               
               _if(!_cycle_params().if_else,function(){
               
                  
                  
                  sleep(1000)!
                  

                  
                  
                  VAR_ERROR_CAPTCHA_UNSOLVABLE_MODULE = parseInt(VAR_ERROR_CAPTCHA_UNSOLVABLE_MODULE) + parseInt(1)
                  

                  
                  
                  /*Browser*/
                  ;_SELECTOR=VAR_RECAPTCHA_PREFIX_SECOND_FRAME + "\u003eXPATH\u003e id(\u0022recaptcha-reload-button\u0022)";
                  get_element_selector(_SELECTOR, false).nowait().exist()!
                  VAR_IS_EXISTS = _result() == 1
                  _if(VAR_IS_EXISTS, function(){
                  get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
                  VAR_IS_EXISTS = _result().indexOf("true")>=0
                  })!
                  

                  
                  
                  _set_if_expression("W1tJU19FWElTVFNdXQ==");
                  _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
                  
                     
                     
                     /*Browser*/
                     cache_data_clear()!
                     

                     
                     
                     /*Browser*/
                     _SELECTOR = VAR_RECAPTCHA_PREFIX_SECOND_FRAME + "\u003eXPATH\u003e id(\u0022recaptcha-reload-button\u0022)";
                     wait_element_visible(_SELECTOR)!
                     _call(_random_point, {})!
                     _if(_result().length > 0, function(){
                     move( {"speed": VAR_SPEED,"gravity": VAR_GRAVITY,"deviation": VAR_DEVIATION} )!
                     get_element_selector(_SELECTOR, false).clarify(X,Y)!
                     _call(_clarify, {"speed": VAR_SPEED,"gravity": VAR_GRAVITY,"deviation": VAR_DEVIATION} )!
                     mouse(X,Y)!
                     })!
                     

                  })!
                  

                  
                  
                  _break("function")
                  

               })!
               delete _cycle_params().if_else;
               

            })!
            

         },null)!
         

         
         
         _set_if_expression("W1tXQVNfRVJST1JdXQ==");
         _if(typeof(VAR_WAS_ERROR) !== "undefined" ? (VAR_WAS_ERROR) : undefined,function(){
         
            
            
            sleep(1000)!
            

            
            
            VAR_BAS_CAPMONSTER_IMAGE_ID = 0
            

            
            
            _set_if_expression("W1tSRUNBUFRDSEFfMl9JTlZJU0lCTEVdXSA9PSAx");
            _if(VAR_RECAPTCHA_2_INVISIBLE == 1,function(){
            
               
               
               VAR_RECAPTCHA_2_INVISIBLE = parseInt(VAR_RECAPTCHA_2_INVISIBLE) + parseInt(1)
               

            })!
            

            
            
            _set_if_expression("W1tMQVNUX0VSUk9SXV0uaW5kZXhPZigicGF5bG9hZCIpID49IDAg");
            _if(VAR_LAST_ERROR.indexOf("payload") >= 0 ,function(){
            
               
               
               _call(function()
               {
               _on_fail(function(){
               VAR_LAST_ERROR = _result()
               VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
               VAR_WAS_ERROR = false
               _break(1,true)
               })
               CYCLES.Current().RemoveLabel("function")
               
                  
                  
                  /*Browser*/
                  ;_SELECTOR=VAR_RECAPTCHA_PREFIX_SECOND_FRAME + "\u003eXPATH\u003e id(\u0022recaptcha-reload-button\u0022)";
                  get_element_selector(_SELECTOR, false).nowait().exist()!
                  VAR_IS_EXISTS = _result() == 1
                  _if(VAR_IS_EXISTS, function(){
                  get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
                  VAR_IS_EXISTS = _result().indexOf("true")>=0
                  })!
                  

                  
                  
                  _set_if_expression("W1tJU19FWElTVFNdXQ==");
                  _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
                  
                     
                     
                     /*Browser*/
                     cache_data_clear()!
                     

                     
                     
                     /*Browser*/
                     _SELECTOR = VAR_RECAPTCHA_PREFIX_SECOND_FRAME + "\u003eXPATH\u003e id(\u0022recaptcha-reload-button\u0022)";
                     wait_element_visible(_SELECTOR)!
                     _call(_random_point, {})!
                     _if(_result().length > 0, function(){
                     move( {"speed": VAR_SPEED,"gravity": VAR_GRAVITY,"deviation": VAR_DEVIATION} )!
                     get_element_selector(_SELECTOR, false).clarify(X,Y)!
                     _call(_clarify, {"speed": VAR_SPEED,"gravity": VAR_GRAVITY,"deviation": VAR_DEVIATION} )!
                     mouse(X,Y)!
                     })!
                     

                  })!
                  

               },null)!
               

            })!
            

         })!
         

         
         
         _next("function")
         

      })!
      

   }
   

