var dmxzrntj = GetInputConstructorValue("dmxzrntj", loader);
                 if(dmxzrntj["original"].length == 0)
                 {
                   Invalid(tr("This action cannot be created. Cause: ") + tr("Key of CaptchaGuru ") + tr("is not specified"));	;
                   return;
                 }
var ubkshdvd = GetInputConstructorValue("ubkshdvd", loader);
                 if(ubkshdvd["original"].length == 0)
                 {
                   Invalid(tr("This action cannot be created. Cause: ") + tr("Captcha Guru Server ") + tr("is not specified"));	
                   return;
                 }
var ynyuevjc = GetInputConstructorValue("ynyuevjc", loader);
                 if(ynyuevjc["original"].length == 0)
                 {
                   Invalid(tr("This action cannot be created. Cause: ") + tr("Selector of captcha ") + tr("is not specified"));	
                   return;
                 }
var kucmgqgy = GetInputConstructorValue("kucmgqgy", loader);
                 if(kucmgqgy["original"].length == 0)
                 {
                   Invalid("ATTEMPTS_SOLVE" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#CaptchaImageClick_YandexSmartCaptcha_code").html())({"dmxzrntj": dmxzrntj["updated"],"ubkshdvd": ubkshdvd["updated"],"ynyuevjc": ynyuevjc["updated"],"kucmgqgy": kucmgqgy["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}

