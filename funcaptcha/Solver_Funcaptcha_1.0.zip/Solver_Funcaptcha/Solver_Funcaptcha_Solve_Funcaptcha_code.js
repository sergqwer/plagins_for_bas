_call_function(Solver_Funcaptcha_Solve_Funcaptcha,{ "KEY": (<%= repinvoc %>),"NUMBER": (<%= kaqxblgn %>),"SELECTOR": (<%= qvcbgson %>),"TRY_MAX_CAPTCHA_PICTURE": (<%= groldlta %>) })!
