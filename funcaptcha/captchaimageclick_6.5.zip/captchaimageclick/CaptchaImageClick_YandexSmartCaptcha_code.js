_call_function(CaptchaImageClick_YandexSmartCaptcha,{ "KEY": (<%= dmxzrntj %>),"METHOD": (<%= ubkshdvd %>),"SELECTOR": (<%= ynyuevjc %>),"ATTEMPTS_SOLVE": (<%= kucmgqgy %>) })!
