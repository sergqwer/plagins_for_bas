_call_function(Solver_Funcaptcha_Allow_FunCaptcha_Cache,{  })!
