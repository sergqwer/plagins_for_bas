var repinvoc = GetInputConstructorValue("repinvoc", loader);
                 if(repinvoc["original"].length == 0)
                 {
                   Invalid("KEY" + " is empty");
                   return;
                 }
var kaqxblgn = GetInputConstructorValue("kaqxblgn", loader);
                 if(kaqxblgn["original"].length == 0)
                 {
                   Invalid("NUMBER" + " is empty");
                   return;
                 }
var qvcbgson = GetInputConstructorValue("qvcbgson", loader);
                 if(qvcbgson["original"].length == 0)
                 {
                   Invalid("SELECTOR" + " is empty");
                   return;
                 }
var groldlta = GetInputConstructorValue("groldlta", loader);
                 if(groldlta["original"].length == 0)
                 {
                   Invalid("TRY_MAX_CAPTCHA_PICTURE" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#Solver_Funcaptcha_Solve_Funcaptcha_code").html())({"repinvoc": repinvoc["updated"],"kaqxblgn": kaqxblgn["updated"],"qvcbgson": qvcbgson["updated"],"groldlta": groldlta["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
