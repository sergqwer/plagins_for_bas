function Solver_Funcaptcha_Allow_FunCaptcha_Cache()
   {
   
      
      
      /*Browser*/
      cache_allow("*blob*")!
      

      
      
      /*Browser*/
      cache_allow("*/fc/gfc*")!
      

      
      
      /*Browser*/
      cache_allow("*/rtig/image*")!
      

   }
   

function Solver_Funcaptcha_Solve_Funcaptcha()
   {
   
      
      
      VAR_GLOBAL_SELECTOR = _function_argument("SELECTOR")
      VAR_SPEED_MOUSE = "Normal"
      VAR_KEY_MODULE = _function_argument("KEY")
      VAR_METHOD_MODULE = "GoodXevilPay"
      VAR_TRY_MAX_CAPTCHA_PICTURE = _function_argument("TRY_MAX_CAPTCHA_PICTURE")
      VAR_NUMBER_CAPTCHA_MODULE = 0
      VAR_CYCLE_INDEX = 0
      VAR_FUNCAPTCHA_TYPE = "0"
      VAR_ERROR_LOAD = "0"
      VAR_CACHE_ERROR = "0"
      VAR_ERROR_SOLVE = "0"
      VAR_ERROR_TASK = "0"
      VAR_ERROR_FIND_MAIN_SELECTOR = "0"
      VAR_ERROR_CAPTCHA_UNSOLVABLE_MODULE = 0
      VAR_ERROR_LOAD_NEXT_PICTURE_FUNCAPTCHA = 0
      VAR_FUNCAPTCHA_PREFIX_SECOND_FRAME = ""
      VAR_RECAPTCHA_MODULE_ENABLED = 0
      VAR_HCAPTCHA_MODULE_ENABLED = 0
      VAR_FUNCAPTCHA_MODULE_ENABLED = 0
      VAR_NAME_MODULE_AUTOSUBMIT = "NaN"
      VAR_SQUARE_NUMBER_3 = 0
      VAR_RESULT_SELECTOR = 0
      VAR_TILE_NORMAL_VIEW = 0
      VAR_SET_TASK = ""
      VAR_CURRENT_TASK_NUMBER_SOLVE = 0
      VAR_GREEN_TICK = false
      VAR_RAND_MODULE_IMAGE = "0"
      VAR_RETURN_TYPE = ""
      VAR_NUMBER_WAIT_TASK = rand(90,120)
      VAR_ERROR_WAIT_TASK_FUNCAPTCHA = 0
      VAR_ALL_JSON_FUNCAP = ""
      VAR_SET_TASK = ""
      VAR_SAVED_CACHE_MODULE = ""
      VAR_CHECK_EMPTY_BODY = ""
      VAR_BAS_MODULE_VERSION = "6.7"
      _call(function()
      {
      _on_fail(function(){
      VAR_LAST_ERROR = _result()
      VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
      VAR_WAS_ERROR = false
      _break(1,true)
      })
      CYCLES.Current().RemoveLabel("function")
      //// Проверить установлены ли модули с автосабмитом.
      if (typeof NumbersParseRecaptcha2 === 'function') VAR_RECAPTCHA_MODULE_ENABLED = 1, VAR_NAME_MODULE_AUTOSUBMIT = "ReCaptcha 2 Autosubmit";
      if (typeof BASCaptchaSolver.helpers.HCaptchaHelper === 'function') VAR_HCAPTCHA_MODULE_ENABLED = 1, VAR_NAME_MODULE_AUTOSUBMIT = "hCaptcha Autosubmit";
      if (typeof BASCaptchaSolver.helpers.FunCaptchaHelper === 'function') VAR_FUNCAPTCHA_MODULE_ENABLED = 1, VAR_NAME_MODULE_AUTOSUBMIT = "FunCaptcha Autosubmit";
      },null)!
      _set_if_expression("W1tGVU5DQVBUQ0hBX01PRFVMRV9FTkFCTEVEXV0gPT0gMSB8fCBbW1JFQ0FQVENIQV9NT0RVTEVfRU5BQkxFRF1dID09IDEgfHwgW1tIQ0FQVENIQV9NT0RVTEVfRU5BQkxFRF1dID09IDE=");
      _if(VAR_FUNCAPTCHA_MODULE_ENABLED == 1 || VAR_RECAPTCHA_MODULE_ENABLED == 1 || VAR_HCAPTCHA_MODULE_ENABLED == 1,function(){
      fail((_K==="en" ? "Solve the captcha failed, to continue solving captchas by clicks requires to disable module " +VAR_NAME_MODULE_AUTOSUBMIT + " and also remove all actions from the script associated with it and retry solve captcha again" : "Решить капчу не удалось, для продолжения решения капчи кликами требуется отключить сторонний встроенный модуль в BAS: " +VAR_NAME_MODULE_AUTOSUBMIT + ", а также удалить все действия из шаблона связанные с ним и повторить попытку"));
      })!
      _call(function()
      {
      _on_fail(function(){
      VAR_LAST_ERROR = _result()
      VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
      VAR_WAS_ERROR = false
      _break(1,true)
      })
      CYCLES.Current().RemoveLabel("function")
      VAR_SELECTOR_1 = "Y2FwbW9uc3Rlcg=="
      VAR_SELECTOR_2 = "c2VydmVydXJs"
      },null)!
      _call(function()
      {
      _on_fail(function(){
      VAR_LAST_ERROR = _result()
      VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
      VAR_WAS_ERROR = false
      _break(1,true)
      })
      CYCLES.Current().RemoveLabel("function")
      _do(function(){
      _set_action_info({ name: "For" });
      VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
      if(VAR_CYCLE_INDEX > parseInt(200))_break();
      /*Browser*/
      is_load("*/fc/gfc*")!
      VAR_WAIT_LOAD_TASK = _result()
      _set_if_expression("W1tXQUlUX0xPQURfVEFTS11dID09IDE=");
      _if(VAR_WAIT_LOAD_TASK == 1,function(){
      _break("function")
      })!
      _set_if_expression("W1tDWUNMRV9JTkRFWF1dID49IFtbTlVNQkVSX1dBSVRfVEFTS11d");
      _if(VAR_CYCLE_INDEX >= VAR_NUMBER_WAIT_TASK,function(){
      VAR_ERROR_WAIT_TASK_FUNCAPTCHA = 1
      _break("function")
      })!
      sleep(rand(200,500))!
      })!
      },null)!
      _set_if_expression("W1tFUlJPUl9XQUlUX1RBU0tfRlVOQ0FQVENIQV1dID09PSAx");
      _if(VAR_ERROR_WAIT_TASK_FUNCAPTCHA === 1,function(){
      /*Browser*/
      cache_data_clear()!
      fail((_K==="en" ? "FunCaptcha was not solved, could not wait URL with tasks. Timeout waiting - */fc/gfc*" : "Funcaptcha не была решена, не удалось загрузить URL со списком заданий. Таймаут ожидания - */fc/gfc*"));
      })!
      _call(function()
      {
      _on_fail(function(){
      VAR_LAST_ERROR = _result()
      VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
      VAR_WAS_ERROR = false
      _break(1,true)
      })
      CYCLES.Current().RemoveLabel("function")
      _do(function(){
      _set_action_info({ name: "For" });
      VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
      if(VAR_CYCLE_INDEX > parseInt(40))_break();
      /*Browser*/
      _cache_get_all("*/fc/gfc*")!
      VAR_ALL_JSON_FUNCAP = JSON.parse(_result())
      VAR_ALL_JSON_FUNCAP_LENGTH = (VAR_ALL_JSON_FUNCAP).length
      _set_if_expression("W1tBTExfSlNPTl9GVU5DQVBdXSAhPSAnJyAmJiBbW0FMTF9KU09OX0ZVTkNBUF9MRU5HVEhdXSA9PSAx");
      _if(VAR_ALL_JSON_FUNCAP != '' && VAR_ALL_JSON_FUNCAP_LENGTH == 1,function(){
      /*Browser*/
      wait_load("*/fc/gfc*")!
      cache_get_string("*/fc/gfc*")!
      VAR_SAVED_CACHE_MODULE = _result()
      })!
      _set_if_expression("W1tBTExfSlNPTl9GVU5DQVBdXSAhPSAnJyAmJiBbW0FMTF9KU09OX0ZVTkNBUF9MRU5HVEhdXSA+IDE=");
      _if(VAR_ALL_JSON_FUNCAP != '' && VAR_ALL_JSON_FUNCAP_LENGTH > 1,function(){
      _do(function(){
      _set_action_info({ name: "While" });
      VAR_CYCLE_INDEX = _iterator() - 1
      BREAK_CONDITION = VAR_ALL_JSON_FUNCAP !=0;
      if(!BREAK_CONDITION)_break();
      _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gNDA=");
      _if(VAR_CYCLE_INDEX > 40,function(){
      _break("function")
      })!
      VAR_ALL_JSON_FUNCAP_LENGTH = (VAR_ALL_JSON_FUNCAP).length
      VAR_LIST_ELEMENT_BAS_MODULE = (VAR_ALL_JSON_FUNCAP)[0];
      VAR_ALL_JSON_FUNCAP.splice(0,1)
      _set_if_expression("dHlwZW9mKFtbTElTVF9FTEVNRU5UX0JBU19NT0RVTEVdXSkgPT09ICJ1bmRlZmluZWQi");
      _if(typeof(VAR_LIST_ELEMENT_BAS_MODULE) === "undefined",function(){
      _break("function")
      })!
      /// Функция декодирования
      function decodeBase64Module(base64StringModule) {
      var decodedStringModule = "";
      var keyStr = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";
      var chr1, chr2, chr3;
      var enc1, enc2, enc3, enc4;
      var i = 0;
      base64StringModule = base64StringModule.replace(/[^A-Za-z0-9+/=]/g, "");
      while (i < base64StringModule.length) {
      enc1 = keyStr.indexOf(base64StringModule.charAt(i++));
      enc2 = keyStr.indexOf(base64StringModule.charAt(i++));
      enc3 = keyStr.indexOf(base64StringModule.charAt(i++));
      enc4 = keyStr.indexOf(base64StringModule.charAt(i++));
      chr1 = (enc1 << 2) | (enc2 >> 4);
      chr2 = ((enc2 & 15) << 4) | (enc3 >> 2);
      chr3 = ((enc3 & 3) << 6) | enc4;
      decodedStringModule += String.fromCharCode(chr1);
      if (enc3 !== 64) {
      decodedStringModule += String.fromCharCode(chr2);
      }
      if (enc4 !== 64) {
      decodedStringModule += String.fromCharCode(chr3);
      }
      }
      return decodedStringModule;
      }
      // Функция проверка валидности JSON
      function isJSONValid(jsonString) {
      try {
      JSON.parse(jsonString);
      return true;
      } catch (error) {
      return false;
      }
      }
      /// Ищем задание в каждом элементе кэша
      if (VAR_LIST_ELEMENT_BAS_MODULE.hasOwnProperty("body")) VAR_CHECK_EMPTY_BODY = VAR_LIST_ELEMENT_BAS_MODULE.body
      if (VAR_CHECK_EMPTY_BODY != '') VAR_SAVED_CACHE_MODULE = decodeBase64Module(VAR_CHECK_EMPTY_BODY);
      // Проверяем валидный JSON
      var jsonStringModule = VAR_SAVED_CACHE_MODULE
      if (isJSONValid(jsonStringModule)) {
      VAR_IS_JSON_VALID = true
      } else {
      VAR_IS_JSON_VALID = false
      }
      _set_if_expression("W1tJU19KU09OX1ZBTElEXV0gPT0gZmFsc2U=");
      _if(VAR_IS_JSON_VALID == false,function(){
      _next("function")
      })!
      _set_if_expression("W1tTQVZFRF9DQUNIRV9NT0RVTEVdXS5pbmRleE9mKCJnYW1lX2RhdGEiKSA+PSAw");
      _if(VAR_SAVED_CACHE_MODULE.indexOf("game_data") >= 0,function(){
      _break("function")
      })!
      sleep(200)!
      })!
      })!
      // Проверяем, спарсили ли кэш из body
      function isJSONValid(jsonStringModule) {
      try {
      JSON.parse(jsonStringModule);
      return true;
      } catch (error) {
      return false;
      }
      }
      var jsonStringModule = VAR_SAVED_CACHE_MODULE
      if (isJSONValid(jsonStringModule)) {
      VAR_IS_JSON_VALID = true
      } else {
      VAR_IS_JSON_VALID = false
      }
      _set_if_expression("W1tJU19KU09OX1ZBTElEXV0gPT09IHRydWU=");
      _if(VAR_IS_JSON_VALID === true,function(){
      /// Парсим задание
      VAR_SAVED_CACHE_MODULE = JSON.parse(VAR_SAVED_CACHE_MODULE);
      ///Game Item, Game_Chidldren, Game_Header
      if (VAR_SAVED_CACHE_MODULE.hasOwnProperty("game_data") &&
      VAR_SAVED_CACHE_MODULE.game_data.hasOwnProperty("game_variant")){
      VAR_SET_TASK = VAR_SAVED_CACHE_MODULE.game_data.game_variant.split("|")[0].split("/")[0]
      VAR_CURRENT_TASK_NUMBERS = VAR_SAVED_CACHE_MODULE.game_data.waves;
      VAR_ALL_TASK_NUMBERS = VAR_SAVED_CACHE_MODULE.game_data.waves;
      }
      /// GameBox и GameTile
      if (VAR_SAVED_CACHE_MODULE.hasOwnProperty("game_data") &&
      VAR_SAVED_CACHE_MODULE.game_data.hasOwnProperty("instruction_string")){
      VAR_SET_TASK = VAR_SAVED_CACHE_MODULE.game_data.instruction_string.split("|")[0].split("/")[0]
      VAR_CURRENT_TASK_NUMBERS = VAR_SAVED_CACHE_MODULE.game_data.waves;
      VAR_ALL_TASK_NUMBERS = VAR_SAVED_CACHE_MODULE.game_data.waves;
      }
      })!
      _set_if_expression("W1tTRVRfVEFTS11dICE9ICIi");
      _if(VAR_SET_TASK != "",function(){
      _break("function")
      })!
      _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gMzA=");
      _if(VAR_CYCLE_INDEX > 30,function(){
      VAR_CACHE_ERROR = "1"
      _break("function")
      })!
      sleep(rand(100,300))!
      })!
      },null)!
      _set_if_expression("W1tXQVNfRVJST1JdXQ==");
      _if(typeof(VAR_WAS_ERROR) !== "undefined" ? (VAR_WAS_ERROR) : undefined,function(){
      fail((_K==="en" ? "Error parsing cache: */fc/gfc*" : "Произошла неизвестная ошибка парсинга кэша - */fc/gfc*"));
      })!
      VAR_SAVED_CACHE_MODULE = ""
      VAR_ALL_JSON_FUNCAP = ""
      VAR_LIST_ELEMENT_BAS_MODULE = ""
      _call(function()
      {
      _on_fail(function(){
      VAR_LAST_ERROR = _result()
      VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
      VAR_WAS_ERROR = false
      _break(1,true)
      })
      CYCLES.Current().RemoveLabel("function")
      if (VAR_SPEED_MOUSE == "Slow")
      {
      VAR_SPEED = 100;
      VAR_GRAVITY = 6;
      VAR_DEVIATION = 2.5;
      }
      if (VAR_SPEED_MOUSE == "Normal")
      {
      VAR_SPEED = 200;
      VAR_GRAVITY = 12;
      VAR_DEVIATION = 5;
      }
      if (VAR_SPEED_MOUSE == "Fast")
      {
      VAR_SPEED = 300;
      VAR_GRAVITY = 18;
      VAR_DEVIATION = 7.5;
      }
      if (VAR_SPEED_MOUSE == "Very Fast")
      {
      VAR_SPEED = 400;
      VAR_GRAVITY = 24;
      VAR_DEVIATION = 10;
      }
      if (VAR_SPEED_MOUSE == "Extreme")
      {
      VAR_SPEED = 500;
      VAR_GRAVITY = 30;
      VAR_DEVIATION = 12.5;
      }
      VAR_IS_MOBILE = _IS_MOBILE;
      _set_if_expression("W1tJU19NT0JJTEVdXSA9PSBmYWxzZSAmJiByYW5kICgxLDEwKSA+IDM=");
      _if(VAR_IS_MOBILE == false && rand (1,10) > 6,function(){
      _do(function(){
      _set_action_info({ name: "While" });
      VAR_CYCLE_INDEX = _iterator() - 1
      BREAK_CONDITION = VAR_CYCLE_INDEX < 2;
      if(!BREAK_CONDITION)_break();
      _get_browser_screen_settings()!
      ;(function(){
      var result = JSON.parse(_result())
      VAR_SCROLL_X = result["ScrollX"]
      VAR_SCROLL_Y = result["ScrollY"]
      VAR_CURSOR_X = result["CursorX"]
      VAR_CURSOR_Y = result["CursorY"]
      VAR_BROWSER_WIDTH = result["Width"]
      VAR_BROWSER_HEIGHT = result["Height"]
      })();
      var scroll_x=parseInt(VAR_CURSOR_Y);
      var scroll_y=parseInt(VAR_SCROLL_Y);
      var browser_h=parseInt(VAR_BROWSER_HEIGHT);
      //-------------------- Привели все в числа, считаем позицию ---------------------
      var absolut_y = VAR_CURSOR_Y + VAR_SCROLL_Y;
      var y_without_scroll = absolut_y - VAR_SCROLL_Y;
      var check_y_top = VAR_BROWSER_HEIGHT/12;
      var check_y_down = VAR_BROWSER_HEIGHT/100*92;
      var move_y_top = VAR_BROWSER_HEIGHT/10;
      var move_y_down = VAR_BROWSER_HEIGHT/100*80;
      // -------------------------- Округляем ----------------------------------
      VAR_CHECK_Y_TOP = check_y_top.toFixed();
      VAR_CHECK_Y_DOWN = check_y_down.toFixed();
      VAR_Y_WITHOUNT_SCROLL = y_without_scroll.toFixed();
      VAR_MOVE_Y_TOP = move_y_top.toFixed();
      VAR_MOVE_Y_DOWN = move_y_down.toFixed();
      // ----------------- Снова приводим к числу ------------------------
      VAR_CHECK_Y_TOP=parseInt(VAR_CHECK_Y_TOP);
      VAR_CHECK_Y_DOWN=parseInt(VAR_CHECK_Y_DOWN);
      VAR_Y_WITHOUNT_SCROLL=parseInt(VAR_Y_WITHOUNT_SCROLL);
      VAR_MOVE_Y_TOP=parseInt(VAR_MOVE_Y_TOP);
      VAR_MOVE_Y_DOWN=parseInt(VAR_MOVE_Y_DOWN);
      /*Browser*/
      move(rand(VAR_BROWSER_WIDTH/5,VAR_BROWSER_WIDTH/1.3),rand(VAR_MOVE_Y_TOP + VAR_SCROLL_Y,VAR_MOVE_Y_DOWN + VAR_SCROLL_Y),  {} )!
      _set_if_expression("cmFuZCAoMSwxMCkgPiA1");
      _if(rand (1,10) > 5,function(){
      _break("function")
      })!
      })!
      })!
      VAR_FUNCAPTCHA_PREFIX = VAR_GLOBAL_SELECTOR;
      VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME = VAR_FUNCAPTCHA_PREFIX;
      {
      var index = VAR_FUNCAPTCHA_PREFIX.toString().lastIndexOf(">FRAME>")
      if(index >= 0)
      VAR_FUNCAPTCHA_PREFIX = VAR_FUNCAPTCHA_PREFIX.substring(0,index)
      VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME = VAR_FUNCAPTCHA_PREFIX
      index = VAR_FUNCAPTCHA_PREFIX.toString().lastIndexOf(">FRAME>")
      if(index >= 0)
      VAR_FUNCAPTCHA_PREFIX = VAR_FUNCAPTCHA_PREFIX.substring(0,index + ">FRAME>".length)
      else
      VAR_FUNCAPTCHA_PREFIX = ""
      index = VAR_FUNCAPTCHA_PREFIX.toString().lastIndexOf(">FRAME>")
      if(index >= 0)
      VAR_FUNCAPTCHA_PREFIX = VAR_FUNCAPTCHA_PREFIX.substring(0,index + ">FRAME>".length)
      else
      VAR_FUNCAPTCHA_PREFIX = ""
      }
      _set_if_expression("W1tGVU5DQVBUQ0hBX1BSRUZJWF9TRUNPTkRfRlJBTUVdXSA9PSAiIg==");
      _if(VAR_FUNCAPTCHA_PREFIX_SECOND_FRAME == "",function(){
      _do(function(){
      _set_action_info({ name: "For" });
      VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
      if(VAR_CYCLE_INDEX > parseInt(50))_break();
      /*Browser*/
      ;_SELECTOR=VAR_GLOBAL_SELECTOR;
      get_element_selector(_SELECTOR, false).nowait().exist()!
      VAR_IS_EXISTS = _result() == 1
      _if(VAR_IS_EXISTS, function(){
      get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
      VAR_IS_EXISTS = _result().indexOf("true")>=0
      })!
      _cycle_params().if_else = typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined;
      _set_if_expression("W1tJU19FWElTVFNdXQ==");
      _if(_cycle_params().if_else,function(){
      /*Browser*/
      _SELECTOR = VAR_GLOBAL_SELECTOR;waiter_timeout_next(8000)
      wait_element_visible(_SELECTOR)!
      _call(_random_point, {})!
      _if(_result().length > 0, function(){
      move( {} )!
      get_element_selector(_SELECTOR, false).clarify(X,Y)!
      _call(_clarify, {} )!
      mouse(X,Y)!
      })!
      _break("function")
      })!
      _if(!_cycle_params().if_else,function(){
      sleep(rand(500,600))!
      })!
      delete _cycle_params().if_else;
      _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gcmFuZCAoNDAsNDgp");
      _if(VAR_CYCLE_INDEX > rand (40,48),function(){
      VAR_ERROR_FIND_MAIN_SELECTOR = "1"
      })!
      })!
      })!
      },null)!
      _set_if_expression("W1tDQUNIRV9FUlJPUl1dID09IDE=");
      _if(VAR_CACHE_ERROR == 1,function(){
      /*Browser*/
      cache_data_clear()!
      fail((_K==="en" ? "FunCaptcha was not solved, could not get task from URL - */fc/gfc*" : "Funcaptcha не была решена, не удалось спарсить задание из маски URL - */fc/gfc*"));
      })!
      _set_if_expression("W1tDVVJSRU5UX1RBU0tfTlVNQkVSU11dID4gW1tUUllfTUFYX0NBUFRDSEFfUElDVFVSRV1d");
      _if(VAR_CURRENT_TASK_NUMBERS > VAR_TRY_MAX_CAPTCHA_PICTURE,function(){
      fail((_K==="en" ? "The capctha could not be resolved. The maximum number of tasks Funcaptcha has been exceeded " +VAR_CURRENT_TASK_NUMBERS + ". Check the quality of the browser and proxy." : "Каптчу решить не удалось, превышен лимит на максимально допустимое число заданий у FunCaptcha: " +VAR_CURRENT_TASK_NUMBERS + ". Проверьте качество браузера или прокси."));
      })!
      _set_if_expression("W1tFUlJPUl9GSU5EX01BSU5fU0VMRUNUT1JdXSA9PSAx");
      _if(VAR_ERROR_FIND_MAIN_SELECTOR == 1,function(){
      /*Browser*/
      cache_data_clear()!
      fail((_K==="en" ? "Could not wait for the main FunCaptcha selector to load main captcha window" : "Не удалось дождаться загрузки основного селектора, который должен открыть главное окно с FunCaptcha"));
      })!
      _set_if_expression("W1tXQVNfRVJST1JdXQ==");
      _if(typeof(VAR_WAS_ERROR) !== "undefined" ? (VAR_WAS_ERROR) : undefined,function(){
      fail(VAR_LAST_ERROR)
      })!
      VAR_TRY_CAPTCHA = "0"
      VAR_CAPTCHA_FAIL = "0"
      VAR_ERROR_KEY = "0"
      VAR_ERROR_BALANCE = "0"
      VAR_ERROR_LANG = "0"
      VAR_GET_ALL_COORDINATES = "0"
      VAR_FIRST_LOAD_CAPTCHA = true
      VAR_FIRST_LOAD_BUTTON = true
      /// Селектор который передал юзер модулю приведем в нормальный вид
      get_selector_normal = function(s) {
      var e={},i,b=0,c,x,l=0,a,r='',w=String.fromCharCode,L=s.length;
      var A="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
      for(i=0;i<64;i++){e[A.charAt(i)]=i;}
      for(x=0;x<L;x++){
      c=e[s.charAt(x)];b=(b<<6)+c;l+=6;
      while(l>=8){((a=(b>>>(l-=8))&0xff)||(x<(L-2)))&&(r+=w(a));}
      }
      return r;
      };
      VAR_SELECTOR_1 = get_selector_normal(VAR_SELECTOR_1);
      VAR_SELECTOR_2 = get_selector_normal(VAR_SELECTOR_2);
      _do(function(){
      _set_action_info({ name: "For" });
      VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
      if(VAR_CYCLE_INDEX > parseInt(500))_break();
      VAR_CYCLE_INDEX = 0
      _set_if_expression("W1tFUlJPUl9LRVldXSA9PSAx");
      _if(VAR_ERROR_KEY == 1,function(){
      /*Browser*/
      cache_data_clear()!
      fail((_K==="en" ? "API secret key from captcha recognition service is wrong ERROR_WRONG_USER_KEY" : "Секретный ключ API от сервиса распознавания капчи неправильный ERROR_WRONG_USER_KEY"));
      })!
      _set_if_expression("W1tFUlJPUl9CQUxBTkNFXV0gPT0gMQ==");
      _if(VAR_ERROR_BALANCE == 1,function(){
      /*Browser*/
      cache_data_clear()!
      fail((_K==="en" ? "The balance on the captcha service has ended - ERROR_ZERO_BALANCE" : "Закончился баланс на сервисе распознавания капчи - ERROR_ZERO_BALANCE"));
      })!
      _set_if_expression("W1tFUlJPUl9UQVNLXV0gPiAx");
      _if(VAR_ERROR_TASK > 1,function(){
      /*Browser*/
      cache_data_clear()!
      fail((_K==="en" ? "This Funcaptcha task or image type is not supported service " +VAR_METHOD_MODULE + ": " +VAR_SET_TASK : "Каптча не была решена, " +VAR_METHOD_MODULE + " не смог распознать или не умеет решать это изображение с таким заданием: " +VAR_SET_TASK));
      })!
      _set_if_expression("W1tDQVBUQ0hBX0ZBSUxdXSA+IDE=");
      _if(VAR_CAPTCHA_FAIL > 1,function(){
      /*Browser*/
      cache_data_clear()!
      fail((_K==="en" ? "Failed to solve FunCaptcha, reason - " +VAR_SAVED_CONTENT : "Не удалось решить FunCaptcha, причина - " +VAR_SAVED_CONTENT));
      })!
      _set_if_expression("W1tFUlJPUl9DQVBUQ0hBX1VOU09MVkFCTEVfTU9EVUxFXV0gPiAx");
      _if(VAR_ERROR_CAPTCHA_UNSOLVABLE_MODULE > 1,function(){
      /*Browser*/
      cache_data_clear()!
      sleep(100)!
      fail((_K==="en" ? "FunCaptcha task or image type is not supported service CaptchaGuru, reason: ERROR_CAPTCHA_UNSOLVABLE" : "Решить FunCaptcha не удалось - сервис CaptchaGuru не смог распознать несколько изображений подряд, причина: ERROR_CAPTCHA_UNSOLVABLE"));
      })!
      _do(function(){
      _set_action_info({ name: "For" });
      VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
      if(VAR_CYCLE_INDEX > parseInt(85))_break();
      _set_if_expression("W1tGSVJTVF9MT0FEX0JVVFRPTl1dID09IHRydWU=");
      _if(VAR_FIRST_LOAD_BUTTON == true,function(){
      /*Browser*/
      ;_SELECTOR=VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e #verifyButton";
      get_element_selector(_SELECTOR, false).nowait().exist()!
      VAR_IS_EXISTS = _result() == 1
      _set_if_expression("W1tJU19FWElTVFNdXQ==");
      _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
      /*Browser*/
      _SELECTOR = VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e #verifyButton";
      wait_element_visible(_SELECTOR)!
      _call(_random_point, {})!
      _if(_result().length > 0, function(){
      move( {} )!
      get_element_selector(_SELECTOR, false).clarify(X,Y)!
      _call(_clarify, {} )!
      mouse(X,Y)!
      })!
      })!
      /*Browser*/
      ;_SELECTOR=VAR_FUNCAPTCHA_PREFIX + " \u003eCSS\u003e #verifyButton";
      get_element_selector(_SELECTOR, false).nowait().exist()!
      VAR_IS_EXISTS = _result() == 1
      _set_if_expression("W1tJU19FWElTVFNdXQ==");
      _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
      /*Browser*/
      _SELECTOR = VAR_FUNCAPTCHA_PREFIX + " \u003eCSS\u003e #verifyButton";
      wait_element_visible(_SELECTOR)!
      _call(_random_point, {})!
      _if(_result().length > 0, function(){
      move( {} )!
      get_element_selector(_SELECTOR, false).clarify(X,Y)!
      _call(_clarify, {} )!
      mouse(X,Y)!
      })!
      })!
      })!
      _set_if_expression("W1tGSVJTVF9MT0FEX0JVVFRPTl1dID09IHRydWUgfHwgW1tFUlJPUl9MT0FEX05FWFRfUElDVFVSRV9GVU5DQVBUQ0hBXV0gPT0gMQ==");
      _if(VAR_FIRST_LOAD_BUTTON == true || VAR_ERROR_LOAD_NEXT_PICTURE_FUNCAPTCHA == 1,function(){
      /*Browser*/
      ;_SELECTOR=VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e div[class*=\u0027error box screen\u0027]";
      get_element_selector(_SELECTOR, false).nowait().exist()!
      VAR_TIMEOUT_ERROR_1 = _result() == 1
      _if(VAR_TIMEOUT_ERROR_1, function(){
      get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
      VAR_TIMEOUT_ERROR_1 = _result().indexOf("true")>=0
      })!
      /*Browser*/
      ;_SELECTOR=VAR_FUNCAPTCHA_PREFIX + " \u003eCSS\u003e #sub-frame-error";
      get_element_selector(_SELECTOR, false).nowait().exist()!
      VAR_TIMEOUT_ERROR_2 = _result() == 1
      _if(VAR_TIMEOUT_ERROR_2, function(){
      get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
      VAR_TIMEOUT_ERROR_2 = _result().indexOf("true")>=0
      })!
      /*Browser*/
      ;_SELECTOR=VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e #sub-frame-error";
      get_element_selector(_SELECTOR, false).nowait().exist()!
      VAR_TIMEOUT_ERROR_3 = _result() == 1
      _if(VAR_TIMEOUT_ERROR_3, function(){
      get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
      VAR_TIMEOUT_ERROR_3 = _result().indexOf("true")>=0
      })!
      /*Browser*/
      ;_SELECTOR=VAR_FUNCAPTCHA_PREFIX + " \u003eCSS\u003e #timeout_widget";
      get_element_selector(_SELECTOR, false).nowait().exist()!
      VAR_TIMEOUT_ERROR_4 = _result() == 1
      _if(VAR_TIMEOUT_ERROR_4, function(){
      get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
      VAR_TIMEOUT_ERROR_4 = _result().indexOf("true")>=0
      })!
      _set_if_expression("W1tUSU1FT1VUX0VSUk9SXzFdXSA9PSB0cnVlIHx8IFtbVElNRU9VVF9FUlJPUl8yXV0gPT0gdHJ1ZSB8fCBbW1RJTUVPVVRfRVJST1JfM11dID09IHRydWUgfHwgW1tUSU1FT1VUX0VSUk9SXzRdXSA9PSB0cnVl");
      _if(VAR_TIMEOUT_ERROR_1 == true || VAR_TIMEOUT_ERROR_2 == true || VAR_TIMEOUT_ERROR_3 == true || VAR_TIMEOUT_ERROR_4 == true,function(){
      VAR_ERROR_LOAD = "1"
      _break("function")
      })!
      })!
      _set_if_expression("W1tDVVJSRU5UX1RBU0tfTlVNQkVSU11dIDwgMQ==");
      _if(VAR_CURRENT_TASK_NUMBERS < 1,function(){
      /*Browser*/
      ;_SELECTOR=VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e #wrong_children_exclamation";
      get_element_selector(_SELECTOR, false).nowait().exist()!
      VAR_WRONG_CAPTCHA_SOLVE_1 = _result() == 1
      /*Browser*/
      ;_SELECTOR=VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e div[class*=\u0027match-game-fail\u0027]";
      get_element_selector(_SELECTOR, false).nowait().exist()!
      VAR_WRONG_CAPTCHA_SOLVE_2 = _result() == 1
      /*Browser*/
      ;_SELECTOR=VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e div[class*=\u0027tile-game-fail\u0027]";
      get_element_selector(_SELECTOR, false).nowait().exist()!
      VAR_WRONG_CAPTCHA_SOLVE_3 = _result() == 1
      /*Browser*/
      ;_SELECTOR=VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e div[id*=\u0027descriptionTryAgain\u0027]";
      get_element_selector(_SELECTOR, false).nowait().exist()!
      VAR_WRONG_CAPTCHA_SOLVE_4 = _result() == 1
      _set_if_expression("W1tXUk9OR19DQVBUQ0hBX1NPTFZFXzFdXSA9PSB0cnVlIHx8IFtbV1JPTkdfQ0FQVENIQV9TT0xWRV8yXV0gPT0gdHJ1ZSB8fCBbW1dST05HX0NBUFRDSEFfU09MVkVfM11dID09IHRydWUgfHwgW1tXUk9OR19DQVBUQ0hBX1NPTFZFXzRdXSA9PSB0cnVl");
      _if(VAR_WRONG_CAPTCHA_SOLVE_1 == true || VAR_WRONG_CAPTCHA_SOLVE_2 == true || VAR_WRONG_CAPTCHA_SOLVE_3 == true || VAR_WRONG_CAPTCHA_SOLVE_4 == true,function(){
      VAR_ERROR_SOLVE = "1"
      _break("function")
      })!
      })!
      _set_if_expression("W1tGSVJTVF9MT0FEX0JVVFRPTl1dID09IHRydWUgfHwgW1tDVVJSRU5UX1RBU0tfTlVNQkVSU11dIDwgMQ==");
      _if(VAR_FIRST_LOAD_BUTTON == true || VAR_CURRENT_TASK_NUMBERS < 1,function(){
      /*Browser*/
      ;_SELECTOR=VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e #game_challengeItem";
      get_element_selector(_SELECTOR, false).nowait().exist()!
      VAR_IS_EXISTS = _result() == 1
      _if(VAR_IS_EXISTS, function(){
      get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
      VAR_IS_EXISTS = _result().indexOf("true")>=0
      })!
      /*Browser*/
      ;_SELECTOR=VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e div[class*=\u0027match-game box screen\u0027]";
      get_element_selector(_SELECTOR, false).nowait().exist()!
      VAR_IS_EXISTS_2 = _result() == 1
      _if(VAR_IS_EXISTS_2, function(){
      get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
      VAR_IS_EXISTS_2 = _result().indexOf("true")>=0
      })!
      /*Browser*/
      ;_SELECTOR=VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e div[class*=\u0027tile-game box screen\u0027]";
      get_element_selector(_SELECTOR, false).nowait().exist()!
      VAR_IS_EXISTS_3 = _result() == 1
      _if(VAR_IS_EXISTS_3, function(){
      get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
      VAR_IS_EXISTS_3 = _result().indexOf("true")>=0
      })!
      /*Browser*/
      ;_SELECTOR=VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e legend[id*=\u0027game-header\u0027]";
      get_element_selector(_SELECTOR, false).nowait().exist()!
      VAR_IS_EXISTS_4 = _result() == 1
      _if(VAR_IS_EXISTS_4, function(){
      get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
      VAR_IS_EXISTS_4 = _result().indexOf("true")>=0
      })!
      /*Browser*/
      ;_SELECTOR=VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e a[id*=\u0027Frame_children_arrow\u0027]";
      get_element_selector(_SELECTOR, false).nowait().exist()!
      VAR_IS_EXISTS_5 = _result() == 1
      _if(VAR_IS_EXISTS_5, function(){
      get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
      VAR_IS_EXISTS_5 = _result().indexOf("true")>=0
      })!
      _set_if_expression("W1tJU19FWElTVFNdXSA9PSB0cnVlIHx8IFtbSVNfRVhJU1RTXzJdXSA9PSB0cnVlIHx8IFtbSVNfRVhJU1RTXzNdXSA9PSB0cnVlIHx8IFtbSVNfRVhJU1RTXzRdXSA9PSB0cnVlIHx8IFtbSVNfRVhJU1RTXzVdXSA9PSB0cnVl");
      _if(VAR_IS_EXISTS == true || VAR_IS_EXISTS_2 == true || VAR_IS_EXISTS_3 == true || VAR_IS_EXISTS_4 == true || VAR_IS_EXISTS_5 == true,function(){
      _set_if_expression("W1tJU19FWElTVFNdXQ==");
      _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
      VAR_FUNCAPTCHA_TYPE = "Game_Item"
      })!
      _set_if_expression("W1tJU19FWElTVFNfMl1d");
      _if(typeof(VAR_IS_EXISTS_2) !== "undefined" ? (VAR_IS_EXISTS_2) : undefined,function(){
      VAR_FUNCAPTCHA_TYPE = "Game_Box"
      })!
      _set_if_expression("W1tJU19FWElTVFNfM11d");
      _if(typeof(VAR_IS_EXISTS_3) !== "undefined" ? (VAR_IS_EXISTS_3) : undefined,function(){
      VAR_FUNCAPTCHA_TYPE = "Game_Tile"
      })!
      _set_if_expression("W1tJU19FWElTVFNfNF1d");
      _if(typeof(VAR_IS_EXISTS_4) !== "undefined" ? (VAR_IS_EXISTS_4) : undefined,function(){
      VAR_FUNCAPTCHA_TYPE = "Game_Header"
      })!
      _set_if_expression("W1tJU19FWElTVFNfNV1d");
      _if(typeof(VAR_IS_EXISTS_5) !== "undefined" ? (VAR_IS_EXISTS_5) : undefined,function(){
      VAR_FUNCAPTCHA_TYPE = "Game_Children"
      })!
      _break("function")
      })!
      _set_if_expression("W1tJU19FWElTVFNdXSA9PSBmYWxzZSAmJiBbW0lTX0VYSVNUU18yXV0gPT0gZmFsc2UgJiYgW1tJU19FWElTVFNfM11dID09IGZhbHNlICYmIFtbSVNfRVhJU1RTXzRdXSA9PSBmYWxzZSAmJiBbW0lTX0VYSVNUU181XV0gPT0gZmFsc2UgJiYgW1tGSVJTVF9MT0FEX0NBUFRDSEFdXSA9PSBmYWxzZSAmJiBbW0NZQ0xFX0lOREVYXV0gPiAxICYmIFtbUkVTVUxUX1NFTEVDVE9SXV0gIT0gMQ==");
      _if(VAR_IS_EXISTS == false && VAR_IS_EXISTS_2 == false && VAR_IS_EXISTS_3 == false && VAR_IS_EXISTS_4 == false && VAR_IS_EXISTS_5 == false && VAR_FIRST_LOAD_CAPTCHA == false && VAR_CYCLE_INDEX > 1 && VAR_RESULT_SELECTOR != 1,function(){
      /*Browser*/
      cache_data_clear()!
      VAR_GREEN_TICK = true
      _break("function")
      })!
      })!
      _set_if_expression("W1tDVVJSRU5UX1RBU0tfTlVNQkVSU11dID4gMCAmJiBbW0ZJUlNUX0xPQURfQlVUVE9OXV0gPT0gZmFsc2U=");
      _if(VAR_CURRENT_TASK_NUMBERS > 0 && VAR_FIRST_LOAD_BUTTON == false,function(){
      _break("function")
      })!
      _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gNDAgJiYgW1tGSVJTVF9MT0FEX0JVVFRPTl1dID09IHRydWUgJiYgW1tSRVNVTFRfU0VMRUNUT1JdXSAhPSAx");
      _if(VAR_CYCLE_INDEX > 40 && VAR_FIRST_LOAD_BUTTON == true && VAR_RESULT_SELECTOR != 1,function(){
      VAR_FIRST_LOAD_BUTTON = false
      sleep(rand(1000,1000))!
      /*Browser*/
      ;_SELECTOR=VAR_GLOBAL_SELECTOR;
      get_element_selector(_SELECTOR, false).nowait().exist()!
      VAR_IS_EXISTS = _result() == 1
      _if(VAR_IS_EXISTS, function(){
      get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
      VAR_IS_EXISTS = _result().indexOf("true")>=0
      })!
      _set_if_expression("W1tJU19FWElTVFNdXQ==");
      _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
      /*Browser*/
      _SELECTOR = VAR_GLOBAL_SELECTOR;waiter_timeout_next(8000)
      wait_element_visible(_SELECTOR)!
      _call(_random_point, {})!
      _if(_result().length > 0, function(){
      move( {} )!
      get_element_selector(_SELECTOR, false).clarify(X,Y)!
      _call(_clarify, {} )!
      mouse(X,Y)!
      })!
      sleep(rand(2000,2000))!
      })!
      })!
      _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gNjAgJiYgW1tGSVJTVF9MT0FEX0NBUFRDSEFdXSA9PSB0cnVlICYmIFtbUkVTVUxUX1NFTEVDVE9SXV0gIT0gMQ==");
      _if(VAR_CYCLE_INDEX > 60 && VAR_FIRST_LOAD_CAPTCHA == true && VAR_RESULT_SELECTOR != 1,function(){
      /*Browser*/
      cache_data_clear()!
      fail((_K==="en" ? "Failed to solve FunCaptcha. This captcha type is unknown for current module solve method" : "Не удалось решить FunCaptcha, модуль не умеет решать такой тип капчи"));
      })!
      _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gODAgJiYgW1tGSVJTVF9MT0FEX0NBUFRDSEFdXSA9PSBmYWxzZSAmJiBbW1JFU1VMVF9TRUxFQ1RPUl1dICE9IDE=");
      _if(VAR_CYCLE_INDEX > 80 && VAR_FIRST_LOAD_CAPTCHA == false && VAR_RESULT_SELECTOR != 1,function(){
      /*Browser*/
      cache_data_clear()!
      fail((_K==="en" ? "Failed to solve the captcha. The captcha window is closed." : "Решить капчу не удалось. Окно с капчей не было открыто."));
      })!
      })!
      VAR_CYCLE_INDEX = 0
      VAR_FIRST_LOAD_BUTTON = false
      _set_if_expression("W1tHUkVFTl9USUNLXV0gPT0gdHJ1ZSAmJiBbW1JFU1VMVF9TRUxFQ1RPUl1dICE9IDE=");
      _if(VAR_GREEN_TICK == true && VAR_RESULT_SELECTOR != 1,function(){
      /*Browser*/
      cache_data_clear()!
      _function_return("")
      })!
      _set_if_expression("W1tFUlJPUl9TT0xWRV1dID09IDE=");
      _if(VAR_ERROR_SOLVE == 1,function(){
      /*Browser*/
      cache_data_clear()!
      fail((_K==="en" ? "FunCaptcha solved incorrectly, error - ERROR_CAPTCHA_SOLVE. FunCaptcha type " + VAR_FUNCAPTCHA_TYPE + ". Short task: " + VAR_SET_TASK : "FunCaptcha решена неверно, ошибка  - ERROR_CAPTCHA_SOLVE. Тип каптчи: " + VAR_FUNCAPTCHA_TYPE + ". Задание: " + VAR_SET_TASK));
      })!
      _set_if_expression("W1tFUlJPUl9MT0FEXV0gPT0gMQ==");
      _if(VAR_ERROR_LOAD == 1,function(){
      /*Browser*/
      cache_data_clear()!
      fail((_K==="en" ? "Solving FunCaptcha failed, the connection to a verification server was interrupted - ERROR_CAPTCHA_TIMEOUT" : "Решить FunCaptcha не удалось, не удалось открыть iframe с картнками каптчи - ERROR_CAPTCHA_TIMEOUT"));
      })!
      VAR_TRY_CAPTCHA = parseInt(VAR_TRY_CAPTCHA) + parseInt(1)
      _set_if_expression("W1tUUllfQ0FQVENIQV1dID4gMjM=");
      _if(VAR_TRY_CAPTCHA > 200,function(){
      /*Browser*/
      cache_data_clear()!
      fail((_K==="en" ? "Failed to solve the captcha. FunCaptcha attempts limit exceeded" : "Решить капчу не удалось. Превышен лимит попыток решить FunCaptcha"));
      })!
      _call(function()
      {
      _on_fail(function(){
      VAR_LAST_ERROR = _result()
      VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
      VAR_WAS_ERROR = false
      _break(1,true)
      })
      CYCLES.Current().RemoveLabel("function")
      _get_browser_screen_settings()!
      ;(function(){
      var result = JSON.parse(_result())
      VAR_SCROLL_X = result["ScrollX"]
      VAR_SCROLL_Y = result["ScrollY"]
      VAR_CURSOR_X = result["CursorX"]
      VAR_CURSOR_Y = result["CursorY"]
      VAR_BROWSER_WIDTH = result["Width"]
      VAR_BROWSER_HEIGHT = result["Height"]
      })();
      _set_if_expression("W1tGVU5DQVBUQ0hBX1RZUEVdXSA9PSAiR2FtZV9JdGVtIg==");
      _if(VAR_FUNCAPTCHA_TYPE == "Game_Item",function(){
      /*Browser*/
      ;_SELECTOR=VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e #game_challengeItem";
      get_element_selector(_SELECTOR, false).nowait().exist()!
      VAR_IS_EXISTS = _result() == 1
      _set_if_expression("IVtbSVNfRVhJU1RTXV0=");
      _if(!VAR_IS_EXISTS,function(){
      sleep(rand(100,200))!
      _next("function")
      })!
      /*Browser*/
      _SELECTOR = VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e #game_challengeItem";
      wait_element(_SELECTOR)!
      get_element_selector(_SELECTOR, false).script("(function(){var rect = _BAS_HIDE(BrowserAutomationStudio_GetBoundingClientRect)(self);return (rect.left + positionx) + '|' + (rect.top + positiony) + '|' + (rect.right - rect.left) + '|' + (rect.bottom - rect.top)})();")!
      if(_result().length > 0)
      {
      var split = _result().split("|")
      VAR_X = parseInt(split[0])
      VAR_Y = parseInt(split[1])
      VAR_CAPTCHA_WIDTH = parseInt(split[2])
      VAR_CAPTCHA_HEIGHT = parseInt(split[3])
      }
      _set_if_expression("cmFuZCAoMSwxMCkgPiA1");
      _if(rand (1,10) > 5,function(){
      /*Browser*/
      move(rand(VAR_X/100*115,(VAR_X+VAR_CAPTCHA_WIDTH)/100*93).toFixed(),rand(VAR_Y + VAR_SCROLL_Y/100*120,VAR_Y + VAR_SCROLL_Y + VAR_CAPTCHA_HEIGHT/100*90).toFixed(),  {} )!
      })!
      })!
      _set_if_expression("W1tGVU5DQVBUQ0hBX1RZUEVdXSA9PSAiR2FtZV9UaWxlIg==");
      _if(VAR_FUNCAPTCHA_TYPE == "Game_Tile",function(){
      /*Browser*/
      ;_SELECTOR=VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e div[class*=\u0027tile-game box screen\u0027]";
      get_element_selector(_SELECTOR, false).nowait().exist()!
      VAR_IS_EXISTS = _result() == 1
      _set_if_expression("IVtbSVNfRVhJU1RTXV0=");
      _if(!VAR_IS_EXISTS,function(){
      sleep(rand(100,200))!
      _next("function")
      })!
      /*Browser*/
      _SELECTOR = VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e div[class*=\u0027tile-game box screen\u0027]";
      wait_element(_SELECTOR)!
      get_element_selector(_SELECTOR, false).script("(function(){var rect = _BAS_HIDE(BrowserAutomationStudio_GetBoundingClientRect)(self);return (rect.left + positionx) + '|' + (rect.top + positiony) + '|' + (rect.right - rect.left) + '|' + (rect.bottom - rect.top)})();")!
      if(_result().length > 0)
      {
      var split = _result().split("|")
      VAR_X = parseInt(split[0])
      VAR_Y = parseInt(split[1])
      VAR_CAPTCHA_WIDTH = parseInt(split[2])
      VAR_CAPTCHA_HEIGHT = parseInt(split[3])
      }
      _set_if_expression("cmFuZCAoMSwxMCkgPiA1");
      _if(rand (1,10) > 5,function(){
      /*Browser*/
      move(rand(VAR_X/100*115,(VAR_X+VAR_CAPTCHA_WIDTH)/100*93).toFixed(),rand(VAR_Y + VAR_SCROLL_Y/100*120,VAR_Y + VAR_SCROLL_Y + VAR_CAPTCHA_HEIGHT/100*90).toFixed(),  {} )!
      })!
      })!
      _set_if_expression("W1tGVU5DQVBUQ0hBX1RZUEVdXSA9PSAiR2FtZV9Cb3gi");
      _if(VAR_FUNCAPTCHA_TYPE == "Game_Box",function(){
      /*Browser*/
      ;_SELECTOR=VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e img[aria-label*=\u00271\u0027]";
      get_element_selector(_SELECTOR, false).nowait().exist()!
      VAR_IS_EXISTS = _result() == 1
      _set_if_expression("IVtbSVNfRVhJU1RTXV0=");
      _if(!VAR_IS_EXISTS,function(){
      sleep(rand(100,200))!
      _next("function")
      })!
      _set_if_expression("W1tJU19FWElTVFNdXQ==");
      _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
      /*Browser*/
      _SELECTOR = VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e a[class*=\u0027right-arrow\u0027]";
      wait_element_visible(_SELECTOR)!
      _call(_random_point, {})!
      _if(_result().length > 0, function(){
      move( {} )!
      get_element_selector(_SELECTOR, false).clarify(X,Y)!
      _call(_clarify, {} )!
      })!
      })!
      })!
      _set_if_expression("W1tGVU5DQVBUQ0hBX1RZUEVdXSA9PSAiR2FtZV9IZWFkZXIi");
      _if(VAR_FUNCAPTCHA_TYPE == "Game_Header",function(){
      /*Browser*/
      ;_SELECTOR=VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e img[id*=\u0027challenge-image\u0027]";
      get_element_selector(_SELECTOR, false).nowait().exist()!
      VAR_IS_EXISTS = _result() == 1
      _set_if_expression("IVtbSVNfRVhJU1RTXV0=");
      _if(!VAR_IS_EXISTS,function(){
      sleep(rand(100,500))!
      _next("function")
      })!
      /*Browser*/
      _SELECTOR = VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e img[id*=\u0027challenge-image\u0027]";
      wait_element(_SELECTOR)!
      get_element_selector(_SELECTOR, false).script("(function(){var rect = _BAS_HIDE(BrowserAutomationStudio_GetBoundingClientRect)(self);return (rect.left + positionx) + '|' + (rect.top + positiony) + '|' + (rect.right - rect.left) + '|' + (rect.bottom - rect.top)})();")!
      if(_result().length > 0)
      {
      var split = _result().split("|")
      VAR_X = parseInt(split[0])
      VAR_Y = parseInt(split[1])
      VAR_CAPTCHA_WIDTH = parseInt(split[2])
      VAR_CAPTCHA_HEIGHT = parseInt(split[3])
      }
      _set_if_expression("cmFuZCAoMSwxMCkgPiA1");
      _if(rand (1,10) > 5,function(){
      /*Browser*/
      move(rand(VAR_X/100*115,(VAR_X+VAR_CAPTCHA_WIDTH)/100*93).toFixed(),rand(VAR_Y + VAR_SCROLL_Y/100*120,VAR_Y + VAR_SCROLL_Y + VAR_CAPTCHA_HEIGHT/100*90).toFixed(),  {} )!
      })!
      })!
      _set_if_expression("W1tGVU5DQVBUQ0hBX1RZUEVdXSA9PSAiR2FtZV9DaGlsZHJlbiI=");
      _if(VAR_FUNCAPTCHA_TYPE == "Game_Children",function(){
      /*Browser*/
      ;_SELECTOR=VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e a[id*=\u0027children_arrowRight\u0027]";
      get_element_selector(_SELECTOR, false).nowait().exist()!
      VAR_IS_EXISTS = _result() == 1
      _set_if_expression("IVtbSVNfRVhJU1RTXV0=");
      _if(!VAR_IS_EXISTS,function(){
      sleep(rand(100,200))!
      _next("function")
      })!
      _set_if_expression("W1tJU19FWElTVFNdXQ==");
      _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
      /*Browser*/
      _SELECTOR = VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e a[id*=\u0027children_arrowRight\u0027]";
      wait_element_visible(_SELECTOR)!
      _call(_random_point, {})!
      _if(_result().length > 0, function(){
      move( {} )!
      get_element_selector(_SELECTOR, false).clarify(X,Y)!
      _call(_clarify, {} )!
      })!
      })!
      })!
      },null)!
      _call(function()
      {
      _on_fail(function(){
      VAR_LAST_ERROR = _result()
      VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
      VAR_WAS_ERROR = false
      _break(1,true)
      })
      CYCLES.Current().RemoveLabel("function")
      _get_browser_screen_settings()!
      ;(function(){
      var result = JSON.parse(_result())
      VAR_SCROLL_X = result["ScrollX"]
      VAR_SCROLL_Y = result["ScrollY"]
      VAR_CURSOR_X = result["CursorX"]
      VAR_CURSOR_Y = result["CursorY"]
      VAR_BROWSER_WIDTH = result["Width"]
      VAR_BROWSER_HEIGHT = result["Height"]
      })();
      _set_if_expression("W1tHRVRfQUxMX0NPT1JESU5BVEVTXV0gPT0gMCB8fCAhKFtbSVNfQ0hBTkdFRF9TQ1JPTExfWV1dIDw9IFtbU0NST0xMX1ldXSArIDQgJiYgW1tJU19DSEFOR0VEX1NDUk9MTF9ZXV0gPj0gW1tTQ1JPTExfWV1dIC0gNCk=");
      _if(VAR_GET_ALL_COORDINATES == 0 || !(VAR_IS_CHANGED_SCROLL_Y <= VAR_SCROLL_Y + 4 && VAR_IS_CHANGED_SCROLL_Y >= VAR_SCROLL_Y - 4),function(){
      VAR_IS_CHANGED_SCROLL_Y = VAR_SCROLL_Y
      _set_if_expression("W1tGVU5DQVBUQ0hBX1RZUEVdXSA9PSAiR2FtZV9JdGVtIg==");
      _if(VAR_FUNCAPTCHA_TYPE == "Game_Item",function(){
      VAR_ELEMENT_SELECTOR = VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e #image1 \u003e a"
      _SELECTOR = VAR_ELEMENT_SELECTOR;
      get_element_selector(_SELECTOR, false).script("(function(){var rect = _BAS_HIDE(BrowserAutomationStudio_GetBoundingClientRect)(self);return (rect.left + positionx) + '|' + (rect.top + positiony) + '|' + (rect.right - rect.left) + '|' + (rect.bottom - rect.top)})();")!
      var split = _result().split("|");
      var x = parseInt(split[0]), y = parseInt(split[1]), w = parseInt(split[2]), h = parseInt(split[3]);
      /// Первый квадрат
      VAR_SQUARE_BUTTON_X = parseInt(x) + VAR_SCROLL_X;
      VAR_SQUARE_BUTTON_Y = parseInt(y) + VAR_SCROLL_Y;
      VAR_SQUARE_WIDTH = parseInt(w)
      VAR_SQUARE_HEIGHT = parseInt(h)
      //// Реальный рамзер всех 6 квадратов
      VAR_REAL_SIZE_WIDTH = VAR_SQUARE_WIDTH * 3;
      VAR_REAL_SIZE_HEIGHT = VAR_SQUARE_HEIGHT * 2;
      })!
      _set_if_expression("W1tGVU5DQVBUQ0hBX1RZUEVdXSA9PSAiR2FtZV9UaWxlIg==");
      _if(VAR_FUNCAPTCHA_TYPE == "Game_Tile",function(){
      VAR_ELEMENT_SELECTOR = VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e button[class*=\u0027tile box\u0027]"
      _SELECTOR = VAR_ELEMENT_SELECTOR;
      get_element_selector(_SELECTOR, false).script("(function(){var rect = _BAS_HIDE(BrowserAutomationStudio_GetBoundingClientRect)(self);return (rect.left + positionx) + '|' + (rect.top + positiony) + '|' + (rect.right - rect.left) + '|' + (rect.bottom - rect.top)})();")!
      var split = _result().split("|");
      var x = parseInt(split[0]), y = parseInt(split[1]), w = parseInt(split[2]), h = parseInt(split[3]);
      /// Первый квадрат (Версия плитки)
      VAR_SQUARE_BUTTON_X = parseInt(x) + VAR_SCROLL_X;
      VAR_SQUARE_BUTTON_Y = parseInt(y) + VAR_SCROLL_Y;
      VAR_SQUARE_WIDTH = parseInt(w)
      VAR_SQUARE_HEIGHT = parseInt(h)
      //// Реальный рамзер всех 6 квадратов
      VAR_REAL_SIZE_WIDTH = VAR_SQUARE_WIDTH * 3;
      VAR_REAL_SIZE_HEIGHT = VAR_SQUARE_HEIGHT * 2;
      VAR_ELEMENT_SELECTOR = VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e button[class*=\u0027tile box\u0027]\u003eAT\u003e2"
      _SELECTOR = VAR_ELEMENT_SELECTOR;
      get_element_selector(_SELECTOR, false).script("(function(){var rect = _BAS_HIDE(BrowserAutomationStudio_GetBoundingClientRect)(self);return (rect.left + positionx) + '|' + (rect.top + positiony) + '|' + (rect.right - rect.left) + '|' + (rect.bottom - rect.top)})();")!
      var split = _result().split("|");
      var x = parseInt(split[0]), y = parseInt(split[1]), w = parseInt(split[2]), h = parseInt(split[3]);
      /// Третий квадрат квадрат (Версия плитки)
      VAR_SQUARE_NUMBER_3 = parseInt(x);
      _cycle_params().if_else = VAR_SQUARE_BUTTON_X + VAR_SQUARE_WIDTH*2 == VAR_SQUARE_NUMBER_3;
      _set_if_expression("W1tTUVVBUkVfQlVUVE9OX1hdXSArIFtbU1FVQVJFX1dJRFRIXV0qMiA9PSBbW1NRVUFSRV9OVU1CRVJfM11d");
      _if(_cycle_params().if_else,function(){
      VAR_TILE_NORMAL_VIEW = true
      })!
      _if(!_cycle_params().if_else,function(){
      VAR_TILE_NORMAL_VIEW = false
      })!
      delete _cycle_params().if_else;
      })!
      _set_if_expression("W1tGVU5DQVBUQ0hBX1RZUEVdXSA9PSAiR2FtZV9Cb3gi");
      _if(VAR_FUNCAPTCHA_TYPE == "Game_Box",function(){
      VAR_ELEMENT_SELECTOR = VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e a[class*=\u0027right-arrow\u0027]"
      _SELECTOR = VAR_ELEMENT_SELECTOR;
      get_element_selector(_SELECTOR, false).script("(function(){var rect = _BAS_HIDE(BrowserAutomationStudio_GetBoundingClientRect)(self);return (rect.left + positionx) + '|' + (rect.top + positiony) + '|' + (rect.right - rect.left) + '|' + (rect.bottom - rect.top)})();")!
      var split = _result().split("|");
      var x = parseInt(split[0]), y = parseInt(split[1]), w = parseInt(split[2]), h = parseInt(split[3]);
      /// Первый квадрат
      VAR_DIRECT_BUTTON_X = parseInt(x) + VAR_SCROLL_X;
      VAR_DIRECT_BUTTON_Y = parseInt(y) + VAR_SCROLL_Y;
      VAR_DIRECT_WIDTH = parseInt(w)
      VAR_DIRECT_HEIGHT = parseInt(h)
      ////Высчитаем центр стрелочки
      VAR_DIRECT_BUTTON_X = VAR_DIRECT_BUTTON_X + VAR_DIRECT_WIDTH/2;
      VAR_DIRECT_BUTTON_Y = VAR_DIRECT_BUTTON_Y + VAR_DIRECT_HEIGHT/2;
      })!
      _set_if_expression("W1tGVU5DQVBUQ0hBX1RZUEVdXSA9PSAiR2FtZV9IZWFkZXIi");
      _if(VAR_FUNCAPTCHA_TYPE == "Game_Header",function(){
      VAR_ELEMENT_SELECTOR = VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e img[id*=\u0027challenge-image\u0027]"
      _SELECTOR = VAR_ELEMENT_SELECTOR;
      get_element_selector(_SELECTOR, false).script("(function(){var rect = _BAS_HIDE(BrowserAutomationStudio_GetBoundingClientRect)(self);return (rect.left + positionx) + '|' + (rect.top + positiony) + '|' + (rect.right - rect.left) + '|' + (rect.bottom - rect.top)})();")!
      var split = _result().split("|");
      var x = parseInt(split[0]), y = parseInt(split[1]), w = parseInt(split[2]), h = parseInt(split[3]);
      /// Первый квадрат
      VAR_SQUARE_BUTTON_X = parseInt(x) + VAR_SCROLL_X;
      VAR_SQUARE_BUTTON_Y = parseInt(y) + VAR_SCROLL_Y;
      VAR_SQUARE_WIDTH = parseInt(w)
      VAR_SQUARE_HEIGHT = parseInt(h)
      //// Реальный рамзер всех 6 квадратов
      VAR_REAL_SIZE_WIDTH = VAR_SQUARE_WIDTH * 3;
      VAR_REAL_SIZE_HEIGHT = VAR_SQUARE_HEIGHT * 2;
      })!
      _set_if_expression("W1tGVU5DQVBUQ0hBX1RZUEVdXSA9PSAiR2FtZV9DaGlsZHJlbiI=");
      _if(VAR_FUNCAPTCHA_TYPE == "Game_Children",function(){
      VAR_ELEMENT_SELECTOR = VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e a[id*=\u0027children_arrowRight\u0027]"
      _SELECTOR = VAR_ELEMENT_SELECTOR;
      get_element_selector(_SELECTOR, false).script("(function(){var rect = _BAS_HIDE(BrowserAutomationStudio_GetBoundingClientRect)(self);return (rect.left + positionx) + '|' + (rect.top + positiony) + '|' + (rect.right - rect.left) + '|' + (rect.bottom - rect.top)})();")!
      var split = _result().split("|");
      var x = parseInt(split[0]), y = parseInt(split[1]), w = parseInt(split[2]), h = parseInt(split[3]);
      /// Первый квадрат
      VAR_DIRECT_BUTTON_X = parseInt(x) + VAR_SCROLL_X;
      VAR_DIRECT_BUTTON_Y = parseInt(y) + VAR_SCROLL_Y;
      VAR_DIRECT_WIDTH = parseInt(w)
      VAR_DIRECT_HEIGHT = parseInt(h)
      ////Высчитаем центр стрелочки
      VAR_DIRECT_BUTTON_X = VAR_DIRECT_BUTTON_X + VAR_DIRECT_WIDTH/2;
      VAR_DIRECT_BUTTON_Y = VAR_DIRECT_BUTTON_Y + VAR_DIRECT_HEIGHT/2;
      })!
      VAR_GET_ALL_COORDINATES = "1"
      })!
      },null)!
      _set_if_expression("W1tXQVNfRVJST1JdXQ==");
      _if(typeof(VAR_WAS_ERROR) !== "undefined" ? (VAR_WAS_ERROR) : undefined,function(){
      /*Browser*/
      cache_data_clear()!
      fail(VAR_LAST_ERROR)
      })!
      _call(function()
      {
      _on_fail(function(){
      VAR_LAST_ERROR = _result()
      VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
      VAR_WAS_ERROR = false
      _break(1,true)
      })
      CYCLES.Current().RemoveLabel("function")
      _set_if_expression("W1tGVU5DQVBUQ0hBX1RZUEVdXSA9PSAiR2FtZV9JdGVtIg==");
      _if(VAR_FUNCAPTCHA_TYPE == "Game_Item",function(){
      _set_if_expression("W1tGSVJTVF9MT0FEX0NBUFRDSEFdXSA9PSB0cnVl");
      _if(VAR_FIRST_LOAD_CAPTCHA == true,function(){
      /*Browser*/
      wait_load("*rtig/image*")!
      })!
      /*Browser*/
      ;_SELECTOR=VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e #game_challengeItem";
      get_element_selector(_SELECTOR, false).nowait().exist()!
      VAR_IS_EXISTS = _result() == 1
      _if(VAR_IS_EXISTS, function(){
      get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
      VAR_IS_EXISTS = _result().indexOf("true")>=0
      })!
      _set_if_expression("W1tJU19FWElTVFNdXSA9PSBmYWxzZQ==");
      _if(VAR_IS_EXISTS == false,function(){
      _next("function")
      })!
      /*Browser*/
      _SELECTOR = VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e #game_challengeItem_image";waiter_timeout_next(20000)
      wait_element(_SELECTOR)!
      sleep(200)!
      /*Browser*/
      _SELECTOR = VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e #game_challengeItem_image";
      wait_element(_SELECTOR)!
      get_element_selector(_SELECTOR, false).attr("src")!
      VAR_SAVED_ATTRIBUTE = _result()
      _set_if_expression("W1tTQVZFRF9BVFRSSUJVVEVdXS5pbmRleE9mKCJkYXRhOmltYWdlL2dpZjtiYXNlNjQiKSA+PSAw");
      _if(VAR_SAVED_ATTRIBUTE.indexOf("data:image/gif;base64") >= 0,function(){
      var replace_string_funcap = "data:image/gif;base64,"
      VAR_IMAGE_BASE_64 = VAR_SAVED_ATTRIBUTE.replace(replace_string_funcap, "")
      VAR_LOADED_IMAGE_ID = native("imageprocessing", "load", VAR_IMAGE_BASE_64)
      var split = native("imageprocessing", "convert", (VAR_LOADED_IMAGE_ID) + "," + ("jpeg"))
      {
      var split = native("imageprocessing", "getsize", VAR_LOADED_IMAGE_ID).split(",")
      VAR_GET_IMAGE_W = parseInt(split[0])
      VAR_GET_IMAGE_H = parseInt(split[1])
      }
      VAR_IMAGE_BASE_64 = native("imageprocessing", "getdata", VAR_LOADED_IMAGE_ID)
      native("imageprocessing", "delete", VAR_LOADED_IMAGE_ID)
      })!
      _set_if_expression("W1tTQVZFRF9BVFRSSUJVVEVdXS5pbmRleE9mKCJkYXRhOmltYWdlL2pwZWc7YmFzZTY0IikgPj0gMA==");
      _if(VAR_SAVED_ATTRIBUTE.indexOf("data:image/jpeg;base64") >= 0,function(){
      var replace_string_funcap = "data:image/jpeg;base64,"
      VAR_IMAGE_BASE_64 = VAR_SAVED_ATTRIBUTE.replace(replace_string_funcap, "")
      VAR_LOADED_IMAGE_ID = native("imageprocessing", "load", VAR_IMAGE_BASE_64)
      {
      var split = native("imageprocessing", "getsize", VAR_LOADED_IMAGE_ID).split(",")
      VAR_GET_IMAGE_W = parseInt(split[0])
      VAR_GET_IMAGE_H = parseInt(split[1])
      }
      native("imageprocessing", "delete", VAR_LOADED_IMAGE_ID)
      })!
      })!
      _set_if_expression("W1tGVU5DQVBUQ0hBX1RZUEVdXSA9PSAiR2FtZV9UaWxlIg==");
      _if(VAR_FUNCAPTCHA_TYPE == "Game_Tile",function(){
      /*Browser*/
      ;_SELECTOR=VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e div[class*=\u0027tile-game box screen\u0027]";
      get_element_selector(_SELECTOR, false).nowait().exist()!
      VAR_IS_EXISTS = _result() == 1
      _if(VAR_IS_EXISTS, function(){
      get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
      VAR_IS_EXISTS = _result().indexOf("true")>=0
      })!
      _set_if_expression("W1tJU19FWElTVFNdXSA9PSBmYWxzZQ==");
      _if(VAR_IS_EXISTS == false,function(){
      _next("function")
      })!
      /*Browser*/
      waiter_timeout_next(45000)
      wait_load("*blob*")!
      /*Browser*/
      wait_load("*blob*")!
      cache_get_base64("*blob*")!
      VAR_IMAGE_BASE_64 = _result()
      VAR_LOADED_IMAGE_ID = native("imageprocessing", "load", VAR_IMAGE_BASE_64)
      {
      var split = native("imageprocessing", "getsize", VAR_LOADED_IMAGE_ID).split(",")
      VAR_GET_IMAGE_W = parseInt(split[0])
      VAR_GET_IMAGE_H = parseInt(split[1])
      }
      native("imageprocessing", "delete", VAR_LOADED_IMAGE_ID)
      })!
      _set_if_expression("W1tGVU5DQVBUQ0hBX1RZUEVdXSA9PSAiR2FtZV9IZWFkZXIi");
      _if(VAR_FUNCAPTCHA_TYPE == "Game_Header",function(){
      /*Browser*/
      ;_SELECTOR=VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e img[id*=\u0027challenge-image\u0027]";
      get_element_selector(_SELECTOR, false).nowait().exist()!
      VAR_IS_EXISTS = _result() == 1
      _if(VAR_IS_EXISTS, function(){
      get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
      VAR_IS_EXISTS = _result().indexOf("true")>=0
      })!
      _set_if_expression("W1tJU19FWElTVFNdXSA9PSBmYWxzZQ==");
      _if(VAR_IS_EXISTS == false,function(){
      _next("function")
      })!
      /*Browser*/
      waiter_timeout_next(45000)
      wait_load("*/rtig/image*")!
      /*Browser*/
      wait_load("*/rtig/image*")!
      cache_get_base64("*/rtig/image*")!
      VAR_IMAGE_BASE_64 = _result()
      VAR_LOADED_IMAGE_ID = native("imageprocessing", "load", VAR_IMAGE_BASE_64)
      {
      var split = native("imageprocessing", "getsize", VAR_LOADED_IMAGE_ID).split(",")
      VAR_GET_IMAGE_W = parseInt(split[0])
      VAR_GET_IMAGE_H = parseInt(split[1])
      }
      native("imageprocessing", "delete", VAR_LOADED_IMAGE_ID)
      })!
      _set_if_expression("W1tGVU5DQVBUQ0hBX1RZUEVdXSA9PSAiR2FtZV9Cb3gi");
      _if(VAR_FUNCAPTCHA_TYPE == "Game_Box",function(){
      /*Browser*/
      ;_SELECTOR=VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e div[class*=\u0027match-game box screen\u0027]";
      get_element_selector(_SELECTOR, false).nowait().exist()!
      VAR_IS_EXISTS = _result() == 1
      _if(VAR_IS_EXISTS, function(){
      get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
      VAR_IS_EXISTS = _result().indexOf("true")>=0
      })!
      _set_if_expression("W1tJU19FWElTVFNdXSA9PSBmYWxzZQ==");
      _if(VAR_IS_EXISTS == false,function(){
      _next("function")
      })!
      /*Browser*/
      waiter_timeout_next(45000)
      wait_load("*blob*")!
      /*Browser*/
      wait_load("*blob*")!
      cache_get_base64("*blob*")!
      VAR_IMAGE_BASE_64 = _result()
      })!
      _set_if_expression("W1tGVU5DQVBUQ0hBX1RZUEVdXSA9PSAiR2FtZV9DaGlsZHJlbiI=");
      _if(VAR_FUNCAPTCHA_TYPE == "Game_Children",function(){
      _set_if_expression("W1tGSVJTVF9MT0FEX0NBUFRDSEFdXSA9PSB0cnVl");
      _if(VAR_FIRST_LOAD_CAPTCHA == true,function(){
      /*Browser*/
      wait_load("*rtig/image*")!
      })!
      /*Browser*/
      ;_SELECTOR=VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e img[id*=\u0027children_challengeImage\u0027]";
      get_element_selector(_SELECTOR, false).nowait().exist()!
      VAR_IS_EXISTS = _result() == 1
      _if(VAR_IS_EXISTS, function(){
      get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
      VAR_IS_EXISTS = _result().indexOf("true")>=0
      })!
      _set_if_expression("W1tJU19FWElTVFNdXSA9PSBmYWxzZQ==");
      _if(VAR_IS_EXISTS == false,function(){
      _next("function")
      })!
      /*Browser*/
      _SELECTOR = VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e img[id*=\u0027children_challengeImage\u0027]";waiter_timeout_next(20000)
      wait_element(_SELECTOR)!
      /*Browser*/
      _SELECTOR = VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e img[id*=\u0027children_challengeImage\u0027]";
      wait_element(_SELECTOR)!
      get_element_selector(_SELECTOR, false).script('_BAS_SAFE(Window.getComputedStyle)(self)[' + JSON.stringify("background") + ']')!
      VAR_SAVED_STYLE = _result()
      // Извлекаем
      var Module_inputString = VAR_SAVED_STYLE
      var Module_regex = /data:image([^"]*)"/;
      var Module_match = Module_inputString.match(Module_regex);
      if (Module_match && Module_match.length >= 2) VAR_SAVED_STYLE = Module_match[1];
      _set_if_expression("W1tTQVZFRF9TVFlMRV1dLmluZGV4T2YoIi9naWY7YmFzZTY0IikgPj0gMA==");
      _if(VAR_SAVED_STYLE.indexOf("/gif;base64") >= 0,function(){
      var replace_string_funcap = "/gif;base64,"
      VAR_IMAGE_BASE_64 = VAR_SAVED_STYLE.replace(replace_string_funcap, "")
      })!
      _set_if_expression("W1tTQVZFRF9TVFlMRV1dLmluZGV4T2YoIi9qcGVnO2Jhc2U2NCIpID49IDA=");
      _if(VAR_SAVED_STYLE.indexOf("/jpeg;base64") >= 0,function(){
      var replace_string_funcap = "/jpeg;base64,"
      VAR_IMAGE_BASE_64 = VAR_SAVED_STYLE.replace(replace_string_funcap, "")
      })!
      })!
      },null)!
      _set_if_expression("W1tXQVNfRVJST1JdXQ==");
      _if(typeof(VAR_WAS_ERROR) !== "undefined" ? (VAR_WAS_ERROR) : undefined,function(){
      /*Browser*/
      cache_data_clear()!
      fail(VAR_LAST_ERROR)
      })!
      VAR_FIRST_LOAD_CAPTCHA = false
      _set_if_expression("dHlwZW9mKFtbSU1BR0VfQkFTRV82NF1dKSA9PSAidW5kZWZpbmVkIg==");
      _if(typeof(VAR_IMAGE_BASE_64) == "undefined",function(){
      _next("function")
      })!
      _call(function()
      {
      _on_fail(function(){
      VAR_LAST_ERROR = _result()
      VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
      VAR_WAS_ERROR = false
      _break(1,true)
      })
      CYCLES.Current().RemoveLabel("function")
      _do(function(){
      _set_action_info({ name: "For" });
      VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
      if(VAR_CYCLE_INDEX > parseInt(20))_break();
      ///Чистим
      solver_properties_clear("capmonster")
      //_SELECTOR = VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e h2";
      //wait_element(_SELECTOR)!
      //get_element_selector(_SELECTOR, false).text()!
      //VAR_SHORT_TASK = _result()
      //VAR_SHORT_TASK = VAR_SHORT_TASK.split(".")[0]
      if (VAR_FUNCAPTCHA_TYPE == "Game_Item") VAR_RETURN_TYPE = "funcap|";
      if (VAR_FUNCAPTCHA_TYPE == "Game_Tile") VAR_RETURN_TYPE = "funcap|";
      if (VAR_FUNCAPTCHA_TYPE == "Game_Box") VAR_RETURN_TYPE = "funcap2|";
      if (VAR_FUNCAPTCHA_TYPE == "Game_Children") VAR_RETURN_TYPE = "funcap2|";
      /// Формирумем основной запрос
      solver_property("capmonster","serverurl","http://goodxevilpay.pp.ua/")
      //if (VAR_FUNCAPTCHA_TYPE != "Game_Box") solver_property("capmonster","coordinatescaptcha","1")
      solver_property("capmonster","key",VAR_KEY_MODULE)
      solver_property("capmonster","imginstructions",VAR_SET_TASK)
      solver_property("capmonster","click",VAR_RETURN_TYPE)
      //solver_property("capmonster","basmodule",VAR_BAS_MODULE_VERSION)
      solver_property("capmonster","method","post")
      //// Отправляем
      solve_base64_no_fail("capmonster", VAR_IMAGE_BASE_64)!
      VAR_SAVED_CONTENT = _result();
      _set_if_expression("W1tTQVZFRF9DT05URU5UXV0uaW5kZXhPZigiRVJST1JfQ0FQVENIQV9VTlNPTFZBQkxFIikgPj0gMA==");
      _if(VAR_SAVED_CONTENT.indexOf("ERROR_CAPTCHA_UNSOLVABLE") >= 0,function(){
      VAR_ERROR_TASK = parseInt(VAR_ERROR_TASK) + parseInt(1)
      sleep(1000)!
      _break("function")
      })!
      _set_if_expression("W1tTQVZFRF9DT05URU5UXV0uaW5kZXhPZigiRVJST1JfV1JPTkdfVVNFUl9LRVkiKSA+PSAw");
      _if(VAR_SAVED_CONTENT.indexOf("ERROR_WRONG_USER_KEY") >= 0,function(){
      VAR_ERROR_KEY = "1"
      _break("function")
      })!
      _set_if_expression("W1tTQVZFRF9DT05URU5UXV0uaW5kZXhPZigiRVJST1JfWkVST19CQUxBTkNFIikgPj0gMA==");
      _if(VAR_SAVED_CONTENT.indexOf("ERROR_ZERO_BALANCE") >= 0,function(){
      VAR_ERROR_BALANCE = "1"
      _break("function")
      })!
      _set_if_expression("W1tTQVZFRF9DT05URU5UXV0uaW5kZXhPZigiQ0FQVENIQV9GQUlMIikgPj0gMA==");
      _if(VAR_SAVED_CONTENT.indexOf("CAPTCHA_FAIL") >= 0,function(){
      sleep(rand(1000,1000))!
      VAR_CAPTCHA_FAIL = parseInt(VAR_CAPTCHA_FAIL) + parseInt(1)
      _break("function")
      })!
      _cycle_params().if_else = VAR_SAVED_CONTENT.match(/^\d+$/) && (VAR_FUNCAPTCHA_TYPE == "Game_Box" || VAR_FUNCAPTCHA_TYPE == "Game_Children") || VAR_SAVED_CONTENT.match(/[0-9]/) && VAR_SAVED_CONTENT.indexOf("coordinates") >= 0 && VAR_FUNCAPTCHA_TYPE != "Game_Box" && VAR_FUNCAPTCHA_TYPE != "Game_Children";
      _set_if_expression("W1tTQVZFRF9DT05URU5UXV0ubWF0Y2goL15cZCskLykgJiYgKFtbRlVOQ0FQVENIQV9UWVBFXV0gPT0gIkdhbWVfQm94IiB8fCBbW0ZVTkNBUFRDSEFfVFlQRV1dID09ICJHYW1lX0NoaWxkcmVuIikgfHwgW1tTQVZFRF9DT05URU5UXV0ubWF0Y2goL1swLTldLykgJiYgW1tTQVZFRF9DT05URU5UXV0uaW5kZXhPZigiY29vcmRpbmF0ZXMiKSA+PSAwICYmIFtbRlVOQ0FQVENIQV9UWVBFXV0gIT0gIkdhbWVfQm94IiAmJiBbW0ZVTkNBUFRDSEFfVFlQRV1dICE9ICJHYW1lX0NoaWxkcmVuIg==");
      _if(_cycle_params().if_else,function(){
      /*Browser*/
      cache_data_clear()!
      _set_if_expression("W1tGVU5DQVBUQ0hBX1RZUEVdXSA9PSAiR2FtZV9JdGVtIiB8fCBbW0ZVTkNBUFRDSEFfVFlQRV1dID09ICJHYW1lX0hlYWRlciIgfHwgW1tGVU5DQVBUQ0hBX1RZUEVdXSA9PSAiR2FtZV9UaWxlIg==");
      _if(VAR_FUNCAPTCHA_TYPE == "Game_Item" || VAR_FUNCAPTCHA_TYPE == "Game_Header" || VAR_FUNCAPTCHA_TYPE == "Game_Tile",function(){
      VAR_LISTS_COORDINATES = VAR_SAVED_CONTENT
      VAR_LISTS_COORDINATES = VAR_LISTS_COORDINATES.split("coordinates:")[1];
      VAR_LISTS_COORDINATES = VAR_LISTS_COORDINATES.split(";");
      ;(function (a) {var j, x, i;for (i = a.length; i; i--) {j = Math.floor(Math.random() * i);x = a[i - 1]; a[i - 1] = a[j];a[j] = x;}})(VAR_LISTS_COORDINATES)
      _do_with_params({"foreach_data":(VAR_LISTS_COORDINATES)},function(){
      _set_action_info({ name: "Foreach" });
      VAR_CYCLE_INDEX = _iterator() - 1
      if(VAR_CYCLE_INDEX > _cycle_param("foreach_data").length - 1)_break();
      VAR_FOREACH_DATA = _cycle_param("foreach_data")[VAR_CYCLE_INDEX]
      var csv_parse_result = csv_parse(VAR_FOREACH_DATA)
      VAR_ANSWER_X = csv_parse_result[0]
      if(typeof(VAR_ANSWER_X) == 'undefined' || !VAR_ANSWER_X)
      {
      VAR_ANSWER_X = ""
      }
      VAR_ANSWER_Y = csv_parse_result[1]
      if(typeof(VAR_ANSWER_Y) == 'undefined' || !VAR_ANSWER_Y)
      {
      VAR_ANSWER_Y = ""
      }
      VAR_ANSWER_X = VAR_ANSWER_X.replace(/[^0-9]/g, '');
      VAR_ANSWER_Y = VAR_ANSWER_Y.replace(/[^0-9]/g, '');
      VAR_ANSWER_X = parseInt(VAR_ANSWER_X)
      VAR_ANSWER_Y = parseInt(VAR_ANSWER_Y)
      if (VAR_TILE_NORMAL_VIEW == 0 || VAR_TILE_NORMAL_VIEW == true)
      {
      /// Реальные размеры картинки из кэша
      var bigWidth = VAR_GET_IMAGE_W;
      var bigHeight = VAR_GET_IMAGE_H;
      /// Реальные размеры картинки из СSS окна
      var smallWidth = VAR_REAL_SIZE_WIDTH;
      var smallHeight = VAR_REAL_SIZE_HEIGHT;
      var xBig = VAR_ANSWER_X; // координата x на большой картинке
      var yBig = VAR_ANSWER_Y; // координата y на большой картинке
      VAR_ANSWER_X = xBig / bigWidth  * smallWidth; // преобразование x
      VAR_ANSWER_Y = yBig / bigHeight * smallHeight;  // преобразование y
      }
      if (VAR_FUNCAPTCHA_TYPE == "Game_Tile" && VAR_TILE_NORMAL_VIEW == false) {
      /// Переворачиваем координаты
      if (VAR_ANSWER_X == 150 && VAR_ANSWER_Y == 150) VAR_ANSWER_X = 50, VAR_ANSWER_Y = 250
      if (VAR_ANSWER_X == 50 && VAR_ANSWER_Y == 150) VAR_ANSWER_X = 150, VAR_ANSWER_Y = 150
      if (VAR_ANSWER_X == 250 && VAR_ANSWER_Y == 50) VAR_ANSWER_X = 50, VAR_ANSWER_Y = 150
      if (VAR_ANSWER_X == 250 && VAR_ANSWER_Y == 150) VAR_ANSWER_X = 150, VAR_ANSWER_Y = 250
      }
      VAR_SQUARE_BUTTON_X_CLICK = 0;
      VAR_SQUARE_BUTTON_Y_CLICK = 0;
      VAR_SQUARE_BUTTON_X_CLICK = VAR_SQUARE_BUTTON_X + VAR_ANSWER_X + rand (-10,+10);
      VAR_SQUARE_BUTTON_Y_CLICK = VAR_SQUARE_BUTTON_Y + VAR_ANSWER_Y + rand (-10,+10);
      /*Browser*/
      move(VAR_SQUARE_BUTTON_X_CLICK,VAR_SQUARE_BUTTON_Y_CLICK,  {"speed": VAR_SPEED,"gravity": VAR_GRAVITY,"deviation": VAR_DEVIATION} )!
      mouse(VAR_SQUARE_BUTTON_X_CLICK,VAR_SQUARE_BUTTON_Y_CLICK)!
      })!
      })!
      _set_if_expression("KFtbRlVOQ0FQVENIQV9UWVBFXV0gPT0gIkdhbWVfQm94IiB8fCBbW0ZVTkNBUFRDSEFfVFlQRV1dID09ICJHYW1lX0NoaWxkcmVuIikgJiYgW1tTQVZFRF9DT05URU5UXV0gIT0x");
      _if((VAR_FUNCAPTCHA_TYPE == "Game_Box" || VAR_FUNCAPTCHA_TYPE == "Game_Children") && VAR_SAVED_CONTENT !=1,function(){
      _do(function(){
      _set_action_info({ name: "For" });
      VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
      if(VAR_CYCLE_INDEX > parseInt(VAR_SAVED_CONTENT - 1))_break();
      VAR_DIRECT_BUTTON_X_CLICK = 0;
      VAR_DIRECT_BUTTON_Y_CLICK = 0;
      VAR_DIRECT_BUTTON_X_CLICK = VAR_DIRECT_BUTTON_X + rand(-8,+8);
      VAR_DIRECT_BUTTON_Y_CLICK = VAR_DIRECT_BUTTON_Y + rand(-8,+8);
      /*Browser*/
      move(VAR_DIRECT_BUTTON_X_CLICK,VAR_DIRECT_BUTTON_Y_CLICK,  {} )!
      mouse(VAR_DIRECT_BUTTON_X_CLICK,VAR_DIRECT_BUTTON_Y_CLICK)!
      _cycle_params().if_else = rand (1,10) > 5;
      _set_if_expression("cmFuZCAoMSwxMCkgPiA1");
      _if(_cycle_params().if_else,function(){
      sleep(rand(100,200))!
      })!
      _if(!_cycle_params().if_else,function(){
      sleep(rand(200,300))!
      })!
      delete _cycle_params().if_else;
      _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gMjU=");
      _if(VAR_CYCLE_INDEX > 25,function(){
      _break("function")
      })!
      })!
      /*Browser*/
      ;_SELECTOR=VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e img[style*=\u0027blob\u0027]";
      get_element_selector(_SELECTOR, false).nowait().exist()!
      VAR_IS_EXISTS = _result() == 1
      _if(VAR_IS_EXISTS, function(){
      get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
      VAR_IS_EXISTS = _result().indexOf("true")>=0
      })!
      _set_if_expression("W1tJU19FWElTVFNdXQ==");
      _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
      sleep(100)!
      /*Browser*/
      _SELECTOR = VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e img[style*=\u0027blob\u0027]";
      wait_element(_SELECTOR)!
      get_element_selector(_SELECTOR, false).attr("aria-label")!
      VAR_SAVED_ATTRIBUTE = _result()
      function findSmallestNumber(str) {
      var numbers = str.match(/-?\d+(\.\d+)?/g); // получаем все числа из строки
      var smallest = Math.min.apply(Math, numbers); // находим минимальное число
      return smallest;
      }
      var str = VAR_SAVED_ATTRIBUTE
      VAR_MIN_NUMBERS_TASK = findSmallestNumber(str);
      _set_if_expression("W1tNSU5fTlVNQkVSU19UQVNLXV0gPT0gMQ==");
      _if(VAR_MIN_NUMBERS_TASK == 1,function(){
      VAR_ELEMENT_SELECTOR = VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e a[class*=\u0027left-arrow\u0027]"
      _SELECTOR = VAR_ELEMENT_SELECTOR;
      get_element_selector(_SELECTOR, false).script("(function(){var rect = _BAS_HIDE(BrowserAutomationStudio_GetBoundingClientRect)(self);return (rect.left + positionx) + '|' + (rect.top + positiony) + '|' + (rect.right - rect.left) + '|' + (rect.bottom - rect.top)})();")!
      var split = _result().split("|");
      var x = parseInt(split[0]), y = parseInt(split[1]), w = parseInt(split[2]), h = parseInt(split[3]);
      /// Первый квадрат
      VAR_DIRECT_BUTTON_X = parseInt(x)
      VAR_DIRECT_BUTTON_Y = parseInt(y) + VAR_SCROLL_Y;
      VAR_DIRECT_WIDTH = parseInt(w)
      VAR_DIRECT_HEIGHT = parseInt(h)
      ////Высчитаем центр стрелочки
      VAR_DIRECT_BUTTON_X = VAR_DIRECT_BUTTON_X + VAR_DIRECT_WIDTH/2;
      VAR_DIRECT_BUTTON_Y = VAR_DIRECT_BUTTON_Y + VAR_DIRECT_HEIGHT/2;
      _do(function(){
      _set_action_info({ name: "For" });
      VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
      if(VAR_CYCLE_INDEX > parseInt(10))_break();
      _set_if_expression("W1tTQVZFRF9DT05URU5UXV0gPT0gNg==");
      _if(VAR_SAVED_CONTENT == 6,function(){
      VAR_SAVED_CONTENT = "1"
      _break("function")
      })!
      _set_if_expression("W1tTQVZFRF9DT05URU5UXV0gPT0gNQ==");
      _if(VAR_SAVED_CONTENT == 5,function(){
      VAR_SAVED_CONTENT = "2"
      _break("function")
      })!
      _set_if_expression("W1tTQVZFRF9DT05URU5UXV0gPT0gNA==");
      _if(VAR_SAVED_CONTENT == 4,function(){
      VAR_SAVED_CONTENT = "3"
      _break("function")
      })!
      _set_if_expression("W1tTQVZFRF9DT05URU5UXV0gPT0gMw==");
      _if(VAR_SAVED_CONTENT == 3,function(){
      VAR_SAVED_CONTENT = "4"
      _break("function")
      })!
      _set_if_expression("W1tTQVZFRF9DT05URU5UXV0gPT0gMg==");
      _if(VAR_SAVED_CONTENT == 2,function(){
      VAR_SAVED_CONTENT = "5"
      _break("function")
      })!
      sleep(300)!
      })!
      _do(function(){
      _set_action_info({ name: "For" });
      VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
      if(VAR_CYCLE_INDEX > parseInt(VAR_SAVED_CONTENT))_break();
      VAR_DIRECT_BUTTON_X_CLICK = 0;
      VAR_DIRECT_BUTTON_Y_CLICK = 0;
      VAR_DIRECT_BUTTON_X_CLICK = VAR_DIRECT_BUTTON_X + rand(-8,+8);
      VAR_DIRECT_BUTTON_Y_CLICK = VAR_DIRECT_BUTTON_Y + rand(-8,+8);
      /*Browser*/
      move(VAR_DIRECT_BUTTON_X_CLICK,VAR_DIRECT_BUTTON_Y_CLICK,  {} )!
      mouse(VAR_DIRECT_BUTTON_X_CLICK,VAR_DIRECT_BUTTON_Y_CLICK)!
      _cycle_params().if_else = rand (1,10) > 5;
      _set_if_expression("cmFuZCAoMSwxMCkgPiA1");
      _if(_cycle_params().if_else,function(){
      sleep(rand(100,200))!
      })!
      _if(!_cycle_params().if_else,function(){
      sleep(rand(200,500))!
      })!
      delete _cycle_params().if_else;
      _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gMjA=");
      _if(VAR_CYCLE_INDEX > 20,function(){
      _break("function")
      })!
      })!
      VAR_GET_ALL_COORDINATES = "0"
      })!
      })!
      /*Browser*/
      ;_SELECTOR=VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e img[id*=\u0027children_challengeImage\u0027]";
      get_element_selector(_SELECTOR, false).nowait().exist()!
      VAR_IS_EXISTS = _result() == 1
      _if(VAR_IS_EXISTS, function(){
      get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
      VAR_IS_EXISTS = _result().indexOf("true")>=0
      })!
      _set_if_expression("W1tJU19FWElTVFNdXQ==");
      _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
      sleep(100)!
      /*Browser*/
      _SELECTOR = VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e img[id*=\u0027children_challengeImage\u0027]";
      wait_element(_SELECTOR)!
      get_element_selector(_SELECTOR, false).attr("aria-label")!
      VAR_SAVED_ATTRIBUTE = _result()
      function findSmallestNumber(str) {
      var numbers = str.match(/-?\d+(\.\d+)?/g); // получаем все числа из строки
      var smallest = Math.min.apply(Math, numbers); // находим минимальное число
      return smallest;
      }
      var str = VAR_SAVED_ATTRIBUTE
      VAR_MIN_NUMBERS_TASK = findSmallestNumber(str);
      _set_if_expression("W1tNSU5fTlVNQkVSU19UQVNLXV0gPT0gMQ==");
      _if(VAR_MIN_NUMBERS_TASK == 1,function(){
      VAR_ELEMENT_SELECTOR = VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e a[id*=\u0027Frame_children_arrowLeft\u0027]"
      _SELECTOR = VAR_ELEMENT_SELECTOR;
      get_element_selector(_SELECTOR, false).script("(function(){var rect = _BAS_HIDE(BrowserAutomationStudio_GetBoundingClientRect)(self);return (rect.left + positionx) + '|' + (rect.top + positiony) + '|' + (rect.right - rect.left) + '|' + (rect.bottom - rect.top)})();")!
      var split = _result().split("|");
      var x = parseInt(split[0]), y = parseInt(split[1]), w = parseInt(split[2]), h = parseInt(split[3]);
      /// Первый квадрат
      VAR_DIRECT_BUTTON_X = parseInt(x)
      VAR_DIRECT_BUTTON_Y = parseInt(y) + VAR_SCROLL_Y;
      VAR_DIRECT_WIDTH = parseInt(w)
      VAR_DIRECT_HEIGHT = parseInt(h)
      ////Высчитаем центр стрелочки
      VAR_DIRECT_BUTTON_X = VAR_DIRECT_BUTTON_X + VAR_DIRECT_WIDTH/2;
      VAR_DIRECT_BUTTON_Y = VAR_DIRECT_BUTTON_Y + VAR_DIRECT_HEIGHT/2;
      _do(function(){
      _set_action_info({ name: "For" });
      VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
      if(VAR_CYCLE_INDEX > parseInt(10))_break();
      _set_if_expression("W1tTQVZFRF9DT05URU5UXV0gPT0gNg==");
      _if(VAR_SAVED_CONTENT == 6,function(){
      VAR_SAVED_CONTENT = "1"
      _break("function")
      })!
      _set_if_expression("W1tTQVZFRF9DT05URU5UXV0gPT0gNQ==");
      _if(VAR_SAVED_CONTENT == 5,function(){
      VAR_SAVED_CONTENT = "2"
      _break("function")
      })!
      _set_if_expression("W1tTQVZFRF9DT05URU5UXV0gPT0gNA==");
      _if(VAR_SAVED_CONTENT == 4,function(){
      VAR_SAVED_CONTENT = "3"
      _break("function")
      })!
      _set_if_expression("W1tTQVZFRF9DT05URU5UXV0gPT0gMw==");
      _if(VAR_SAVED_CONTENT == 3,function(){
      VAR_SAVED_CONTENT = "4"
      _break("function")
      })!
      _set_if_expression("W1tTQVZFRF9DT05URU5UXV0gPT0gMg==");
      _if(VAR_SAVED_CONTENT == 2,function(){
      VAR_SAVED_CONTENT = "5"
      _break("function")
      })!
      sleep(300)!
      })!
      _do(function(){
      _set_action_info({ name: "For" });
      VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
      if(VAR_CYCLE_INDEX > parseInt(VAR_SAVED_CONTENT))_break();
      VAR_DIRECT_BUTTON_X_CLICK = 0;
      VAR_DIRECT_BUTTON_Y_CLICK = 0;
      VAR_DIRECT_BUTTON_X_CLICK = VAR_DIRECT_BUTTON_X + rand(-8,+8);
      VAR_DIRECT_BUTTON_Y_CLICK = VAR_DIRECT_BUTTON_Y + rand(-8,+8);
      /*Browser*/
      move(VAR_DIRECT_BUTTON_X_CLICK,VAR_DIRECT_BUTTON_Y_CLICK,  {} )!
      mouse(VAR_DIRECT_BUTTON_X_CLICK,VAR_DIRECT_BUTTON_Y_CLICK)!
      _cycle_params().if_else = rand (1,10) > 5;
      _set_if_expression("cmFuZCAoMSwxMCkgPiA1");
      _if(_cycle_params().if_else,function(){
      sleep(rand(100,200))!
      })!
      _if(!_cycle_params().if_else,function(){
      sleep(rand(200,500))!
      })!
      delete _cycle_params().if_else;
      _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gMjA=");
      _if(VAR_CYCLE_INDEX > 20,function(){
      _break("function")
      })!
      })!
      VAR_GET_ALL_COORDINATES = "0"
      })!
      })!
      })!
      VAR_ERROR_TASK = 0
      VAR_CURRENT_TASK_NUMBERS = parseInt(VAR_CURRENT_TASK_NUMBERS) + parseInt(-1)
      sleep(200)!
      _set_if_expression("W1tGVU5DQVBUQ0hBX1RZUEVdXSA9PSAiR2FtZV9JdGVtIiAmJiBbW0NVUlJFTlRfVEFTS19OVU1CRVJTXV0gIT0w");
      _if(VAR_FUNCAPTCHA_TYPE == "Game_Item" && VAR_CURRENT_TASK_NUMBERS !=0,function(){
      /*Browser*/
      _SELECTOR = VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e #game_challengeItem_image";waiter_timeout_next(20000)
      wait_element(_SELECTOR)!
      })!
      _set_if_expression("W1tGVU5DQVBUQ0hBX1RZUEVdXSA9PSAiR2FtZV9UaWxlIiAmJiBbW0NVUlJFTlRfVEFTS19OVU1CRVJTXV0gIT0w");
      _if(VAR_FUNCAPTCHA_TYPE == "Game_Tile" && VAR_CURRENT_TASK_NUMBERS !=0,function(){
      /*Browser*/
      _SELECTOR = VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e div[class*=\u0027tile-game box screen\u0027]";waiter_timeout_next(20000)
      wait_element(_SELECTOR)!
      })!
      _set_if_expression("W1tGVU5DQVBUQ0hBX1RZUEVdXSA9PSAiR2FtZV9IZWFkZXIiICYmIFtbQ1VSUkVOVF9UQVNLX05VTUJFUlNdXSAhPTA=");
      _if(VAR_FUNCAPTCHA_TYPE == "Game_Header" && VAR_CURRENT_TASK_NUMBERS !=0,function(){
      /*Browser*/
      _SELECTOR = VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e img[id*=\u0027challenge-image\u0027]";waiter_timeout_next(20000)
      wait_element(_SELECTOR)!
      })!
      _set_if_expression("W1tGVU5DQVBUQ0hBX1RZUEVdXSA9PSAiR2FtZV9Cb3gi");
      _if(VAR_FUNCAPTCHA_TYPE == "Game_Box",function(){
      _do(function(){
      _set_action_info({ name: "For" });
      VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
      if(VAR_CYCLE_INDEX > parseInt(60))_break();
      /*Browser*/
      ;_SELECTOR=VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e div[class*=\u0027match-game box screen\u0027] \u003eCSS\u003e button";
      get_element_selector(_SELECTOR, false).nowait().exist()!
      VAR_IS_EXISTS = _result() == 1
      _if(VAR_IS_EXISTS, function(){
      get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
      VAR_IS_EXISTS = _result().indexOf("true")>=0
      })!
      _set_if_expression("W1tJU19FWElTVFNdXQ==");
      _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
      /*Browser*/
      _SELECTOR = VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e div[class*=\u0027match-game box screen\u0027] \u003eCSS\u003e button";
      wait_element_visible(_SELECTOR)!
      _call(_random_point, {})!
      _if(_result().length > 0, function(){
      move( {} )!
      get_element_selector(_SELECTOR, false).clarify(X,Y)!
      _call(_clarify, {} )!
      mouse(X,Y)!
      })!
      _break("function")
      })!
      sleep(100)!
      })!
      _set_if_expression("W1tDVVJSRU5UX1RBU0tfTlVNQkVSU11dICE9IDA=");
      _if(VAR_CURRENT_TASK_NUMBERS != 0,function(){
      /*Browser*/
      _SELECTOR = VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e div[class*=\u0027match-game box screen\u0027]";waiter_timeout_next(20000)
      wait_element(_SELECTOR)!
      })!
      })!
      _set_if_expression("W1tGVU5DQVBUQ0hBX1RZUEVdXSA9PSAiR2FtZV9DaGlsZHJlbiI=");
      _if(VAR_FUNCAPTCHA_TYPE == "Game_Children",function(){
      _do(function(){
      _set_action_info({ name: "For" });
      VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
      if(VAR_CYCLE_INDEX > parseInt(60))_break();
      /*Browser*/
      ;_SELECTOR=VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e div[id*=\u0027game_children_buttonContainer\u0027]";
      get_element_selector(_SELECTOR, false).nowait().exist()!
      VAR_IS_EXISTS = _result() == 1
      _if(VAR_IS_EXISTS, function(){
      get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
      VAR_IS_EXISTS = _result().indexOf("true")>=0
      })!
      _set_if_expression("W1tJU19FWElTVFNdXQ==");
      _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
      /*Browser*/
      _SELECTOR = VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e div[id*=\u0027game_children_buttonContainer\u0027]";
      wait_element_visible(_SELECTOR)!
      _call(_random_point, {})!
      _if(_result().length > 0, function(){
      move( {} )!
      get_element_selector(_SELECTOR, false).clarify(X,Y)!
      _call(_clarify, {} )!
      mouse(X,Y)!
      })!
      _break("function")
      })!
      sleep(100)!
      })!
      _set_if_expression("W1tDVVJSRU5UX1RBU0tfTlVNQkVSU11dICE9IDA=");
      _if(VAR_CURRENT_TASK_NUMBERS != 0,function(){
      /*Browser*/
      _SELECTOR = VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e img[id*=\u0027children_challengeImage\u0027]";waiter_timeout_next(20000)
      wait_element(_SELECTOR)!
      })!
      })!
      _set_if_expression("W1tDVVJSRU5UX1RBU0tfTlVNQkVSU11dIDwgMQ==");
      _if(VAR_CURRENT_TASK_NUMBERS < 1,function(){
      _cycle_params().if_else = VAR_IS_MOBILE === false;
      _set_if_expression("W1tJU19NT0JJTEVdXSA9PT0gZmFsc2U=");
      _if(_cycle_params().if_else,function(){
      sleep(rand(100,300))!
      _get_browser_screen_settings()!
      ;(function(){
      var result = JSON.parse(_result())
      VAR_SCROLL_X = result["ScrollX"]
      VAR_SCROLL_Y = result["ScrollY"]
      VAR_CURSOR_X = result["CursorX"]
      VAR_CURSOR_Y = result["CursorY"]
      VAR_BROWSER_WIDTH = result["Width"]
      VAR_BROWSER_HEIGHT = result["Height"]
      })();
      var scroll_x=parseInt(VAR_CURSOR_Y);
      var scroll_y=parseInt(VAR_SCROLL_Y);
      var browser_h=parseInt(VAR_BROWSER_HEIGHT);
      //-------------------- Привели все в числа, считаем позицию ---------------------
      var absolut_y = VAR_CURSOR_Y + VAR_SCROLL_Y;
      var y_without_scroll = absolut_y - VAR_SCROLL_Y;
      var check_y_top = VAR_BROWSER_HEIGHT/12;
      var check_y_down = VAR_BROWSER_HEIGHT/100*92;
      var move_y_top = VAR_BROWSER_HEIGHT/10;
      var move_y_down = VAR_BROWSER_HEIGHT/100*80;
      // -------------------------- Округляем ----------------------------------
      VAR_CHECK_Y_TOP = check_y_top.toFixed();
      VAR_CHECK_Y_DOWN = check_y_down.toFixed();
      VAR_Y_WITHOUNT_SCROLL = y_without_scroll.toFixed();
      VAR_MOVE_Y_TOP = move_y_top.toFixed();
      VAR_MOVE_Y_DOWN = move_y_down.toFixed();
      // ----------------- Снова приводим к числу ------------------------
      VAR_CHECK_Y_TOP=parseInt(VAR_CHECK_Y_TOP);
      VAR_CHECK_Y_DOWN=parseInt(VAR_CHECK_Y_DOWN);
      VAR_Y_WITHOUNT_SCROLL=parseInt(VAR_Y_WITHOUNT_SCROLL);
      VAR_MOVE_Y_TOP=parseInt(VAR_MOVE_Y_TOP);
      VAR_MOVE_Y_DOWN=parseInt(VAR_MOVE_Y_DOWN);
      /*Browser*/
      move(rand(VAR_BROWSER_WIDTH/5,VAR_BROWSER_WIDTH/1.3),rand(VAR_MOVE_Y_TOP + VAR_SCROLL_Y,VAR_MOVE_Y_DOWN + VAR_SCROLL_Y),  {} )!
      })!
      _if(!_cycle_params().if_else,function(){
      sleep(rand(100,200))!
      })!
      delete _cycle_params().if_else;
      })!
      VAR_RESULT_SELECTOR = 0
      _break("function")
      })!
      _if(!_cycle_params().if_else,function(){
      sleep(1000)!
      VAR_ERROR_CAPTCHA_UNSOLVABLE_MODULE = parseInt(VAR_ERROR_CAPTCHA_UNSOLVABLE_MODULE) + parseInt(1)
      _break("function")
      })!
      delete _cycle_params().if_else;
      })!
      _next("function")
      },null)!
      _set_if_expression("W1tXQVNfRVJST1JdXQ==");
      _if(typeof(VAR_WAS_ERROR) !== "undefined" ? (VAR_WAS_ERROR) : undefined,function(){
      VAR_ERROR_LOAD_NEXT_PICTURE_FUNCAPTCHA = 1
      sleep(1000)!
      _next("function")
      })!
      })!
      

   }
   

