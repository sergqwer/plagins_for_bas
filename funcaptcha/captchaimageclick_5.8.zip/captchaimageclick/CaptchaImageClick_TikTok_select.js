var iodepnsd = GetInputConstructorValue("iodepnsd", loader);
                 if(iodepnsd["original"].length == 0)
                 {
                   Invalid(tr("This action cannot be created. Cause: ") + tr("Key of CaptchaGuru ") + tr("is not specified"));	
                   return;
                 }
var dooglasb = GetInputConstructorValue("dooglasb", loader);
                 if(dooglasb["original"].length == 0)
                 {
                   Invalid(tr("This action cannot be created. Cause: ") + tr("Captcha Guru Server ") + tr("is not specified"));	
                   return;
                 }
var jkcqszxl = GetInputConstructorValue("jkcqszxl", loader);
                 if(jkcqszxl["original"].length == 0)
                 {
                   Invalid("SPEED_MOUSE" + " is empty");
                   return;
                 }
var ldsvthug = GetInputConstructorValue("ldsvthug", loader);
                 if(ldsvthug["original"].length == 0)
                 {
                   Invalid("TRY_MAX_CAPTCHA_PICTURE" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#CaptchaImageClick_TikTok_code").html())({"iodepnsd": iodepnsd["updated"],"dooglasb": dooglasb["updated"],"jkcqszxl": jkcqszxl["updated"],"ldsvthug": ldsvthug["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
