<div class="container-fluid">
<%= _.template($('#input_constructor').html())({id:"zetrilkf", description:tr("Captcha Selector"), default_selector: "string", disable_expression:true, disable_int:true, value_string: ">CSS> div[class*='geetest_btn']", help: {description: tr("Specify your captcha selector in this setting. All you need to do is place a button selector that opens a window with the GeeTest captcha solution.")} }) %>
<%= _.template($('#input_constructor').html())({id:"zrsiisyg", description:tr("Solve Method"), default_selector: "string", variants: ["CaptchaGuru (RU Server)", "CaptchaGuru (German Server)", "CaptchaGuru (Finland Server)"], disable_expression:true, disable_int:true, value_string: "", help: {description: tr("In this string you need to specify which of the CaptchaGuru servers you want to send your captcha to. Please note, that captcha solving requests are not sent through a proxy, but directly from the Internet connection of your PC or server. If you observe problems with access to one of the servers, then change the solution server in the settings. It is recommended to use the RU server if you solve captcha on a server or PC from Russia, if your server is located outside of Russia, then it is recommended to use a server in Germany for solving.")} }) %>
<%= _.template($('#input_constructor').html())({id:"xsjngzty", description:tr("Secret API Key"), default_selector: "string", disable_expression:true, disable_int:true, value_string: "", help: {description: tr("In this field, you must specify the secret API key for your solution method, this key must be purchased at the recognition service https://captcha.guru. Example: 1ceb81e1cbd343b136bcc3975f914dd1")} }) %>
<div style="margin-left: 20px;">
<input type="checkbox" id="AdvancedCheck" onchange="$('#Advanced').toggle()" />
<label for="AdvancedCheck" class="tr" >Advanced settings.</label>
</div>
<span id="Advanced" style="display:none">
<%= _.template($('#input_constructor').html())({id:"ambhfnyz", description:tr("Attempts to solve"), default_selector: "int", disable_string: true, value_number: 10, min_number:5, max_number:999999, help: {description: tr("This parameter determines the maximum number of attempts to solve the captcha dragging the slider at the round geetest captcha. Recommended value is 10.")} }) %>
</span>
</div>
<div class="tooltipinternal">
<div class="tr tooltip-paragraph-first-fold">Решить <span style="color: #FFA500;">GeeTest</span> капчу, используя метод кликов по изображению или метод перетягивания ползунка в заданное направление.</div>
<div class="tr tooltip-paragraph-fold"><code>Note! In order to solve this captcha, you need to select the button selector on the site that opens the window with the GeeTest captcha and place it on the selector field in the module settings.</code></div>
<div class="tr tooltip-paragraph-fold"><code>Note!</code> In order to solve this capcha, you need to resolve the cache in the current thread, you can do this here: the 'Network' module - the 'Allow cache' action. You must create one action with the following mask - <code>*geetest.com/*/bg*</code> and <code>*geetest.com/captcha*</code> and <code>*geetest.com/nerualpic*</code>.</div>
<div class="tr tooltip-paragraph-fold">You need to place these actions at the beginning of the template, for example, after loading the page with the site where you collected the captcha.</div>
<div class="tr tooltip-paragraph-fold">This action performs automatic clicks on image numbers or coordinates, takes a screenshot of the image and sends it to the service or program you specified by the capch solution. There is no need to perform any additional actions.</div>
<div class="tr tooltip-paragraph-fold">This solution method is convenient in that you do not need to search for how to call 'callback' on the site, study complex JavaScripts in order to successfully pass the captcha solution.</div>
<div class="tr tooltip-paragraph-fold">This means that you do not need to constantly disable or enable this module in your scripts for fear of sanctions from the site. For example, when you warm up a profile, this action will not create any new properties of the window object or even replace the current ones.</div>
<div class="tr tooltip-paragraph-last-fold">Pay attention! This action does not create any 'dangerous code' inside the browser and does not break other types of captcha on sites, as the actions to solve captcha from the context menu do.</div>
</div>
<%= _.template($('#back').html())({action:"executeandadd", visible:true}) %>

