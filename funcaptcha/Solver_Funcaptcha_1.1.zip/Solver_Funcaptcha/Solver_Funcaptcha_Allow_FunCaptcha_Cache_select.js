try{
          var code = loader.GetAdditionalData() + _.template($("#Solver_Funcaptcha_Allow_FunCaptcha_Cache_code").html())({});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
