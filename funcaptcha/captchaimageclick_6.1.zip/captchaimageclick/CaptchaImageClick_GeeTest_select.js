var xsjngzty = GetInputConstructorValue("xsjngzty", loader);
                 if(xsjngzty["original"].length == 0)
                 {
                   Invalid(tr("This action cannot be created. Cause: ") + tr("Key of CaptchaGuru ") + tr("is not specified"));
                   return;
                 }
var zrsiisyg = GetInputConstructorValue("zrsiisyg", loader);
                 if(zrsiisyg["original"].length == 0)
                 {
                   Invalid(tr("This action cannot be created. Cause: ") + tr("Captcha Guru Server ") + tr("is not specified"));	
                   return;
                 }
var zetrilkf = GetInputConstructorValue("zetrilkf", loader);
                 if(zetrilkf["original"].length == 0)
                 {
                   Invalid(tr("This action cannot be created. Cause: ") + tr("Selector of captcha ") + tr("is not specified"));
                   return;
                 }
var ambhfnyz = GetInputConstructorValue("ambhfnyz", loader);
                 if(ambhfnyz["original"].length == 0)
                 {
                   Invalid("TRY_MAX_CAPTCHA_PICTURE" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#CaptchaImageClick_GeeTest_code").html())({"xsjngzty": xsjngzty["updated"],"zrsiisyg": zrsiisyg["updated"],"zetrilkf": zetrilkf["updated"],"ambhfnyz": ambhfnyz["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
