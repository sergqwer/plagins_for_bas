<div class="container-fluid">
<%= _.template($('#input_constructor').html())({id:"ynyuevjc", description:tr("Captcha Selector"), default_selector: "string", disable_expression:true, disable_int:true, value_string: ">CSS> input[class*='CheckboxCaptcha-Button']", help: {description: tr("This parameter defines the selector for the button that opens the Yandex captcha solution form. The default selector is already set correctly to the 'I'm not a robot' button, but if you have trouble opening the captcha window, you can change this selector if you like.")} }) %>
<%= _.template($('#input_constructor').html())({id:"ubkshdvd", description:tr("Solve Method"), default_selector: "string", variants: ["CaptchaGuru (RU Server)", "CaptchaGuru (German Server)", "CaptchaGuru (Finland Server)"], disable_expression:true, disable_int:true, value_string: "", help: {description: tr("In this string you need to specify which of the CaptchaGuru servers you want to send your captcha to. Please note, that captcha solving requests are not sent through a proxy, but directly from the Internet connection of your PC or server. If you observe problems with access to one of the servers, then change the solution server in the settings. It is recommended to use the RU server if you solve captcha on a server or PC from Russia, if your server is located outside of Russia, then it is recommended to use a server in Germany for solving.")} }) %>
<%= _.template($('#input_constructor').html())({id:"dmxzrntj", description:tr("Secret API Key"), default_selector: "string", disable_expression:true, disable_int:true, value_string: "", help: {description: tr("In this field, you must specify the secret API key for your solution method, this key must be purchased at the recognition service https://captcha.guru. Example: 1ceb81e1cbd343b136bcc3975f914dd1")} }) %>
<div style="margin-left: 20px;">
<input type="checkbox" id="AdvancedCheck" onchange="$('#Advanced').toggle()" />
<label for="AdvancedCheck" class="tr">Advanced settings.</label>
</div>
<span id="Advanced" style="display:none">
<%= _.template($('#input_constructor').html())({id:"kucmgqgy", description:tr("Attempts to solve"), default_selector: "int", disable_string: true, value_number: 10, min_number: 1, max_number:20, help: {description: tr("This parameter defines the maximum number of attempts to solve the Yandex captcha. One attempt equals 1 solved or unsolved captcha picture")} }) %>	
</span>
</div>
<div class="tooltipinternal">
<div class="tr tooltip-paragraph-first-fold">Решить <span style="color: #FF4500;">YandexSmart</span> капчу, используя метод распознавания цифр и букв на изображении.</div>
<div class="tr tooltip-paragraph-fold"><code>To solve this captcha you need to open the captcha window with the button 'I'm not a robot' and run the module to solve the captcha.</code></div>
<div class="tr tooltip-paragraph-last-fold">The module supports 2 types of Yandex captcha: sequentially click on the objects drawn on the image, as well as the second type where you need to enter the text from the image in a special form and confirm the decision.</div>
</div>
<%= _.template($('#back').html())({action:"executeandadd", visible:true}) %>
