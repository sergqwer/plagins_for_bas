_call_function(canny_edge_detector_canny_edge_detector,{ "gaussian_Blur": (<%= cvrzneoa %>),"high_Threshold": (<%= xlfhqvuh %>),"INPUT_IMAGE_BASE64": (<%= xjvyecot %>),"low_Threshold": (<%= zgtbeudu %>) })!
<%= variable %> = _result_function()
