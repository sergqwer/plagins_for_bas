var cvrzneoa = GetInputConstructorValue("cvrzneoa", loader);
                 if(cvrzneoa["original"].length == 0)
                 {
                   Invalid("gaussian_Blur" + " is empty");
                   return;
                 }
var xlfhqvuh = GetInputConstructorValue("xlfhqvuh", loader);
                 if(xlfhqvuh["original"].length == 0)
                 {
                   Invalid("high_Threshold" + " is empty");
                   return;
                 }
var xjvyecot = GetInputConstructorValue("xjvyecot", loader);
                 if(xjvyecot["original"].length == 0)
                 {
                   Invalid("INPUT_IMAGE_BASE64" + " is empty");
                   return;
                 }
var zgtbeudu = GetInputConstructorValue("zgtbeudu", loader);
                 if(zgtbeudu["original"].length == 0)
                 {
                   Invalid("low_Threshold" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#canny_edge_detector_canny_edge_detector_code").html())({"cvrzneoa": cvrzneoa["updated"],"xlfhqvuh": xlfhqvuh["updated"],"xjvyecot": xjvyecot["updated"],"zgtbeudu": zgtbeudu["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
