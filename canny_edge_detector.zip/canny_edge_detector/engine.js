function canny_edge_detector_canny_edge_detector()
   {
   
      
      
      VAR_GAUSSIAN_BLUR = _function_argument("gaussian_Blur")
      

      
      
      VAR_LOW_THRESHOLD = _function_argument("low_Threshold")
      

      
      
      VAR_HIGH_THRESHOLD = _function_argument("high_Threshold")
      

      
      
      VAR_INPUT_IMAGE_BASE64 = _function_argument("INPUT_IMAGE_BASE64")
      

      
      
      /*VAR_HIGH_THRESHOLD VAR_LOW_THRESHOLD VAR_GAUSSIAN_BLUR VAR_INPUT_IMAGE_BASE64 VAR_RESULT_IMAGE_BASE64*/
      _embedded("013njna6dfb", "Node", "12.18.3", "HIGH_THRESHOLD,LOW_THRESHOLD,GAUSSIAN_BLUR,INPUT_IMAGE_BASE64,RESULT_IMAGE_BASE64", 60000 )!
      

      
      
      _function_return(VAR_RESULT_IMAGE_BASE64)
      

   }
   

