function Captcha_Soler_Profit_Profit_Image_Solver()
   {
   
      
      
      VAR_ERROR_FATAL = 0
      

      
      
      VAR_APIKEY = _function_argument("apikey")
      

      
      
      _do(function(){
      _set_action_info({ name: "While" });
      VAR_CYCLE_INDEX = _iterator() - 1
      BREAK_CONDITION = true == false;
      if(!BREAK_CONDITION)_break();
      
         
         
         _set_goto_label("failcaptcha")!
         

         
         
         VAR_ERROR_FATAL = parseInt(VAR_ERROR_FATAL) + parseInt(1)
         

         
         
         /*Browser*/
         _SELECTOR = " \u003eCSS\u003e .out-reload";
         wait_element_visible(_SELECTOR)!
         _call(_random_point, {})!
         _if(_result().length > 0, function(){
         move( {} )!
         get_element_selector(_SELECTOR, false).clarify(X,Y)!
         _call(_clarify, {} )!
         mouse(X,Y)!
         })!
         

         
         
         _call(function()
         {
         _on_fail(function(){
         VAR_LAST_ERROR = _result()
         VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
         VAR_WAS_ERROR = false
         _break(1,true)
         })
         CYCLES.Current().RemoveLabel("function")
         
            
            
            /*Browser*/
            waiter_timeout_next(30000)
            wait_async_load()!
            

         },null)!
         

      })!
      

      _set_goto_label("_internal_1494020708_78586266")!
      
      VAR_CAPTCHALIST = []
      

      
      
      _do(function(){
      _set_action_info({ name: "For" });
      VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(0)
      if(VAR_CYCLE_INDEX > parseInt(5))_break();
      
         
         
         _call(function()
         {
         _on_fail(function(){
         VAR_LAST_ERROR = _result()
         VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
         VAR_WAS_ERROR = false
         _break(1,true)
         })
         CYCLES.Current().RemoveLabel("function")
         
            
            
            /*Browser*/
            _SELECTOR = " \u003eXPATH\u003e //label[@class=\u0022out-capcha-lab\u0022]\u003eAT\u003e" + VAR_CYCLE_INDEX;
            wait_element(_SELECTOR)!
            get_element_selector(_SELECTOR, false).exist()!
            _if(_result() == "1", function(){
            get_element_selector(_SELECTOR, false).render_base64()!
            VAR_SCREENSHOT_BASE64 = _result()
            })!
            

            
            
            _switch_http_client_main()
            new_http_client()
            

            
            
            _switch_http_client_main()
            general_timeout_next(15000)
            http_client_post("https://goodxevilpay.shop/privat.php", ["data", "\u007b\u0022imagebase64\u0022:\u0022" + VAR_SCREENSHOT_BASE64 + "\u0022, \u0022apikey\u0022:\u0022" + VAR_APIKEY + "\u0022, \u0022typeimg\u0022:\u0022profitcentr\u0022\u007d"], {"content-type":"custom/" + ("application/json"), "encoding":("UTF-8"), "method":("POST"),headers:("")})!
            

            
            
            _switch_http_client_main()
            VAR_CAPTCHA = http_client_encoded_content("auto")
            

            
            
            VAR_CAPTCHA = base64_decode(VAR_CAPTCHA)
            

            
            
            VAR_STRING_CONTAINS = _string_contains(VAR_CAPTCHA,"ERROR");
            

            
            
            _set_if_expression("W1tTVFJJTkdfQ09OVEFJTlNdXQ==");
            _if(typeof(VAR_STRING_CONTAINS) !== "undefined" ? (VAR_STRING_CONTAINS) : undefined,function(){
            
               
               
               _long_goto("failcaptcha", 3, ["_internal_1494020708_78586266"])!
               

            })!
            

            
            
            VAR_CAPTCHALIST.push(VAR_CAPTCHA)
            

         },null)!
         

         
         
         _set_if_expression("W1tXQVNfRVJST1JdXQ==");
         _if(typeof(VAR_WAS_ERROR) !== "undefined" ? (VAR_WAS_ERROR) : undefined,function(){
         
            
            
            _set_if_expression("W1tFUlJPUl9GQVRBTF1dIDwgNQ==");
            _if(VAR_ERROR_FATAL < 5,function(){
            
               
               
               _long_goto("failcaptcha", 3, ["_internal_1494020708_78586266"])!
               

            })!
            

         })!
         

      })!
      

      
      
      VAR_CAPTCHALIST_LIST_LENGTH = (VAR_CAPTCHALIST).length
      

      
      
      _set_if_expression("W1tDQVBUQ0hBTElTVF9MSVNUX0xFTkdUSF1dID09IDA=");
      _if(VAR_CAPTCHALIST_LIST_LENGTH == 0,function(){
      
         
         
         _set_if_expression("W1tFUlJPUl9GQVRBTF1dIDwgNQ==");
         _if(VAR_ERROR_FATAL < 5,function(){
         
            
            
            _long_goto("failcaptcha", 2, ["_internal_1494020708_78586266"])!
            

         })!
         

      })!
      

      
      
      _call(function()
      {
      _on_fail(function(){
      VAR_LAST_ERROR = _result()
      VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
      VAR_WAS_ERROR = false
      _break(1,true)
      })
      CYCLES.Current().RemoveLabel("function")
      
         
         
         /*Browser*/
         _SELECTOR = " \u003eCSS\u003e .out-capcha-title";
         wait_element(_SELECTOR)!
         get_element_selector(_SELECTOR, false).text()!
         VAR_CAPTCHA_TEXT = _result()
         

         
         
         VAR_CAPTCHA_TEXT = _clean(VAR_CAPTCHA_TEXT, "\\t\\v", "\\r\\n\\f", true);
         

         
         
         VAR_CAPTCHA_TEXT = (VAR_CAPTCHA_TEXT).split(" ")
         

         
         
         ;(VAR_CAPTCHA_TEXT).splice(0,3)
         

         
         
         VAR_CAPTCHA_TEXT = (VAR_CAPTCHA_TEXT).join(" ")
         

         
         
         VAR_CAPTCHA_TEXT = _clean(VAR_CAPTCHA_TEXT, "\\t\\v" + " ", "\\r\\n\\f", true);
         

         
         
         _cycle_params().if_else = VAR_CAPTCHA_TEXT == "животными";
         _set_if_expression("W1tDQVBUQ0hBX1RFWFRdXSA9PSAi0LbQuNCy0L7RgtC90YvQvNC4Ig==");
         _if(_cycle_params().if_else,function(){
         
            
            
            _do_with_params({"foreach_data":(VAR_CAPTCHALIST)},function(){
            _set_action_info({ name: "Foreach" });
            VAR_CYCLE_INDEX = _iterator() - 1
            if(VAR_CYCLE_INDEX > _cycle_param("foreach_data").length - 1)_break();
            VAR_FOREACH_DATA = _cycle_param("foreach_data")[VAR_CYCLE_INDEX]
            
               
               
               _set_if_expression("W1tGT1JFQUNIX0RBVEFdXSA9PSAiRmFpbCI=");
               _if(VAR_FOREACH_DATA == "Fail",function(){
               
                  
                  
                  _long_goto("failcaptcha", 4, ["_internal_1494020708_78586266"])!
                  

               })!
               

               
               
               _set_if_expression("W1tGT1JFQUNIX0RBVEFdXSA9PSAi0ZHQttC40LrQsNC80Lgi");
               _if(VAR_FOREACH_DATA == "ёжиками",function(){
               
                  
                  
                  VAR_CAPTCHANAMBER = VAR_CYCLE_INDEX+2
                  

                  
                  
                  /*Browser*/
                  _SELECTOR = "\u003eCSS\u003e .out-capcha \u003e :nth-child(" + VAR_CAPTCHANAMBER + ")";waiter_timeout_next(20000)
                  wait_element_visible(_SELECTOR)!
                  _call(_random_point, {})!
                  _if(_result().length > 0, function(){
                  move( {} )!
                  get_element_selector(_SELECTOR, false).clarify(X,Y)!
                  _call(_clarify, {} )!
                  mouse(X,Y)!
                  })!
                  

               })!
               

               
               
               _set_if_expression("W1tGT1JFQUNIX0RBVEFdXSA9PSAi0LbQuNGA0LDRhNCw0LzQuCI=");
               _if(VAR_FOREACH_DATA == "жирафами",function(){
               
                  
                  
                  VAR_CAPTCHANAMBER = VAR_CYCLE_INDEX+2
                  

                  
                  
                  /*Browser*/
                  _SELECTOR = "\u003eCSS\u003e .out-capcha \u003e :nth-child(" + VAR_CAPTCHANAMBER + ")";waiter_timeout_next(20000)
                  wait_element_visible(_SELECTOR)!
                  _call(_random_point, {})!
                  _if(_result().length > 0, function(){
                  move( {} )!
                  get_element_selector(_SELECTOR, false).clarify(X,Y)!
                  _call(_clarify, {} )!
                  mouse(X,Y)!
                  })!
                  

               })!
               

               
               
               _set_if_expression("W1tGT1JFQUNIX0RBVEFdXSA9PSAi0LrQvtGC0Y/RgtCw0LzQuCI=");
               _if(VAR_FOREACH_DATA == "котятами",function(){
               
                  
                  
                  VAR_CAPTCHANAMBER = VAR_CYCLE_INDEX+2
                  

                  
                  
                  /*Browser*/
                  _SELECTOR = "\u003eCSS\u003e .out-capcha \u003e :nth-child(" + VAR_CAPTCHANAMBER + ")";waiter_timeout_next(20000)
                  wait_element_visible(_SELECTOR)!
                  _call(_random_point, {})!
                  _if(_result().length > 0, function(){
                  move( {} )!
                  get_element_selector(_SELECTOR, false).clarify(X,Y)!
                  _call(_clarify, {} )!
                  mouse(X,Y)!
                  })!
                  

               })!
               

               
               
               _set_if_expression("W1tGT1JFQUNIX0RBVEFdXSA9PSAi0LvQvtGI0LDQtNGM0LzQuCI=");
               _if(VAR_FOREACH_DATA == "лошадьми",function(){
               
                  
                  
                  VAR_CAPTCHANAMBER = VAR_CYCLE_INDEX+2
                  

                  
                  
                  /*Browser*/
                  _SELECTOR = "\u003eCSS\u003e .out-capcha \u003e :nth-child(" + VAR_CAPTCHANAMBER + ")";waiter_timeout_next(20000)
                  wait_element_visible(_SELECTOR)!
                  _call(_random_point, {})!
                  _if(_result().length > 0, function(){
                  move( {} )!
                  get_element_selector(_SELECTOR, false).clarify(X,Y)!
                  _call(_clarify, {} )!
                  mouse(X,Y)!
                  })!
                  

               })!
               

               
               
               _set_if_expression("W1tGT1JFQUNIX0RBVEFdXSA9PSAi0L/QsNC90LTQvtC5Ig==");
               _if(VAR_FOREACH_DATA == "пандой",function(){
               
                  
                  
                  VAR_CAPTCHANAMBER = VAR_CYCLE_INDEX+2
                  

                  
                  
                  /*Browser*/
                  _SELECTOR = "\u003eCSS\u003e .out-capcha \u003e :nth-child(" + VAR_CAPTCHANAMBER + ")";waiter_timeout_next(20000)
                  wait_element_visible(_SELECTOR)!
                  _call(_random_point, {})!
                  _if(_result().length > 0, function(){
                  move( {} )!
                  get_element_selector(_SELECTOR, false).clarify(X,Y)!
                  _call(_clarify, {} )!
                  mouse(X,Y)!
                  })!
                  

               })!
               

               
               
               _set_if_expression("W1tGT1JFQUNIX0RBVEFdXSA9PSAi0L/QvtGA0L7RgdGP0YLQsNC80Lgi");
               _if(VAR_FOREACH_DATA == "поросятами",function(){
               
                  
                  
                  VAR_CAPTCHANAMBER = VAR_CYCLE_INDEX+2
                  

                  
                  
                  /*Browser*/
                  _SELECTOR = "\u003eCSS\u003e .out-capcha \u003e :nth-child(" + VAR_CAPTCHANAMBER + ")";waiter_timeout_next(20000)
                  wait_element_visible(_SELECTOR)!
                  _call(_random_point, {})!
                  _if(_result().length > 0, function(){
                  move( {} )!
                  get_element_selector(_SELECTOR, false).clarify(X,Y)!
                  _call(_clarify, {} )!
                  mouse(X,Y)!
                  })!
                  

               })!
               

               
               
               _set_if_expression("W1tGT1JFQUNIX0RBVEFdXSA9PSAi0YHQu9C+0L3QsNC80Lgi");
               _if(VAR_FOREACH_DATA == "слонами",function(){
               
                  
                  
                  VAR_CAPTCHANAMBER = VAR_CYCLE_INDEX+2
                  

                  
                  
                  /*Browser*/
                  _SELECTOR = "\u003eCSS\u003e .out-capcha \u003e :nth-child(" + VAR_CAPTCHANAMBER + ")";waiter_timeout_next(20000)
                  wait_element_visible(_SELECTOR)!
                  _call(_random_point, {})!
                  _if(_result().length > 0, function(){
                  move( {} )!
                  get_element_selector(_SELECTOR, false).clarify(X,Y)!
                  _call(_clarify, {} )!
                  mouse(X,Y)!
                  })!
                  

               })!
               

               
               
               _set_if_expression("W1tGT1JFQUNIX0RBVEFdXSA9PSAi0YHQvtCx0LDQutCw0LzQuCI=");
               _if(VAR_FOREACH_DATA == "собаками",function(){
               
                  
                  
                  VAR_CAPTCHANAMBER = VAR_CYCLE_INDEX+2
                  

                  
                  
                  /*Browser*/
                  _SELECTOR = "\u003eCSS\u003e .out-capcha \u003e :nth-child(" + VAR_CAPTCHANAMBER + ")";waiter_timeout_next(20000)
                  wait_element_visible(_SELECTOR)!
                  _call(_random_point, {})!
                  _if(_result().length > 0, function(){
                  move( {} )!
                  get_element_selector(_SELECTOR, false).clarify(X,Y)!
                  _call(_clarify, {} )!
                  mouse(X,Y)!
                  })!
                  

               })!
               

               
               
               _set_if_expression("W1tGT1JFQUNIX0RBVEFdXSA9PSAi0YLQuNCz0YDQsNC80Lgi");
               _if(VAR_FOREACH_DATA == "тиграми",function(){
               
                  
                  
                  VAR_CAPTCHANAMBER = VAR_CYCLE_INDEX+2
                  

                  
                  
                  /*Browser*/
                  _SELECTOR = "\u003eCSS\u003e .out-capcha \u003e :nth-child(" + VAR_CAPTCHANAMBER + ")";waiter_timeout_next(20000)
                  wait_element_visible(_SELECTOR)!
                  _call(_random_point, {})!
                  _if(_result().length > 0, function(){
                  move( {} )!
                  get_element_selector(_SELECTOR, false).clarify(X,Y)!
                  _call(_clarify, {} )!
                  mouse(X,Y)!
                  })!
                  

               })!
               

            })!
            

         })!
         

         
         
         _if(!_cycle_params().if_else,function(){
         
            
            
            _do_with_params({"foreach_data":(VAR_CAPTCHALIST)},function(){
            _set_action_info({ name: "Foreach" });
            VAR_CYCLE_INDEX = _iterator() - 1
            if(VAR_CYCLE_INDEX > _cycle_param("foreach_data").length - 1)_break();
            VAR_FOREACH_DATA = _cycle_param("foreach_data")[VAR_CYCLE_INDEX]
            
               
               
               _set_if_expression("W1tGT1JFQUNIX0RBVEFdXSA9PSAiRmFpbCI=");
               _if(VAR_FOREACH_DATA == "Fail",function(){
               
                  
                  
                  _long_goto("failcaptcha", 4, ["_internal_1494020708_78586266"])!
                  

               })!
               

               
               
               _set_if_expression("W1tGT1JFQUNIX0RBVEFdXSA9PSBbW0NBUFRDSEFfVEVYVF1d");
               _if(VAR_FOREACH_DATA == VAR_CAPTCHA_TEXT,function(){
               
                  
                  
                  VAR_CAPTCHANAMBER = VAR_CYCLE_INDEX+2
                  

                  
                  
                  /*Browser*/
                  _SELECTOR = "\u003eCSS\u003e .out-capcha \u003e :nth-child(" + VAR_CAPTCHANAMBER + ")";waiter_timeout_next(20000)
                  wait_element_visible(_SELECTOR)!
                  _call(_random_point, {})!
                  _if(_result().length > 0, function(){
                  move( {} )!
                  get_element_selector(_SELECTOR, false).clarify(X,Y)!
                  _call(_clarify, {} )!
                  mouse(X,Y)!
                  })!
                  

               })!
               

            })!
            

         })!
         delete _cycle_params().if_else;
         

      },null)!
      

      
      
      _set_if_expression("W1tXQVNfRVJST1JdXQ==");
      _if(typeof(VAR_WAS_ERROR) !== "undefined" ? (VAR_WAS_ERROR) : undefined,function(){
      
         
         
         _set_if_expression("W1tFUlJPUl9GQVRBTF1dIDwgNQ==");
         _if(VAR_ERROR_FATAL < 5,function(){
         
            
            
            _long_goto("failcaptcha", 2, ["_internal_1494020708_78586266"])!
            

         })!
         

      })!
      

   }
   

