_call_function(Captcha_Soler_Profit_Profit_Image_Solver,{ "apikey": (<%= rmpniqhi %>) })!
