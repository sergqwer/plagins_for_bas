var ocrtamfv = GetInputConstructorValue("ocrtamfv", loader);
                 if(ocrtamfv["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#Captcha_Soler_Profit_Profit_Image_Solver_code").html())({"ocrtamfv": ocrtamfv["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
