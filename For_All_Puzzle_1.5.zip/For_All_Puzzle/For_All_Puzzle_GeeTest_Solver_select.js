var mtsmvtyz = GetInputConstructorValue("mtsmvtyz", loader);
                 if(mtsmvtyz["original"].length == 0)
                 {
                   Invalid("arrow_id" + " is empty");
                   return;
                 }
var pmdjotfl = GetInputConstructorValue("pmdjotfl", loader);
                 if(pmdjotfl["original"].length == 0)
                 {
                   Invalid("avtoupdate" + " is empty");
                   return;
                 }
var okmzbosw = GetInputConstructorValue("okmzbosw", loader);
                 if(okmzbosw["original"].length == 0)
                 {
                   Invalid("button_id" + " is empty");
                   return;
                 }
var ohwfunhw = GetInputConstructorValue("ohwfunhw", loader);
                 if(ohwfunhw["original"].length == 0)
                 {
                   Invalid("coef" + " is empty");
                   return;
                 }
var fawujnob = GetInputConstructorValue("fawujnob", loader);
                 if(fawujnob["original"].length == 0)
                 {
                   Invalid("image id" + " is empty");
                   return;
                 }
var fjyodnwk = GetInputConstructorValue("fjyodnwk", loader);
                 if(fjyodnwk["original"].length == 0)
                 {
                   Invalid("key" + " is empty");
                   return;
                 }
var tuvthtsn = GetInputConstructorValue("tuvthtsn", loader);
                 if(tuvthtsn["original"].length == 0)
                 {
                   Invalid("pixel_koef" + " is empty");
                   return;
                 }
var hbujtjfs = GetInputConstructorValue("hbujtjfs", loader);
                 if(hbujtjfs["original"].length == 0)
                 {
                   Invalid("reload_id" + " is empty");
                   return;
                 }
var fjhffzuk = GetInputConstructorValue("fjhffzuk", loader);
                 if(fjhffzuk["original"].length == 0)
                 {
                   Invalid("speed" + " is empty");
                   return;
                 }
var jgbubvzk = GetInputConstructorValue("jgbubvzk", loader);
                 if(jgbubvzk["original"].length == 0)
                 {
                   Invalid("type_slide" + " is empty");
                   return;
                 }
var kefhbabi = GetInputConstructorValue("kefhbabi", loader);
                 if(kefhbabi["original"].length == 0)
                 {
                   Invalid("type_swipe" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#For_All_Puzzle_GeeTest_Solver_code").html())({"mtsmvtyz": mtsmvtyz["updated"],"pmdjotfl": pmdjotfl["updated"],"okmzbosw": okmzbosw["updated"],"ohwfunhw": ohwfunhw["updated"],"fawujnob": fawujnob["updated"],"fjyodnwk": fjyodnwk["updated"],"tuvthtsn": tuvthtsn["updated"],"hbujtjfs": hbujtjfs["updated"],"fjhffzuk": fjhffzuk["updated"],"jgbubvzk": jgbubvzk["updated"],"kefhbabi": kefhbabi["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
