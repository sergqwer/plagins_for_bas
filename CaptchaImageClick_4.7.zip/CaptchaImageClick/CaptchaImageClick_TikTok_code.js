_call_function(CaptchaImageClick_TikTok,{ "KEY": (<%= iodepnsd %>),"METHOD": (<%= dooglasb %>),"SPEED_MOUSE": (<%= jkcqszxl %>),"TRY_MAX_CAPTCHA_PICTURE": (<%= ldsvthug %>) })!
