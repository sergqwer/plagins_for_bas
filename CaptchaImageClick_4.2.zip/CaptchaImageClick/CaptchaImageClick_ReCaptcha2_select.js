var dkxpoyuh = GetInputConstructorValue("dkxpoyuh", loader);
                 if(dkxpoyuh["original"].length == 0)
                 {
                   Invalid("IS_INVISIBLE_CAPTCHA" + " is empty");
                   return;
                 }
var hqslsalo = GetInputConstructorValue("hqslsalo", loader);
                 if(hqslsalo["original"].length < 0)
                 {
                   Invalid("KEY" + " is empty");
                   return;
                 }
var avadrara = GetInputConstructorValue("avadrara", loader);
                 if(avadrara["original"].length == 0)
                 {
                   Invalid("METHOD" + " is empty");
                   return;
                 }
var xhrcnprk = GetInputConstructorValue("xhrcnprk", loader);
                 if(xhrcnprk["original"].length == 0)
                 {
                   Invalid("NUMBER_CAPTCHA" + " is empty");
                   return;
                 }
var tcbiwjzv = GetInputConstructorValue("tcbiwjzv", loader);
                 if(tcbiwjzv["original"].length == 0)
                 {
                   Invalid("SELECTOR" + " is empty");
                   return;
                 }
var ergukjtr = GetInputConstructorValue("ergukjtr", loader);
                 if(ergukjtr["original"].length == 0)
                 {
                   Invalid("SPEED_MOUSE" + " is empty");
                   return;
                 }
var ejbfqmeq = GetInputConstructorValue("ejbfqmeq", loader);
                 if(ejbfqmeq["original"].length == 0)
                 {
                   Invalid("TRY_NUMBER" + " is empty");
                   return;
                 }
var acpuurdl = GetInputConstructorValue("acpuurdl", loader);
                 if(acpuurdl["original"].length == 0)
                 {
                   Invalid("URL" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#CaptchaImageClick_ReCaptcha2_code").html())({"dkxpoyuh": dkxpoyuh["updated"],"hqslsalo": hqslsalo["updated"],"avadrara": avadrara["updated"],"xhrcnprk": xhrcnprk["updated"],"tcbiwjzv": tcbiwjzv["updated"],"ergukjtr": ergukjtr["updated"],"ejbfqmeq": ejbfqmeq["updated"],"acpuurdl": acpuurdl["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
