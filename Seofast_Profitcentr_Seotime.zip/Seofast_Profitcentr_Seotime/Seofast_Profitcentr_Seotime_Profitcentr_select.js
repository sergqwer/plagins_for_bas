var rmafowlx = GetInputConstructorValue("rmafowlx", loader);
                 if(rmafowlx["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#Seofast_Profitcentr_Seotime_Profitcentr_code").html())({"rmafowlx": rmafowlx["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
