function CaptchaImageClick_FunCaptcha_goodxevilpay()
   {
   
      
      
      VAR_GLOBAL_SELECTOR = _function_argument("SELECTOR")
      

      
      
      VAR_SPEED_MOUSE = _function_argument("SPEED_MOUSE")
      

      
      
      VAR_KEY_MODULE = _function_argument("KEY")
      

      
      
      VAR_METHOD_MODULE = _function_argument("METHOD")
      

      
      
      VAR_TRY_MAX_CAPTCHA_PICTURE = _function_argument("TRY_MAX_CAPTCHA_PICTURE")
      

      
      
      VAR_NUMBER_CAPTCHA_MODULE = _function_argument("NUMBER_CAPTCHA")
      

      
      
      VAR_ERROR_LOAD = "0"
      

      
      
      VAR_CACHE_ERROR = "0"
      

      
      
      VAR_ERROR_SOLVE = "0"
      

      
      
      VAR_ERROR_TASK = "0"
      

      
      
      VAR_ERROR_FIND_MAIN_SELECTOR = "0"
      

      
      
      VAR_FUNCAPTCHA_PREFIX_SECOND_FRAME = ""
      

      
      
      VAR_GREEN_TICK = false
      

      
      
      _call(function()
      {
      _on_fail(function(){
      VAR_LAST_ERROR = _result()
      VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
      VAR_WAS_ERROR = false
      _break(1,true)
      })
      CYCLES.Current().RemoveLabel("function")
      
         
         
         /*Browser*/
         waiter_timeout_next(45000)
         wait_load("*/rtig/image*")!
         

         
         
         sleep(rand(100,500))!
         

         
         
         /*Browser*/
         wait_load("*/fc/gfc*")!
         cache_get_string("*/fc/gfc*")!
         VAR_SAVED_CACHE = _result()
         

         
         
         _cycle_params().if_else = VAR_SAVED_CACHE != '';
         _set_if_expression("W1tTQVZFRF9DQUNIRV1dICE9ICcn");
         _if(_cycle_params().if_else,function(){
         
            
            
            var regexp_result = native("regexp", "first", JSON.stringify({text: VAR_SAVED_CACHE,regexp:"\u005c\u0022[0-9]\u005c.\u005cinstructions-[A-z0-9_-]*"}))
            if(regexp_result.length == 0)
            regexp_result = []
            else
            regexp_result = JSON.parse(regexp_result)
            VAR_ALL_MATCH = regexp_result.pop()
            if(typeof(VAR_ALL_MATCH) == 'undefined' || !VAR_ALL_MATCH)
            VAR_ALL_MATCH = ""
            VAR_SET_TASK = regexp_result[0]
            if(typeof(VAR_SET_TASK) == 'undefined' || !VAR_SET_TASK)
            VAR_SET_TASK = ""
            VAR_SET_TASK1 = regexp_result[1]
            if(typeof(VAR_SET_TASK1) == 'undefined' || !VAR_SET_TASK1)
            VAR_SET_TASK1 = ""
            VAR_SET_TASK2 = regexp_result[2]
            if(typeof(VAR_SET_TASK2) == 'undefined' || !VAR_SET_TASK2)
            VAR_SET_TASK2 = ""
            if(regexp_result.length == 0)
            {
            VAR_SET_TASK = VAR_ALL_MATCH
            }
            

            
            
            VAR_SHORT_TASK_FIRST = native("regexp", "replace", JSON.stringify({text: VAR_SET_TASK,regexp:"\u005c\u0022[0-9]\u005c.\u005cinstructions-",replace:""}))
            

            
            
            VAR_SHORT_TASK = native("regexp", "replace", JSON.stringify({text: VAR_SHORT_TASK_FIRST,regexp:"[_-]icon$",replace:""}))
            
	
            VAR_SET_TASK = VAR_SET_TASK.replace('"',"")
			//VAR_LIST_ELEMENT = base64_decode(VAR_SAVED_CACHE)
			VAR_SET_TASK = VAR_SAVED_CACHE.split(VAR_SET_TASK)[1].split('"')[2].replace(".", "")
            
            //VAR_SET_TASK = native("regexp", "replace", JSON.stringify({text: VAR_SET_TASK,regexp:"\u0022",replace:""}))
            

            
            
            VAR_SAVED_CACHE = JSON.parse(VAR_SAVED_CACHE);
            VAR_CURRENT_TASK_NUMBERS = VAR_SAVED_CACHE.game_data.waves;
            

         })!
         

         
         
         _if(!_cycle_params().if_else,function(){
         
            
            
            VAR_CACHE_ERROR = "1"
            

         })!
         delete _cycle_params().if_else;
         

      },null)!
      

      
      
      _set_if_expression("W1tXQVNfRVJST1JdXQ==");
      _if(typeof(VAR_WAS_ERROR) !== "undefined" ? (VAR_WAS_ERROR) : undefined,function(){
      
         
         
         fail(VAR_LAST_ERROR)
         

      })!
      

      
      
      _call(function()
      {
      _on_fail(function(){
      VAR_LAST_ERROR = _result()
      VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
      VAR_WAS_ERROR = false
      _break(1,true)
      })
      CYCLES.Current().RemoveLabel("function")
      
         
         
         if (VAR_SPEED_MOUSE == "Slow")
         {
         VAR_SPEED = 100;
         VAR_GRAVITY = 6;
         VAR_DEVIATION = 2.5;
         }
         if (VAR_SPEED_MOUSE == "Normal")
         {
         VAR_SPEED = 200;
         VAR_GRAVITY = 12;
         VAR_DEVIATION = 5;
         }
         if (VAR_SPEED_MOUSE == "Fast")
         {
         VAR_SPEED = 300;
         VAR_GRAVITY = 18;
         VAR_DEVIATION = 7.5;
         }
         if (VAR_SPEED_MOUSE == "Very Fast")
         {
         VAR_SPEED = 400;
         VAR_GRAVITY = 24;
         VAR_DEVIATION = 10;
         }
         if (VAR_SPEED_MOUSE == "Extremal")
         {
         VAR_SPEED = 500;
         VAR_GRAVITY = 30;
         VAR_DEVIATION = 12.5;
         }
         

         
         
         page().script2("[[IS_MOBILE]] = navigator.maxTouchPoints;",JSON.stringify(_read_variables(["VAR_IS_MOBILE"])))!
         var _parse_result = JSON.parse(_result())
         _write_variables(JSON.parse(_parse_result.variables))
         if(!_parse_result.is_success)
         fail(_parse_result.error)
         

         
         
         _set_if_expression("W1tJU19NT0JJTEVdXSA9PSAwICYmIHJhbmQgKDEsMTApID4gNQ==");
         _if(VAR_IS_MOBILE == 0 && rand (1,10) > 5,function(){
         
            
            
            _do(function(){
            _set_action_info({ name: "While" });
            VAR_CYCLE_INDEX = _iterator() - 1
            BREAK_CONDITION = VAR_CYCLE_INDEX < 2 && VAR_IS_MOBILE == 0;
            if(!BREAK_CONDITION)_break();
            
               
               
               _get_browser_screen_settings()!
               ;(function(){
               var result = JSON.parse(_result())
               VAR_SCROLL_X = result["ScrollX"]
               VAR_SCROLL_Y = result["ScrollY"]
               VAR_CURSOR_X = result["CursorX"]
               VAR_CURSOR_Y = result["CursorY"]
               VAR_BROWSER_WIDTH = result["Width"]
               VAR_BROWSER_HEIGHT = result["Height"]
               })();
               

               
               
               var scroll_x=parseInt(VAR_CURSOR_Y);
               var scroll_y=parseInt(VAR_SCROLL_Y);
               var browser_h=parseInt(VAR_BROWSER_HEIGHT);
               //-------------------- Привели все в числа, считаем позицию ---------------------
               var absolut_y = VAR_CURSOR_Y + VAR_SCROLL_Y;
               var y_without_scroll = absolut_y - VAR_SCROLL_Y;
               var check_y_top = VAR_BROWSER_HEIGHT/12;
               var check_y_down = VAR_BROWSER_HEIGHT/100*92;
               var move_y_top = VAR_BROWSER_HEIGHT/10;
               var move_y_down = VAR_BROWSER_HEIGHT/100*80;
               // -------------------------- Округляем ----------------------------------
               VAR_CHECK_Y_TOP = check_y_top.toFixed();
               VAR_CHECK_Y_DOWN = check_y_down.toFixed();
               VAR_Y_WITHOUNT_SCROLL = y_without_scroll.toFixed();
               VAR_MOVE_Y_TOP = move_y_top.toFixed();
               VAR_MOVE_Y_DOWN = move_y_down.toFixed();
               // ----------------- Снова приводим к числу ------------------------
               VAR_CHECK_Y_TOP=parseInt(VAR_CHECK_Y_TOP);
               VAR_CHECK_Y_DOWN=parseInt(VAR_CHECK_Y_DOWN);
               VAR_Y_WITHOUNT_SCROLL=parseInt(VAR_Y_WITHOUNT_SCROLL);
               VAR_MOVE_Y_TOP=parseInt(VAR_MOVE_Y_TOP);
               VAR_MOVE_Y_DOWN=parseInt(VAR_MOVE_Y_DOWN);
               

               
               
               /*Browser*/
               move(rand(VAR_BROWSER_WIDTH/5,VAR_BROWSER_WIDTH/1.3),rand(VAR_MOVE_Y_TOP + VAR_SCROLL_Y,VAR_MOVE_Y_DOWN + VAR_SCROLL_Y),  {} )!
               

               
               
               _set_if_expression("cmFuZCAoMSwxMCkgPiA1");
               _if(rand (1,10) > 5,function(){
               
                  
                  
                  _break("function")
                  

               })!
               

            })!
            

         })!
         

         
         
         VAR_FUNCAPTCHA_PREFIX = VAR_GLOBAL_SELECTOR;
         VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME = VAR_FUNCAPTCHA_PREFIX;
         {
         var index = VAR_FUNCAPTCHA_PREFIX.toString().lastIndexOf(">FRAME>")
         if(index >= 0)
         VAR_FUNCAPTCHA_PREFIX = VAR_FUNCAPTCHA_PREFIX.substring(0,index)
         VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME = VAR_FUNCAPTCHA_PREFIX
         index = VAR_FUNCAPTCHA_PREFIX.toString().lastIndexOf(">FRAME>")
         if(index >= 0)
         VAR_FUNCAPTCHA_PREFIX = VAR_FUNCAPTCHA_PREFIX.substring(0,index + ">FRAME>".length)
         else
         VAR_FUNCAPTCHA_PREFIX = ""
         index = VAR_FUNCAPTCHA_PREFIX.toString().lastIndexOf(">FRAME>")
         if(index >= 0)
         VAR_FUNCAPTCHA_PREFIX = VAR_FUNCAPTCHA_PREFIX.substring(0,index + ">FRAME>".length)
         else
         VAR_FUNCAPTCHA_PREFIX = ""
         }
         

         
         
         _set_if_expression("W1tGVU5DQVBUQ0hBX1BSRUZJWF9TRUNPTkRfRlJBTUVdXSA9PSAiIg==");
         _if(VAR_FUNCAPTCHA_PREFIX_SECOND_FRAME == "",function(){
         
            
            
            _do(function(){
            _set_action_info({ name: "For" });
            VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
            if(VAR_CYCLE_INDEX > parseInt(40))_break();
            
               
               
               /*Browser*/
               ;_SELECTOR=VAR_GLOBAL_SELECTOR;
               get_element_selector(_SELECTOR, false).nowait().exist()!
               VAR_IS_EXISTS = _result() == 1
               _if(VAR_IS_EXISTS, function(){
               get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
               VAR_IS_EXISTS = _result().indexOf("true")>=0
               })!
               

               
               
               _cycle_params().if_else = typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined;
               _set_if_expression("W1tJU19FWElTVFNdXQ==");
               _if(_cycle_params().if_else,function(){
               
                  
                  
                  /*Browser*/
                  _SELECTOR = VAR_GLOBAL_SELECTOR;waiter_timeout_next(8000)
                  wait_element_visible(_SELECTOR)!
                  _call(_random_point, {})!
                  _if(_result().length > 0, function(){
                  move( {} )!
                  get_element_selector(_SELECTOR, false).clarify(X,Y)!
                  _call(_clarify, {} )!
                  mouse(X,Y)!
                  })!
                  

                  
                  
                  /*Browser*/
                  wait_load("*rtig/image*")!
                  

                  
                  
                  _break("function")
                  

               })!
               

               
               
               _if(!_cycle_params().if_else,function(){
               
                  
                  
                  sleep(rand(100,500))!
                  

               })!
               delete _cycle_params().if_else;
               

               
               
               _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gcmFuZCAoMjAsMjUp");
               _if(VAR_CYCLE_INDEX > rand (20,25),function(){
               
                  
                  
                  VAR_ERROR_FIND_MAIN_SELECTOR = "1"
                  

               })!
               

            })!
            

         })!
         

      },null)!
      

      
      
      _set_if_expression("W1tDQUNIRV9FUlJPUl1dID09IDE=");
      _if(VAR_CACHE_ERROR == 1,function(){
      
         
         
         fail((_K==="en" ? "Warning! Before load FunCaptcha you need allow cache by mask *rtig/image* and */fc/gfc*" : "Внимание! Перед решением FunCaptcha необходимо разрешить кэш по маске *rtig/image* и */fc/gfc*"));
         

      })!
      

      
      
      _set_if_expression("W1tDVVJSRU5UX1RBU0tfTlVNQkVSU11dID4gW1tUUllfTUFYX0NBUFRDSEFfUElDVFVSRV1d");
      _if(VAR_CURRENT_TASK_NUMBERS > VAR_TRY_MAX_CAPTCHA_PICTURE,function(){
      
         
         
         fail((_K==="en" ? "The capctha could not be resolved. The maximum number of jobs has been exceeded. Check the quality of the browser and proxy." : "Не удалось решить капчу. Превышен лимит на максимальное число заданий. Проверьте качество браузера и прокси."));
         

      })!
      

      
      
      _set_if_expression("W1tFUlJPUl9GSU5EX01BSU5fU0VMRUNUT1JdXSA9PSAx");
      _if(VAR_ERROR_FIND_MAIN_SELECTOR == 1,function(){
      
         
         
         /*Browser*/
         cache_data_clear()!
         

         
         
         fail((_K==="en" ? "Failed to wait for main captcha selector to load" : "Не удалось дождатся загрузки основного селектора капчи"));
         

      })!
      

      
      
      VAR_TRY_CAPTCHA = "0"
      

      
      
      VAR_BAS_CAPMONSTER_IMAGE_ID = "0"
      

      
      
      VAR_CAPTCHA_FAIL = "0"
      

      
      
      VAR_ERROR_KEY = "0"
      

      
      
      VAR_ERROR_BALANCE = "0"
      

      
      
      VAR_ERROR_LANG = "0"
      

      
      
      VAR_GET_ALL_COORDINATES = "0"
      

      
      
      VAR_FIRST_LOAD_CAPTCHA = true
      

      
      
      _do(function(){
      _set_action_info({ name: "For" });
      VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
      if(VAR_CYCLE_INDEX > parseInt(500))_break();
      
         
         
         VAR_CYCLE_INDEX = 0
         

         
         
         _set_if_expression("W1tFUlJPUl9LRVldXSA9PSAx");
         _if(VAR_ERROR_KEY == 1,function(){
         
            
            
            /*Browser*/
            cache_data_clear()!
            

            
            
            fail((_K==="en" ? "API secret key from captcha recognition service is wrong ERROR_WRONG_USER_KEY" : "Секретный ключ API от сервиса распознавания капчи неправильный ERROR_WRONG_USER_KEY"));
            

         })!
         

         
         
         _set_if_expression("W1tFUlJPUl9CQUxBTkNFXV0gPT0gMQ==");
         _if(VAR_ERROR_BALANCE == 1,function(){
         
            
            
            /*Browser*/
            cache_data_clear()!
            

            
            
            fail((_K==="en" ? "The balance on the captcha service has ended - ERROR_ZERO_BALANCE" : "Закончился баланс на сервисе распознавания капчи - ERROR_ZERO_BALANCE"));
            

         })!
         

         
         
         _set_if_expression("W1tFUlJPUl9UQVNLXV0gPiAx");
         _if(VAR_ERROR_TASK > 1,function(){
         
            
            
            /*Browser*/
            cache_data_clear()!
            

            
            
            fail((_K==="en" ? "This Funcaptcha task or picture type is not supported service goodxevilpay.shop: " +VAR_SHORT_TASK : "Не удалось решить капчу: сервис goodxevilpay.shop не смог распознать это изображение: " +VAR_SHORT_TASK));
            

         })!
         

         
         
         _set_if_expression("W1tDQVBUQ0hBX0ZBSUxdXSA9PSAx");
         _if(VAR_CAPTCHA_FAIL == 1,function(){
         
            
            
            /*Browser*/
            cache_data_clear()!
            

            
            
            fail((_K==="en" ? "Failed to complete the request to the captcha recognition server, error - CAPTCHA_FAIL" : "Не удалось выполнить запрос к серверу распознавания капчи, ошибка - CAPTCHA_FAIL"));
            

         })!
         

         
         
         _do(function(){
         _set_action_info({ name: "For" });
         VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
         if(VAR_CYCLE_INDEX > parseInt(120))_break();
         
            
            
            /*Browser*/
            ;_SELECTOR=VAR_FUNCAPTCHA_PREFIX + "\u003eCSS\u003e #verifyButton";
            get_element_selector(_SELECTOR, false).nowait().exist()!
            VAR_IS_EXISTS = _result() == 1
            

            
            
            _set_if_expression("W1tJU19FWElTVFNdXQ==");
            _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
            
               
               
               /*Browser*/
               _SELECTOR = VAR_FUNCAPTCHA_PREFIX + "\u003eCSS\u003e #verifyButton";
               wait_element_visible(_SELECTOR)!
               _call(_random_point, {})!
               _if(_result().length > 0, function(){
               move( {} )!
               get_element_selector(_SELECTOR, false).clarify(X,Y)!
               _call(_clarify, {} )!
               mouse(X,Y)!
               })!
               

               
               
               sleep(rand(500,1000))!
               

               
               
               /*Browser*/
               wait_load("*rtig/image*")!
               

            })!
            

            
            
            /*Browser*/
            ;_SELECTOR=VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e #wrong_children_exclamation";
            get_element_selector(_SELECTOR, false).nowait().exist()!
            VAR_IS_EXISTS = _result() == 1
            _if(VAR_IS_EXISTS, function(){
            get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
            VAR_IS_EXISTS = _result().indexOf("true")>=0
            })!
            

            
            
            _set_if_expression("W1tJU19FWElTVFNdXSA9PSB0cnVl");
            _if(VAR_IS_EXISTS == true,function(){
            
               
               
               VAR_ERROR_SOLVE = "1"
               

               
               
               _break("function")
               

            })!
            

            
            
            /*Browser*/
            ;_SELECTOR=VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e #game_challengeItem";
            get_element_selector(_SELECTOR, false).nowait().exist()!
            VAR_IS_EXISTS = _result() == 1
            _if(VAR_IS_EXISTS, function(){
            get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
            VAR_IS_EXISTS = _result().indexOf("true")>=0
            })!
            

            
            
            _set_if_expression("W1tJU19FWElTVFNdXSA9PSB0cnVl");
            _if(VAR_IS_EXISTS == true,function(){
            
               
               
               _break("function")
               

            })!
            

            
            
            _set_if_expression("W1tJU19FWElTVFNdXSA9PSBmYWxzZSAmJiBbW0ZJUlNUX0xPQURfQ0FQVENIQV1dID09IGZhbHNl");
            _if(VAR_IS_EXISTS == false && VAR_FIRST_LOAD_CAPTCHA == false,function(){
            
               
               
               /*Browser*/
               cache_data_clear()!
               

               
               
               VAR_GREEN_TICK = true
               

               
               
               _break("function")
               

            })!
            

            
            
            _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gNDAgJiYgW1tGSVJTVF9MT0FEX0NBUFRDSEFdXSA9PSB0cnVl");
            _if(VAR_CYCLE_INDEX > 40 && VAR_FIRST_LOAD_CAPTCHA == true,function(){
            
               
               
               /*Browser*/
               cache_data_clear()!
               

               
               
               fail((_K==="en" ? "Failed to load captcha image window, internet connection too slow" : "Не удалось загрузить окно с картинками капчи, слишком медленное интернет соединение"));
               

            })!
            

            
            
            _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gNjAgJiYgW1tGSVJTVF9MT0FEX0NBUFRDSEFdXSA9PSBmYWxzZQ==");
            _if(VAR_CYCLE_INDEX > 60 && VAR_FIRST_LOAD_CAPTCHA == false,function(){
            
               
               
               /*Browser*/
               cache_data_clear()!
               

               
               
               fail((_K==="en" ? "Failed to solve the captcha. The captcha window is closed." : "Решить капчу не удалось. Окно с капчей не было открыто."));
               

            })!
            

            
            
            sleep(100)!
            

         })!
         

         
         
         VAR_CYCLE_INDEX = 0
         

         
         
         _set_if_expression("W1tHUkVFTl9USUNLXV0gPT0gdHJ1ZQ==");
         _if(VAR_GREEN_TICK == true,function(){
         
            
            
            /*Browser*/
            cache_data_clear()!
            

            
            
            _function_return("")
            

         })!
         

         
         
         _set_if_expression("W1tFUlJPUl9TT0xWRV1dID09IDE=");
         _if(VAR_ERROR_SOLVE == 1,function(){
         
            
            
            /*Browser*/
            cache_data_clear()!
            

            
            
            fail((_K==="en" ? "Сapcha solved incorrectly, error - ERROR_CAPTCHA_SOLVE" : "Капча решена неверно, ошибка  - ERROR_CAPTCHA_SOLVE"));
            

         })!
         

         
         
         VAR_TRY_CAPTCHA = parseInt(VAR_TRY_CAPTCHA) + parseInt(1)
         

         
         
         _set_if_expression("W1tUUllfQ0FQVENIQV1dID4gMzA=");
         _if(VAR_TRY_CAPTCHA > 30,function(){
         
            
            
            fail((_K==="en" ? "Failed to solve the captcha. FunCaptcha attempts limit exceeded" : "Решить капчу не удалось. Превышен лимит попыток решить FunCaptha"));
            

         })!
         

         
         
         _call(function()
         {
         _on_fail(function(){
         VAR_LAST_ERROR = _result()
         VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
         VAR_WAS_ERROR = false
         _break(1,true)
         })
         CYCLES.Current().RemoveLabel("function")
         
            
            
            _set_if_expression("W1tJU19NT0JJTEVdXSA9PSAwICYmIHJhbmQgKDEsMTApID4gNQ==");
            _if(VAR_IS_MOBILE == 0 && rand (1,10) > 5,function(){
            
               
               
               _get_browser_screen_settings()!
               ;(function(){
               var result = JSON.parse(_result())
               VAR_SCROLL_X = result["ScrollX"]
               VAR_SCROLL_Y = result["ScrollY"]
               VAR_CURSOR_X = result["CursorX"]
               VAR_CURSOR_Y = result["CursorY"]
               VAR_BROWSER_WIDTH = result["Width"]
               VAR_BROWSER_HEIGHT = result["Height"]
               })();
               

               
               
               /*Browser*/
               ;_SELECTOR=VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e #game_challengeItem";
               get_element_selector(_SELECTOR, false).nowait().exist()!
               VAR_IS_EXISTS = _result() == 1
               

               
               
               _set_if_expression("IVtbSVNfRVhJU1RTXV0=");
               _if(!VAR_IS_EXISTS,function(){
               
                  
                  
                  _next("function")
                  

               })!
               

               
               
               /*Browser*/
               _SELECTOR = VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e #game_challengeItem";
               wait_element(_SELECTOR)!
               get_element_selector(_SELECTOR, false).script("(function(){var rect = self.getBoundingClientRect();return (rect.left + positionx).toString() + '|' + (rect.top + positiony).toString() + '|' + (rect.right - rect.left).toString() + '|' + (rect.bottom - rect.top).toString()})();")!
               if(_result().length > 0)
               {
               var split = _result().split("|")
               VAR_X = parseInt(split[0])
               VAR_Y = parseInt(split[1])
               VAR_CAPTCHA_WIDTH = parseInt(split[2])
               VAR_CAPTCHA_HEIGHT = parseInt(split[3])
               }
               

               
               
               /*Browser*/
               move(rand(VAR_X/100*115,(VAR_X+VAR_CAPTCHA_WIDTH)/100*93).toFixed(),rand(VAR_Y + VAR_SCROLL_Y/100*120,VAR_Y + VAR_SCROLL_Y + VAR_CAPTCHA_HEIGHT/100*90).toFixed(),  {} )!
               

            })!
            

         },null)!
         

         
         
         _call(function()
         {
         _on_fail(function(){
         VAR_LAST_ERROR = _result()
         VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
         VAR_WAS_ERROR = false
         _break(1,true)
         })
         CYCLES.Current().RemoveLabel("function")
         
            
            
            _get_browser_screen_settings()!
            ;(function(){
            var result = JSON.parse(_result())
            VAR_SCROLL_X = result["ScrollX"]
            VAR_SCROLL_Y = result["ScrollY"]
            VAR_CURSOR_X = result["CursorX"]
            VAR_CURSOR_Y = result["CursorY"]
            VAR_BROWSER_WIDTH = result["Width"]
            VAR_BROWSER_HEIGHT = result["Height"]
            })();
            

            
            
            _set_if_expression("W1tHRVRfQUxMX0NPT1JESU5BVEVTXV0gPT0gMCB8fCBbW0lTX0NIQU5HRURfU0NST0xMX1ldXSAhPSBbW1NDUk9MTF9ZXV0=");
            _if(VAR_GET_ALL_COORDINATES == 0 || VAR_IS_CHANGED_SCROLL_Y != VAR_SCROLL_Y,function(){
            
               
               
               VAR_IS_CHANGED_SCROLL_Y = VAR_SCROLL_Y
               

               
               
               VAR_ELEMENT_SELECTOR = VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e #image1 \u003e a"
               

               
               
               _SELECTOR = VAR_ELEMENT_SELECTOR;
               get_element_selector(_SELECTOR, false).script("(function(){var rect = self.getBoundingClientRect();return (rect.left + positionx).toString() + '|' + (rect.top + positiony).toString() + '|' + (rect.right - rect.left).toString() + '|' + (rect.bottom - rect.top).toString()})();")!
               var split = _result().split("|");
               var x = parseInt(split[0]), y = parseInt(split[1]), w = parseInt(split[2]), h = parseInt(split[3]);
               /// Первый квадрат
               VAR_SQUARE_BUTTON_X = parseInt(x)
               VAR_SQUARE_BUTTON_Y = parseInt(y) + VAR_SCROLL_Y;
               VAR_SQUARE_WIDTH = parseInt(w)
               VAR_SQUARE_HEIGHT = parseInt(h)
               

               
               
               VAR_GET_ALL_COORDINATES = "1"
               

            })!
            

         },null)!
         

         
         
         _set_if_expression("W1tXQVNfRVJST1JdXQ==");
         _if(typeof(VAR_WAS_ERROR) !== "undefined" ? (VAR_WAS_ERROR) : undefined,function(){
         
            
            
            /*Browser*/
            cache_data_clear()!
            

            
            
            fail(VAR_LAST_ERROR)
            

         })!
         

         
         
         _call(function()
         {
         _on_fail(function(){
         VAR_LAST_ERROR = _result()
         VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
         VAR_WAS_ERROR = false
         _break(1,true)
         })
         CYCLES.Current().RemoveLabel("function")
         
            
            
            /*Browser*/
            ;_SELECTOR=VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e #game_challengeItem";
            get_element_selector(_SELECTOR, false).nowait().exist()!
            VAR_IS_EXISTS = _result() == 1
            _if(VAR_IS_EXISTS, function(){
            get_element_selector(_SELECTOR, false).nowait().script("document.readyState!='loading' && Math.round(self.getBoundingClientRect().height) > 0 && Math.round(self.getBoundingClientRect().width) > 0&& window.getComputedStyle(self)['display']!='none'&&window.getComputedStyle(self)['visibility'] != 'hidden'")!
            VAR_IS_EXISTS = _result().indexOf("true")>=0
            })!
            

            
            
            _set_if_expression("W1tJU19FWElTVFNdXSA9PSBmYWxzZQ==");
            _if(VAR_IS_EXISTS == false,function(){
            
               
               
               _next("function")
               

            })!
            

            
            
            /*Browser*/
            _SELECTOR = VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e #game_challengeItem_image";waiter_timeout_next(20000)
            wait_element(_SELECTOR)!
            

            
            
            sleep(200)!
            

            
            
            /*Browser*/
            _SELECTOR = VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e #game_challengeItem_image";
            wait_element(_SELECTOR)!
            get_element_selector(_SELECTOR, false).attr("src")!
            VAR_SAVED_ATTRIBUTE = _result()
            

            
            
            _set_if_expression("W1tTQVZFRF9BVFRSSUJVVEVdXS5pbmRleE9mKCJkYXRhOmltYWdlL2dpZjtiYXNlNjQiKSA+PSAw");
            _if(VAR_SAVED_ATTRIBUTE.indexOf("data:image/gif;base64") >= 0,function(){
            
               
               
               var replace_string_funcap = "data:image/gif;base64,"
               VAR_IMAGE_BASE_64 = VAR_SAVED_ATTRIBUTE.replace(replace_string_funcap, "")
               

               
               
               VAR_LOADED_IMAGE_ID = native("imageprocessing", "load", VAR_IMAGE_BASE_64)
               

               
               
               var split = native("imageprocessing", "convert", (VAR_LOADED_IMAGE_ID) + "," + ("jpeg"))
               

               
               
               native("imageprocessing", "delete", VAR_LOADED_IMAGE_ID)
               

            })!
            

            
            
            _set_if_expression("W1tTQVZFRF9BVFRSSUJVVEVdXS5pbmRleE9mKCJkYXRhOmltYWdlL2pwZWc7YmFzZTY0IikgPj0gMA==");
            _if(VAR_SAVED_ATTRIBUTE.indexOf("data:image/jpeg;base64") >= 0,function(){
            
               
               
               var replace_string_funcap = "data:image/jpeg;base64,"
               VAR_IMAGE_BASE_64 = VAR_SAVED_ATTRIBUTE.replace(replace_string_funcap, "")
               

            })!
            

            
            
            VAR_THREAD_INDEX = thread_number()
            

            
            
            _set_if_expression("W1tUSFJFQURfSU5ERVhdXSA+IDk5OQ==");
            _if(VAR_THREAD_INDEX > 999,function(){
            
               
               
               native("filesystem", "writefile", JSON.stringify({path: "C:\u005cImages\u005c" + VAR_SET_TASK + "_" + VAR_THREAD_INDEX + ".jpeg",value: (VAR_IMAGE_BASE_64).toString(),base64:true,append:false}))
               

            })!
            

         },null)!
         

         
         
         _set_if_expression("W1tXQVNfRVJST1JdXQ==");
         _if(typeof(VAR_WAS_ERROR) !== "undefined" ? (VAR_WAS_ERROR) : undefined,function(){
         
            
            
            /*Browser*/
            cache_data_clear()!
            

            
            
            fail(VAR_LAST_ERROR)
            

         })!
         

         
         
         VAR_FIRST_LOAD_CAPTCHA = false
         

         
         
         _call(function()
         {
         _on_fail(function(){
         VAR_LAST_ERROR = _result()
         VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
         VAR_WAS_ERROR = false
         _break(1,true)
         })
         CYCLES.Current().RemoveLabel("function")
         
            
            
            _do(function(){
            _set_action_info({ name: "For" });
            VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(1)
            if(VAR_CYCLE_INDEX > parseInt(3))_break();
            
               
               
               ///Чистим
               solver_properties_clear("capmonster")
               /// Формирумем основной запрос
               solver_property("capmonster","serverurl","http://goodxevilpay.shop/")
               //solver_property("capmonster","coordinatescaptcha","1")
               solver_property("capmonster","key",VAR_KEY_MODULE)
               solver_property("capmonster","imginstructions",VAR_SET_TASK)
               //solver_property("capmonster","click","funcap")
               solver_property("capmonster","method","post")
               //// Отправляем
               solve_base64_no_fail("capmonster", VAR_IMAGE_BASE_64)!
               VAR_SAVED_CONTENT = _result();
               

               
               
               _set_if_expression("W1tTQVZFRF9DT05URU5UXV0uaW5kZXhPZigiRVJST1JfQ0FQVENIQV9VTlNPTFZBQkxFIikgPj0gMA==");
               _if(VAR_SAVED_CONTENT.indexOf("ERROR_CAPTCHA_UNSOLVABLE") >= 0,function(){
               
                  
                  
                  VAR_ERROR_TASK = parseInt(VAR_ERROR_TASK) + parseInt(1)
                  

                  
                  
                  sleep(rand(2000,4000))!
                  

                  
                  
                  _break("function")
                  

               })!
               

               
               
               _set_if_expression("W1tTQVZFRF9DT05URU5UXV0uaW5kZXhPZigiRVJST1JfV1JPTkdfVVNFUl9LRVkiKSA+PSAw");
               _if(VAR_SAVED_CONTENT.indexOf("ERROR_WRONG_USER_KEY") >= 0,function(){
               
                  
                  
                  VAR_ERROR_KEY = "1"
                  

                  
                  
                  _break("function")
                  

               })!
               

               
               
               _set_if_expression("W1tTQVZFRF9DT05URU5UXV0uaW5kZXhPZigiRVJST1JfWkVST19CQUxBTkNFIikgPj0gMA==");
               _if(VAR_SAVED_CONTENT.indexOf("ERROR_ZERO_BALANCE") >= 0,function(){
               
                  
                  
                  VAR_ERROR_BALANCE = "1"
                  

                  
                  
                  _break("function")
                  

               })!
               

               
               
               _set_if_expression("W1tTQVZFRF9DT05URU5UXV0uaW5kZXhPZigiQ0FQVENIQV9GQUlMIikgPj0gMA==");
               _if(VAR_SAVED_CONTENT.indexOf("CAPTCHA_FAIL") >= 0,function(){
               
                  
                  
                  VAR_CAPTCHA_FAIL = "1"
                  

                  
                  
                  _break("function")
                  

               })!
               

               
               
               _cycle_params().if_else = VAR_SAVED_CONTENT.match(/[0-9]/);
               _set_if_expression("W1tTQVZFRF9DT05URU5UXV0ubWF0Y2goL1swLTldLyk=");
               _if(_cycle_params().if_else,function(){
               
                  
                  VAR_SAVED_LIST = [
					"",
					"coordinates:x=50,y=50",
					"coordinates:x=150,y=50",
					"coordinates:x=250,y=50",
					"coordinates:x=50,y=150",
					"coordinates:x=150,y=150",
					"coordinates:x=250,y=150"
				  ];
				  VAR_INDEX = parseInt(VAR_SAVED_CONTENT);
				  VAR_LISTS_COORDINATES = VAR_SAVED_LIST[VAR_INDEX];
				  //VAR_LISTS_COORDINATES = VAR_SAVED_CONTENT
                  VAR_LISTS_COORDINATES = VAR_LISTS_COORDINATES.split("coordinates:")[1];
                  VAR_LISTS_COORDINATES = VAR_LISTS_COORDINATES.split(";");
                  

                  
                  
                  ;(function (a) {var j, x, i;for (i = a.length; i; i--) {j = Math.floor(Math.random() * i);x = a[i - 1]; a[i - 1] = a[j];a[j] = x;}})(VAR_LISTS_COORDINATES)
                  

                  
                  
                  _do_with_params({"foreach_data":(VAR_LISTS_COORDINATES)},function(){
                  _set_action_info({ name: "Foreach" });
                  VAR_CYCLE_INDEX = _iterator() - 1
                  if(VAR_CYCLE_INDEX > _cycle_param("foreach_data").length - 1)_break();
                  VAR_FOREACH_DATA = _cycle_param("foreach_data")[VAR_CYCLE_INDEX]
                  
                     
                     
                     var csv_parse_result = csv_parse(VAR_FOREACH_DATA)
                     VAR_ANSWER_X = csv_parse_result[0]
                     if(typeof(VAR_ANSWER_X) == 'undefined' || !VAR_ANSWER_X)
                     {
                     VAR_ANSWER_X = ""
                     }
                     VAR_ANSWER_Y = csv_parse_result[1]
                     if(typeof(VAR_ANSWER_Y) == 'undefined' || !VAR_ANSWER_Y)
                     {
                     VAR_ANSWER_Y = ""
                     }
                     

                     
                     
                     VAR_ANSWER_X = VAR_ANSWER_X.replace(/[^0-9]/g, '');
                     VAR_ANSWER_Y = VAR_ANSWER_Y.replace(/[^0-9]/g, '');
                     VAR_ANSWER_X = parseInt(VAR_ANSWER_X)
                     VAR_ANSWER_Y = parseInt(VAR_ANSWER_Y)
                     
                     
                     /*Browser*/
                     move(VAR_SQUARE_BUTTON_X + VAR_ANSWER_X + rand (-14,+14),VAR_SQUARE_BUTTON_Y + VAR_ANSWER_Y + rand (-14,+14),  {"speed": VAR_SPEED,"gravity": VAR_GRAVITY,"deviation": VAR_DEVIATION} )!
                     mouse(VAR_SQUARE_BUTTON_X + VAR_ANSWER_X + rand (-14,+14),VAR_SQUARE_BUTTON_Y + VAR_ANSWER_Y + rand (-14,+14))!
                     

                  })!
                  

                  
                  
                  VAR_ERROR_TASK = 0
                  

                  
                  
                  VAR_CURRENT_TASK_NUMBERS = parseInt(VAR_CURRENT_TASK_NUMBERS) + parseInt(-1)
                  

                  
                  
                  sleep(200)!
                  

                  
                  
                  _set_if_expression("W1tDVVJSRU5UX1RBU0tfTlVNQkVSU11dICE9MA==");
                  _if(VAR_CURRENT_TASK_NUMBERS !=0,function(){
                  
                     
                     
                     /*Browser*/
                     _SELECTOR = VAR_FUNCAPTCHA_PREFIX_FIRST_FRAME + "\u003eFRAME\u003e \u003eCSS\u003e #game_challengeItem_image";waiter_timeout_next(20000)
                     wait_element(_SELECTOR)!
                     

                  })!
                  

                  
                  
                  _set_if_expression("W1tDVVJSRU5UX1RBU0tfTlVNQkVSU11dID09IDA=");
                  _if(VAR_CURRENT_TASK_NUMBERS == 0,function(){
                  
                     
                     
                     sleep(500)!
                     

                  })!
                  

                  
                  
                  _break("function")
                  

               })!
               

               
               
               _if(!_cycle_params().if_else,function(){
               
                  
                  
                  sleep(1000)!
                  

                  
                  
                  _next("function")
                  

               })!
               delete _cycle_params().if_else;
               

            })!
            

            
            
            _next("function")
            

         },null)!
         

         
         
         _set_if_expression("W1tXQVNfRVJST1JdXQ==");
         _if(typeof(VAR_WAS_ERROR) !== "undefined" ? (VAR_WAS_ERROR) : undefined,function(){
         
            
            
            sleep(1000)!
            

            
            
            _next("function")
            

         })!
         

      })!
      

   }
   


