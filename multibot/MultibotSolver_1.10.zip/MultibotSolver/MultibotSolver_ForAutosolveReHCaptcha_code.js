_call_function(MultibotSolver_ForAutosolveReHCaptcha,{ "AutoSettings": (<%= rmetfmno %>) })!
