_call_function(MultibotSolver_ReCaptchav2TakeToken,{ "APIKEY": (<%= smqbdbmr %>),"site_url": (<%= msiepzrl %>),"sitekey": (<%= xtedwcwo %>) })!
<%= variable %> = _result_function()
