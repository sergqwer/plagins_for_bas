_call_function(MultibotSolver_GetBalance,{ "APIKEY": (<%= gcnvkmqv %>) })!
<%= variable %> = _result_function()
