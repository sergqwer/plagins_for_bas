_call_function(MultibotSolver_HcaptchaTakeToken,{ "APIKEY": (<%= tvfzokbs %>),"site_url": (<%= brxaiytg %>),"sitekey": (<%= nrzpnsju %>) })!
<%= variable %> = _result_function()
