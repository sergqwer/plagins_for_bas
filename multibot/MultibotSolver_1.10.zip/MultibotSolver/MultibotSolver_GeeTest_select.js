var bmejtlcs = GetInputConstructorValue("bmejtlcs", loader);
                 if(bmejtlcs["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var daqwaqpp = GetInputConstructorValue("daqwaqpp", loader);
                 if(daqwaqpp["original"].length == 0)
                 {
                   Invalid("pixel_koef" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#MultibotSolver_GeeTest_code").html())({"bmejtlcs": bmejtlcs["updated"],"daqwaqpp": daqwaqpp["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
