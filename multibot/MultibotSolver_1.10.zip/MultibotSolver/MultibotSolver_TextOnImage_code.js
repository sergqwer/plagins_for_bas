_call_function(MultibotSolver_TextOnImage,{ "APIKEY": (<%= kgizorrf %>),"IMAGE_IN_BASE64": (<%= xnhjfgym %>) })!
<%= variable %> = _result_function()
