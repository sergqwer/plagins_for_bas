_call_function(MultibotSolver_AntiBot,{ "apikey": (<%= ryawekax %>),"mouse": (<%= ujhxmdof %>) })!
