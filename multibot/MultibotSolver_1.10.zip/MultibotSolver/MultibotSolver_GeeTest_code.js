_call_function(MultibotSolver_GeeTest,{ "APIKEY": (<%= bmejtlcs %>),"pixel_koef": (<%= daqwaqpp %>) })!
