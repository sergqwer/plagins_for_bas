var devtgnil = GetInputConstructorValue("devtgnil", loader);
                 if(devtgnil["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var fmqdlxuz = GetInputConstructorValue("fmqdlxuz", loader);
                 if(fmqdlxuz["original"].length == 0)
                 {
                   Invalid("mouse" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#MultibotSolver_AntiBot_code").html())({"devtgnil": devtgnil["updated"],"fmqdlxuz": fmqdlxuz["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
