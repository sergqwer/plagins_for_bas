_call_function(MultibotSolver_GeeTest,{ "APIKEY": (<%= jlgqnxma %>),"pixel_koef": (<%= epzeiget %>) })!
