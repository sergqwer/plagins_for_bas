_call_function(MultibotSolver_AntiBot,{ "apikey": (<%= devtgnil %>),"mouse": (<%= fmqdlxuz %>) })!
