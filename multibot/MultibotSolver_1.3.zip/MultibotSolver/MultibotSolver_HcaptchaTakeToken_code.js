_call_function(MultibotSolver_HcaptchaTakeToken,{ "APIKEY": (<%= rdrzhjmz %>),"site_url": (<%= isjhnlqa %>),"sitekey": (<%= ynkruvgw %>) })!
<%= variable %> = _result_function()
