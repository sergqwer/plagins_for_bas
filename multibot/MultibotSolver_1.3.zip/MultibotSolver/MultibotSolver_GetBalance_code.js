_call_function(MultibotSolver_GetBalance,{ "APIKEY": (<%= tdxfnhbf %>) })!
<%= variable %> = _result_function()
