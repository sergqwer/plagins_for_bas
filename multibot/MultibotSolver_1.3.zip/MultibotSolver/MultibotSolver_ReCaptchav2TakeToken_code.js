_call_function(MultibotSolver_ReCaptchav2TakeToken,{ "APIKEY": (<%= mxyxomnx %>),"site_url": (<%= livcpykv %>),"sitekey": (<%= efiypdso %>) })!
<%= variable %> = _result_function()
