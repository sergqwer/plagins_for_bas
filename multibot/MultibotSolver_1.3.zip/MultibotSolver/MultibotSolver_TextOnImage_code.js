_call_function(MultibotSolver_TextOnImage,{ "APIKEY": (<%= vzmfsbdw %>),"IMAGE_IN_BASE64": (<%= jcoppwxq %>) })!
<%= variable %> = _result_function()
