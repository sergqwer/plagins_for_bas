_call_function(MultibotSolver_ReCaptchaAutoSolver,{ "apikey": (<%= yrndvcxx %>) })!
