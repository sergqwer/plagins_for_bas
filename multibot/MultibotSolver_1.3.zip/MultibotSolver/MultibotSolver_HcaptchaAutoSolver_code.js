_call_function(MultibotSolver_HcaptchaAutoSolver,{ "apikey": (<%= ewelmkgx %>) })!
