var vzmfsbdw = GetInputConstructorValue("vzmfsbdw", loader);
                 if(vzmfsbdw["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var jcoppwxq = GetInputConstructorValue("jcoppwxq", loader);
                 if(jcoppwxq["original"].length == 0)
                 {
                   Invalid("IMAGE_IN_BASE64" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#MultibotSolver_TextOnImage_code").html())({"vzmfsbdw": vzmfsbdw["updated"],"jcoppwxq": jcoppwxq["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
