_call_function(MultibotSolver_AntiBot,{ "apikey": (<%= aowjqjhh %>),"mouse": (<%= lueaneef %>) })!
