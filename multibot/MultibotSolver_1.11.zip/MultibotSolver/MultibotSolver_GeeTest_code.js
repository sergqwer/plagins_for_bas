_call_function(MultibotSolver_GeeTest,{ "APIKEY": (<%= ltdygyfo %>),"pixel_koef": (<%= gtcxapio %>) })!
