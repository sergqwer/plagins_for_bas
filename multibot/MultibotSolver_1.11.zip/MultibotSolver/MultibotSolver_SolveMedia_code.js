_call_function(MultibotSolver_SolveMedia,{ "APIKEY": (<%= kvzmkdzb %>) })!
