_call_function(MultibotSolver_ReCaptchav2TakeToken,{ "APIKEY": (<%= uuhoxrlh %>),"site_url": (<%= rlwciejz %>),"sitekey": (<%= ijtbccib %>) })!
<%= variable %> = _result_function()
