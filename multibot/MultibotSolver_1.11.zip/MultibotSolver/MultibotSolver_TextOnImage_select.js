var rgmzgskv = GetInputConstructorValue("rgmzgskv", loader);
                 if(rgmzgskv["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var cftphvle = GetInputConstructorValue("cftphvle", loader);
                 if(cftphvle["original"].length == 0)
                 {
                   Invalid("IMAGE_IN_BASE64" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#MultibotSolver_TextOnImage_code").html())({"rgmzgskv": rgmzgskv["updated"],"cftphvle": cftphvle["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
