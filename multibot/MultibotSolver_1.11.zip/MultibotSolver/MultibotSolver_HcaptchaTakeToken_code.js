_call_function(MultibotSolver_HcaptchaTakeToken,{ "APIKEY": (<%= oksdfvig %>),"site_url": (<%= jftfulls %>),"sitekey": (<%= djfudyqa %>) })!
<%= variable %> = _result_function()
