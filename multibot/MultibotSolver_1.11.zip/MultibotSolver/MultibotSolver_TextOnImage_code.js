_call_function(MultibotSolver_TextOnImage,{ "APIKEY": (<%= rgmzgskv %>),"IMAGE_IN_BASE64": (<%= cftphvle %>) })!
<%= variable %> = _result_function()
