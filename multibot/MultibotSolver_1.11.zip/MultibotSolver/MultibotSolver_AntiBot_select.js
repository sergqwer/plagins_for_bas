var aowjqjhh = GetInputConstructorValue("aowjqjhh", loader);
                 if(aowjqjhh["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var lueaneef = GetInputConstructorValue("lueaneef", loader);
                 if(lueaneef["original"].length == 0)
                 {
                   Invalid("mouse" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#MultibotSolver_AntiBot_code").html())({"aowjqjhh": aowjqjhh["updated"],"lueaneef": lueaneef["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
