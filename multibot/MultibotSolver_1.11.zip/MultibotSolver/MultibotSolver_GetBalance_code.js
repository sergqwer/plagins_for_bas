_call_function(MultibotSolver_GetBalance,{ "APIKEY": (<%= mzjrjekn %>) })!
<%= variable %> = _result_function()
