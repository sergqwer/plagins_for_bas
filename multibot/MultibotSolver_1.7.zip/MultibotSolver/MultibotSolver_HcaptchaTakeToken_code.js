_call_function(MultibotSolver_HcaptchaTakeToken,{ "APIKEY": (<%= vbkroubm %>),"site_url": (<%= towpfmvy %>),"sitekey": (<%= huejuiea %>) })!
<%= variable %> = _result_function()
