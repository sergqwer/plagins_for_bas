_call_function(MultibotSolver_HcaptchaTakeToken,{ "APIKEY": (<%= orrvaduc %>),"site_url": (<%= tvpzliza %>),"sitekey": (<%= vxvqxqto %>) })!
<%= variable %> = _result_function()
