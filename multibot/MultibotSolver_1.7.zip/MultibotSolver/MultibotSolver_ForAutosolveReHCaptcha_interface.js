<div class="container-fluid">
<%= _.template($('#input_constructor').html())({id:"wsyfobos", description:"AutoSettings", default_selector: "string", disable_expression:true, disable_int:true, value_string: "true", help: {description: "true - автоматически приминяет настройки браузера\nfalse - используйте, если вам надо самим изменить настройки браузера"} }) %>
</div>
<div class="tooltipinternal">
<div class="tr tooltip-paragraph-first-fold">Надо для автоматического решения hcaptcha/recaptcha</div>
<div class="tr tooltip-paragraph-fold">Запускать надо до загрузки первой страницы, в самом начале скрипта, после приминения отпечатка, прокси, и профиля, если вы их используете</div>
<div class="tr tooltip-paragraph-last-fold">Эта функция установит расширение, которое будет подгружать js нужный для автоматического определения sitekey и callback</div>
</div>
<%= _.template($('#back').html())({action:"executeandadd", visible:true}) %>
