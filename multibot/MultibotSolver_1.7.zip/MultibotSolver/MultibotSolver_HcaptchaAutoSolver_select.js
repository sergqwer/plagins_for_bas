var fsorjift = GetInputConstructorValue("fsorjift", loader);
                 if(fsorjift["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#MultibotSolver_HcaptchaAutoSolver_code").html())({"fsorjift": fsorjift["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
