var auxqspyo = GetInputConstructorValue("auxqspyo", loader);
                 if(auxqspyo["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var omeotmfe = GetInputConstructorValue("omeotmfe", loader);
                 if(omeotmfe["original"].length == 0)
                 {
                   Invalid("pixel_koef" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#MultibotSolver_GeeTest_code").html())({"auxqspyo": auxqspyo["updated"],"omeotmfe": omeotmfe["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
