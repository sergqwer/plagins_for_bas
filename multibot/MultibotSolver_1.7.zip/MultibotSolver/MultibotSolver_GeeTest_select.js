var fmwklezv = GetInputConstructorValue("fmwklezv", loader);
                 if(fmwklezv["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var cxbbgmwl = GetInputConstructorValue("cxbbgmwl", loader);
                 if(cxbbgmwl["original"].length == 0)
                 {
                   Invalid("pixel_koef" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#MultibotSolver_GeeTest_code").html())({"fmwklezv": fmwklezv["updated"],"cxbbgmwl": cxbbgmwl["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
