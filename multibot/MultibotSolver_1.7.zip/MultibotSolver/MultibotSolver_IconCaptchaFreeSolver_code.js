_call_function(MultibotSolver_IconCaptchaFreeSolver,{  })!
