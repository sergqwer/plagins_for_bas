var cprapfpx = GetInputConstructorValue("cprapfpx", loader);
                 if(cprapfpx["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var ybbjmmvm = GetInputConstructorValue("ybbjmmvm", loader);
                 if(ybbjmmvm["original"].length == 0)
                 {
                   Invalid("site_url" + " is empty");
                   return;
                 }
var ryxvyeff = GetInputConstructorValue("ryxvyeff", loader);
                 if(ryxvyeff["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#MultibotSolver_ReCaptchav2TakeToken_code").html())({"cprapfpx": cprapfpx["updated"],"ybbjmmvm": ybbjmmvm["updated"],"ryxvyeff": ryxvyeff["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
