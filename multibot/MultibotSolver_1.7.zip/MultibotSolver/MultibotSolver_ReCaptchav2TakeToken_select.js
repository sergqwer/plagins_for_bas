var bteynfts = GetInputConstructorValue("bteynfts", loader);
                 if(bteynfts["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var nnedharg = GetInputConstructorValue("nnedharg", loader);
                 if(nnedharg["original"].length == 0)
                 {
                   Invalid("site_url" + " is empty");
                   return;
                 }
var jttqhyrj = GetInputConstructorValue("jttqhyrj", loader);
                 if(jttqhyrj["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#MultibotSolver_ReCaptchav2TakeToken_code").html())({"bteynfts": bteynfts["updated"],"nnedharg": nnedharg["updated"],"jttqhyrj": jttqhyrj["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
