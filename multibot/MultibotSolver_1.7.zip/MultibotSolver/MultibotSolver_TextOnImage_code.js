_call_function(MultibotSolver_TextOnImage,{ "APIKEY": (<%= uovxvsmj %>),"IMAGE_IN_BASE64": (<%= iyygihig %>) })!
<%= variable %> = _result_function()
