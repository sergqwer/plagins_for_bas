_call_function(MultibotSolver_TextOnImage,{ "APIKEY": (<%= bcxwjalw %>),"IMAGE_IN_BASE64": (<%= wjblaccj %>) })!
<%= variable %> = _result_function()
