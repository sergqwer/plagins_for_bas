_call_function(MultibotSolver_GeeTest,{ "APIKEY": (<%= auxqspyo %>),"pixel_koef": (<%= omeotmfe %>) })!
