_call_function(MultibotSolver_GeeTest,{ "APIKEY": (<%= fmwklezv %>),"pixel_koef": (<%= cxbbgmwl %>) })!
