_call_function(MultibotSolver_AntiBot,{ "apikey": (<%= aetejmkn %>),"mouse": (<%= ggfadlqc %>) })!
