_call_function(MultibotSolver_AntiBot,{ "apikey": (<%= apdasjiz %>),"mouse": (<%= umqvxzzi %>) })!
