var apdasjiz = GetInputConstructorValue("apdasjiz", loader);
                 if(apdasjiz["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var umqvxzzi = GetInputConstructorValue("umqvxzzi", loader);
                 if(umqvxzzi["original"].length == 0)
                 {
                   Invalid("mouse" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#MultibotSolver_AntiBot_code").html())({"apdasjiz": apdasjiz["updated"],"umqvxzzi": umqvxzzi["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
