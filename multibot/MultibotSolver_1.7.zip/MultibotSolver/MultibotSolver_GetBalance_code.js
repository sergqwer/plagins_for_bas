_call_function(MultibotSolver_GetBalance,{ "APIKEY": (<%= qzytodus %>) })!
<%= variable %> = _result_function()
