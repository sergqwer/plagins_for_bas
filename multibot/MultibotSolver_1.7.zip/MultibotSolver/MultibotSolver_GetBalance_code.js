_call_function(MultibotSolver_GetBalance,{ "APIKEY": (<%= nucfhtfu %>) })!
<%= variable %> = _result_function()
