_call_function(MultibotSolver_ReCaptchav2TakeToken,{ "APIKEY": (<%= cprapfpx %>),"site_url": (<%= ybbjmmvm %>),"sitekey": (<%= ryxvyeff %>) })!
<%= variable %> = _result_function()
