_call_function(MultibotSolver_ReCaptchav2TakeToken,{ "APIKEY": (<%= bteynfts %>),"site_url": (<%= nnedharg %>),"sitekey": (<%= jttqhyrj %>) })!
<%= variable %> = _result_function()
