_call_function(OLD_MultibotSolver_GeeTest,{ "APIKEY": (<%= jruxpgiv %>),"pixel_koef": (<%= sgpgxvgl %>) })!
