_call_function(OLD_MultibotSolver_HcaptchaTakeToken,{ "APIKEY": (<%= okfjjeau %>),"site_url": (<%= yrjlvptk %>),"sitekey": (<%= ppzxmdnz %>) })!
<%= variable %> = _result_function()
