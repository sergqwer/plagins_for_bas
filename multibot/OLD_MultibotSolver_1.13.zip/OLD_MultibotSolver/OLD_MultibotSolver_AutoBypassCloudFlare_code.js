_call_function(OLD_MultibotSolver_AutoBypassCloudFlare,{ "custom_button": (<%= dgptuzrd %>),"max_time": (<%= gtfimbke %>),"whait_element": (<%= okmgfsof %>) })!
