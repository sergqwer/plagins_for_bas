_call_function(OLD_MultibotSolver_RsCaptchaFreeSolver,{  })!
