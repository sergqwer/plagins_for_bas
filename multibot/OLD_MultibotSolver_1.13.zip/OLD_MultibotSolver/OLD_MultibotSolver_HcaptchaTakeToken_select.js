var okfjjeau = GetInputConstructorValue("okfjjeau", loader);
                 if(okfjjeau["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var yrjlvptk = GetInputConstructorValue("yrjlvptk", loader);
                 if(yrjlvptk["original"].length == 0)
                 {
                   Invalid("site_url" + " is empty");
                   return;
                 }
var ppzxmdnz = GetInputConstructorValue("ppzxmdnz", loader);
                 if(ppzxmdnz["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#OLD_MultibotSolver_HcaptchaTakeToken_code").html())({"okfjjeau": okfjjeau["updated"],"yrjlvptk": yrjlvptk["updated"],"ppzxmdnz": ppzxmdnz["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
