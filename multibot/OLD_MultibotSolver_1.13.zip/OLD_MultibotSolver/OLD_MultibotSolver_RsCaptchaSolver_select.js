var yvpaadam = GetInputConstructorValue("yvpaadam", loader);
                 if(yvpaadam["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#OLD_MultibotSolver_RsCaptchaSolver_code").html())({"yvpaadam": yvpaadam["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
