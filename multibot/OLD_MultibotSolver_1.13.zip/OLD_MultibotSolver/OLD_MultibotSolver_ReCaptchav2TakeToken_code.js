_call_function(OLD_MultibotSolver_ReCaptchav2TakeToken,{ "APIKEY": (<%= hxvdhfdg %>),"site_url": (<%= bdhmxgrt %>),"sitekey": (<%= empqtpxa %>) })!
<%= variable %> = _result_function()
