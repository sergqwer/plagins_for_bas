_call_function(OLD_MultibotSolver_ReCaptcha_Bypass,{ "apikey": (<%= jvowfrok %>),"index": (<%= nimsmpdw %>) })!
