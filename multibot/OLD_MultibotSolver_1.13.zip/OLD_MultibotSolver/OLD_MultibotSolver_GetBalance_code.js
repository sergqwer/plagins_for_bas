_call_function(OLD_MultibotSolver_GetBalance,{ "APIKEY": (<%= xtnwybrk %>) })!
<%= variable %> = _result_function()
