_call_function(OLD_MultibotSolver_TextOnImage,{ "APIKEY": (<%= ifpmdrxy %>),"IMAGE_IN_BASE64": (<%= xumtpgau %>) })!
<%= variable %> = _result_function()
