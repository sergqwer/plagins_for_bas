var hjulqtpq = GetInputConstructorValue("hjulqtpq", loader);
                 if(hjulqtpq["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#OLD_MultibotSolver_Faucetpay_PTC_code").html())({"hjulqtpq": hjulqtpq["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
