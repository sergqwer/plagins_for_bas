var bcsiyafy = GetInputConstructorValue("bcsiyafy", loader);
                 if(bcsiyafy["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var uelkbrle = GetInputConstructorValue("uelkbrle", loader);
                 if(uelkbrle["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var rjbjhbsc = GetInputConstructorValue("rjbjhbsc", loader);
                 if(rjbjhbsc["original"].length == 0)
                 {
                   Invalid("siteurl" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#OLD_MultibotSolver_BasiliskCaptcha_code").html())({"bcsiyafy": bcsiyafy["updated"],"uelkbrle": uelkbrle["updated"],"rjbjhbsc": rjbjhbsc["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
