var dgptuzrd = GetInputConstructorValue("dgptuzrd", loader);
                 if(dgptuzrd["original"].length == 0)
                 {
                   Invalid("custom_button" + " is empty");
                   return;
                 }
var gtfimbke = GetInputConstructorValue("gtfimbke", loader);
                 if(gtfimbke["original"].length == 0)
                 {
                   Invalid("max_time" + " is empty");
                   return;
                 }
var okmgfsof = GetInputConstructorValue("okmgfsof", loader);
                 if(okmgfsof["original"].length == 0)
                 {
                   Invalid("whait_element" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#OLD_MultibotSolver_AutoBypassCloudFlare_code").html())({"dgptuzrd": dgptuzrd["updated"],"gtfimbke": gtfimbke["updated"],"okmgfsof": okmgfsof["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
