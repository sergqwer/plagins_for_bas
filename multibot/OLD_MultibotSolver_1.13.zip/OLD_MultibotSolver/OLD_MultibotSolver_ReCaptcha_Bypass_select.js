var jvowfrok = GetInputConstructorValue("jvowfrok", loader);
                 if(jvowfrok["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var nimsmpdw = GetInputConstructorValue("nimsmpdw", loader);
                 if(nimsmpdw["original"].length == 0)
                 {
                   Invalid("index" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#OLD_MultibotSolver_ReCaptcha_Bypass_code").html())({"jvowfrok": jvowfrok["updated"],"nimsmpdw": nimsmpdw["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
