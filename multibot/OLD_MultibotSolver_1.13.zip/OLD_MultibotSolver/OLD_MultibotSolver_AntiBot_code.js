_call_function(OLD_MultibotSolver_AntiBot,{ "apikey": (<%= qslnkfej %>),"mouse": (<%= hqcnqpzz %>) })!
