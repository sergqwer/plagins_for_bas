var ezeuyewl = GetInputConstructorValue("ezeuyewl", loader);
                 if(ezeuyewl["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#OLD_MultibotSolver_HcaptchaAutoSolver_code").html())({"ezeuyewl": ezeuyewl["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
