<div class="container-fluid">
<%= _.template($('#input_constructor').html())({id:"klzrabvz", description:"apikey", default_selector: "string", disable_int:true, value_string: "", help: {description: "apikey с сервиса https://multibot.in/"} }) %>
</div>
<div class="tooltipinternal">
</div>
<%= _.template($('#back').html())({action:"executeandadd", visible:true}) %>
