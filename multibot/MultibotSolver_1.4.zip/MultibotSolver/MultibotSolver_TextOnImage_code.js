_call_function(MultibotSolver_TextOnImage,{ "APIKEY": (<%= ynqoermx %>),"IMAGE_IN_BASE64": (<%= rwssscww %>) })!
<%= variable %> = _result_function()
