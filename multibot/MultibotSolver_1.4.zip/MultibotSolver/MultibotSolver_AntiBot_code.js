_call_function(MultibotSolver_AntiBot,{ "apikey": (<%= atzvibmp %>),"mouse": (<%= kbxcfhtd %>) })!
