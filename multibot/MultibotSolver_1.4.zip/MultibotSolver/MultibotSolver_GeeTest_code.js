_call_function(MultibotSolver_GeeTest,{ "APIKEY": (<%= ycffitwj %>),"pixel_koef": (<%= uigbfmjv %>) })!
