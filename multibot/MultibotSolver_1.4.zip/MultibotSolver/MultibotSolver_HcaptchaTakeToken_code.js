_call_function(MultibotSolver_HcaptchaTakeToken,{ "APIKEY": (<%= rifkakjd %>),"site_url": (<%= avmjtruk %>),"sitekey": (<%= ownnbpre %>) })!
<%= variable %> = _result_function()
