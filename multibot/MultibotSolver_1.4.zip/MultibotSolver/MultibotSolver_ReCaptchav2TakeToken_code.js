_call_function(MultibotSolver_ReCaptchav2TakeToken,{ "APIKEY": (<%= djhramej %>),"site_url": (<%= tnlsqgnu %>),"sitekey": (<%= yrqietcy %>) })!
<%= variable %> = _result_function()
