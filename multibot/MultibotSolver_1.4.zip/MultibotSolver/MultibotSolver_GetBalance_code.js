_call_function(MultibotSolver_GetBalance,{ "APIKEY": (<%= diexckdu %>) })!
<%= variable %> = _result_function()
