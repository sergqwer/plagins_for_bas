var atzvibmp = GetInputConstructorValue("atzvibmp", loader);
                 if(atzvibmp["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var kbxcfhtd = GetInputConstructorValue("kbxcfhtd", loader);
                 if(kbxcfhtd["original"].length == 0)
                 {
                   Invalid("mouse" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#MultibotSolver_AntiBot_code").html())({"atzvibmp": atzvibmp["updated"],"kbxcfhtd": kbxcfhtd["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
