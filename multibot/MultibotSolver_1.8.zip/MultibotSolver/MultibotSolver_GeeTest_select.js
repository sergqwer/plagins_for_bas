var cwusigax = GetInputConstructorValue("cwusigax", loader);
                 if(cwusigax["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var ghmrpdyw = GetInputConstructorValue("ghmrpdyw", loader);
                 if(ghmrpdyw["original"].length == 0)
                 {
                   Invalid("pixel_koef" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#MultibotSolver_GeeTest_code").html())({"cwusigax": cwusigax["updated"],"ghmrpdyw": ghmrpdyw["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
