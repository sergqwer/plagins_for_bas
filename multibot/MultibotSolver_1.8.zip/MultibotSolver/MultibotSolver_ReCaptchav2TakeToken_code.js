_call_function(MultibotSolver_ReCaptchav2TakeToken,{ "APIKEY": (<%= tufmmqhn %>),"site_url": (<%= dzzmlupw %>),"sitekey": (<%= fucffrlr %>) })!
<%= variable %> = _result_function()
