var tufmmqhn = GetInputConstructorValue("tufmmqhn", loader);
                 if(tufmmqhn["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var dzzmlupw = GetInputConstructorValue("dzzmlupw", loader);
                 if(dzzmlupw["original"].length == 0)
                 {
                   Invalid("site_url" + " is empty");
                   return;
                 }
var fucffrlr = GetInputConstructorValue("fucffrlr", loader);
                 if(fucffrlr["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#MultibotSolver_ReCaptchav2TakeToken_code").html())({"tufmmqhn": tufmmqhn["updated"],"dzzmlupw": dzzmlupw["updated"],"fucffrlr": fucffrlr["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
