var yjdticnz = GetInputConstructorValue("yjdticnz", loader);
                 if(yjdticnz["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#MultibotSolver_GetBalance_code").html())({"yjdticnz": yjdticnz["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
