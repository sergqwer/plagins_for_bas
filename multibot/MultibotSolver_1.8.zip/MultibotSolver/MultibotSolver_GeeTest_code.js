_call_function(MultibotSolver_GeeTest,{ "APIKEY": (<%= cwusigax %>),"pixel_koef": (<%= ghmrpdyw %>) })!
