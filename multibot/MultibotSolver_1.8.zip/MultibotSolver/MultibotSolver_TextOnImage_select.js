var rjfbjmwn = GetInputConstructorValue("rjfbjmwn", loader);
                 if(rjfbjmwn["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var jnapyxwl = GetInputConstructorValue("jnapyxwl", loader);
                 if(jnapyxwl["original"].length == 0)
                 {
                   Invalid("IMAGE_IN_BASE64" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#MultibotSolver_TextOnImage_code").html())({"rjfbjmwn": rjfbjmwn["updated"],"jnapyxwl": jnapyxwl["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
