_call_function(MultibotSolver_TextOnImage,{ "APIKEY": (<%= rjfbjmwn %>),"IMAGE_IN_BASE64": (<%= jnapyxwl %>) })!
<%= variable %> = _result_function()
