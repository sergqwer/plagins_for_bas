_call_function(MultibotSolver_AntiBot,{ "apikey": (<%= adplfsjn %>),"mouse": (<%= juayulsx %>) })!
