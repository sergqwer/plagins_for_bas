_call_function(MultibotSolver_HcaptchaTakeToken,{ "APIKEY": (<%= ksrgztop %>),"site_url": (<%= ndpvxmoe %>),"sitekey": (<%= ntgleurn %>) })!
<%= variable %> = _result_function()
