_call_function(MultibotSolver_GetBalance,{ "APIKEY": (<%= yjdticnz %>) })!
<%= variable %> = _result_function()
