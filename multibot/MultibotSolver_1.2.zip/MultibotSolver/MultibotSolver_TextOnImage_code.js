_call_function(MultibotSolver_TextOnImage,{ "APIKEY": (<%= loxzlglr %>),"IMAGE_IN_BASE64": (<%= sqsnzhrk %>) })!
<%= variable %> = _result_function()
