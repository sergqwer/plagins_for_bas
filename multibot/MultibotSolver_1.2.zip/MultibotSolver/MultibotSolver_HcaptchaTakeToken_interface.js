<div class="container-fluid">
<%= _.template($('#input_constructor').html())({id:"vwvahcmf", description:"APIKEY", default_selector: "string", disable_expression:true, disable_int:true, value_string: "", help: {description: "apikey с сервиса https://multibot.in/"} }) %>
<%= _.template($('#input_constructor').html())({id:"rhnwjfwd", description:"site_url", default_selector: "string", disable_expression:true, disable_int:true, value_string: "", help: {description: "Полный URL страницы где находится Hcaptcha"} }) %>
<%= _.template($('#input_constructor').html())({id:"wkhvfsgq", description:"sitekey", default_selector: "string", disable_expression:true, disable_int:true, value_string: "", help: {description: "Значение параметра data-sitekey Hcaptcha"} }) %>
<%= _.template($('#variable_constructor').html())({id:"Save", description:"Result", default_variable: "HCAPTCHA_TOKEN", help: {description: "Токен hcaptcha"}}) %>
</div>
<div class="tooltipinternal">
<div class="tr tooltip-paragraph-first-fold">Эта функция получает токен Hcaptcha через сервис решения капчи https://multibot.in/</div>
</div>
<%= _.template($('#back').html())({action:"executeandadd", visible:true}) %>
