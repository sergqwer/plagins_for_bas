_call_function(MultibotSolver_ReCaptchav2TakeToken,{ "APIKEY": (<%= jfobblho %>),"site_url": (<%= aexmjgjd %>),"sitekey": (<%= zljuxdud %>) })!
<%= variable %> = _result_function()
