_call_function(MultibotSolver_GeeTest,{ "APIKEY": (<%= vtkvlzbx %>),"pixel_koef": (<%= bsyzsitw %>) })!
