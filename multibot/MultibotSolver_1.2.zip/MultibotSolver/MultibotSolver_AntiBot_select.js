var qhnfpjcg = GetInputConstructorValue("qhnfpjcg", loader);
                 if(qhnfpjcg["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var fwzriqwa = GetInputConstructorValue("fwzriqwa", loader);
                 if(fwzriqwa["original"].length == 0)
                 {
                   Invalid("mouse" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#MultibotSolver_AntiBot_code").html())({"qhnfpjcg": qhnfpjcg["updated"],"fwzriqwa": fwzriqwa["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
