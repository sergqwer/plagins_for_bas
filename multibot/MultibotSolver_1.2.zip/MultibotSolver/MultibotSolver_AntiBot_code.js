_call_function(MultibotSolver_AntiBot,{ "apikey": (<%= qhnfpjcg %>),"mouse": (<%= fwzriqwa %>) })!
