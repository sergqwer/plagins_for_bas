_call_function(MultibotSolver_GetBalance,{ "APIKEY": (<%= mbjkbjfa %>) })!
<%= variable %> = _result_function()
