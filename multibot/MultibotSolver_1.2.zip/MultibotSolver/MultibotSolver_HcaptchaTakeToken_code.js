_call_function(MultibotSolver_HcaptchaTakeToken,{ "APIKEY": (<%= vwvahcmf %>),"site_url": (<%= rhnwjfwd %>),"sitekey": (<%= wkhvfsgq %>) })!
<%= variable %> = _result_function()
