_call_function(MultibotSolver_RsCaptchaFreeSolver,{  })!
