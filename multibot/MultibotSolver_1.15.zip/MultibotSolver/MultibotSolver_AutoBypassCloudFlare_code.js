_call_function(MultibotSolver_AutoBypassCloudFlare,{ "custom_button": (<%= nsxcqsmv %>),"max_time": (<%= ysapnriz %>),"whait_element": (<%= thhpqvlj %>) })!
