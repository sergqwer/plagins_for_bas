_call_function(MultibotSolver_ForAutosolveReHCaptcha,{ "hCaptcha_USE": (<%= iqzkmcwz %>),"ReCaptcha_USE": (<%= nrbguukd %>) })!
