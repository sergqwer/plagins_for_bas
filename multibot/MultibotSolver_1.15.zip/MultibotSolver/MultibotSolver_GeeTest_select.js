var gmyamgdz = GetInputConstructorValue("gmyamgdz", loader);
                 if(gmyamgdz["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var wxmssozf = GetInputConstructorValue("wxmssozf", loader);
                 if(wxmssozf["original"].length == 0)
                 {
                   Invalid("pixel_koef" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#MultibotSolver_GeeTest_code").html())({"gmyamgdz": gmyamgdz["updated"],"wxmssozf": wxmssozf["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
