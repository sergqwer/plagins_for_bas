_call_function(MultibotSolver_Faucetpay_CacheAllow,{  })!
