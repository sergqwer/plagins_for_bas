_call_function(MultibotSolver_HcaptchaTakeToken,{ "APIKEY": (<%= vwqtmgau %>),"site_url": (<%= czxoqccp %>),"sitekey": (<%= uuuxzedi %>) })!
<%= variable %> = _result_function()
