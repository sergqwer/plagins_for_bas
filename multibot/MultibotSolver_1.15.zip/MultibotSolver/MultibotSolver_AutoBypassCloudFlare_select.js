var nsxcqsmv = GetInputConstructorValue("nsxcqsmv", loader);
                 if(nsxcqsmv["original"].length == 0)
                 {
                   Invalid("custom_button" + " is empty");
                   return;
                 }
var ysapnriz = GetInputConstructorValue("ysapnriz", loader);
                 if(ysapnriz["original"].length == 0)
                 {
                   Invalid("max_time" + " is empty");
                   return;
                 }
var thhpqvlj = GetInputConstructorValue("thhpqvlj", loader);
                 if(thhpqvlj["original"].length == 0)
                 {
                   Invalid("whait_element" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#MultibotSolver_AutoBypassCloudFlare_code").html())({"nsxcqsmv": nsxcqsmv["updated"],"ysapnriz": ysapnriz["updated"],"thhpqvlj": thhpqvlj["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
