var yjdsdeaz = GetInputConstructorValue("yjdsdeaz", loader);
                 if(yjdsdeaz["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var duwxyotc = GetInputConstructorValue("duwxyotc", loader);
                 if(duwxyotc["original"].length == 0)
                 {
                   Invalid("site_url" + " is empty");
                   return;
                 }
var qslkagxy = GetInputConstructorValue("qslkagxy", loader);
                 if(qslkagxy["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#MultibotSolver_Turnstile_TakeToken_code").html())({"yjdsdeaz": yjdsdeaz["updated"],"duwxyotc": duwxyotc["updated"],"qslkagxy": qslkagxy["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
