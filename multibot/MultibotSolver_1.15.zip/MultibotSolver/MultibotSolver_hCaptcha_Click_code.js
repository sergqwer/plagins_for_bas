_call_function(MultibotSolver_hCaptcha_Click,{ "apikey": (<%= buyyevob %>),"CaptchaSelector": (<%= gpbbwslq %>),"InvisibleCaptcha": (<%= xkzdfbtj %>),"TrySolve": (<%= qlwhngar %>) })!
