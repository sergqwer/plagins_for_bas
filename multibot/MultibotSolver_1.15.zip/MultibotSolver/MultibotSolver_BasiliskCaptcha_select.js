var lyaeycxb = GetInputConstructorValue("lyaeycxb", loader);
                 if(lyaeycxb["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var wkwiills = GetInputConstructorValue("wkwiills", loader);
                 if(wkwiills["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var caysvwwc = GetInputConstructorValue("caysvwwc", loader);
                 if(caysvwwc["original"].length == 0)
                 {
                   Invalid("siteurl" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#MultibotSolver_BasiliskCaptcha_code").html())({"lyaeycxb": lyaeycxb["updated"],"wkwiills": wkwiills["updated"],"caysvwwc": caysvwwc["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
