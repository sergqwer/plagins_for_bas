<div class="container-fluid">
<%= _.template($('#input_constructor').html())({id:"yjdsdeaz", description:"APIKEY", default_selector: "string", disable_expression:true, disable_int:true, value_string: "", help: {description: "apikey с сервиса https://multibot.in/"} }) %>
<%= _.template($('#input_constructor').html())({id:"duwxyotc", description:"site_url", default_selector: "string", disable_expression:true, disable_int:true, value_string: "https://turnstile.zeroclover.io/", help: {description: "Полный URL страницы где находится Turnstile"} }) %>
<%= _.template($('#input_constructor').html())({id:"qslkagxy", description:"sitekey", default_selector: "string", disable_expression:true, disable_int:true, value_string: "0x4AAAAAAAEwzhD6pyKkgXC0", help: {description: "Значение параметра data-sitekey Turnstile"} }) %>
<%= _.template($('#variable_constructor').html())({id:"Save", description:"Result", default_variable: "TURNSTILE_TOKEN", help: {description: "Токен Turnstile"}}) %>
</div>
<div class="tooltipinternal">
<div class="tr tooltip-paragraph-first-fold">Эта функция получает токен Turnstile через сервис решения капчи https://multibot.in/</div>
<div class="tr tooltip-paragraph-last-fold">(решается только капча, это НЕ обходит защиту от DOS/DDOS которая появляется при загрузки сайта)</div>
</div>
<%= _.template($('#back').html())({action:"executeandadd", visible:true}) %>
