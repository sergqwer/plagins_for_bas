_call_function(MultibotSolver_RsCaptchaSolver,{ "apikey": (<%= qakufgzq %>) })!
