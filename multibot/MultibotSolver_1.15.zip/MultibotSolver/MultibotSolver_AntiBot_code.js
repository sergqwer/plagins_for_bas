_call_function(MultibotSolver_AntiBot,{ "apikey": (<%= qkchziii %>),"mouse": (<%= neofvwsd %>) })!
