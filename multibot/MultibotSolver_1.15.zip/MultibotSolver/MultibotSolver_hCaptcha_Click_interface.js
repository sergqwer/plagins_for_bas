<div class="container-fluid">
<%= _.template($('#input_constructor').html())({id:"buyyevob", description:"apikey", default_selector: "string", disable_int:true, value_string: "", help: {description: "apikey с сервиса https://multibot.in/"} }) %>
<%= _.template($('#input_constructor').html())({id:"gpbbwslq", description:"CaptchaSelector", default_selector: "string", disable_int:true, value_string: ">CSS> iframe[src*='checkbox']>FRAME> >CSS> #checkbox", help: {description: "Селектор hCaptcha"} }) %>
<%= _.template($('#input_constructor').html())({id:"xkzdfbtj", description:"InvisibleCaptcha", default_selector: "expression", disable_int:true, disable_string:true, value_string: "false", help: {description: "Это невидимая капча?\nfalse - нет\ntrue - да\nЕсли капча невидимая, для ее решения надо разрешить кеш"} }) %>
<%= _.template($('#input_constructor').html())({id:"qlwhngar", description:"TrySolve", default_selector: "int", disable_string:true, value_number: 20, min_number:-999999, max_number:999999, help: {description: "Количество попыток решения капчи"} }) %>
</div>
<div class="tooltipinternal">
<div class="tr tooltip-paragraph-first-fold">Решает кликами hCaptcha через сервис https://multibot.in/, оплачивается каждое изображение</div>
<div class="tr tooltip-paragraph-last-fold">Для невидимой hcaptcha надо разрешить кеш *hcaptcha.com/getcaptcha* и *img*hcaptcha.com/*</div>
</div>
<%= _.template($('#back').html())({action:"executeandadd", visible:true}) %>
