_call_function(MultibotSolver_GeeTest,{ "APIKEY": (<%= gmyamgdz %>),"pixel_koef": (<%= wxmssozf %>) })!
