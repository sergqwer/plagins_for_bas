_call_function(MultibotSolver_Faucetpay_PTC,{ "apikey": (<%= tbzhgryk %>) })!
