var kndbgpki = GetInputConstructorValue("kndbgpki", loader);
                 if(kndbgpki["original"].length == 0)
                 {
                   Invalid("hCaptcha_USE" + " is empty");
                   return;
                 }
var huceblqx = GetInputConstructorValue("huceblqx", loader);
                 if(huceblqx["original"].length == 0)
                 {
                   Invalid("ReCaptcha_USE" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#OLD_MultibotSolver_ForAutosolveReHCaptcha_code").html())({"kndbgpki": kndbgpki["updated"],"huceblqx": huceblqx["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
