var qkmusxdp = GetInputConstructorValue("qkmusxdp", loader);
                 if(qkmusxdp["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#OLD_MultibotSolver_Upside_Down_code").html())({"qkmusxdp": qkmusxdp["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
