var invzcwqe = GetInputConstructorValue("invzcwqe", loader);
                 if(invzcwqe["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#OLD_MultibotSolver_Faucetpay_PTC_code").html())({"invzcwqe": invzcwqe["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
