var aqroswyu = GetInputConstructorValue("aqroswyu", loader);
                 if(aqroswyu["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var apcdfisu = GetInputConstructorValue("apcdfisu", loader);
                 if(apcdfisu["original"].length == 0)
                 {
                   Invalid("site_url" + " is empty");
                   return;
                 }
var xioiemhl = GetInputConstructorValue("xioiemhl", loader);
                 if(xioiemhl["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#OLD_MultibotSolver_ReCaptchav2TakeToken_code").html())({"aqroswyu": aqroswyu["updated"],"apcdfisu": apcdfisu["updated"],"xioiemhl": xioiemhl["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
