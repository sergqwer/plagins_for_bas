var defwgmth = GetInputConstructorValue("defwgmth", loader);
                 if(defwgmth["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#OLD_MultibotSolver_SolveMedia_code").html())({"defwgmth": defwgmth["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
