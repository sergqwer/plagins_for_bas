_call_function(OLD_MultibotSolver_ForAutosolveReHCaptcha,{ "hCaptcha_USE": (<%= kndbgpki %>),"ReCaptcha_USE": (<%= huceblqx %>) })!
