var moiwpqxb = GetInputConstructorValue("moiwpqxb", loader);
                 if(moiwpqxb["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var nvgbezwy = GetInputConstructorValue("nvgbezwy", loader);
                 if(nvgbezwy["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var vvhbrtbw = GetInputConstructorValue("vvhbrtbw", loader);
                 if(vvhbrtbw["original"].length == 0)
                 {
                   Invalid("siteurl" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#OLD_MultibotSolver_BasiliskCaptcha_code").html())({"moiwpqxb": moiwpqxb["updated"],"nvgbezwy": nvgbezwy["updated"],"vvhbrtbw": vvhbrtbw["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
