_call_function(OLD_MultibotSolver_AutoBypassCloudFlare,{ "custom_button": (<%= fjsmxxmn %>),"max_time": (<%= ckfccyum %>),"whait_element": (<%= udizyjkr %>) })!
