<div class="container-fluid">
<%= _.template($('#input_constructor').html())({id:"fjsmxxmn", description:"custom_button", default_selector: "string", disable_int:true, value_string: "false", help: {description: "На некоторых сайтах собственный ид кнопри при прохождении клауда, можете вписать этот ид здесь\n\nfalse - игнорировать этот параметр"} }) %>
<%= _.template($('#input_constructor').html())({id:"ckfccyum", description:"max_time", default_selector: "int", disable_string:true, value_number: 250, min_number:-999999, max_number:999999, help: {description: "Максимальное время ожидания в секундах"} }) %>
<%= _.template($('#input_constructor').html())({id:"udizyjkr", description:"whait_element", default_selector: "string", disable_int:true, value_string: "false", help: {description: "Елемент на странице, после появления которого скрипт прервет ожидания\n\nfalse - игнорировать этот параметр\n\nНапример вам надо загрузить страницу входа на сайт, но там клауд, указываете здесь идентификатор формы ввода логина"} }) %>
</div>
<div class="tooltipinternal">
<div class="tr tooltip-paragraph-first-fold">Автоматически проходит CloudFlare на любом сайте в браузере, просто небольшой удобный скрипт</div>
</div>
<%= _.template($('#back').html())({action:"executeandadd", visible:true}) %>
