_call_function(OLD_MultibotSolver_ReCaptchav2TakeToken,{ "APIKEY": (<%= aqroswyu %>),"site_url": (<%= apcdfisu %>),"sitekey": (<%= xioiemhl %>) })!
<%= variable %> = _result_function()
