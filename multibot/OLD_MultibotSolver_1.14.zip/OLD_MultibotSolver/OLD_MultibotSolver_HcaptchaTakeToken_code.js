_call_function(OLD_MultibotSolver_HcaptchaTakeToken,{ "APIKEY": (<%= cajsdgqj %>),"site_url": (<%= kojnhjwi %>),"sitekey": (<%= mfialfyf %>) })!
<%= variable %> = _result_function()
