_call_function(OLD_MultibotSolver_Turnstile_TakeToken,{ "APIKEY": (<%= pjpymtpu %>),"site_url": (<%= pokejtca %>),"sitekey": (<%= ahcpoisd %>) })!
<%= variable %> = _result_function()
