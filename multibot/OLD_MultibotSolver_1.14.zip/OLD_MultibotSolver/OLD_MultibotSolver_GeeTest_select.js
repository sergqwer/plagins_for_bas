var zoeariwl = GetInputConstructorValue("zoeariwl", loader);
                 if(zoeariwl["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var bfyhtzjc = GetInputConstructorValue("bfyhtzjc", loader);
                 if(bfyhtzjc["original"].length == 0)
                 {
                   Invalid("pixel_koef" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#OLD_MultibotSolver_GeeTest_code").html())({"zoeariwl": zoeariwl["updated"],"bfyhtzjc": bfyhtzjc["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
