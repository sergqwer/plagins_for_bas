_call_function(OLD_MultibotSolver_TextOnImage,{ "APIKEY": (<%= pukweeac %>),"IMAGE_IN_BASE64": (<%= cueazcsr %>) })!
<%= variable %> = _result_function()
