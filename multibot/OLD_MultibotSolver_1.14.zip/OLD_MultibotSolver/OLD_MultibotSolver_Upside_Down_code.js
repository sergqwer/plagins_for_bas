_call_function(OLD_MultibotSolver_Upside_Down,{ "apikey": (<%= qkmusxdp %>) })!
