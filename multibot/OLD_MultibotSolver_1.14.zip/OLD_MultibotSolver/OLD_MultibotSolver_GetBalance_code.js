_call_function(OLD_MultibotSolver_GetBalance,{ "APIKEY": (<%= orxzezaz %>) })!
<%= variable %> = _result_function()
