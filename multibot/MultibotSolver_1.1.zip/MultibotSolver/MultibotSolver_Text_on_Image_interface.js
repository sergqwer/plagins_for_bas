<div class="container-fluid">
<%= _.template($('#input_constructor').html())({id:"fqovjnph", description:"APIKEY", default_selector: "string", disable_expression:true, disable_int:true, value_string: "", help: {description: "apikey с сервиса https://multibot.in/"} }) %>
<%= _.template($('#input_constructor').html())({id:"fuebrtct", description:"IMAGE_IN_BASE64", default_selector: "string", disable_expression:true, disable_int:true, value_string: "", help: {description: "Изображение в формате base64"} }) %>
<%= _.template($('#variable_constructor').html())({id:"Save", description:"Result", default_variable: "IMAGE_RESULT", help: {description: "Текст с изображения"}}) %>
</div>
<div class="tooltipinternal">
<div class="tr tooltip-paragraph-first-fold">Эта функция распознает текст на изображении через сервис решения капчи https://multibot.in/</div>
<div class="tr tooltip-paragraph-last-fold">Для работы надо указать изображение в формате base64</div>
</div>
<%= _.template($('#back').html())({action:"executeandadd", visible:true}) %>
