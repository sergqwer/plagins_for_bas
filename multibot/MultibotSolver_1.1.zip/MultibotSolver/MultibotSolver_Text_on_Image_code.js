_call_function(MultibotSolver_Text_on_Image,{ "APIKEY": (<%= fqovjnph %>),"IMAGE_IN_BASE64": (<%= fuebrtct %>) })!
<%= variable %> = _result_function()
