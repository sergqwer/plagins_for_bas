_call_function(MultibotSolver_Text_on_Image,{ "APIKEY": (<%= kwfqoavl %>),"IMAGE_IN_BASE64": (<%= tvmpupgw %>) })!
<%= variable %> = _result_function()
