var frggaaol = GetInputConstructorValue("frggaaol", loader);
                 if(frggaaol["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var qkndyyxo = GetInputConstructorValue("qkndyyxo", loader);
                 if(qkndyyxo["original"].length == 0)
                 {
                   Invalid("mouse" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#MultibotSolver_AntiBot_code").html())({"frggaaol": frggaaol["updated"],"qkndyyxo": qkndyyxo["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
