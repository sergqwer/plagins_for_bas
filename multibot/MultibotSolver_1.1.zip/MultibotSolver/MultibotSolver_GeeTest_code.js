_call_function(MultibotSolver_GeeTest,{ "APIKEY": (<%= aywqstxp %>),"pixel_koef": (<%= qvdjjigu %>) })!
