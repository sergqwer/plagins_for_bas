_call_function(MultibotSolver_GeeTest,{ "APIKEY": (<%= vrqizlsg %>),"pixel_koef": (<%= uowrkcfj %>) })!
