var bijduibd = GetInputConstructorValue("bijduibd", loader);
                 if(bijduibd["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var nibywgql = GetInputConstructorValue("nibywgql", loader);
                 if(nibywgql["original"].length == 0)
                 {
                   Invalid("site_url" + " is empty");
                   return;
                 }
var zptwatea = GetInputConstructorValue("zptwatea", loader);
                 if(zptwatea["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#MultibotSolver_HcaptchaTakeToken_code").html())({"bijduibd": bijduibd["updated"],"nibywgql": nibywgql["updated"],"zptwatea": zptwatea["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
