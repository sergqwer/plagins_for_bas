_call_function(MultibotSolver_GetBalance,{ "APIKEY": (<%= jeslrllp %>) })!
<%= variable %> = _result_function()
