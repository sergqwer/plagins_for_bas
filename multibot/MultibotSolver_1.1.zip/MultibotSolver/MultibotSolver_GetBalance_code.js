_call_function(MultibotSolver_GetBalance,{ "APIKEY": (<%= zviwxibt %>) })!
<%= variable %> = _result_function()
