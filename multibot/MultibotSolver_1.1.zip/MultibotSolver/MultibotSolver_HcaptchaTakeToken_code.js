_call_function(MultibotSolver_HcaptchaTakeToken,{ "APIKEY": (<%= iisehchs %>),"site_url": (<%= qtecpxon %>),"sitekey": (<%= cycysnac %>) })!
<%= variable %> = _result_function()
