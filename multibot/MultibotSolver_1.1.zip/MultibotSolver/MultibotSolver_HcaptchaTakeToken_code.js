_call_function(MultibotSolver_HcaptchaTakeToken,{ "APIKEY": (<%= bijduibd %>),"site_url": (<%= nibywgql %>),"sitekey": (<%= zptwatea %>) })!
<%= variable %> = _result_function()
