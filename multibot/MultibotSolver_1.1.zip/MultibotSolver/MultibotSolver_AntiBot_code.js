_call_function(MultibotSolver_AntiBot,{ "apikey": (<%= frggaaol %>),"mouse": (<%= qkndyyxo %>) })!
