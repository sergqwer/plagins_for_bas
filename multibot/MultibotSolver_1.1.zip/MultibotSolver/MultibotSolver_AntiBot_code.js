_call_function(MultibotSolver_AntiBot,{ "apikey": (<%= lsqdqchl %>),"mouse": (<%= custpmwc %>) })!
