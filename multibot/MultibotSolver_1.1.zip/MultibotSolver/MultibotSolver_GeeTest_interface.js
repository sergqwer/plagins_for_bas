<div class="container-fluid">
<%= _.template($('#input_constructor').html())({id:"vrqizlsg", description:"APIKEY", default_selector: "string", disable_expression:true, disable_int:true, value_string: "", help: {description: "apikey с сервиса https://multibot.in/"} }) %>
<%= _.template($('#input_constructor').html())({id:"uowrkcfj", description:"pixel_koef", default_selector: "int", disable_string:true, value_number: 0, min_number:-999999, max_number:999999, help: {description: "Значения в пикселях которое додается к ответу (если скрипт перетягивает, или недотягивает пазл), в основном находится в пределах от - 60 до 60"} }) %>
</div>
<div class="tooltipinternal">
<div class="tr tooltip-paragraph-first-fold">Эта функция решает GeeTest slider через сервис решения капчи https://multibot.in/</div>
<div class="tr tooltip-paragraph-last-fold">Если не находит кнопку, которая вызывает капчу, нажмите на нее, после чего вызовите эту функцию</div>
</div>
<%= _.template($('#back').html())({action:"executeandadd", visible:true}) %>
