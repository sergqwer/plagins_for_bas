_call_function(MultibotSolver_ReCaptchav2TakeToken,{ "APIKEY": (<%= wowrantf %>),"site_url": (<%= bzyceqtz %>),"sitekey": (<%= nughtlhn %>) })!
<%= variable %> = _result_function()
