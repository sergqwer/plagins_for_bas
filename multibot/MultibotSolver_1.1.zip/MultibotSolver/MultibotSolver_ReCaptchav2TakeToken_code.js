_call_function(MultibotSolver_ReCaptchav2TakeToken,{ "APIKEY": (<%= kvxtnvvu %>),"site_url": (<%= kfurrcnd %>),"sitekey": (<%= siyphhzt %>) })!
<%= variable %> = _result_function()
