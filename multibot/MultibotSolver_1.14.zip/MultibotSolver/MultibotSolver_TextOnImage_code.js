_call_function(MultibotSolver_TextOnImage,{ "APIKEY": (<%= ygxqhexl %>),"IMAGE_IN_BASE64": (<%= qwntrwwt %>) })!
<%= variable %> = _result_function()
