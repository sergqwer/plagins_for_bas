_call_function(MultibotSolver_TextOnImage,{ "APIKEY": (<%= ktbbrvxb %>),"IMAGE_IN_BASE64": (<%= evkshiso %>) })!
<%= variable %> = _result_function()
