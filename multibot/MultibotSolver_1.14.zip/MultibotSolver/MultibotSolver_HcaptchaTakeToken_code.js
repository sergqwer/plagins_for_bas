_call_function(MultibotSolver_HcaptchaTakeToken,{ "APIKEY": (<%= mpjfjokg %>),"site_url": (<%= ssqbxwgk %>),"sitekey": (<%= dtrfuhzq %>) })!
<%= variable %> = _result_function()
