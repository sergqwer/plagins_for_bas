_call_function(MultibotSolver_HcaptchaTakeToken,{ "APIKEY": (<%= umkthmbv %>),"site_url": (<%= cwidvpgg %>),"sitekey": (<%= wxdxmcnf %>) })!
<%= variable %> = _result_function()
