var eczylfsb = GetInputConstructorValue("eczylfsb", loader);
                 if(eczylfsb["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var tzeqoier = GetInputConstructorValue("tzeqoier", loader);
                 if(tzeqoier["original"].length == 0)
                 {
                   Invalid("index" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#MultibotSolver_ReCaptcha_Bypass_code").html())({"eczylfsb": eczylfsb["updated"],"tzeqoier": tzeqoier["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
