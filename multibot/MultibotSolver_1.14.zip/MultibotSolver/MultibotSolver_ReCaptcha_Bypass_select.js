var rhddvfiz = GetInputConstructorValue("rhddvfiz", loader);
                 if(rhddvfiz["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var lijxphmq = GetInputConstructorValue("lijxphmq", loader);
                 if(lijxphmq["original"].length == 0)
                 {
                   Invalid("index" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#MultibotSolver_ReCaptcha_Bypass_code").html())({"rhddvfiz": rhddvfiz["updated"],"lijxphmq": lijxphmq["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
