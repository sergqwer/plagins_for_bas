_call_function(MultibotSolver_Turnstile_TakeToken,{ "APIKEY": (<%= evjyltoy %>),"site_url": (<%= qanratrm %>),"sitekey": (<%= gotoxoqy %>) })!
<%= variable %> = _result_function()
