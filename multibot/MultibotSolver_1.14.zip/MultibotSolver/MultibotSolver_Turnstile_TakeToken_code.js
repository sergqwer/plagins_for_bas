_call_function(MultibotSolver_Turnstile_TakeToken,{ "APIKEY": (<%= hhoariwq %>),"site_url": (<%= ubmjguzm %>),"sitekey": (<%= cizvkyzy %>) })!
<%= variable %> = _result_function()
