var azzyfwod = GetInputConstructorValue("azzyfwod", loader);
                 if(azzyfwod["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var buoieqmw = GetInputConstructorValue("buoieqmw", loader);
                 if(buoieqmw["original"].length == 0)
                 {
                   Invalid("CaptchaSelector" + " is empty");
                   return;
                 }
var ohyalwsf = GetInputConstructorValue("ohyalwsf", loader);
                 if(ohyalwsf["original"].length == 0)
                 {
                   Invalid("InvisibleCaptcha" + " is empty");
                   return;
                 }
var zxgxxwzx = GetInputConstructorValue("zxgxxwzx", loader);
                 if(zxgxxwzx["original"].length == 0)
                 {
                   Invalid("TrySolve" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#MultibotSolver_hCaptcha_Click_code").html())({"azzyfwod": azzyfwod["updated"],"buoieqmw": buoieqmw["updated"],"ohyalwsf": ohyalwsf["updated"],"zxgxxwzx": zxgxxwzx["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
