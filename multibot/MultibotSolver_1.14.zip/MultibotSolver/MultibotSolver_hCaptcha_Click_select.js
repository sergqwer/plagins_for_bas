var autkhqas = GetInputConstructorValue("autkhqas", loader);
                 if(autkhqas["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var agfdojca = GetInputConstructorValue("agfdojca", loader);
                 if(agfdojca["original"].length == 0)
                 {
                   Invalid("CaptchaSelector" + " is empty");
                   return;
                 }
var ruovmdvc = GetInputConstructorValue("ruovmdvc", loader);
                 if(ruovmdvc["original"].length == 0)
                 {
                   Invalid("InvisibleCaptcha" + " is empty");
                   return;
                 }
var ghlyqfjq = GetInputConstructorValue("ghlyqfjq", loader);
                 if(ghlyqfjq["original"].length == 0)
                 {
                   Invalid("TrySolve" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#MultibotSolver_hCaptcha_Click_code").html())({"autkhqas": autkhqas["updated"],"agfdojca": agfdojca["updated"],"ruovmdvc": ruovmdvc["updated"],"ghlyqfjq": ghlyqfjq["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
