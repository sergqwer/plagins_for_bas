var quctemfy = GetInputConstructorValue("quctemfy", loader);
                 if(quctemfy["original"].length == 0)
                 {
                   Invalid("custom_button" + " is empty");
                   return;
                 }
var pqskrzyo = GetInputConstructorValue("pqskrzyo", loader);
                 if(pqskrzyo["original"].length == 0)
                 {
                   Invalid("max_time" + " is empty");
                   return;
                 }
var dacqorbk = GetInputConstructorValue("dacqorbk", loader);
                 if(dacqorbk["original"].length == 0)
                 {
                   Invalid("whait_element" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#MultibotSolver_AutoBypassCloudFlare_code").html())({"quctemfy": quctemfy["updated"],"pqskrzyo": pqskrzyo["updated"],"dacqorbk": dacqorbk["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
