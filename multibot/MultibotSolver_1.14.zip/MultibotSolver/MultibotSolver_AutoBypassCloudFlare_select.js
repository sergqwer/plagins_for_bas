var qzrblmhh = GetInputConstructorValue("qzrblmhh", loader);
                 if(qzrblmhh["original"].length == 0)
                 {
                   Invalid("custom_button" + " is empty");
                   return;
                 }
var poqpvlnj = GetInputConstructorValue("poqpvlnj", loader);
                 if(poqpvlnj["original"].length == 0)
                 {
                   Invalid("max_time" + " is empty");
                   return;
                 }
var kzizexls = GetInputConstructorValue("kzizexls", loader);
                 if(kzizexls["original"].length == 0)
                 {
                   Invalid("whait_element" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#MultibotSolver_AutoBypassCloudFlare_code").html())({"qzrblmhh": qzrblmhh["updated"],"poqpvlnj": poqpvlnj["updated"],"kzizexls": kzizexls["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
