_call_function(MultibotSolver_ForAutosolveReHCaptcha,{ "hCaptcha_USE": (<%= gggeyjzr %>),"ReCaptcha_USE": (<%= pcvnuqif %>) })!
