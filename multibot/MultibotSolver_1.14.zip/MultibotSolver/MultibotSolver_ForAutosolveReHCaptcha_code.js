_call_function(MultibotSolver_ForAutosolveReHCaptcha,{ "hCaptcha_USE": (<%= xdcqjpcs %>),"ReCaptcha_USE": (<%= qxyhnewx %>) })!
