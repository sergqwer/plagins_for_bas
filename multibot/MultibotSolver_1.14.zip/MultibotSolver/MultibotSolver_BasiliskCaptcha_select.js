var vloezqxc = GetInputConstructorValue("vloezqxc", loader);
                 if(vloezqxc["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var rcrmjkub = GetInputConstructorValue("rcrmjkub", loader);
                 if(rcrmjkub["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var ebquqrlv = GetInputConstructorValue("ebquqrlv", loader);
                 if(ebquqrlv["original"].length == 0)
                 {
                   Invalid("siteurl" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#MultibotSolver_BasiliskCaptcha_code").html())({"vloezqxc": vloezqxc["updated"],"rcrmjkub": rcrmjkub["updated"],"ebquqrlv": ebquqrlv["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
