var jqvuxtxy = GetInputConstructorValue("jqvuxtxy", loader);
                 if(jqvuxtxy["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var pmmdeiaj = GetInputConstructorValue("pmmdeiaj", loader);
                 if(pmmdeiaj["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var bermahal = GetInputConstructorValue("bermahal", loader);
                 if(bermahal["original"].length == 0)
                 {
                   Invalid("siteurl" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#MultibotSolver_BasiliskCaptcha_code").html())({"jqvuxtxy": jqvuxtxy["updated"],"pmmdeiaj": pmmdeiaj["updated"],"bermahal": bermahal["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
