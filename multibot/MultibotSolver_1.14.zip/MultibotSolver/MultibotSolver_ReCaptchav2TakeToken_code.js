_call_function(MultibotSolver_ReCaptchav2TakeToken,{ "APIKEY": (<%= qqneofxi %>),"site_url": (<%= mbnyrvlo %>),"sitekey": (<%= swhagzoc %>) })!
<%= variable %> = _result_function()
