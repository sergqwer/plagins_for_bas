_call_function(MultibotSolver_ReCaptchav2TakeToken,{ "APIKEY": (<%= vxzzmseh %>),"site_url": (<%= bfnnnzqx %>),"sitekey": (<%= apgdvrey %>) })!
<%= variable %> = _result_function()
