_call_function(MultibotSolver_AutoBypassCloudFlare,{ "custom_button": (<%= quctemfy %>),"max_time": (<%= pqskrzyo %>),"whait_element": (<%= dacqorbk %>) })!
