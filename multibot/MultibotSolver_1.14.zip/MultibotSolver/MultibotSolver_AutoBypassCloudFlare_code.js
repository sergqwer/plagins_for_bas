_call_function(MultibotSolver_AutoBypassCloudFlare,{ "custom_button": (<%= qzrblmhh %>),"max_time": (<%= poqpvlnj %>),"whait_element": (<%= kzizexls %>) })!
