_call_function(MultibotSolver_Faucetpay_PTC,{ "apikey": (<%= uwxosgti %>) })!
