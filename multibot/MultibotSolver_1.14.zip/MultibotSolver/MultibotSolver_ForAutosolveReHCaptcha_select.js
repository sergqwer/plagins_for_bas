var gggeyjzr = GetInputConstructorValue("gggeyjzr", loader);
                 if(gggeyjzr["original"].length == 0)
                 {
                   Invalid("hCaptcha_USE" + " is empty");
                   return;
                 }
var pcvnuqif = GetInputConstructorValue("pcvnuqif", loader);
                 if(pcvnuqif["original"].length == 0)
                 {
                   Invalid("ReCaptcha_USE" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#MultibotSolver_ForAutosolveReHCaptcha_code").html())({"gggeyjzr": gggeyjzr["updated"],"pcvnuqif": pcvnuqif["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
