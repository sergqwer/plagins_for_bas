var xdcqjpcs = GetInputConstructorValue("xdcqjpcs", loader);
                 if(xdcqjpcs["original"].length == 0)
                 {
                   Invalid("hCaptcha_USE" + " is empty");
                   return;
                 }
var qxyhnewx = GetInputConstructorValue("qxyhnewx", loader);
                 if(qxyhnewx["original"].length == 0)
                 {
                   Invalid("ReCaptcha_USE" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#MultibotSolver_ForAutosolveReHCaptcha_code").html())({"xdcqjpcs": xdcqjpcs["updated"],"qxyhnewx": qxyhnewx["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
