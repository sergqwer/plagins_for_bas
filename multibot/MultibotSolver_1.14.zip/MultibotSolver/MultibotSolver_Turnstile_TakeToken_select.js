var evjyltoy = GetInputConstructorValue("evjyltoy", loader);
                 if(evjyltoy["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var qanratrm = GetInputConstructorValue("qanratrm", loader);
                 if(qanratrm["original"].length == 0)
                 {
                   Invalid("site_url" + " is empty");
                   return;
                 }
var gotoxoqy = GetInputConstructorValue("gotoxoqy", loader);
                 if(gotoxoqy["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#MultibotSolver_Turnstile_TakeToken_code").html())({"evjyltoy": evjyltoy["updated"],"qanratrm": qanratrm["updated"],"gotoxoqy": gotoxoqy["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
