var hhoariwq = GetInputConstructorValue("hhoariwq", loader);
                 if(hhoariwq["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var ubmjguzm = GetInputConstructorValue("ubmjguzm", loader);
                 if(ubmjguzm["original"].length == 0)
                 {
                   Invalid("site_url" + " is empty");
                   return;
                 }
var cizvkyzy = GetInputConstructorValue("cizvkyzy", loader);
                 if(cizvkyzy["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#MultibotSolver_Turnstile_TakeToken_code").html())({"hhoariwq": hhoariwq["updated"],"ubmjguzm": ubmjguzm["updated"],"cizvkyzy": cizvkyzy["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
