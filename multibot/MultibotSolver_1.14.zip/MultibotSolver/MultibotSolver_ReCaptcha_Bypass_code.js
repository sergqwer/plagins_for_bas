_call_function(MultibotSolver_ReCaptcha_Bypass,{ "apikey": (<%= rhddvfiz %>),"index": (<%= lijxphmq %>) })!
