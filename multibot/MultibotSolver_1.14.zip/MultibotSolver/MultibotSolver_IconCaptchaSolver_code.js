_call_function(MultibotSolver_IconCaptchaSolver,{ "apikey": (<%= zywvdsou %>) })!
