var mpjfjokg = GetInputConstructorValue("mpjfjokg", loader);
                 if(mpjfjokg["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var ssqbxwgk = GetInputConstructorValue("ssqbxwgk", loader);
                 if(ssqbxwgk["original"].length == 0)
                 {
                   Invalid("site_url" + " is empty");
                   return;
                 }
var dtrfuhzq = GetInputConstructorValue("dtrfuhzq", loader);
                 if(dtrfuhzq["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#MultibotSolver_HcaptchaTakeToken_code").html())({"mpjfjokg": mpjfjokg["updated"],"ssqbxwgk": ssqbxwgk["updated"],"dtrfuhzq": dtrfuhzq["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
