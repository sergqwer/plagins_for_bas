var qcuicpbi = GetInputConstructorValue("qcuicpbi", loader);
                 if(qcuicpbi["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var ilukfabw = GetInputConstructorValue("ilukfabw", loader);
                 if(ilukfabw["original"].length == 0)
                 {
                   Invalid("mouse" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#MultibotSolver_AntiBot_code").html())({"qcuicpbi": qcuicpbi["updated"],"ilukfabw": ilukfabw["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
