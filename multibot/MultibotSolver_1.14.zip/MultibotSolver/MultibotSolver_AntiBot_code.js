_call_function(MultibotSolver_AntiBot,{ "apikey": (<%= qcuicpbi %>),"mouse": (<%= ilukfabw %>) })!
