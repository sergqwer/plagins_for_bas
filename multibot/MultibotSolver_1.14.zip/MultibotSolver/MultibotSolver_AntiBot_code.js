_call_function(MultibotSolver_AntiBot,{ "apikey": (<%= fljjrpvb %>),"mouse": (<%= wcigadck %>) })!
