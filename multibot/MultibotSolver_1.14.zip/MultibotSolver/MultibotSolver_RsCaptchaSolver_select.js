var uiwgpkic = GetInputConstructorValue("uiwgpkic", loader);
                 if(uiwgpkic["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#MultibotSolver_RsCaptchaSolver_code").html())({"uiwgpkic": uiwgpkic["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
