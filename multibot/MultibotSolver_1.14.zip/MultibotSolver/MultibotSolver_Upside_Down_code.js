_call_function(MultibotSolver_Upside_Down,{ "apikey": (<%= selaypac %>) })!
