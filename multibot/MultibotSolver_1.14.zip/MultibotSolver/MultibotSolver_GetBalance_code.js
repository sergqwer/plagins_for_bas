_call_function(MultibotSolver_GetBalance,{ "APIKEY": (<%= safsujbv %>) })!
<%= variable %> = _result_function()
