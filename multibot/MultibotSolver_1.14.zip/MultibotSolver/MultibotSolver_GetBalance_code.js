_call_function(MultibotSolver_GetBalance,{ "APIKEY": (<%= bbzhzado %>) })!
<%= variable %> = _result_function()
