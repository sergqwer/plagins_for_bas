_call_function(MultibotSolver_hCaptcha_Click,{ "apikey": (<%= autkhqas %>),"CaptchaSelector": (<%= agfdojca %>),"InvisibleCaptcha": (<%= ruovmdvc %>),"TrySolve": (<%= ghlyqfjq %>) })!
