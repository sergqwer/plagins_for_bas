_call_function(MultibotSolver_hCaptcha_Click,{ "apikey": (<%= azzyfwod %>),"CaptchaSelector": (<%= buoieqmw %>),"InvisibleCaptcha": (<%= ohyalwsf %>),"TrySolve": (<%= zxgxxwzx %>) })!
