var vbjrojsm = GetInputConstructorValue("vbjrojsm", loader);
                 if(vbjrojsm["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#MultibotSolver_Upside_Down_code").html())({"vbjrojsm": vbjrojsm["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
