_call_function(MultibotSolver_BasiliskCaptcha,{ "apikey": (<%= vloezqxc %>),"sitekey": (<%= rcrmjkub %>),"siteurl": (<%= ebquqrlv %>) })!
