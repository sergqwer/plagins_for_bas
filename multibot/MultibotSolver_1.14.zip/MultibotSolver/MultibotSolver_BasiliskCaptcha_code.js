_call_function(MultibotSolver_BasiliskCaptcha,{ "apikey": (<%= jqvuxtxy %>),"sitekey": (<%= pmmdeiaj %>),"siteurl": (<%= bermahal %>) })!
