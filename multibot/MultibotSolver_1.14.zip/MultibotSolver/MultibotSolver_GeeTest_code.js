_call_function(MultibotSolver_GeeTest,{ "APIKEY": (<%= yiddcnrl %>),"pixel_koef": (<%= nwmrfgpl %>) })!
