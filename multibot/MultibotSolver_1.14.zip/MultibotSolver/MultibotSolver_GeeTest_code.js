_call_function(MultibotSolver_GeeTest,{ "APIKEY": (<%= utwirigc %>),"pixel_koef": (<%= ttoxtvjm %>) })!
