var qqneofxi = GetInputConstructorValue("qqneofxi", loader);
                 if(qqneofxi["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var mbnyrvlo = GetInputConstructorValue("mbnyrvlo", loader);
                 if(mbnyrvlo["original"].length == 0)
                 {
                   Invalid("site_url" + " is empty");
                   return;
                 }
var swhagzoc = GetInputConstructorValue("swhagzoc", loader);
                 if(swhagzoc["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#MultibotSolver_ReCaptchav2TakeToken_code").html())({"qqneofxi": qqneofxi["updated"],"mbnyrvlo": mbnyrvlo["updated"],"swhagzoc": swhagzoc["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
