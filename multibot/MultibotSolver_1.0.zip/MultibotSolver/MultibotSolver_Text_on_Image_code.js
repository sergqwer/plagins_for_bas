_call_function(MultibotSolver_Text_on_Image,{ "APIKEY": (<%= aoyzxqgb %>),"IMAGE_IN_BASE64": (<%= rqjuoafd %>) })!
<%= variable %> = _result_function()
