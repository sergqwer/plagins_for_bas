var aoyzxqgb = GetInputConstructorValue("aoyzxqgb", loader);
                 if(aoyzxqgb["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var rqjuoafd = GetInputConstructorValue("rqjuoafd", loader);
                 if(rqjuoafd["original"].length == 0)
                 {
                   Invalid("IMAGE_IN_BASE64" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#MultibotSolver_Text_on_Image_code").html())({"aoyzxqgb": aoyzxqgb["updated"],"rqjuoafd": rqjuoafd["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
