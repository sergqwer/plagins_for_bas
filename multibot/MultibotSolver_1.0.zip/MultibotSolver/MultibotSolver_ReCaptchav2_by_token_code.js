_call_function(MultibotSolver_ReCaptchav2_by_token,{ "APIKEY": (<%= sxegkelh %>),"site_url": (<%= jeeeqqpk %>),"sitekey": (<%= wbnbfzft %>) })!
<%= variable %> = _result_function()
