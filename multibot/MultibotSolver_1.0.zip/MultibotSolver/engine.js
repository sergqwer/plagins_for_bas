function MultibotSolver_GeeTest()
   {
   
      
      
      VAR_APIKEY = _function_argument("APIKEY")
      

      
      
      VAR_PIXEL_KOEF = _function_argument("pixel_koef")
      

      
      
      var regexp_result = native("regexp", "first", JSON.stringify({text: VAR_APIKEY,regexp:"([0-9A-Za-z]\u007b20,40\u007d)"}))
      if(regexp_result.length == 0)
      regexp_result = []
      else
      regexp_result = JSON.parse(regexp_result)
      VAR_ALL_MATCH = regexp_result.pop()
      if(typeof(VAR_ALL_MATCH) == 'undefined' || !VAR_ALL_MATCH)
      VAR_ALL_MATCH = ""
      VAR_APIKEY = regexp_result[0]
      if(typeof(VAR_APIKEY) == 'undefined' || !VAR_APIKEY)
      VAR_APIKEY = ""
      if(regexp_result.length == 0)
      {
      VAR_APIKEY = VAR_ALL_MATCH
      }
      

      
      
      /*Browser*/
      ;_SELECTOR=" \u003eCSS\u003e .geetest_radar_tip_content";
      get_element_selector(_SELECTOR, false).nowait().exist()!
      VAR_IS_EXISTS = _result() == 1
      _if(VAR_IS_EXISTS, function(){
      get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
      VAR_IS_EXISTS = _result().indexOf("true")>=0
      })!
      

      
      
      _set_if_expression("W1tJU19FWElTVFNdXQ==");
      _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
      
         
         
         /*Browser*/
         _SELECTOR = " \u003eCSS\u003e .geetest_radar_tip_content";
         wait_element_visible(_SELECTOR)!
         _call(_random_point, {})!
         _if(_result().length > 0, function(){
         move( {} )!
         get_element_selector(_SELECTOR, false).clarify(X,Y)!
         _call(_clarify, {} )!
         mouse(X,Y)!
         })!
         

      })!
      

      
      
      /*Browser*/
      ;_SELECTOR=" \u003eCSS\u003e .geetest_btn_click";
      get_element_selector(_SELECTOR, false).nowait().exist()!
      VAR_IS_EXISTS = _result() == 1
      _if(VAR_IS_EXISTS, function(){
      get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
      VAR_IS_EXISTS = _result().indexOf("true")>=0
      })!
      

      
      
      _set_if_expression("W1tJU19FWElTVFNdXQ==");
      _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
      
         
         
         /*Browser*/
         _SELECTOR = " \u003eCSS\u003e .geetest_btn_click";
         wait_element_visible(_SELECTOR)!
         _call(_random_point, {})!
         _if(_result().length > 0, function(){
         move( {} )!
         get_element_selector(_SELECTOR, false).clarify(X,Y)!
         _call(_clarify, {} )!
         mouse(X,Y)!
         })!
         

      })!
      

      
      
      _call(function()
      {
      _on_fail(function(){
      VAR_LAST_ERROR = _result()
      VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
      VAR_WAS_ERROR = false
      _break(1,true)
      })
      CYCLES.Current().RemoveLabel("function")
      
         
         
         /*Browser*/
         waiter_timeout_next(25000)
         wait_async_load()!
         

      },null)!
      

      
      
      page().script2("[[TEMP_DATA]] = []\r\nfunction isVisible(sel){\r\n    var e = document.querySelector(sel);\r\n    return !! e && ( e.offsetWidth || e.offsetHeight || e.getClientRects().length );\r\n}\r\nfunction info_img(sel){\r\n    var info = false,\r\n    img = document.querySelector(sel),\r\n    style = img.currentStyle || window.getComputedStyle(img, false),\r\n    info = style.backgroundImage.slice(4, -1).replace(/\"/g, \"\");\r\n    return info;\r\n}\r\nvar background = false,\r\npiece = false\r\n\r\nif (isVisible('.geetest_canvas_bg') && isVisible('.geetest_canvas_slice')){\r\n    background = document.getElementsByClassName(\"geetest_canvas_bg geetest_absolute\")[0].toDataURL(\"image/png\");\r\n    piece = document.getElementsByClassName(\"geetest_canvas_slice geetest_absolute\")[0].toDataURL(\"image/png\");\r\n    if(background == piece){\r\n        background = false;\r\n        piece = false;\r\n    }\r\n}\r\nif (isVisible('.geetest_slice_bg')){\r\n    const toDataURL = url => fetch(url)\r\n        .then(response => response.blob())\r\n        .then(blob => new Promise((resolve, reject) => {\r\n            const reader = new FileReader()\r\n            reader.onloadend = () => resolve(reader.result)\r\n            reader.onerror = reject\r\n            reader.readAsDataURL(blob)\r\n        }));\r\n    background = await toDataURL(info_img('.geetest_bg'));\r\n    piece = await toDataURL(info_img('.geetest_slice_bg'));\r\n}\r\nif(background && piece){\r\n    let container = (document.querySelector(\"div.geetest_holder\")) ? document.querySelector(\"div.geetest_holder\").parentNode : document.querySelector(\"div.geetest_captcha\").parentNode;\r\n    container.id = \"geetest-container-\" + Date.now();\r\n    [[TEMP_DATA]] = [\r\n        background,\r\n        piece,\r\n        container.id,\r\n    ];\r\n}",JSON.stringify(_read_variables(["VAR_TEMP_DATA"])))!
      var _parse_result = JSON.parse(_result())
      _write_variables(JSON.parse(_parse_result.variables))
      if(!_parse_result.is_success)
      fail(_parse_result.error)
      

      
      
      VAR_LIST_LENGTH = (VAR_TEMP_DATA).length
      

      
      
      _set_if_expression("W1tMSVNUX0xFTkdUSF1dID09IDA=");
      _if(VAR_LIST_LENGTH == 0,function(){
      
         
         
         fail_user("Geetest не найден",false)
         

      })!
      

      
      
      _call(function()
      {
      _on_fail(function(){
      VAR_LAST_ERROR = _result()
      VAR_ERROR_ID = ScriptWorker.GetCurrentAction()
      VAR_WAS_ERROR = false
      _break(1,true)
      })
      CYCLES.Current().RemoveLabel("function")
      
         
         
         solver_properties_clear("capmonster")
         solver_property("capmonster","serverurl","http://api.multibot.in/")
         solver_property("capmonster","key",VAR_APIKEY)
         solver_property("capmonster","method","geetest")
         solver_property("capmonster","background",VAR_TEMP_DATA[0])
         solver_property("capmonster","piece",VAR_TEMP_DATA[1])
         solve_base64_no_fail("capmonster", "")!
         VAR_SAVED_CONTENT = parseInt(_result());
         

      },null)!
      

      
      
      _set_if_expression("W1tXQVNfRVJST1JdXQ==");
      _if(VAR_WAS_ERROR,function(){
      
         
         
         fail_user("Не удалось решить капчу",false)
         

      })!
      

      
      
      VAR_BUTTON_SLIDER = ""
      

      
      
      _do(function(){
      _set_action_info({ name: "For" });
      VAR_CYCLE_INDEX = _iterator() - 1 + parseInt(0)
      if(VAR_CYCLE_INDEX > parseInt(1))_break();
      
         
         
         /*Browser*/
         ;_SELECTOR=" \u003eCSS\u003e .geetest_btn";
         get_element_selector(_SELECTOR, false).nowait().exist()!
         VAR_IS_EXISTS = _result() == 1
         _if(VAR_IS_EXISTS, function(){
         get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
         VAR_IS_EXISTS = _result().indexOf("true")>=0
         })!
         

         
         
         _set_if_expression("W1tJU19FWElTVFNdXQ==");
         _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
         
            
            
            VAR_BUTTON_SLIDER = " \u003eCSS\u003e .geetest_btn"
            

            
            
            _break("function")
            

         })!
         

         
         
         /*Browser*/
         ;_SELECTOR=" \u003eCSS\u003e .geetest_slider_button";
         get_element_selector(_SELECTOR, false).nowait().exist()!
         VAR_IS_EXISTS = _result() == 1
         _if(VAR_IS_EXISTS, function(){
         get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
         VAR_IS_EXISTS = _result().indexOf("true")>=0
         })!
         

         
         
         _set_if_expression("W1tJU19FWElTVFNdXQ==");
         _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
         
            
            
            VAR_BUTTON_SLIDER = " \u003eCSS\u003e .geetest_slider_button"
            

            
            
            _break("function")
            

         })!
         

         
         
         /*Browser*/
         ;_SELECTOR=" \u003eCSS\u003e .geetest_arrow";
         get_element_selector(_SELECTOR, false).nowait().exist()!
         VAR_IS_EXISTS = _result() == 1
         _if(VAR_IS_EXISTS, function(){
         get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
         VAR_IS_EXISTS = _result().indexOf("true")>=0
         })!
         

         
         
         _set_if_expression("W1tJU19FWElTVFNdXQ==");
         _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
         
            
            
            VAR_BUTTON_SLIDER = " \u003eCSS\u003e .geetest_arrow"
            

            
            
            _break("function")
            

         })!
         

      })!
      

      
      
      _set_if_expression("W1tCVVRUT05fU0xJREVSXV0gPT0gIiI=");
      _if(VAR_BUTTON_SLIDER == "",function(){
      
         
         
         fail_user("Не нашел снопку слайдера",false)
         

      })!
      

      
      
      /*Browser*/
      _SELECTOR = VAR_BUTTON_SLIDER;
      wait_element_visible(_SELECTOR)!
      _call(_random_point, {})!
      _if(_result().length > 0, function(){
      move( {} )!
      get_element_selector(_SELECTOR, false).clarify(X,Y)!
      _call(_clarify, {} )!
      mouse_down(X,Y)!
      })!
      

      
      
      /*Browser*/
      _SELECTOR = VAR_BUTTON_SLIDER;
      wait_element(_SELECTOR)!
      get_element_selector(_SELECTOR, false).script("(function(){var rect = _BAS_HIDE(BrowserAutomationStudio_GetBoundingClientRect)(self);return (rect.left + positionx) + '|' + (rect.top + positiony) + '|' + (rect.right - rect.left) + '|' + (rect.bottom - rect.top)})();")!
      if(_result().length > 0)
      {
      var split = _result().split("|")
      VAR_X = parseInt(split[0])
      VAR_Y = parseInt(split[1])
      VAR_WIDTH = parseInt(split[2])
      VAR_HEIGHT = parseInt(split[3])
      }
      

      
      
      VAR_SAVED_CONTENT = VAR_SAVED_CONTENT + (VAR_WIDTH/2)
      

      
      
      VAR_RANDOM_SPEED = Math.floor(Math.random() * (parseInt(200) - parseInt(100) + 1)) + parseInt(100)
      

      
      
      VAR_RANDOM_PR = Math.floor(Math.random() * (parseInt(9) - parseInt(5) + 1)) + parseInt(5)
      

      
      
      /*Browser*/
      move(VAR_X+ (VAR_SAVED_CONTENT/1.2),VAR_Y,  {"speed": VAR_RANDOM_SPEED,"gravity": VAR_RANDOM_PR,"deviation": 4} )!
      

      
      
      VAR_RANDOM_SPEED = Math.floor(Math.random() * (parseInt(60) - parseInt(10) + 1)) + parseInt(10)
      

      
      
      VAR_RANDOM_PR = Math.floor(Math.random() * (parseInt(10) - parseInt(7) + 1)) + parseInt(7)
      

      
      
      /*Browser*/
      move(VAR_X+VAR_SAVED_CONTENT,VAR_Y,  {"speed": VAR_RANDOM_SPEED,"gravity": VAR_RANDOM_PR,"deviation": 0} )!
      

      
      
      VAR_RANDOM_Y = Math.floor(Math.random() * (parseInt(5) - parseInt(-5) + 1)) + parseInt(-5)
      

      
      
      /*Browser*/
      var move_settings =  {"speed": 50,"gravity": 9,"deviation": 0} ;
      move_settings["do_mouse_up"] = "true"
      move(VAR_X+VAR_SAVED_CONTENT,VAR_Y + VAR_RANDOM_Y, move_settings)!
      

   }
   

function MultibotSolver_ReCaptchav2_by_token()
   {
   
      
      
      VAR_APIKEY = _function_argument("APIKEY")
      

      
      
      VAR_SITE_URL = _function_argument("site_url")
      

      
      
      VAR_SITEKEY = _function_argument("sitekey")
      

      
      
      var regexp_result = native("regexp", "first", JSON.stringify({text: VAR_APIKEY,regexp:"([0-9A-Za-z]\u007b20,40\u007d)"}))
      if(regexp_result.length == 0)
      regexp_result = []
      else
      regexp_result = JSON.parse(regexp_result)
      VAR_ALL_MATCH = regexp_result.pop()
      if(typeof(VAR_ALL_MATCH) == 'undefined' || !VAR_ALL_MATCH)
      VAR_ALL_MATCH = ""
      VAR_APIKEY = regexp_result[0]
      if(typeof(VAR_APIKEY) == 'undefined' || !VAR_APIKEY)
      VAR_APIKEY = ""
      if(regexp_result.length == 0)
      {
      VAR_APIKEY = VAR_ALL_MATCH
      }
      

      
      
      solver_properties_clear("capmonster")
      solver_property("capmonster","serverurl","http://api.multibot.in/")
      solver_property("capmonster","key",VAR_APIKEY)
      solver_property("capmonster","method","userrecaptcha")
      solver_property("capmonster","pageurl",VAR_SITE_URL)
      solver_property("capmonster","sitekey",VAR_SITEKEY)
      solve_base64_no_fail("capmonster", "")!
      VAR_SAVED_CONTENT = _result();
      

      
      
      _function_return(VAR_SAVED_CONTENT)
      

   }
   

function MultibotSolver_Hcaptcha_by_token()
   {
   
      
      
      VAR_APIKEY = _function_argument("APIKEY")
      

      
      
      VAR_SITE_URL = _function_argument("site_url")
      

      
      
      VAR_SITEKEY = _function_argument("sitekey")
      

      
      
      var regexp_result = native("regexp", "first", JSON.stringify({text: VAR_APIKEY,regexp:"([0-9A-Za-z]\u007b20,40\u007d)"}))
      if(regexp_result.length == 0)
      regexp_result = []
      else
      regexp_result = JSON.parse(regexp_result)
      VAR_ALL_MATCH = regexp_result.pop()
      if(typeof(VAR_ALL_MATCH) == 'undefined' || !VAR_ALL_MATCH)
      VAR_ALL_MATCH = ""
      VAR_APIKEY = regexp_result[0]
      if(typeof(VAR_APIKEY) == 'undefined' || !VAR_APIKEY)
      VAR_APIKEY = ""
      if(regexp_result.length == 0)
      {
      VAR_APIKEY = VAR_ALL_MATCH
      }
      

      
      
      solver_properties_clear("capmonster")
      solver_property("capmonster","serverurl","http://api.multibot.in/")
      solver_property("capmonster","key",VAR_APIKEY)
      solver_property("capmonster","method","hcaptcha")
      solver_property("capmonster","pageurl",VAR_SITE_URL)
      solver_property("capmonster","sitekey",VAR_SITEKEY)
      solve_base64_no_fail("capmonster", "")!
      VAR_SAVED_CONTENT = _result();
      

      
      
      _function_return(VAR_SAVED_CONTENT)
      

   }
   

function MultibotSolver_Text_on_Image()
   {
   
      
      
      VAR_APIKEY = _function_argument("APIKEY")
      

      
      
      var regexp_result = native("regexp", "first", JSON.stringify({text: VAR_APIKEY,regexp:"([0-9A-Za-z]\u007b20,40\u007d)"}))
      if(regexp_result.length == 0)
      regexp_result = []
      else
      regexp_result = JSON.parse(regexp_result)
      VAR_ALL_MATCH = regexp_result.pop()
      if(typeof(VAR_ALL_MATCH) == 'undefined' || !VAR_ALL_MATCH)
      VAR_ALL_MATCH = ""
      VAR_APIKEY = regexp_result[0]
      if(typeof(VAR_APIKEY) == 'undefined' || !VAR_APIKEY)
      VAR_APIKEY = ""
      if(regexp_result.length == 0)
      {
      VAR_APIKEY = VAR_ALL_MATCH
      }
      

      
      
      VAR_IMAGE_IN_BASE64 = _function_argument("IMAGE_IN_BASE64")
      

      
      
      VAR_STRING_MATCHES = Boolean(native("regexp", "ismatch", JSON.stringify({text: VAR_IMAGE_IN_BASE64,regexp:"(base64\u005c,)"})) == "true")
      

      
      
      _set_if_expression("W1tTVFJJTkdfTUFUQ0hFU11d");
      _if(typeof(VAR_STRING_MATCHES) !== "undefined" ? (VAR_STRING_MATCHES) : undefined,function(){
      
         
         
         VAR_IMAGE_IN_BASE64 = VAR_IMAGE_IN_BASE64 + ".split(\u0022base64,\u0022)[1]"
         

      })!
      

      
      
      solver_properties_clear("capmonster")
      solver_property("capmonster","serverurl","http://api.multibot.in/")
      solver_property("capmonster","key",VAR_APIKEY)
      solver_property("capmonster","method","universal")
      solver_property("capmonster","body",VAR_IMAGE_IN_BASE64)
      solve_base64_no_fail("capmonster", "")!
      VAR_SAVED_CONTENT = _result();
      

      
      
      _function_return(VAR_SAVED_CONTENT)
      

   }
   

function MultibotSolver_GetBalance()
   {
   
      
      
      VAR_APIKEY = _function_argument("APIKEY")
      

      
      
      var regexp_result = native("regexp", "first", JSON.stringify({text: VAR_APIKEY,regexp:"([0-9A-Za-z]\u007b20,40\u007d)"}))
      if(regexp_result.length == 0)
      regexp_result = []
      else
      regexp_result = JSON.parse(regexp_result)
      VAR_ALL_MATCH = regexp_result.pop()
      if(typeof(VAR_ALL_MATCH) == 'undefined' || !VAR_ALL_MATCH)
      VAR_ALL_MATCH = ""
      VAR_APIKEY = regexp_result[0]
      if(typeof(VAR_APIKEY) == 'undefined' || !VAR_APIKEY)
      VAR_APIKEY = ""
      if(regexp_result.length == 0)
      {
      VAR_APIKEY = VAR_ALL_MATCH
      }
      

      
      
      _switch_http_client_internal();
      

      
      
      _switch_http_client_main()
      http_client_get2("https://multibot.in/res.php?action=userinfo\u0026key=" + VAR_APIKEY + "\u0026json=1",{method:("GET"),headers:("")})!
      

      
      
      _switch_http_client_main()
      VAR_SAVED_CONTENT = http_client_encoded_content("utf-8")
      

      
      
      var regexp_result = native("regexp", "first", JSON.stringify({text: VAR_SAVED_CONTENT,regexp:"[\u005cs\u005cS]*balance\u0022:\u0022(\u005cd+)\u0022\u005c\u007d*"}))
      if(regexp_result.length == 0)
      regexp_result = []
      else
      regexp_result = JSON.parse(regexp_result)
      VAR_ALL_MATCH = regexp_result.pop()
      if(typeof(VAR_ALL_MATCH) == 'undefined' || !VAR_ALL_MATCH)
      VAR_ALL_MATCH = ""
      VAR_BALANCE = regexp_result[0]
      if(typeof(VAR_BALANCE) == 'undefined' || !VAR_BALANCE)
      VAR_BALANCE = ""
      if(regexp_result.length == 0)
      {
      VAR_BALANCE = VAR_ALL_MATCH
      }
      

      
      
      _set_if_expression("W1tCQUxBTkNFXV0ubGVuZ3RoID09IDA=");
      _if(VAR_BALANCE.length == 0,function(){
      
         
         
         fail_user("Не получилось узнать длинну строки",false)
         

      })!
      

      
      
      VAR_BALANCE = parseInt(VAR_BALANCE)
      

      
      
      _function_return(VAR_BALANCE)
      

   }
   

function MultibotSolver_SolveMedia()
   {
   
      
      
      VAR_APIKEY = _function_argument("APIKEY")
      

      
      
      var regexp_result = native("regexp", "first", JSON.stringify({text: VAR_APIKEY,regexp:"([0-9A-Za-z]\u007b20,40\u007d)"}))
      if(regexp_result.length == 0)
      regexp_result = []
      else
      regexp_result = JSON.parse(regexp_result)
      VAR_ALL_MATCH = regexp_result.pop()
      if(typeof(VAR_ALL_MATCH) == 'undefined' || !VAR_ALL_MATCH)
      VAR_ALL_MATCH = ""
      VAR_APIKEY = regexp_result[0]
      if(typeof(VAR_APIKEY) == 'undefined' || !VAR_APIKEY)
      VAR_APIKEY = ""
      if(regexp_result.length == 0)
      {
      VAR_APIKEY = VAR_ALL_MATCH
      }
      

      
      
      /*Browser*/
      page().script("_BAS_HIDE(BrowserAutomationStudio_GetPageContent)()")!
      VAR_SAVED_PAGE_HTML = _result()
      

      
      
      html_parser_xpath_parse(VAR_SAVED_PAGE_HTML)
      VAR_XPATH_XML_LIST = html_parser_xpath_xml_list("//*[@src[contains(., \u0027https://api-secure.solvemedia.com/papi/challenge.script?\u0027)]]/@src")
      

      
      
      _set_if_expression("W1tYUEFUSF9YTUxfTElTVF1dLmxlbmd0aCA8PSAw");
      _if(VAR_XPATH_XML_LIST.length <= 0,function(){
      
         
         
         fail_user("Solve Media не найдено",false)
         

      })!
      

      
      
      VAR_CAPTCHA_ID = 0
      

      
      
      VAR_IS_FINDED = "false"
      

      
      
      VAR_SOLVE_MEDIA_CLASS = ""
      

      
      
      html_parser_xpath_parse(VAR_SAVED_PAGE_HTML)
      VAR_XPATH_XML_LIST_CLASS = html_parser_xpath_xml_list("//*[@src[contains(., \u0027https://api-secure.solvemedia.com/papi/challenge.script?\u0027)]]/../@class")
      

      
      
      _do_with_params({"foreach_data":(VAR_XPATH_XML_LIST_CLASS)},function(){
      _set_action_info({ name: "Foreach" });
      VAR_CYCLE_INDEX = _iterator() - 1
      if(VAR_CYCLE_INDEX > _cycle_param("foreach_data").length - 1)_break();
      VAR_FOREACH_DATA = _cycle_param("foreach_data")[VAR_CYCLE_INDEX]
      
         
         
         /*Browser*/
         ;_SELECTOR=" \u003eXPATH\u003e //*[@class=\u0027" + VAR_FOREACH_DATA + "\u0027]";
         get_element_selector(_SELECTOR, false).nowait().exist()!
         VAR_IS_EXISTS = _result() == 1
         _if(VAR_IS_EXISTS, function(){
         get_element_selector(_SELECTOR, false).nowait().script("_BAS_HIDE(BrowserAutomationStudio_IsVisible)(self)")!
         VAR_IS_EXISTS = _result().indexOf("true")>=0
         })!
         

         
         
         VAR_SOLVE_MEDIA_CLASS = VAR_FOREACH_DATA
         

         
         
         _set_if_expression("W1tJU19FWElTVFNdXQ==");
         _if(typeof(VAR_IS_EXISTS) !== "undefined" ? (VAR_IS_EXISTS) : undefined,function(){
         
            
            
            VAR_IS_FINDED = "true"
            

            
            
            VAR_CAPTCHA_ID = VAR_CYCLE_INDEX
            

            
            
            _break("function")
            

         })!
         

      })!
      

      
      
      _set_if_expression("W1tJU19GSU5ERURdXSA9PSAiZmFsc2Ui");
      _if(VAR_IS_FINDED == "false",function(){
      
         
         
         fail_user("Не найдена капча на странице",false)
         

      })!
      

      
      
      VAR_CAPTCHA_TOKEN = VAR_XPATH_XML_LIST[VAR_CAPTCHA_ID]
      

      
      
      var regexp_result = native("regexp", "first", JSON.stringify({text: VAR_CAPTCHA_TOKEN,regexp:"k=([A-Z0-9a-z]\u007b5,50\u007d)"}))
      if(regexp_result.length == 0)
      regexp_result = []
      else
      regexp_result = JSON.parse(regexp_result)
      VAR_1 = regexp_result.pop()
      if(typeof(VAR_1) == 'undefined' || !VAR_1)
      VAR_1 = ""
      VAR_CAPTCHA_TOKEN = regexp_result[0]
      if(typeof(VAR_CAPTCHA_TOKEN) == 'undefined' || !VAR_CAPTCHA_TOKEN)
      VAR_CAPTCHA_TOKEN = ""
      if(regexp_result.length == 0)
      {
      VAR_CAPTCHA_TOKEN = VAR_1
      }
      

      
      
      /*Browser*/
      url()!
      VAR_CURRENT_URL = _result()
      

      
      
      solver_properties_clear("capmonster")
      solver_property("capmonster","serverurl","http://api.multibot.in/")
      solver_property("capmonster","key",VAR_APIKEY)
      solver_property("capmonster","method","solvemedia")
      solver_property("capmonster","pageurl",VAR_CURRENT_URL)
      solver_property("capmonster","sitekey",VAR_CAPTCHA_TOKEN)
      solve_base64_no_fail("capmonster", "")!
      VAR_SAVED_CONTENT = _result();
      

      
      
      VAR_STRING_MATCHES = Boolean(native("regexp", "ismatch", JSON.stringify({text: VAR_SAVED_CONTENT,regexp:"(_)"})) == "true")
      

      
      
      _set_if_expression("W1tTVFJJTkdfTUFUQ0hFU11d");
      _if(typeof(VAR_STRING_MATCHES) !== "undefined" ? (VAR_STRING_MATCHES) : undefined,function(){
      
         
         
         fail_user("Ошибка при решении капчи: " + VAR_SAVED_CONTENT,false)
         

      })!
      

      
      
      VAR_STRING_MATCHES = Boolean(native("regexp", "ismatch", JSON.stringify({text: VAR_SAVED_CONTENT,regexp:"(\u005c#)"})) == "true")
      

      
      
      _set_if_expression("W1tTVFJJTkdfTUFUQ0hFU11dID09IGZhbHNl");
      _if(VAR_STRING_MATCHES == false,function(){
      
         
         
         fail_user("Ошибка при решении капчи: " + VAR_SAVED_CONTENT,false)
         

      })!
      

      
      
      /*Browser*/
      _SELECTOR = " \u003eXPATH\u003e //*[@class=\u0027" + VAR_SOLVE_MEDIA_CLASS + "\u0027]//input[@name=\u0022adcopy_challenge\u0022]";
      wait_element(_SELECTOR)!
      get_element_selector(_SELECTOR, false).set_attr("value", VAR_SAVED_CONTENT.split("#")[1])!
      

      
      
      /*Browser*/
      _SELECTOR = " \u003eXPATH\u003e //*[@class=\u0027" + VAR_SOLVE_MEDIA_CLASS + "\u0027]//input[@name=\u0022adcopy_response\u0022]";
      wait_element_visible(_SELECTOR)!
      _call(_random_point, {})!
      _if(_result().length > 0, function(){
      move( {} )!
      get_element_selector(_SELECTOR, false).clarify(X,Y)!
      _call(_clarify, {} )!
      mouse(X,Y)!
      _type(VAR_SAVED_CONTENT.split("#")[0],0)!
      })!
      

   }
   

function MultibotSolver_AntiBot()
   {
   
      
      
      VAR_APIKEY = _function_argument("apikey")
      

      
      
      VAR_MOUSE = _function_argument("mouse")
      

      
      
      var regexp_result = native("regexp", "first", JSON.stringify({text: VAR_APIKEY,regexp:"([0-9A-Za-z]\u007b20,40\u007d)"}))
      if(regexp_result.length == 0)
      regexp_result = []
      else
      regexp_result = JSON.parse(regexp_result)
      VAR_ALL_MATCH = regexp_result.pop()
      if(typeof(VAR_ALL_MATCH) == 'undefined' || !VAR_ALL_MATCH)
      VAR_ALL_MATCH = ""
      VAR_APIKEY = regexp_result[0]
      if(typeof(VAR_APIKEY) == 'undefined' || !VAR_APIKEY)
      VAR_APIKEY = ""
      if(regexp_result.length == 0)
      {
      VAR_APIKEY = VAR_ALL_MATCH
      }
      

      
      
      _do(function(){
      _set_action_info({ name: "While" });
      VAR_CYCLE_INDEX = _iterator() - 1
      BREAK_CONDITION = true;
      if(!BREAK_CONDITION)_break();
      
         
         
         _set_if_expression("W1tDWUNMRV9JTkRFWF1dID4gMTU=");
         _if(VAR_CYCLE_INDEX > 15,function(){
         
            
            
            fail_user("Не дождался antibot капчи",false)
            

         })!
         

         
         
         /*Browser*/
         page().script("_BAS_HIDE(BrowserAutomationStudio_GetPageContent)()")!
         VAR_SAVED_PAGE_HTML = _result()
         

         
         
         html_parser_xpath_parse(VAR_SAVED_PAGE_HTML)
         VAR_XPATH_XML_LIST = html_parser_xpath_xml_list("//img[contains(@src, \u0027data:image/png;base64\u0027)]/..")
         

         
         
         _set_if_expression("W1tYUEFUSF9YTUxfTElTVF1dLmxlbmd0aCA+IDM=");
         _if(VAR_XPATH_XML_LIST.length > 3,function(){
         
            
            
            _break("function")
            

         })!
         

         
         
         sleep(1000)!
         

      })!
      

      
      
      VAR_MAIN_FOTO = ""
      

      
      
      VAR_MAIN_ID = 0
      

      
      
      VAR_REL_ID = 0
      

      
      
      VAR_REL_LIST = []
      

      
      
      _do_with_params({"foreach_data":(VAR_XPATH_XML_LIST)},function(){
      _set_action_info({ name: "Foreach" });
      VAR_CYCLE_INDEX = _iterator() - 1
      if(VAR_CYCLE_INDEX > _cycle_param("foreach_data").length - 1)_break();
      VAR_FOREACH_DATA = _cycle_param("foreach_data")[VAR_CYCLE_INDEX]
      
         
         
         _set_if_expression("W1tNQUlOX0lEXV0gPT0gMA==");
         _if(VAR_MAIN_ID == 0,function(){
         
            
            
            html_parser_xpath_parse(VAR_FOREACH_DATA)
            VAR_XPATH_EXISTS = html_parser_xpath_exist("//*[@id=\u0027antibotlinks_reset\u0027 and not(@rel)]")
            

            
            
            _set_if_expression("W1tYUEFUSF9FWElTVFNdXQ==");
            _if(typeof(VAR_XPATH_EXISTS) !== "undefined" ? (VAR_XPATH_EXISTS) : undefined,function(){
            
               
               
               html_parser_xpath_parse(VAR_FOREACH_DATA)
               if((true) && !html_parser_xpath_exist("//@src"))
               fail("Can't resolve query " + "//@src");
               VAR_XPATH_XML = html_parser_xpath_xml("//@src")
               

               
               
               VAR_MAIN_FOTO = VAR_XPATH_XML.split("base64,")[1]
               

               
               
               VAR_MAIN_ID = 1
               

               
               
               _next("function")
               

            })!
            

         })!
         

         
         
         html_parser_xpath_parse(VAR_FOREACH_DATA)
         VAR_XPATH_EXISTS = html_parser_xpath_exist("//@rel")
         

         
         
         _set_if_expression("W1tYUEFUSF9FWElTVFNdXQ==");
         _if(typeof(VAR_XPATH_EXISTS) !== "undefined" ? (VAR_XPATH_EXISTS) : undefined,function(){
         
            
            
            html_parser_xpath_parse(VAR_FOREACH_DATA)
            if((true) && !html_parser_xpath_exist("//@src"))
            fail("Can't resolve query " + "//@src");
            VAR_XPATH_XML = html_parser_xpath_xml("//@src")
            

            
            
            html_parser_xpath_parse(VAR_FOREACH_DATA)
            if((true) && !html_parser_xpath_exist("//@rel"))
            fail("Can't resolve query " + "//@rel");
            VAR_XPATH_XML_REL = html_parser_xpath_xml("//@rel")
            

            
            
            VAR_REL_FOTO = VAR_XPATH_XML.split("base64,")[1]
            

            
            
            VAR_REL_LIST.push(VAR_XPATH_XML_REL + ";" + VAR_REL_FOTO)
            

            
            
            VAR_REL_ID = parseInt(VAR_REL_ID) + parseInt(1)
            

         })!
         

      })!
      

      
      
      _set_if_expression("W1tNQUlOX0lEXV0gPT0gMA==");
      _if(VAR_MAIN_ID == 0,function(){
      
         
         
         fail_user("Не найдено основное изображение капчи",false)
         

      })!
      

      
      
      _set_if_expression("W1tSRUxfSURdXSA8IDMgfHwgW1tSRUxfSURdXSA+IDQ=");
      _if(VAR_REL_ID < 3 || VAR_REL_ID > 4,function(){
      
         
         
         fail_user("Найдено (" + VAR_REL_ID + ") изображений antibot с значением rel",false)
         

      })!
      

      
      
      solver_properties_clear("capmonster")
      solver_property("capmonster","serverurl","http://api.multibot.in/")
      solver_property("capmonster","key",VAR_APIKEY)
      solver_property("capmonster","method","antibot")
      solver_property("capmonster","main",VAR_MAIN_FOTO)
      VAR_REL_LIST.forEach(function(item) {
      VAR_REL_ID = item.split(";")[0]
      VAR_BASE64 = item.split(";")[1]
      solver_property("capmonster",VAR_REL_ID,VAR_BASE64)
      });
      solve_base64_no_fail("capmonster", "")!
      VAR_SAVED_CONTENT = _result();
      

      
      
      VAR_STRING_MATCHES = Boolean(native("regexp", "ismatch", JSON.stringify({text: VAR_SAVED_CONTENT,regexp:"(_)"})) == "true")
      

      
      
      _set_if_expression("W1tTVFJJTkdfTUFUQ0hFU11d");
      _if(typeof(VAR_STRING_MATCHES) !== "undefined" ? (VAR_STRING_MATCHES) : undefined,function(){
      
         
         
         fail_user("Ошибка при решении капчи: " + VAR_SAVED_CONTENT,false)
         

      })!
      

      
      
      VAR_SCAN_RESULT_LIST = native("regexp", "scan", JSON.stringify({text: VAR_SAVED_CONTENT,regexp:"\u005cd+"}))
      if(VAR_SCAN_RESULT_LIST.length == 0)
      VAR_SCAN_RESULT_LIST = []
      else
      VAR_SCAN_RESULT_LIST = JSON.parse(VAR_SCAN_RESULT_LIST)
      

      
      
      _set_if_expression("W1tTQ0FOX1JFU1VMVF9MSVNUXV0ubGVuZ3RoICE9IFtbUkVMX0xJU1RdXS5sZW5ndGg=");
      _if(VAR_SCAN_RESULT_LIST.length != VAR_REL_LIST.length,function(){
      
         
         
         fail_user("Капча решена сервисом не верно: " + VAR_SAVED_CONTENT,false)
         

      })!
      

      
      
      _do_with_params({"foreach_data":(VAR_SCAN_RESULT_LIST)},function(){
      _set_action_info({ name: "Foreach" });
      VAR_CYCLE_INDEX = _iterator() - 1
      if(VAR_CYCLE_INDEX > _cycle_param("foreach_data").length - 1)_break();
      VAR_FOREACH_DATA = _cycle_param("foreach_data")[VAR_CYCLE_INDEX]
      
         
         
         _cycle_params().if_else = VAR_MOUSE == "true";
         _set_if_expression("W1tNT1VTRV1dID09ICJ0cnVlIg==");
         _if(_cycle_params().if_else,function(){
         
            
            
            /*Browser*/
            _SELECTOR = " \u003eXPATH\u003e //*[@rel=" + VAR_FOREACH_DATA + "]";
            wait_element_visible(_SELECTOR)!
            _call(_random_point, {})!
            _if(_result().length > 0, function(){
            move( {} )!
            get_element_selector(_SELECTOR, false).clarify(X,Y)!
            _call(_clarify, {} )!
            mouse(X,Y)!
            })!
            

         })!
         

         
         
         _if(!_cycle_params().if_else,function(){
         
            
            
            /*Browser*/
            _SELECTOR = " \u003eXPATH\u003e //*[@rel=" + VAR_FOREACH_DATA + "]";
            wait_element_visible(_SELECTOR)!
            _call(_random_point, {})!
            _if(_result().length > 0, function(){
            X = parseInt(_result().split(",")[0])
            Y = parseInt(_result().split(",")[1])
            mouse(X,Y)!
            })!
            

         })!
         delete _cycle_params().if_else;
         

      })!
      

   }
   

