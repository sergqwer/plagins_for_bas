_call_function(MultibotSolver_GetBalance,{ "APIKEY": (<%= jnykmcwz %>) })!
<%= variable %> = _result_function()
