_call_function(MultibotSolver_GeeTest,{ "APIKEY": (<%= mwikjity %>),"pixel_koef": (<%= bflgxrhm %>) })!
