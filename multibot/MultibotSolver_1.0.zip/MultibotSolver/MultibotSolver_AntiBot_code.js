_call_function(MultibotSolver_AntiBot,{ "apikey": (<%= pygcjlqg %>),"mouse": (<%= mikvqgjk %>) })!
