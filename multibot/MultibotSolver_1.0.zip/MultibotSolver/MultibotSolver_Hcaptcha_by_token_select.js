var txmqezpt = GetInputConstructorValue("txmqezpt", loader);
                 if(txmqezpt["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var khtghqkc = GetInputConstructorValue("khtghqkc", loader);
                 if(khtghqkc["original"].length == 0)
                 {
                   Invalid("site_url" + " is empty");
                   return;
                 }
var slijuuip = GetInputConstructorValue("slijuuip", loader);
                 if(slijuuip["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#MultibotSolver_Hcaptcha_by_token_code").html())({"txmqezpt": txmqezpt["updated"],"khtghqkc": khtghqkc["updated"],"slijuuip": slijuuip["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
