var sxegkelh = GetInputConstructorValue("sxegkelh", loader);
                 if(sxegkelh["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var jeeeqqpk = GetInputConstructorValue("jeeeqqpk", loader);
                 if(jeeeqqpk["original"].length == 0)
                 {
                   Invalid("site_url" + " is empty");
                   return;
                 }
var wbnbfzft = GetInputConstructorValue("wbnbfzft", loader);
                 if(wbnbfzft["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#MultibotSolver_ReCaptchav2_by_token_code").html())({"sxegkelh": sxegkelh["updated"],"jeeeqqpk": jeeeqqpk["updated"],"wbnbfzft": wbnbfzft["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
