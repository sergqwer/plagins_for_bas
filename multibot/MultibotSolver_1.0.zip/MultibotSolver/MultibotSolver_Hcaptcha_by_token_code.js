_call_function(MultibotSolver_Hcaptcha_by_token,{ "APIKEY": (<%= txmqezpt %>),"site_url": (<%= khtghqkc %>),"sitekey": (<%= slijuuip %>) })!
<%= variable %> = _result_function()
