var vvebvhiz = GetInputConstructorValue("vvebvhiz", loader);
                 if(vvebvhiz["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var czylalgc = GetInputConstructorValue("czylalgc", loader);
                 if(czylalgc["original"].length == 0)
                 {
                   Invalid("mouse" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#OLD_MultibotSolver_AntiBot_code").html())({"vvebvhiz": vvebvhiz["updated"],"czylalgc": czylalgc["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
