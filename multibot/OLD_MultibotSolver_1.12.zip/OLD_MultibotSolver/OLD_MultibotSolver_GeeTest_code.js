_call_function(OLD_MultibotSolver_GeeTest,{ "APIKEY": (<%= jjwbvgmd %>),"pixel_koef": (<%= zlqrwsxs %>) })!
