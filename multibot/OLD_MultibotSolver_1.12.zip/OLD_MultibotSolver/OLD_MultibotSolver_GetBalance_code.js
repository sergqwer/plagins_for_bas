_call_function(OLD_MultibotSolver_GetBalance,{ "APIKEY": (<%= ahjgycwp %>) })!
<%= variable %> = _result_function()
