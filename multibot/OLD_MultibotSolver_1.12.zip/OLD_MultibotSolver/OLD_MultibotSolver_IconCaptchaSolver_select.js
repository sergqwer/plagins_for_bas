var dwlpxuda = GetInputConstructorValue("dwlpxuda", loader);
                 if(dwlpxuda["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#OLD_MultibotSolver_IconCaptchaSolver_code").html())({"dwlpxuda": dwlpxuda["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
