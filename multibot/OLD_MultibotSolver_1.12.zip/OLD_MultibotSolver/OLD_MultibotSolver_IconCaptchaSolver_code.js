_call_function(OLD_MultibotSolver_IconCaptchaSolver,{ "apikey": (<%= dwlpxuda %>) })!
