_call_function(OLD_MultibotSolver_ReCaptchav2TakeToken,{ "APIKEY": (<%= jgnlhdvo %>),"site_url": (<%= giwnswes %>),"sitekey": (<%= kkuctxzd %>) })!
<%= variable %> = _result_function()
