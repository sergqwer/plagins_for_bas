_call_function(OLD_MultibotSolver_RsCaptchaSolver,{ "apikey": (<%= hifybljw %>) })!
