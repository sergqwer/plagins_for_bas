var suiliatd = GetInputConstructorValue("suiliatd", loader);
                 if(suiliatd["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var arkwains = GetInputConstructorValue("arkwains", loader);
                 if(arkwains["original"].length == 0)
                 {
                   Invalid("site_url" + " is empty");
                   return;
                 }
var ukntznkt = GetInputConstructorValue("ukntznkt", loader);
                 if(ukntznkt["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#OLD_MultibotSolver_HcaptchaTakeToken_code").html())({"suiliatd": suiliatd["updated"],"arkwains": arkwains["updated"],"ukntznkt": ukntznkt["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
