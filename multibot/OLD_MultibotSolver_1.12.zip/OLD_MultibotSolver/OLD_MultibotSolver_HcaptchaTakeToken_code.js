_call_function(OLD_MultibotSolver_HcaptchaTakeToken,{ "APIKEY": (<%= suiliatd %>),"site_url": (<%= arkwains %>),"sitekey": (<%= ukntznkt %>) })!
<%= variable %> = _result_function()
