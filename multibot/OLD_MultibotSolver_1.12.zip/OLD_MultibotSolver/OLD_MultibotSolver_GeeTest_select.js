var jjwbvgmd = GetInputConstructorValue("jjwbvgmd", loader);
                 if(jjwbvgmd["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var zlqrwsxs = GetInputConstructorValue("zlqrwsxs", loader);
                 if(zlqrwsxs["original"].length == 0)
                 {
                   Invalid("pixel_koef" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#OLD_MultibotSolver_GeeTest_code").html())({"jjwbvgmd": jjwbvgmd["updated"],"zlqrwsxs": zlqrwsxs["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
