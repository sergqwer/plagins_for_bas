_call_function(OLD_MultibotSolver_AutoBypassCloudFlare,{ "custom_button": (<%= hnliigra %>),"max_time": (<%= mvfjcdnj %>),"whait_element": (<%= enlotlzm %>) })!
