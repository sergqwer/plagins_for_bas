var hnliigra = GetInputConstructorValue("hnliigra", loader);
                 if(hnliigra["original"].length == 0)
                 {
                   Invalid("custom_button" + " is empty");
                   return;
                 }
var mvfjcdnj = GetInputConstructorValue("mvfjcdnj", loader);
                 if(mvfjcdnj["original"].length == 0)
                 {
                   Invalid("max_time" + " is empty");
                   return;
                 }
var enlotlzm = GetInputConstructorValue("enlotlzm", loader);
                 if(enlotlzm["original"].length == 0)
                 {
                   Invalid("whait_element" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#OLD_MultibotSolver_AutoBypassCloudFlare_code").html())({"hnliigra": hnliigra["updated"],"mvfjcdnj": mvfjcdnj["updated"],"enlotlzm": enlotlzm["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
