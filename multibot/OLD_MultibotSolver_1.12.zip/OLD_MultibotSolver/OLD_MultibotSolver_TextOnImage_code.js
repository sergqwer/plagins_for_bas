_call_function(OLD_MultibotSolver_TextOnImage,{ "APIKEY": (<%= jhevexbh %>),"IMAGE_IN_BASE64": (<%= cviyjkhq %>) })!
<%= variable %> = _result_function()
