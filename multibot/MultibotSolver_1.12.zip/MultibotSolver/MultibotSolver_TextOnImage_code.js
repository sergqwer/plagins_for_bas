_call_function(MultibotSolver_TextOnImage,{ "APIKEY": (<%= daypolkb %>),"IMAGE_IN_BASE64": (<%= tkbrgetv %>) })!
<%= variable %> = _result_function()
