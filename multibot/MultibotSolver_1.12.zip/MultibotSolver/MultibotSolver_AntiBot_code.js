_call_function(MultibotSolver_AntiBot,{ "apikey": (<%= hgsmgfkv %>),"mouse": (<%= gmhjenmn %>) })!
