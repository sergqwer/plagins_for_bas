_call_function(MultibotSolver_GeeTest,{ "APIKEY": (<%= wpijgovj %>),"pixel_koef": (<%= nmnzxkcg %>) })!
