_call_function(MultibotSolver_ReCaptchav2TakeToken,{ "APIKEY": (<%= rlzbnxqs %>),"site_url": (<%= rdegddmg %>),"sitekey": (<%= lnzffgni %>) })!
<%= variable %> = _result_function()
