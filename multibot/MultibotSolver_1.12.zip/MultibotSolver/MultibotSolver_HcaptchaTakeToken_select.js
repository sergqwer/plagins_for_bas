var mxzvbdqh = GetInputConstructorValue("mxzvbdqh", loader);
                 if(mxzvbdqh["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var rgrxvumd = GetInputConstructorValue("rgrxvumd", loader);
                 if(rgrxvumd["original"].length == 0)
                 {
                   Invalid("site_url" + " is empty");
                   return;
                 }
var jtkogizo = GetInputConstructorValue("jtkogizo", loader);
                 if(jtkogizo["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#MultibotSolver_HcaptchaTakeToken_code").html())({"mxzvbdqh": mxzvbdqh["updated"],"rgrxvumd": rgrxvumd["updated"],"jtkogizo": jtkogizo["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
