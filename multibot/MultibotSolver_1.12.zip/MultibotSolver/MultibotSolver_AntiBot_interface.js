<div class="container-fluid">
<%= _.template($('#input_constructor').html())({id:"hgsmgfkv", description:"apikey", default_selector: "string", disable_expression:true, disable_int:true, value_string: "", help: {description: "apikey с сервиса https://multibot.in/"} }) %>
<%= _.template($('#input_constructor').html())({id:"gmhjenmn", description:"mouse", default_selector: "string", disable_expression:true, disable_int:true, value_string: "true", help: {description: "Включить емуляцию движения миши: true - включить, false - отключить"} }) %>
</div>
<div class="tooltipinternal">
<div class="tr tooltip-paragraph-first-fold">Эта функция решает капчу антибот через сервис решения капчи https://multibot.in/</div>
<div class="tr tooltip-paragraph-last-fold">Для работы достаточно вызвать ее не странице с капчей</div>
</div>
<%= _.template($('#back').html())({action:"executeandadd", visible:true}) %>
