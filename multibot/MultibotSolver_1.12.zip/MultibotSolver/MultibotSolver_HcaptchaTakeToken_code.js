_call_function(MultibotSolver_HcaptchaTakeToken,{ "APIKEY": (<%= mxzvbdqh %>),"site_url": (<%= rgrxvumd %>),"sitekey": (<%= jtkogizo %>) })!
<%= variable %> = _result_function()
