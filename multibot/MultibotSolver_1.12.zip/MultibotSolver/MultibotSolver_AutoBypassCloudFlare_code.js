_call_function(MultibotSolver_AutoBypassCloudFlare,{ "custom_button": (<%= lqwnkztl %>),"max_time": (<%= yuoatwzt %>),"whait_element": (<%= mwumkuka %>) })!
