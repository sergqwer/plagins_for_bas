_call_function(MultibotSolver_GetBalance,{ "APIKEY": (<%= imtjeglc %>) })!
<%= variable %> = _result_function()
