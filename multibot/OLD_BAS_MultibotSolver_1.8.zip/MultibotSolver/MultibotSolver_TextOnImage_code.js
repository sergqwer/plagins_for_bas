_call_function(MultibotSolver_TextOnImage,{ "APIKEY": (<%= pvusysud %>),"IMAGE_IN_BASE64": (<%= aztvisjd %>) })!
<%= variable %> = _result_function()
