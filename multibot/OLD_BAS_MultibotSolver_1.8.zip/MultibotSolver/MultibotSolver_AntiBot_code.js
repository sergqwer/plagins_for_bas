_call_function(MultibotSolver_AntiBot,{ "apikey": (<%= sjofworm %>),"mouse": (<%= pksipzxk %>) })!
