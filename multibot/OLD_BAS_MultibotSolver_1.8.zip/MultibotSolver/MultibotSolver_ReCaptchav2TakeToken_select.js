var wxghztvn = GetInputConstructorValue("wxghztvn", loader);
                 if(wxghztvn["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var pobndwmu = GetInputConstructorValue("pobndwmu", loader);
                 if(pobndwmu["original"].length == 0)
                 {
                   Invalid("site_url" + " is empty");
                   return;
                 }
var brkredfd = GetInputConstructorValue("brkredfd", loader);
                 if(brkredfd["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#MultibotSolver_ReCaptchav2TakeToken_code").html())({"wxghztvn": wxghztvn["updated"],"pobndwmu": pobndwmu["updated"],"brkredfd": brkredfd["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
