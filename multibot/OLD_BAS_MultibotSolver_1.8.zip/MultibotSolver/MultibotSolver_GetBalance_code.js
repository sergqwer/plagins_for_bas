_call_function(MultibotSolver_GetBalance,{ "APIKEY": (<%= kqazmbyo %>) })!
<%= variable %> = _result_function()
