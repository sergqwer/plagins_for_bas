var mkxblmew = GetInputConstructorValue("mkxblmew", loader);
                 if(mkxblmew["original"].length == 0)
                 {
                   Invalid("AutoSettings" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#MultibotSolver_ForAutosolveReHCaptcha_code").html())({"mkxblmew": mkxblmew["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
