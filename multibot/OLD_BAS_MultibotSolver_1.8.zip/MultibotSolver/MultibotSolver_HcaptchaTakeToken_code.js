_call_function(MultibotSolver_HcaptchaTakeToken,{ "APIKEY": (<%= jjqjjebr %>),"site_url": (<%= fuiohgvo %>),"sitekey": (<%= rxdifbty %>) })!
<%= variable %> = _result_function()
