_call_function(MultibotSolver_HcaptchaAutoSolver,{ "apikey": (<%= seleeyzs %>) })!
