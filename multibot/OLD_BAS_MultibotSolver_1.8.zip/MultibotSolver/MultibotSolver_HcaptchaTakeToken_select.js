var jjqjjebr = GetInputConstructorValue("jjqjjebr", loader);
                 if(jjqjjebr["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var fuiohgvo = GetInputConstructorValue("fuiohgvo", loader);
                 if(fuiohgvo["original"].length == 0)
                 {
                   Invalid("site_url" + " is empty");
                   return;
                 }
var rxdifbty = GetInputConstructorValue("rxdifbty", loader);
                 if(rxdifbty["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#MultibotSolver_HcaptchaTakeToken_code").html())({"jjqjjebr": jjqjjebr["updated"],"fuiohgvo": fuiohgvo["updated"],"rxdifbty": rxdifbty["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
