_call_function(MultibotSolver_GeeTest,{ "APIKEY": (<%= sewoofwf %>),"pixel_koef": (<%= oglxgvbl %>) })!
