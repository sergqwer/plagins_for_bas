_call_function(MultibotSolver_ReCaptchav2TakeToken,{ "APIKEY": (<%= wxghztvn %>),"site_url": (<%= pobndwmu %>),"sitekey": (<%= brkredfd %>) })!
<%= variable %> = _result_function()
