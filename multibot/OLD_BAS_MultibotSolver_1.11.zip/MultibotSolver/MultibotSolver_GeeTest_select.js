var folrzhfc = GetInputConstructorValue("folrzhfc", loader);
                 if(folrzhfc["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var fxcscetm = GetInputConstructorValue("fxcscetm", loader);
                 if(fxcscetm["original"].length == 0)
                 {
                   Invalid("pixel_koef" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#MultibotSolver_GeeTest_code").html())({"folrzhfc": folrzhfc["updated"],"fxcscetm": fxcscetm["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
