_call_function(MultibotSolver_AntiBot,{ "apikey": (<%= cbiszbmt %>),"mouse": (<%= ebolldgh %>) })!
