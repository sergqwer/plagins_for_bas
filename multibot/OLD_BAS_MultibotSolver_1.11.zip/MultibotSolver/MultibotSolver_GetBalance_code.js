_call_function(MultibotSolver_GetBalance,{ "APIKEY": (<%= rojoboad %>) })!
<%= variable %> = _result_function()
