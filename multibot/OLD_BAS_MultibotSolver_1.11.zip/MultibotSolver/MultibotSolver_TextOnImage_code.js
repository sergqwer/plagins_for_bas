_call_function(MultibotSolver_TextOnImage,{ "APIKEY": (<%= autsenfm %>),"IMAGE_IN_BASE64": (<%= mhcajdka %>) })!
<%= variable %> = _result_function()
