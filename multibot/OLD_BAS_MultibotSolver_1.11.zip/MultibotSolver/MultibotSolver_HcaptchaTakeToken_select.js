var ebgqjyoe = GetInputConstructorValue("ebgqjyoe", loader);
                 if(ebgqjyoe["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var rsgaufio = GetInputConstructorValue("rsgaufio", loader);
                 if(rsgaufio["original"].length == 0)
                 {
                   Invalid("site_url" + " is empty");
                   return;
                 }
var xcagsfvf = GetInputConstructorValue("xcagsfvf", loader);
                 if(xcagsfvf["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#MultibotSolver_HcaptchaTakeToken_code").html())({"ebgqjyoe": ebgqjyoe["updated"],"rsgaufio": rsgaufio["updated"],"xcagsfvf": xcagsfvf["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
