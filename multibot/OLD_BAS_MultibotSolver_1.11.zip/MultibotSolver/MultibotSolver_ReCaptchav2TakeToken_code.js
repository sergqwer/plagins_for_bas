_call_function(MultibotSolver_ReCaptchav2TakeToken,{ "APIKEY": (<%= pvmitapk %>),"site_url": (<%= axkhqyyq %>),"sitekey": (<%= mfnzubxj %>) })!
<%= variable %> = _result_function()
