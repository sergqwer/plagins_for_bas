_call_function(MultibotSolver_RsCaptchaSolver,{ "apikey": (<%= rkqjufdw %>) })!
