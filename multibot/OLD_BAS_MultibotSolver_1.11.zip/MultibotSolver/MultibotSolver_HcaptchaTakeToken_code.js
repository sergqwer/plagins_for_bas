_call_function(MultibotSolver_HcaptchaTakeToken,{ "APIKEY": (<%= ebgqjyoe %>),"site_url": (<%= rsgaufio %>),"sitekey": (<%= xcagsfvf %>) })!
<%= variable %> = _result_function()
