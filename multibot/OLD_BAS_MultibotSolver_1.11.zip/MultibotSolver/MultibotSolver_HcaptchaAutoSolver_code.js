_call_function(MultibotSolver_HcaptchaAutoSolver,{ "apikey": (<%= hydyywuc %>) })!
