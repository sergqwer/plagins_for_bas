_call_function(MultibotSolver_GeeTest,{ "APIKEY": (<%= folrzhfc %>),"pixel_koef": (<%= fxcscetm %>) })!
