var autsenfm = GetInputConstructorValue("autsenfm", loader);
                 if(autsenfm["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var mhcajdka = GetInputConstructorValue("mhcajdka", loader);
                 if(mhcajdka["original"].length == 0)
                 {
                   Invalid("IMAGE_IN_BASE64" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#MultibotSolver_TextOnImage_code").html())({"autsenfm": autsenfm["updated"],"mhcajdka": mhcajdka["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
