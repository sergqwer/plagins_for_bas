var uvwofiwu = GetInputConstructorValue("uvwofiwu", loader);
                 if(uvwofiwu["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var ebngcjqp = GetInputConstructorValue("ebngcjqp", loader);
                 if(ebngcjqp["original"].length == 0)
                 {
                   Invalid("mouse" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#MultibotSolver_AntiBot_code").html())({"uvwofiwu": uvwofiwu["updated"],"ebngcjqp": ebngcjqp["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
