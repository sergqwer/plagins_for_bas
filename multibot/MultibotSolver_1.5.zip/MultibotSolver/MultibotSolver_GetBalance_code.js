_call_function(MultibotSolver_GetBalance,{ "APIKEY": (<%= cyllezox %>) })!
<%= variable %> = _result_function()
