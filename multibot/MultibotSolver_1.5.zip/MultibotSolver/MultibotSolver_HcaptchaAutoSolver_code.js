_call_function(MultibotSolver_HcaptchaAutoSolver,{ "apikey": (<%= qasseeph %>) })!
