_call_function(MultibotSolver_GeeTest,{ "APIKEY": (<%= icegwhns %>),"pixel_koef": (<%= pukptkms %>) })!
