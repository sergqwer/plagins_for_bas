var icegwhns = GetInputConstructorValue("icegwhns", loader);
                 if(icegwhns["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var pukptkms = GetInputConstructorValue("pukptkms", loader);
                 if(pukptkms["original"].length == 0)
                 {
                   Invalid("pixel_koef" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#MultibotSolver_GeeTest_code").html())({"icegwhns": icegwhns["updated"],"pukptkms": pukptkms["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
