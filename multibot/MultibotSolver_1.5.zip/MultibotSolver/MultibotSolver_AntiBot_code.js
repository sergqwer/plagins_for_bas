_call_function(MultibotSolver_AntiBot,{ "apikey": (<%= uvwofiwu %>),"mouse": (<%= ebngcjqp %>) })!
