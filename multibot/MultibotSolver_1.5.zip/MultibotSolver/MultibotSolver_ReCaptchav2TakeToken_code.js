_call_function(MultibotSolver_ReCaptchav2TakeToken,{ "APIKEY": (<%= ijrqzrpr %>),"site_url": (<%= ojxzhkfh %>),"sitekey": (<%= ibiqbslc %>) })!
<%= variable %> = _result_function()
