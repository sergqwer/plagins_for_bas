_call_function(MultibotSolver_TextOnImage,{ "APIKEY": (<%= vwtfvfcu %>),"IMAGE_IN_BASE64": (<%= itwggoco %>) })!
<%= variable %> = _result_function()
