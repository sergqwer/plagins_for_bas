_call_function(MultibotSolver_HcaptchaTakeToken,{ "APIKEY": (<%= zoainqof %>),"site_url": (<%= uomwldag %>),"sitekey": (<%= xwtpzbee %>) })!
<%= variable %> = _result_function()
