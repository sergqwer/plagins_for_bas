_call_function(MultibotSolver_GeeTest,{ "APIKEY": (<%= ezhleuqi %>),"pixel_koef": (<%= zvxmovzx %>) })!
