_call_function(MultibotSolver_AntiBot,{ "apikey": (<%= qpwkjdzi %>),"mouse": (<%= gpwqshzv %>) })!
