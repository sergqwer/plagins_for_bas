_call_function(MultibotSolver_TextOnImage,{ "APIKEY": (<%= anzlqpop %>),"IMAGE_IN_BASE64": (<%= yqcgqony %>) })!
<%= variable %> = _result_function()
