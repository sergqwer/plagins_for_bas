var ajrgxfzs = GetInputConstructorValue("ajrgxfzs", loader);
                 if(ajrgxfzs["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var ymvweukw = GetInputConstructorValue("ymvweukw", loader);
                 if(ymvweukw["original"].length == 0)
                 {
                   Invalid("site_url" + " is empty");
                   return;
                 }
var nsnvegie = GetInputConstructorValue("nsnvegie", loader);
                 if(nsnvegie["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#MultibotSolver_ReCaptchav2TakeToken_code").html())({"ajrgxfzs": ajrgxfzs["updated"],"ymvweukw": ymvweukw["updated"],"nsnvegie": nsnvegie["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
