<div class="container-fluid">
<%= _.template($('#input_constructor').html())({id:"vwpqvzye", description:"APIKEY", default_selector: "string", disable_expression:true, disable_int:true, value_string: "", help: {description: "apikey с сервиса https://multibot.in/"} }) %>
<%= _.template($('#variable_constructor').html())({id:"Save", description:"Result", default_variable: "BALANCE_RESULT", help: {description: "Баланс аккаунта"}}) %>
</div>
<div class="tooltipinternal">
<div class="tr tooltip-paragraph-first-fold">Эта функция получает баланс ключа с сервиса https://multibot.in/</div>
</div>
<%= _.template($('#back').html())({action:"executeandadd", visible:true}) %>
