var ezhleuqi = GetInputConstructorValue("ezhleuqi", loader);
                 if(ezhleuqi["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var zvxmovzx = GetInputConstructorValue("zvxmovzx", loader);
                 if(zvxmovzx["original"].length == 0)
                 {
                   Invalid("pixel_koef" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#MultibotSolver_GeeTest_code").html())({"ezhleuqi": ezhleuqi["updated"],"zvxmovzx": zvxmovzx["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
