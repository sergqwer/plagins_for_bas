var mbijwwsa = GetInputConstructorValue("mbijwwsa", loader);
                 if(mbijwwsa["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#MultibotSolver_ReCaptchaAutoSolver_code").html())({"mbijwwsa": mbijwwsa["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
