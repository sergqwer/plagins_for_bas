_call_function(MultibotSolver_HcaptchaTakeToken,{ "APIKEY": (<%= cylzmfjd %>),"site_url": (<%= yuuxxxtw %>),"sitekey": (<%= asndvulx %>) })!
<%= variable %> = _result_function()
