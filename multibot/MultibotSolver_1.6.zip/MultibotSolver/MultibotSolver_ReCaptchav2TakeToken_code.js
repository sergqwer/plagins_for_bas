_call_function(MultibotSolver_ReCaptchav2TakeToken,{ "APIKEY": (<%= ajrgxfzs %>),"site_url": (<%= ymvweukw %>),"sitekey": (<%= nsnvegie %>) })!
<%= variable %> = _result_function()
