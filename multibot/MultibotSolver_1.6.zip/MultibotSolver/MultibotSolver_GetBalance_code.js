_call_function(MultibotSolver_GetBalance,{ "APIKEY": (<%= vwpqvzye %>) })!
<%= variable %> = _result_function()
