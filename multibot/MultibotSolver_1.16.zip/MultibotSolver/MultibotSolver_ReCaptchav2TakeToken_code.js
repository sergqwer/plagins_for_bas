_call_function(MultibotSolver_ReCaptchav2TakeToken,{ "APIKEY": (<%= aufurpoe %>),"site_url": (<%= fjywabuj %>),"sitekey": (<%= lnhatmeq %>) })!
<%= variable %> = _result_function()
