var iqzkmcwz = GetInputConstructorValue("iqzkmcwz", loader);
                 if(iqzkmcwz["original"].length == 0)
                 {
                   Invalid("hCaptcha_USE" + " is empty");
                   return;
                 }
var nrbguukd = GetInputConstructorValue("nrbguukd", loader);
                 if(nrbguukd["original"].length == 0)
                 {
                   Invalid("ReCaptcha_USE" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#MultibotSolver_ForAutosolveReHCaptcha_code").html())({"iqzkmcwz": iqzkmcwz["updated"],"nrbguukd": nrbguukd["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
