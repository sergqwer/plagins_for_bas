var aekpmlnw = GetInputConstructorValue("aekpmlnw", loader);
                 if(aekpmlnw["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var kvjvtjyo = GetInputConstructorValue("kvjvtjyo", loader);
                 if(kvjvtjyo["original"].length == 0)
                 {
                   Invalid("index" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#MultibotSolver_ReCaptcha_Bypass_code").html())({"aekpmlnw": aekpmlnw["updated"],"kvjvtjyo": kvjvtjyo["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
