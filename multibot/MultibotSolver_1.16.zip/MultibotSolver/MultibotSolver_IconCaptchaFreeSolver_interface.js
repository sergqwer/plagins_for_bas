<div class="container-fluid">
</div>
<div class="tooltipinternal">
<div class="tr tooltip-paragraph-first-fold">Решает Icon капчу стандартными сервисами BAS не используя сторонние сервисы</div>
</div>
<%= _.template($('#back').html())({action:"executeandadd", visible:true}) %>
