_call_function(MultibotSolver_GetBalance,{ "APIKEY": (<%= nluytlgd %>) })!
<%= variable %> = _result_function()
