_call_function(MultibotSolver_TextOnImage,{ "APIKEY": (<%= xzvcives %>),"IMAGE_IN_BASE64": (<%= voaymsir %>) })!
<%= variable %> = _result_function()
