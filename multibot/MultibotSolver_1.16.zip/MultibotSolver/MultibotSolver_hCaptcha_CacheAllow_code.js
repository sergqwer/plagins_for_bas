_call_function(MultibotSolver_hCaptcha_CacheAllow,{  })!
