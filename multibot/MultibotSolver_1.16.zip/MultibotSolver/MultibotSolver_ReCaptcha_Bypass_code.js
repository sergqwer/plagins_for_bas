_call_function(MultibotSolver_ReCaptcha_Bypass,{ "apikey": (<%= aekpmlnw %>),"index": (<%= kvjvtjyo %>) })!
