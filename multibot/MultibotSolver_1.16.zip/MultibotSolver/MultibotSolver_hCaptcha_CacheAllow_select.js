try{
          var code = loader.GetAdditionalData() + _.template($("#MultibotSolver_hCaptcha_CacheAllow_code").html())({});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
