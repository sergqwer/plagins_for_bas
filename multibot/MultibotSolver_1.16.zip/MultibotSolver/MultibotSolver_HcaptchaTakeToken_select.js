var vwqtmgau = GetInputConstructorValue("vwqtmgau", loader);
                 if(vwqtmgau["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var czxoqccp = GetInputConstructorValue("czxoqccp", loader);
                 if(czxoqccp["original"].length == 0)
                 {
                   Invalid("site_url" + " is empty");
                   return;
                 }
var uuuxzedi = GetInputConstructorValue("uuuxzedi", loader);
                 if(uuuxzedi["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#MultibotSolver_HcaptchaTakeToken_code").html())({"vwqtmgau": vwqtmgau["updated"],"czxoqccp": czxoqccp["updated"],"uuuxzedi": uuuxzedi["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
