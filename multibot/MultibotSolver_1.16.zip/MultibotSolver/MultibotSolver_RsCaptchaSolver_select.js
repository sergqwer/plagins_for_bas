var qakufgzq = GetInputConstructorValue("qakufgzq", loader);
                 if(qakufgzq["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#MultibotSolver_RsCaptchaSolver_code").html())({"qakufgzq": qakufgzq["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
