var buyyevob = GetInputConstructorValue("buyyevob", loader);
                 if(buyyevob["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var gpbbwslq = GetInputConstructorValue("gpbbwslq", loader);
                 if(gpbbwslq["original"].length == 0)
                 {
                   Invalid("CaptchaSelector" + " is empty");
                   return;
                 }
var xkzdfbtj = GetInputConstructorValue("xkzdfbtj", loader);
                 if(xkzdfbtj["original"].length == 0)
                 {
                   Invalid("InvisibleCaptcha" + " is empty");
                   return;
                 }
var qlwhngar = GetInputConstructorValue("qlwhngar", loader);
                 if(qlwhngar["original"].length == 0)
                 {
                   Invalid("TrySolve" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#MultibotSolver_hCaptcha_Click_code").html())({"buyyevob": buyyevob["updated"],"gpbbwslq": gpbbwslq["updated"],"xkzdfbtj": xkzdfbtj["updated"],"qlwhngar": qlwhngar["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
