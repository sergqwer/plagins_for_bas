_call_function(MultibotSolver_Turnstile_TakeToken,{ "APIKEY": (<%= yjdsdeaz %>),"site_url": (<%= duwxyotc %>),"sitekey": (<%= qslkagxy %>) })!
<%= variable %> = _result_function()
