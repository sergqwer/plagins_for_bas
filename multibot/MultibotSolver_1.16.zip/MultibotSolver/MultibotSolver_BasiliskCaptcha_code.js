_call_function(MultibotSolver_BasiliskCaptcha,{ "apikey": (<%= lyaeycxb %>),"sitekey": (<%= wkwiills %>),"siteurl": (<%= caysvwwc %>) })!
