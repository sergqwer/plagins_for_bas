_call_function(MultibotSolver_GeeTest,{ "APIKEY": (<%= gndtbiaa %>),"pixel_koef": (<%= vijzrznc %>) })!
