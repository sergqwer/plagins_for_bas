var jaufwshb = GetInputConstructorValue("jaufwshb", loader);
                 if(jaufwshb["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var rqoxpvzu = GetInputConstructorValue("rqoxpvzu", loader);
                 if(rqoxpvzu["original"].length == 0)
                 {
                   Invalid("mouse" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#MultibotSolver_AntiBot_code").html())({"jaufwshb": jaufwshb["updated"],"rqoxpvzu": rqoxpvzu["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
