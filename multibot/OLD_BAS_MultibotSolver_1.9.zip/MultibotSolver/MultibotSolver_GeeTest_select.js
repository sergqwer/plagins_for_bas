var gndtbiaa = GetInputConstructorValue("gndtbiaa", loader);
                 if(gndtbiaa["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var vijzrznc = GetInputConstructorValue("vijzrznc", loader);
                 if(vijzrznc["original"].length == 0)
                 {
                   Invalid("pixel_koef" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#MultibotSolver_GeeTest_code").html())({"gndtbiaa": gndtbiaa["updated"],"vijzrznc": vijzrznc["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
