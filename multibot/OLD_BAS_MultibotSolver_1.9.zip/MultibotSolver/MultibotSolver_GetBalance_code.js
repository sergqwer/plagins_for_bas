_call_function(MultibotSolver_GetBalance,{ "APIKEY": (<%= fdidqzri %>) })!
<%= variable %> = _result_function()
