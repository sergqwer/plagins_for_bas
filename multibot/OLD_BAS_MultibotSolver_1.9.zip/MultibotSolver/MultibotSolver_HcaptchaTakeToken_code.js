_call_function(MultibotSolver_HcaptchaTakeToken,{ "APIKEY": (<%= jffiwgwc %>),"site_url": (<%= vhdoxgfu %>),"sitekey": (<%= tstgbbgf %>) })!
<%= variable %> = _result_function()
