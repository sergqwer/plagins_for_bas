_call_function(MultibotSolver_ReCaptchav2TakeToken,{ "APIKEY": (<%= qiyxamct %>),"site_url": (<%= boatsouf %>),"sitekey": (<%= cqdnguhm %>) })!
<%= variable %> = _result_function()
