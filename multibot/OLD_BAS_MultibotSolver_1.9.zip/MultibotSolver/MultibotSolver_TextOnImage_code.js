_call_function(MultibotSolver_TextOnImage,{ "APIKEY": (<%= ehxgzwjc %>),"IMAGE_IN_BASE64": (<%= wbsxbzas %>) })!
<%= variable %> = _result_function()
