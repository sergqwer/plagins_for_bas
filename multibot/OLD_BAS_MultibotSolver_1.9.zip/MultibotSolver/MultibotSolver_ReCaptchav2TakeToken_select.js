var qiyxamct = GetInputConstructorValue("qiyxamct", loader);
                 if(qiyxamct["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var boatsouf = GetInputConstructorValue("boatsouf", loader);
                 if(boatsouf["original"].length == 0)
                 {
                   Invalid("site_url" + " is empty");
                   return;
                 }
var cqdnguhm = GetInputConstructorValue("cqdnguhm", loader);
                 if(cqdnguhm["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#MultibotSolver_ReCaptchav2TakeToken_code").html())({"qiyxamct": qiyxamct["updated"],"boatsouf": boatsouf["updated"],"cqdnguhm": cqdnguhm["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
