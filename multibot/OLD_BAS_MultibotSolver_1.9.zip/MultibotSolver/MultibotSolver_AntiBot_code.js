_call_function(MultibotSolver_AntiBot,{ "apikey": (<%= jaufwshb %>),"mouse": (<%= rqoxpvzu %>) })!
