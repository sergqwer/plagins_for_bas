_call_function(MultibotSolver_AntiBot,{ "apikey": (<%= xhvtgotc %>),"mouse": (<%= joqkjvyx %>) })!
