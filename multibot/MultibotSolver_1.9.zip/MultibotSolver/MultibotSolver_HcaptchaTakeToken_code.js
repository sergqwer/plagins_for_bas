_call_function(MultibotSolver_HcaptchaTakeToken,{ "APIKEY": (<%= zdqbqfil %>),"site_url": (<%= xydzfhnk %>),"sitekey": (<%= suywygif %>) })!
<%= variable %> = _result_function()
