_call_function(MultibotSolver_ReCaptchav2TakeToken,{ "APIKEY": (<%= xkyarmgq %>),"site_url": (<%= igxvayxs %>),"sitekey": (<%= povzqkhn %>) })!
<%= variable %> = _result_function()
