_call_function(MultibotSolver_TextOnImage,{ "APIKEY": (<%= qplsbeup %>),"IMAGE_IN_BASE64": (<%= akdtlvxg %>) })!
<%= variable %> = _result_function()
