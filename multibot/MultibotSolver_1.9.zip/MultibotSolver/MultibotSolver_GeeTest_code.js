_call_function(MultibotSolver_GeeTest,{ "APIKEY": (<%= zyqyqixo %>),"pixel_koef": (<%= anfnyynw %>) })!
