var xkyarmgq = GetInputConstructorValue("xkyarmgq", loader);
                 if(xkyarmgq["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var igxvayxs = GetInputConstructorValue("igxvayxs", loader);
                 if(igxvayxs["original"].length == 0)
                 {
                   Invalid("site_url" + " is empty");
                   return;
                 }
var povzqkhn = GetInputConstructorValue("povzqkhn", loader);
                 if(povzqkhn["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#MultibotSolver_ReCaptchav2TakeToken_code").html())({"xkyarmgq": xkyarmgq["updated"],"igxvayxs": igxvayxs["updated"],"povzqkhn": povzqkhn["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
