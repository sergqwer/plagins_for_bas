_call_function(MultibotSolver_GetBalance,{ "APIKEY": (<%= keatamco %>) })!
<%= variable %> = _result_function()
