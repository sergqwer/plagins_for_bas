var xhvtgotc = GetInputConstructorValue("xhvtgotc", loader);
                 if(xhvtgotc["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var joqkjvyx = GetInputConstructorValue("joqkjvyx", loader);
                 if(joqkjvyx["original"].length == 0)
                 {
                   Invalid("mouse" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#MultibotSolver_AntiBot_code").html())({"xhvtgotc": xhvtgotc["updated"],"joqkjvyx": joqkjvyx["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
