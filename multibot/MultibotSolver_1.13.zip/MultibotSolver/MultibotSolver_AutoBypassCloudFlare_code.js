_call_function(MultibotSolver_AutoBypassCloudFlare,{ "custom_button": (<%= iirpdfnn %>),"max_time": (<%= ziersskv %>),"whait_element": (<%= eugbexbi %>) })!
