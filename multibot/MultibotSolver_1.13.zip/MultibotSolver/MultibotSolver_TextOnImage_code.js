_call_function(MultibotSolver_TextOnImage,{ "APIKEY": (<%= mqllwcfp %>),"IMAGE_IN_BASE64": (<%= rxzfmxih %>) })!
<%= variable %> = _result_function()
