_call_function(MultibotSolver_GeeTest,{ "APIKEY": (<%= rirvpqwo %>),"pixel_koef": (<%= qrvxspui %>) })!
