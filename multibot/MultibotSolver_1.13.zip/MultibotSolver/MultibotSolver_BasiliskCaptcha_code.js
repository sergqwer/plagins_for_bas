_call_function(MultibotSolver_BasiliskCaptcha,{ "apikey": (<%= thfioqku %>),"sitekey": (<%= lvaznqsm %>),"siteurl": (<%= jaxptxzm %>) })!
