_call_function(MultibotSolver_ReCaptcha_Bypass,{ "apikey": (<%= wtevcpil %>),"index": (<%= jzcmmbhn %>) })!
