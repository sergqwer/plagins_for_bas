var thfioqku = GetInputConstructorValue("thfioqku", loader);
                 if(thfioqku["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var lvaznqsm = GetInputConstructorValue("lvaznqsm", loader);
                 if(lvaznqsm["original"].length == 0)
                 {
                   Invalid("sitekey" + " is empty");
                   return;
                 }
var jaxptxzm = GetInputConstructorValue("jaxptxzm", loader);
                 if(jaxptxzm["original"].length == 0)
                 {
                   Invalid("siteurl" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#MultibotSolver_BasiliskCaptcha_code").html())({"thfioqku": thfioqku["updated"],"lvaznqsm": lvaznqsm["updated"],"jaxptxzm": jaxptxzm["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
