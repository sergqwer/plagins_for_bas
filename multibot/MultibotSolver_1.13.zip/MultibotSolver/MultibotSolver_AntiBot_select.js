var lqkhndux = GetInputConstructorValue("lqkhndux", loader);
                 if(lqkhndux["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var cxcqqwby = GetInputConstructorValue("cxcqqwby", loader);
                 if(cxcqqwby["original"].length == 0)
                 {
                   Invalid("mouse" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#MultibotSolver_AntiBot_code").html())({"lqkhndux": lqkhndux["updated"],"cxcqqwby": cxcqqwby["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
