_call_function(MultibotSolver_ReCaptchav2TakeToken,{ "APIKEY": (<%= hezmvdyc %>),"site_url": (<%= kshtkbrv %>),"sitekey": (<%= kokgakju %>) })!
<%= variable %> = _result_function()
