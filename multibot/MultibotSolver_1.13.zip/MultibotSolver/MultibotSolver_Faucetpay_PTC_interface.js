<div class="container-fluid">
<%= _.template($('#input_constructor').html())({id:"zmdagvro", description:"apikey", default_selector: "string", disable_int:true, value_string: "", help: {description: "apikey с сервиса https://multibot.in/"} }) %>
</div>
<div class="tooltipinternal">
<div class="tr tooltip-paragraph-first-fold">Решает https://faucetpay.io/ptc автоматически, внимание, на екране ничего не произойдет, т.к. просто отправляется запрос</div>
<div class="tr tooltip-paragraph-fold">Капча не обязательно должна быть загружена на странице, это не важно</div>
<div class="tr tooltip-paragraph-fold">Ответ от сайта будет в переменной window.responseData браузера</div>
<div class="tr tooltip-paragraph-fold">Чтобы его получить, выполните код</div>
<div class="tr tooltip-paragraph-fold">[[RESPONSE]] = window.responseData;</div>
<div class="tr tooltip-paragraph-fold">Браузер --> Яваскрипт</div>
<div class="tr tooltip-paragraph-fold">Resolves https://faucetpay.io/ptc automatically, attention, nothing will happen on the screen, because it just sends a request.</div>
<div class="tr tooltip-paragraph-fold">The captcha doesn't have to be loaded on the page, it doesn't matter.</div>
<div class="tr tooltip-paragraph-fold">The response from the site will be in the browser's window.responseData variable.</div>
<div class="tr tooltip-paragraph-fold">To get it, execute the code</div>
<div class="tr tooltip-paragraph-fold">[[RESPONSE]] = window.responseData;</div>
<div class="tr tooltip-paragraph-last-fold">Browser --> Javascript</div>
</div>
<%= _.template($('#back').html())({action:"executeandadd", visible:true}) %>
