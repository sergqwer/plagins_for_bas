var iirpdfnn = GetInputConstructorValue("iirpdfnn", loader);
                 if(iirpdfnn["original"].length == 0)
                 {
                   Invalid("custom_button" + " is empty");
                   return;
                 }
var ziersskv = GetInputConstructorValue("ziersskv", loader);
                 if(ziersskv["original"].length == 0)
                 {
                   Invalid("max_time" + " is empty");
                   return;
                 }
var eugbexbi = GetInputConstructorValue("eugbexbi", loader);
                 if(eugbexbi["original"].length == 0)
                 {
                   Invalid("whait_element" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#MultibotSolver_AutoBypassCloudFlare_code").html())({"iirpdfnn": iirpdfnn["updated"],"ziersskv": ziersskv["updated"],"eugbexbi": eugbexbi["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
