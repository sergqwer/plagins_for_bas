_call_function(MultibotSolver_HcaptchaTakeToken,{ "APIKEY": (<%= uxwftafl %>),"site_url": (<%= lzxbyrbj %>),"sitekey": (<%= tgpjeznn %>) })!
<%= variable %> = _result_function()
