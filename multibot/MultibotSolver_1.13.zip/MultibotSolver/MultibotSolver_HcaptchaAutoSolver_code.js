_call_function(MultibotSolver_HcaptchaAutoSolver,{ "apikey": (<%= ofluueax %>) })!
