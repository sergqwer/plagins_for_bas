_call_function(MultibotSolver_GetBalance,{ "APIKEY": (<%= vcgeecrt %>) })!
<%= variable %> = _result_function()
