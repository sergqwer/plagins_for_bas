_call_function(MultibotSolver_AntiBot,{ "apikey": (<%= lqkhndux %>),"mouse": (<%= cxcqqwby %>) })!
