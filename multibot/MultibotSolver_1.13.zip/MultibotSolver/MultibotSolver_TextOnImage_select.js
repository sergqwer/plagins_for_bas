var mqllwcfp = GetInputConstructorValue("mqllwcfp", loader);
                 if(mqllwcfp["original"].length == 0)
                 {
                   Invalid("APIKEY" + " is empty");
                   return;
                 }
var rxzfmxih = GetInputConstructorValue("rxzfmxih", loader);
                 if(rxzfmxih["original"].length == 0)
                 {
                   Invalid("IMAGE_IN_BASE64" + " is empty");
                   return;
                 }
var Save = this.$el.find("#Save").val().toUpperCase();
try{
          var code = loader.GetAdditionalData() + _.template($("#MultibotSolver_TextOnImage_code").html())({"mqllwcfp": mqllwcfp["updated"],"rxzfmxih": rxzfmxih["updated"],"variable": "VAR_" + Save});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
