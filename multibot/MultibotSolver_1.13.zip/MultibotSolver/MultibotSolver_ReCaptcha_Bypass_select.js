var wtevcpil = GetInputConstructorValue("wtevcpil", loader);
                 if(wtevcpil["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
var jzcmmbhn = GetInputConstructorValue("jzcmmbhn", loader);
                 if(jzcmmbhn["original"].length == 0)
                 {
                   Invalid("index" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#MultibotSolver_ReCaptcha_Bypass_code").html())({"wtevcpil": wtevcpil["updated"],"jzcmmbhn": jzcmmbhn["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
