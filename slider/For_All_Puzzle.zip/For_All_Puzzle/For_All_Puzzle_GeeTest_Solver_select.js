var meehjhyd = GetInputConstructorValue("meehjhyd", loader);
                 if(meehjhyd["original"].length == 0)
                 {
                   Invalid("arrow_id" + " is empty");
                   return;
                 }
var tyzowadh = GetInputConstructorValue("tyzowadh", loader);
                 if(tyzowadh["original"].length == 0)
                 {
                   Invalid("avtoupdate" + " is empty");
                   return;
                 }
var lhozvoye = GetInputConstructorValue("lhozvoye", loader);
                 if(lhozvoye["original"].length == 0)
                 {
                   Invalid("button_id" + " is empty");
                   return;
                 }
var jirqzezv = GetInputConstructorValue("jirqzezv", loader);
                 if(jirqzezv["original"].length == 0)
                 {
                   Invalid("coef" + " is empty");
                   return;
                 }
var uhitraij = GetInputConstructorValue("uhitraij", loader);
                 if(uhitraij["original"].length == 0)
                 {
                   Invalid("image id" + " is empty");
                   return;
                 }
var xktwiakp = GetInputConstructorValue("xktwiakp", loader);
                 if(xktwiakp["original"].length == 0)
                 {
                   Invalid("key" + " is empty");
                   return;
                 }
var aftcvwoa = GetInputConstructorValue("aftcvwoa", loader);
                 if(aftcvwoa["original"].length == 0)
                 {
                   Invalid("pixel_koef" + " is empty");
                   return;
                 }
var bccgwzlr = GetInputConstructorValue("bccgwzlr", loader);
                 if(bccgwzlr["original"].length == 0)
                 {
                   Invalid("reload_id" + " is empty");
                   return;
                 }
var snnmhanr = GetInputConstructorValue("snnmhanr", loader);
                 if(snnmhanr["original"].length == 0)
                 {
                   Invalid("speed" + " is empty");
                   return;
                 }
var xynuutmi = GetInputConstructorValue("xynuutmi", loader);
                 if(xynuutmi["original"].length == 0)
                 {
                   Invalid("type_slide" + " is empty");
                   return;
                 }
var uzcavfkg = GetInputConstructorValue("uzcavfkg", loader);
                 if(uzcavfkg["original"].length == 0)
                 {
                   Invalid("type_swipe" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#For_All_Puzzle_GeeTest_Solver_code").html())({"meehjhyd": meehjhyd["updated"],"tyzowadh": tyzowadh["updated"],"lhozvoye": lhozvoye["updated"],"jirqzezv": jirqzezv["updated"],"uhitraij": uhitraij["updated"],"xktwiakp": xktwiakp["updated"],"aftcvwoa": aftcvwoa["updated"],"bccgwzlr": bccgwzlr["updated"],"snnmhanr": snnmhanr["updated"],"xynuutmi": xynuutmi["updated"],"uzcavfkg": uzcavfkg["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
