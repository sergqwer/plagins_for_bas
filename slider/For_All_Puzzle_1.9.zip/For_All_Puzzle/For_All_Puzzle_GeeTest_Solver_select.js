var usuovobn = GetInputConstructorValue("usuovobn", loader);
                 if(usuovobn["original"].length == 0)
                 {
                   Invalid("arrow_id" + " is empty");
                   return;
                 }
var rmueuzij = GetInputConstructorValue("rmueuzij", loader);
                 if(rmueuzij["original"].length == 0)
                 {
                   Invalid("avtoupdate" + " is empty");
                   return;
                 }
var ejkshbuf = GetInputConstructorValue("ejkshbuf", loader);
                 if(ejkshbuf["original"].length == 0)
                 {
                   Invalid("button_id" + " is empty");
                   return;
                 }
var adfgfkzx = GetInputConstructorValue("adfgfkzx", loader);
                 if(adfgfkzx["original"].length == 0)
                 {
                   Invalid("coef" + " is empty");
                   return;
                 }
var fdkyxulz = GetInputConstructorValue("fdkyxulz", loader);
                 if(fdkyxulz["original"].length == 0)
                 {
                   Invalid("image id" + " is empty");
                   return;
                 }
var mrvjgsqs = GetInputConstructorValue("mrvjgsqs", loader);
                 if(mrvjgsqs["original"].length == 0)
                 {
                   Invalid("key" + " is empty");
                   return;
                 }
var srylbwee = GetInputConstructorValue("srylbwee", loader);
                 if(srylbwee["original"].length == 0)
                 {
                   Invalid("pixel_koef" + " is empty");
                   return;
                 }
var ffcnqbgh = GetInputConstructorValue("ffcnqbgh", loader);
                 if(ffcnqbgh["original"].length == 0)
                 {
                   Invalid("reload_id" + " is empty");
                   return;
                 }
var notvbcre = GetInputConstructorValue("notvbcre", loader);
                 if(notvbcre["original"].length == 0)
                 {
                   Invalid("speed" + " is empty");
                   return;
                 }
var gvifiyeu = GetInputConstructorValue("gvifiyeu", loader);
                 if(gvifiyeu["original"].length == 0)
                 {
                   Invalid("type_slide" + " is empty");
                   return;
                 }
var jbefiesz = GetInputConstructorValue("jbefiesz", loader);
                 if(jbefiesz["original"].length == 0)
                 {
                   Invalid("type_swipe" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#For_All_Puzzle_GeeTest_Solver_code").html())({"usuovobn": usuovobn["updated"],"rmueuzij": rmueuzij["updated"],"ejkshbuf": ejkshbuf["updated"],"adfgfkzx": adfgfkzx["updated"],"fdkyxulz": fdkyxulz["updated"],"mrvjgsqs": mrvjgsqs["updated"],"srylbwee": srylbwee["updated"],"ffcnqbgh": ffcnqbgh["updated"],"notvbcre": notvbcre["updated"],"gvifiyeu": gvifiyeu["updated"],"jbefiesz": jbefiesz["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
