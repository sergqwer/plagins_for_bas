var tlikklks = GetInputConstructorValue("tlikklks", loader);
                 if(tlikklks["original"].length == 0)
                 {
                   Invalid("arrow_id" + " is empty");
                   return;
                 }
var qhngackf = GetInputConstructorValue("qhngackf", loader);
                 if(qhngackf["original"].length == 0)
                 {
                   Invalid("avtoupdate" + " is empty");
                   return;
                 }
var ocrvtckx = GetInputConstructorValue("ocrvtckx", loader);
                 if(ocrvtckx["original"].length == 0)
                 {
                   Invalid("button_id" + " is empty");
                   return;
                 }
var xlmdtnfh = GetInputConstructorValue("xlmdtnfh", loader);
                 if(xlmdtnfh["original"].length == 0)
                 {
                   Invalid("coef" + " is empty");
                   return;
                 }
var fxkmbxkt = GetInputConstructorValue("fxkmbxkt", loader);
                 if(fxkmbxkt["original"].length == 0)
                 {
                   Invalid("image id" + " is empty");
                   return;
                 }
var hbpbfgjy = GetInputConstructorValue("hbpbfgjy", loader);
                 if(hbpbfgjy["original"].length == 0)
                 {
                   Invalid("key" + " is empty");
                   return;
                 }
var lavlqjnb = GetInputConstructorValue("lavlqjnb", loader);
                 if(lavlqjnb["original"].length == 0)
                 {
                   Invalid("pixel_koef" + " is empty");
                   return;
                 }
var lssvgeqh = GetInputConstructorValue("lssvgeqh", loader);
                 if(lssvgeqh["original"].length == 0)
                 {
                   Invalid("reload_id" + " is empty");
                   return;
                 }
var kjshilup = GetInputConstructorValue("kjshilup", loader);
                 if(kjshilup["original"].length == 0)
                 {
                   Invalid("speed" + " is empty");
                   return;
                 }
var twbouyvi = GetInputConstructorValue("twbouyvi", loader);
                 if(twbouyvi["original"].length == 0)
                 {
                   Invalid("type_slide" + " is empty");
                   return;
                 }
var acscpttz = GetInputConstructorValue("acscpttz", loader);
                 if(acscpttz["original"].length == 0)
                 {
                   Invalid("type_swipe" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#For_All_Puzzle_GeeTest_Solver_code").html())({"tlikklks": tlikklks["updated"],"qhngackf": qhngackf["updated"],"ocrvtckx": ocrvtckx["updated"],"xlmdtnfh": xlmdtnfh["updated"],"fxkmbxkt": fxkmbxkt["updated"],"hbpbfgjy": hbpbfgjy["updated"],"lavlqjnb": lavlqjnb["updated"],"lssvgeqh": lssvgeqh["updated"],"kjshilup": kjshilup["updated"],"twbouyvi": twbouyvi["updated"],"acscpttz": acscpttz["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
