_call_function(Captcha_Solver_SeoFast_SeoFast_Captcha_Solver,{ "apikey": (<%= odcqkbrm %>) })!
