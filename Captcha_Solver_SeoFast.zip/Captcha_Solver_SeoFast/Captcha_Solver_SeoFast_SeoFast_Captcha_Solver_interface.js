<div class="container-fluid">
<%= _.template($('#input_constructor').html())({id:"odcqkbrm", description:"apikey", default_selector: "string", disable_expression:true, disable_int:true, value_string: "", help: {description: ""} }) %>
</div>
<div class="tooltipinternal">
</div>
<%= _.template($('#back').html())({action:"executeandadd", visible:true}) %>
