var odcqkbrm = GetInputConstructorValue("odcqkbrm", loader);
                 if(odcqkbrm["original"].length == 0)
                 {
                   Invalid("apikey" + " is empty");
                   return;
                 }
try{
          var code = loader.GetAdditionalData() + _.template($("#Captcha_Solver_SeoFast_SeoFast_Captcha_Solver_code").html())({"odcqkbrm": odcqkbrm["updated"]});
          code = Normalize(code,0);
          BrowserAutomationStudio_Append("", BrowserAutomationStudio_SaveControls() + code, action, DisableIfAdd);
        }catch(e)
        {}
